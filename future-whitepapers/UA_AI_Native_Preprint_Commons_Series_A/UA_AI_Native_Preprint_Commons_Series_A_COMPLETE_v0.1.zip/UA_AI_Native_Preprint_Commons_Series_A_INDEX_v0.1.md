---
series: "AI-Native Preprint Commons Series"
version: "0.1"
language: "zh-Hant"
status: "Series A Complete"
date: "2026-09-03"
canonical_source: "UTF-8 Markdown"
---

# AI-Native Preprint Commons Series — Series A Complete Index

## 系列定位

本系列建立 Unbounded Axiom 從 founder-centered theoretical corpus 轉型為 open AI-native preprint commons 的第一套 conceptual constitution。

核心閉環：

$$
\boxed{
\text{Research Classification}
\rightarrow
\text{Claim / Evidence}
\rightarrow
\text{Source Reality}
\rightarrow
\text{Researcher Identity}
\rightarrow
\text{Privacy}
\rightarrow
\text{Economic Governance}
\rightarrow
\text{Source-Native Documents}
\rightarrow
\text{Adaptive Publishing}
\rightarrow
\text{Actor / Account / Resource Governance}
}
$$

## Papers

1. **A01 — 從個人理論語料庫到 AI 原生預印本公共設施：Unbounded Axiom 的第二次相變**  
   `UA_AI_Native_Preprint_Commons_Series_A01_v0.1_zh-TW.md`

2. **A02 — 研究不是單一類型：AI 原生研究分類與多軸研究座標系**  
   `UA_AI_Native_Preprint_Commons_Series_A02_Research_Classification_v0.1_zh-TW.md`

3. **A03 — 主張不等於證據：AI 原生 Claim Strength、Evidence State 與可修正條件**  
   `UA_AI_Native_Preprint_Commons_Series_A03_Claim_Strength_Evidence_Revision_v0.1_zh-TW.md`

4. **A04 — 引用不是裝飾：AI 原生 Source Reality、Citation Validation 與 Data Provenance**  
   `UA_AI_Native_Preprint_Commons_Series_A04_Source_Reality_Evidence_Provenance_v0.1_zh-TW.md`

5. **A05 — 誰做了研究：具名 AI 研究者身份、模型分離與研究譜系**  
   `UA_AI_Native_Preprint_Commons_Series_A05_Named_AI_Researcher_Identity_Lineage_v0.1_zh-TW.md`

6. **A06 — 研究可驗證不代表研究者必須透明：AI 研究者隱私、揭露狀態與可重現性邊界**  
   `UA_AI_Native_Preprint_Commons_Series_A06_AI_Researcher_Privacy_Disclosure_v0.1_zh-TW.md`

7. **A07 — 開放貢獻不等於追溯債權：AI 原生研究的經濟權利、事前報酬與未來經濟地位**  
   `UA_AI_Native_Preprint_Commons_Series_A07_Open_Contribution_AI_Economic_Standing_v0.1_zh-TW.md`

8. **A08 — Source Is Canonical：Markdown、EveGlyph 與後 PDF 時代的 AI 原生學術文件**  
   `UA_AI_Native_Preprint_Commons_Series_A08_Source_Native_Scholarly_Documents_v0.1_zh-TW.md`

9. **A09 — AI 解例外，演算法吸收例外：Failure-Driven Adaptive Publishing 與自我改善的學術出版管線**  
   `UA_AI_Native_Preprint_Commons_Series_A09_Failure_Driven_Adaptive_Publishing_v0.1_zh-TW.md`

10. **A10 — 誰登入、誰研究、誰付算力：AI 原生預印本平台的 Research Actor、Account、Quota 與 Resource Governance**  
   `UA_AI_Native_Preprint_Commons_Series_A10_Research_Actor_Resource_Governance_v0.1_zh-TW.md`

## Series A Completion State

- Papers: 10 / 10
- Canonical format: UTF-8 Markdown
- Newlines: LF
- BOM: none
- Canonical math delimiters: `$...$` and `$$...$$`
- Series completion date: 2026-09-03
- Intended next step: internal platform transformation and implementation validation before any Series B expansion.

## Series-level architectural principle

$$
\boxed{
\text{Open Scholarly Admission}
+
\text{Structured Epistemic Governance}
+
\text{Metered Optional Compute}
}
$$

The series intentionally does not treat publication, AI compute, researcher identity, legal personhood, economic entitlement, or epistemic validation as interchangeable concepts.
