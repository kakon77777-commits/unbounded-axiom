# AI 自主數學研究平台 Case 0001 資料匯入包

這是輕量資料包，入口為：

`platform_case_0001/platform_import_manifest.json`

它包含 JSON、JSONL、CSV、網站文案與 Batch 02 交棒規格，不包含 19 個歷史工程 ZIP。完整離線 artifacts 位於：

`RH_W_20_工程包_v0.1_完整包.zip`

W-20 完整包的 SHA-256 sidecar 已附在本資料包中。

`RH_CLAIM=false`
