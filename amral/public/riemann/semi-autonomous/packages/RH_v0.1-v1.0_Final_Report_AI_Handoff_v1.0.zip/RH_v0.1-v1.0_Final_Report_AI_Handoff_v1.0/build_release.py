#!/usr/bin/env python3
"""Build the deterministic metadata and canonical evidence snapshots.

The ten source ZIP archives are treated as the canonical release objects.
The already-extracted working directories are deliberately not used as the
evidence source, because a working copy may have been touched by a replay.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import zipfile


PACKAGE = Path(__file__).resolve().parent
WORKSPACE = PACKAGE.parent


NODES = [
    {
        "sequence": 1,
        "version": "0.1",
        "date": "2026-07-24",
        "archive": "RH_Banded_MultiTest_Cover_Certificates_v0.1.zip",
        "node_id": "RH-BMCC-20260724-v0.1",
        "title_zh": "分帶、多測試函數與自適應覆蓋證書族",
        "question": "局部相位塑形能否以分帶、多測試函數與有限覆蓋，轉成可檢查的全域支配候選？",
        "result": "18 個有理原子 patch 的覆蓋與局部浮點符號審計通過；72 個候選皆未通過部分全域預算。",
        "decision": "保留 18-patch 覆蓋，將對角非負錐升級為完整 PSD Gram 變量。",
        "evidence_ceiling": "exact_finite_cover_plus_floating_diagnostics",
        "global_rh_certificate": False,
    },
    {
        "sequence": 2,
        "version": "0.2",
        "date": "2026-07-24",
        "archive": "RH_PSD_Gram_Banded_Global_Dominance_v0.2.zip",
        "node_id": "RH-PSDGRAM-20260724-v0.2",
        "title_zh": "PSD Gram 分帶全域支配",
        "question": "完整 Gram 交叉項能否補足對角錐的全域預算缺口？",
        "result": "每個 patch 的 sampled majorant 均改善，但最終因子數值秩皆塌縮為 1，所有 sampled 與 Lipschitz-corrected 預算仍為負。",
        "decision": "停止同一 primal rank 家族，改做聚焦主導軸帶的 dual transfer lower bound。",
        "evidence_ceiling": "exact_model_identities_plus_floating_nonconvex_search",
        "global_rh_certificate": False,
    },
    {
        "sequence": 3,
        "version": "0.3",
        "date": "2026-07-24",
        "archive": "RH_Axis_Target_Dual_Obstruction_v0.3.zip",
        "node_id": "RH-AxisTarget-Dual-20260724-v0.3",
        "title_zh": "軸目標對偶障礙",
        "question": "目前 $R=3$ 有限函數類是否在預算 1 下已被對偶證人阻塞？",
        "result": "18 個有理 surrogate 的 exact LDL 均為正，dual lower bound 為 2；此結論只拒絕具名有限模型。",
        "decision": "淘汰目前 $R=3$ patchwise 類，先測 support radius 與 prime cost 的前沿。",
        "evidence_ceiling": "exact_rational_surrogate_plus_floating_analytic_transfer",
        "global_rh_certificate": False,
    },
    {
        "sequence": 4,
        "version": "0.4",
        "date": "2026-07-24",
        "archive": "RH_Support_Prime_Dual_Frontier_v0.4.zip",
        "node_id": "RH-SupportPrime-DualFrontier-20260724-v0.4",
        "title_zh": "支撐半徑—質數成本對偶前沿",
        "question": "只增加支撐半徑，能否在可接受 prime cutoff 下穿過 dual gate？",
        "result": "細化後所有測試支撐仍有 blocked patch；coarse axis grid 曾產生假 escape；prime cost 隨 $R$ 劇增。",
        "decision": "停止 support-only 擴張，改做軸 notch、dictionary geometry 與 patch constraint 的共同設計。",
        "evidence_ceiling": "exact_witness_reconstruction_plus_sampled_frontier",
        "global_rh_certificate": False,
    },
    {
        "sequence": 5,
        "version": "0.5",
        "date": "2026-07-24",
        "archive": "RH_Axis_Notch_Cover_Codesign_v0.5.zip",
        "node_id": "RH-AxisNotch-CoverCodesign-20260724-v0.5",
        "title_zh": "軸 notch、覆蓋與字典共設計",
        "question": "有限維 notch 或外部 lift 能否把最困難 patch 的 safe dual threshold 壓到 1 以下？",
        "result": "齊次 notch 子空間有精確單調性障礙；anchor-flat 更差；最佳幾何仍為 $1.0717612>1$。",
        "decision": "停止已測 notch/lift/polynomial scaling，轉入連續 Paley–Wiener 型極值問題。",
        "evidence_ceiling": "exact_subspace_theorem_plus_floating_search",
        "global_rh_certificate": False,
    },
    {
        "sequence": 6,
        "version": "0.6",
        "date": "2026-07-25",
        "archive": "RH_PaleyWiener_AxisCore_Extremal_v0.6.zip",
        "node_id": "RH-PaleyWiener-AxisCoreExtremal-20260725-v0.6",
        "title_zh": "Paley–Wiener 軸核連續極值",
        "question": "能否把有限字典飽和改寫成可證的連續 $H_0^2$ 核對偶，並將無限維 PSD 降為低秩判定？",
        "result": "證得弱對偶、Green 核與 rank-two Schur 歸約；58+2 原子 witness 的 direct Green threshold 約為 $1.1324412$。",
        "decision": "凍結 rational witness，在 $\\alpha=21/20$ 上做完整區間證書。",
        "evidence_ceiling": "proved_continuous_model_plus_floating_green_witness",
        "global_rh_certificate": False,
    },
    {
        "sequence": 7,
        "version": "0.7",
        "date": "2026-07-25",
        "archive": "RH_IntervalGreenKernel_AtomicCertificate_v0.7.zip",
        "node_id": "RH-IntervalGreenKernel-AtomicCertificate-20260725-v0.7",
        "title_zh": "區間 Green 核原子證書",
        "question": "固定的 60 正秩、2 負秩抽象連續算子在 $\\alpha=21/20$ 時是否嚴格正？",
        "result": "區間 Neumann defect、第一主子式與 Schur determinant 均嚴格通過；但五帶係數方向審計揭露 upper/lower 語義錯置。",
        "decision": "保留抽象證書，停止把它解讀為 zeta zero-side 障礙；先修正 count semantics。",
        "evidence_ceiling": "interval_certified_abstract_continuous_model",
        "global_rh_certificate": False,
    },
    {
        "sequence": 8,
        "version": "0.8",
        "date": "2026-07-25",
        "archive": "RH_ZeroCount_Semantics_Bridge_v0.8.zip",
        "node_id": "RH-ZeroCount-SemanticsBridge-20260725-v0.8",
        "title_zh": "零點計數語義橋",
        "question": "標量上下計數能否合法轉成任意位置分布的算子質量？",
        "result": "證明 upper-sup 與 lower-inf 的合法方向，並以 exact countermodel 否決 lower count 到 arbitrary measure/operator 的普遍轉移。",
        "decision": "將工作拆成 upper-envelope no-go 與 location-aware occupancy 兩軌；主線轉向後者。",
        "evidence_ceiling": "exact_semantic_theorems_and_counterexamples",
        "global_rh_certificate": False,
    },
    {
        "sequence": 9,
        "version": "0.9",
        "date": "2026-07-25",
        "archive": "RH_Occupancy_OperatorFamily_v0.9.zip",
        "node_id": "RH-Occupancy-OperatorFamily-20260725-v0.9",
        "title_zh": "占用算子族與覆蓋式 Green 證書",
        "question": "cell occupancy、位置全稱量詞與 PSD surplus 能否形成合法的 operator transfer 架構？",
        "result": "exact occupancy transfer 與 count-only counterexample 完成；synthetic 8-leaf cover 通過；clamped 58-cell 只在 $2\\times10^{-15}$ 半徑上條件通過。",
        "decision": "建立局部 Green 導數／仿射區間引擎，直接擴張 58 維位置盒。",
        "evidence_ceiling": "exact_synthetic_and_parent_conditional_interval_results",
        "global_rh_certificate": False,
    },
    {
        "sequence": 10,
        "version": "1.0",
        "date": "2026-07-25",
        "archive": "RH_LocalIntervalGreen_CellCover_v1.0.zip",
        "node_id": "RH-LocalIntervalGreen-CellCover-20260725-v1.0",
        "title_zh": "局部區間 Green 五十八胞覆蓋",
        "question": "可否用位置感知區間 Green pairing，把 microscopic 58-cell 半徑提升成可用的 downward-closed cover family？",
        "result": "在 $h=89/50000000=1.78\\times10^{-6}$ 上證得所有 58 個獨立位置選擇的抽象算子嚴格正，尺度提升 $890000000$ 倍。",
        "decision": "技術收束；不再擴張局部證明器，轉為完整報告與後續 AI 交接。",
        "evidence_ceiling": "interval_certified_abstract_58_location_family",
        "global_rh_certificate": False,
    },
]


SYNTHESIS_CLAIMS = [
    {
        "claim_id": "SYN-C01",
        "origin": ["v0.1"],
        "status": "proved_in_finite_cover_model",
        "evidence_class": "EXACT_FINITE",
        "statement": "18 個有理原子 patch 覆蓋具名目標矩形，且覆蓋可被機器重算。",
        "scope": "合成目標 $[20,20.5]\\times[-0.2,-0.1]$；不是 zeta 零點存在證書。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C02",
        "origin": ["v0.1", "v0.2"],
        "status": "floating_family_failure",
        "evidence_class": "FLOATING_DIAGNOSTIC",
        "statement": "對角候選與具名 full-Gram 非凸搜尋家族均未通過全域支配預算；full Gram 雖有局部改善，仍不足以閉合 gap。",
        "scope": "僅限已搜尋家族；不是對所有測試函數的不可能定理。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C03",
        "origin": ["v0.3"],
        "status": "proved_for_rational_surrogate",
        "evidence_class": "EXACT_FINITE",
        "statement": "具名 $R=3$ 有限模型存在 exact rational dual obstruction，足以淘汰該模型家族。",
        "scope": "不含 Fourier/count/tail 的定向解析轉移；不排除更大函數類。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C04",
        "origin": ["v0.4"],
        "status": "diagnostic_frontier",
        "evidence_class": "REPLAY_STRUCTURAL",
        "statement": "support-only 擴張在 $R\\le16$ 的具名搜尋中仍有 blocked patch，且 coarse axis grid 會產生假 escape。",
        "scope": "有限支撐與網格研究結論。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C05",
        "origin": ["v0.5"],
        "status": "proved_monotonicity_plus_diagnostic_saturation",
        "evidence_class": "EXACT_FINITE",
        "statement": "齊次 notch 約束只是縮小可行子空間，不能改善同一 parent minimization；已測外部 lifts 仍未穿過 gate。",
        "scope": "精確定理適用於齊次子空間；外部 lift 結論只限已測家族。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C06",
        "origin": ["v0.6"],
        "status": "proved_in_continuous_model",
        "evidence_class": "MODEL_THEOREM",
        "statement": "在明確定義的 real-even clamped $H_0^2(-R,R)$ 模型中，弱對偶、clamped Green kernel、投影公式與 rank-two Schur 歸約成立。",
        "scope": "抽象連續 Hilbert/operator 模型。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C07",
        "origin": ["v0.6"],
        "status": "floating_reproduced",
        "evidence_class": "FLOATING_DIAGNOSTIC",
        "statement": "58 軸原子加 2 核原子的 fixed-measure direct Green threshold 約為 $1.1324412$；Galerkin 與 direct solver 在選定點相差約 $1.05\\times10^{-9}$。",
        "scope": "凍結 witness 的數值研究證據。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C08",
        "origin": ["v0.7"],
        "status": "interval_certified_abstract",
        "evidence_class": "INTERVAL_CERTIFIED_ABSTRACT",
        "statement": "在 $\\alpha=21/20$ 上，固定 60 正秩、2 負秩抽象 Green 算子嚴格正。",
        "scope": "Neumann defect upper $7.5314\\times10^{-15}$、第一主子式 lower $0.3524279$、determinant lower $0.0636153$。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C09",
        "origin": ["v0.7", "v0.8"],
        "status": "semantic_blocker_confirmed",
        "evidence_class": "EXACT_SEMANTIC",
        "statement": "v0.7 的五帶 positive coefficients 不能由 inherited upper-count profile 合法重解讀為 zero-side lower coefficients。",
        "scope": "抽象 operator 證書保留；zeta-facing 推論撤回。",
        "zeta_facing": True,
    },
    {
        "claim_id": "SYN-C10",
        "origin": ["v0.8"],
        "status": "proved",
        "evidence_class": "EXACT_SEMANTIC",
        "statement": "對非負函數，upper count 乘 band supremum 給 upper bound；lower count 乘 band infimum 給 lower bound。",
        "scope": "標量零點和的不等式方向。",
        "zeta_facing": True,
    },
    {
        "claim_id": "SYN-C11",
        "origin": ["v0.8", "v0.9"],
        "status": "universal_rule_refuted",
        "evidence_class": "EXACT_COUNTEREXAMPLE",
        "statement": "scalar lower count 不能普遍支配 arbitrary probability-measure average，也不能替代位置分離的 operator occupancy。",
        "scope": "exact two-point/rank-one countermodels。",
        "zeta_facing": True,
    },
    {
        "claim_id": "SYN-C12",
        "origin": ["v0.9"],
        "status": "proved_abstract_transfer",
        "evidence_class": "MODEL_THEOREM",
        "statement": "若每個 cell 有合法 occupancy，且所有 selected locations 的 operator family 皆 PSD，則加入 surplus PSD terms 後可轉移到 all-point operator。",
        "scope": "前提中的 occupancy source 尚未對實際 zeta 建立。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C13",
        "origin": ["v0.9"],
        "status": "interval_certified_synthetic",
        "evidence_class": "INTERVAL_CERTIFIED_SYNTHETIC",
        "statement": "兩-cell synthetic Dirichlet Green family 在 8-leaf adaptive cover 上全域嚴格正。",
        "scope": "synthetic axiom；非 zeta presence theorem。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C14",
        "origin": ["v0.9"],
        "status": "conditional_interval_parent",
        "evidence_class": "INTERVAL_CERTIFIED_ABSTRACT",
        "statement": "條件於 v0.7 parent，58 個獨立位置在每格半徑 $2\\times10^{-15}$ 內時，$\\alpha=1$ 的抽象 clamped operator 保持嚴格正。",
        "scope": "固定 parent atoms；無 actual zeta occupancy。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C15",
        "origin": ["v1.0"],
        "status": "interval_certified_abstract",
        "evidence_class": "INTERVAL_CERTIFIED_ABSTRACT",
        "statement": "對 58 個獨立位置變量，在統一半寬 $h=1.78\\times10^{-6}$ 的 closed product box 上，抽象 projected Green operator 嚴格正。",
        "scope": "Neumann defect $0.0275573<1$；第一主子式 lower $0.3305743$；determinant lower $6.69375\\times10^{-5}$。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C16",
        "origin": ["v1.0"],
        "status": "interval_certified_abstract",
        "evidence_class": "INTERVAL_CERTIFIED_ABSTRACT",
        "statement": "最大已證 product box 及其所有 coordinatewise contained rational closed subboxes 構成 downward-closed 證書族。",
        "scope": "已證半徑不宣稱為真實最大 positivity radius。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C17",
        "origin": ["v1.0"],
        "status": "failure_classified",
        "evidence_class": "INTERVAL_METHOD_AUDIT",
        "statement": "$1.8\\times10^{-6}$、$10^{-4}$、$10^{-3}$ 的 box 驗證失敗只是所用區間下界／候選逆失敗，不是 operator point counterexample。",
        "scope": "一個距中心 $10^{-3}$ 的 exact rational corner point 反而仍通過。",
        "zeta_facing": False,
    },
    {
        "claim_id": "SYN-C18",
        "origin": ["v0.1-v1.0"],
        "status": "explicit_nonclaim",
        "evidence_class": "TRUST_BOUNDARY",
        "statement": "本鏈沒有 actual zeta occupancy family、沒有完整 explicit-formula transfer、沒有 global RH certificate，也沒有 RH 證明或反證。",
        "scope": "全研究鏈。",
        "zeta_facing": True,
    },
]


GAPS = {
    "closed_or_resolved_as_no_go": [
        {
            "gap_id": "SYN-G01",
            "statement": "合成目標上的 adaptive finite cover 與多測試函數表示",
            "resolution": "v0.1 exact finite cover",
        },
        {
            "gap_id": "SYN-G02",
            "statement": "是否只靠 diagonal/full-Gram finite family 即可閉合全域預算",
            "resolution": "v0.1-v0.2 否決已測家族；不是 universal impossibility",
        },
        {
            "gap_id": "SYN-G03",
            "statement": "具名 $R=3$ finite model 是否被 dual gate 阻塞",
            "resolution": "v0.3 rational surrogate exact obstruction",
        },
        {
            "gap_id": "SYN-G04",
            "statement": "support-only 擴張與 coarse-grid escape 是否可靠",
            "resolution": "v0.4 前沿與 false-escape 審計",
        },
        {
            "gap_id": "SYN-G05",
            "statement": "齊次 notch 子空間能否改善 parent optimum",
            "resolution": "v0.5 exact monotonicity obstruction",
        },
        {
            "gap_id": "SYN-G06",
            "statement": "固定抽象連續 witness 的 interval positivity",
            "resolution": "v0.7 E3-A abstract certificate",
        },
        {
            "gap_id": "SYN-G07",
            "statement": "upper/lower count coefficient direction",
            "resolution": "v0.7-v0.8 semantic correction",
        },
        {
            "gap_id": "SYN-G08",
            "statement": "scalar count 是否可代替 arbitrary operator mass",
            "resolution": "v0.8-v0.9 exact counterexamples; universal rule refuted",
        },
        {
            "gap_id": "SYN-G09",
            "statement": "occupancy selection 到 all-point operator 的抽象轉移",
            "resolution": "v0.9 proved under explicit occupancy premises",
        },
    ],
    "partially_closed": [
        {
            "gap_id": "SYN-G10",
            "statement": "58 維 uncertain-location clamped Green family",
            "current_result": "v1.0 在 $h=1.78\\times10^{-6}$ 的抽象 product box 上完成 interval certificate",
            "remaining": "尚未接上任何合法的 zeta occupancy source",
        },
        {
            "gap_id": "SYN-G11",
            "statement": "區間依賴與尺度落差",
            "current_result": "相較 v0.9 半徑提升 $890000000$ 倍",
            "remaining": "rigorous $1.78\\times10^{-6}$ 與 floating transition $0.016$--$0.017$ 相差約四個數量級",
        },
    ],
    "open_blocking": [
        {
            "gap_id": "SYN-G12",
            "priority": "highest",
            "track": "conditional_zeta_occupancy",
            "statement": "從「若存在偏軸 zeta 零點」合法產生有理 cell、multiplicity、endpoint convention 與 selected-location quantifier 的條件式 occupancy theorem",
            "next_action": "不要尋找已知偏軸零點；建立 source-locked conditional contradiction interface。",
        },
        {
            "gap_id": "SYN-G13",
            "priority": "highest",
            "track": "zeta_coefficients",
            "statement": "五帶係數與 tail coefficient 的 theorem-backed directed intervals，以及正確 upper/lower orientation",
            "next_action": "逐一封裝來源定理、假設、端點、常數與 directed rounding。",
        },
        {
            "gap_id": "SYN-G14",
            "priority": "highest",
            "track": "explicit_formula",
            "statement": "clamped $H_0^2$ closure 到 zeta explicit-formula admissible test class 的 density、limit exchange、tail convergence 與 operator identity",
            "next_action": "先證 transfer theorem，再重用任何 numerical witness。",
        },
        {
            "gap_id": "SYN-G15",
            "priority": "high",
            "track": "prime_side",
            "statement": "同一合法 test-function family 的 prime-side nonnegative cone 或 validated arithmetic lower bound",
            "next_action": "只在 G12-G14 有可結合的介面後啟動大規模 prime enumeration。",
        },
        {
            "gap_id": "SYN-G16",
            "priority": "high",
            "track": "operator_scaling",
            "statement": "將 local interval box 從固定 58 atoms 推廣為高度／cell 參數化的 adaptive family",
            "next_action": "採 affine/Taylor matrix models 減少 dependency overestimation；不得把更大半徑本身當主成功指標。",
        },
        {
            "gap_id": "SYN-G17",
            "priority": "blocked",
            "track": "global_closure",
            "statement": "全部可能偏軸區域、無窮高度、零點尾與 local-to-global quantifier exhaustion",
            "next_action": "G12-G16 未閉合前不得宣稱此 gap 有實質進展。",
        },
        {
            "gap_id": "SYN-G18",
            "priority": "recommended",
            "track": "formal_audit",
            "statement": "對連續模型、interval engine 與 zeta transfer 的獨立外審或 proof-assistant kernel verification",
            "next_action": "至少對關鍵 Green/Schur 與語義轉移做第二實作交叉核驗。",
        },
    ],
}


FAILURE_MAP = [
    {
        "stage": "prehistory_to_v0.1",
        "failed_assumption": "單一局部負窗與單一算術正純量足以逼近顯式公式矛盾。",
        "evidence": "已知軸上 leakage 遠大於局部負裕量。",
        "correction": "改用分帶、多測試函數、全域預算與覆蓋證書族。",
    },
    {
        "stage": "v0.1_to_v0.2",
        "failed_assumption": "對角非負 cone 的候選多樣性足以改善全域 budget。",
        "evidence": "72 candidates 的 partial global gap 全負。",
        "correction": "引入完整 PSD Gram cross terms。",
    },
    {
        "stage": "v0.2_to_v0.3",
        "failed_assumption": "增加 factor rank 會帶來有效高秩改良。",
        "evidence": "requested ranks $1,2,4,8$ 的 selected factors 全部數值秩 1；預算仍負。",
        "correction": "轉為 dual lower bound，先判斷函數類是否值得繼續。",
    },
    {
        "stage": "v0.3_to_v0.4",
        "failed_assumption": "目前 $R=3$ patchwise family 尚可由 primal tuning 挽救。",
        "evidence": "18 個 rational surrogate exact LDL 均支持 dual obstruction。",
        "correction": "淘汰具名 finite family，量化 support-prime frontier。",
    },
    {
        "stage": "v0.4_to_v0.5",
        "failed_assumption": "只增加支撐或依賴 coarse axis grid 可找到真 escape。",
        "evidence": "refinement 把 raw $0.9853$ 提升到 $1.1923$；prime cutoff 快速爆炸。",
        "correction": "設計 notch 與 geometry，但加入 dense-grid gate。",
    },
    {
        "stage": "v0.5_to_v0.6",
        "failed_assumption": "齊次 notch、已測 external lift 或 polynomial density scaling 會穿過 threshold。",
        "evidence": "subspace monotonicity theorem；最佳 safe threshold 仍 $1.0717612$。",
        "correction": "改寫為連續 $H_0^2$ extremal 與 Green-kernel dual。",
    },
    {
        "stage": "v0.6_to_v0.7",
        "failed_assumption": "更大字典／更高 Galerkin 維度仍是主瓶頸。",
        "evidence": "independent Galerkin/direct Green 在 selected point 相差約 $10^{-9}$，且 rational witness 有足夠 floating margin。",
        "correction": "凍結 witness，投入 directed interval certificate。",
    },
    {
        "stage": "v0.7_to_v0.8",
        "failed_assumption": "抽象 interval positivity 可直接沿用 inherited band coefficients 成為 zeta zero-side obstruction。",
        "evidence": "五帶係數對應 upper profile，不是所需 lower coefficient；lower-profile stress 失敗。",
        "correction": "嚴格區分抽象證書與 zeta-facing coefficient legitimacy。",
    },
    {
        "stage": "v0.8_to_v0.9",
        "failed_assumption": "scalar lower count 可重型別為 arbitrary operator distribution。",
        "evidence": "exact two-point、rank-one range-intersection 與 count-only Schur counterexamples。",
        "correction": "以 cell occupancy、位置全稱量詞與 PSD surplus 建立合法 transfer。",
    },
    {
        "stage": "v0.9_to_v1.0",
        "failed_assumption": "固定原子的小擾動只能得到 $2\\times10^{-15}$ 等級半徑。",
        "evidence": "位置感知區間 Green pairing 將證書半徑提升至 $1.78\\times10^{-6}$。",
        "correction": "建立 affine-tagged local Green engine 與 downward-closed cover family。",
    },
    {
        "stage": "post_v1.0",
        "failed_assumption": "繼續放大抽象盒半徑是下一階段主 GAP。",
        "evidence": "actual zeta occupancy、coefficient transfer、explicit-formula admissibility 全仍為 false。",
        "correction": "下一節點先做 conditional off-axis cell 與 zeta transfer；局部 radius 僅為從屬工程。",
    },
]


PREHISTORY = [
    {
        "path": "upload/從歸心到等變拓樸_RH合法判定研究的思考方法與方法群_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "合法判定、方法分工與 ZFC 可審計原則",
    },
    {
        "path": "upload/歸心後的等變拓樸判定域_RH除子固定點與繞數障礙重構_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "歸心、等變母空間、除子與繞數障礙",
    },
    {
        "path": "upload/等變零點組態拓樸學_RH軌道型分層有效除子半環與正障礙_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "軌道型、有效除子與正障礙語義",
    },
    {
        "path": "upload/層化零點障礙與局部全域提升_從有理矩形證書到全臨界帶判定_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "有理矩形局部證書與 local-to-global 判定架構",
    },
    {
        "path": "upload/等變算術分離_從軌道空間局部化到Zeta顯式公式可容許測試函數_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "拓樸分離到顯式公式可容許測試函數",
    },
    {
        "path": "upload/顯式公式中的偏軸正障礙_零點側區域負方向質數側可計算錐與ZFC矛盾架構_v0.1_內部稿(1).md",
        "kind": "theory_manuscript",
        "role": "零點側負方向、prime-side cone 與條件式矛盾架構",
    },
    {
        "path": "upload/RH_Regional_Phase_Shaping_v0.1(1).zip",
        "kind": "engineering_archive",
        "role": "區域相位塑形原型",
    },
    {
        "path": "upload/RH_Arithmetic_Matrix_PSD_v0.1(1).zip",
        "kind": "engineering_archive",
        "role": "算術矩陣／PSD 原型",
    },
    {
        "path": "upload/RH_Separation_Positivity_Intersection_v0.1(1).zip",
        "kind": "engineering_archive",
        "role": "分離—正性交集原型",
    },
    {
        "path": "upload/RH_Validated_Intersection_Certificate_v0.2(1).zip",
        "kind": "engineering_archive",
        "role": "單一函數驗證數值交集證書",
    },
    {
        "path": "upload/RH_Zero_Side_Leakage_Budget_v0.1(1).zip",
        "kind": "engineering_archive",
        "role": "零點側 leakage budget 與反向否決",
    },
    {
        "path": "upload/RH_Axis_Suppressed_Global_Window_Optimizer_v0.1(1).zip",
        "kind": "engineering_archive",
        "role": "軸抑制與 arithmetic-positive dimension trade-off",
    },
    {
        "path": "RH_Equivariant_Arithmetic_Obstruction_Integration_v1.0.zip",
        "kind": "integration_archive",
        "role": "前史六稿六包的整合與 CASE-0001 審計",
    },
]


HANDOFF = {
    "schema": "EveMissLab.RH.FinalAIHandoff.v1.0",
    "case_id": "CASE-0003-RH-FINAL-SYNTHESIS-20260725",
    "research_mode": "semi-autonomous AI mathematical research",
    "current_state": "v0.1-v1.0 technical chain complete; final synthesis complete",
    "hard_flags": {
        "rh_proved": False,
        "rh_disproved": False,
        "actual_zeta_occupancy_family": False,
        "zeta_facing_count_and_tail_coefficients_certified": False,
        "explicit_formula_transfer_certified": False,
        "global_rh_certificate": False,
        "v0_7_abstract_continuous_interval_certificate": True,
        "v1_0_abstract_58_location_cover_certificate": True,
    },
    "entry_order": [
        "README.md",
        "RH半AI自主研究完整報告_v0.1-v1.0_與後續AI交接_v1.0.md",
        "AI_HANDOFF.md",
        "metadata/ai-handoff.json",
        "metadata/claim-register.json",
        "metadata/gap-ledger.json",
        "metadata/failure-correction-map.json",
        "validation/source-archive-audit.json",
    ],
    "recommended_next_node": {
        "node_id": "RH-ConditionalOffAxisCell-ZetaTransfer-2026Q3-v1.1",
        "title": "Conditional off-axis cell occupancy and zeta-facing transfer",
        "primary_question": "Can a hypothetical off-axis zeta zero be mapped, without using an actual off-axis zero table, to a source-locked rational occupancy cell and then to a legally oriented explicit-formula operator inequality?",
        "why_first": "The present bottleneck is semantic/analytic transfer, not local interval radius.",
    },
    "work_packages": [
        {
            "id": "WP11-SOURCE-LOCK",
            "priority": 1,
            "task": "Freeze exact source theorems and hypotheses for zero counting, argument principle/Turing semantics, tail bounds, and the explicit formula.",
            "deliverable": "source registry with theorem statements, ranges, endpoint conventions, hashes, and no inferred constants",
        },
        {
            "id": "WP11-CONDITIONAL-OCC",
            "priority": 2,
            "task": "Prove a conditional occupancy interface: if an off-axis zero exists, isolate a rational cell with explicit multiplicity and boundary conventions and retain its location as a quantified variable.",
            "deliverable": "machine-readable theorem schema plus exact semantic tests and countermodels",
        },
        {
            "id": "WP11-EF-TRANSFER",
            "priority": 3,
            "task": "Prove admissibility and the correct coefficient orientation for the same clamped test-function family.",
            "deliverable": "directed coefficient intervals and a theorem-backed zero-side/prime-side identity",
        },
        {
            "id": "WP11-OPERATOR-BRIDGE",
            "priority": 4,
            "task": "Compose conditional cells with interval Green-Schur covers; re-optimize only if the legally oriented coefficients invalidate the frozen witness.",
            "deliverable": "one parameterized conditional cell certificate or a formal robust-failure record",
        },
        {
            "id": "WP11-UPPER-NOGO",
            "priority": 5,
            "task": "Separately source-certify the upper-envelope route to decide whether it is a theorem-level no-go.",
            "deliverable": "do not merge this result with actual occupancy",
        },
    ],
    "success_gates": [
        "Every zeta-facing coefficient has a source theorem, legal direction, validity range, endpoint convention, and directed interval.",
        "The occupancy theorem is conditional on a hypothetical off-axis zero and does not pretend that the synthetic 58 centers are actual zeta zeros.",
        "The same admissible test-function object appears on zero and prime sides.",
        "Any universal location claim is proved by interval cover or a formal theorem, never by a sampled grid.",
        "A failed interval bound is labeled inconclusive unless an exact or interval point counterexample is supplied.",
        "All six hard false flags remain false unless a new artifact explicitly closes them.",
    ],
    "stop_rules": [
        "Do not spend another major round only enlarging the $1.78\\times10^{-6}$ box.",
        "Do not optimize at the height-20.4 prototype as though it were an unresolved off-axis zeta target.",
        "Do not convert scalar counts into arbitrary operator measures.",
        "Do not use known zero ordinates as optimization equalities or as evidence of off-axis occupancy.",
        "Do not start large prime enumeration before the support, admissibility, and coefficient directions are frozen.",
        "Do not infer universal impossibility from a finite dictionary, finite support sweep, nonconvex local optimum, or failed interval enclosure.",
        "Do not claim RH proof, RH disproof, or a global certificate without a checked local-to-global dependency graph.",
    ],
    "minimum_replay": [
        "python3 validate_release.py",
        "Verify the ten canonical source ZIP SHA-256 values against metadata/artifact-index.json.",
        "Inspect validation/source-archive-audit.json and require ten manifest passes.",
        "Read the canonical claim/gap/handoff snapshots before changing any status.",
    ],
}


SNAPSHOT_SUFFIXES = {
    "0.1": [
        "case-manifest.json",
        "outputs/experiment_summary.json",
        "metadata/claim_ledger.json",
        "metadata/gap_update.json",
        "metadata/handoff.json",
        "TRUST_BOUNDARY.md",
        "RESULTS.md",
        "validation/validation_report.json",
    ],
    "default": [
        "outputs/experiment_summary.json",
        "metadata/research_node.json",
        "metadata/claim_register.json",
        "metadata/gap_ledger.json",
        "metadata/handoff.json",
        "metadata/dependency_graph.json",
        "TRUST_BOUNDARY.md",
        "RESULTS.md",
        "metadata/validation_report.json",
    ],
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(relative: str, obj: object) -> None:
    path = PACKAGE / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def locate_member(names: list[str], suffix: str) -> str | None:
    hits = [
        name
        for name in names
        if name == suffix or name.endswith("/" + suffix)
    ]
    if not hits:
        return None
    return min(hits, key=len)


def audit_archive(archive: Path) -> dict:
    result = {
        "archive": archive.name,
        "sha256": sha256_file(archive),
        "size_bytes": archive.stat().st_size,
        "zip_crc_test": False,
        "manifest_present": False,
        "manifest_entries": 0,
        "manifest_pass": False,
        "failures": [],
    }
    with zipfile.ZipFile(archive) as zf:
        bad = zf.testzip()
        result["zip_crc_test"] = bad is None
        if bad is not None:
            result["failures"].append({"kind": "zip_crc", "member": bad})
        names = zf.namelist()
        manifest_member = locate_member(names, "MANIFEST.sha256")
        if manifest_member is None:
            result["failures"].append({"kind": "manifest_missing"})
            return result
        result["manifest_present"] = True
        base = PurePosixPath(manifest_member).parent
        text = zf.read(manifest_member).decode("utf-8")
        entries = []
        for line in text.splitlines():
            if not line.strip():
                continue
            digest, rel = line.split(maxsplit=1)
            rel = rel.lstrip(" *")
            entries.append((digest, rel))
        result["manifest_entries"] = len(entries)
        for expected, rel in entries:
            candidate = str(base / PurePosixPath(rel))
            if candidate.startswith("./"):
                candidate = candidate[2:]
            try:
                data = zf.read(candidate)
            except KeyError:
                result["failures"].append(
                    {"kind": "manifest_member_missing", "member": candidate}
                )
                continue
            actual = sha256_bytes(data)
            if actual != expected:
                result["failures"].append(
                    {
                        "kind": "manifest_hash_mismatch",
                        "member": candidate,
                        "expected": expected,
                        "actual": actual,
                    }
                )
        result["manifest_pass"] = not result["failures"]
    return result


def extract_snapshots(node: dict) -> list[dict]:
    archive = WORKSPACE / node["archive"]
    version = node["version"]
    out_root = PACKAGE / "evidence_snapshots" / ("v" + version)
    if out_root.exists():
        shutil.rmtree(out_root)
    out_root.mkdir(parents=True, exist_ok=True)
    records = []
    suffixes = SNAPSHOT_SUFFIXES.get(version, SNAPSHOT_SUFFIXES["default"])
    with zipfile.ZipFile(archive) as zf:
        names = zf.namelist()
        for suffix in suffixes:
            member = locate_member(names, suffix)
            if member is None:
                continue
            data = zf.read(member)
            destination = out_root / suffix
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(data)
            records.append(
                {
                    "version": version,
                    "source_archive": archive.name,
                    "source_member": member,
                    "snapshot_path": str(destination.relative_to(PACKAGE)),
                    "sha256": sha256_bytes(data),
                    "size_bytes": len(data),
                }
            )
    return records


def main() -> None:
    for folder in ("metadata", "validation", "evidence_snapshots"):
        (PACKAGE / folder).mkdir(parents=True, exist_ok=True)

    archive_audits = []
    snapshot_records = []
    artifact_index = []
    for node in NODES:
        archive = WORKSPACE / node["archive"]
        if not archive.is_file():
            raise FileNotFoundError(archive)
        audit = audit_archive(archive)
        archive_audits.append(audit)
        artifact_index.append(
            {
                "kind": "canonical_source_archive",
                "version": node["version"],
                "node_id": node["node_id"],
                "filename": archive.name,
                "sha256": audit["sha256"],
                "size_bytes": audit["size_bytes"],
                "zip_crc_test": audit["zip_crc_test"],
                "internal_manifest_pass": audit["manifest_pass"],
                "included_in_synthesis_zip": False,
            }
        )
        snapshot_records.extend(extract_snapshots(node))

    source_corpus = []
    for item in PREHISTORY:
        source = WORKSPACE / item["path"]
        if not source.is_file():
            raise FileNotFoundError(source)
        source_corpus.append(
            {
                **item,
                "filename": source.name,
                "sha256": sha256_file(source),
                "size_bytes": source.stat().st_size,
                "evidentiary_role": "prehistory_or_method_source_not_main_chain_certificate",
            }
        )

    dependency_nodes = [
        {
            "id": node["node_id"],
            "kind": "completed_research_node",
            "version": node["version"],
            "global_rh_certificate": False,
        }
        for node in NODES
    ]
    dependency_nodes.extend(
        [
            {"id": "FUTURE-CONDITIONAL-OCC", "kind": "open_gate"},
            {"id": "FUTURE-EF-TRANSFER", "kind": "open_gate"},
            {"id": "FUTURE-PRIME-CONE", "kind": "open_gate"},
            {"id": "FUTURE-COMPOSED-CELL", "kind": "blocked_gate"},
            {"id": "FUTURE-GLOBAL-EXHAUSTION", "kind": "blocked_gate"},
        ]
    )
    dependency_edges = [
        {
            "from": NODES[index]["node_id"],
            "to": NODES[index + 1]["node_id"],
            "relation": "research_pivot_or_dependency",
        }
        for index in range(len(NODES) - 1)
    ]
    dependency_edges.extend(
        [
            {
                "from": NODES[-1]["node_id"],
                "to": "FUTURE-CONDITIONAL-OCC",
                "relation": "requires actual conditional zeta semantics",
            },
            {
                "from": NODES[6]["node_id"],
                "to": "FUTURE-EF-TRANSFER",
                "relation": "abstract witness requires zeta-facing admissibility and coefficient direction",
            },
            {
                "from": "FUTURE-EF-TRANSFER",
                "to": "FUTURE-PRIME-CONE",
                "relation": "freezes the legal test-function and support before arithmetic enumeration",
            },
            {
                "from": "FUTURE-CONDITIONAL-OCC",
                "to": "FUTURE-COMPOSED-CELL",
                "relation": "supplies legal occupancy premises",
            },
            {
                "from": "FUTURE-EF-TRANSFER",
                "to": "FUTURE-COMPOSED-CELL",
                "relation": "supplies legal operator coefficients",
            },
            {
                "from": "FUTURE-PRIME-CONE",
                "to": "FUTURE-COMPOSED-CELL",
                "relation": "supplies arithmetic side of contradiction",
            },
            {
                "from": "FUTURE-COMPOSED-CELL",
                "to": "FUTURE-GLOBAL-EXHAUSTION",
                "relation": "one parameterized cell family must precede all-height exhaustion",
            },
        ]
    )

    case_manifest = {
        "schema": "EveMissLab.RH.FinalSynthesisCaseManifest.v1.0",
        "case_id": "CASE-0003-RH-FINAL-SYNTHESIS-20260725",
        "title": "RH v0.1-v1.0 Complete Research Report and Downstream AI Handoff",
        "date": "2026-07-25",
        "timezone": "Asia/Taipei",
        "research_mode": "semi-autonomous AI mathematical research",
        "main_chain_node_count": len(NODES),
        "canonical_source_archive_count": len(artifact_index),
        "canonical_snapshot_count": len(snapshot_records),
        "prehistory_source_count": len(source_corpus),
        "main_report": "RH半AI自主研究完整報告_v0.1-v1.0_與後續AI交接_v1.0.md",
        "human_handoff": "AI_HANDOFF.md",
        "machine_handoff": "metadata/ai-handoff.json",
        "status": "final_synthesis_complete",
        "hard_flags": HANDOFF["hard_flags"],
    }

    write_json("metadata/case-manifest.json", case_manifest)
    write_json("metadata/timeline.json", {"schema": "RH.Timeline.v1.0", "nodes": NODES})
    write_json(
        "metadata/dependency-graph.json",
        {
            "schema": "RH.UnifiedDependencyGraph.v1.0",
            "nodes": dependency_nodes,
            "edges": dependency_edges,
            "global_rh_certificate": False,
        },
    )
    write_json(
        "metadata/claim-register.json",
        {
            "schema": "RH.UnifiedClaimRegister.v1.0",
            "normalization": {
                "EXACT_FINITE": "exact algebra/rational finite-model result",
                "MODEL_THEOREM": "proved in an explicitly defined abstract analytic/operator model",
                "REPLAY_STRUCTURAL": "machine-recomputed structure or reconstruction check",
                "FLOATING_DIAGNOSTIC": "reproducible numerical research evidence without directed enclosure",
                "INTERVAL_CERTIFIED_SYNTHETIC": "directed interval theorem under synthetic premises",
                "INTERVAL_CERTIFIED_ABSTRACT": "directed interval theorem inside the abstract Green/operator model",
                "EXACT_SEMANTIC": "exact theorem about legal coefficient/quantifier semantics",
                "EXACT_COUNTEREXAMPLE": "exact counterexample to a proposed universal transfer",
                "TRUST_BOUNDARY": "explicit nonclaim or dependency boundary",
                "ZETA_TRANSFER": "theorem-backed transfer to actual zeta; no positive claim in this chain",
            },
            "claims": SYNTHESIS_CLAIMS,
            "raw_canonical_registers": [
                record["snapshot_path"]
                for record in snapshot_records
                if "claim_" in Path(record["snapshot_path"]).name
                or Path(record["snapshot_path"]).name == "claim_register.json"
            ],
            "global_rh_certificate": False,
        },
    )
    write_json(
        "metadata/gap-ledger.json",
        {
            "schema": "RH.UnifiedGapLedger.v1.0",
            **GAPS,
            "actual_zeta_occupancy_family": False,
            "explicit_formula_transfer_certified": False,
            "global_rh_certificate": False,
        },
    )
    write_json(
        "metadata/failure-correction-map.json",
        {
            "schema": "RH.FailureCorrectionMap.v1.0",
            "entries": FAILURE_MAP,
            "interpretation": "A failure closes only the stated family or inference; it is not silently promoted to a theorem about all admissible test functions.",
        },
    )
    write_json(
        "metadata/artifact-index.json",
        {
            "schema": "RH.ArtifactIndex.v1.0",
            "canonical_source_archives": artifact_index,
            "snapshot_policy": "Canonical snapshots are extracted byte-for-byte from source ZIP archives; full source archives are indexed by hash but not duplicated inside the synthesis ZIP.",
        },
    )
    write_json(
        "metadata/source-corpus.json",
        {
            "schema": "RH.SourceCorpus.v1.0",
            "scope_rule": "These files are prehistory or method sources. They are not counted among the ten v0.1-v1.0 certificate nodes.",
            "items": source_corpus,
        },
    )
    write_json("metadata/ai-handoff.json", HANDOFF)
    write_json(
        "validation/source-archive-audit.json",
        {
            "schema": "RH.SourceArchiveAudit.v1.0",
            "canonical_policy": "The ZIP archives, not mutable extracted working trees, are canonical.",
            "archive_count": len(archive_audits),
            "all_zip_crc_pass": all(x["zip_crc_test"] for x in archive_audits),
            "all_internal_manifests_pass": all(
                x["manifest_pass"] for x in archive_audits
            ),
            "archives": archive_audits,
            "working_tree_note": "A local extracted v0.2 outputs/gram_results.json was found truncated during synthesis. Its canonical v0.2 ZIP is intact and passes the internal manifest, so snapshots and claims use the ZIP copy.",
        },
    )
    write_json(
        "validation/evidence-snapshot-index.json",
        {
            "schema": "RH.EvidenceSnapshotIndex.v1.0",
            "records": snapshot_records,
        },
    )

    print(
        json.dumps(
            {
                "status": "ok",
                "nodes": len(NODES),
                "archives": len(archive_audits),
                "snapshots": len(snapshot_records),
                "prehistory_sources": len(source_corpus),
                "all_internal_manifests_pass": all(
                    x["manifest_pass"] for x in archive_audits
                ),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
