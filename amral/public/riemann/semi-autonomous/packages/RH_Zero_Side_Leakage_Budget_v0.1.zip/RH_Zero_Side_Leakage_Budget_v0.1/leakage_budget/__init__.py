from .model import HatSpline
