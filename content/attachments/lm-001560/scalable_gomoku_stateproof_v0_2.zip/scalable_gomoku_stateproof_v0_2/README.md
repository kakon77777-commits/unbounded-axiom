# Scalable Gomoku State-Proof v0.2

這是一個研究自訂 $n\times n$、連 $k$ 棋類的低複雜度精確證明框架。

v0.2 在 v0.1 的完整 Negamax 狀態機上新增：

- 威脅超圖；
- 最小防守擊中集；
- 即時勝點與雙威脅偵測；
- Tactical Proof-Number Search；
- $D_4$ 對稱軌道覆蓋；
- 可獨立驗證的 PNS 必勝證書；
- 首手對稱軌道批次分析；
- JSON、CSV、Markdown 實驗輸出。

## 核心命題

對攻方即時威脅族 $\mathcal T(s)$，若輪到守方且：

$$
\tau(\mathcal T(s))>1
$$

同時守方沒有立即反勝，則守方一手不能覆蓋全部威脅。

## 快速執行

```bash
python pns.py --size 4 --k 3 \
  --max-nodes 10000 --max-seconds 5 \
  --certificate-out results/4x4_k3_pns_certificate.json

python opening_analysis.py --size 4 --k 3 \
  --json-out results/4x4_k3_openings.json \
  --csv-out results/4x4_k3_openings.csv \
  --md-out results/4x4_k3_openings.md

python -m unittest discover -s tests -v
```

## v0.2 已驗證結果

- $3\times3$ 連三：黑方不能強制獲勝；
- $4\times4$ 連三：黑方可強制獲勝；
- $4\times4$ 連三的三個首手對稱軌道均可必勝；
- 內部四點在目前 PNS 排序與剪枝下，需要的證明節點最少；
- $4\times4$ 連四在有限節點預算內仍未求解，成為下一個壓力測試。

## 檔案

- `solver.py`：v0.1 完整 Negamax；
- `threats.py`：威脅超圖與擊中集；
- `pns.py`：戰術 Proof-Number Search 與證書驗證；
- `opening_analysis.py`：首手軌道比較；
- `certificate.py`：v0.1 小棋盤完整 AND–OR 證書；
- `docs/methodology.md`：基礎尺度方法；
- `docs/v0_2_theory.md`：v0.2 理論與下一步；
- `results/`：可重現實驗結果。

## 嚴格限制

目前的 PNS 節點數依賴：

- 動作排序；
- 戰術剪枝；
- 對稱壓縮；
- 節點與時間預算。

所以它是證明效率測量，不是已證明的遊戲不變量。
