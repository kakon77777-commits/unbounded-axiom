import unittest

from solver import (
    BLACK,
    EMPTY,
    Rules,
    ExactSolver,
    apply_move,
    canonical_board,
    idx,
    is_winning_move,
    line_degree,
    transform_board,
)


class SolverTests(unittest.TestCase):
    def test_immediate_horizontal_win(self):
        rules = Rules(3, 3)
        board = (
            BLACK, BLACK, EMPTY,
            EMPTY, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY,
        )
        child = apply_move(board, 2, BLACK)
        self.assertTrue(is_winning_move(child, rules, 2, BLACK))

    def test_symmetry_canonical(self):
        board = (
            BLACK, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY,
        )
        canon = canonical_board(board, 3)
        for t in range(8):
            self.assertEqual(canon, canonical_board(transform_board(board, 3, t), 3))

    def test_tic_tac_toe_draw(self):
        result = ExactSolver(Rules(3, 3)).solve()
        self.assertEqual(result.value, 0)

    def test_2x2_connect2_first_player_win(self):
        result = ExactSolver(Rules(2, 2)).solve()
        self.assertEqual(result.value, 1)

    def test_center_has_max_degree(self):
        rules = Rules(3, 3)
        degree = line_degree(rules)
        self.assertEqual(degree[idx(3, 1, 1)], max(degree))


if __name__ == "__main__":
    unittest.main()
