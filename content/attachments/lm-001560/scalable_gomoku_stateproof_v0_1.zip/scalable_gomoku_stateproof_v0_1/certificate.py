from __future__ import annotations

from typing import Any, Optional
import argparse
import json

from solver import (
    BLACK,
    WHITE,
    EMPTY,
    Rules,
    ExactSolver,
    apply_move,
    board_full,
    board_to_rows,
    is_winning_move,
    legal_moves,
    other,
    rc,
)


def build_certificate(
    solver: ExactSolver,
    board: tuple[int, ...],
    player: int,
    root_player: int,
    max_nodes: int = 100000,
) -> dict[str, Any]:
    counter = {"nodes": 0}

    def rec(state: tuple[int, ...], turn: int, last_move: Optional[int], last_player: Optional[int]):
        counter["nodes"] += 1
        if counter["nodes"] > max_nodes:
            raise RuntimeError(f"certificate exceeded max_nodes={max_nodes}")

        if last_move is not None and last_player is not None:
            if is_winning_move(state, solver.rules, last_move, last_player):
                return {
                    "type": "terminal",
                    "winner": "black" if last_player == BLACK else "white",
                    "board": board_to_rows(state, solver.rules.size),
                }

        if board_full(state):
            return {
                "type": "terminal",
                "winner": "draw",
                "board": board_to_rows(state, solver.rules.size),
            }

        node = {
            "type": "OR" if turn == root_player else "AND",
            "turn": "black" if turn == BLACK else "white",
            "board": board_to_rows(state, solver.rules.size),
            "children": [],
        }

        moves = legal_moves(state)
        if turn == root_player:
            best = solver.best_moves(state, turn)
            if not best:
                raise RuntimeError("no chosen winning move")
            moves = [best[0]]

        for move in moves:
            child = apply_move(state, move, turn)
            node["children"].append({
                "move": {
                    "index": move,
                    "row": rc(solver.rules.size, move)[0],
                    "col": rc(solver.rules.size, move)[1],
                },
                "node": rec(child, other(turn), move, turn),
            })
        return node

    tree = rec(board, player, None, None)
    return {
        "format": "connect-k-and-or-certificate-v1",
        "rules": {
            "size": solver.rules.size,
            "k": solver.rules.k,
            "win_mode": solver.rules.win_mode,
        },
        "root_player": "black" if root_player == BLACK else "white",
        "node_count": counter["nodes"],
        "tree": tree,
    }


def verify_certificate(cert: dict[str, Any]) -> tuple[bool, str]:
    data = cert["rules"]
    rules = Rules(data["size"], data["k"], data["win_mode"])
    root_player = BLACK if cert["root_player"] == "black" else WHITE
    symbol = {".": EMPTY, "X": BLACK, "O": WHITE}

    def rows_to_board(rows: list[str]) -> tuple[int, ...]:
        return tuple(symbol[ch] for row in rows for ch in row)

    def rec(node: dict[str, Any], expected_board: Optional[tuple[int, ...]] = None):
        board = rows_to_board(node["board"])
        if expected_board is not None and board != expected_board:
            return False, "board transition mismatch", None

        if node["type"] == "terminal":
            winner_name = node["winner"]
            if winner_name == "draw":
                if not board_full(board):
                    return False, "non-full draw terminal", None
                return True, "ok", 0
            winner = BLACK if winner_name == "black" else WHITE
            found = any(
                board[i] == winner and is_winning_move(board, rules, i, winner)
                for i in range(len(board))
            )
            if not found:
                return False, "terminal has no winning line", None
            return True, "ok", winner

        turn = BLACK if node["turn"] == "black" else WHITE
        children = node.get("children", [])
        legal = set(legal_moves(board))

        if node["type"] == "OR":
            if turn != root_player or len(children) != 1:
                return False, "invalid OR node", None
        elif node["type"] == "AND":
            if turn == root_player:
                return False, "invalid AND owner", None
            if {c["move"]["index"] for c in children} != legal:
                return False, "AND node misses legal replies", None
        else:
            return False, "unknown node type", None

        for child in children:
            move = child["move"]["index"]
            if move not in legal:
                return False, "illegal move", None
            next_board = apply_move(board, move, turn)
            ok, msg, winner = rec(child["node"], next_board)
            if not ok:
                return False, msg, None
            if winner not in {root_player, 0}:
                return False, "opponent wins a covered branch", None

        return True, "ok", root_player

    ok, msg, _ = rec(cert["tree"])
    return ok, msg


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    build = sub.add_parser("build")
    build.add_argument("--size", type=int, required=True)
    build.add_argument("--k", type=int, required=True)
    build.add_argument("--win-mode", choices=["at_least", "exact"], default="at_least")
    build.add_argument("--out", required=True)
    build.add_argument("--max-nodes", type=int, default=100000)

    verify = sub.add_parser("verify")
    verify.add_argument("certificate")

    args = parser.parse_args()

    if args.command == "build":
        rules = Rules(args.size, args.k, args.win_mode)
        board = (EMPTY,) * (rules.size * rules.size)
        solver = ExactSolver(rules)
        result = solver.solve(board, BLACK)
        if result.value != 1:
            raise SystemExit("root is not a proven first-player win")
        cert = build_certificate(solver, board, BLACK, BLACK, args.max_nodes)
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(cert, f, ensure_ascii=False, indent=2)
        ok, msg = verify_certificate(cert)
        print(json.dumps({
            "out": args.out,
            "node_count": cert["node_count"],
            "verified": ok,
            "message": msg,
        }, ensure_ascii=False, indent=2))
        if not ok:
            raise SystemExit(1)
    else:
        with open(args.certificate, "r", encoding="utf-8") as f:
            cert = json.load(f)
        ok, msg = verify_certificate(cert)
        print(json.dumps({"ok": ok, "message": msg}, ensure_ascii=False, indent=2))
        if not ok:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
