from __future__ import annotations

import argparse
import json
from pathlib import Path

from solver import BLACK, EMPTY, Rules, ExactSolver, line_degree, rc


DEFAULT_CASES = [
    {"size": 1, "k": 1, "win_mode": "at_least"},
    {"size": 2, "k": 2, "win_mode": "at_least"},
    {"size": 3, "k": 2, "win_mode": "at_least"},
    {"size": 3, "k": 3, "win_mode": "at_least"},
]


def run_case(case: dict) -> dict:
    rules = Rules(case["size"], case["k"], case.get("win_mode", "at_least"))
    board = (EMPTY,) * (rules.size * rules.size)
    solver = ExactSolver(rules)
    result = solver.solve(board, BLACK)
    best = solver.best_moves(board, BLACK)
    degree = line_degree(rules)
    return {
        **case,
        "value_black_to_move": result.value,
        "distance_plies": result.distance,
        "expanded_nodes": result.nodes,
        "cache_entries": len(solver._cache),
        "elapsed_sec": result.elapsed_sec,
        "best_moves": [
            {
                "index": m,
                "row": rc(rules.size, m)[0],
                "col": rc(rules.size, m)[1],
                "line_degree": degree[m],
            }
            for m in best
        ],
        "max_line_degree": max(degree),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config")
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    cases = (
        json.loads(Path(args.config).read_text(encoding="utf-8"))
        if args.config else DEFAULT_CASES
    )
    results = [run_case(case) for case in cases]
    Path(args.out).write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
