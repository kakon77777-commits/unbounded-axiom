from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
import argparse
import json
import time

EMPTY = 0
BLACK = 1
WHITE = -1


@dataclass(frozen=True)
class Rules:
    size: int
    k: int
    win_mode: str = "at_least"

    def __post_init__(self) -> None:
        if self.size < 1:
            raise ValueError("size must be >= 1")
        if self.k < 1 or self.k > self.size:
            raise ValueError("k must satisfy 1 <= k <= size")
        if self.win_mode not in {"at_least", "exact"}:
            raise ValueError("win_mode must be 'at_least' or 'exact'")


@dataclass(frozen=True)
class SolveResult:
    value: int
    distance: int
    nodes: int
    elapsed_sec: float


def other(player: int) -> int:
    return -player


def idx(size: int, row: int, col: int) -> int:
    return row * size + col


def rc(size: int, index: int) -> tuple[int, int]:
    return divmod(index, size)


def legal_moves(board: tuple[int, ...]) -> list[int]:
    return [i for i, v in enumerate(board) if v == EMPTY]


def apply_move(board: tuple[int, ...], move: int, player: int) -> tuple[int, ...]:
    if move < 0 or move >= len(board):
        raise ValueError("move out of range")
    if board[move] != EMPTY:
        raise ValueError("cell is occupied")
    out = list(board)
    out[move] = player
    return tuple(out)


def board_full(board: tuple[int, ...]) -> bool:
    return EMPTY not in board


def run_length_through(
    board: tuple[int, ...],
    rules: Rules,
    move: int,
    player: int,
    dr: int,
    dc: int,
) -> int:
    n = rules.size
    r0, c0 = rc(n, move)
    total = 1

    r, c = r0 + dr, c0 + dc
    while 0 <= r < n and 0 <= c < n and board[idx(n, r, c)] == player:
        total += 1
        r += dr
        c += dc

    r, c = r0 - dr, c0 - dc
    while 0 <= r < n and 0 <= c < n and board[idx(n, r, c)] == player:
        total += 1
        r -= dr
        c -= dc

    return total


def is_winning_move(
    board_after_move: tuple[int, ...],
    rules: Rules,
    move: int,
    player: int,
) -> bool:
    for dr, dc in ((1, 0), (0, 1), (1, 1), (1, -1)):
        length = run_length_through(board_after_move, rules, move, player, dr, dc)
        if rules.win_mode == "at_least" and length >= rules.k:
            return True
        if rules.win_mode == "exact" and length == rules.k:
            return True
    return False


def transform_index(size: int, index: int, transform: int) -> int:
    r, c = rc(size, index)
    n = size - 1
    if transform == 0:
        rr, cc = r, c
    elif transform == 1:
        rr, cc = c, n - r
    elif transform == 2:
        rr, cc = n - r, n - c
    elif transform == 3:
        rr, cc = n - c, r
    elif transform == 4:
        rr, cc = r, n - c
    elif transform == 5:
        rr, cc = n - r, c
    elif transform == 6:
        rr, cc = c, r
    elif transform == 7:
        rr, cc = n - c, n - r
    else:
        raise ValueError("transform must be 0..7")
    return idx(size, rr, cc)


def transform_board(board: tuple[int, ...], size: int, transform: int) -> tuple[int, ...]:
    out = [EMPTY] * len(board)
    for old_i, value in enumerate(board):
        out[transform_index(size, old_i, transform)] = value
    return tuple(out)


def canonical_board(board: tuple[int, ...], size: int) -> tuple[int, ...]:
    return min(transform_board(board, size, t) for t in range(8))


def all_k_segments(rules: Rules) -> tuple[tuple[int, ...], ...]:
    n, k = rules.size, rules.k
    segments: list[tuple[int, ...]] = []
    for r in range(n):
        for c in range(n):
            for dr, dc in ((1, 0), (0, 1), (1, 1), (1, -1)):
                end_r = r + (k - 1) * dr
                end_c = c + (k - 1) * dc
                if 0 <= end_r < n and 0 <= end_c < n:
                    segments.append(
                        tuple(idx(n, r + i * dr, c + i * dc) for i in range(k))
                    )
    return tuple(segments)


def line_degree(rules: Rules) -> list[int]:
    degree = [0] * (rules.size * rules.size)
    for segment in all_k_segments(rules):
        for p in segment:
            degree[p] += 1
    return degree


def threat_profile(board: tuple[int, ...], rules: Rules, player: int) -> dict[int, int]:
    profile = {need: 0 for need in range(rules.k + 1)}
    for segment in all_k_segments(rules):
        values = [board[i] for i in segment]
        if -player in values:
            continue
        own = values.count(player)
        profile[rules.k - own] += 1
    return profile


class ExactSolver:
    def __init__(self, rules: Rules, use_symmetry: bool = True):
        self.rules = rules
        self.use_symmetry = use_symmetry
        self.nodes = 0
        self._cache: dict[tuple[tuple[int, ...], int], tuple[int, int]] = {}
        self._degree = line_degree(rules)
        self._center = (rules.size - 1) / 2

    def _key(self, board: tuple[int, ...], player: int):
        b = canonical_board(board, self.rules.size) if self.use_symmetry else board
        return b, player

    def _ordered_moves(self, board: tuple[int, ...], player: int) -> list[int]:
        scored = []
        for move in legal_moves(board):
            r, c = rc(self.rules.size, move)
            child = apply_move(board, move, player)
            immediate = is_winning_move(child, self.rules, move, player)
            centrality = abs(r - self._center) + abs(c - self._center)
            scored.append(((0 if immediate else 1, -self._degree[move], centrality, move), move))
        scored.sort()
        return [m for _, m in scored]

    def solve_value(self, board: tuple[int, ...], player: int) -> tuple[int, int]:
        key = self._key(board, player)
        if key in self._cache:
            return self._cache[key]

        self.nodes += 1
        moves = self._ordered_moves(board, player)
        if not moves:
            result = (0, 0)
            self._cache[key] = result
            return result

        win_dist: list[int] = []
        draw_dist: list[int] = []
        loss_dist: list[int] = []

        for move in moves:
            child = apply_move(board, move, player)
            if is_winning_move(child, self.rules, move, player):
                win_dist.append(1)
                continue

            child_value, child_distance = self.solve_value(child, other(player))
            value = -child_value
            distance = child_distance + 1
            if value == 1:
                win_dist.append(distance)
            elif value == 0:
                draw_dist.append(distance)
            else:
                loss_dist.append(distance)

        if win_dist:
            result = (1, min(win_dist))
        elif draw_dist:
            result = (0, min(draw_dist))
        else:
            result = (-1, max(loss_dist))

        self._cache[key] = result
        return result

    def solve(self, board: Optional[tuple[int, ...]] = None, player: int = BLACK) -> SolveResult:
        if board is None:
            board = (EMPTY,) * (self.rules.size * self.rules.size)
        start_nodes = self.nodes
        start = time.perf_counter()
        value, distance = self.solve_value(board, player)
        elapsed = time.perf_counter() - start
        return SolveResult(value, distance, self.nodes - start_nodes, elapsed)

    def best_moves(self, board: tuple[int, ...], player: int) -> list[int]:
        target_value, _ = self.solve_value(board, player)
        candidates: list[tuple[int, int]] = []

        for move in self._ordered_moves(board, player):
            child = apply_move(board, move, player)
            if is_winning_move(child, self.rules, move, player):
                value, distance = 1, 1
            else:
                child_value, child_distance = self.solve_value(child, other(player))
                value, distance = -child_value, child_distance + 1
            if value == target_value:
                candidates.append((move, distance))

        if target_value == 1:
            target_distance = min(d for _, d in candidates)
        elif target_value == -1:
            target_distance = max(d for _, d in candidates)
        else:
            target_distance = min(d for _, d in candidates)
        return [m for m, d in candidates if d == target_distance]


def board_to_rows(board: tuple[int, ...], size: int) -> list[str]:
    symbol = {EMPTY: ".", BLACK: "X", WHITE: "O"}
    return [
        "".join(symbol[board[idx(size, r, c)]] for c in range(size))
        for r in range(size)
    ]


def parse_opening(spec: str, rules: Rules) -> tuple[tuple[int, ...], int]:
    board = (EMPTY,) * (rules.size * rules.size)
    if spec == "empty":
        return board, BLACK
    if spec == "center":
        if rules.size % 2 == 0:
            raise ValueError("center opening requires odd board size")
        center = idx(rules.size, rules.size // 2, rules.size // 2)
        return apply_move(board, center, BLACK), WHITE
    raise ValueError("opening must be empty or center")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--win-mode", choices=["at_least", "exact"], default="at_least")
    parser.add_argument("--opening", choices=["empty", "center"], default="empty")
    parser.add_argument("--no-symmetry", action="store_true")
    parser.add_argument("--json-out")
    args = parser.parse_args()

    rules = Rules(args.size, args.k, args.win_mode)
    board, player = parse_opening(args.opening, rules)
    solver = ExactSolver(rules, use_symmetry=not args.no_symmetry)
    result = solver.solve(board, player)
    best = solver.best_moves(board, player)

    payload = {
        "rules": {
            "size": rules.size,
            "k": rules.k,
            "win_mode": rules.win_mode,
            "opening": args.opening,
        },
        "board": board_to_rows(board, rules.size),
        "player_to_move": "black" if player == BLACK else "white",
        "value_for_player_to_move": result.value,
        "distance_plies": result.distance,
        "expanded_nodes": result.nodes,
        "cache_entries": len(solver._cache),
        "elapsed_sec": result.elapsed_sec,
        "best_moves_zero_based": [
            {"index": m, "row": rc(rules.size, m)[0], "col": rc(rules.size, m)[1]}
            for m in best
        ],
        "line_degree": line_degree(rules),
        "threat_profile_black": threat_profile(board, rules, BLACK),
        "threat_profile_white": threat_profile(board, rules, WHITE),
    }

    text = json.dumps(payload, ensure_ascii=False, indent=2)
    print(text)
    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            f.write(text + "\n")


if __name__ == "__main__":
    main()
