# Scalable Gomoku State-Proof v0.1

這是一個研究「自訂伸縮棋盤上的廣義連 $k$ 遊戲」的低複雜度精確狀態機。

## 功能

- 自訂 $n\times n$；
- 自訂連 $k$；
- 至少連 $k$／恰好連 $k$；
- 空盤或中央首手；
- Negamax 完整求解；
- $D_4$ 八對稱壓縮；
- 勝負值與終局距離；
- 勝線度數與威脅輪廓；
- 小棋盤 AND–OR 策略證書；
- 獨立證書驗證器。

## 已確認的計算分層

純 Python 全狀態枚舉適合作為：

$$
n\leq3
$$

的精確校準層。

$4\times4$、連三已顯示明顯狀態爆炸，因此下一版不應只靠更長時間暴力枚舉，而要加入：

$$
\text{威脅域剪枝}
\to
\text{Proof-Number Search}
\to
\text{壓縮證書}
$$

## 兩條實驗軸

### 校準軸

$$
(1,1)\to(2,2)\to(3,2)\to(3,3)
$$

用來確認狀態機、對稱與證書正確。

### 真正連五主軸

$$
(5,5)\to(6,5)\to(7,5)\to\cdots
$$

其中 $(n,k)$ 表示 $n\times n$ 棋盤、連 $k$。

注意：$5\times5$ 是最小能容納五連的棋盤，但並不代表適合完整盲目枚舉。

## 執行

```bash
python solver.py --size 3 --k 3 --opening empty
python solver.py --size 3 --k 3 --opening center

python experiments.py --config experiment_config.json --out results/sample_results.json

python certificate.py build --size 2 --k 2 --out results/2x2_k2_certificate.json
python certificate.py verify results/2x2_k2_certificate.json
```

## 值

$$
V(s)\in\{-1,0,1\}
$$

- $1$：輪到的一方必勝；
- $0$：最佳應對下和局；
- $-1$：輪到的一方必敗。

## 研究原則

不要預先把所有統計量叫作「勝利不變量」。依序處理：

$$
\text{狀態特徵}
\to
\text{穩定規律}
\to
\text{單調性猜想}
\to
\text{歸納證明}
\to
\text{不變量／證書條件}
$$
