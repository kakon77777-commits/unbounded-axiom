from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix, csr_matrix

from pairing_frontier import symmetry_orbits
from pairing_proof import winning_segments


def has_disjoint_static_block_cover(
    n: int,
    k: int,
    first: int,
    lines: list[tuple[int, ...]] | None = None,
    time_limit: float = 5.0,
) -> bool:
    active = winning_segments(n, k) if lines is None else lines
    available = set(range(n * n)) - {first}
    candidates: set[tuple[int, ...]] = set()
    for line in active:
        points = [point for point in line if point in available]
        for size in range(2, len(points) + 1):
            candidates.update(combinations(points, size))
    candidate_list = sorted(candidates, key=lambda group: (len(group), group))
    candidate_sets = [set(group) for group in candidate_list]

    constraints: list[list[int]] = []
    lower: list[float] = []
    upper: list[float] = []
    for cell in sorted(available):
        ids = [i for i, group in enumerate(candidate_list) if cell in group]
        constraints.append(ids)
        lower.append(0.0)
        upper.append(1.0)
    for line in active:
        line_set = set(line)
        ids = [i for i, group in enumerate(candidate_sets) if group <= line_set]
        if not ids:
            return False
        constraints.append(ids)
        lower.append(1.0)
        upper.append(float("inf"))

    matrix = lil_matrix((len(constraints), len(candidate_list)), dtype=float)
    for row, ids in enumerate(constraints):
        matrix.rows[row] = ids
        matrix.data[row] = [1.0] * len(ids)
    result = milp(
        c=np.zeros(len(candidate_list)),
        integrality=np.ones(len(candidate_list)),
        bounds=Bounds(np.zeros(len(candidate_list)), np.ones(len(candidate_list))),
        constraints=LinearConstraint(
            csr_matrix(matrix), np.array(lower), np.array(upper)
        ),
        options={"presolve": True, "time_limit": time_limit},
    )
    return bool(result.success)


def greedy_infeasible_core(n: int, k: int, first: int) -> list[tuple[int, ...]]:
    core = list(winning_segments(n, k))
    if has_disjoint_static_block_cover(n, k, first, core):
        return []
    changed = True
    while changed:
        changed = False
        for line in list(core):
            trial = [candidate for candidate in core if candidate != line]
            if trial and not has_disjoint_static_block_cover(n, k, first, trial):
                core = trial
                changed = True
    return core


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, default=7)
    parser.add_argument("--k", type=int, default=5)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cores", nargs="*", type=int, default=[0, 24])
    args = parser.parse_args()

    records = []
    for orbit in symmetry_orbits(args.size):
        first = orbit[0]
        feasible = has_disjoint_static_block_cover(
            args.size, args.k, first
        )
        records.append({
            "representative": first,
            "representative_rc": [first // args.size, first % args.size],
            "orbit": orbit,
            "orbit_size": len(orbit),
            "static_disjoint_block_partition_exists": feasible,
        })

    cores = {}
    for first in args.cores:
        core = greedy_infeasible_core(args.size, args.k, first)
        cores[str(first)] = {
            "first": first,
            "first_rc": [first // args.size, first % args.size],
            "line_count": len(core),
            "lines": [list(line) for line in core],
            "lines_rc": [
                [[point // args.size, point % args.size] for point in line]
                for line in core
            ],
            "note": (
                "Greedy irreducible-by-single-deletion core for the MILP model; "
                "not guaranteed minimum-cardinality. Re-solving is required to "
                "check infeasibility."
            ),
        }

    payload = {
        "rules": {"size": args.size, "k": args.k},
        "certificate_family_tested": (
            "After excluding Black's first point, choose disjoint response groups "
            "of sizes 2..5 so every winning segment contains a whole group."
        ),
        "results": records,
        "greedy_infeasible_cores": cores,
        "logical_status": (
            "These are reproducible MILP infeasibility results for a restricted "
            "certificate family. They are not game-value proofs and are not "
            "standalone independently checkable infeasibility certificates."
        ),
    }
    Path(args.out).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "out": args.out,
        "orbit_count": len(records),
        "feasible_orbits": sum(r["static_disjoint_block_partition_exists"] for r in records),
        "core_sizes": {key: value["line_count"] for key, value in cores.items()},
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
