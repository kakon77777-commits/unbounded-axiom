from __future__ import annotations

import argparse
import csv
import json
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "cpp" / "andor_775_reproducer.cpp"
BINARY = ROOT / "cpp" / "andor_775_reproducer"
RESULT_DIR = ROOT / "results" / "v0_5"

# Three D4 representatives of the central 3x3.
CASES = [
    {"class": "central_corner_neighbor", "black_first": 16, "white_reply": 31},
    {"class": "central_edge_neighbor", "black_first": 17, "white_reply": 31},
    {"class": "center", "black_first": 24, "white_reply": 31},
]


def compile_solver(opt: str = "-O3", output: Path = BINARY) -> None:
    cmd = ["g++", opt, "-std=c++20", str(SOURCE), "-o", str(output)]
    if opt == "-O3":
        cmd.insert(2, "-march=native")
    subprocess.run(cmd, check=True, cwd=ROOT)


def run_case(binary: Path, case: dict, budget_sec: float) -> dict:
    cmd = [
        str(binary),
        str(case["black_first"]),
        str(budget_sec),
        str(case["white_reply"]),
    ]
    started = time.perf_counter()
    proc = subprocess.run(cmd, check=False, capture_output=True, text=True, cwd=ROOT)
    wall = time.perf_counter() - started
    stdout_lines = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
    if not stdout_lines:
        raise RuntimeError(f"solver emitted no JSON: stderr={proc.stderr!r}")
    payload = json.loads(stdout_lines[-1])
    payload.update({
        "class": case["class"],
        "returncode": proc.returncode,
        "wall_seconds": wall,
        "stderr": proc.stderr.strip(),
    })
    return payload


def write_outputs(results: list[dict], label: str) -> None:
    RESULT_DIR.mkdir(parents=True, exist_ok=True)
    json_path = RESULT_DIR / f"central_recompute_{label}.json"
    csv_path = RESULT_DIR / f"central_recompute_{label}.csv"
    md_path = RESULT_DIR / f"central_recompute_{label}.md"

    json_path.write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    fields = [
        "class", "f", "g", "breaker", "timedout", "calls", "tt", "nodes",
        "pairCalls", "pairFound", "potentialTerms", "reducePairs", "domPrunes",
        "rzSkips", "seconds", "wall_seconds", "returncode",
    ]
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)

    lines = [
        f"# $7\\times7$ 連五中央三類重算（{label}）",
        "",
        "| 對稱類 | 黑首手 | 白首應 | Breaker 證成 | 呼叫數 | TT 狀態 | 證明節點 | 秒 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in results:
        lines.append(
            f"| {row['class']} | {row['f']} | {row['g']} | {row['breaker']} | "
            f"{row['calls']} | {row['tt']} | {row['nodes']} | {row['seconds']:.6f} |"
        )
    lines += [
        "",
        "`breaker=true` 表示：在固定黑方第一手與白方第一應後，程式證明白方可阻止黑方完成任一五連。",
        "",
        "本檔是可重算審計結果；目前尚未把 C++ 內部的全部 AND–OR／r-zone 推導序列化為獨立靜態證書。",
    ]
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--budget", type=float, default=60.0)
    parser.add_argument("--opt", default="-O3", choices=["-O0", "-O2", "-O3"])
    parser.add_argument("--label", default="o3")
    args = parser.parse_args()

    output = BINARY if args.label == "o3" else ROOT / "cpp" / f"andor_775_reproducer_{args.label}"
    compile_solver(args.opt, output)
    results = [run_case(output, case, args.budget) for case in CASES]
    write_outputs(results, args.label)
    print(json.dumps(results, ensure_ascii=False, indent=2))
    if not all(r["breaker"] and not r["timedout"] and r["returncode"] == 0 for r in results):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
