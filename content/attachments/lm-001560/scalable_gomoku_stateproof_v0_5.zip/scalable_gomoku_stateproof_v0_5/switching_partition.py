from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path
from typing import Iterable

from pairing_proof import winning_segments


def transform_index(n: int, index: int, transform: int) -> int:
    r, c = divmod(index, n)
    m = n - 1
    if transform == 0:
        rr, cc = r, c
    elif transform == 1:
        rr, cc = c, m - r
    elif transform == 2:
        rr, cc = m - r, m - c
    elif transform == 3:
        rr, cc = m - c, r
    elif transform == 4:
        rr, cc = r, m - c
    elif transform == 5:
        rr, cc = m - r, c
    elif transform == 6:
        rr, cc = c, r
    elif transform == 7:
        rr, cc = m - c, m - r
    else:
        raise ValueError("transform must be 0..7")
    return rr * n + cc


def symmetry_orbit(n: int, cell: int) -> list[int]:
    return sorted({transform_index(n, cell, t) for t in range(8)})


def transform_seed(seed: dict, transform: int, n: int = 7) -> dict:
    first = transform_index(n, seed["f"], transform)
    white_first = transform_index(n, seed["g"], transform)
    branches: dict[str, dict] = {}
    for branch in seed["branches"]:
        black_second = transform_index(n, branch["h"], transform)
        white_second = transform_index(n, branch["r"], transform)
        groups = [
            sorted(transform_index(n, point, transform) for point in group)
            for group in branch["blocks"]
        ]
        groups.sort(key=lambda group: (len(group), group))
        branches[str(black_second)] = {
            "black_second_move": black_second,
            "black_second_move_rc": [black_second // n, black_second % n],
            "white_second_move": white_second,
            "white_second_move_rc": [white_second // n, white_second % n],
            "blocking_partition": groups,
        }
    return {
        "black_first_move": first,
        "black_first_move_rc": [first // n, first % n],
        "white_first_move": white_first,
        "white_first_move_rc": [white_first // n, white_first % n],
        "branches": branches,
    }


def expand_seed_files(seed_paths: Iterable[Path]) -> dict:
    n, k = 7, 5
    openings: dict[str, dict] = {}
    representative_metadata: list[dict] = []
    for seed_path in seed_paths:
        seed = json.loads(seed_path.read_text(encoding="utf-8"))
        rep = seed["f"]
        orbit = symmetry_orbit(n, rep)
        mapped: set[int] = set()
        for target in orbit:
            transform = next(
                t for t in range(8)
                if transform_index(n, rep, t) == target
            )
            entry = transform_seed(seed, transform, n)
            openings[str(target)] = entry
            mapped.add(target)
        representative_metadata.append({
            "representative": rep,
            "representative_rc": [rep // n, rep % n],
            "white_first_move": seed["g"],
            "white_first_move_rc": [seed["g"] // n, seed["g"] % n],
            "orbit": orbit,
            "orbit_size": len(orbit),
            "seed_file": seed_path.name,
            "expanded_targets": sorted(mapped),
        })

    central_3x3 = {
        r * n + c for r in range(2, 5) for c in range(2, 5)
    }
    expected = set(range(n * n)) - central_3x3
    actual = set(map(int, openings))
    if actual != expected:
        raise RuntimeError({
            "message": "expanded openings do not equal the non-central-3x3 cells",
            "missing": sorted(expected - actual),
            "extra": sorted(actual - expected),
        })

    return {
        "format": "two-stage-switching-blocking-partition-v1",
        "rules": {
            "size": n,
            "k": k,
            "win_mode_scope": ["at_least", "exact"],
        },
        "certificate_type": "second_player_nonloss_outside_central_3x3",
        "quantifier_pattern": (
            "for each certified Black first move f, there exists White g; "
            "for every Black second move h, there exists White r and a static "
            "blocking partition for all later play"
        ),
        "strategy_after_partition": (
            "Whenever Black plays in a group not yet occupied by White, White "
            "plays another free point in that same group. If the group is already "
            "blocked by White, White may play in any legal point, preferably an "
            "untouched group. Every winning segment is preblocked or contains a "
            "whole group, so Black can never own a complete winning segment."
        ),
        "central_3x3_unresolved": sorted(central_3x3),
        "central_3x3_unresolved_rc": [
            [cell // n, cell % n] for cell in sorted(central_3x3)
        ],
        "representatives": representative_metadata,
        "openings": openings,
    }


def _solve_disjoint_block_cover(
    n: int,
    k: int,
    unavailable: set[int],
    already_blocked: set[int],
    max_group_size: int = 3,
    time_limit: float = 0.5,
) -> list[list[int]] | None:
    """Generate a static partition certificate using SciPy/HiGHS.

    Selected coverage groups are disjoint subsets of active winning lines.
    Leftover cells are partitioned into filler pairs and at most one triple.
    Verification does not trust this optimizer.
    """
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import lil_matrix, csr_matrix

    available = set(range(n * n)) - unavailable
    active_lines = [
        line for line in winning_segments(n, k)
        if not (set(line) & already_blocked)
    ]
    candidate_set: set[tuple[int, ...]] = set()
    for line in active_lines:
        points = [point for point in line if point in available]
        for size in range(2, min(max_group_size, len(points)) + 1):
            candidate_set.update(combinations(points, size))
    candidates = sorted(candidate_set, key=lambda group: (len(group), group))
    candidate_sets = [set(group) for group in candidates]

    constraints: list[list[int]] = []
    lower: list[float] = []
    upper: list[float] = []

    for cell in sorted(available):
        ids = [i for i, group in enumerate(candidates) if cell in group]
        constraints.append(ids)
        lower.append(0.0)
        upper.append(1.0)

    for line in active_lines:
        line_set = set(line)
        ids = [i for i, group in enumerate(candidate_sets) if group <= line_set]
        if not ids:
            return None
        constraints.append(ids)
        lower.append(1.0)
        upper.append(float("inf"))

    matrix = lil_matrix((len(constraints), len(candidates)), dtype=float)
    for row, ids in enumerate(constraints):
        matrix.rows[row] = ids
        matrix.data[row] = [1.0] * len(ids)

    objective = np.array(
        [len(group) + 0.01 * (len(group) - 2) for group in candidates],
        dtype=float,
    )
    result = milp(
        c=objective,
        integrality=np.ones(len(candidates)),
        bounds=Bounds(np.zeros(len(candidates)), np.ones(len(candidates))),
        constraints=LinearConstraint(
            csr_matrix(matrix),
            np.array(lower),
            np.array(upper),
        ),
        options={"presolve": True, "time_limit": time_limit},
    )
    if not result.success:
        return None

    selected = [
        list(candidates[i]) for i, value in enumerate(result.x) if value > 0.5
    ]
    used = {cell for group in selected for cell in group}
    leftover = sorted(available - used)
    if len(leftover) == 1:
        return None
    if len(leftover) % 2 == 1:
        selected.append(leftover[:3])
        leftover = leftover[3:]
    selected.extend(leftover[i:i + 2] for i in range(0, len(leftover), 2))
    selected.sort(key=lambda group: (len(group), group))
    return selected


def search_representative(
    first: int,
    white_first: int,
    n: int = 7,
    k: int = 5,
    time_limit: float = 0.5,
) -> dict | None:
    if first == white_first:
        raise ValueError("first moves must differ")
    branches = []
    degree = {
        cell: sum(cell in line for line in winning_segments(n, k))
        for cell in range(n * n)
    }
    for black_second in range(n * n):
        if black_second in {first, white_first}:
            continue
        response_candidates = [
            cell for cell in range(n * n)
            if cell not in {first, white_first, black_second}
        ]
        response_candidates.sort(key=lambda cell: (-degree[cell], cell))
        found = None
        for white_second in response_candidates:
            partition = _solve_disjoint_block_cover(
                n,
                k,
                {first, white_first, black_second, white_second},
                {white_first, white_second},
                max_group_size=3,
                time_limit=time_limit,
            )
            if partition is not None:
                found = {
                    "h": black_second,
                    "r": white_second,
                    "blocks": partition,
                }
                break
        if found is None:
            return None
        branches.append(found)
    return {
        "f": first,
        "g": white_first,
        "success": len(branches),
        "total": n * n - 2,
        "branches": branches,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    expand = sub.add_parser("expand")
    expand.add_argument("--seed-dir", required=True)
    expand.add_argument("--out", required=True)

    search = sub.add_parser("search")
    search.add_argument("--first", type=int, required=True)
    search.add_argument("--white-first", type=int, required=True)
    search.add_argument("--time-limit", type=float, default=0.5)
    search.add_argument("--out", required=True)

    args = parser.parse_args()
    if args.command == "expand":
        paths = sorted(Path(args.seed_dir).glob("seed_*.json"))
        certificate = expand_seed_files(paths)
        Path(args.out).write_text(
            json.dumps(certificate, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(json.dumps({
            "out": args.out,
            "seed_count": len(paths),
            "opening_count": len(certificate["openings"]),
        }, ensure_ascii=False, indent=2))
    else:
        seed = search_representative(
            args.first,
            args.white_first,
            time_limit=args.time_limit,
        )
        Path(args.out).write_text(
            json.dumps(seed, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(json.dumps({
            "out": args.out,
            "success": seed is not None,
        }, ensure_ascii=False, indent=2))
        if seed is None:
            raise SystemExit(2)


if __name__ == "__main__":
    main()
