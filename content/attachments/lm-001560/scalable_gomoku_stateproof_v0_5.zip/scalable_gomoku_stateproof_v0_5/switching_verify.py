from __future__ import annotations

import argparse
import json
from pathlib import Path

from pairing_proof import winning_segments


def verify_partition(
    n: int,
    k: int,
    occupied: set[int],
    white_stones: set[int],
    groups_raw: list[list[int]],
) -> tuple[bool, str, dict]:
    available = set(range(n * n)) - occupied
    used: set[int] = set()
    groups: list[set[int]] = []
    for raw in groups_raw:
        if len(raw) < 2:
            return False, "a blocking group has fewer than two points", {}
        group = set(raw)
        if len(group) != len(raw):
            return False, "a blocking group repeats a point", {}
        if not group <= available:
            return False, "a blocking group uses an occupied/out-of-board point", {}
        if used & group:
            return False, "blocking groups are not disjoint", {}
        used |= group
        groups.append(group)

    if used != available:
        return False, "blocking groups do not partition all remaining cells", {
            "missing": sorted(available - used),
            "extra": sorted(used - available),
        }

    uncovered: list[list[int]] = []
    for line in winning_segments(n, k):
        line_set = set(line)
        if line_set & white_stones:
            continue
        if not any(group <= line_set for group in groups):
            uncovered.append(list(line))
    if uncovered:
        return False, "an unblocked winning line contains no full response group", {
            "uncovered_lines": uncovered,
        }

    return True, "ok", {
        "group_count": len(groups),
        "group_size_histogram": {
            str(size): sum(len(group) == size for group in groups)
            for size in sorted({len(group) for group in groups})
        },
    }


def verify_certificate(cert: dict) -> tuple[bool, str, dict]:
    n = cert["rules"]["size"]
    k = cert["rules"]["k"]
    if cert.get("certificate_type") != "second_player_nonloss_outside_central_3x3":
        return False, "unexpected certificate type", {}

    central = {r * n + c for r in range(2, 5) for c in range(2, 5)}
    expected_openings = set(range(n * n)) - central
    openings = cert["openings"]
    actual_openings = set(map(int, openings.keys()))
    if actual_openings != expected_openings:
        return False, "certificate opening domain is not exactly outside central 3x3", {
            "missing": sorted(expected_openings - actual_openings),
            "extra": sorted(actual_openings - expected_openings),
        }

    branch_count = 0
    group_histogram: dict[int, int] = {}
    for key, opening in openings.items():
        first = int(key)
        if opening["black_first_move"] != first:
            return False, f"opening {first}: first move field mismatch", {}
        white_first = opening["white_first_move"]
        if white_first == first or not (0 <= white_first < n * n):
            return False, f"opening {first}: invalid White first move", {}

        expected_seconds = set(range(n * n)) - {first, white_first}
        branches = opening["branches"]
        if set(map(int, branches.keys())) != expected_seconds:
            return False, f"opening {first}: Black second moves are incomplete", {}

        for branch_key, branch in branches.items():
            black_second = int(branch_key)
            if branch["black_second_move"] != black_second:
                return False, f"opening {first}, branch {black_second}: key mismatch", {}
            white_second = branch["white_second_move"]
            occupied = {first, white_first, black_second, white_second}
            if len(occupied) != 4 or not all(0 <= x < n * n for x in occupied):
                return False, f"opening {first}, branch {black_second}: illegal second response", {}
            ok, message, info = verify_partition(
                n,
                k,
                occupied,
                {white_first, white_second},
                branch["blocking_partition"],
            )
            if not ok:
                return False, f"opening {first}, branch {black_second}: {message}", info
            branch_count += 1
            for size, count in info["group_size_histogram"].items():
                group_histogram[int(size)] = group_histogram.get(int(size), 0) + count

    return True, "ok", {
        "verified_first_moves": len(openings),
        "verified_branches": branch_count,
        "unresolved_first_moves": sorted(central),
        "unresolved_first_moves_rc": [[x // n, x % n] for x in sorted(central)],
        "aggregate_group_size_histogram": {
            str(size): group_histogram[size] for size in sorted(group_histogram)
        },
        "theorem": (
            "For every Black first move outside the central 3x3, White has a "
            "two-move switching strategy leading to a static blocking partition. "
            "Therefore Black cannot force a win from any of those 40 openings."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate")
    parser.add_argument("--json-out")
    args = parser.parse_args()
    cert = json.loads(Path(args.certificate).read_text(encoding="utf-8"))
    ok, message, details = verify_certificate(cert)
    payload = {"ok": ok, "message": message, "details": details}
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    print(text)
    if args.json_out:
        Path(args.json_out).write_text(text + "\n", encoding="utf-8")
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
