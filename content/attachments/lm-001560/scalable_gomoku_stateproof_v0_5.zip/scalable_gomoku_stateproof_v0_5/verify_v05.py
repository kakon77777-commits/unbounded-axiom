from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULT_DIR = ROOT / "results" / "v0_5"
CENTRAL_REPS = {16: 31, 17: 31, 24: 31}


def transform_index(index: int, t: int, n: int = 7) -> int:
    r, c = divmod(index, n)
    m = n - 1
    transforms = (
        (r, c), (c, m-r), (m-r, m-c), (m-c, r),
        (r, m-c), (m-r, c), (c, r), (m-c, m-r),
    )
    rr, cc = transforms[t]
    return rr * n + cc


def orbit(index: int) -> set[int]:
    return {transform_index(index, t) for t in range(8)}


def central_strategy_map() -> dict[str, dict]:
    mapping: dict[str, dict] = {}
    for rep, reply in CENTRAL_REPS.items():
        for t in range(8):
            opening = transform_index(rep, t)
            transformed_reply = transform_index(reply, t)
            mapping.setdefault(str(opening), {
                "representative": rep,
                "transform": t,
                "white_first_reply": transformed_reply,
                "opening_rc": [opening // 7, opening % 7],
                "reply_rc": [transformed_reply // 7, transformed_reply % 7],
            })
    return mapping


def run_outer_verifier() -> dict:
    cert = ROOT / "results" / "v0_4" / "7x7_k5_outer40_switching_certificate.json"
    out = RESULT_DIR / "outer40_reverification.json"
    proc = subprocess.run(
        [sys.executable, str(ROOT / "switching_verify.py"), str(cert), "--json-out", str(out)],
        cwd=ROOT, capture_output=True, text=True, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stdout + "\n" + proc.stderr)
    return json.loads(out.read_text(encoding="utf-8"))


def run_recompute(label: str, opt: str, budget: float) -> list[dict]:
    proc = subprocess.run(
        [sys.executable, str(ROOT / "recompute_v05.py"), "--label", label, f"--opt={opt}", "--budget", str(budget)],
        cwd=ROOT, capture_output=True, text=True, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stdout + "\n" + proc.stderr)
    path = RESULT_DIR / f"central_recompute_{label}.json"
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--budget", type=float, default=60.0)
    parser.add_argument("--recompute", action="store_true", help="rerun the C++ solver before verification")
    parser.add_argument("--skip-repeat", action="store_true")
    args = parser.parse_args()
    RESULT_DIR.mkdir(parents=True, exist_ok=True)

    outer = run_outer_verifier()
    if not outer["ok"]:
        raise SystemExit("outer certificate failed")

    if args.recompute:
        o3 = run_recompute("o3", "-O3", args.budget)
        repeat = [] if args.skip_repeat else run_recompute("o3_repeat", "-O3", args.budget)
    else:
        o3 = json.loads((RESULT_DIR / "central_recompute_o3.json").read_text(encoding="utf-8"))
        repeat_path = RESULT_DIR / "central_recompute_o3_repeat.json"
        repeat = [] if args.skip_repeat else json.loads(repeat_path.read_text(encoding="utf-8"))

    def normalized(rows: list[dict]) -> dict[int, bool]:
        return {row["f"]: bool(row["breaker"] and not row["timedout"] and row["returncode"] == 0) for row in rows}

    structural_keys = (
        "f", "g", "breaker", "timedout", "calls", "tt", "nodes",
        "pairCalls", "pairFound", "potentialTerms", "reducePairs",
        "domPrunes", "rzSkips", "returncode",
    )
    def structural(rows: list[dict]) -> list[tuple]:
        return [tuple(row[key] for key in structural_keys) for row in sorted(rows, key=lambda x: x["f"])]

    central_map = central_strategy_map()
    central = set(map(int, central_map))
    expected_central = {r * 7 + c for r in range(2, 5) for c in range(2, 5)}
    outer_domain = set(range(49)) - expected_central

    checks = {
        "outer_certificate_ok": bool(outer["ok"]),
        "outer_domain_size": len(outer_domain),
        "central_domain_size": len(central),
        "central_orbit_coverage_exact": central == expected_central,
        "domains_disjoint": not (outer_domain & central),
        "all_49_openings_covered": (outer_domain | central) == set(range(49)),
        "o3_three_representatives_proved": all(normalized(o3).values()) and set(normalized(o3)) == set(CENTRAL_REPS),
        "o3_repeat_agrees": True if args.skip_repeat else structural(repeat) == structural(o3),
    }
    ok = all(checks.values())

    strategy_path = RESULT_DIR / "central9_symmetry_strategy_map.json"
    strategy_path.write_text(json.dumps(central_map, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    payload = {
        "ok": ok,
        "checks": checks,
        "outer_verification": outer,
        "central_recompute_o3": o3,
        "central_recompute_o3_repeat": repeat,
        "central_strategy_map": central_map,
        "coverage_theorem": (
            "The v0.4 static switching certificate covers 40 outer openings. "
            "The v0.5 C++ recomputation proves Breaker nonloss for the three D4 "
            "representatives 16, 17 and 24 after reply 31; D4 transport covers "
            "the remaining central 3x3. Thus Black has no forced five-in-a-row "
            "from any first move on the 7x7 board."
        ),
        "qualification": (
            "Outer40 is a serialized independently checked certificate. Central9 "
            "is currently a source-available deterministic recomputation audit, "
            "recomputed twice from the same source; it is not yet a serialized full proof DAG."
        ),
        "source_sha256": sha256(ROOT / "cpp" / "andor_775_reproducer.cpp"),
    }
    out = RESULT_DIR / "v0_5_verification.json"
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
