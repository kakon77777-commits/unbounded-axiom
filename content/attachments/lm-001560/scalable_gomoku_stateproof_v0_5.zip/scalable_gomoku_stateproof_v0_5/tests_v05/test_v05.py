import unittest

from verify_v05 import CENTRAL_REPS, central_strategy_map, orbit


class V05Tests(unittest.TestCase):
    def test_central_orbits(self):
        central = set().union(*(orbit(rep) for rep in CENTRAL_REPS))
        expected = {r * 7 + c for r in range(2, 5) for c in range(2, 5)}
        self.assertEqual(central, expected)

    def test_strategy_map_has_nine_openings(self):
        mapping = central_strategy_map()
        self.assertEqual(len(mapping), 9)
        for opening, data in mapping.items():
            self.assertNotEqual(int(opening), data["white_first_reply"])

    def test_representatives(self):
        self.assertEqual(set(CENTRAL_REPS), {16, 17, 24})
        self.assertEqual(set(CENTRAL_REPS.values()), {31})


if __name__ == "__main__":
    unittest.main()
