import copy
import json
import unittest
from pathlib import Path

from switching_partition import expand_seed_files
from switching_verify import verify_certificate


BASE = Path(__file__).resolve().parents[1]
SEED_DIR = BASE / "results" / "v0_4" / "seeds"
CERT_PATH = BASE / "results" / "v0_4" / "7x7_k5_outer40_switching_certificate.json"


class V04Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cert = json.loads(CERT_PATH.read_text(encoding="utf-8"))

    def test_seed_expansion_covers_40_openings(self):
        cert = expand_seed_files(sorted(SEED_DIR.glob("seed_*.json")))
        self.assertEqual(len(cert["openings"]), 40)

    def test_certificate_verifies(self):
        ok, message, details = verify_certificate(self.cert)
        self.assertTrue(ok, message)
        self.assertEqual(details["verified_first_moves"], 40)
        self.assertEqual(details["verified_branches"], 1880)

    def test_unresolved_region_is_central_3x3(self):
        expected = {r * 7 + c for r in range(2, 5) for c in range(2, 5)}
        self.assertEqual(set(self.cert["central_3x3_unresolved"]), expected)

    def test_tampered_group_is_rejected(self):
        broken = copy.deepcopy(self.cert)
        opening = broken["openings"]["0"]
        branch_key = next(iter(opening["branches"]))
        groups = opening["branches"][branch_key]["blocking_partition"]
        groups[0][0] = groups[1][0]
        ok, _, _ = verify_certificate(broken)
        self.assertFalse(ok)

    def test_each_partition_has_21_pairs_and_one_triple(self):
        for opening in self.cert["openings"].values():
            for branch in opening["branches"].values():
                sizes = [len(group) for group in branch["blocking_partition"]]
                self.assertEqual(sizes.count(2), 21)
                self.assertEqual(sizes.count(3), 1)


if __name__ == "__main__":
    unittest.main()
