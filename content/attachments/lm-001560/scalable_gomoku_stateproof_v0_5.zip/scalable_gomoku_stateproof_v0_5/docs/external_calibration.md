# 外部校准：既有 $7\times7$ 与 $8\times8$ 连五求解

## 已知结果

Hsu、Wu、Tseng、Hsueh 与 Wu 在 2020 年发表于 *Theoretical Computer Science* 的论文：

> Hsu, C.-C., Wu, I.-C., Tseng, C.-W., Hsueh, T.-J., & Wu, S.-J. (2020). *On solving the 7,7,5-game and the 8,8,5-game*. Theoretical Computer Science, 815, 79–94. DOI: 10.1016/j.tcs.2020.02.023.

论文报告：

$$
(7,7,5)
$$

与：

$$
(8,8,5)
$$

均为和局。

其方法包括：

- AND／OR 树搜索；
- partial pairing；
- vertex domination；
- Breaker relevance zones；
- pairing-strategy terminal；
- potential-weight pruning；
- transposition table。

论文报告的 $7\times7$ 求解时间约为 $2.5$ 秒，但该时间依赖其实现、硬件与完整算法组合，不能直接与本项目的 Python／C++ 混合研究代码横向比较。

## 与本项目的关系

外部文献的作用是校准最终博弈值，而不是替代本项目的自建证明。

v0.3 与 v0.4 是在尚未调用该结论时，从小棋盘逐步发现：

$$
\text{静态配对}
\to
\text{适应性配对}
\to
\text{两阶段切换阻断}.
$$

v0.5 再对中央三个对称类建立决定性 AND／OR 重算，使内部结果与已知文献一致：

$$
\boxed{V(G(7,5))=0}.
$$

## 不应混淆的两件事

外部论文已经给出完整求解结果，并不自动意味着本项目的每段代码都正确。

相反，本项目的三层验证目标是：

1. 结果与既有文献一致；
2. 外围证书可由独立验证器静态检查；
3. 中央求解可由公开原始码决定性重算，并在下一版转化为独立静态证明证书。
