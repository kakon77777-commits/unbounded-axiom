# 兩階段切換阻斷定理

## 定理

設 $G$ 是有限 Maker–Breaker 型格點遊戲，Maker 每回合占一點，Breaker 每回合占一點。對某個四手前綴：

$$
(f,g,h,r),
$$

其中 $f,h$ 為 Maker，$g,r$ 為 Breaker。若剩餘點可分區為：

$$
\mathcal P=\{C_1,\ldots,C_m\},
\qquad |C_i|\geq2,
$$

且每個勝利集合 $L$ 都滿足：

$$
L\cap\{g,r\}\neq\varnothing
\quad\lor\quad
\exists C_i\in\mathcal P:C_i\subseteq L,
$$

則 Breaker 從該前綴有非敗策略。

## 策略

Maker 落在 $C_i$ 時：

1. 若 $C_i$ 尚無 Breaker 棋子，Breaker 在 $C_i$ 的另一空點落子；
2. 若 $C_i$ 已含 Breaker 棋子，Breaker 可在任何合法點落子，優先占據尚未阻斷的組。

## 歸納不變量

每個組始終滿足：

$$
C_i\cap S_B\neq\varnothing
\quad\lor\quad
|C_i\cap S_M|\leq1.
$$

因此 Maker 永遠不能完整占有任何 $C_i$。每個勝利集合又不是已被 $g,r$ 阻斷，就是包含某個 $C_i$，故 Maker 永遠不能完成勝利集合。

## $7\times7$ 連五的套用

對中央 $3\times3$ 外的每個黑方首手 $f$，v0.4 提供：

$$
\exists g\;\forall h\;\exists r,\mathcal P_{f,g,h,r}.
$$

每個分區恰由：

$$
21\text{ 個二元組}+1\text{ 個三元組}
$$

組成，覆蓋餘下 $45$ 點。總共驗證：

$$
40\times47=1880
$$

個黑方第二手分支。
