#include <bits/stdc++.h>
using namespace std; using U=uint64_t;
constexpr int N=7,K=5,C=49; constexpr U FULL=(1ULL<<C)-1;
vector<U> LINES; vector<U> CELL_LBITS; vector<vector<int>> CELL_LIDX;

struct State{U avail, active, black; uint8_t turn;}; // turn 0 Maker,1 Breaker
struct Key{U a,e,b;uint8_t t;bool operator==(Key const&o)const{return a==o.a&&e==o.e&&b==o.b&&t==o.t;}};
struct KH{size_t operator()(Key const&x)const{U h=x.a*0x9e3779b97f4a7c15ULL ^ rotl(x.e,17)^rotl(x.b,37)^x.t;return h^(h>>32);}};
struct Res{bool breaker; U rzone; int node=-1;};
struct Node{State s; string type; U rzone=0; int move=-1; vector<pair<int,int>> children; vector<vector<int>> blocks; U reducedRemoved=0;};
vector<Node> NODES;
unordered_map<Key,Res,KH> TT;
long long calls=0,ttHits=0,pairCalls=0,pairFound=0,potentialTerms=0,reducePairs=0,domPrunes=0,rzSkips=0;
chrono::steady_clock::time_point DEADLINE;
bool timedout=false;

bool makerWin(U b,U active){U x=active;while(x){int i=__builtin_ctzll(x);x&=x-1;U L=LINES[i];if((b&L)==L)return true;}return false;}
int potential(U b,U active){int p=0;U x=active;while(x){int i=__builtin_ctzll(x);x&=x-1;p+=1<<__builtin_popcountll(b&LINES[i]);}return p;}
int cellPotential(int c,U b,U active){int p=0;U x=active&CELL_LBITS[c];while(x){int i=__builtin_ctzll(x);x&=x-1;p+=1<<__builtin_popcountll(b&LINES[i]);}return p;}

struct Reduction{State s;U removed=0;vector<pair<int,int>> pairs;};
Reduction reduceState(State s){
 Reduction R{s,0,{}};
 bool changed=true;
 while(changed){changed=false;
   // redundant available vertices
   U av=R.s.avail, rem=0;
   U x=av;while(x){int c=__builtin_ctzll(x);x&=x-1;if((CELL_LBITS[c]&R.s.active)==0)rem|=1ULL<<c;}
   if(rem){R.s.avail&=~rem;R.removed|=rem;changed=true;}
   // mutually dominated/equal incidence: choose pair and remove all lines containing them
   vector<int> cells; x=R.s.avail;while(x){int c=__builtin_ctzll(x);x&=x-1;cells.push_back(c);} 
   bool got=false;
   for(size_t i=0;i<cells.size()&&!got;i++)for(size_t j=i+1;j<cells.size();j++){
      U ei=CELL_LBITS[cells[i]]&R.s.active, ej=CELL_LBITS[cells[j]]&R.s.active;
      if(ei && ei==ej){int a=cells[i],b=cells[j];U pm=(1ULL<<a)|(1ULL<<b);R.s.avail&=~pm;R.s.active&=~ei;R.removed|=pm;R.pairs.push_back({a,b});reducePairs++;changed=got=true;break;}
   }
 }
 return R;
}

struct BlockFinder{
 State s; vector<array<U,2>> cand; vector<vector<int>> byLine; unordered_set<U> fail; long long steps=0, stepLimit=0; bool to=false;
 bool dfs(U unc,U used,vector<vector<int>>&out){
   if(++steps>stepLimit){to=true;return false;} if(!unc)return true;
   // no memo with used because collision/incorrect; exact correctness over speed
   int best=-1;vector<int> opts;size_t bn=SIZE_MAX;U x=unc;
   while(x){int li=__builtin_ctzll(x);x&=x-1;vector<int> cur;for(int ci:byLine[li])if(!(cand[ci][0]&used))cur.push_back(ci);if(cur.empty())return false;if(cur.size()<bn){bn=cur.size();best=li;opts.swap(cur);if(bn==1)break;}}
   sort(opts.begin(),opts.end(),[&](int a,int b){return __builtin_popcountll(cand[a][1]&unc)>__builtin_popcountll(cand[b][1]&unc);});
   for(int ci:opts){U cm=cand[ci][0];vector<int> g;U z=cm;while(z){int c=__builtin_ctzll(z);z&=z-1;g.push_back(c);}out.push_back(g);if(dfs(unc&~cand[ci][1],used|cm,out))return true;out.pop_back();if(to)return false;}return false;
 }
 bool find(State st,vector<vector<int>>&out,long long maxSteps=20000){
   pairCalls++;s=st;U active=st.active;if(!active){pairFound++;return true;}
   cand.clear();byLine.assign(LINES.size(),{});
   vector<int> freec;U q=st.avail;while(q){int c=__builtin_ctzll(q);q&=q-1;freec.push_back(c);} 
   // pairs only; triples can be enabled if needed
   for(size_t ai=0;ai<freec.size();ai++)for(size_t bi=ai+1;bi<freec.size();bi++){
      int a=freec[ai],b=freec[bi];U cm=(1ULL<<a)|(1ULL<<b);U cov=active&CELL_LBITS[a]&CELL_LBITS[b];if(cov){int id=cand.size();cand.push_back({cm,cov});U x=cov;while(x){int li=__builtin_ctzll(x);x&=x-1;byLine[li].push_back(id);}}
   }
   U x=active;while(x){int li=__builtin_ctzll(x);x&=x-1;if(byLine[li].empty())return false;}
   steps=0;stepLimit=maxSteps;to=false;out.clear();bool ok=dfs(active,0,out);if(ok)pairFound++;return ok;
 }
} BF;

vector<int> moveList(State s){
 vector<int> v;U x=s.avail;while(x){int c=__builtin_ctzll(x);x&=x-1;v.push_back(c);} 
 // vertex domination: keep cells not strictly dominated; equal keep lower index
 vector<char> drop(C,0);vector<U> inc(C);for(int c:v)inc[c]=CELL_LBITS[c]&s.active;
 for(int j:v)for(int i:v)if(i!=j&&!drop[j]){
   if((inc[i]|inc[j])==inc[i]){ // i superset j
      if(inc[i]!=inc[j] || i<j){drop[j]=1;domPrunes++;}
   }
 }
 vector<int>w;for(int c:v)if(!drop[c])w.push_back(c);
 sort(w.begin(),w.end(),[&](int a,int b){int pa=cellPotential(a,s.black,s.active),pb=cellPotential(b,s.black,s.active);if(pa!=pb)return pa>pb;return a<b;});return w;
}

Res makerSearch(State);Res breakerSearch(State);
int newNode(State s,string type){NODES.push_back(Node{s,type});return NODES.size()-1;}

Res terminalCheck(State s,bool makerTurn,U augRemoved=0){
 if(makerWin(s.black,s.active)){int id=newNode(s,"maker_win");return {false,0,id};}
 if(!s.active){int id=newNode(s,"all_blocked");NODES[id].rzone=augRemoved;return {true,augRemoved,id};}
 vector<vector<int>> blocks;
 if(BF.find(s,blocks,20000)) {U rz=augRemoved;for(auto&g:blocks)for(int c:g)rz|=1ULL<<c;int id=newNode(s,"pairing_terminal");NODES[id].blocks=blocks;NODES[id].rzone=rz;return {true,rz,id};}
 if(!makerTurn && potential(s.black,s.active)<(1<<K)){potentialTerms++;U rz=augRemoved|s.avail;int id=newNode(s,"potential_terminal");NODES[id].rzone=rz;return {true,rz,id};}
 return {false,~0ULL,-1}; // sentinel node -1 no terminal
}

Res makerSearch(State orig){
 if(chrono::steady_clock::now()>DEADLINE){timedout=true;return {false,0,-2};}calls++;
 Reduction red=reduceState(orig);State s=red.s;Key k{s.avail,s.active,s.black,0};auto it=TT.find(k);if(it!=TT.end()){ttHits++;Res r=it->second;r.rzone|=red.removed;return r;}
 Res term=terminalCheck(s,true,red.removed);if(term.node!=-1){TT[k]={term.breaker,term.rzone&~red.removed,term.node};return term;}
 int id=newNode(s,"maker_and");NODES[id].reducedRemoved=red.removed;
 auto mv=moveList(s); // immediate maker winning moves
 for(int v:mv){State ch{s.avail&~(1ULL<<v),s.active,s.black|(1ULL<<v),1};if(makerWin(ch.black,ch.active)){int tid=newNode(ch,"maker_win");NODES[id].children.push_back({v,tid});Res r{false,0,id};TT[k]=r;return r;}}
 U R=red.removed,Vcheck=s.avail;
 for(int v:mv){if(!(Vcheck>>v&1ULL)){rzSkips++;continue;}State ch{s.avail&~(1ULL<<v),s.active,s.black|(1ULL<<v),1};Res cr=breakerSearch(ch);NODES[id].children.push_back({v,cr.node});if(!cr.breaker){Res r{false,0,id};TT[k]=r;return r;}R|=cr.rzone;Vcheck&=cr.rzone;if(!Vcheck)break;}
 NODES[id].rzone=R;Res r{true,R,id};TT[k]={true,R&~red.removed,id};return r;
}
Res breakerSearch(State s){
 if(chrono::steady_clock::now()>DEADLINE){timedout=true;return {false,0,-2};}calls++;Key k{s.avail,s.active,s.black,1};auto it=TT.find(k);if(it!=TT.end()){ttHits++;return it->second;}
 Res term=terminalCheck(s,false,0);if(term.node!=-1){TT[k]=term;return term;}
 int id=newNode(s,"breaker_or");auto mv=moveList(s);
 for(int v:mv){State ch{s.avail&~(1ULL<<v),s.active&~CELL_LBITS[v],s.black,0};Res cr=makerSearch(ch);NODES[id].children.push_back({v,cr.node});if(cr.breaker){U R=(1ULL<<v)|cr.rzone;NODES[id].move=v;NODES[id].rzone=R;Res r{true,R,id};TT[k]=r;return r;}}
 Res r{false,0,id};TT[k]=r;return r;
}

void init(){set<U>ss;for(int r=0;r<N;r++)for(int c=0;c<N;c++)for(auto [dr,dc]:vector<pair<int,int>>{{1,0},{0,1},{1,1},{1,-1}}){int rr=r+4*dr,cc=c+4*dc;if(rr<0||rr>=N||cc<0||cc>=N)continue;U L=0;for(int i=0;i<K;i++)L|=1ULL<<((r+i*dr)*N+c+i*dc);ss.insert(L);}LINES.assign(ss.begin(),ss.end());CELL_LBITS.assign(C,0);CELL_LIDX.assign(C,{});for(int i=0;i<(int)LINES.size();i++)for(int c=0;c<C;c++)if(LINES[i]>>c&1ULL){CELL_LBITS[c]|=1ULL<<i;CELL_LIDX[c].push_back(i);}cerr<<"lines="<<LINES.size()<<"\n";}
int main(int argc,char**argv){init();int f=argc>1?stoi(argv[1]):24;double sec=argc>2?stod(argv[2]):300;int g=argc>3?stoi(argv[3]):-1;State root;bool fixed=(g>=0);if(fixed){root={FULL&~((1ULL<<f)|(1ULL<<g)),((1ULL<<LINES.size())-1)&~CELL_LBITS[g],1ULL<<f,0};}else{root={FULL&~(1ULL<<f),(LINES.size()==64?~0ULL:((1ULL<<LINES.size())-1)),1ULL<<f,1};}DEADLINE=chrono::steady_clock::now()+chrono::duration_cast<chrono::steady_clock::duration>(chrono::duration<double>(sec));auto st=chrono::steady_clock::now();Res r=fixed?makerSearch(root):breakerSearch(root);double tm=chrono::duration<double>(chrono::steady_clock::now()-st).count();cout<<"{\"f\":"<<f<<",\"g\":"<<g<<",\"breaker\":"<<(r.breaker?"true":"false")<<",\"timedout\":"<<(timedout?"true":"false")<<",\"calls\":"<<calls<<",\"tt\":"<<TT.size()<<",\"nodes\":"<<NODES.size()<<",\"pairCalls\":"<<pairCalls<<",\"pairFound\":"<<pairFound<<",\"potentialTerms\":"<<potentialTerms<<",\"reducePairs\":"<<reducePairs<<",\"domPrunes\":"<<domPrunes<<",\"rzSkips\":"<<rzSkips<<",\"seconds\":"<<tm<<"}\n";return r.breaker?0:1;}
