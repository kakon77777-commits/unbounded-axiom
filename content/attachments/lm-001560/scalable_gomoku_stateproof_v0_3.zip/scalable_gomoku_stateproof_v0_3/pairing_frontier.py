from __future__ import annotations

import argparse
import json
from pathlib import Path

from pairing_proof import _solve_matching_milp


def transform_index(n: int, index: int, t: int) -> int:
    r, c = divmod(index, n)
    m = n - 1
    if t == 0:
        rr, cc = r, c
    elif t == 1:
        rr, cc = c, m - r
    elif t == 2:
        rr, cc = m - r, m - c
    elif t == 3:
        rr, cc = m - c, r
    elif t == 4:
        rr, cc = r, m - c
    elif t == 5:
        rr, cc = m - r, c
    elif t == 6:
        rr, cc = c, r
    elif t == 7:
        rr, cc = m - c, m - r
    else:
        raise ValueError("t must be 0..7")
    return rr * n + cc


def symmetry_orbits(n: int) -> list[list[int]]:
    seen: set[int] = set()
    result: list[list[int]] = []
    for cell in range(n * n):
        if cell in seen:
            continue
        orbit = sorted({transform_index(n, cell, t) for t in range(8)})
        seen.update(orbit)
        result.append(orbit)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    records = []
    for orbit in symmetry_orbits(args.size):
        first = orbit[0]
        pairs = _solve_matching_milp(
            args.size,
            args.k,
            {first},
            set(),
        )
        records.append({
            "representative": first,
            "representative_rc": [first // args.size, first % args.size],
            "orbit": orbit,
            "orbit_size": len(orbit),
            "perfect_pairing_exists": pairs is not None,
            "pair_count": 0 if pairs is None else len(pairs),
        })

    payload = {
        "rules": {"size": args.size, "k": args.k},
        "test": (
            "After excluding the first move, can all remaining cells be perfectly "
            "paired so that every winning segment contains an entire pair?"
        ),
        "results": records,
        "warning": (
            "Infeasibility of this restricted certificate family is not a game-value "
            "proof. It only shows that the simplest static perfect-pair invariant does "
            "not extend to that opening orbit."
        ),
    }
    Path(args.out).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
