from __future__ import annotations

from dataclasses import dataclass, asdict
from itertools import combinations
from typing import Iterable, Optional

from solver import (
    EMPTY,
    Rules,
    all_k_segments,
    apply_move,
    legal_moves,
)


@dataclass(frozen=True)
class ThreatMetrics:
    player: int
    open_segments: int
    immediate_threat_segments: int
    immediate_completion_points: tuple[int, ...]
    immediate_hitting_number: int
    near_threat_sets: tuple[tuple[int, ...], ...]
    near_threat_hitting_number: Optional[int]
    near_threat_hitting_set: tuple[int, ...]
    fork_moves: tuple[int, ...]
    max_fork_width: int

    def to_dict(self) -> dict:
        return asdict(self)


def has_winning_line(board: tuple[int, ...], rules: Rules, player: int) -> bool:
    for segment in all_k_segments(rules):
        if all(board[i] == player for i in segment):
            return True
    return False


def winning_completion_points(
    board: tuple[int, ...],
    rules: Rules,
    player: int,
) -> set[int]:
    points: set[int] = set()
    for segment in all_k_segments(rules):
        values = [board[i] for i in segment]
        if -player in values:
            continue
        if values.count(player) == rules.k - 1 and values.count(EMPTY) == 1:
            points.add(segment[values.index(EMPTY)])
    return points


def open_segment_empty_sets(
    board: tuple[int, ...],
    rules: Rules,
    player: int,
    max_missing: Optional[int] = None,
    min_own: int = 1,
) -> list[frozenset[int]]:
    """Return empty-cell sets of unblocked winning segments.

    Duplicate empty sets are removed because they impose the same defense set.
    """
    family: set[frozenset[int]] = set()
    for segment in all_k_segments(rules):
        values = [board[i] for i in segment]
        if -player in values:
            continue
        own = values.count(player)
        empties = frozenset(i for i in segment if board[i] == EMPTY)
        if own < min_own or not empties:
            continue
        if max_missing is not None and len(empties) > max_missing:
            continue
        family.add(empties)
    return sorted(family, key=lambda s: (len(s), tuple(sorted(s))))


def minimum_hitting_set(
    family: Iterable[Iterable[int]],
    max_universe: int = 22,
) -> tuple[Optional[int], tuple[int, ...]]:
    """Exact minimum hitting set for small threat families.

    Returns (None, ()) when the universe is intentionally capped to avoid
    accidental combinatorial explosion.
    """
    normalized = [frozenset(s) for s in family if s]
    if not normalized:
        return 0, ()

    # Remove supersets: hitting a subset automatically hits its supersets.
    minimal: list[frozenset[int]] = []
    for s in sorted(set(normalized), key=lambda x: (len(x), tuple(sorted(x)))):
        if any(t <= s for t in minimal):
            continue
        minimal.append(s)

    universe = sorted(set().union(*minimal))
    if len(universe) > max_universe:
        return None, ()

    for size in range(1, len(universe) + 1):
        for candidate in combinations(universe, size):
            chosen = set(candidate)
            if all(chosen & threat for threat in minimal):
                return size, tuple(candidate)
    return None, ()


def fork_width_after_move(
    board: tuple[int, ...],
    rules: Rules,
    player: int,
    move: int,
) -> int:
    child = apply_move(board, move, player)
    return len(winning_completion_points(child, rules, player))


def fork_moves(
    board: tuple[int, ...],
    rules: Rules,
    player: int,
    minimum_width: int = 2,
) -> dict[int, int]:
    result: dict[int, int] = {}
    for move in legal_moves(board):
        width = fork_width_after_move(board, rules, player, move)
        if width >= minimum_width:
            result[move] = width
    return result


def threat_metrics(
    board: tuple[int, ...],
    rules: Rules,
    player: int,
    near_missing: int = 2,
) -> ThreatMetrics:
    immediate_points = winning_completion_points(board, rules, player)
    immediate_segments = open_segment_empty_sets(
        board,
        rules,
        player,
        max_missing=1,
        min_own=max(1, rules.k - 1),
    )
    near_family = open_segment_empty_sets(
        board,
        rules,
        player,
        max_missing=near_missing,
        min_own=max(1, rules.k - near_missing),
    )
    hitting_number, hitting_set = minimum_hitting_set(near_family)
    forks = fork_moves(board, rules, player)

    open_count = len(open_segment_empty_sets(
        board, rules, player, max_missing=None, min_own=1
    ))

    return ThreatMetrics(
        player=player,
        open_segments=open_count,
        immediate_threat_segments=len(immediate_segments),
        immediate_completion_points=tuple(sorted(immediate_points)),
        immediate_hitting_number=len(immediate_points),
        near_threat_sets=tuple(tuple(sorted(s)) for s in near_family),
        near_threat_hitting_number=hitting_number,
        near_threat_hitting_set=hitting_set,
        fork_moves=tuple(sorted(forks)),
        max_fork_width=max(forks.values(), default=0),
    )
