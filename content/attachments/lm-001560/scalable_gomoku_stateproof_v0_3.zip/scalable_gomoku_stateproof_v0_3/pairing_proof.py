from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path
from typing import Iterable


def winning_segments(n: int, k: int) -> list[tuple[int, ...]]:
    lines: list[tuple[int, ...]] = []
    for r in range(n):
        for c in range(n):
            for dr, dc in ((1, 0), (0, 1), (1, 1), (1, -1)):
                points = tuple((r + i * dr) * n + (c + i * dc) for i in range(k))
                coords = [(r + i * dr, c + i * dc) for i in range(k)]
                if all(0 <= rr < n and 0 <= cc < n for rr, cc in coords):
                    lines.append(points)
    return sorted(set(lines))


def _solve_matching_milp(
    n: int,
    k: int,
    unavailable: set[int],
    already_blocked: set[int],
) -> list[tuple[int, int]] | None:
    """Find a perfect matching whose pairs cover every unblocked winning line.

    SciPy/HiGHS is required only for certificate generation. Verification uses
    the standard library and does not trust the optimizer.
    """
    import numpy as np
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import lil_matrix, csr_matrix

    cells = [i for i in range(n * n) if i not in unavailable]
    if len(cells) % 2:
        return None

    pairs = list(combinations(cells, 2))
    constraints: list[list[int]] = []
    lower: list[float] = []
    upper: list[float] = []

    for cell in cells:
        indices = [j for j, pair in enumerate(pairs) if cell in pair]
        constraints.append(indices)
        lower.append(1.0)
        upper.append(1.0)

    for line in winning_segments(n, k):
        if set(line) & already_blocked:
            continue
        line_set = set(line)
        indices = [
            j for j, (a, b) in enumerate(pairs)
            if a in line_set and b in line_set
        ]
        if not indices:
            return None
        constraints.append(indices)
        lower.append(1.0)
        upper.append(float("inf"))

    matrix = lil_matrix((len(constraints), len(pairs)), dtype=float)
    for row, indices in enumerate(constraints):
        matrix.rows[row] = indices
        matrix.data[row] = [1.0] * len(indices)

    result = milp(
        c=np.zeros(len(pairs)),
        integrality=np.ones(len(pairs)),
        bounds=Bounds(np.zeros(len(pairs)), np.ones(len(pairs))),
        constraints=LinearConstraint(
            csr_matrix(matrix),
            np.array(lower),
            np.array(upper),
        ),
        options={"presolve": True},
    )
    if not result.success:
        return None
    return [pairs[i] for i, value in enumerate(result.x) if value > 0.5]


def generate_5x5_all_openings() -> dict:
    n = k = 5
    certificates: dict[str, dict] = {}
    for first in range(n * n):
        pairs = _solve_matching_milp(n, k, {first}, set())
        if pairs is None:
            raise RuntimeError(f"no 5x5 pairing found after first move {first}")
        certificates[str(first)] = {
            "first_move": first,
            "first_move_rc": [first // n, first % n],
            "pairs": [list(pair) for pair in sorted(pairs)],
            "recommended_initial_protect_move_for_second": pairs[0][0],
        }
    return {
        "format": "pairing-block-certificate-v1",
        "theorem_scope": "5x5 connect-5, at-least or exact-five (equivalent on this board)",
        "rules": {"size": n, "k": k},
        "certificate_type": "all_first_moves_perfect_pairing",
        "openings": certificates,
    }


def generate_6x6_central_draw(first_move: int = 14) -> dict:
    n, k = 6, 5
    all_cells = set(range(n * n))
    if first_move not in all_cells:
        raise ValueError("first move outside board")

    # White non-loss from the empty board: for every possible Black first move,
    # White has one preemptive blocking move and then a perfect pairing on the
    # 34 remaining cells.
    white_by_black_first: dict[str, dict] = {}
    for black_first in range(n * n):
        found = None
        for white_move in range(n * n):
            if white_move == black_first:
                continue
            pairs = _solve_matching_milp(
                n,
                k,
                {black_first, white_move},
                {white_move},
            )
            if pairs is not None:
                found = {
                    "black_first_move": black_first,
                    "black_first_move_rc": [black_first // n, black_first % n],
                    "white_first_move": white_move,
                    "white_first_move_rc": [white_move // n, white_move % n],
                    "pairs": [list(pair) for pair in sorted(pairs)],
                }
                break
        if found is None:
            raise RuntimeError(
                f"no White non-loss pairing after Black first move {black_first}"
            )
        white_by_black_first[str(black_first)] = found

    # Black non-loss witness: Black chooses the specified first move. After
    # every White first reply, Black obtains a perfect matching on the 34 empty
    # cells. Black's opening stone preblocks every White line containing it.
    black_replies: dict[str, dict] = {}
    for white_reply in range(n * n):
        if white_reply == first_move:
            continue
        pairs = _solve_matching_milp(
            n,
            k,
            {first_move, white_reply},
            {first_move},
        )
        if pairs is None:
            raise RuntimeError(
                f"no Black non-loss matching after White reply {white_reply}"
            )
        black_replies[str(white_reply)] = {
            "white_reply": white_reply,
            "white_reply_rc": [white_reply // n, white_reply % n],
            "black_initial_protect_move": pairs[0][0],
            "pairs": [list(pair) for pair in sorted(pairs)],
        }

    return {
        "format": "pairing-block-certificate-v1",
        "theorem_scope": "6x6 connect-5 draw from the empty board",
        "rules": {"size": n, "k": k},
        "certificate_type": "adaptive_two-sided_pairing_draw",
        "white_nonloss_by_black_first": white_by_black_first,
        "black_witness_first_move": first_move,
        "black_witness_first_move_rc": [first_move // n, first_move % n],
        "black_nonloss_by_white_reply": black_replies,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=["5x5-all", "6x6-central"], required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--first-move", type=int, default=14)
    args = parser.parse_args()

    if args.case == "5x5-all":
        certificate = generate_5x5_all_openings()
    else:
        certificate = generate_6x6_central_draw(args.first_move)

    Path(args.out).write_text(
        json.dumps(certificate, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({
        "out": args.out,
        "case": args.case,
        "size_bytes": Path(args.out).stat().st_size,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
