from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any
import argparse
import json


def certificate_stats(cert: dict[str, Any]) -> dict[str, Any]:
    counts = Counter()
    reasons = Counter()
    leaf_depths: list[int] = []

    def walk(node: dict[str, Any], depth: int) -> None:
        node_type = node["type"]
        counts[node_type] += 1
        if node_type == "terminal_proven":
            reasons[node["reason"]] += 1
            leaf_depths.append(depth)
            return
        if node_type == "OR":
            walk(node["child"], depth + 1)
            return
        if node_type == "AND":
            for item in node["children"]:
                walk(item["child"], depth + 1)
            return
        raise ValueError(f"unknown node type: {node_type}")

    walk(cert["tree"], 0)
    total = sum(counts.values())
    return {
        "total_certificate_nodes": total,
        "node_type_counts": dict(counts),
        "terminal_reason_counts": dict(reasons),
        "leaf_count": len(leaf_depths),
        "min_leaf_depth": min(leaf_depths) if leaf_depths else None,
        "max_leaf_depth": max(leaf_depths) if leaf_depths else None,
        "mean_leaf_depth": (
            sum(leaf_depths) / len(leaf_depths) if leaf_depths else None
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate")
    parser.add_argument("--out")
    args = parser.parse_args()

    cert = json.loads(Path(args.certificate).read_text(encoding="utf-8"))
    stats = certificate_stats(cert)
    text = json.dumps(stats, ensure_ascii=False, indent=2)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
