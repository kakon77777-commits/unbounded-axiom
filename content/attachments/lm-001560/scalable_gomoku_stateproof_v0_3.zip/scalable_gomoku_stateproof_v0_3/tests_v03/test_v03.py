from __future__ import annotations

import copy
import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from pairing_verify import verify_certificate


ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "v0_3"


class PairingCertificateTests(unittest.TestCase):
    def test_5x5_all_openings_certificate(self):
        cert = json.loads(
            (RESULTS / "5x5_k5_all_openings_pairing_certificate.json").read_text(
                encoding="utf-8"
            )
        )
        ok, message, details = verify_certificate(cert)
        self.assertTrue(ok, message)
        self.assertEqual(details["verified_openings"], 25)

    def test_6x6_draw_certificate(self):
        cert = json.loads(
            (RESULTS / "6x6_k5_draw_pairing_certificate.json").read_text(
                encoding="utf-8"
            )
        )
        ok, message, details = verify_certificate(cert)
        self.assertTrue(ok, message)
        self.assertEqual(details["white_first_move_cases_verified"], 36)
        self.assertEqual(details["black_reply_cases_verified"], 35)

    def test_mutated_certificate_fails(self):
        cert = json.loads(
            (RESULTS / "5x5_k5_all_openings_pairing_certificate.json").read_text(
                encoding="utf-8"
            )
        )
        broken = copy.deepcopy(cert)
        broken["openings"]["12"]["pairs"][0] = broken["openings"]["12"]["pairs"][1]
        ok, _, _ = verify_certificate(broken)
        self.assertFalse(ok)


class TablebaseTests(unittest.TestCase):
    def test_4x4_k4_exact_result(self):
        payload = json.loads(
            (RESULTS / "4x4_k4_exact_tablebase.json").read_text(encoding="utf-8")
        )
        self.assertEqual(payload["root"]["outcome"], "draw")
        self.assertEqual(len(payload["first_moves"]), 16)
        self.assertTrue(all(x["outcome"] == "draw" for x in payload["first_moves"]))
        self.assertGreater(payload["search"]["computed_states"], 9_000_000)

    def test_cpp_solver_reproduces_result(self):
        binary = ROOT / "cpp" / "connectk_tablebase"
        proc = subprocess.run(
            [str(binary), "--size", "4", "--k", "4"],
            check=True,
            capture_output=True,
            text=True,
            timeout=20,
        )
        payload = json.loads(proc.stdout)
        self.assertEqual(payload["root"]["value"], 0)
        self.assertTrue(all(x["value"] == 0 for x in payload["first_moves"]))


if __name__ == "__main__":
    unittest.main()
