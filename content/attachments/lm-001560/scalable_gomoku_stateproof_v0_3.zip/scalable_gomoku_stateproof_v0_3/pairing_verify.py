from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Iterable

from pairing_proof import winning_segments


def verify_matching(
    n: int,
    k: int,
    unavailable: set[int],
    already_blocked: set[int],
    pairs_raw: list[list[int]],
) -> tuple[bool, str, dict]:
    pairs: list[tuple[int, int]] = []
    used: set[int] = set()
    for raw in pairs_raw:
        if len(raw) != 2:
            return False, "a pair does not have exactly two endpoints", {}
        a, b = raw
        if a == b:
            return False, "self-pair detected", {}
        if not (0 <= a < n * n and 0 <= b < n * n):
            return False, "pair endpoint outside board", {}
        if a in unavailable or b in unavailable:
            return False, "pair uses an unavailable cell", {}
        if a in used or b in used:
            return False, "pairs are not disjoint", {}
        used.add(a)
        used.add(b)
        pairs.append((a, b))

    expected = set(range(n * n)) - unavailable
    if used != expected:
        return False, "matching is not perfect on the available cells", {
            "missing": sorted(expected - used),
            "extra": sorted(used - expected),
        }

    uncovered: list[list[int]] = []
    pair_sets = [set(pair) for pair in pairs]
    for line in winning_segments(n, k):
        line_set = set(line)
        if line_set & already_blocked:
            continue
        if not any(pair <= line_set for pair in pair_sets):
            uncovered.append(list(line))

    if uncovered:
        return False, "some winning lines are neither preblocked nor pair-covered", {
            "uncovered_lines": uncovered,
        }

    return True, "ok", {
        "pair_count": len(pairs),
        "winning_line_count": len(winning_segments(n, k)),
        "preblocked_cells": sorted(already_blocked),
    }


def verify_certificate(cert: dict) -> tuple[bool, str, dict]:
    n = cert["rules"]["size"]
    k = cert["rules"]["k"]
    kind = cert["certificate_type"]

    if kind == "all_first_moves_perfect_pairing":
        openings = cert["openings"]
        if set(map(int, openings.keys())) != set(range(n * n)):
            return False, "not every first move is covered", {}
        details = {}
        for key, entry in openings.items():
            first = int(key)
            ok, msg, info = verify_matching(
                n, k, {first}, set(), entry["pairs"]
            )
            if not ok:
                return False, f"opening {first}: {msg}", info
            initial = entry["recommended_initial_protect_move_for_second"]
            if initial == first or not (0 <= initial < n * n):
                return False, f"opening {first}: invalid initial protect move", {}
            details[key] = info
        return True, "ok", {
            "verified_openings": len(openings),
            "interpretation": (
                "For each first move, the remaining cells admit a perfect matching "
                "whose pair set intersects every winning line. Either player can use "
                "the matching as a response invariant to prevent the opponent from "
                "owning a complete winning line."
            ),
        }

    if kind == "adaptive_two-sided_pairing_draw":
        white_cases = cert["white_nonloss_by_black_first"]
        expected_first_moves = set(range(n * n))
        if set(map(int, white_cases.keys())) != expected_first_moves:
            return False, "White strategy does not cover every Black first move", {}

        for key, white in white_cases.items():
            black_first = int(key)
            white_move = white["white_first_move"]
            if white_move == black_first:
                return False, "White preemptive move equals Black first move", {}
            ok, msg, info = verify_matching(
                n,
                k,
                {black_first, white_move},
                {white_move},
                white["pairs"],
            )
            if not ok:
                return False, f"White strategy after Black {black_first}: {msg}", info

        first = cert["black_witness_first_move"]
        replies = cert["black_nonloss_by_white_reply"]
        expected_replies = set(range(n * n)) - {first}
        if set(map(int, replies.keys())) != expected_replies:
            return False, "Black strategy does not cover every White reply", {}

        for key, entry in replies.items():
            white_reply = int(key)
            ok, msg, info = verify_matching(
                n,
                k,
                {first, white_reply},
                {first},
                entry["pairs"],
            )
            if not ok:
                return False, f"Black strategy after White {white_reply}: {msg}", info
            initial = entry["black_initial_protect_move"]
            paired_cells = {x for pair in entry["pairs"] for x in pair}
            if initial not in paired_cells:
                return False, "Black initial protect move is not in matching", {}

        return True, "ok", {
            "white_first_move_cases_verified": len(white_cases),
            "black_witness_first_move": first,
            "black_reply_cases_verified": len(replies),
            "interpretation": (
                "White has a preemptive-block plus pairing strategy after every "
                "possible Black first move, so Black cannot force a win. Black has "
                "one first-move witness and a pairing strategy after every White "
                "reply, so White cannot force a win. Hence the empty-board game is "
                "a draw."
            ),
        }

    return False, f"unknown certificate type: {kind}", {}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("certificate")
    parser.add_argument("--json-out")
    args = parser.parse_args()

    cert = json.loads(Path(args.certificate).read_text(encoding="utf-8"))
    ok, message, details = verify_certificate(cert)
    result = {"ok": ok, "message": message, "details": details}
    text = json.dumps(result, ensure_ascii=False, indent=2)
    print(text)
    if args.json_out:
        Path(args.json_out).write_text(text + "\n", encoding="utf-8")
    if not ok:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
