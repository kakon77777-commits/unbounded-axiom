import unittest

from solver import BLACK, WHITE, EMPTY, Rules, apply_move, idx
from threats import (
    minimum_hitting_set,
    threat_metrics,
    winning_completion_points,
)
from pns import TacticalProofNumberSearch, verify_win_certificate
from opening_analysis import move_orbits


class ThreatTests(unittest.TestCase):
    def test_minimum_hitting_set(self):
        number, chosen = minimum_hitting_set([{1, 2}, {2, 3}, {2, 4}])
        self.assertEqual(number, 1)
        self.assertEqual(chosen, (2,))

    def test_two_completion_points(self):
        rules = Rules(4, 3)
        board = (
            EMPTY, EMPTY, EMPTY, EMPTY,
            EMPTY, BLACK, BLACK, EMPTY,
            EMPTY, EMPTY, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY, EMPTY,
        )
        points = winning_completion_points(board, rules, BLACK)
        self.assertEqual(points, {idx(4, 1, 0), idx(4, 1, 3)})

    def test_threat_metrics_fork(self):
        rules = Rules(4, 3)
        board = (
            EMPTY, BLACK, EMPTY, EMPTY,
            BLACK, EMPTY, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY, EMPTY,
            EMPTY, EMPTY, EMPTY, EMPTY,
        )
        metrics = threat_metrics(board, rules, BLACK)
        self.assertGreaterEqual(metrics.open_segments, 1)


class PNSTests(unittest.TestCase):
    def test_3x3_connect3_disproves_forced_win(self):
        search = TacticalProofNumberSearch(Rules(3, 3), root_player=BLACK)
        result, _ = search.solve(max_nodes=10000, max_seconds=5)
        self.assertEqual(result.status, "disproven_win")

    def test_4x4_connect3_proven_win(self):
        search = TacticalProofNumberSearch(Rules(4, 3), root_player=BLACK)
        result, root = search.solve(max_nodes=10000, max_seconds=5)
        self.assertEqual(result.status, "proven_win")
        cert = search.build_win_certificate(root)
        ok, message = verify_win_certificate(cert)
        self.assertTrue(ok, message)

    def test_opening_orbits_4x4(self):
        orbits = move_orbits(4)
        self.assertEqual(sorted(len(o) for o in orbits), [4, 4, 8])


if __name__ == "__main__":
    unittest.main()
