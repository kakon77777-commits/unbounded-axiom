from __future__ import annotations

from dataclasses import dataclass, field, asdict
from math import inf
from time import perf_counter
from typing import Optional, Any
import argparse
import json

from solver import (
    BLACK,
    WHITE,
    EMPTY,
    Rules,
    apply_move,
    board_to_rows,
    canonical_board,
    legal_moves,
    line_degree,
    rc,
)
from threats import has_winning_line, winning_completion_points, fork_width_after_move


@dataclass
class PNSNode:
    board: tuple[int, ...]
    turn: int
    parent: Optional["PNSNode"] = None
    move: Optional[int] = None
    children: list["PNSNode"] = field(default_factory=list)
    covered_moves: dict[int, tuple[int, ...]] = field(default_factory=dict)
    expanded: bool = False
    proof: float = 1
    disproof: float = 1
    terminal_reason: Optional[str] = None


@dataclass(frozen=True)
class PNSResult:
    status: str
    proof_number: float
    disproof_number: float
    iterations: int
    nodes: int
    elapsed_sec: float
    witness_move: Optional[int]
    root_player: int
    player_to_move: int

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["proof_number"] = "inf" if self.proof_number == inf else self.proof_number
        data["disproof_number"] = "inf" if self.disproof_number == inf else self.disproof_number
        return data


class TacticalProofNumberSearch:
    """Proof-number search for the proposition: root_player can force a win.

    Sound tactical reductions:
      * an available immediate win resolves the node;
      * two distinct immediate completion points are an unanswerable fork if
        the defender has no immediate counter-win;
      * under one immediate threat, only the blocking point is relevant;
      * D4-equivalent children are represented once and recorded as an orbit.
    """

    def __init__(
        self,
        rules: Rules,
        root_player: int = BLACK,
        use_symmetry: bool = True,
    ) -> None:
        self.rules = rules
        self.root_player = root_player
        self.use_symmetry = use_symmetry
        self.nodes = 0
        self.iterations = 0
        self._degree = line_degree(rules)
        self._center = (rules.size - 1) / 2

    def _terminal_status(self, node: PNSNode) -> tuple[Optional[bool], Optional[str]]:
        board = node.board
        root = self.root_player
        opponent = -root

        if has_winning_line(board, self.rules, root):
            return True, "root_has_winning_line"
        if has_winning_line(board, self.rules, opponent):
            return False, "opponent_has_winning_line"
        if not legal_moves(board):
            return False, "full_board_without_root_win"

        root_wins = winning_completion_points(board, self.rules, root)
        opp_wins = winning_completion_points(board, self.rules, opponent)

        if node.turn == root:
            if root_wins:
                return True, "root_immediate_win_available"
            if len(opp_wins) >= 2:
                return False, "opponent_double_immediate_threat"
        else:
            if opp_wins:
                return False, "opponent_immediate_win_available"
            if len(root_wins) >= 2:
                return True, "root_double_immediate_threat"

        return None, None

    def _set_numbers(self, node: PNSNode) -> None:
        status, reason = self._terminal_status(node)
        node.terminal_reason = reason
        if status is True:
            node.proof, node.disproof = 0, inf
            return
        if status is False:
            node.proof, node.disproof = inf, 0
            return
        if not node.expanded:
            node.proof = node.disproof = 1
            return

        if node.turn == self.root_player:  # OR
            node.proof = min(child.proof for child in node.children)
            node.disproof = sum(child.disproof for child in node.children)
        else:  # AND
            node.proof = sum(child.proof for child in node.children)
            node.disproof = min(child.disproof for child in node.children)

    def _candidate_moves(self, node: PNSNode) -> list[int]:
        board = node.board
        root_wins = winning_completion_points(board, self.rules, self.root_player)
        opp_wins = winning_completion_points(board, self.rules, -self.root_player)

        # Immediate terminal cases are handled before expansion.
        if node.turn == self.root_player and len(opp_wins) == 1:
            return sorted(opp_wins)
        if node.turn != self.root_player and len(root_wins) == 1:
            return sorted(root_wins)
        return self._ordered_moves(board, node.turn)

    def _ordered_moves(self, board: tuple[int, ...], player: int) -> list[int]:
        scored: list[tuple[tuple[float, ...], int]] = []
        for move in legal_moves(board):
            r, c = rc(self.rules.size, move)
            child = apply_move(board, move, player)
            own_fork = fork_width_after_move(board, self.rules, player, move)
            opponent_fork = fork_width_after_move(board, self.rules, -player, move)
            centrality = abs(r - self._center) + abs(c - self._center)
            score = (
                -own_fork,
                opponent_fork,
                -self._degree[move],
                centrality,
                move,
            )
            scored.append((score, move))
        scored.sort()
        return [move for _, move in scored]

    def _expand(self, node: PNSNode) -> None:
        candidate_moves = self._candidate_moves(node)
        orbit_by_key: dict[tuple[int, ...], list[int]] = {}
        board_by_key: dict[tuple[int, ...], tuple[int, ...]] = {}
        representative_by_key: dict[tuple[int, ...], int] = {}

        for move in candidate_moves:
            child_board = apply_move(node.board, move, node.turn)
            key = (
                canonical_board(child_board, self.rules.size)
                if self.use_symmetry else child_board
            )
            orbit_by_key.setdefault(key, []).append(move)
            board_by_key.setdefault(key, child_board)
            representative_by_key.setdefault(key, move)

        for key in sorted(orbit_by_key, key=lambda x: x):
            representative = representative_by_key[key]
            child = PNSNode(
                board=board_by_key[key],
                turn=-node.turn,
                parent=node,
                move=representative,
            )
            self._set_numbers(child)
            node.children.append(child)
            node.covered_moves[representative] = tuple(sorted(orbit_by_key[key]))
            self.nodes += 1

        node.expanded = True
        self._set_numbers(node)

    def _select_most_proving(self, root: PNSNode) -> PNSNode:
        node = root
        while (
            node.expanded
            and node.children
            and node.proof not in (0, inf)
            and node.disproof not in (0, inf)
        ):
            if node.turn == self.root_player:
                node = min(node.children, key=lambda child: child.proof)
            else:
                node = min(node.children, key=lambda child: child.disproof)
        return node

    def _update_ancestors(self, node: Optional[PNSNode]) -> None:
        while node is not None:
            self._set_numbers(node)
            node = node.parent

    def solve(
        self,
        board: Optional[tuple[int, ...]] = None,
        player_to_move: int = BLACK,
        max_nodes: int = 250_000,
        max_seconds: float = 30.0,
    ) -> tuple[PNSResult, PNSNode]:
        if board is None:
            board = (EMPTY,) * (self.rules.size * self.rules.size)

        self.nodes = 1
        self.iterations = 0
        root = PNSNode(board=board, turn=player_to_move)
        self._set_numbers(root)
        started = perf_counter()

        while root.proof != 0 and root.disproof != 0:
            if self.nodes >= max_nodes:
                break
            if perf_counter() - started >= max_seconds:
                break
            leaf = self._select_most_proving(root)
            self._expand(leaf)
            self._update_ancestors(leaf.parent)
            self.iterations += 1

        elapsed = perf_counter() - started
        if root.proof == 0:
            status = "proven_win"
        elif root.disproof == 0:
            status = "disproven_win"
        else:
            status = "unresolved"

        witness_move: Optional[int] = None
        if root.terminal_reason == "root_immediate_win_available":
            witness_move = min(winning_completion_points(board, self.rules, self.root_player))
        elif root.children and player_to_move == self.root_player:
            candidates = [c for c in root.children if c.proof == 0]
            if candidates:
                witness_move = candidates[0].move

        result = PNSResult(
            status=status,
            proof_number=root.proof,
            disproof_number=root.disproof,
            iterations=self.iterations,
            nodes=self.nodes,
            elapsed_sec=elapsed,
            witness_move=witness_move,
            root_player=self.root_player,
            player_to_move=player_to_move,
        )
        return result, root

    def build_win_certificate(self, root: PNSNode) -> dict[str, Any]:
        if root.proof != 0:
            raise ValueError("root is not a proven win")

        def encode(node: PNSNode) -> dict[str, Any]:
            status, reason = self._terminal_status(node)
            base = {
                "board": board_to_rows(node.board, self.rules.size),
                "turn": "black" if node.turn == BLACK else "white",
            }
            if status is True:
                root_completions = sorted(
                    winning_completion_points(node.board, self.rules, self.root_player)
                )
                return {
                    **base,
                    "type": "terminal_proven",
                    "reason": reason,
                    "root_completion_points": root_completions,
                }

            if node.turn == self.root_player:
                child = min(
                    (child for child in node.children if child.proof == 0),
                    key=lambda child: child.move if child.move is not None else -1,
                )
                return {
                    **base,
                    "type": "OR",
                    "chosen_move": child.move,
                    "child": encode(child),
                }

            children_payload = []
            for child in node.children:
                if child.proof != 0:
                    raise ValueError("proven AND node contains an unproven child")
                children_payload.append({
                    "representative_move": child.move,
                    "covered_moves": list(node.covered_moves.get(child.move, (child.move,))),
                    "child": encode(child),
                })
            return {
                **base,
                "type": "AND",
                "children": children_payload,
            }

        return {
            "format": "tactical-pns-win-certificate-v1",
            "rules": {
                "size": self.rules.size,
                "k": self.rules.k,
                "win_mode": self.rules.win_mode,
            },
            "root_player": "black" if self.root_player == BLACK else "white",
            "tree": encode(root),
        }


def verify_win_certificate(cert: dict[str, Any]) -> tuple[bool, str]:
    rules_data = cert["rules"]
    rules = Rules(rules_data["size"], rules_data["k"], rules_data["win_mode"])
    root_player = BLACK if cert["root_player"] == "black" else WHITE
    symbol = {".": EMPTY, "X": BLACK, "O": WHITE}

    def rows_to_board(rows: list[str]) -> tuple[int, ...]:
        return tuple(symbol[ch] for row in rows for ch in row)

    def candidate_moves(board: tuple[int, ...], turn: int) -> set[int]:
        root_wins = winning_completion_points(board, rules, root_player)
        opp_wins = winning_completion_points(board, rules, -root_player)
        if turn == root_player and len(opp_wins) == 1:
            return set(opp_wins)
        if turn != root_player and len(root_wins) == 1:
            return set(root_wins)
        return set(legal_moves(board))

    def verify_node(node: dict[str, Any], expected_board: Optional[tuple[int, ...]] = None):
        board = rows_to_board(node["board"])
        if expected_board is not None and board != expected_board:
            return False, "board transition mismatch"
        turn = BLACK if node["turn"] == "black" else WHITE

        if node["type"] == "terminal_proven":
            reason = node["reason"]
            if reason == "root_has_winning_line":
                return (
                    (True, "ok") if has_winning_line(board, rules, root_player)
                    else (False, "missing root winning line")
                )
            root_points = winning_completion_points(board, rules, root_player)
            opp_points = winning_completion_points(board, rules, -root_player)
            if reason == "root_immediate_win_available":
                if turn != root_player or not root_points:
                    return False, "invalid immediate-win terminal"
                return True, "ok"
            if reason == "root_double_immediate_threat":
                if turn == root_player or len(root_points) < 2 or opp_points:
                    return False, "invalid double-threat terminal"
                return True, "ok"
            return False, f"unsupported proven terminal reason: {reason}"

        if node["type"] == "OR":
            if turn != root_player:
                return False, "OR node is not root player's turn"
            move = node["chosen_move"]
            allowed = candidate_moves(board, turn)
            if move not in allowed:
                return False, "chosen OR move violates forced-defense policy"
            child_board = apply_move(board, move, turn)
            return verify_node(node["child"], child_board)

        if node["type"] == "AND":
            if turn == root_player:
                return False, "AND node is root player's turn"
            required = candidate_moves(board, turn)
            covered: set[int] = set()
            for item in node["children"]:
                rep = item["representative_move"]
                orbit = set(item["covered_moves"])
                if rep not in orbit:
                    return False, "representative not in its orbit"
                if not orbit <= required:
                    return False, "certificate covers an inadmissible move"
                rep_board = apply_move(board, rep, turn)
                rep_key = canonical_board(rep_board, rules.size)
                for move in orbit:
                    child_key = canonical_board(apply_move(board, move, turn), rules.size)
                    if child_key != rep_key:
                        return False, "claimed symmetry orbit is invalid"
                ok, message = verify_node(item["child"], rep_board)
                if not ok:
                    return ok, message
                covered |= orbit
            if covered != required:
                return False, "AND node does not cover every required reply"
            return True, "ok"

        return False, "unknown certificate node type"

    return verify_node(cert["tree"])


def main() -> None:
    parser = argparse.ArgumentParser(description="Tactical proof-number search for scalable connect-k.")
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--win-mode", choices=["at_least", "exact"], default="at_least")
    parser.add_argument("--max-nodes", type=int, default=250000)
    parser.add_argument("--max-seconds", type=float, default=30.0)
    parser.add_argument("--certificate-out")
    args = parser.parse_args()

    rules = Rules(args.size, args.k, args.win_mode)
    search = TacticalProofNumberSearch(rules, root_player=BLACK)
    result, root = search.solve(max_nodes=args.max_nodes, max_seconds=args.max_seconds)
    payload: dict[str, Any] = {"result": result.to_dict()}

    if result.status == "proven_win" and args.certificate_out:
        cert = search.build_win_certificate(root)
        ok, message = verify_win_certificate(cert)
        with open(args.certificate_out, "w", encoding="utf-8") as f:
            json.dump(cert, f, ensure_ascii=False, indent=2)
        payload["certificate"] = {
            "path": args.certificate_out,
            "verified": ok,
            "message": message,
        }

    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
