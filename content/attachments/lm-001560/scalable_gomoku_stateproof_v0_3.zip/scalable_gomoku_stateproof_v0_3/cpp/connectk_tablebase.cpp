#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>

using namespace std;

struct Solver {
    int n;
    int k;
    int cells;
    int states;
    vector<uint32_t> win_masks;
    vector<int8_t> memo;      // 2 unknown, -1 loss, 0 draw, 1 win
    vector<uint8_t> distance; // tie policy documented in output
    vector<int> move_order;
    uint64_t nodes = 0;
    uint64_t hits = 0;

    explicit Solver(int board_size, int connect_k)
        : n(board_size), k(connect_k), cells(n * n) {
        if (n < 1 || n > 4) {
            throw invalid_argument("exact ternary tablebase currently supports 1 <= n <= 4");
        }
        if (k < 1 || k > n) {
            throw invalid_argument("k must satisfy 1 <= k <= n");
        }
        states = 1;
        for (int i = 0; i < cells; ++i) states *= 3;
        memo.assign(states, 2);
        distance.assign(states, 0);
        build_masks();
        build_move_order();
    }

    int index(int r, int c) const { return r * n + c; }

    void build_masks() {
        static const int dirs[4][2] = {{1,0},{0,1},{1,1},{1,-1}};
        for (int r = 0; r < n; ++r) {
            for (int c = 0; c < n; ++c) {
                for (auto &d : dirs) {
                    int er = r + (k - 1) * d[0];
                    int ec = c + (k - 1) * d[1];
                    if (er < 0 || er >= n || ec < 0 || ec >= n) continue;
                    uint32_t mask = 0;
                    for (int i = 0; i < k; ++i) {
                        mask |= uint32_t(1) << index(r + i * d[0], c + i * d[1]);
                    }
                    win_masks.push_back(mask);
                }
            }
        }
        sort(win_masks.begin(), win_masks.end());
        win_masks.erase(unique(win_masks.begin(), win_masks.end()), win_masks.end());
    }

    void build_move_order() {
        double center = (n - 1) / 2.0;
        vector<tuple<double, int>> ranked;
        for (int i = 0; i < cells; ++i) {
            int r = i / n, c = i % n;
            double d = abs(r - center) + abs(c - center);
            ranked.emplace_back(d, i);
        }
        sort(ranked.begin(), ranked.end());
        for (auto [_, i] : ranked) move_order.push_back(i);
    }

    bool has_win(uint32_t stones) const {
        for (uint32_t mask : win_masks) {
            if ((stones & mask) == mask) return true;
        }
        return false;
    }

    int encode(uint32_t current, uint32_t opponent) const {
        int code = 0;
        for (int i = cells - 1; i >= 0; --i) {
            code *= 3;
            uint32_t bit = uint32_t(1) << i;
            if (current & bit) code += 1;
            else if (opponent & bit) code += 2;
        }
        return code;
    }

    pair<int, int> solve(uint32_t current, uint32_t opponent, int code) {
        int8_t cached = memo[code];
        if (cached != 2) {
            ++hits;
            return {cached, distance[code]};
        }
        ++nodes;
        uint32_t occupied = current | opponent;
        const uint32_t full = (cells == 32) ? 0xffffffffu : ((uint32_t(1) << cells) - 1u);
        if (occupied == full) {
            memo[code] = 0;
            distance[code] = 0;
            return {0, 0};
        }

        int best = -2;
        int best_distance = 0;
        for (int move : move_order) {
            uint32_t bit = uint32_t(1) << move;
            if (occupied & bit) continue;
            uint32_t current2 = current | bit;
            int value;
            int d;
            if (has_win(current2)) {
                value = 1;
                d = 1;
            } else {
                int child_code = encode(opponent, current2);
                auto child = solve(opponent, current2, child_code);
                value = -child.first;
                d = child.second + 1;
            }

            if (value > best) {
                best = value;
                best_distance = d;
            } else if (value == best) {
                if (value >= 0) best_distance = min(best_distance, d);
                else best_distance = max(best_distance, d);
            }
        }

        memo[code] = static_cast<int8_t>(best);
        distance[code] = static_cast<uint8_t>(best_distance);
        return {best, best_distance};
    }

    vector<tuple<int,int,int>> first_move_values() {
        vector<tuple<int,int,int>> out;
        for (int move = 0; move < cells; ++move) {
            uint32_t black = uint32_t(1) << move;
            int child_code = encode(0, black); // white to move
            auto child = solve(0, black, child_code);
            out.emplace_back(move, -child.first, child.second + 1);
        }
        return out;
    }

    array<uint64_t,4> value_counts() const {
        // unknown, loss, draw, win
        array<uint64_t,4> c{0,0,0,0};
        for (int8_t v : memo) {
            if (v == 2) ++c[0];
            else if (v == -1) ++c[1];
            else if (v == 0) ++c[2];
            else if (v == 1) ++c[3];
        }
        return c;
    }
};

static string value_name(int v) {
    if (v > 0) return "win";
    if (v < 0) return "loss";
    return "draw";
}

int main(int argc, char** argv) {
    int n = 4;
    int k = 4;
    string out_path;
    for (int i = 1; i < argc; ++i) {
        string arg = argv[i];
        if (arg == "--size" && i + 1 < argc) n = atoi(argv[++i]);
        else if (arg == "--k" && i + 1 < argc) k = atoi(argv[++i]);
        else if (arg == "--json-out" && i + 1 < argc) out_path = argv[++i];
        else {
            cerr << "unknown or incomplete argument: " << arg << "\n";
            return 2;
        }
    }

    try {
        Solver solver(n, k);
        auto started = chrono::steady_clock::now();
        auto root = solver.solve(0, 0, 0);
        double elapsed = chrono::duration<double>(chrono::steady_clock::now() - started).count();
        auto first = solver.first_move_values();
        auto counts = solver.value_counts();

        string json;
        json += "{\n";
        json += "  \"solver\": \"exact_ternary_tablebase_cpp_v1\",\n";
        json += "  \"rules\": {\"size\": " + to_string(n) + ", \"k\": " + to_string(k) + ", \"win_mode\": \"at_least\"},\n";
        json += "  \"root\": {\"value\": " + to_string(root.first) + ", \"outcome\": \"" + value_name(root.first) + "\", \"distance_plies\": " + to_string(root.second) + "},\n";
        json += "  \"search\": {\"ternary_state_capacity\": " + to_string(solver.states) + ", \"computed_states\": " + to_string(solver.nodes) + ", \"cache_hits\": " + to_string(solver.hits) + ", \"elapsed_sec\": " + to_string(elapsed) + "},\n";
        json += "  \"memo_value_counts\": {\"unknown\": " + to_string(counts[0]) + ", \"loss\": " + to_string(counts[1]) + ", \"draw\": " + to_string(counts[2]) + ", \"win\": " + to_string(counts[3]) + "},\n";
        json += "  \"distance_policy\": \"shortest win, shortest draw, longest forced loss under the stored minimax recursion\",\n";
        json += "  \"first_moves\": [\n";
        for (size_t i = 0; i < first.size(); ++i) {
            auto [move, value, dist] = first[i];
            int r = move / n, c = move % n;
            json += "    {\"index\": " + to_string(move) + ", \"row\": " + to_string(r) + ", \"col\": " + to_string(c) + ", \"value\": " + to_string(value) + ", \"outcome\": \"" + value_name(value) + "\", \"distance_plies\": " + to_string(dist) + "}";
            json += (i + 1 == first.size()) ? "\n" : ",\n";
        }
        json += "  ]\n";
        json += "}\n";

        cout << json;
        if (!out_path.empty()) {
            ofstream out(out_path);
            if (!out) throw runtime_error("cannot open output path");
            out << json;
        }
    } catch (const exception& e) {
        cerr << e.what() << "\n";
        return 1;
    }
    return 0;
}
