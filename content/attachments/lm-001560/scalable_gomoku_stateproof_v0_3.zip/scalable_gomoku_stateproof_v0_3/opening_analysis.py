from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any
import argparse
import csv
import json

from solver import (
    BLACK,
    WHITE,
    EMPTY,
    Rules,
    apply_move,
    canonical_board,
    idx,
    line_degree,
    rc,
    transform_index,
)
from pns import TacticalProofNumberSearch
from threats import threat_metrics


def move_orbits(size: int) -> list[tuple[int, ...]]:
    remaining = set(range(size * size))
    orbits: list[tuple[int, ...]] = []
    while remaining:
        seed = min(remaining)
        orbit = tuple(sorted({transform_index(size, seed, t) for t in range(8)}))
        orbits.append(orbit)
        remaining -= set(orbit)
    return orbits


def analyze_openings(
    rules: Rules,
    max_nodes: int = 250000,
    max_seconds: float = 30.0,
) -> list[dict[str, Any]]:
    empty = (EMPTY,) * (rules.size * rules.size)
    degree = line_degree(rules)
    center = (rules.size - 1) / 2
    results: list[dict[str, Any]] = []

    for orbit in move_orbits(rules.size):
        move = orbit[0]
        board = apply_move(empty, move, BLACK)
        search = TacticalProofNumberSearch(rules, root_player=BLACK)
        pns_result, _ = search.solve(
            board=board,
            player_to_move=WHITE,
            max_nodes=max_nodes,
            max_seconds=max_seconds,
        )
        r, c = rc(rules.size, move)
        black_metrics = threat_metrics(board, rules, BLACK).to_dict()
        results.append({
            "representative_move": move,
            "row": r,
            "col": c,
            "orbit": list(orbit),
            "orbit_size": len(orbit),
            "line_degree": degree[move],
            "manhattan_distance_to_center": abs(r - center) + abs(c - center),
            "black_threat_metrics_after_opening": black_metrics,
            "pns": pns_result.to_dict(),
        })
    return results


def write_markdown(results: list[dict[str, Any]], rules: Rules, path: Path) -> None:
    lines = [
        f"# {rules.size}×{rules.size} 連 {rules.k} 首手對稱軌道分析",
        "",
        "| 代表點 | 軌道大小 | 勝線度數 | 距中心 | 黑方可強制勝 | PNS 節點 | 迭代 |",
        "|---:|---:|---:|---:|---|---:|---:|",
    ]
    for item in results:
        pns = item["pns"]
        status = {
            "proven_win": "是",
            "disproven_win": "否",
            "unresolved": "未解",
        }[pns["status"]]
        lines.append(
            f"| ({item['row']},{item['col']}) | {item['orbit_size']} | "
            f"{item['line_degree']} | {item['manhattan_distance_to_center']:.1f} | "
            f"{status} | {pns['nodes']} | {pns['iterations']} |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--size", type=int, required=True)
    parser.add_argument("--k", type=int, required=True)
    parser.add_argument("--win-mode", choices=["at_least", "exact"], default="at_least")
    parser.add_argument("--max-nodes", type=int, default=250000)
    parser.add_argument("--max-seconds", type=float, default=30.0)
    parser.add_argument("--json-out", required=True)
    parser.add_argument("--csv-out")
    parser.add_argument("--md-out")
    args = parser.parse_args()

    rules = Rules(args.size, args.k, args.win_mode)
    results = analyze_openings(rules, args.max_nodes, args.max_seconds)
    Path(args.json_out).write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    if args.csv_out:
        with open(args.csv_out, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "representative_move", "row", "col", "orbit_size",
                "line_degree", "manhattan_distance_to_center", "status",
                "nodes", "iterations", "elapsed_sec",
            ])
            writer.writeheader()
            for item in results:
                pns = item["pns"]
                writer.writerow({
                    "representative_move": item["representative_move"],
                    "row": item["row"],
                    "col": item["col"],
                    "orbit_size": item["orbit_size"],
                    "line_degree": item["line_degree"],
                    "manhattan_distance_to_center": item["manhattan_distance_to_center"],
                    "status": pns["status"],
                    "nodes": pns["nodes"],
                    "iterations": pns["iterations"],
                    "elapsed_sec": pns["elapsed_sec"],
                })

    if args.md_out:
        write_markdown(results, rules, Path(args.md_out))

    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
