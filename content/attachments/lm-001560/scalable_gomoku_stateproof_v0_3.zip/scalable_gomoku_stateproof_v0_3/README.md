# Scalable Gomoku State-Proof v0.3

這是一個研究「自訂伸縮棋盤上的廣義連 $k$ 遊戲」的精確求解與不變量證明框架。

v0.3 的主要轉向是：

$$
\text{只擴大狀態樹}
\quad\longrightarrow\quad
\text{狀態表庫＋小型結構證書}
$$

## 本輪正式結果

### $4\times4$ 連四

完整 C++ 三進位表庫求得：

$$
\boxed{V(G(4,4))=0}
$$

全部 $16$ 個第一手均為和局。

### $5\times5$ 連五

對全部 $25$ 個第一手，各找到一份完美配對阻斷證書：

$$
\boxed{V(G(5,5))=0}
$$

### $6\times6$ 連五

找到雙向適應性配對證書：

- 白方對黑方全部 $36$ 個第一手均有非敗策略；
- 黑方選擇第一手 $14$，對白方全部 $35$ 個回應均有非敗策略。

因此：

$$
\boxed{V(G(6,5))=0}
$$

### $7\times7$ 連五前沿

最簡單的靜態完美配對證書在全部 $10$ 個第一手對稱軌道上均不可行。這不是遊戲值證明，只表示需要更高階不變量或搜尋方法。

## 核心不變量

對配對集合：

$$
M=\{\{u_1,v_1\},\ldots,\{u_m,v_m\}\}
$$

回應策略保持：

$$
I_M(t):
\quad
\forall\{u,v\}\in M,
\qquad
\neg(u,v\in S_{\mathrm{opponent}}(t))
$$

若每一條勝線都已被防守棋子占據，或包含一整個配對，則對手永遠不能完成勝線。

詳見：

- `docs/pairing_invariant_theorem.md`
- `docs/v0_3_theory.md`

## 主要檔案

### v0.1／v0.2 保留內容

- `solver.py`：小棋盤 Python 精確 Negamax；
- `pns.py`：Tactical Proof-Number Search；
- `threats.py`：立即威脅與分叉分析；
- `certificate.py`：小棋盤 AND–OR 證書；
- `opening_analysis.py`：首手軌道比較。

### v0.3 新增

- `cpp/connectk_tablebase.cpp`：$n\leq4$ 的精確三進位表庫；
- `pairing_proof.py`：使用 MILP 產生配對證書；
- `pairing_verify.py`：只依賴標準函式庫的獨立驗證器；
- `pairing_frontier.py`：測試靜態配對證書的尺度前沿；
- `tests_v03/test_v03.py`：v0.3 回歸與破壞測試。

## 執行

### 編譯並重算 $4\times4$ 連四

```bash
g++ -O3 -std=c++20 cpp/connectk_tablebase.cpp -o cpp/connectk_tablebase
cpp/connectk_tablebase --size 4 --k 4
```

### 驗證 $5\times5$ 證書

```bash
python pairing_verify.py \
  results/v0_3/5x5_k5_all_openings_pairing_certificate.json
```

### 驗證 $6\times6$ 證書

```bash
python pairing_verify.py \
  results/v0_3/6x6_k5_draw_pairing_certificate.json
```

### 重新生成配對證書

生成器需要 SciPy／HiGHS：

```bash
python pairing_proof.py \
  --case 5x5-all \
  --out results/v0_3/5x5_k5_all_openings_pairing_certificate.json

python pairing_proof.py \
  --case 6x6-central \
  --first-move 14 \
  --out results/v0_3/6x6_k5_draw_pairing_certificate.json
```

驗證器不需要 SciPy。

### 執行測試

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s tests_v03 -v
```

## 研究結論的當前形態

低尺度資料不支持：

$$
\text{中央首手}
\Longrightarrow
\text{必勝}
$$

真正需要尋找的是臨界尺度：

$$
\text{勝線交叉容量}
>
\text{配對／覆蓋阻斷能力}
$$

何時首次成立。

下一版將處理：

1. $7\times7$ 的自適應配對切換；
2. 配對以外的三元／多元阻斷覆蓋；
3. 位元棋盤 DFPN；
4. SAT／QBF 證書；
5. 從和局尺度到先手必勝尺度的相變點。
