# Scalable Gomoku State-Proof v0.4

這是一個從極小棋盤逐步推向一般五子棋的精確狀態機、證明搜尋與結構證書研究專案。

## v0.4 新結果

對 $7\times7$ 連五，建立「兩階段切換阻斷證書」：

$$
\forall f\notin\text{中央 }3\times3,
\quad
\exists g\;\forall h\;\exists r,\mathcal P_{f,g,h,r}.
$$

- 已證白方可阻止黑方從外圍 $40$ 個首手強制獲勝；
- 驗證 $40\times47=1880$ 個黑方第二手分支；
- 每個分支的剩餘 $45$ 點分為 $21$ 對與一個三元組；
- 每條五連線已被白棋阻斷，或包含一整個阻斷組；
- 黑方若存在必勝首手，只可能在中央 $3\times3$ 九點內。

這不是 $7\times7$ 的完整遊戲值求解；中央九點仍未決。

## 尺度鏈

| 棋盤 | 結果／前沿 | 方法 |
|---|---|---|
| $3\times3$ 連三 | 和局 | 完整求解 |
| $4\times4$ 連三 | 先手勝 | Tactical PNS |
| $4\times4$ 連四 | 和局 | C++ 完整表庫 |
| $5\times5$ 連五 | 所有首手和局 | 配對阻斷證書 |
| $6\times6$ 連五 | 空盤和局 | 雙向適應性配對 |
| $7\times7$ 連五 | 外圍 $40$ 首手非勝；中央九點未決 | 兩階段切換阻斷 |

## v0.4 主要檔案

- `switching_partition.py`：切換阻斷證書搜尋、對稱展開；
- `switching_verify.py`：不依賴 MILP 的獨立證書驗證器；
- `static_obstruction.py`：靜態互斥阻斷分區前沿與貪婪不可行核心；
- `results/v0_4/7x7_k5_outer40_switching_certificate.json`：完整證書；
- `results/v0_4/7x7_k5_outer40_verification.json`：驗證結果；
- `docs/two_stage_switching_theorem.md`：形式定理；
- `docs/v0_4_theory.md`：理論摘要。

## 驗證

```bash
python switching_verify.py \
  results/v0_4/7x7_k5_outer40_switching_certificate.json

python -m unittest discover -s tests_v04 -v
```

## 下一前沿

中央三個首手對稱軌道：

$$
(2,2),\quad(2,3),\quad(3,3)
$$

需要更深的量詞層：

$$
\exists g\;\forall h\;\exists r\;\forall j\;\exists s,\mathcal P
$$

或改用 DFPN、SAT／QBF 與可檢查策略 DAG。
