from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import server

def main():
    boot={'operators':len(server.OPERATORS),'propositions':len(server.PROPOSITIONS),'domains':len(server.DOMAINS)}
    assert boot['operators']>=100 and boot['propositions']==102 and boot['domains']==10
    dm=server.domain_matrix('U00_AGNOSTIC'); assert len(dm['cells'])==100 and dm['max_value']>0
    nonzero=next(x for x in dm['cells'] if x['value']>0)
    om=server.operator_matrix('U00_AGNOSTIC',nonzero['source'],nonzero['target']); assert om['rows'] and om['cols']
    cmp=server.compare('U00_AGNOSTIC','U01_CONTINUITY_PLURAL'); assert cmp['a_states']>0 and cmp['b_states']>0
    print(json.dumps({'bootstrap':boot,'domain_max':dm['max_value'],'sample_block':[nonzero['source'],nonzero['target']],'operator_matrix':[len(om['rows']),len(om['cols'])],'comparison':cmp},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
