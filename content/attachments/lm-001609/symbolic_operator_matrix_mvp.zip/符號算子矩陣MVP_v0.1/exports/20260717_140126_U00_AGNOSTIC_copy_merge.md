# 符號算子矩陣匯出

- 宇宙：`U00_AGNOSTIC`
- 來源算子：`copy`
- 目標算子：`merge`

## 算子關係

- 可組合：`True`
- 共用型別：`SUBJECT_SET`

## 相關命題


## 局部派生路徑
