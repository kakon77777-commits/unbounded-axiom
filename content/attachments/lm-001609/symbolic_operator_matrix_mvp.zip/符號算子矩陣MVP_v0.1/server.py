from __future__ import annotations
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from datetime import datetime
import argparse
import hashlib
import json
import mimetypes
import os
import re

ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web'
DATA=ROOT/'data'
EXPORTS=ROOT/'exports'


def load_json(name):
    return json.loads((DATA/name).read_text(encoding='utf-8'))

OPERATORS=load_json('operators.json')
PROPOSITIONS=load_json('propositions.json')
TYPES=load_json('types.json')
DIMENSIONS=load_json('axiom_dimensions.json')
PROFILES=load_json('representative_profiles.json')
COMPARISONS=load_json('scenario_comparisons.json')
RUN_SUMMARY=load_json('run_summary_v03.json')
DOMAIN_DATA=load_json('domains.json')
DOMAINS=DOMAIN_DATA['domains']
CAT_TO_DOMAIN=DOMAIN_DATA['category_to_domain']
OP_BY_NAME={x['name']:x for x in OPERATORS}
PROP_BY_ID={x['id']:x for x in PROPOSITIONS}
PROFILE_BY_ID={x['id']:x for x in PROFILES}
COMPARISON_BY_ID={x['scenario_id']:x for x in COMPARISONS}
DOMAIN_BY_ID={x['id']:x for x in DOMAINS}


def operator_domain(op):
    return CAT_TO_DOMAIN.get(op.get('category',''), 'other')


def compile_profile(profile_id):
    p=PROFILE_BY_ID.get(profile_id) or PROFILE_BY_ID['U00_AGNOSTIC']
    disabled=set(); markers=set(); supports=set(); selected=[]
    for dim,val in p.get('choices',{}).items():
        opt=DIMENSIONS[dim][val]; selected.append((dim,val))
        disabled.update(opt.get('disable_operators',[])); markers.update(opt.get('initial_markers',[])); supports.update(opt.get('supports',[]))
    for dim,vals in p.get('multi_choices',{}).items():
        for val in vals:
            opt=DIMENSIONS[dim][val]; selected.append((dim,val))
            disabled.update(opt.get('disable_operators',[])); markers.update(opt.get('initial_markers',[])); supports.update(opt.get('supports',[]))
    return {'id':p['id'],'name_zh':p['name_zh'],'description_zh':p.get('description_zh',''),'disabled':sorted(disabled),'markers':sorted(markers),'supports':sorted(supports),'selected':selected}


def active_ops(universe):
    disabled=set(compile_profile(universe)['disabled'])
    return [o for o in OPERATORS if o.get('enabled_for_closure',False) and o['name'] not in disabled]


def composable(a,b):
    outs={x for x in a.get('output_types',[]) if x!='ANY'}
    ins={x for x in b.get('input_types',[]) if x!='ANY'}
    return bool(outs & ins) or not ins


def related_props(source,target=None):
    names={source};
    if target: names.add(target)
    out=[]
    for p in PROPOSITIONS:
        ops=set(p.get('operators',[]))
        if names.issubset(ops) if target else source in ops:
            out.append({'id':p['id'],'title_zh':p['title_zh'],'category':p['category'],'confidence':p.get('confidence'), 'operators':p.get('operators',[])})
    return out


def domain_matrix(universe):
    ops=active_ops(universe)
    by={d['id']:[] for d in DOMAINS}
    for o in ops: by[operator_domain(o)].append(o)
    cells=[]
    maxv=0
    for sd in DOMAINS:
        for td in DOMAINS:
            edges=[]
            for a in by[sd['id']]:
                for b in by[td['id']]:
                    if composable(a,b): edges.append((a['name'],b['name']))
            value=len(edges); maxv=max(maxv,value)
            cells.append({'source':sd['id'],'target':td['id'],'value':value,'edge_sample':edges[:12]})
    return {'domains':DOMAINS,'cells':cells,'max_value':maxv,'universe':compile_profile(universe)}


def operator_matrix(universe, source_domain, target_domain):
    ops=active_ops(universe)
    rows=[o for o in ops if operator_domain(o)==source_domain]
    cols=[o for o in ops if operator_domain(o)==target_domain]
    rows.sort(key=lambda x:x['name']); cols.sort(key=lambda x:x['name'])
    cells=[]; maxv=1
    for a in rows:
        for b in cols:
            ok=composable(a,b)
            props=related_props(a['name'],b['name']) if ok else []
            score=(1+len(props)) if ok else 0
            maxv=max(maxv,score)
            cells.append({'source':a['name'],'target':b['name'],'value':score,'composable':ok,'proposition_count':len(props)})
    slim=lambda o:{'name':o['name'],'label_zh':o.get('label_zh') or o['name'],'category':o.get('category'),'input_types':o.get('input_types',[]),'output_types':o.get('output_types',[]),'cost':o.get('cost',1),'confidence':o.get('confidence',0.5)}
    return {'rows':[slim(x) for x in rows],'cols':[slim(x) for x in cols],'cells':cells,'max_value':maxv,'source_domain':DOMAIN_BY_ID[source_domain],'target_domain':DOMAIN_BY_ID[target_domain],'universe':compile_profile(universe)}


def ledger(universe, source, target):
    a=OP_BY_NAME.get(source); b=OP_BY_NAME.get(target)
    if not a or not b: return {'error':'operator not found'}
    return {'universe':compile_profile(universe),'source':a,'target':b,'composable':composable(a,b),'shared_types':sorted(set(a.get('output_types',[])) & set(b.get('input_types',[]))),'propositions':related_props(source,target),'source_propositions':related_props(source),'target_propositions':related_props(target)}


def closure_data(universe):
    p=DATA/f'closure_{universe}.json'
    if not p.exists(): p=DATA/'closure_U00_AGNOSTIC.json'
    return json.loads(p.read_text(encoding='utf-8'))


def path_query(universe, source='', target='', q='', limit=80):
    data=closure_data(universe); paths=[]
    q=q.lower().strip(); source=source.strip(); target=target.strip()
    for item in data.get('paths',[]):
        ops=item.get('operator_path',[]); states=item.get('state_types',[])
        if source and source not in ops: continue
        if target and target not in ops: continue
        blob=' '.join(ops+states+item.get('provenance',[])).lower()
        if q and q not in blob: continue
        paths.append(item)
        if len(paths)>=limit: break
    return {'universe':data.get('scenario',{}),'paths':paths,'count':len(paths)}


def axiom_marker_types():
    marker_categories={'axiom','identity_axiom','death_axiom','institution_axiom','goal_axiom','subjectivity_axiom','derived_marker'}
    markers={t['id'] for t in TYPES if t.get('category') in marker_categories}
    markers.update({'AXIOM_SET','MODEL_BRANCH','AXIOM_CONFLICT'})
    for dim in DIMENSIONS.values():
        for opt in dim.values():
            markers.update(opt.get('initial_markers',[]))
            for effect in opt.get('trigger_effects',{}).values():
                markers.update(effect.get('add',[])); markers.update(effect.get('remove',[]))
    return markers

AXIOM_MARKERS=axiom_marker_types()

def normalize_state(types):
    return tuple(sorted(x for x in types if x not in AXIOM_MARKERS))

def compare(a,b):
    da=closure_data(a); db=closure_data(b)
    sa={normalize_state(x.get('state_types',[])) for x in da.get('paths',[])}
    sb={normalize_state(x.get('state_types',[])) for x in db.get('paths',[])}
    added=sb-sa; removed=sa-sb; union=sa|sb; inter=sa&sb
    return {'a':compile_profile(a),'b':compile_profile(b),'a_states':len(sa),'b_states':len(sb),'added':len(added),'removed':len(removed),'jaccard':len(inter)/len(union) if union else 1.0,'sample_added':[list(x) for x in sorted(added)[:20]],'sample_removed':[list(x) for x in sorted(removed)[:20]],'normalization':'axiom markers removed before state comparison'}


def safe_slug(s): return re.sub(r'[^0-9A-Za-z_\-]+','_',s)[:80]


def make_export(payload):
    EXPORTS.mkdir(exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
    source=payload.get('source',''); target=payload.get('target',''); universe=payload.get('universe','U00_AGNOSTIC')
    led=ledger(universe,source,target) if source and target else None
    paths=path_query(universe,source,target,limit=50)
    base=f'{stamp}_{safe_slug(universe)}_{safe_slug(source)}_{safe_slug(target)}'
    jpath=EXPORTS/f'{base}.json'; mpath=EXPORTS/f'{base}.md'
    pack={'request':payload,'ledger':led,'paths':paths}
    jpath.write_text(json.dumps(pack,ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# 符號算子矩陣匯出','',f'- 宇宙：`{universe}`',f'- 來源算子：`{source or "未指定"}`',f'- 目標算子：`{target or "未指定"}`','']
    if led:
        lines += ['## 算子關係','',f'- 可組合：`{led["composable"]}`',f'- 共用型別：`{", ".join(led["shared_types"]) or "無"}`','', '## 相關命題','']
        for p in led['propositions']: lines.append(f'- **{p["id"]}** {p["title_zh"]}')
    lines += ['','## 局部派生路徑','']
    for x in paths['paths']:
        chain=' → '.join(x.get('operator_path',[])) or '初始狀態'; states=', '.join(x.get('state_types',[]))
        lines.append(f'- `{chain}` → `{states}`')
    mpath.write_text('\n'.join(lines),encoding='utf-8')
    return {'json':f'/exports/{jpath.name}','markdown':f'/exports/{mpath.name}'}


class Handler(BaseHTTPRequestHandler):
    server_version='SymbolicMatrixMVP/0.1'
    def log_message(self, fmt,*args): print('[MVP]',fmt%args)
    def send_json(self,obj,status=200):
        raw=json.dumps(obj,ensure_ascii=False).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(raw)
    def send_file(self,path):
        if not path.exists() or not path.is_file(): self.send_error(404); return
        raw=path.read_bytes(); mime=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
        self.send_response(200); self.send_header('Content-Type',mime + ('; charset=utf-8' if mime.startswith('text/') else '')); self.send_header('Content-Length',str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def do_GET(self):
        u=urlparse(self.path); q=parse_qs(u.query); path=u.path
        try:
            if path=='/api/bootstrap':
                self.send_json({'domains':DOMAINS,'universes':[{'id':x['id'],'name_zh':x['name_zh'],'description_zh':x.get('description_zh','')} for x in PROFILES],'run_summary':RUN_SUMMARY,'counts':{'operators':len(OPERATORS),'propositions':len(PROPOSITIONS),'types':len(TYPES)}}); return
            if path=='/api/domain-matrix': self.send_json(domain_matrix(q.get('universe',['U00_AGNOSTIC'])[0])); return
            if path=='/api/operator-matrix': self.send_json(operator_matrix(q.get('universe',['U00_AGNOSTIC'])[0],q.get('source',['core'])[0],q.get('target',['core'])[0])); return
            if path=='/api/ledger': self.send_json(ledger(q.get('universe',['U00_AGNOSTIC'])[0],q.get('source',[''])[0],q.get('target',[''])[0])); return
            if path=='/api/paths': self.send_json(path_query(q.get('universe',['U00_AGNOSTIC'])[0],q.get('source',[''])[0],q.get('target',[''])[0],q.get('q',[''])[0],int(q.get('limit',['80'])[0]))); return
            if path=='/api/compare': self.send_json(compare(q.get('a',['U00_AGNOSTIC'])[0],q.get('b',['U01_CONTINUITY_PLURAL'])[0])); return
            if path.startswith('/exports/'):
                self.send_file(EXPORTS/path.split('/')[-1]); return
            rel='index.html' if path=='/' else path.lstrip('/')
            target=(WEB/rel).resolve()
            if WEB.resolve() not in target.parents and target!=WEB.resolve(): self.send_error(403); return
            self.send_file(target)
        except Exception as e:
            self.send_json({'error':type(e).__name__,'message':str(e)},500)
    def do_POST(self):
        u=urlparse(self.path)
        try:
            size=int(self.headers.get('Content-Length','0')); payload=json.loads(self.rfile.read(size) or b'{}')
            if u.path=='/api/export': self.send_json(make_export(payload)); return
            self.send_json({'error':'not found'},404)
        except Exception as e: self.send_json({'error':type(e).__name__,'message':str(e)},500)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--host',default='127.0.0.1'); ap.add_argument('--port',type=int,default=8765); args=ap.parse_args()
    print(f'Open http://{args.host}:{args.port}')
    ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()
if __name__=='__main__': main()
