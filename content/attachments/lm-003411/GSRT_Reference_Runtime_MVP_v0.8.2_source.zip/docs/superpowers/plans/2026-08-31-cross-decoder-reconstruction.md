# GSRT v0.3 Cross-Decoder Reconstruction Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extend the GSRT reference runtime with an offline, cleanly labeled cross-decoder reconstruction harness that measures off-diagonal fidelity, consensus, and portability gaps without claiming independent cross-model evidence.

**Architecture:** Add a decoder registry with three behaviorally distinct reference decoders, a cross-decoder matrix runner that reuses the existing artifact/seed/evaluation/certificate pipeline, and a report/bundle/CLI surface. Keep the existing v0.1/v0.2 deterministic reference decoder untouched for regression compatibility; v0.3 adds an orthogonal experiment plane. Evidence metadata must distinguish internal decoder variants from independent external model families.

**Tech Stack:** Python 3.11+, stdlib dataclasses/json/sqlite/hashlib/argparse, pytest, setuptools wheel.

**Spec:** `GSRT-TW01_Generative_Seed_Runtime_Architecture_v0.1.0.md` and GSRT-03/GSRT-07 boundaries as summarized in project docs/README.

## Global Constraints

- Preserve v0.1 and v0.2 CLI behavior and regression tests.
- Cross-decoder evidence produced in v0.3 is `INTERNAL_REFERENCE_VARIANTS`, not independent provider/model evidence.
- Decoder inputs remain seed-only; source visibility must remain false.
- Compact 7-byte seeds may rely on exact reference codebook; the experiment must expose, not hide, that decoder dependency.
- Negative controls must remain sensitive and must not count as cross-decoder successes.
- Reports must separate target fidelity from inter-decoder consensus.
- No ISQL canonicalization work in v0.3.

---

### Task 1: Decoder Registry and Distinct Reference Decoders

**Files:**
- Create: `src/gsrt/decoders.py`
- Test: `tests/test_decoders.py`

**Interfaces:**
- Produces: `DecoderSpec`, `CrossDecoder`, `reference_decoder_registry()`.
- `CrossDecoder.decode(seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult`.

- [ ] **Step 1: Write failing tests** for registry IDs, seed-only metadata, and distinct compact-seed behavior.
- [ ] **Step 2: Run `pytest tests/test_decoders.py -v` and verify RED.**
- [ ] **Step 3: Implement minimal decoder registry** with:
  - `reference_exact:v0.3`: existing family-aware semantics, including compact codebook;
  - `relational_interlingua:v0.3`: freeform/structured/summary relational parser but deliberately no compact-codebook decoding;
  - `compact_core:v0.3`: compact decoder plus structured/freeform support, default neutral style when style absent.
- [ ] **Step 4: Run focused tests and full regression.**
- [ ] **Step 5: Commit.**

### Task 2: Cross-Decoder Matrix Models and Runner

**Files:**
- Modify: `src/gsrt/models.py`
- Create: `src/gsrt/cross_decoder.py`
- Test: `tests/test_cross_decoder.py`

**Interfaces:**
- Produces: `CrossDecoderReport`, `CrossDecoderConfig`, `CrossDecoderRunner.run(config) -> CrossDecoderReport`.

- [ ] **Step 1: Write failing tests** for matrix cell counts, off-diagonal aggregation, consensus separation, evidence-level metadata, and zero source visibility violations.
- [ ] **Step 2: Run focused test and verify RED.**
- [ ] **Step 3: Implement runner** across artifact × seed family × decoder × repetition, using existing evaluator and dependency audit.
- [ ] **Step 4: Compute per-cell metrics:** pass rate, mean fidelity, hard-pass rate, errors, source-visibility violations.
- [ ] **Step 5: Compute summary metrics:** diagonal/off-diagonal means, interoperability gap, pairwise consensus proxy, compact-seed portability profile.
- [ ] **Step 6: Run focused and full tests.**
- [ ] **Step 7: Commit.**

### Task 3: CLI and Reproducibility Bundle

**Files:**
- Modify: `src/gsrt/cli.py`
- Modify: `src/gsrt/bundle.py`
- Test: `tests/test_cross_decoder_cli.py`

**Interfaces:**
- Adds CLI command `gsrt cross-decoder`.
- Adds `export_cross_decoder_bundle(report, path)`.

- [ ] **Step 1: Write failing CLI/bundle tests.**
- [ ] **Step 2: Verify RED.**
- [ ] **Step 3: Implement CLI flags:** `--root`, `--count`, `--budget-bytes`, `--families`, `--decoders`, `--repetitions`, `--out`, `--bundle`.
- [ ] **Step 4: Bundle report + manifest + checksums.**
- [ ] **Step 5: Run focused/full tests.**
- [ ] **Step 6: Commit.**

### Task 4: v0.3 Full-Corpus Evidence and Release Docs

**Files:**
- Modify: `pyproject.toml`
- Modify: `src/gsrt/__init__.py`
- Modify: `README.md`
- Modify: `VALIDATION.md`
- Create: `release_evidence_v0.3/cross_decoder_report.json`
- Create: `release_evidence_v0.3/validation.json`
- Test: `tests/test_version.py`

**Interfaces:**
- Package version becomes `0.3.0`.

- [ ] **Step 1: Update version test first and verify RED.**
- [ ] **Step 2: Bump version and docs.**
- [ ] **Step 3: Run 120-artifact cross-decoder sweep with all five seed families and three internal decoders.**
- [ ] **Step 4: Record exact evidence boundary:** internal reference variants only; no independent model claim.
- [ ] **Step 5: Run full pytest and compileall.**
- [ ] **Step 6: Build wheel and clean-venv installed CLI smoke.**
- [ ] **Step 7: Create release checksums and verify them.**
- [ ] **Step 8: Commit release evidence.**

### Task 5: Final Verification and Export

**Files:**
- Create/update: `CHECKSUMS.sha256`
- Export outside repo: source ZIP, wheel, validation report/json, cross-decoder report, release manifest.

**Interfaces:** none.

- [ ] **Step 1: Run fresh full test suite on final commit.**
- [ ] **Step 2: Re-run full 120-case cross-decoder experiment and compare to committed report.**
- [ ] **Step 3: Run compileall, wheel build, clean install, installed CLI smoke.**
- [ ] **Step 4: Verify git working tree clean.**
- [ ] **Step 5: Export artifacts and SHA-256 manifest.**
