from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.library_experiment import LibraryExperimentRunner
from gsrt.qd import BehaviorDescriptorSchema, QDArchive, descriptor_distance, novelty_score


def _seeded_library(tmp_path: Path, count: int = 48):
    runner = LibraryExperimentRunner(tmp_path / "library")
    records = runner._build_library(count)
    return runner.library, records


def test_descriptor_distance_is_normalized_hamming() -> None:
    assert descriptor_distance(("solid", "center", "wide"), ("outline", "left", "wide")) == pytest.approx(2 / 3)
    assert descriptor_distance(("solid", "center", "wide"), ("solid", "center", "wide")) == 0.0
    with pytest.raises(ValueError, match="equal non-zero length"):
        descriptor_distance(("solid",), ("solid", "center"))


def test_novelty_score_reports_nearest_and_mean_distance() -> None:
    candidate = ("solid", "center", "wide")
    occupied = (
        ("solid", "left", "wide"),
        ("outline", "left", "wide"),
    )

    score = novelty_score(candidate, occupied)

    assert score.nearest == pytest.approx(1 / 3)
    assert score.mean == pytest.approx(0.5)


def test_duplicate_admission_does_not_inflate_coverage(tmp_path: Path) -> None:
    library, records = _seeded_library(tmp_path, 24)
    archive = QDArchive(library.db, BehaviorDescriptorSchema.visual_v081())
    seed_id = records[0]["seed_id"]

    for _ in range(20):
        archive.consider(seed_id, quality=1.0)

    assert archive.filled_niches() == 1
    assert archive.coverage() == pytest.approx(1 / 27)
    assert archive.qd_score() == 1.0


def test_quality_and_novelty_are_separate_fields_and_stats_rebuild(tmp_path: Path) -> None:
    library, records = _seeded_library(tmp_path, 48)
    archive = QDArchive(library.db, BehaviorDescriptorSchema.visual_v081())

    for record in records:
        archive.consider(record["seed_id"], quality=1.0)
        if archive.filled_niches() >= 3:
            break

    cells = archive.cells()
    assert len(cells) >= 3
    assert all(cell.quality == 1.0 for cell in cells)
    assert all(cell.novelty_nearest > 0.0 for cell in cells)
    assert all(cell.novelty_mean > 0.0 for cell in cells)

    stats = archive.stats()
    assert stats.total_niches == 27
    assert stats.filled_niches == len(cells)
    assert stats.coverage == pytest.approx(len(cells) / 27)
    assert stats.qd_score == float(len(cells))
    assert stats.mean_quality == 1.0
    assert stats.mean_novelty > 0.0

    before = [(c.niche_key, c.elite_seed_id, c.quality, c.novelty_nearest, c.novelty_mean) for c in cells]
    archive.rebuild([c.elite_seed_id for c in reversed(cells)])
    after_cells = archive.cells()
    after = [(c.niche_key, c.elite_seed_id, c.quality, c.novelty_nearest, c.novelty_mean) for c in after_cells]
    assert before == after
