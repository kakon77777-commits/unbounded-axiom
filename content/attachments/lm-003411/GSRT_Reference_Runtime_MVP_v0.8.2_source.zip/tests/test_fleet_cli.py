from __future__ import annotations

import json
from pathlib import Path

from gsrt.cli import main


def test_fleet_run_cli_writes_report_and_bundle(tmp_path: Path) -> None:
    root = tmp_path / "runtime"
    out = tmp_path / "fleet-report.json"
    bundle = tmp_path / "fleet-bundle"

    rc = main([
        "fleet-run",
        "--root", str(root),
        "--trials", "1",
        "--candidate-budget", "6",
        "--experiment-seed", "fleet-cli",
        "--out", str(out),
        "--bundle", str(bundle),
    ])

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["metadata"]["runtime_version"] == "0.8.2"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_MUTATION_PRIOR_FLEET"
    assert report["metadata"]["real_world_fleet_claim"] is False
    assert manifest["bundle_version"] == "0.8.2"
    assert manifest["experiment"] == "heterogeneous_mutation_fleet"
    assert manifest["experiment_id"] == report["experiment_id"]
    assert (bundle / "CHECKSUMS.sha256").exists()
