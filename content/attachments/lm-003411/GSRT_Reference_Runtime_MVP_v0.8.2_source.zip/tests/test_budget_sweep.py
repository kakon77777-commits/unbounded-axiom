from pathlib import Path

from gsrt.budget import BudgetSweepConfig, BudgetSweepRunner


def test_budget_sweep_derives_compact_minimum_cliff_and_unresolved_keyword(tmp_path: Path):
    runner = BudgetSweepRunner(tmp_path / "runtime")
    report = runner.run(
        BudgetSweepConfig(
            count=4,
            budgets=(160, 8, 7, 6, 4),
            repetitions=1,
            families=("summary", "keyword", "freeform", "structured", "compact"),
            near_minimal_eta_bytes=4,
        )
    )

    assert report.artifact_count == 4
    assert report.budgets == (160, 8, 7, 6, 4)
    assert report.source_visibility_violations == 0

    compact_curve = report.curves["compact"]
    assert [point["budget_bytes"] for point in compact_curve] == [160, 8, 7, 6, 4]
    assert [point["pass_rate"] for point in compact_curve] == [1.0, 1.0, 1.0, 0.0, 0.0]

    compact_summary = report.minimums["compact"]
    assert compact_summary["resolved"] == 4
    assert compact_summary["unresolved"] == 0
    assert compact_summary["min_budget_min"] == 7
    assert compact_summary["min_budget_max"] == 7
    assert compact_summary["min_payload_min"] == 7
    assert compact_summary["min_payload_max"] == 7
    assert compact_summary["compression_gain_median"] > 10.0

    assert report.minimums["keyword"]["resolved"] == 0
    assert report.minimums["keyword"]["unresolved"] == 4

    cliff = report.cliffs["compact"]
    assert cliff["upper_budget"] == 7
    assert cliff["lower_budget"] == 6
    assert cliff["pass_rate_drop"] == 1.0

    compact_artifacts = [row for row in report.artifact_minima if row["family"] == "compact"]
    assert len(compact_artifacts) == 4
    assert all(row["min_budget_bytes"] == 7 for row in compact_artifacts)
    assert all(row["min_adjusted_cost_bytes"] == 7 for row in compact_artifacts)
    assert all(any(p["budget_bytes"] == 7 for p in row["near_minimal_points"]) for row in compact_artifacts)

    assert report.control_budget_bytes == 160
    assert report.control_stats["random"]["total"] == 4.0
    assert report.control_stats["random"]["pass_rate"] == 0.0
    assert report.control_stats["contradiction"]["pass_rate"] == 0.0


def test_budget_sweep_rejects_duplicate_or_nonpositive_budgets(tmp_path: Path):
    runner = BudgetSweepRunner(tmp_path / "runtime")

    for budgets in ((8, 8, 7), (8, 0, 7), (8, -1, 7)):
        try:
            runner.run(BudgetSweepConfig(count=1, budgets=budgets, repetitions=1))
        except ValueError:
            pass
        else:
            raise AssertionError(f"expected invalid budgets to fail: {budgets}")
