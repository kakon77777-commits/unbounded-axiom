from pathlib import Path


def test_fleet_controls_match_valid_admission_and_expose_oracle_upper_bound(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    report = FleetExperimentRunner(tmp_path / "runtime").run(FleetExperimentConfig(trials=2, candidate_budget=8, experiment_seed="fleet-controls"))
    assert report.controls["matched_valid_admission_rate"] == 1.0
    assert report.controls["oracle_enumeration_coverage"] == 1.0
    assert report.metadata["oracle_information_access"] == "direct-27-niche-enumeration"
    assert report.metadata["oracle_is_matched_fleet_condition"] is False


def test_fleet_report_marks_synthetic_prior_evidence_not_cross_model_proof(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    report = FleetExperimentRunner(tmp_path / "runtime").run(FleetExperimentConfig(trials=1, candidate_budget=6, experiment_seed="fleet-boundary"))
    assert report.metadata["evidence_level"] == "SYNTHETIC_MUTATION_PRIOR_FLEET"
    assert report.metadata["independent_cross_model_evidence"] is False
    assert report.metadata["real_world_fleet_claim"] is False
    assert report.metadata["condition_name_in_rng"] is False
