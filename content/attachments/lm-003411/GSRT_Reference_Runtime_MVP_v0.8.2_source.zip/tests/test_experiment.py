from pathlib import Path

from gsrt.corpus import generate_reference_corpus
from gsrt.experiment import ExperimentConfig, ExperimentRunner
from gsrt.text_semantics import parse_fixture_text


def test_reference_corpus_has_120_unique_parseable_artifacts():
    corpus = generate_reference_corpus(120)
    assert len(corpus) == 120
    assert len({item.text for item in corpus}) == 120
    assert all(parse_fixture_text(item.text) for item in corpus)


def test_experiment_runner_persists_blind_reconstruction_and_controls(tmp_path: Path):
    runner = ExperimentRunner(tmp_path / "runtime")
    report = runner.run(ExperimentConfig(count=12, budget_bytes=512, repetitions=2))

    assert report.artifact_count == 12
    assert report.seed_count == 48
    assert report.source_visibility_violations == 0
    assert report.family_stats["structured"]["pass_rate"] == 1.0
    assert report.family_stats["freeform"]["pass_rate"] == 1.0
    assert report.control_stats["random"]["pass_rate"] == 0.0
    assert report.control_stats["relation_shuffle"]["pass_rate"] == 0.0
    assert report.control_stats["contradiction"]["pass_rate"] == 0.0
    assert report.control_stats["unrelated"]["pass_rate"] == 0.0
    assert runner.db.count("artifacts") == 12
    assert runner.db.count("seed_candidates") >= 48
    assert runner.db.count("certificates") == 48
