from __future__ import annotations

import json

from gsrt.cli import main


def test_navigation_run_cli_writes_v08_report_and_bundle(tmp_path) -> None:
    out = tmp_path / "navigation-report.json"
    bundle = tmp_path / "navigation-bundle"
    runtime = tmp_path / "runtime"

    rc = main(
        [
            "navigation-run",
            "--root",
            str(runtime),
            "--count",
            "24",
            "--tasks-per-distance",
            "2",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["artifact_count"] == 24
    assert report["task_count"] == 6
    assert report["metadata"]["runtime_version"] == "0.8.0"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_SEED_SPACE_NAVIGATION"
    assert report["conditions"]["D_full_navigation"]["success_rate"] == 1.0
    assert manifest["bundle_version"] == "0.8.0"
    assert manifest["experiment"] == "seed_space_navigation"
    assert manifest["task_count"] == 6
    assert (bundle / "CHECKSUMS.sha256").exists()
