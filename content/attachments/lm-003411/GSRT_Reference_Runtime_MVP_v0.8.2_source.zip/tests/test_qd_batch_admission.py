from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path

from gsrt.library_experiment import LibraryExperimentRunner
from gsrt.qd import BehaviorDescriptorSchema, QDArchive


def test_qd_consider_uses_one_atomic_batch_for_cell_and_novelty_refresh(tmp_path: Path) -> None:
    runner = LibraryExperimentRunner(tmp_path / "runtime")
    record = runner._build_library(1)[0]
    db = runner.library.db
    archive = QDArchive(db, BehaviorDescriptorSchema.visual_v081())

    original_batch = db.batch
    calls = {"count": 0}

    @contextmanager
    def counted_batch():
        calls["count"] += 1
        with original_batch():
            yield db

    db.batch = counted_batch  # type: ignore[method-assign]
    archive.consider(str(record["seed_id"]), quality=1.0)

    assert calls["count"] == 1
    assert archive.filled_niches() == 1
