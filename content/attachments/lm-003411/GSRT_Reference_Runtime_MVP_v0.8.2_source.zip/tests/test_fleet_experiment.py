from pathlib import Path


def test_matched_fleet_conditions_use_equal_candidate_budget_and_reference_cost(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    report = FleetExperimentRunner(tmp_path / "runtime").run(FleetExperimentConfig(trials=2, candidate_budget=8, experiment_seed="fleet-mini-cost"))
    costs = {name: metrics["mean_reference_cost"] for name, metrics in report.conditions.items()}
    attempts = {name: metrics["candidate_attempts"] for name, metrics in report.conditions.items()}
    assert len(set(costs.values())) == 1
    assert set(attempts.values()) == {16.0}
    assert report.metadata["worker_count"] == 3
    assert report.metadata["reference_cost_per_candidate"] == 5.0


def test_label_only_heterogeneity_matches_homogeneous_balanced_exactly(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    report = FleetExperimentRunner(tmp_path / "runtime").run(FleetExperimentConfig(trials=3, candidate_budget=10, experiment_seed="fleet-label-control"))
    assert report.conditions["label_only_control"] == report.conditions["homogeneous_balanced"]
    assert report.controls["label_only_exact_match"] == 1.0


def test_complementary_heterogeneous_priors_beat_narrow_homogeneous_bias_in_fixed_mini_benchmark(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    report = FleetExperimentRunner(tmp_path / "runtime").run(FleetExperimentConfig(trials=6, candidate_budget=18, experiment_seed="fleet-stress"))
    hetero = report.conditions["heterogeneous_complementary"]
    biased = report.conditions["homogeneous_biased"]
    assert hetero["mean_coverage"] > biased["mean_coverage"]
    assert hetero["mean_duplicate_rate"] < biased["mean_duplicate_rate"]
    assert report.paired["heterogeneous_vs_biased_coverage_delta"] > 0.0


def test_fleet_experiment_report_is_reproducible_across_clean_roots(tmp_path: Path):
    from gsrt.fleet_experiment import FleetExperimentConfig, FleetExperimentRunner
    config = FleetExperimentConfig(trials=2, candidate_budget=9, experiment_seed="fleet-repro")
    first = FleetExperimentRunner(tmp_path / "a").run(config).to_dict()
    second = FleetExperimentRunner(tmp_path / "b").run(config).to_dict()
    assert first == second
