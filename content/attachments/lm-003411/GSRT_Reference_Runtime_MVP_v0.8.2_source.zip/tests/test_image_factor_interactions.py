from gsrt.image_factor_interactions import pixel_interaction_matrix, semantic_coupling_matrix
from gsrt.image_factors import FACTOR_SPECS
from gsrt.image_semantics import ImageSemantics


def _base() -> ImageSemantics:
    return ImageSemantics("orb", "alpha", "left", "above", "wide", "left", "warm", "solid")


def test_semantic_coupling_matrix_is_diagonal_for_reference_visual_grammar():
    matrix = semantic_coupling_matrix(_base())

    for changed_factor in FACTOR_SPECS:
        for observed_factor in FACTOR_SPECS:
            expected = 1.0 if changed_factor == observed_factor else 0.0
            assert matrix[changed_factor][observed_factor] == expected


def test_pixel_interaction_matrix_detects_nonadditive_render_coupling_and_is_symmetric():
    matrix = pixel_interaction_matrix(_base())

    assert matrix["camera"]["subject"] > 0.0
    assert matrix["subject"]["camera"] == matrix["camera"]["subject"]
    for factor_name in FACTOR_SPECS:
        assert matrix[factor_name][factor_name] == 0.0
