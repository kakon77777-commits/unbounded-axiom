import pytest

from gsrt.image_factors import (
    FACTOR_SPECS,
    ablate_factor,
    round_trip_factor,
    semantic_delta,
    transplant_factor,
    transplant_metrics,
)
from gsrt.image_semantics import ImageSemantics, analyze_reference_image, render_reference_image


RECIPIENT = ImageSemantics(
    "block", "beta", "center", "below", "medium", "right", "cool", "striped"
)
DONOR = ImageSemantics(
    "spire", "gamma", "right", "beside", "close", "flat", "mono", "outline"
)


@pytest.mark.parametrize("factor_name", tuple(FACTOR_SPECS))
def test_ablation_replaces_non_default_factor_and_preserves_all_other_coordinates(factor_name):
    ablated = ablate_factor(RECIPIENT, factor_name)
    observed = analyze_reference_image(render_reference_image(ablated))

    assert getattr(observed, factor_name) == FACTOR_SPECS[factor_name].default
    assert semantic_delta(RECIPIENT, observed) == {factor_name}
    assert getattr(observed, factor_name) != getattr(RECIPIENT, factor_name)


@pytest.mark.parametrize("factor_name", tuple(FACTOR_SPECS))
def test_donor_transplant_transfers_target_and_preserves_recipient_non_target_factors(factor_name):
    hybrid = transplant_factor(RECIPIENT, DONOR, factor_name)
    observed = analyze_reference_image(render_reference_image(hybrid))
    metrics = transplant_metrics(RECIPIENT, DONOR, observed, factor_name)

    assert getattr(observed, factor_name) == getattr(DONOR, factor_name)
    assert metrics["target_transfer"] == 1.0
    assert metrics["protected_preservation"] == 1.0
    assert metrics["preservation_leakage"] == 0.0
    assert metrics["repair_cost"] == 0.0


@pytest.mark.parametrize("factor_name", tuple(FACTOR_SPECS))
def test_round_trip_swap_restores_recipient_semantics_and_pixels_exactly(factor_name):
    hybrid, restored = round_trip_factor(RECIPIENT, DONOR, factor_name)

    assert getattr(hybrid, factor_name) == getattr(DONOR, factor_name)
    assert restored == RECIPIENT
    assert render_reference_image(restored) == render_reference_image(RECIPIENT)
