from __future__ import annotations

import json

from gsrt.cli import main


def test_library_run_cli_writes_v06_report_and_bundle(tmp_path):
    out = tmp_path / "library-report.json"
    bundle = tmp_path / "library-bundle"
    runtime = tmp_path / "runtime"

    rc = main(
        [
            "library-run",
            "--root",
            str(runtime),
            "--count",
            "24",
            "--tasks-per-specificity",
            "1",
            "--max-fresh-attempts",
            "256",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["library_seed_count"] == 24
    assert report["task_count"] == 3
    assert report["metadata"]["runtime_version"] == "0.6.0"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_GENERATIVE_MEMORY"
    assert manifest["bundle_version"] == "0.6.0"
    assert manifest["experiment"] == "seed_library_reuse"
    assert manifest["library_seed_count"] == 24
    assert (bundle / "CHECKSUMS.sha256").exists()


def test_library_inspect_cli_reports_persistent_memory_counts_and_snapshot(tmp_path, capsys):
    runtime = tmp_path / "runtime"
    assert main(
        [
            "library-run",
            "--root",
            str(runtime),
            "--count",
            "24",
            "--tasks-per-specificity",
            "1",
            "--max-fresh-attempts",
            "256",
        ]
    ) == 0
    capsys.readouterr()

    assert main(["library-inspect", "--root", str(runtime)]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["reusable_seed_count"] == 24
    assert payload["factor_count"] == 24 * 8
    assert payload["snapshot_digest"].startswith("sha256:")
    assert payload["candidate_seed_count"] == 24
    assert payload["certificate_count"] == 24
