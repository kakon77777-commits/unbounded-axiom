from __future__ import annotations

from gsrt.db import RuntimeDB
from gsrt.retrieval import LibraryQuery, SeedRetriever


def _add(db: RuntimeDB, seed_id: str, *, factors: dict[str, str], status="REUSABLE", cert="cert:x"):
    db.record_validated_seed(
        {
            "seed_id": seed_id,
            "artifact_id": f"artifact:{seed_id}",
            "modality": "image",
            "family": "visual_compact",
            "payload": "ABCDEFGH",
            "payload_hash": f"hash:{seed_id}",
            "status": status,
            "certificate_id": cert,
            "freshness_key": "reference-image-reconstructor:v0.4",
            "metadata": {},
        }
    )
    for name, value in factors.items():
        db.record_seed_factor(seed_id, name, value)


def test_retrieval_intersects_required_factors_and_excludes_source_seed(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _add(db, "seed:a", factors={"identity": "alpha", "lighting": "left", "style": "solid"})
    _add(db, "seed:b", factors={"identity": "alpha", "lighting": "left", "style": "solid"})
    _add(db, "seed:c", factors={"identity": "alpha", "lighting": "right", "style": "solid"})
    retriever = SeedRetriever(db)

    portfolio = retriever.retrieve(
        LibraryQuery(
            required_factors={"identity": "alpha", "lighting": "left"},
            optional_factors={"style": "solid"},
            exclude_seed_ids=("seed:a",),
        )
    )

    assert portfolio.selected_seed_id == "seed:b"
    assert [candidate.seed_id for candidate in portfolio.candidates] == ["seed:b"]
    assert "required:identity=alpha" in portfolio.candidates[0].reasons
    assert "optional:style=solid" in portfolio.candidates[0].reasons


def test_retrieval_excludes_stale_and_uncertified_by_default(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _add(db, "seed:a", factors={"identity": "alpha"}, status="STALE")
    _add(db, "seed:b", factors={"identity": "alpha"}, cert="")
    _add(db, "seed:c", factors={"identity": "alpha"})

    portfolio = SeedRetriever(db).retrieve(LibraryQuery(required_factors={"identity": "alpha"}))

    assert [candidate.seed_id for candidate in portfolio.candidates] == ["seed:c"]


def test_optional_factor_score_ranks_deterministically_then_seed_id(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _add(db, "seed:z", factors={"identity": "alpha", "style": "solid", "palette": "warm"})
    _add(db, "seed:a", factors={"identity": "alpha", "style": "solid", "palette": "warm"})
    _add(db, "seed:m", factors={"identity": "alpha", "style": "striped", "palette": "warm"})

    portfolio = SeedRetriever(db).retrieve(
        LibraryQuery(
            required_factors={"identity": "alpha"},
            optional_factors={"style": "solid", "palette": "warm"},
            max_candidates=3,
        )
    )

    assert [candidate.seed_id for candidate in portfolio.candidates] == ["seed:a", "seed:z", "seed:m"]
    assert [candidate.optional_matches for candidate in portfolio.candidates] == [2, 2, 1]
    assert portfolio.selected_seed_id == "seed:a"
    assert portfolio.query_id == SeedRetriever(db).retrieve(
        LibraryQuery(
            required_factors={"identity": "alpha"},
            optional_factors={"style": "solid", "palette": "warm"},
            max_candidates=3,
        )
    ).query_id


def test_retrieval_can_return_empty_explainable_portfolio(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _add(db, "seed:a", factors={"identity": "beta"})

    portfolio = SeedRetriever(db).retrieve(LibraryQuery(required_factors={"identity": "alpha"}))

    assert portfolio.selected_seed_id is None
    assert portfolio.candidates == ()
    assert portfolio.metadata["reason"] == "no_compatible_seed"
