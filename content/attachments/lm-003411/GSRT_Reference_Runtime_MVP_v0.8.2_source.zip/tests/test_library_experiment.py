from __future__ import annotations

from gsrt.library_experiment import LibraryExperimentConfig, LibraryExperimentRunner


def test_library_reuse_benchmark_excludes_source_seed_and_beats_fresh_search_in_small_run(tmp_path):
    report = LibraryExperimentRunner(tmp_path).run(
        LibraryExperimentConfig(
            count=24,
            tasks_per_specificity=2,
            max_fresh_attempts=256,
            repetitions=1,
        )
    )

    assert report.library_seed_count == 24
    assert report.task_count == 6
    assert report.source_seed_reuse_violations == 0
    assert report.overall["library_success_rate"] == 1.0
    assert report.overall["mean_reuse_benefit"] > 0.0
    assert report.overall["relative_reuse_gain"] > 0.0
    assert report.controls["empty_library_pass"] == 1.0
    assert report.controls["stale_filter_pass"] == 1.0
    assert report.controls["wrong_factor_rejected"] == 1.0
    assert 0.0 <= report.controls["random_library_pass_rate"] < 1.0
    assert report.library_reuse_failure_count == 0
    assert report.recorded_failure_count >= report.fresh_search_failure_count
    assert report.metadata["lineage_edge_count"] == report.artifact_count + report.task_count


def test_library_experiment_is_deterministic_for_same_config(tmp_path):
    config = LibraryExperimentConfig(
        count=24,
        tasks_per_specificity=2,
        max_fresh_attempts=256,
        repetitions=1,
    )
    first = LibraryExperimentRunner(tmp_path / "a").run(config).to_dict()
    second = LibraryExperimentRunner(tmp_path / "b").run(config).to_dict()

    assert first == second


def test_library_report_separates_raw_cost_components_from_reference_scalar(tmp_path):
    report = LibraryExperimentRunner(tmp_path).run(
        LibraryExperimentConfig(
            count=24,
            tasks_per_specificity=1,
            max_fresh_attempts=256,
            repetitions=1,
        )
    )

    assert report.metadata["cost_model"] == {
        "generation": 1.0,
        "evaluation": 1.0,
        "retrieval_call": 1.0,
        "claim": "reference operation count; not a universal economic scalar",
    }
    for stats in report.by_specificity.values():
        assert stats["mean_library_generation_count"] == 1.0
        assert stats["mean_library_evaluator_calls"] == 1.0
        assert stats["mean_library_retrieval_calls"] == 1.0
