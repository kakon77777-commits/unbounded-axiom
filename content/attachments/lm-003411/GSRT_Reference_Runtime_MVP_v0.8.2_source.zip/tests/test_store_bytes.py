from pathlib import Path

from gsrt.store import ArtifactStore


def test_ingest_bytes_is_content_addressed_for_image_artifacts(tmp_path: Path):
    store = ArtifactStore(tmp_path / "artifacts")
    payload = b"\x89PNG synthetic bytes"

    first = store.ingest_bytes(payload, "image", {"fixture": 1})
    second = store.ingest_bytes(payload, "image", {"fixture": 2})

    assert first.artifact_id == second.artifact_id
    assert first.modality == "image"
    assert first.source_bytes == len(payload)
    assert store.read_bytes(first.artifact_id) == payload
