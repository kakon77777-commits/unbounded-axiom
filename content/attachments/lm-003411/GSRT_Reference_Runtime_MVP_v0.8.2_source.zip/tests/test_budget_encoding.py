from pathlib import Path

from gsrt.corpus import generate_reference_corpus
from gsrt.evaluation import TextFidelityEvaluator
from gsrt.extraction import ReferenceSeedExtractor
from gsrt.reconstruction import ReferenceReconstructor
from gsrt.store import ArtifactStore


def _fixture(tmp_path: Path):
    item = generate_reference_corpus(1)[0]
    store = ArtifactStore(tmp_path / "artifacts")
    artifact = store.ingest_text(item.text, item.metadata)
    extractor = ReferenceSeedExtractor(store.read_text)
    return item.text, artifact, extractor


def test_compact_seed_has_eight_byte_full_form_and_seven_byte_semantic_form(tmp_path: Path):
    source, artifact, extractor = _fixture(tmp_path)
    reconstructor = ReferenceReconstructor()
    evaluator = TextFidelityEvaluator()

    full = extractor.extract(artifact, "compact", 8)
    semantic = extractor.extract(artifact, "compact", 7)

    assert full.payload_bytes == 8
    assert semantic.payload_bytes == 7

    full_eval = evaluator.evaluate(source, reconstructor.reconstruct(full))
    semantic_eval = evaluator.evaluate(source, reconstructor.reconstruct(semantic))

    assert full_eval.passed is True
    assert full_eval.scores["style"] == 1.0
    assert semantic_eval.passed is True
    assert semantic_eval.scores["style"] == 0.0


def test_compact_seed_below_seven_bytes_fails_reconstruction(tmp_path: Path):
    source, artifact, extractor = _fixture(tmp_path)
    seed = extractor.extract(artifact, "compact", 6)
    result = ReferenceReconstructor().reconstruct(seed)
    evaluation = TextFidelityEvaluator().evaluate(source, result)

    assert seed.payload_bytes == 6
    assert result.error is not None
    assert evaluation.passed is False


def test_candidate_identity_includes_budget_even_when_payload_is_identical(tmp_path: Path):
    _, artifact, extractor = _fixture(tmp_path)
    seed8 = extractor.extract(artifact, "compact", 8)
    seed9 = extractor.extract(artifact, "compact", 9)

    assert seed8.payload == seed9.payload
    assert seed8.seed_id != seed9.seed_id
    assert seed8.budget_bytes == 8
    assert seed9.budget_bytes == 9
