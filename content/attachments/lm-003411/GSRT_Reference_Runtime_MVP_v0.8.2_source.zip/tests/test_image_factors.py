import pytest

from gsrt.image_factors import FACTOR_SPECS, factor_locality_metrics, next_factor_value, replace_factor, semantic_delta
from gsrt.image_semantics import ImageSemantics, analyze_reference_image, render_reference_image


def _base() -> ImageSemantics:
    return ImageSemantics(
        subject="orb",
        identity="alpha",
        composition="left",
        spatial="above",
        camera="wide",
        lighting="left",
        palette="warm",
        style="solid",
    )


@pytest.mark.parametrize("factor_name", tuple(FACTOR_SPECS))
def test_single_factor_replacement_is_semantically_local_after_render_observe(factor_name):
    base = _base()
    changed = replace_factor(base, factor_name, next_factor_value(base, factor_name))
    observed = analyze_reference_image(render_reference_image(changed))

    assert semantic_delta(base, observed) == {factor_name}
    metrics = factor_locality_metrics(base, observed, factor_name)
    assert metrics["target_effect"] == 1.0
    assert metrics["collateral_changed"] == 0.0
    assert metrics["preservation_leakage"] == 0.0
    assert metrics["protected_preservation"] == 1.0
    assert metrics["normalized_locality"] == 1.0
