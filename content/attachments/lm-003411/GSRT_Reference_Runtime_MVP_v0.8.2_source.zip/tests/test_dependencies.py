from gsrt.dependencies import DependencyAuditor, DependencyPolicy
from gsrt.models import DependencyRef, SeedCandidate


def candidate(deps):
    return SeedCandidate(
        seed_id="seed:1",
        artifact_id="artifact:1",
        family="structured",
        payload="{}",
        payload_bytes=2,
        budget_bytes=64,
        dependencies=tuple(deps),
    )


def test_dependency_audit_charges_private_dependency_and_blocks_hidden_artifact_copy():
    deps = [
        DependencyRef(kind="SHARED_BASELINE", ref="model:fixture", cost_bytes=999),
        DependencyRef(kind="PRIVATE_PER_ITEM", ref="cache:item-1", cost_bytes=120),
    ]
    audit = DependencyAuditor().audit(candidate(deps), DependencyPolicy.strict())

    assert audit.private_cost_bytes == 120
    assert audit.adjusted_cost_bytes == 122
    assert audit.passed is False
    assert "PRIVATE_PER_ITEM" in audit.violations


def test_shared_baseline_is_not_charged_as_private_seed_cost():
    deps = [DependencyRef(kind="SHARED_BASELINE", ref="model:fixture", cost_bytes=999)]
    audit = DependencyAuditor().audit(candidate(deps), DependencyPolicy.strict())

    assert audit.passed is True
    assert audit.private_cost_bytes == 0
    assert audit.adjusted_cost_bytes == 2
