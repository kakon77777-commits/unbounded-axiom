from pathlib import Path

from gsrt.store import ArtifactStore


def test_ingest_text_is_content_addressed_and_immutable(tmp_path: Path):
    store = ArtifactStore(tmp_path / "artifacts")
    first = store.ingest_text("alpha β", {"source": "fixture"})
    second = store.ingest_text("alpha β", {"source": "fixture-2"})

    assert first.artifact_id == second.artifact_id
    assert first.source_hash == second.source_hash
    assert store.read_text(first.artifact_id) == "alpha β"
    assert first.source_hash == "sha256:" + __import__("hashlib").sha256("alpha β".encode("utf-8")).hexdigest()
    assert (tmp_path / "artifacts" / first.artifact_id.split(":", 1)[1]).read_bytes() == "alpha β".encode("utf-8")
