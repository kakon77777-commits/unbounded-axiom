from gsrt.extraction import ReferenceSeedExtractor
from gsrt.models import ArtifactRecord
from gsrt.text_semantics import parse_fixture_text


SOURCE = (
    "Technically, redundant replicas may preserve service continuity under partial node loss; "
    "it does not necessarily imply higher safety."
)


def make_artifact():
    return ArtifactRecord(
        artifact_id="sha256:fixture",
        modality="text",
        source_hash="sha256:fixture",
        source_bytes=len(SOURCE.encode("utf-8")),
        metadata={},
    )


def test_reference_fixture_parser_extracts_relational_semantics():
    semantics = parse_fixture_text(SOURCE)
    assert semantics.subject == "redundant replicas"
    assert semantics.epistemic == "may"
    assert semantics.relation == "preserve"
    assert semantics.object == "service continuity"
    assert semantics.condition == "partial node loss"
    assert semantics.negated_implication is True
    assert semantics.consequence == "higher safety"
    assert semantics.style == "technical"


def test_four_seed_families_respect_matched_budget():
    extractor = ReferenceSeedExtractor(lambda _: SOURCE)
    families = ["summary", "keyword", "freeform", "structured"]
    seeds = [extractor.extract(make_artifact(), family=f, budget_bytes=512) for f in families]

    assert [s.family for s in seeds] == families
    assert all(s.payload_bytes <= 512 for s in seeds)
    assert all(s.budget_bytes == 512 for s in seeds)
    assert len({s.seed_id for s in seeds}) == 4
    assert '"r":"preserve"' in seeds[-1].payload
    assert "R:preserve" in seeds[2].payload
