import json

from gsrt.cli import main


def test_image_run_cli_writes_report_and_bundle(tmp_path):
    out = tmp_path / "report.json"
    bundle = tmp_path / "bundle"
    rc = main(
        [
            "image-run",
            "--root",
            str(tmp_path / "runtime"),
            "--count",
            "4",
            "--repetitions",
            "1",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["artifact_count"] == 4
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_GRAMMAR"
    assert manifest["bundle_version"] == "0.4.0"
    assert manifest["modality"] == "image"
    assert (bundle / "CHECKSUMS.sha256").exists()
