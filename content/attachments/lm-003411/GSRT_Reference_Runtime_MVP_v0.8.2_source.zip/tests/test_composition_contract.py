from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.composition import CompositionContract, CompatibilityEngine, FactorAssignment
from gsrt.db import RuntimeDB
from gsrt.image_factors import FACTOR_SPECS


def _seed_record(seed_id: str, *, status: str = "REUSABLE") -> dict:
    return {
        "seed_id": seed_id,
        "artifact_id": f"artifact:{seed_id}",
        "modality": "image",
        "family": "visual_compact",
        "payload": "abcdefgh",
        "payload_hash": f"hash:{seed_id}",
        "status": status,
        "certificate_id": f"cert:{seed_id}",
        "freshness_key": "reference-image-reconstructor:v0.4",
        "metadata": {},
    }


def _put_seed(db: RuntimeDB, seed_id: str, factors: dict[str, str], *, status: str = "REUSABLE") -> None:
    db.record_validated_seed(_seed_record(seed_id, status=status))
    for name, spec in FACTOR_SPECS.items():
        db.record_seed_factor(seed_id, name, factors.get(name, spec.default))


def test_compatibility_resolves_legal_multi_factor_donors(tmp_path: Path) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _put_seed(db, "recipient", {"identity": "alpha", "lighting": "flat", "style": "solid"})
    _put_seed(db, "light-donor", {"lighting": "left"})
    _put_seed(db, "style-donor", {"style": "outline"})

    result = CompatibilityEngine(db).check(
        CompositionContract(
            recipient_seed_id="recipient",
            assignments=(
                FactorAssignment("lighting", "light-donor"),
                FactorAssignment("style", "style-donor"),
            ),
            protected_factors=("identity", "subject", "composition", "spatial", "camera", "palette"),
        )
    )

    assert result.status == "PASS"
    assert result.resolved_values == {"lighting": "left", "style": "outline"}
    assert result.target_factors == ("lighting", "style")
    assert result.reasons == ()


@pytest.mark.parametrize(
    ("contract", "expected_reason"),
    [
        (
            CompositionContract(
                recipient_seed_id="recipient",
                assignments=(FactorAssignment("unknown", "light-donor"),),
            ),
            "unknown_factor:unknown",
        ),
        (
            CompositionContract(
                recipient_seed_id="recipient",
                assignments=(
                    FactorAssignment("lighting", "light-donor"),
                    FactorAssignment("lighting", "style-donor"),
                ),
            ),
            "duplicate_target:lighting",
        ),
        (
            CompositionContract(
                recipient_seed_id="recipient",
                assignments=(FactorAssignment("lighting", "light-donor"),),
                protected_factors=("lighting", "identity"),
            ),
            "protected_target_overlap:lighting",
        ),
        (
            CompositionContract(
                recipient_seed_id="recipient",
                assignments=(FactorAssignment("style", "missing"),),
            ),
            "missing_donor:missing",
        ),
    ],
)
def test_compatibility_fails_closed_for_invalid_contracts(
    tmp_path: Path,
    contract: CompositionContract,
    expected_reason: str,
) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _put_seed(db, "recipient", {})
    _put_seed(db, "light-donor", {"lighting": "left"})
    _put_seed(db, "style-donor", {"style": "outline"})

    result = CompatibilityEngine(db).check(contract)

    assert result.status == "FAIL"
    assert expected_reason in result.reasons


def test_compatibility_rejects_stale_recipient_or_donor(tmp_path: Path) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    _put_seed(db, "stale-recipient", {}, status="STALE")
    _put_seed(db, "recipient", {})
    _put_seed(db, "stale-donor", {"lighting": "left"}, status="STALE")

    stale_recipient = CompatibilityEngine(db).check(
        CompositionContract(
            recipient_seed_id="stale-recipient",
            assignments=(FactorAssignment("lighting", "stale-donor"),),
        )
    )
    stale_donor = CompatibilityEngine(db).check(
        CompositionContract(
            recipient_seed_id="recipient",
            assignments=(FactorAssignment("lighting", "stale-donor"),),
        )
    )

    assert stale_recipient.status == "FAIL"
    assert "recipient_not_reusable:STALE" in stale_recipient.reasons
    assert stale_donor.status == "FAIL"
    assert "donor_not_reusable:stale-donor:STALE" in stale_donor.reasons
