from pathlib import Path

from gsrt.image_evaluation import ImageFidelityEvaluator
from gsrt.image_extraction import ReferenceImageSeedExtractor
from gsrt.image_reconstruction import ReferenceImageReconstructor
from gsrt.image_semantics import ImageSemantics, render_reference_image
from gsrt.models import ArtifactRecord
from gsrt.store import ArtifactStore


def _source_record(png: bytes, semantics: ImageSemantics) -> ArtifactRecord:
    import hashlib

    digest = hashlib.sha256(png).hexdigest()
    return ArtifactRecord(
        artifact_id=f"sha256:{digest}",
        modality="image",
        source_hash=f"sha256:{digest}",
        source_bytes=len(png),
        metadata={"intentionally_wrong_semantics": "extractor must ignore metadata"},
    )


def test_image_extractor_reads_finished_png_and_full_seed_families_reconstruct(tmp_path: Path):
    semantics = ImageSemantics("spire", "gamma", "right", "below", "close", "right", "warm", "striped")
    source_png = render_reference_image(semantics)
    record = _source_record(source_png, semantics)
    reads = []

    def source_reader(artifact_id: str) -> bytes:
        reads.append(artifact_id)
        return source_png

    extractor = ReferenceImageSeedExtractor(source_reader)
    output_store = ArtifactStore(tmp_path / "outputs")
    reconstructor = ReferenceImageReconstructor(output_store)
    evaluator = ImageFidelityEvaluator(output_store.read_bytes)

    for family in ("visual_description", "visual_structured", "visual_compact"):
        seed = extractor.extract(record, family, 512)
        result = reconstructor.reconstruct(seed, 0)
        evaluation = evaluator.evaluate(semantics, source_png, result)

        assert result.source_visible_to_decoder is False
        assert result.error is None
        assert evaluation.passed is True
        assert evaluation.scores["pixel_exact"] == 1.0

    assert reads == [record.artifact_id] * 3


def test_visual_partial_seed_is_a_weak_baseline_when_omitted_factors_differ(tmp_path: Path):
    semantics = ImageSemantics("orb", "gamma", "right", "below", "close", "right", "cool", "outline")
    source_png = render_reference_image(semantics)
    record = _source_record(source_png, semantics)
    extractor = ReferenceImageSeedExtractor(lambda _: source_png)
    output_store = ArtifactStore(tmp_path / "outputs")
    reconstructor = ReferenceImageReconstructor(output_store)
    evaluator = ImageFidelityEvaluator(output_store.read_bytes)

    seed = extractor.extract(record, "visual_partial", 512)
    result = reconstructor.reconstruct(seed, 0)
    evaluation = evaluator.evaluate(semantics, source_png, result)

    assert evaluation.passed is False
    assert evaluation.scores["subject"] == 1.0
    assert evaluation.scores["palette"] == 1.0
    assert evaluation.scores["identity"] == 0.0
    assert evaluation.scores["spatial"] == 0.0
