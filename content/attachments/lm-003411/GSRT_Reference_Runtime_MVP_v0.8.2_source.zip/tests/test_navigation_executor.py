from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.db import RuntimeDB
from gsrt.image_extraction import encode_visual_compact
from gsrt.image_factors import FACTOR_SPECS
from gsrt.image_semantics import ImageSemantics, render_reference_image
from gsrt.navigation import (
    FailureMap,
    GoalCompiler,
    NavigationExecutor,
    RuleBasedNavigationPlanner,
)


def _put_seed(db: RuntimeDB, seed_id: str, semantics: ImageSemantics) -> dict:
    payload = encode_visual_compact(semantics)
    record = {
        "seed_id": seed_id,
        "artifact_id": f"artifact:{seed_id}",
        "modality": "image",
        "family": "visual_compact",
        "payload": payload,
        "payload_hash": f"hash:{seed_id}",
        "status": "REUSABLE",
        "certificate_id": f"cert:{seed_id}",
        "freshness_key": "reference-image-reconstructor:v0.4",
        "metadata": {"origin": seed_id},
    }
    db.record_validated_seed(record)
    for name in FACTOR_SPECS:
        db.record_seed_factor(seed_id, name, getattr(semantics, name))
    return record


@pytest.mark.parametrize(
    ("goal_semantics", "distance"),
    [
        (ImageSemantics("orb", "alpha", "center", "above", "medium", "right", "warm", "solid"), 1),
        (ImageSemantics("orb", "alpha", "center", "above", "wide", "right", "warm", "solid"), 2),
        (ImageSemantics("orb", "alpha", "center", "above", "wide", "right", "warm", "outline"), 3),
    ],
)
def test_navigation_executor_reaches_goal_with_local_steps_and_preserves_parent(
    tmp_path: Path,
    goal_semantics: ImageSemantics,
    distance: int,
) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    start = ImageSemantics("orb", "alpha", "center", "above", "medium", "flat", "warm", "solid")
    donor = ImageSemantics("spire", "beta", "left", "below", "wide", "right", "cool", "outline")
    start_record = _put_seed(db, "start", start)
    _put_seed(db, "donor", donor)
    failures = FailureMap(db)
    planner = RuleBasedNavigationPlanner(db, failures)
    executor = NavigationExecutor(db, planner)

    outcome = executor.navigate("start", GoalCompiler().compile(goal_semantics), max_steps=5)

    assert outcome.success
    assert outcome.initial_distance == distance
    assert outcome.path_length == distance
    assert outcome.final_semantics == goal_semantics
    assert render_reference_image(outcome.final_semantics) == render_reference_image(goal_semantics)
    assert outcome.mean_protected_leakage == 0.0
    assert outcome.known_failure_revisits == 0
    assert len(outcome.steps) == distance
    assert all(step.changed_factors == (step.action.factor_name,) for step in outcome.steps)
    assert all(step.protected_leakage == 0.0 for step in outcome.steps)
    assert db.get_validated_seed("start") == start_record
