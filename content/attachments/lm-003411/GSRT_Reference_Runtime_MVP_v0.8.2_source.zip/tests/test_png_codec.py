import pytest

from gsrt.png_codec import decode_rgb_png, encode_rgb_png


def test_rgb_png_roundtrip_preserves_exact_pixels():
    width, height = 3, 2
    pixels = bytes([
        255, 0, 0,   0, 255, 0,   0, 0, 255,
        10, 20, 30,  40, 50, 60,  70, 80, 90,
    ])

    encoded = encode_rgb_png(width, height, pixels)
    got_width, got_height, got_pixels = decode_rgb_png(encoded)

    assert encoded.startswith(b"\x89PNG\r\n\x1a\n")
    assert (got_width, got_height) == (width, height)
    assert got_pixels == pixels


def test_rgb_png_rejects_wrong_pixel_length():
    with pytest.raises(ValueError, match="pixel length"):
        encode_rgb_png(2, 2, b"short")
