from __future__ import annotations

from pathlib import Path

from gsrt.composition_experiment import CompositionExperimentConfig, CompositionExperimentRunner


def test_composition_experiment_transfers_targets_preserves_protected_and_round_trips(tmp_path: Path) -> None:
    report = CompositionExperimentRunner(tmp_path / "run").run(
        CompositionExperimentConfig(count=24, tasks_per_specificity=4)
    )

    assert report.artifact_count == 24
    assert report.task_count == 12
    assert report.promoted_seed_count == 12
    assert report.new_seed_count + report.existing_state_hit_count == 12
    assert report.branch_isolation_violations == 0
    assert report.overall["composition_pass_rate"] == 1.0
    assert report.overall["mean_target_transfer"] == 1.0
    assert report.overall["mean_protected_preservation"] == 1.0
    assert report.overall["mean_preservation_leakage"] == 0.0
    assert report.overall["round_trip_semantic_exact_rate"] == 1.0
    assert report.overall["round_trip_pixel_exact_rate"] == 1.0
    assert set(report.by_specificity) == {"k1", "k2", "k3"}
    assert all(stats["composition_pass_rate"] == 1.0 for stats in report.by_specificity.values())
    assert all(record["donor_count"] == record["target_factor_count"] for record in report.task_records)
    assert all(record["source_seed_unchanged"] for record in report.task_records)


def test_composition_experiment_fail_closed_controls_pass(tmp_path: Path) -> None:
    report = CompositionExperimentRunner(tmp_path / "run").run(
        CompositionExperimentConfig(count=24, tasks_per_specificity=2)
    )

    assert report.controls == {
        "duplicate_target_rejected": 1.0,
        "protected_overlap_rejected": 1.0,
        "unknown_factor_rejected": 1.0,
        "stale_donor_rejected": 1.0,
        "moved_base_promotion_blocked": 1.0,
        "failed_certificate_promotion_blocked": 1.0,
    }


def test_composition_experiment_report_is_reproducible_across_clean_roots(tmp_path: Path) -> None:
    config = CompositionExperimentConfig(count=24, tasks_per_specificity=3)

    first = CompositionExperimentRunner(tmp_path / "a").run(config)
    second = CompositionExperimentRunner(tmp_path / "b").run(config)

    assert first.to_dict() == second.to_dict()
    assert first.metadata["evidence_level"] == "SYNTHETIC_VISUAL_COMPOSITION_REFERENCE"
    assert first.metadata["real_world_composition_claim"] is False
