from gsrt.controls import make_controls
from gsrt.evaluation import TextFidelityEvaluator
from gsrt.extraction import ReferenceSeedExtractor
from gsrt.models import ArtifactRecord
from gsrt.reconstruction import ReferenceReconstructor


SOURCE = (
    "Technically, redundant replicas may preserve service continuity under partial node loss; "
    "it does not necessarily imply higher safety."
)
OTHER = (
    "Briefly, causal logs must constrain unsafe retries under stale state; "
    "it does imply deterministic rejection."
)


def artifact(name, text):
    return ArtifactRecord(name, "text", name, len(text.encode()), {})


def test_negative_controls_fail_relation_sensitive_contract():
    ex = ReferenceSeedExtractor(lambda aid: SOURCE if aid == "a" else OTHER)
    seed = ex.extract(artifact("a", SOURCE), "structured", 512)
    unrelated = ex.extract(artifact("b", OTHER), "structured", 512)
    controls = make_controls(seed, unrelated)
    recon = ReferenceReconstructor()
    evaluator = TextFidelityEvaluator()

    good = evaluator.evaluate(SOURCE, recon.reconstruct(seed))
    assert good.passed is True
    assert set(controls) == {"random", "relation_shuffle", "contradiction", "unrelated"}
    assert all(
        evaluator.evaluate(SOURCE, recon.reconstruct(control)).passed is False
        for control in controls.values()
    )
