from __future__ import annotations

from pathlib import Path

from gsrt.navigation_experiment import NavigationExperimentConfig, NavigationExperimentRunner


def test_navigation_experiment_matches_a_b_c_d_capability_boundaries(tmp_path: Path) -> None:
    report = NavigationExperimentRunner(tmp_path / "run").run(
        NavigationExperimentConfig(count=24, tasks_per_distance=2)
    )

    assert report.artifact_count == 24
    assert report.initial_library_seed_count == 24
    assert report.task_count == 6
    assert report.goal_distance_counts == {"d1": 2, "d2": 2, "d3": 2}
    assert report.controls["held_out_goal_violations"] == 0.0
    assert report.controls["distance_bucket_violations"] == 0.0
    assert report.controls["library_snapshot_changed"] == 0.0
    assert report.controls["start_seed_mutation_violations"] == 0.0

    assert report.conditions["A_fresh"]["success_rate"] == 1.0
    assert report.conditions["B_nearest_reuse"]["success_rate"] == 0.0
    assert report.by_distance["d1"]["C_local_mutation_success_rate"] == 1.0
    assert report.by_distance["d2"]["C_local_mutation_success_rate"] == 0.0
    assert report.by_distance["d3"]["C_local_mutation_success_rate"] == 0.0
    assert report.conditions["D_full_navigation"]["success_rate"] == 1.0
    assert report.by_distance["d1"]["D_mean_path_length"] == 1.0
    assert report.by_distance["d2"]["D_mean_path_length"] == 2.0
    assert report.by_distance["d3"]["D_mean_path_length"] == 3.0
    assert report.conditions["D_full_navigation"]["mean_protected_leakage"] == 0.0
    assert report.overall["mean_navigation_gain"] > 0.0
    assert report.overall["relative_navigation_gain"] > 0.9
    assert report.controls["oracle_direct_success_rate"] == 1.0
    assert report.controls["oracle_direct_mean_reference_cost"] == 2.0
    assert report.overall["navigation_vs_oracle_gain"] < 0.0


def test_navigation_experiment_failure_memory_prevents_known_revisits(tmp_path: Path) -> None:
    report = NavigationExperimentRunner(tmp_path / "run").run(
        NavigationExperimentConfig(count=24, tasks_per_distance=2)
    )

    assert report.failure_memory["known_failure_opportunities"] == 12.0
    assert report.failure_memory["history_known_failure_revisits"] == 0.0
    assert report.failure_memory["no_history_known_failure_revisits"] == 12.0
    assert report.failure_memory["history_revisit_rate"] == 0.0
    assert report.failure_memory["no_history_revisit_rate"] == 1.0
    assert report.failure_memory["avoided_known_failures"] == 12.0
    assert report.controls["failure_map_record_count"] == 12.0


def test_navigation_experiment_report_is_reproducible_across_clean_roots(tmp_path: Path) -> None:
    config = NavigationExperimentConfig(count=24, tasks_per_distance=2)

    first = NavigationExperimentRunner(tmp_path / "a").run(config)
    second = NavigationExperimentRunner(tmp_path / "b").run(config)

    assert first.to_dict() == second.to_dict()
    assert first.metadata["evidence_level"] == "SYNTHETIC_VISUAL_SEED_SPACE_NAVIGATION"
    assert first.metadata["real_world_navigation_claim"] is False
