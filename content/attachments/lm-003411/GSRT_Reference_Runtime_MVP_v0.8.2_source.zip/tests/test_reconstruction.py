from gsrt.extraction import ReferenceSeedExtractor
from gsrt.models import ArtifactRecord
from gsrt.reconstruction import ReferenceReconstructor


SOURCE = (
    "Technically, redundant replicas may preserve service continuity under partial node loss; "
    "it does not necessarily imply higher safety."
)
ART = ArtifactRecord("sha256:a", "text", "sha256:a", len(SOURCE.encode()), {})


def test_structured_seed_reconstructs_without_source_visibility():
    seed = ReferenceSeedExtractor(lambda _: SOURCE).extract(ART, "structured", 512)
    result = ReferenceReconstructor().reconstruct(seed, run_index=0)

    assert result.text == SOURCE
    assert result.source_visible_to_decoder is False
    assert result.error is None
    assert result.seed_id == seed.seed_id
