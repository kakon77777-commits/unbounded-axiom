import hashlib
import json
from pathlib import Path

from gsrt.cli import main


def test_budget_sweep_cli_writes_report_and_reproducibility_bundle(tmp_path: Path):
    root = tmp_path / "runtime"
    out = tmp_path / "budget_report.json"
    bundle = tmp_path / "bundle"

    rc = main(
        [
            "budget-sweep",
            "--root",
            str(root),
            "--count",
            "4",
            "--budgets",
            "160,8,7,6,4",
            "--repetitions",
            "1",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["budgets"] == [160, 8, 7, 6, 4]
    assert report["minimums"]["compact"]["min_budget_min"] == 7
    assert report["cliffs"]["compact"]["lower_budget"] == 6
    assert report["source_visibility_violations"] == 0

    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    bundled_report = json.loads((bundle / "report.json").read_text(encoding="utf-8"))
    checksums = (bundle / "CHECKSUMS.sha256").read_text(encoding="utf-8")

    assert manifest["bundle_version"] == "0.2.0"
    assert manifest["sweep_id"] == report["sweep_id"]
    assert bundled_report["minimums"]["compact"]["min_payload_min"] == 7
    for filename in ("manifest.json", "report.json"):
        digest = hashlib.sha256((bundle / filename).read_bytes()).hexdigest()
        assert f"{digest}  {filename}" in checksums
