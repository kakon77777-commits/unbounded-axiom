from gsrt.image_experiment import ImageExperimentConfig, ImageExperimentRunner


def test_image_experiment_runs_retrospective_blind_pipeline_with_controls(tmp_path):
    report = ImageExperimentRunner(tmp_path / "runtime").run(
        ImageExperimentConfig(count=12, repetitions=1)
    )

    assert report.artifact_count == 12
    assert report.seed_count == 48
    assert report.source_visibility_violations == 0
    assert report.metadata["evidence_level"] == "SYNTHETIC_VISUAL_GRAMMAR"
    assert report.metadata["source_input"] == "finished_png_bytes_only"

    for family in ("visual_description", "visual_structured", "visual_compact"):
        assert report.family_stats[family]["pass_rate"] == 1.0
        assert report.family_stats[family]["mean_pixel_exact"] == 1.0

    assert report.family_stats["visual_partial"]["pass_rate"] < 1.0
    for control in ("random", "wrong_identity", "spatial_flip", "style_swap", "unrelated"):
        assert report.control_stats[control]["pass_rate"] == 0.0
