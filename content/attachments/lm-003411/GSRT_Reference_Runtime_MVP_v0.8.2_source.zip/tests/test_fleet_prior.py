import pytest

from gsrt.image_semantics import ImageSemantics


def _base():
    return ImageSemantics(
        subject="orb",
        identity="alpha",
        composition="center",
        spatial="above",
        camera="medium",
        lighting="flat",
        palette="warm",
        style="solid",
    )


def test_mutation_prior_rejects_invalid_probability_vector():
    from gsrt.fleet import MutationPrior
    with pytest.raises(ValueError):
        MutationPrior("bad", (0.5, 0.5, 0.5))
    with pytest.raises(ValueError):
        MutationPrior("bad", (-0.1, 0.6, 0.5))


def test_mutation_changes_exactly_one_qd_descriptor_factor():
    from gsrt.fleet import FleetWorker, MutationPrior, mutate_descriptor
    worker = FleetWorker("worker-a", MutationPrior("balanced", (1 / 3, 1 / 3, 1 / 3)))
    proposal = mutate_descriptor(_base(), worker, worker_index=0, trial=3, attempt=5, experiment_seed="fleet-test")
    qd = ("style", "composition", "camera")
    changed = [name for name in qd if getattr(_base(), name) != getattr(proposal.child, name)]
    assert changed == [proposal.factor]
    assert proposal.old_value == getattr(_base(), proposal.factor)
    assert proposal.new_value == getattr(proposal.child, proposal.factor)
    assert proposal.new_value != proposal.old_value
    protected = ("subject", "identity", "spatial", "lighting", "palette")
    assert all(getattr(_base(), name) == getattr(proposal.child, name) for name in protected)


def test_worker_label_does_not_change_deterministic_proposal():
    from gsrt.fleet import FleetWorker, MutationPrior, mutate_descriptor
    prior = MutationPrior("balanced", (1 / 3, 1 / 3, 1 / 3))
    left = mutate_descriptor(_base(), FleetWorker("label-a", prior), worker_index=2, trial=7, attempt=11, experiment_seed="fleet-test")
    right = mutate_descriptor(_base(), FleetWorker("completely-different-label", prior), worker_index=2, trial=7, attempt=11, experiment_seed="fleet-test")
    assert left.factor == right.factor
    assert left.new_value == right.new_value
    assert left.child == right.child
