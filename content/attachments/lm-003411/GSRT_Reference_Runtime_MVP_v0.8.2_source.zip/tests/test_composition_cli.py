from __future__ import annotations

import json

from gsrt.cli import main


def test_composition_run_cli_writes_v07_report_and_bundle(tmp_path) -> None:
    out = tmp_path / "composition-report.json"
    bundle = tmp_path / "composition-bundle"
    runtime = tmp_path / "runtime"

    rc = main(
        [
            "composition-run",
            "--root",
            str(runtime),
            "--count",
            "24",
            "--tasks-per-specificity",
            "2",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["artifact_count"] == 24
    assert report["task_count"] == 6
    assert report["promoted_seed_count"] == 6
    assert report["metadata"]["runtime_version"] == "0.7.0"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_COMPOSITION_REFERENCE"
    assert manifest["bundle_version"] == "0.7.0"
    assert manifest["experiment"] == "composition_mutation"
    assert manifest["task_count"] == 6
    assert (bundle / "CHECKSUMS.sha256").exists()
