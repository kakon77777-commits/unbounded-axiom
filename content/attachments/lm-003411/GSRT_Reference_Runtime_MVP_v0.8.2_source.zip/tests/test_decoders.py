from gsrt.decoders import reference_decoder_registry
from gsrt.extraction import ReferenceSeedExtractor
from gsrt.models import ArtifactRecord


SOURCE = (
    "Technically, redundant replicas may preserve service continuity under partial node loss; "
    "it does not necessarily imply higher safety."
)
ART = ArtifactRecord("sha256:a", "text", "sha256:a", len(SOURCE.encode()), {})


def _seed(family: str, budget: int = 512):
    return ReferenceSeedExtractor(lambda _: SOURCE).extract(ART, family, budget)


def test_reference_decoder_registry_has_three_distinct_internal_profiles():
    registry = reference_decoder_registry()
    assert tuple(registry) == (
        "reference_exact:v0.3",
        "relational_interlingua:v0.3",
        "compact_core:v0.3",
    )
    assert all(spec.evidence_level == "INTERNAL_REFERENCE_VARIANTS" for spec in registry.values())


def test_decoder_run_ids_are_decoder_specific_and_seed_only():
    registry = reference_decoder_registry()
    seed = _seed("freeform")
    outputs = [decoder.decode(seed, 0) for decoder in registry.values()]

    assert len({item.run_id for item in outputs}) == 3
    assert all(item.source_visible_to_decoder is False for item in outputs)
    assert all(item.seed_id == seed.seed_id for item in outputs)
    assert all(item.error is None for item in outputs)
    assert all(item.text == SOURCE for item in outputs)


def test_compact_seed_exposes_decoder_prior_dependency():
    registry = reference_decoder_registry()
    seed = _seed("compact", 7)

    reference = registry["reference_exact:v0.3"].decode(seed)
    relational = registry["relational_interlingua:v0.3"].decode(seed)
    compact = registry["compact_core:v0.3"].decode(seed)

    assert reference.error is None
    assert compact.error is None
    assert relational.error is not None
    assert reference.text.endswith("higher safety.")
    assert compact.text.endswith("higher safety.")


def test_raw_summary_is_not_supported_by_compact_core_decoder():
    registry = reference_decoder_registry()
    seed = _seed("summary")

    assert registry["reference_exact:v0.3"].decode(seed).error is None
    assert registry["relational_interlingua:v0.3"].decode(seed).error is None
    assert registry["compact_core:v0.3"].decode(seed).error is not None
