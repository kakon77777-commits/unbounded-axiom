from gsrt.factor_experiment import FactorExperimentConfig, FactorExperimentRunner
from gsrt.image_factors import FACTOR_SPECS


def test_factor_experiment_measures_ablation_transplant_roundtrip_and_interactions(tmp_path):
    report = FactorExperimentRunner(tmp_path / "runtime").run(FactorExperimentConfig(count=12))

    assert report.artifact_count == 12
    assert report.factor_count == 8
    assert report.metadata["runtime_version"] == "0.5.0"
    assert report.metadata["evidence_level"] == "SYNTHETIC_VISUAL_GRAMMAR"
    assert report.metadata["source_input"] == "finished_png_bytes_only"
    assert report.metadata["source_semantics_visible_to_factorizer"] is False
    assert report.metadata["real_world_disentanglement_claim"] is False
    assert report.metadata["ablation_mode"] == "default_substitution"
    assert report.metadata["operation_counts"]["transplants"] == 96
    assert report.metadata["operation_counts"]["pixel_pair_interactions"] == 336

    for factor_name in FACTOR_SPECS:
        ablation = report.ablation_stats[factor_name]
        assert ablation["eligible"] > 0
        assert ablation["necessity_rate"] == 1.0
        assert ablation["mean_protected_preservation"] == 1.0
        assert ablation["pixel_exact_rate"] == 0.0

        transplant = report.transplant_stats[factor_name]
        assert transplant["tested"] == 12
        assert transplant["target_transfer"] == 1.0
        assert transplant["protected_preservation"] == 1.0
        assert transplant["preservation_leakage"] == 0.0
        assert transplant["normalized_locality"] == 1.0
        assert transplant["portability"] == 1.0
        assert transplant["round_trip_semantic_exact"] == 1.0
        assert transplant["round_trip_pixel_exact"] == 1.0
        assert transplant["mean_repair_cost"] == 0.0

    for changed_factor in FACTOR_SPECS:
        for observed_factor in FACTOR_SPECS:
            expected = 1.0 if changed_factor == observed_factor else 0.0
            assert report.semantic_coupling_matrix[changed_factor][observed_factor] == expected

    assert report.strongest_pixel_interactions
    assert report.strongest_pixel_interactions[0]["mean_residual"] > 0.0
