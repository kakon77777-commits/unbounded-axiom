from __future__ import annotations

import pytest

from gsrt.db import RuntimeDB


def _seed_record(seed_id: str = "seed:a", *, status: str = "VALIDATED") -> dict:
    return {
        "seed_id": seed_id,
        "artifact_id": "artifact:a",
        "modality": "image",
        "family": "visual_compact",
        "payload": "ABCDEFGH",
        "payload_hash": "hash:payload",
        "status": status,
        "certificate_id": "cert:a",
        "freshness_key": "reference-image-reconstructor:v0.4",
        "metadata": {"evidence_level": "SYNTHETIC_VISUAL_GRAMMAR"},
    }


def test_library_schema_persists_validated_seed_factors_failures_and_events(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    record = _seed_record()

    db.record_validated_seed(record)
    db.record_seed_factor("seed:a", "identity", "alpha")
    db.record_seed_factor("seed:a", "style", "solid")
    db.record_library_failure(
        {
            "failure_id": "failure:a",
            "seed_id": "seed:a",
            "query_id": "query:a",
            "failure_class": "WRONG_FACTOR",
            "metadata": {"factor": "style"},
        }
    )
    db.record_library_event(
        {
            "event_id": "event:a",
            "subject_id": "seed:a",
            "event_type": "PROMOTED",
            "metadata": {"certificate_id": "cert:a"},
        }
    )

    assert db.count("validated_seeds") == 1
    assert db.count("seed_factors") == 2
    assert db.count("library_failures") == 1
    assert db.count("library_events") == 1
    assert db.get_validated_seed("seed:a")["status"] == "VALIDATED"
    assert db.get_seed_factors("seed:a") == {"identity": "alpha", "style": "solid"}


def test_query_validated_seeds_filters_factors_status_and_certificate(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    for seed_id, identity, style, status, cert in (
        ("seed:a", "alpha", "solid", "VALIDATED", "cert:a"),
        ("seed:b", "alpha", "striped", "STALE", "cert:b"),
        ("seed:c", "beta", "solid", "VALIDATED", ""),
    ):
        record = _seed_record(seed_id, status=status)
        record["certificate_id"] = cert
        db.record_validated_seed(record)
        db.record_seed_factor(seed_id, "identity", identity)
        db.record_seed_factor(seed_id, "style", style)

    rows = db.query_validated_seeds(
        {"identity": "alpha"},
        allowed_statuses=("VALIDATED",),
        require_certificate=True,
    )
    assert [row["seed_id"] for row in rows] == ["seed:a"]

    rows = db.query_validated_seeds(
        {"style": "solid"},
        allowed_statuses=("VALIDATED",),
        require_certificate=False,
    )
    assert [row["seed_id"] for row in rows] == ["seed:a", "seed:c"]


def test_library_batch_rolls_back_all_new_tables(tmp_path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")

    with pytest.raises(RuntimeError, match="rollback sentinel"):
        with db.batch():
            db.record_validated_seed(_seed_record())
            db.record_seed_factor("seed:a", "identity", "alpha")
            db.record_library_event(
                {
                    "event_id": "event:a",
                    "subject_id": "seed:a",
                    "event_type": "PROMOTED",
                    "metadata": {},
                }
            )
            raise RuntimeError("rollback sentinel")

    assert db.count("validated_seeds") == 0
    assert db.count("seed_factors") == 0
    assert db.count("library_events") == 0
