from pathlib import Path

import pytest

from gsrt.db import RuntimeDB
from gsrt.models import ArtifactRecord


def _artifact(name: str) -> ArtifactRecord:
    return ArtifactRecord(
        artifact_id=f"sha256:{name}",
        modality="text",
        source_hash=f"sha256:{name}",
        source_bytes=1,
        metadata={},
    )


def test_db_batch_commits_multiple_writes_atomically(tmp_path: Path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    with db.batch():
        db.record_artifact(_artifact("a"))
        db.record_artifact(_artifact("b"))
    assert db.count("artifacts") == 2


def test_db_batch_rolls_back_all_writes_on_exception(tmp_path: Path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    with pytest.raises(RuntimeError):
        with db.batch():
            db.record_artifact(_artifact("a"))
            raise RuntimeError("abort")
    assert db.count("artifacts") == 0
