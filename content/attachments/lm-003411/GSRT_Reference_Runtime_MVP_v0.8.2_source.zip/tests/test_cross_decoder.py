import pytest
from pathlib import Path

from gsrt.cross_decoder import CrossDecoderConfig, CrossDecoderRunner


def test_cross_decoder_matrix_separates_target_fidelity_consensus_and_portability(tmp_path: Path):
    runner = CrossDecoderRunner(tmp_path / "runtime")
    report = runner.run(
        CrossDecoderConfig(
            count=4,
            repetitions=1,
            families=("summary", "keyword", "freeform", "structured", "compact"),
            budget_bytes=512,
            family_budget_overrides={"compact": 7},
        )
    )

    assert report.artifact_count == 4
    assert report.source_visibility_violations == 0
    assert report.metadata["evidence_level"] == "INTERNAL_REFERENCE_VARIANTS"
    assert report.decoders == (
        "reference_exact:v0.3",
        "relational_interlingua:v0.3",
        "compact_core:v0.3",
    )

    assert report.matrix["freeform"]["reference_exact:v0.3"]["pass_rate"] == 1.0
    assert report.matrix["freeform"]["relational_interlingua:v0.3"]["pass_rate"] == 1.0
    assert report.matrix["freeform"]["compact_core:v0.3"]["pass_rate"] == 1.0

    assert report.matrix["compact"]["reference_exact:v0.3"]["pass_rate"] == 1.0
    assert report.matrix["compact"]["compact_core:v0.3"]["pass_rate"] == 1.0
    assert report.matrix["compact"]["relational_interlingua:v0.3"]["pass_rate"] == 0.0

    assert report.matrix["summary"]["compact_core:v0.3"]["pass_rate"] == 0.0
    assert all(cell["pass_rate"] == 0.0 for cell in report.matrix["keyword"].values())

    assert report.diagonal_pass_rate == 1.0
    assert report.off_diagonal_pass_rate == pytest.approx(5 / 6)
    assert report.interoperability_gap == pytest.approx(1 / 6)

    assert report.family_consensus["freeform"]["mean_pairwise_consensus"] == 1.0
    assert report.family_consensus["structured"]["mean_pairwise_consensus"] == 1.0
    assert report.family_consensus["compact"]["mean_pairwise_consensus"] == pytest.approx(1 / 3)

    assert report.control_stats["contradiction"]["pass_rate"] == 0.0
    assert report.control_stats["relation_shuffle"]["pass_rate"] == 0.0
    assert report.control_stats["random"]["pass_rate"] == 0.0
    assert report.control_stats["unrelated"]["pass_rate"] == 0.0
    assert report.control_stats["contradiction"]["mean_pairwise_consensus"] == 1.0
    assert report.control_stats["relation_shuffle"]["mean_pairwise_consensus"] == 1.0


def test_cross_decoder_runner_rejects_unknown_decoder_and_requires_two_artifacts_for_controls(tmp_path: Path):
    runner = CrossDecoderRunner(tmp_path / "runtime")

    try:
        runner.run(CrossDecoderConfig(count=1, include_controls=True))
    except ValueError as exc:
        assert "at least two artifacts" in str(exc)
    else:
        raise AssertionError("controls with one artifact should fail")

    try:
        runner.run(
            CrossDecoderConfig(
                count=2,
                decoders=("missing-decoder:v9",),
                include_controls=False,
            )
        )
    except ValueError as exc:
        assert "unknown decoder" in str(exc)
    else:
        raise AssertionError("unknown decoder should fail")
