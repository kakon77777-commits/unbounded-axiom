import json
from pathlib import Path

from gsrt.cli import main


def test_corpus_run_cli_creates_report_and_runtime_db(tmp_path: Path):
    out = tmp_path / "report.json"
    root = tmp_path / "runtime"
    rc = main([
        "corpus-run",
        "--root", str(root),
        "--count", "5",
        "--repetitions", "1",
        "--out", str(out),
    ])

    assert rc == 0
    report = json.loads(out.read_text())
    assert report["artifact_count"] == 5
    assert report["source_visibility_violations"] == 0
    assert (root / "runtime.sqlite3").exists()


def test_inspect_db_cli_returns_success(tmp_path: Path, capsys):
    root = tmp_path / "runtime"
    main(["corpus-run", "--root", str(root), "--count", "2", "--repetitions", "1"])
    rc = main(["inspect-db", "--root", str(root)])
    captured = capsys.readouterr()
    assert rc == 0
    assert '"artifacts": 2' in captured.out


def test_cli_description_tracks_v0_7_runtime():
    from gsrt.cli import build_parser

    assert "v0.8" in (build_parser().description or "")
