from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.db import RuntimeDB
from gsrt.image_extraction import encode_visual_compact
from gsrt.image_factors import FACTOR_SPECS
from gsrt.image_semantics import ImageSemantics
from gsrt.navigation import GenerationGoal, GoalCompiler, QueryPlanner, hamming_distance
from gsrt.retrieval import SeedRetriever


def _put_seed(db: RuntimeDB, seed_id: str, semantics: ImageSemantics) -> None:
    payload = encode_visual_compact(semantics)
    record = {
        "seed_id": seed_id,
        "artifact_id": f"artifact:{seed_id}",
        "modality": "image",
        "family": "visual_compact",
        "payload": payload,
        "payload_hash": f"hash:{seed_id}",
        "status": "REUSABLE",
        "certificate_id": f"cert:{seed_id}",
        "freshness_key": "reference-image-reconstructor:v0.4",
        "metadata": {},
    }
    db.record_validated_seed(record)
    for name in FACTOR_SPECS:
        db.record_seed_factor(seed_id, name, getattr(semantics, name))


def test_goal_compiler_requires_complete_known_visual_factors() -> None:
    compiler = GoalCompiler()
    target = ImageSemantics("orb", "alpha", "center", "above", "medium", "flat", "warm", "solid")

    goal = compiler.compile(target)

    assert isinstance(goal, GenerationGoal)
    assert goal.hard_constraints == {name: getattr(target, name) for name in FACTOR_SPECS}
    assert goal.modality == "image"
    assert goal.family == "visual_compact"

    bad = dict(goal.hard_constraints)
    bad["not_a_factor"] = "x"
    with pytest.raises(ValueError, match="unknown factor"):
        GenerationGoal(hard_constraints=bad)

    incomplete = dict(goal.hard_constraints)
    incomplete.pop("style")
    with pytest.raises(ValueError, match="complete visual goal"):
        GenerationGoal(hard_constraints=incomplete)


def test_query_planner_selects_true_nearest_reusable_seed(tmp_path: Path) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    a = ImageSemantics("orb", "alpha", "center", "above", "medium", "flat", "warm", "solid")
    b = ImageSemantics("orb", "alpha", "center", "above", "wide", "left", "warm", "solid")
    c = ImageSemantics("spire", "gamma", "right", "below", "close", "right", "cool", "striped")
    _put_seed(db, "seed-a", a)
    _put_seed(db, "seed-b", b)
    _put_seed(db, "seed-c", c)
    target = ImageSemantics("orb", "alpha", "center", "above", "wide", "right", "warm", "solid")
    goal = GoalCompiler().compile(target)

    plan = QueryPlanner().compile(goal, max_candidates=3)
    portfolio = SeedRetriever(db).retrieve(plan.library_query)

    assert portfolio.selected_seed_id == "seed-b"
    selected = db.get_seed_factors(portfolio.selected_seed_id)
    assert hamming_distance(selected, goal.hard_constraints) == 1
    assert plan.library_query.required_factors == {}
    assert plan.library_query.optional_factors == goal.hard_constraints
