from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import pytest

from gsrt.library_experiment import LibraryExperimentRunner
from gsrt.qd import BehaviorDescriptorSchema, QDArchive


def _seeded_library(tmp_path: Path, count: int = 96):
    runner = LibraryExperimentRunner(tmp_path / "library")
    records = runner._build_library(count)
    return runner.library, records


def _descriptor_tuple(db, seed_id: str) -> tuple[str, str, str]:
    factors = db.get_seed_factors(seed_id)
    return factors["style"], factors["composition"], factors["camera"]


def test_visual_descriptor_has_27_stable_niches() -> None:
    schema = BehaviorDescriptorSchema.visual_v081()

    assert schema.descriptor_id == "visual-style-composition-camera"
    assert schema.version == "0.8.1"
    assert schema.dimensions == ("style", "composition", "camera")
    assert len(schema.all_niches()) == 27
    assert len(set(schema.all_niches())) == 27
    assert schema.all_niches() == tuple(sorted(schema.all_niches()))


def test_qd_archive_references_reusable_seed_without_mutating_seed(tmp_path: Path) -> None:
    library, records = _seeded_library(tmp_path, 24)
    seed_id = records[0]["seed_id"]
    before = library.db.get_validated_seed(seed_id)
    archive = QDArchive(library.db, BehaviorDescriptorSchema.visual_v081())

    result = archive.consider(seed_id, quality=1.0)

    after = library.db.get_validated_seed(seed_id)
    assert result.accepted is True
    assert result.reason == "EMPTY_NICHE"
    assert before == after
    cells = archive.cells()
    assert len(cells) == 1
    assert cells[0].elite_seed_id == seed_id


def test_qd_archive_equal_quality_tie_is_deterministic(tmp_path: Path) -> None:
    library, records = _seeded_library(tmp_path, 96)
    by_niche: dict[tuple[str, str, str], list[str]] = defaultdict(list)
    for record in records:
        by_niche[_descriptor_tuple(library.db, record["seed_id"])].append(record["seed_id"])
    pair = next(sorted(ids)[:2] for ids in by_niche.values() if len(ids) >= 2)
    expected = min(pair)

    first = QDArchive(library.db, BehaviorDescriptorSchema.visual_v081())
    for seed_id in reversed(pair):
        first.consider(seed_id, quality=1.0)
    assert first.cells()[0].elite_seed_id == expected

    # Rebuild into a clean QD namespace over the same SeedStore in opposite order.
    schema = BehaviorDescriptorSchema(
        descriptor_id="visual-style-composition-camera-rebuild",
        version="0.8.1",
        dimensions=("style", "composition", "camera"),
        bins=BehaviorDescriptorSchema.visual_v081().bins,
    )
    second = QDArchive(library.db, schema)
    for seed_id in pair:
        second.consider(seed_id, quality=1.0)
    assert second.cells()[0].elite_seed_id == expected


def test_qd_archive_rejects_stale_seed(tmp_path: Path) -> None:
    library, records = _seeded_library(tmp_path, 24)
    seed_id = records[0]["seed_id"]
    library.mark_stale(seed_id, reason="qd-test")
    archive = QDArchive(library.db, BehaviorDescriptorSchema.visual_v081())

    with pytest.raises(ValueError, match="reusable"):
        archive.consider(seed_id, quality=1.0)
