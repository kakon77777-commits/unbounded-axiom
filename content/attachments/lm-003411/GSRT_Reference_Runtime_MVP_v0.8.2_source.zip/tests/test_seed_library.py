from __future__ import annotations

import hashlib

import pytest

from gsrt.certificates import CertificateIssuer
from gsrt.dependencies import DependencyAuditor, DependencyPolicy
from gsrt.image_evaluation import ImageFidelityEvaluator
from gsrt.image_extraction import ReferenceImageSeedExtractor
from gsrt.image_reconstruction import ReferenceImageReconstructor
from gsrt.image_semantics import ImageSemantics, render_reference_image
from gsrt.library import SeedLibrary


def _validated_fixture(library: SeedLibrary, semantics: ImageSemantics):
    png = render_reference_image(semantics)
    artifact = library.artifacts.ingest_bytes(png, "image", {"fixture": True})
    library.db.record_artifact(artifact)
    extractor = ReferenceImageSeedExtractor(library.artifacts.read_bytes)
    seed = extractor.extract(artifact, "visual_compact", 8)
    audit = DependencyAuditor().audit(seed, DependencyPolicy.strict())
    output_store = library.outputs
    reconstructor = ReferenceImageReconstructor(output_store)
    result = reconstructor.reconstruct(seed, 0)
    evaluation = ImageFidelityEvaluator(output_store.read_bytes).evaluate(semantics, png, result)
    certificate = CertificateIssuer(1.0).issue(seed, audit, [evaluation], reconstructor.generator_id)
    return artifact, seed, certificate


def test_promote_image_seed_requires_passing_certificate_and_indexes_observed_factors(tmp_path):
    library = SeedLibrary(tmp_path)
    semantics = ImageSemantics("orb", "alpha", "left", "above", "wide", "left", "warm", "solid")
    artifact, seed, certificate = _validated_fixture(library, semantics)

    record = library.promote_image_seed(artifact, seed, certificate)

    assert record["status"] == "REUSABLE"
    assert record["certificate_id"] == certificate.certificate_id
    assert record["payload_hash"] == hashlib.sha256(seed.payload.encode("utf-8")).hexdigest()
    assert library.db.get_seed_factors(seed.seed_id) == {
        "camera": "wide",
        "composition": "left",
        "identity": "alpha",
        "lighting": "left",
        "palette": "warm",
        "spatial": "above",
        "style": "solid",
        "subject": "orb",
    }
    assert library.db.count("library_events") == 1


def test_promote_rejects_failed_or_mismatched_certificate(tmp_path):
    library = SeedLibrary(tmp_path)
    semantics = ImageSemantics("orb", "alpha", "left", "above", "wide", "left", "warm", "solid")
    artifact, seed, certificate = _validated_fixture(library, semantics)

    failed = certificate.__class__(**{**certificate.to_dict(), "passed": False})
    with pytest.raises(ValueError, match="passing certificate"):
        library.promote_image_seed(artifact, seed, failed)

    wrong = certificate.__class__(**{**certificate.to_dict(), "seed_id": "seed:other"})
    with pytest.raises(ValueError, match="certificate seed mismatch"):
        library.promote_image_seed(artifact, seed, wrong)


def test_stale_seed_is_excluded_from_reusable_records_and_snapshot_is_deterministic(tmp_path):
    library = SeedLibrary(tmp_path)
    s1 = ImageSemantics("orb", "alpha", "left", "above", "wide", "left", "warm", "solid")
    s2 = ImageSemantics("block", "beta", "center", "below", "medium", "right", "cool", "striped")
    a1, seed1, cert1 = _validated_fixture(library, s1)
    a2, seed2, cert2 = _validated_fixture(library, s2)
    library.promote_image_seed(a1, seed1, cert1)
    library.promote_image_seed(a2, seed2, cert2)

    digest_before = library.snapshot_digest()
    assert digest_before == library.snapshot_digest()

    library.mark_stale(seed1.seed_id, reason="generator update")

    assert [row["seed_id"] for row in library.records()] == [seed2.seed_id]
    assert {row["seed_id"] for row in library.records(include_stale=True)} == {seed1.seed_id, seed2.seed_id}
    assert library.snapshot_digest() != digest_before


def test_library_records_failure_with_provenance(tmp_path):
    library = SeedLibrary(tmp_path)
    failure = library.record_failure(
        query_id="query:1",
        failure_class="NO_MATCH",
        seed_id=None,
        metadata={"required": {"identity": "alpha"}},
    )
    assert failure["failure_id"].startswith("sha256:")
    assert library.db.count("library_failures") == 1
