from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.library_experiment import LibraryExperimentRunner
from gsrt.qd import BehaviorDescriptorSchema, QDArchive
from gsrt.qd_experiment import QDExperimentConfig, QDExperimentRunner


def test_descriptor_shuffle_reduces_relevant_goal_utility(tmp_path: Path) -> None:
    report = QDExperimentRunner(tmp_path / "run").run(
        QDExperimentConfig(initial_count=96, candidate_budget=243)
    )

    assert report.qd_archive["goal_coverage"] == 1.0
    assert report.controls["descriptor_shuffle_archive_coverage"] == 1.0
    assert report.controls["descriptor_shuffle_goal_coverage"] < report.qd_archive["goal_coverage"]


def test_novelty_only_cannot_admit_non_reusable_candidate(tmp_path: Path) -> None:
    report = QDExperimentRunner(tmp_path / "run").run(
        QDExperimentConfig(initial_count=24, candidate_budget=81)
    )

    assert report.controls["novelty_only_invalid_admissions"] == 0.0


def test_persisted_descriptor_version_mismatch_fails_closed(tmp_path: Path) -> None:
    runner = LibraryExperimentRunner(tmp_path / "library")
    records = runner._build_library(24)
    archive = QDArchive(runner.library.db, BehaviorDescriptorSchema.visual_v081())
    seed_id = records[0]["seed_id"]
    accepted = archive.consider(seed_id, quality=1.0)
    stored = runner.library.db.get_qd_cell(archive.schema.key, accepted.niche_key)
    assert stored is not None
    corrupted = dict(stored)
    corrupted["descriptor_version"] = "0.8.0"
    runner.library.db.record_qd_cell(corrupted)

    with pytest.raises(ValueError, match="descriptor version"):
        archive.cells()
