from __future__ import annotations

from pathlib import Path

from gsrt.db import RuntimeDB
from gsrt.image_extraction import encode_visual_compact
from gsrt.image_factors import FACTOR_SPECS
from gsrt.image_semantics import ImageSemantics
from gsrt.navigation import (
    FailureMap,
    GenerationGoal,
    GoalCompiler,
    RuleBasedNavigationPlanner,
)


def _put_seed(db: RuntimeDB, seed_id: str, semantics: ImageSemantics) -> None:
    payload = encode_visual_compact(semantics)
    db.record_validated_seed(
        {
            "seed_id": seed_id,
            "artifact_id": f"artifact:{seed_id}",
            "modality": "image",
            "family": "visual_compact",
            "payload": payload,
            "payload_hash": f"hash:{seed_id}",
            "status": "REUSABLE",
            "certificate_id": f"cert:{seed_id}",
            "freshness_key": "reference-image-reconstructor:v0.4",
            "metadata": {},
        }
    )
    for name in FACTOR_SPECS:
        db.record_seed_factor(seed_id, name, getattr(semantics, name))


def test_failure_map_persists_deterministic_navigation_failure(tmp_path: Path) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    failures = FailureMap(db)

    first = failures.record(
        state_signature="state:abc",
        operator_id="replace_factor:lighting",
        donor_seed_id="donor-a",
        goal_id="goal-1",
        failure_class="KNOWN_ROUTE_CONFLICT",
        metadata={"reason": "prior evidence"},
    )
    second = failures.record(
        state_signature="state:abc",
        operator_id="replace_factor:lighting",
        donor_seed_id="donor-a",
        goal_id="goal-1",
        failure_class="KNOWN_ROUTE_CONFLICT",
        metadata={"reason": "prior evidence"},
    )

    assert first["failure_id"] == second["failure_id"]
    assert failures.is_known("state:abc", "replace_factor:lighting", "donor-a", "goal-1")
    assert len(failures.records(goal_id="goal-1")) == 1
    assert db.count("navigation_failures") == 1


def test_history_aware_planner_avoids_known_failed_donor(tmp_path: Path) -> None:
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    current = ImageSemantics("orb", "alpha", "center", "above", "medium", "flat", "warm", "solid")
    goal_sem = ImageSemantics("orb", "alpha", "center", "above", "medium", "right", "warm", "solid")
    donor_a = ImageSemantics("spire", "beta", "left", "below", "wide", "right", "cool", "outline")
    donor_b = ImageSemantics("block", "gamma", "left", "below", "wide", "right", "cool", "outline")
    _put_seed(db, "donor-a", donor_a)
    _put_seed(db, "donor-b", donor_b)
    goal: GenerationGoal = GoalCompiler().compile(goal_sem)
    failures = FailureMap(db)
    state_signature = encode_visual_compact(current)
    failures.record(
        state_signature=state_signature,
        operator_id="replace_factor:lighting",
        donor_seed_id="donor-a",
        goal_id=goal.goal_id,
        failure_class="KNOWN_ROUTE_CONFLICT",
    )
    planner = RuleBasedNavigationPlanner(db, failures)

    with_history = planner.next_action(current, goal, use_history=True)
    without_history = planner.next_action(current, goal, use_history=False)

    assert with_history.factor_name == "lighting"
    assert with_history.donor_seed_id == "donor-b"
    assert with_history.avoided_known_failures == 1
    assert without_history.donor_seed_id == "donor-a"
    assert failures.is_known(
        state_signature,
        without_history.operator_id,
        without_history.donor_seed_id,
        goal.goal_id,
    )
