from pathlib import Path

from gsrt.db import RuntimeDB
from gsrt.models import ArtifactRecord


def test_runtime_db_records_and_reads_artifact(tmp_path: Path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    record = ArtifactRecord(
        artifact_id="sha256:abc",
        modality="text",
        source_hash="sha256:abc",
        source_bytes=3,
        metadata={"x": 1},
    )
    db.record_artifact(record)
    loaded = db.get_artifact("sha256:abc")

    assert loaded == record
