from gsrt.certificates import CertificateIssuer
from gsrt.dependencies import DependencyAudit
from gsrt.models import EvaluationResult, SeedCandidate


def make_eval(run_id, hard_pass=True):
    return EvaluationResult(
        evaluation_id=f"eval:{run_id}",
        run_id=run_id,
        seed_id="seed:x",
        scores={"overall": 1.0 if hard_pass else 0.5},
        hard_pass=hard_pass,
        passed=hard_pass,
    )


def test_certificate_requires_dependency_pass_and_repeated_success_probability():
    seed = SeedCandidate("seed:x", "artifact:x", "structured", "{}", 2, 64)
    issuer = CertificateIssuer(min_success_probability=1.0)
    cert = issuer.issue(
        seed,
        DependencyAudit(True, 0, 2, ()),
        [make_eval("r1"), make_eval("r2")],
        generator_scope="reference-reconstructor:v0.1",
    )
    bad = issuer.issue(
        seed,
        DependencyAudit(False, 10, 12, ("PRIVATE_PER_ITEM",)),
        [make_eval("r1"), make_eval("r2")],
        generator_scope="reference-reconstructor:v0.1",
    )

    assert cert.passed is True
    assert cert.success_probability == 1.0
    assert bad.passed is False
