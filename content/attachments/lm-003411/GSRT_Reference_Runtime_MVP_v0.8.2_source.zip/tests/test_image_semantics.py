from gsrt.image_semantics import ImageSemantics, analyze_reference_image, render_reference_image


def test_reference_image_roundtrip_recovers_all_visual_factors():
    cases = [
        ImageSemantics("orb", "alpha", "left", "above", "wide", "left", "warm", "solid"),
        ImageSemantics("block", "beta", "center", "below", "medium", "right", "cool", "striped"),
        ImageSemantics("spire", "gamma", "right", "beside", "close", "flat", "mono", "outline"),
        ImageSemantics("orb", "gamma", "right", "below", "close", "right", "warm", "striped"),
    ]

    for semantics in cases:
        png = render_reference_image(semantics)
        recovered = analyze_reference_image(png)
        assert recovered == semantics


def test_rendered_image_is_deterministic_for_same_semantics():
    semantics = ImageSemantics("block", "alpha", "center", "above", "medium", "flat", "cool", "solid")
    assert render_reference_image(semantics) == render_reference_image(semantics)


def test_wide_spire_gamma_keeps_right_lighting_observable():
    semantics = ImageSemantics("spire", "gamma", "center", "below", "wide", "right", "cool", "solid")
    assert analyze_reference_image(render_reference_image(semantics)) == semantics


def test_reference_visual_grammar_is_identifiable_over_full_factor_space():
    from itertools import product
    from gsrt.image_semantics import CAMERAS, COMPOSITIONS, IDENTITIES, LIGHTINGS, PALETTES, SPATIALS, STYLES, SUBJECTS

    for values in product(SUBJECTS, IDENTITIES, COMPOSITIONS, SPATIALS, CAMERAS, LIGHTINGS, PALETTES, STYLES):
        semantics = ImageSemantics(*values)
        assert analyze_reference_image(render_reference_image(semantics)) == semantics
