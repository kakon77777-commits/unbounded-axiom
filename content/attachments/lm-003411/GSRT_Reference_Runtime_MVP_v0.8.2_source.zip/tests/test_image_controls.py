from pathlib import Path

from gsrt.image_controls import make_image_controls
from gsrt.image_evaluation import ImageFidelityEvaluator
from gsrt.image_extraction import ReferenceImageSeedExtractor
from gsrt.image_reconstruction import ReferenceImageReconstructor
from gsrt.image_semantics import ImageSemantics, render_reference_image
from gsrt.models import ArtifactRecord
from gsrt.store import ArtifactStore


def _record(png: bytes, suffix: str) -> ArtifactRecord:
    import hashlib

    digest = hashlib.sha256(png + suffix.encode()).hexdigest()
    return ArtifactRecord(f"sha256:{digest}", "image", f"sha256:{digest}", len(png), {})


def test_image_negative_controls_do_not_pass_source_contract(tmp_path: Path):
    source_semantics = ImageSemantics("block", "beta", "center", "above", "medium", "left", "warm", "solid")
    other_semantics = ImageSemantics("spire", "gamma", "right", "below", "close", "right", "cool", "outline")
    source_png = render_reference_image(source_semantics)
    other_png = render_reference_image(other_semantics)
    extractor = ReferenceImageSeedExtractor(lambda artifact_id: source_png if artifact_id.endswith("source") else other_png)

    # Use explicit ids so the reader path cannot inspect semantic metadata.
    source = ArtifactRecord("image:source", "image", "image:source", len(source_png), {})
    other = ArtifactRecord("image:other", "image", "image:other", len(other_png), {})
    base = extractor.extract(source, "visual_structured", 512)
    unrelated = extractor.extract(other, "visual_structured", 512)

    output_store = ArtifactStore(tmp_path / "outputs")
    reconstructor = ReferenceImageReconstructor(output_store)
    evaluator = ImageFidelityEvaluator(output_store.read_bytes)

    controls = make_image_controls(base, unrelated)
    assert set(controls) == {"random", "wrong_identity", "spatial_flip", "style_swap", "unrelated"}
    for name, seed in controls.items():
        result = reconstructor.reconstruct(seed, 0)
        evaluation = evaluator.evaluate(source_semantics, source_png, result)
        assert evaluation.passed is False, name
