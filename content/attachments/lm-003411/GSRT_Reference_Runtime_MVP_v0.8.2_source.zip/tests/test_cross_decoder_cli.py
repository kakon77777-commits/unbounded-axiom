import hashlib
import json
from pathlib import Path

from gsrt.cli import main


def test_cross_decoder_cli_writes_report_and_reproducibility_bundle(tmp_path: Path):
    root = tmp_path / "runtime"
    out = tmp_path / "cross_decoder_report.json"
    bundle = tmp_path / "bundle"

    rc = main(
        [
            "cross-decoder",
            "--root",
            str(root),
            "--count",
            "4",
            "--repetitions",
            "1",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["metadata"]["evidence_level"] == "INTERNAL_REFERENCE_VARIANTS"
    assert report["metadata"]["independent_cross_model_claim"] is False
    assert report["family_budgets"]["compact"] == 7
    assert report["matrix"]["compact"]["relational_interlingua:v0.3"]["pass_rate"] == 0.0
    assert report["diagonal_pass_rate"] == 1.0

    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    bundled_report = json.loads((bundle / "report.json").read_text(encoding="utf-8"))
    checksums = (bundle / "CHECKSUMS.sha256").read_text(encoding="utf-8")

    assert manifest["bundle_version"] == "0.3.0"
    assert manifest["experiment_id"] == report["experiment_id"]
    assert manifest["evidence_level"] == "INTERNAL_REFERENCE_VARIANTS"
    assert bundled_report["off_diagonal_pass_rate"] == report["off_diagonal_pass_rate"]
    for filename in ("manifest.json", "report.json"):
        digest = hashlib.sha256((bundle / filename).read_bytes()).hexdigest()
        assert f"{digest}  {filename}" in checksums


def test_cross_decoder_cli_accepts_family_and_decoder_subsets(tmp_path: Path):
    out = tmp_path / "subset.json"
    rc = main(
        [
            "cross-decoder",
            "--root",
            str(tmp_path / "runtime"),
            "--count",
            "2",
            "--repetitions",
            "1",
            "--families",
            "freeform,structured",
            "--decoders",
            "reference_exact:v0.3,relational_interlingua:v0.3",
            "--out",
            str(out),
            "--no-controls",
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    assert report["families"] == ["freeform", "structured"]
    assert report["decoders"] == ["reference_exact:v0.3", "relational_interlingua:v0.3"]
