from __future__ import annotations

from pathlib import Path

import pytest

from gsrt.branches import BranchManager, PromotionGate
from gsrt.composition import CompatibilityEngine, CompositionContract, FactorAssignment
from gsrt.db import RuntimeDB
from gsrt.image_extraction import decode_visual_compact, encode_visual_compact
from gsrt.image_factors import FACTOR_SPECS
from gsrt.image_semantics import ImageSemantics
from gsrt.models import ArtifactRecord, SeedCandidate, ValidationCertificate


def _record(seed_id: str, semantics: ImageSemantics, *, status: str = "REUSABLE") -> dict:
    payload = encode_visual_compact(semantics)
    return {
        "seed_id": seed_id,
        "artifact_id": f"artifact:{seed_id}",
        "modality": "image",
        "family": "visual_compact",
        "payload": payload,
        "payload_hash": f"payload-hash:{seed_id}",
        "status": status,
        "certificate_id": f"cert:{seed_id}",
        "freshness_key": "reference-image-reconstructor:v0.4",
        "metadata": {},
    }


def _put_seed(db: RuntimeDB, seed_id: str, semantics: ImageSemantics, *, status: str = "REUSABLE") -> dict:
    record = _record(seed_id, semantics, status=status)
    db.record_validated_seed(record)
    for name in FACTOR_SPECS:
        db.record_seed_factor(seed_id, name, getattr(semantics, name))
    return record


def _setup(tmp_path: Path):
    db = RuntimeDB(tmp_path / "runtime.sqlite3")
    recipient_sem = ImageSemantics("orb", "alpha", "center", "above", "medium", "flat", "warm", "solid")
    donor_sem = ImageSemantics("spire", "beta", "left", "below", "wide", "left", "cool", "outline")
    recipient = _put_seed(db, "recipient", recipient_sem)
    _put_seed(db, "donor", donor_sem)
    contract = CompositionContract(
        recipient_seed_id="recipient",
        assignments=(FactorAssignment("lighting", "donor"),),
        protected_factors=tuple(name for name in FACTOR_SPECS if name != "lighting"),
    )
    compatibility = CompatibilityEngine(db).check(contract)
    assert compatibility.passed
    return db, recipient, recipient_sem, donor_sem, contract, compatibility


def _candidate_for_branch(branch: dict, artifact_id: str) -> SeedCandidate:
    seed_id = f"candidate:{branch['branch_id']}"
    return SeedCandidate(
        seed_id=seed_id,
        artifact_id=artifact_id,
        family="visual_compact",
        payload=branch["candidate_payload"],
        payload_bytes=8,
        budget_bytes=8,
    )


def _passing_certificate(seed: SeedCandidate) -> ValidationCertificate:
    return ValidationCertificate(
        certificate_id=f"cert:{seed.seed_id}",
        seed_id=seed.seed_id,
        generator_scope="reference-image-reconstructor:v0.4",
        repeated_runs=1,
        success_probability=1.0,
        dependency_passed=True,
        passed=True,
    )


def test_branch_creation_isolates_candidate_from_validated_parent(tmp_path: Path) -> None:
    db, recipient, recipient_sem, donor_sem, contract, compatibility = _setup(tmp_path)

    branch = BranchManager(db).create(contract, compatibility)

    parent_after = db.get_validated_seed("recipient")
    candidate = decode_visual_compact(branch["candidate_payload"])
    assert parent_after == recipient
    assert candidate.lighting == donor_sem.lighting
    for name in FACTOR_SPECS:
        if name != "lighting":
            assert getattr(candidate, name) == getattr(recipient_sem, name)
    assert branch["status"] == "OPEN"
    assert db.count("composition_branches") == 1
    assert db.count("validated_seeds") == 2


def test_failed_evaluation_blocks_promotion_and_rejects_branch(tmp_path: Path) -> None:
    db, _, _, _, contract, compatibility = _setup(tmp_path)
    branch = BranchManager(db).create(contract, compatibility)
    artifact = ArtifactRecord("artifact:new", "image", "hash:new", 10)
    db.record_artifact(artifact)
    seed = _candidate_for_branch(branch, artifact.artifact_id)
    cert = ValidationCertificate(
        certificate_id="cert:failed",
        seed_id=seed.seed_id,
        generator_scope="reference-image-reconstructor:v0.4",
        repeated_runs=1,
        success_probability=0.0,
        dependency_passed=True,
        passed=False,
    )

    with pytest.raises(ValueError, match="passing certificate"):
        PromotionGate(db).promote(branch["branch_id"], seed, cert)

    assert db.get_composition_branch(branch["branch_id"])["status"] == "REJECTED"
    assert db.count("validated_seeds") == 2


def test_moved_base_hash_blocks_promotion_and_marks_branch_stale(tmp_path: Path) -> None:
    db, recipient, _, _, contract, compatibility = _setup(tmp_path)
    branch = BranchManager(db).create(contract, compatibility)
    moved = dict(recipient)
    moved["payload_hash"] = "payload-hash:moved"
    db.record_validated_seed(moved)
    artifact = ArtifactRecord("artifact:new", "image", "hash:new", 10)
    db.record_artifact(artifact)
    seed = _candidate_for_branch(branch, artifact.artifact_id)
    cert = _passing_certificate(seed)

    with pytest.raises(ValueError, match="branch base moved"):
        PromotionGate(db).promote(branch["branch_id"], seed, cert)

    assert db.get_composition_branch(branch["branch_id"])["status"] == "STALE"
    assert db.count("validated_seeds") == 2


def test_passing_branch_promotes_new_reusable_seed_with_lineage(tmp_path: Path) -> None:
    db, recipient, recipient_sem, donor_sem, contract, compatibility = _setup(tmp_path)
    branch = BranchManager(db).create(contract, compatibility)
    artifact = ArtifactRecord("artifact:new", "image", "hash:new", 10)
    db.record_artifact(artifact)
    seed = _candidate_for_branch(branch, artifact.artifact_id)
    cert = _passing_certificate(seed)
    db.record_seed_candidate(seed)
    db.record_certificate(cert)

    promoted = PromotionGate(db).promote(branch["branch_id"], seed, cert)

    assert promoted["status"] == "REUSABLE"
    assert promoted["payload"] == branch["candidate_payload"]
    factors = db.get_seed_factors(seed.seed_id)
    assert factors["lighting"] == donor_sem.lighting
    assert factors["identity"] == recipient_sem.identity
    assert db.get_validated_seed("recipient") == recipient
    persisted_branch = db.get_composition_branch(branch["branch_id"])
    assert persisted_branch["status"] == "PROMOTED"
    assert persisted_branch["promoted_seed_id"] == seed.seed_id
    assert db.count("validated_seeds") == 3
    assert db.count("lineage_edges") == 2


def test_promotion_deduplicates_existing_reusable_state_without_overwriting_provenance(tmp_path: Path) -> None:
    db, _, _, _, contract, compatibility = _setup(tmp_path)
    branch = BranchManager(db).create(contract, compatibility)
    existing_semantics = decode_visual_compact(branch["candidate_payload"])
    existing_record = _put_seed(db, "existing", existing_semantics)
    existing_record = dict(existing_record)
    existing_record["metadata"] = {"promotion": "validated-retrospective-image:v0.6"}
    db.record_validated_seed(existing_record)
    artifact = ArtifactRecord(existing_record["artifact_id"], "image", "hash:existing", 10)
    db.record_artifact(artifact)
    seed = SeedCandidate(
        seed_id="existing",
        artifact_id=artifact.artifact_id,
        family="visual_compact",
        payload=branch["candidate_payload"],
        payload_bytes=8,
        budget_bytes=8,
    )
    cert = _passing_certificate(seed)

    promoted = PromotionGate(db).promote(branch["branch_id"], seed, cert)

    assert promoted == existing_record
    assert db.get_validated_seed("existing") == existing_record
    persisted_branch = db.get_composition_branch(branch["branch_id"])
    assert persisted_branch["status"] == "PROMOTED"
    assert persisted_branch["promotion_mode"] == "EXISTING_REUSABLE"
    assert persisted_branch["promoted_seed_id"] == "existing"
    assert db.count("validated_seeds") == 3
