from pathlib import Path

from gsrt.experiment import ExperimentConfig, ExperimentRunner


def test_experiment_can_suppress_negative_controls_for_budget_sweep(tmp_path: Path):
    runner = ExperimentRunner(tmp_path / "runtime")
    report = runner.run(
        ExperimentConfig(
            count=3,
            budget_bytes=160,
            repetitions=1,
            families=("structured",),
            include_controls=False,
        )
    )

    assert report.control_stats["random"]["total"] == 0.0
    assert report.control_stats["relation_shuffle"]["total"] == 0.0


def test_family_stats_include_mean_cost_and_fidelity(tmp_path: Path):
    runner = ExperimentRunner(tmp_path / "runtime")
    report = runner.run(
        ExperimentConfig(
            count=2,
            budget_bytes=7,
            repetitions=2,
            families=("compact",),
            include_controls=False,
        )
    )

    stats = report.family_stats["compact"]
    assert stats["pass_rate"] == 1.0
    assert stats["mean_payload_bytes"] == 7.0
    assert stats["mean_adjusted_cost_bytes"] == 7.0
    assert stats["evaluation_runs"] == 4.0
    assert stats["mean_relation"] == 1.0
    assert stats["mean_style"] == 0.0
    assert stats["mean_overall"] == 0.875


def test_db_exposes_joined_seed_certificate_outcomes(tmp_path: Path):
    runner = ExperimentRunner(tmp_path / "runtime")
    runner.run(
        ExperimentConfig(
            count=2,
            budget_bytes=7,
            repetitions=1,
            families=("compact",),
            include_controls=False,
        )
    )

    outcomes = runner.db.seed_certificate_outcomes()
    assert len(outcomes) == 2
    assert {row["family"] for row in outcomes} == {"compact"}
    assert {row["budget_bytes"] for row in outcomes} == {7}
    assert {row["payload_bytes"] for row in outcomes} == {7}
    assert {row["adjusted_cost_bytes"] for row in outcomes} == {7}
    assert all(row["passed"] for row in outcomes)
    assert all(row["source_bytes"] > row["payload_bytes"] for row in outcomes)
