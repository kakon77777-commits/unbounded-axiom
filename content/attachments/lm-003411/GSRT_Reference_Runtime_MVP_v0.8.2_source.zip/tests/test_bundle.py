import json
from pathlib import Path

from gsrt.bundle import export_bundle
from gsrt.models import ExperimentReport


def test_export_bundle_writes_report_manifest_and_checksums(tmp_path: Path):
    report = ExperimentReport(
        experiment_id="sha256:exp",
        artifact_count=2,
        seed_count=8,
        family_stats={},
        control_stats={},
        source_visibility_violations=0,
        certificate_passed=6,
        certificate_total=8,
        metadata={"x": 1},
    )
    bundle = export_bundle(report, tmp_path / "bundle")

    assert (bundle / "report.json").exists()
    assert (bundle / "manifest.json").exists()
    assert (bundle / "CHECKSUMS.sha256").exists()
    assert json.loads((bundle / "report.json").read_text())["artifact_count"] == 2
