import json

from gsrt.cli import main


def test_factor_run_cli_writes_v05_report_and_bundle(tmp_path):
    out = tmp_path / "factor-report.json"
    bundle = tmp_path / "factor-bundle"
    rc = main(
        [
            "factor-run",
            "--root",
            str(tmp_path / "runtime"),
            "--count",
            "6",
            "--out",
            str(out),
            "--bundle",
            str(bundle),
        ]
    )

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))
    assert report["artifact_count"] == 6
    assert report["factor_count"] == 8
    assert report["metadata"]["runtime_version"] == "0.5.0"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_GRAMMAR"
    assert manifest["bundle_version"] == "0.5.0"
    assert manifest["experiment"] == "factorization_ablation"
    assert (bundle / "CHECKSUMS.sha256").exists()
