from pathlib import Path
import pytest
from gsrt.fleet import FleetWorker, MutationPrior, MutationProposal, mutate_descriptor
from gsrt.image_factors import replace_factor
from gsrt.image_extraction import decode_visual_compact
from gsrt.library_experiment import LibraryExperimentRunner


def _setup(tmp_path: Path):
    runner = LibraryExperimentRunner(tmp_path)
    records = runner._build_library(1)
    record = records[0]
    parent = decode_visual_compact(str(record["payload"]))
    worker = FleetWorker("worker-a", MutationPrior("balanced", (1 / 3, 1 / 3, 1 / 3)))
    proposal = mutate_descriptor(parent, worker, worker_index=0, trial=0, attempt=0, experiment_seed="fleet-validation")
    return runner.library, record, proposal


def test_validated_mutation_becomes_reusable_and_records_lineage(tmp_path):
    from gsrt.fleet_validation import MutationValidator
    library, parent_record, proposal = _setup(tmp_path / "runtime")
    result = MutationValidator(library).validate(str(parent_record["seed_id"]), proposal)
    assert result.passed is True
    assert result.duplicate_existing is False
    child = library.db.get_validated_seed(result.seed_id)
    assert child is not None
    assert child["status"] == "REUSABLE"
    assert decode_visual_compact(str(child["payload"])) == proposal.child
    edges = library.db._fetchall("SELECT operation, source_id, target_id FROM lineage_edges WHERE edge_id = ?", (result.lineage_edge_id,))
    assert len(edges) == 1
    assert edges[0]["operation"] == "mutated_from"
    assert edges[0]["source_id"] == parent_record["seed_id"]
    assert edges[0]["target_id"] == result.seed_id


def test_duplicate_mutation_reuses_existing_identity_without_overwriting_metadata(tmp_path):
    from gsrt.fleet_validation import MutationValidator
    library, parent_record, proposal = _setup(tmp_path / "runtime")
    validator = MutationValidator(library)
    first = validator.validate(str(parent_record["seed_id"]), proposal)
    before = library.db.get_validated_seed(first.seed_id)
    second = validator.validate(str(parent_record["seed_id"]), proposal)
    after = library.db.get_validated_seed(first.seed_id)
    assert first.duplicate_existing is False
    assert second.duplicate_existing is True
    assert second.seed_id == first.seed_id
    assert before == after


def test_malformed_mutation_delta_fails_closed_without_new_reusable_seed(tmp_path):
    from gsrt.fleet_validation import MutationValidator
    library, parent_record, proposal = _setup(tmp_path / "runtime")
    before = {record["seed_id"] for record in library.records()}
    wrong_child = replace_factor(proposal.parent, "camera", "close" if proposal.parent.camera != "close" else "wide")
    malformed = MutationProposal(parent=proposal.parent, child=wrong_child, factor="style", old_value=proposal.parent.style, new_value=proposal.parent.style, worker_id=proposal.worker_id, prior_name=proposal.prior_name)
    with pytest.raises(ValueError, match="proposal delta"):
        MutationValidator(library).validate(str(parent_record["seed_id"]), malformed)
    after = {record["seed_id"] for record in library.records()}
    assert after == before
