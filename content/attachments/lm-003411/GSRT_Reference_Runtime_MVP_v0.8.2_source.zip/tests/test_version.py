import gsrt


def test_runtime_version_is_0_8_2():
    assert gsrt.__version__ == "0.8.2"
