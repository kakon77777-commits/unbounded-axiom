from __future__ import annotations

import json
from pathlib import Path

from gsrt.cli import main


def test_qd_run_cli_writes_report_and_bundle(tmp_path: Path) -> None:
    root = tmp_path / "runtime"
    out = tmp_path / "qd-report.json"
    bundle = tmp_path / "qd-bundle"

    rc = main([
        "qd-run",
        "--root", str(root),
        "--initial-count", "24",
        "--candidate-budget", "81",
        "--out", str(out),
        "--bundle", str(bundle),
    ])

    assert rc == 0
    report = json.loads(out.read_text(encoding="utf-8"))
    manifest = json.loads((bundle / "manifest.json").read_text(encoding="utf-8"))

    assert report["metadata"]["runtime_version"] == "0.8.1"
    assert report["metadata"]["evidence_level"] == "SYNTHETIC_VISUAL_QUALITY_DIVERSITY"
    assert report["metadata"]["real_world_qd_claim"] is False
    assert manifest["bundle_version"] == "0.8.1"
    assert manifest["experiment"] == "quality_diversity_archive"
    assert manifest["descriptor_id"] == report["metadata"]["descriptor_id"]
    assert manifest["descriptor_version"] == report["metadata"]["descriptor_version"]
    assert manifest["filled_niches"] == report["qd_archive"]["filled_niches"]
    assert manifest["coverage"] == report["qd_archive"]["coverage"]
    assert manifest["qd_score"] == report["qd_archive"]["qd_score"]
    assert (bundle / "CHECKSUMS.sha256").exists()
