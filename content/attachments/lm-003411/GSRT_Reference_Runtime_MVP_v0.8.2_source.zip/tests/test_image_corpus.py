from gsrt.image_corpus import generate_reference_image_corpus


def test_reference_image_corpus_is_deterministic_and_factor_diverse():
    first = generate_reference_image_corpus(96)
    second = generate_reference_image_corpus(96)

    assert first == second
    assert len(first) == 96
    assert all(item.png_bytes.startswith(b"\x89PNG") for item in first)

    for field in ("subject", "identity", "composition", "spatial", "camera", "lighting", "palette", "style"):
        assert len({getattr(item.semantics, field) for item in first}) == 3
