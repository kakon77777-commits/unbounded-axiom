from __future__ import annotations

from pathlib import Path

from gsrt.qd_experiment import QDExperimentConfig, QDExperimentRunner


def test_qd_experiment_improves_descriptor_goal_coverage(tmp_path: Path) -> None:
    report = QDExperimentRunner(tmp_path / "run").run(
        QDExperimentConfig(initial_count=24, candidate_budget=81)
    )

    assert report.initial_library_seed_count == 24
    assert report.validated_candidate_count == 24
    assert report.qd_archive["coverage"] > report.single_best["coverage"]
    assert report.qd_archive["filled_niches"] > 1
    assert report.qd_archive["goal_coverage"] > report.single_best["goal_coverage"]
    assert report.controls["duplicate_coverage_inflation"] == 0.0
    assert report.controls["seedstore_mutation_violations"] == 0.0


def test_qd_experiment_reaches_all_27_niches_with_full_reference_library(tmp_path: Path) -> None:
    report = QDExperimentRunner(tmp_path / "run").run(
        QDExperimentConfig(initial_count=96, candidate_budget=243)
    )

    assert report.qd_archive["filled_niches"] == 27.0
    assert report.qd_archive["coverage"] == 1.0
    assert report.qd_archive["goal_coverage"] == 1.0
    assert report.single_best["filled_niches"] == 1.0
    assert report.single_best["goal_coverage"] == 1 / 27
    assert report.qd_archive["qd_score"] == 27.0


def test_qd_experiment_report_is_reproducible_across_clean_roots(tmp_path: Path) -> None:
    config = QDExperimentConfig(initial_count=24, candidate_budget=81)

    first = QDExperimentRunner(tmp_path / "a").run(config)
    second = QDExperimentRunner(tmp_path / "b").run(config)

    assert first.to_dict() == second.to_dict()
    assert first.metadata["evidence_level"] == "SYNTHETIC_VISUAL_QUALITY_DIVERSITY"
    assert first.metadata["real_world_qd_claim"] is False
    assert first.metadata["candidate_source"] == "validated_reusable_seed_memory"
