from gsrt.evaluation import TextFidelityEvaluator
from gsrt.models import ReconstructionResult


SOURCE = (
    "Technically, redundant replicas may preserve service continuity under partial node loss; "
    "it does not necessarily imply higher safety."
)


def result(text):
    return ReconstructionResult(
        run_id="run:x",
        seed_id="seed:x",
        text=text,
        source_visible_to_decoder=False,
        error=None,
    )


def test_evaluator_is_sensitive_to_relation_and_negation_not_only_topic_words():
    evaluator = TextFidelityEvaluator()
    good = evaluator.evaluate(SOURCE, result(SOURCE))
    wrong = evaluator.evaluate(
        SOURCE,
        result(
            "Technically, redundant replicas may support service continuity under partial node loss; "
            "it does imply higher safety."
        ),
    )

    assert good.hard_pass is True
    assert good.scores["relation"] == 1.0
    assert good.scores["negation"] == 1.0
    assert wrong.hard_pass is False
    assert wrong.scores["relation"] == 0.0
    assert wrong.scores["negation"] == 0.0
    assert wrong.scores["concept"] == 1.0
