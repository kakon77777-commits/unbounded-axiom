# GSRT Reference Runtime MVP v0.8.2 — Validation Report

Date: 2026-09-01
Branch: `integration/v0.8.2-heterogeneous-mutation-fleet`
Recovery base: verified v0.8.1 source ZIP SHA-256 `9f975c00662e063b2c74698f2316cf952d7f6f94f762e81c38900311e84c3d1e`.
Scope: deterministic mutation priors, full mutation validation, matched homogeneous/heterogeneous fleet experiment, QD archive interaction, label-only and information-access controls, and release reproducibility.

## Recovery boundary

The original v0.8.2 formal experiment completed before a CaaS reset erased the unuploaded final source/Git workspace. This release reconstructs the frozen implementation from the verified v0.8.1 source plus the recorded v0.8.2 implementation/protocol evidence. The reconstructed runtime was required to reproduce a cheap first-trial fingerprint before the full formal run:

```text
trial 0, candidate budget 30, experiment_seed=gsrt-v0.8.2
homogeneous_balanced       coverage 18/27 = 0.6666666666666666
homogeneous_biased         coverage 13/27 = 0.48148148148148145
heterogeneous_complementary coverage 16/27 = 0.5925925925925926
label_only_control         coverage 18/27 = 0.6666666666666666
```

The recovered runtime then reproduced the complete formal aggregate and experiment ID exactly.

## Evidence boundary

```text
SYNTHETIC_MUTATION_PRIOR_FLEET
```

No independent model family or provider is used. The benchmark tests the effect of complementary deterministic mutation-prior distributions inside the synthetic visual seed/QD runtime.

## Frozen formal experiment

```text
trials                       32
candidate budget              30 / condition / trial
workers                        3 / condition
conditions                     4
total mutation attempts     3840
reference cost/candidate       5
reference cost/condition     150 / trial
experiment seed               gsrt-v0.8.2
```

Experiment ID:

```text
sha256:964285b6e5817d77b00d9ac3528f74d9b2e3442ca9546eb8da36879b53411048
```

Measured result:

```text
heterogeneous_complementary
  mean filled niches          17.28125
  mean coverage                0.6400462962962963
  mean novelty                 0.6785529740660183
  valid admission              1.0
  duplicate rate               0.45729166666666665
  archive acceptance           0.5427083333333333
  mean reference cost        150.0
  coverage/cost                0.004266975308641975

homogeneous_balanced
  mean filled niches          16.03125
  mean coverage                0.59375
  mean novelty                 0.6684364450908569
  valid admission              1.0
  duplicate rate               0.49895833333333334
  archive acceptance           0.5010416666666667
  mean reference cost        150.0
  coverage/cost                0.003958333333333334

homogeneous_biased
  mean filled niches          11.3125
  mean coverage                0.41898148148148145
  mean novelty                 0.6075601243799773
  valid admission              1.0
  duplicate rate               0.65625
  archive acceptance           0.34375
  mean reference cost        150.0
  coverage/cost                0.0027932098765432096
```

Primary paired comparison:

```text
heterogeneous - balanced mean coverage delta
  0.046296296296296294

95% normal-approx CI
  [0.013701260002548253, 0.07889133259004433]

wins / ties / losses
  21 / 4 / 7
```

Stress comparison:

```text
heterogeneous - homogeneous_biased coverage delta
  0.22106481481481483
```

## Controls

```text
label_only_exact_match          1.0
matched_candidate_budget        1.0
matched_reference_cost          1.0
matched_valid_admission_rate    1.0
oracle_enumeration_coverage     1.0
```

The label-only condition uses different worker names with the exact same balanced priors and reproduces the homogeneous-balanced aggregate exactly. This prevents worker naming from being mistaken for heterogeneity.

The oracle directly enumerates the 27 descriptor niches and has different information access; it is not a matched fleet condition.

## Runtime validation chain

Every candidate is required to pass:

```text
one-factor mutation contract
-> render finished PNG
-> retrospective compact extraction
-> blind reconstruction
-> image fidelity evaluation
-> dependency audit
-> validation certificate
-> reusable SeedStore identity/dedup
-> mutated_from lineage
-> QD archive consideration
```

Existing identical states retain their reusable seed identity/provenance. A duplicate proposal records lineage but does not overwrite the prior reusable record.

## Release acceptance summary

| Gate | Result | Evidence |
|---|---|---|
| V82-R1 Verified v0.8.1 recovery base | PASS | source ZIP SHA matches release manifest |
| V82-R2 Frozen first-trial fingerprint | PASS | 18/27, 13/27, 16/27, 18/27 exact |
| V82-R3 Deterministic prior core | PASS | worker labels excluded from RNG; one QD factor per mutation |
| V82-R4 Full candidate validation | PASS | render/extract/reconstruct/evaluate/certificate/reusable pipeline |
| V82-R5 Identity/dedup | PASS | duplicate state reuses identity and preserves metadata |
| V82-R6 Matched candidate budget | PASS | 30 candidates/condition/trial |
| V82-R7 Matched reference cost | PASS | 150/condition/trial |
| V82-R8 Matched valid-admission rate | PASS | 1.0 all conditions |
| V82-R9 Label-only control | PASS | exact aggregate equality with homogeneous-balanced |
| V82-R10 Primary balanced comparison | PASS | +0.0462963 coverage; CI above zero in reference run |
| V82-R11 Stress biased comparison | PASS | +0.2210648 coverage |
| V82-R12 Oracle information boundary | PASS | coverage=1.0; explicitly not matched competitor |
| V82-R13 Synthetic evidence boundary | PASS | no cross-provider/model claim |
| V82-R14 QD atomic persistence | PASS | admission + novelty refresh in one DB batch |
| V82-R15 CLI / bundle | PASS | `gsrt fleet-run`, bundle v0.8.2 |
| V82-R16 Full regression / build | PASS | 156/156; compileall; wheel; fresh no-index install; source/installed fleet smoke exact |
| V82-R17 Candidate-commit reproducibility | PASS | `c8c1fd7c955b71f08f68598f287dd25da9d31445`; 156/156; formal report EXACT; checksums; wheel 49/49; installed smoke EXACT; git clean |
| V82-R18 Final-commit read-only gate | PENDING | final delivery gate |


## Packaging gate

Fresh pre-candidate packaging evidence:

```text
pytest                         156/156 PASS
compileall                     PASS
git diff --check               PASS
wheel                          gsrt_reference_runtime-0.8.2-py3-none-any.whl
fresh --no-index --no-deps     PASS
source vs installed fleet-run  EXACT MATCH
package metadata version       0.8.2
module version                 0.8.2
```

The environment uses the declared `setuptools.build_meta` backend through `pip wheel --no-deps --no-build-isolation`; this is a build-frontend choice, not a backend change.

## Code-review boundary

No dispatchable independent code-review subagent is available in this runtime. Review therefore uses TDD, diff inspection, `git diff --check`, full regression, frozen formal-result reproduction, checksums, wheel member-content comparison, and clean installed CLI reproduction. This is not labeled independent external code review.

## Next falsifiable stage

v0.9 should add an optional canonical/ISQL adapter only after keeping scientific GSRT evidence and protocol-conformance evidence separate.

## Release-candidate closure gate

Commit `c8c1fd7c955b71f08f68598f287dd25da9d31445` was reverified after documentation/package freeze:

```text
pytest                         156/156 PASS
full 32-trial fleet report     EXACT MATCH
release evidence checksums     11/11 PASS
root checksums                 356/356 PASS
wheel rebuild member contents  49/49 equivalent
fresh no-index install         PASS
installed fleet-run smoke      EXACT MATCH
git working tree               CLEAN
```

The rebuilt wheel archive SHA may differ because ZIP timestamps are not treated as a reproducible-build guarantee; all extracted member contents are byte-equivalent. The final release commit receives one additional read-only verification gate before external delivery.
