from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class TextSemantics:
    subject: str
    epistemic: str
    relation: str
    object: str
    condition: str
    negated_implication: bool
    consequence: str
    style: str


_PATTERN = re.compile(
    r"^(?:(?P<prefix>Technically|In practice|Briefly), )?"
    r"(?P<subject>.+?) "
    r"(?P<epistemic>may|likely|must) "
    r"(?P<relation>preserve|support|constrain|enable|reduce|increase) "
    r"(?P<object>.+?) under "
    r"(?P<condition>.+?); it "
    r"(?P<neg>does not necessarily|does) imply "
    r"(?P<consequence>.+?)\.\s*$"
)

_STYLE = {
    "Technically": "technical",
    "In practice": "practical",
    "Briefly": "concise",
    None: "neutral",
}


def parse_fixture_text(text: str) -> TextSemantics:
    match = _PATTERN.match(text.strip())
    if not match:
        raise ValueError("text does not match GSRT reference fixture grammar")
    return TextSemantics(
        subject=match.group("subject"),
        epistemic=match.group("epistemic"),
        relation=match.group("relation"),
        object=match.group("object"),
        condition=match.group("condition"),
        negated_implication=match.group("neg") == "does not necessarily",
        consequence=match.group("consequence"),
        style=_STYLE[match.group("prefix")],
    )


def render_fixture_text(s: TextSemantics) -> str:
    prefix = {
        "technical": "Technically, ",
        "practical": "In practice, ",
        "concise": "Briefly, ",
        "neutral": "",
    }.get(s.style, "")
    neg = "does not necessarily" if s.negated_implication else "does"
    return (
        f"{prefix}{s.subject} {s.epistemic} {s.relation} {s.object} under {s.condition}; "
        f"it {neg} imply {s.consequence}."
    )
