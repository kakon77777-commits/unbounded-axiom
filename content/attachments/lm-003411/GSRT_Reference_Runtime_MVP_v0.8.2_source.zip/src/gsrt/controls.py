from __future__ import annotations

import hashlib
import json

from .models import SeedCandidate


def _control_seed(base: SeedCandidate, name: str, payload: str) -> SeedCandidate:
    material = f"{base.seed_id}:{name}:{payload}".encode("utf-8")
    seed_id = "sha256:" + hashlib.sha256(material).hexdigest()
    return SeedCandidate(
        seed_id=seed_id,
        artifact_id=base.artifact_id,
        family=base.family,
        payload=payload,
        payload_bytes=len(payload.encode("utf-8")),
        budget_bytes=base.budget_bytes,
        dependencies=base.dependencies,
        metadata={**base.metadata, "control": name},
    )


def make_controls(seed: SeedCandidate, unrelated_seed: SeedCandidate) -> dict[str, SeedCandidate]:
    if seed.family != "structured" or unrelated_seed.family != "structured":
        raise ValueError("reference negative controls require structured seeds")
    obj = json.loads(seed.payload)

    shuffled = dict(obj)
    shuffled["r"] = "support" if obj.get("r") != "support" else "preserve"

    contradiction = dict(obj)
    contradiction["n"] = not bool(obj.get("n"))

    random_payload = json.dumps(
        {"opaque": hashlib.sha256(seed.seed_id.encode("utf-8")).hexdigest()[:24]},
        sort_keys=True,
        separators=(",", ":"),
    )

    unrelated_obj = json.loads(unrelated_seed.payload)
    # A negative-control object must be outside the source proposition neighborhood,
    # even when the caller's adjacent corpus item differs only in style.
    if unrelated_obj.get("s") == obj.get("s"):
        unrelated_obj["s"] = "unrelated control subject"
    if unrelated_obj.get("r") == obj.get("r"):
        unrelated_obj["r"] = "support" if obj.get("r") != "support" else "preserve"
    if unrelated_obj.get("c") == obj.get("c"):
        unrelated_obj["c"] = "unrelated control condition"
    if unrelated_obj.get("e") == obj.get("e"):
        unrelated_obj["e"] = "must" if obj.get("e") != "must" else "may"

    return {
        "random": _control_seed(seed, "random", random_payload),
        "relation_shuffle": _control_seed(
            seed,
            "relation_shuffle",
            json.dumps(shuffled, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        ),
        "contradiction": _control_seed(
            seed,
            "contradiction",
            json.dumps(contradiction, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        ),
        "unrelated": _control_seed(
            seed,
            "unrelated",
            json.dumps(unrelated_obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        ),
    }
