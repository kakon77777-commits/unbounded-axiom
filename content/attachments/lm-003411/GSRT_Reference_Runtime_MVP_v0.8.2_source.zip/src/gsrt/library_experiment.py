from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from itertools import product
from pathlib import Path
from typing import Any

from .certificates import CertificateIssuer
from .dependencies import DependencyAuditor, DependencyPolicy
from .image_evaluation import ImageFidelityEvaluator
from .image_extraction import ReferenceImageSeedExtractor, decode_visual_compact
from .image_reconstruction import ReferenceImageReconstructor
from .image_semantics import (
    CAMERAS,
    COMPOSITIONS,
    IDENTITIES,
    LIGHTINGS,
    PALETTES,
    SPATIALS,
    STYLES,
    SUBJECTS,
    ImageSemantics,
    analyze_reference_image,
    render_reference_image,
)
from .library import SeedLibrary
from .models import DependencyRef, LibraryExperimentReport, SeedCandidate
from .retrieval import LibraryQuery, SeedRetriever


_FACTOR_NAMES = (
    "subject",
    "identity",
    "composition",
    "spatial",
    "camera",
    "lighting",
    "palette",
    "style",
)
_FACTOR_DOMAINS = (
    SUBJECTS,
    IDENTITIES,
    COMPOSITIONS,
    SPATIALS,
    CAMERAS,
    LIGHTINGS,
    PALETTES,
    STYLES,
)
_SPECIFICITIES: dict[str, tuple[str, ...]] = {
    "k2": ("spatial", "lighting"),
    "k3": ("identity", "lighting", "style"),
    "k4": ("identity", "camera", "lighting", "palette"),
}
_SPACE_SIZE = math.prod(len(values) for values in _FACTOR_DOMAINS)


@dataclass(frozen=True)
class LibraryExperimentConfig:
    count: int = 96
    tasks_per_specificity: int = 32
    max_fresh_attempts: int = 512
    repetitions: int = 1
    min_success_probability: float = 1.0


def _experiment_id(config: LibraryExperimentConfig) -> str:
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _seed_candidate_from_record(record: dict[str, Any]) -> SeedCandidate:
    payload = str(record["payload"])
    return SeedCandidate(
        seed_id=str(record["seed_id"]),
        artifact_id=str(record["artifact_id"]),
        family=str(record["family"]),
        payload=payload,
        payload_bytes=len(payload.encode("utf-8")),
        budget_bytes=len(payload.encode("utf-8")),
        dependencies=(
            DependencyRef("SHARED_BASELINE", "reference-visual-grammar:v0.4", 0),
            DependencyRef("SHARED_BASELINE", "reference-visual-codebook:v0.4", 0),
        ),
        metadata={"source": "validated-seed-library:v0.6"},
    )


def _goal_pass(semantics: ImageSemantics, required: dict[str, str]) -> bool:
    return all(getattr(semantics, name) == value for name, value in required.items())


def _state_from_index(index: int) -> ImageSemantics:
    if not 0 <= index < _SPACE_SIZE:
        raise ValueError(index)
    values: list[str] = []
    remaining = index
    # The rightmost factor changes fastest, matching itertools.product order.
    digits = [0] * len(_FACTOR_DOMAINS)
    for i in range(len(_FACTOR_DOMAINS) - 1, -1, -1):
        base = len(_FACTOR_DOMAINS[i])
        digits[i] = remaining % base
        remaining //= base
    for digit, domain in zip(digits, _FACTOR_DOMAINS, strict=True):
        values.append(domain[digit])
    return ImageSemantics(*values)


def _fresh_sequence(query_id: str):
    digest = hashlib.sha256(query_id.encode("utf-8")).digest()
    start = int.from_bytes(digest[:8], "big") % _SPACE_SIZE
    step = int.from_bytes(digest[8:16], "big") % (_SPACE_SIZE - 1) + 1
    while math.gcd(step, _SPACE_SIZE) != 1:
        step = step % (_SPACE_SIZE - 1) + 1
    for offset in range(_SPACE_SIZE):
        yield (start + offset * step) % _SPACE_SIZE


class LibraryExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.library = SeedLibrary(self.root)
        self.extractor = ReferenceImageSeedExtractor(self.library.artifacts.read_bytes)
        self.reconstructor = ReferenceImageReconstructor(self.library.outputs)
        self.evaluator = ImageFidelityEvaluator(self.library.outputs.read_bytes)
        self.auditor = DependencyAuditor()
        self.issuer = CertificateIssuer(1.0)

    @staticmethod
    def _edge_id(source: str, target: str, operation: str) -> str:
        return "sha256:" + hashlib.sha256(f"{source}:{target}:{operation}".encode("utf-8")).hexdigest()

    def _build_library(self, count: int) -> list[dict[str, Any]]:
        from .image_corpus import generate_reference_image_corpus

        records: list[dict[str, Any]] = []
        for item in generate_reference_image_corpus(count):
            artifact = self.library.artifacts.ingest_bytes(item.png_bytes, "image", item.metadata)
            self.library.db.record_artifact(artifact)
            observed = analyze_reference_image(item.png_bytes)
            seed = self.extractor.extract(artifact, "visual_compact", 8)
            audit = self.auditor.audit(seed, DependencyPolicy.strict())
            result = self.reconstructor.reconstruct(seed, 0)
            evaluation = self.evaluator.evaluate(observed, item.png_bytes, result)
            certificate = self.issuer.issue(seed, audit, [evaluation], self.reconstructor.generator_id)
            with self.library.db.batch():
                self.library.db.record_seed_candidate(seed)
                self.library.db.record_reconstruction_run(result)
                self.library.db.record_evaluation(evaluation)
                self.library.db.record_certificate(certificate)
                self.library.db.record_lineage_edge(
                    self._edge_id(artifact.artifact_id, seed.seed_id, "extracted_from"),
                    artifact.artifact_id,
                    seed.seed_id,
                    "extracted_from",
                    {"experiment": "seed-library:v0.6", "family": seed.family},
                )
            records.append(self.library.promote_image_seed(artifact, seed, certificate))
        return records

    def _library_goal_result(
        self,
        selected_record: dict[str, Any] | None,
        required: dict[str, str],
    ) -> tuple[bool, int, int]:
        if selected_record is None:
            return False, 0, 0
        seed = _seed_candidate_from_record(selected_record)
        result = self.reconstructor.reconstruct(seed, 0)
        if result.output_artifact_id is None:
            return False, 1, 1
        observed = analyze_reference_image(self.library.outputs.read_bytes(result.output_artifact_id))
        return _goal_pass(observed, required), 1, 1

    @staticmethod
    def _fresh_goal_result(
        query_id: str,
        required: dict[str, str],
        max_attempts: int,
    ) -> tuple[bool, int, int]:
        attempts = 0
        for state_index in _fresh_sequence(query_id):
            if attempts >= max_attempts:
                break
            attempts += 1
            png = render_reference_image(_state_from_index(state_index))
            observed = analyze_reference_image(png)
            if _goal_pass(observed, required):
                return True, attempts, attempts
        return False, attempts, attempts

    def _random_library_result(
        self,
        records: list[dict[str, Any]],
        query_id: str,
        source_seed_id: str,
        required: dict[str, str],
    ) -> bool:
        candidates = [record for record in records if record["seed_id"] != source_seed_id]
        digest = hashlib.sha256((query_id + ":random-library").encode("utf-8")).digest()
        selected = candidates[int.from_bytes(digest[:8], "big") % len(candidates)]
        semantics = decode_visual_compact(str(selected["payload"]))
        png = render_reference_image(semantics)
        return _goal_pass(analyze_reference_image(png), required)

    def _controls(self, records: list[dict[str, Any]]) -> dict[str, float]:
        from .db import RuntimeDB
        from .retrieval import SeedRetriever

        first = records[0]
        factors = self.library.db.get_seed_factors(first["seed_id"])

        empty_db = RuntimeDB(self.root / "controls-empty.sqlite3")
        empty = SeedRetriever(empty_db).retrieve(LibraryQuery(required_factors={"identity": factors["identity"]}))
        empty_pass = float(empty.selected_seed_id is None)

        stale_db = RuntimeDB(self.root / "controls-stale.sqlite3")
        stale_record = dict(first)
        stale_record["status"] = "STALE"
        stale_db.record_validated_seed(stale_record)
        for name, value in factors.items():
            stale_db.record_seed_factor(first["seed_id"], name, value)
        stale = SeedRetriever(stale_db).retrieve(LibraryQuery(required_factors=factors))
        stale_pass = float(stale.selected_seed_id is None)

        wrong = next(
            record
            for record in records[1:]
            if self.library.db.get_seed_factors(record["seed_id"])["identity"] != factors["identity"]
        )
        wrong_semantics = decode_visual_compact(str(wrong["payload"]))
        wrong_pass = float(not _goal_pass(wrong_semantics, {"identity": factors["identity"]}))

        return {
            "empty_library_pass": empty_pass,
            "stale_filter_pass": stale_pass,
            "wrong_factor_rejected": wrong_pass,
            "random_library_pass_rate": 0.0,  # filled from actual benchmark tasks
        }

    def run(self, config: LibraryExperimentConfig) -> LibraryExperimentReport:
        if config.count < 2:
            raise ValueError("count must be at least two")
        if config.tasks_per_specificity < 1:
            raise ValueError("tasks_per_specificity must be positive")
        if config.max_fresh_attempts < 1:
            raise ValueError("max_fresh_attempts must be positive")
        if config.repetitions != 1:
            raise ValueError("v0.6 reference reuse benchmark currently requires repetitions=1")

        records = self._build_library(config.count)
        retriever = SeedRetriever(self.library.db)
        tasks: list[dict[str, Any]] = []
        source_reuse_violations = 0
        random_passes = 0

        for specificity, factor_names in _SPECIFICITIES.items():
            eligible: list[tuple[dict[str, Any], dict[str, str], dict[str, str], Any]] = []
            for source in sorted(records, key=lambda item: item["seed_id"]):
                factors = self.library.db.get_seed_factors(source["seed_id"])
                required = {name: factors[name] for name in factor_names}
                optional = {name: factors[name] for name in _FACTOR_NAMES if name not in factor_names}
                portfolio = retriever.retrieve(
                    LibraryQuery(
                        required_factors=required,
                        optional_factors=optional,
                        exclude_seed_ids=(source["seed_id"],),
                        max_candidates=5,
                    )
                )
                if portfolio.selected_seed_id is not None:
                    eligible.append((source, required, optional, portfolio))
            if len(eligible) < config.tasks_per_specificity:
                raise ValueError(
                    f"insufficient alternate library coverage for {specificity}: "
                    f"{len(eligible)} < {config.tasks_per_specificity}"
                )

            for source, required, optional, portfolio in eligible[: config.tasks_per_specificity]:
                task_id = "sha256:" + hashlib.sha256(
                    json.dumps(
                        {
                            "specificity": specificity,
                            "source_seed": source["seed_id"],
                            "required": required,
                        },
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                ).hexdigest()
                selected_record = (
                    self.library.db.get_validated_seed(portfolio.selected_seed_id)
                    if portfolio.selected_seed_id
                    else None
                )
                source_reuse_violations += int(portfolio.selected_seed_id == source["seed_id"])
                library_success, library_generations, library_evals = self._library_goal_result(
                    selected_record, required
                )
                fresh_success, fresh_generations, fresh_evals = self._fresh_goal_result(
                    task_id, required, config.max_fresh_attempts
                )
                random_success = self._random_library_result(records, task_id, source["seed_id"], required)
                random_passes += int(random_success)

                library_retrieval_calls = 1
                fresh_retrieval_calls = 0
                library_cost = library_generations + library_evals + library_retrieval_calls
                fresh_cost = fresh_generations + fresh_evals + fresh_retrieval_calls
                reuse_benefit = float(fresh_cost - library_cost)
                relative_gain = 1.0 - (library_cost / fresh_cost) if fresh_cost else 0.0
                if not library_success:
                    self.library.record_failure(
                        query_id=portfolio.query_id,
                        failure_class="LIBRARY_REUSE_FAILED",
                        seed_id=portfolio.selected_seed_id,
                        metadata={"required": required},
                    )
                if not fresh_success:
                    self.library.record_failure(
                        query_id=portfolio.query_id,
                        failure_class="FRESH_SEARCH_CAP",
                        seed_id=None,
                        metadata={"required": required, "max_attempts": config.max_fresh_attempts},
                    )
                if portfolio.selected_seed_id is not None:
                    self.library.db.record_library_event(
                        {
                            "event_id": self.library._hash_event(
                                "REUSED_FOR", portfolio.selected_seed_id, task_id
                            ),
                            "subject_id": portfolio.selected_seed_id,
                            "event_type": "REUSED_FOR",
                            "metadata": {"task_id": task_id, "specificity": specificity},
                        }
                    )
                    self.library.db.record_lineage_edge(
                        self._edge_id(portfolio.selected_seed_id, task_id, "reused_for"),
                        portfolio.selected_seed_id,
                        task_id,
                        "reused_for",
                        {"query_id": portfolio.query_id, "specificity": specificity},
                    )
                tasks.append(
                    {
                        "task_id": task_id,
                        "specificity": specificity,
                        "required_factors": required,
                        "source_seed_id": source["seed_id"],
                        "selected_seed_id": portfolio.selected_seed_id,
                        "portfolio_candidate_count": len(portfolio.candidates),
                        "library_success": library_success,
                        "fresh_success": fresh_success,
                        "random_library_success": random_success,
                        "library_generation_count": library_generations,
                        "library_evaluator_calls": library_evals,
                        "library_retrieval_calls": library_retrieval_calls,
                        "fresh_generation_count": fresh_generations,
                        "fresh_evaluator_calls": fresh_evals,
                        "fresh_retrieval_calls": fresh_retrieval_calls,
                        "library_reference_cost": float(library_cost),
                        "fresh_reference_cost": float(fresh_cost),
                        "reuse_benefit": reuse_benefit,
                        "relative_reuse_gain": relative_gain,
                    }
                )

        def summarize(rows: list[dict[str, Any]]) -> dict[str, float]:
            n = len(rows)
            return {
                "task_count": float(n),
                "library_success_rate": sum(row["library_success"] for row in rows) / n,
                "fresh_success_rate": sum(row["fresh_success"] for row in rows) / n,
                "random_library_success_rate": sum(row["random_library_success"] for row in rows) / n,
                "mean_library_generation_count": sum(row["library_generation_count"] for row in rows) / n,
                "mean_library_evaluator_calls": sum(row["library_evaluator_calls"] for row in rows) / n,
                "mean_library_retrieval_calls": sum(row["library_retrieval_calls"] for row in rows) / n,
                "mean_fresh_generation_count": sum(row["fresh_generation_count"] for row in rows) / n,
                "mean_fresh_evaluator_calls": sum(row["fresh_evaluator_calls"] for row in rows) / n,
                "mean_fresh_reference_cost": sum(row["fresh_reference_cost"] for row in rows) / n,
                "mean_library_reference_cost": sum(row["library_reference_cost"] for row in rows) / n,
                "mean_reuse_benefit": sum(row["reuse_benefit"] for row in rows) / n,
                "relative_reuse_gain": 1.0
                - (sum(row["library_reference_cost"] for row in rows) / sum(row["fresh_reference_cost"] for row in rows)),
            }

        by_specificity = {
            specificity: summarize([row for row in tasks if row["specificity"] == specificity])
            for specificity in _SPECIFICITIES
        }
        overall = summarize(tasks)
        controls = self._controls(records)
        controls["random_library_pass_rate"] = random_passes / len(tasks)

        return LibraryExperimentReport(
            experiment_id=_experiment_id(config),
            artifact_count=config.count,
            library_seed_count=len(self.library.records()),
            task_count=len(tasks),
            library_snapshot=self.library.snapshot_digest(),
            by_specificity=by_specificity,
            overall=overall,
            controls=controls,
            source_seed_reuse_violations=source_reuse_violations,
            library_reuse_failure_count=sum(not row["library_success"] for row in tasks),
            fresh_search_failure_count=sum(not row["fresh_success"] for row in tasks),
            recorded_failure_count=self.library.db.count("library_failures"),
            task_records=tasks,
            metadata={
                "runtime_version": "0.6.0",
                "evidence_level": "SYNTHETIC_VISUAL_GENERATIVE_MEMORY",
                "real_world_reuse_claim": False,
                "source_seed_excluded_from_retrieval": True,
                "goal_factors": {key: list(value) for key, value in _SPECIFICITIES.items()},
                "fresh_search_space_size": _SPACE_SIZE,
                "fresh_search_policy": "deterministic full-space permutation without memory",
                "library_retrieval_policy": "required-factor intersection + optional-factor rerank",
                "cost_model": {
                    "generation": 1.0,
                    "evaluation": 1.0,
                    "retrieval_call": 1.0,
                    "claim": "reference operation count; not a universal economic scalar",
                },
                "lineage_edge_count": self.library.db.count("lineage_edges"),
            },
        )
