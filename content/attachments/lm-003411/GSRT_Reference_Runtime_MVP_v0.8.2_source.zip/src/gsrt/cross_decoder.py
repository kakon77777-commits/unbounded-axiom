from __future__ import annotations

import hashlib
import itertools
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .certificates import CertificateIssuer
from .controls import make_controls
from .corpus import generate_reference_corpus
from .db import RuntimeDB
from .decoders import reference_decoder_registry
from .dependencies import DependencyAuditor, DependencyPolicy
from .evaluation import TextFidelityEvaluator
from .extraction import ReferenceSeedExtractor
from .models import CrossDecoderReport, SeedCandidate
from .store import ArtifactStore
from .text_semantics import parse_fixture_text


DEFAULT_DECODERS = (
    "reference_exact:v0.3",
    "relational_interlingua:v0.3",
    "compact_core:v0.3",
)
DEFAULT_FAMILIES = ("summary", "keyword", "freeform", "structured", "compact")
HOME_DECODERS = {
    "structured": "reference_exact:v0.3",
    "freeform": "relational_interlingua:v0.3",
    "compact": "compact_core:v0.3",
}


@dataclass(frozen=True)
class CrossDecoderConfig:
    count: int = 120
    repetitions: int = 2
    families: tuple[str, ...] = DEFAULT_FAMILIES
    decoders: tuple[str, ...] = DEFAULT_DECODERS
    budget_bytes: int = 512
    family_budget_overrides: dict[str, int] = field(default_factory=lambda: {"compact": 7})
    min_success_probability: float = 1.0
    include_controls: bool = True


_SCORE_NAMES = (
    "concept",
    "relation",
    "negation",
    "qualifier",
    "epistemic",
    "order",
    "style",
    "functional",
    "overall",
)


def _experiment_id(config: CrossDecoderConfig) -> str:
    material = repr(
        (
            config.count,
            config.repetitions,
            config.families,
            config.decoders,
            config.budget_bytes,
            tuple(sorted(config.family_budget_overrides.items())),
            config.min_success_probability,
            config.include_controls,
        )
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


def _semantic_consensus(text_a: str, text_b: str) -> float:
    try:
        a = parse_fixture_text(text_a)
        b = parse_fixture_text(text_b)
    except Exception:
        return 0.0
    pairs = (
        (a.subject, b.subject),
        (a.epistemic, b.epistemic),
        (a.relation, b.relation),
        (a.object, b.object),
        (a.condition, b.condition),
        (a.negated_implication, b.negated_implication),
        (a.consequence, b.consequence),
        (a.style, b.style),
    )
    return sum(left == right for left, right in pairs) / len(pairs)


class CrossDecoderRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = ArtifactStore(self.root / "artifacts")
        self.db = RuntimeDB(self.root / "runtime.sqlite3")
        self.extractor = ReferenceSeedExtractor(self.artifacts.read_text)
        self.evaluator = TextFidelityEvaluator()
        self.auditor = DependencyAuditor()

    def _edge_id(self, source: str, target: str, operation: str) -> str:
        raw = f"{source}:{target}:{operation}".encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def run(self, config: CrossDecoderConfig) -> CrossDecoderReport:
        if config.count < 1:
            raise ValueError("count must be positive")
        if config.repetitions < 1:
            raise ValueError("repetitions must be positive")
        if config.budget_bytes < 1:
            raise ValueError("budget_bytes must be positive")
        if config.include_controls and config.count < 2:
            raise ValueError("negative controls require at least two artifacts")

        registry = reference_decoder_registry()
        unknown = [decoder_id for decoder_id in config.decoders if decoder_id not in registry]
        if unknown:
            raise ValueError(f"unknown decoder: {unknown[0]}")
        for family in config.families:
            if family not in ReferenceSeedExtractor.FAMILIES:
                raise ValueError(f"unknown seed family: {family}")
        for family, budget in config.family_budget_overrides.items():
            if family not in config.families:
                continue
            if budget < 1:
                raise ValueError(f"family budget must be positive: {family}")

        decoders = {decoder_id: registry[decoder_id] for decoder_id in config.decoders}
        corpus = generate_reference_corpus(config.count)
        records = []
        for item in corpus:
            record = self.artifacts.ingest_text(item.text, item.metadata)
            self.db.record_artifact(record)
            records.append(record)

        family_budgets = {
            family: int(config.family_budget_overrides.get(family, config.budget_bytes))
            for family in config.families
        }
        seeds_by_artifact: dict[str, dict[str, SeedCandidate]] = {}
        for record in records:
            by_family = {}
            with self.db.batch():
                for family in config.families:
                    seed = self.extractor.extract(record, family, family_budgets[family])
                    self.db.record_seed_candidate(seed)
                    self.db.record_lineage_edge(
                        self._edge_id(record.artifact_id, seed.seed_id, "extracted_from"),
                        record.artifact_id,
                        seed.seed_id,
                        "extracted_from",
                        {"family": family, "experiment": "cross-decoder:v0.3"},
                    )
                    by_family[family] = seed
            seeds_by_artifact[record.artifact_id] = by_family

        totals: dict[str, dict[str, dict[str, Any]]] = {
            family: {
                decoder_id: {
                    "total": 0,
                    "passed": 0,
                    "hard_passed": 0,
                    "errors": 0,
                    "score_sums": {name: 0.0 for name in _SCORE_NAMES},
                }
                for decoder_id in config.decoders
            }
            for family in config.families
        }
        first_outputs: dict[tuple[str, str], dict[str, str]] = {}
        visibility_violations = 0
        certificate_passed = 0
        certificate_total = 0
        issuer = CertificateIssuer(config.min_success_probability)

        for record in records:
            source_text = self.artifacts.read_text(record.artifact_id)
            with self.db.batch():
                for family in config.families:
                    seed = seeds_by_artifact[record.artifact_id][family]
                    audit = self.auditor.audit(seed, DependencyPolicy.strict())
                    first_outputs[(record.artifact_id, family)] = {}
                    for decoder_id, decoder in decoders.items():
                        evaluations = []
                        for run_index in range(config.repetitions):
                            result = decoder.decode(seed, run_index)
                            self.db.record_reconstruction_run(result)
                            evaluation = self.evaluator.evaluate(source_text, result)
                            self.db.record_evaluation(evaluation)
                            evaluations.append(evaluation)
                            cell = totals[family][decoder_id]
                            cell["total"] += 1
                            cell["passed"] += int(evaluation.passed)
                            cell["hard_passed"] += int(evaluation.hard_pass)
                            cell["errors"] += int(result.error is not None)
                            for score_name in _SCORE_NAMES:
                                cell["score_sums"][score_name] += evaluation.scores[score_name]
                            visibility_violations += int(result.source_visible_to_decoder)
                            if run_index == 0:
                                first_outputs[(record.artifact_id, family)][decoder_id] = result.text
                        certificate = issuer.issue(seed, audit, evaluations, decoder_id)
                        self.db.record_certificate(certificate)
                        certificate_total += 1
                        certificate_passed += int(certificate.passed)

        matrix: dict[str, dict[str, dict[str, Any]]] = {}
        for family in config.families:
            matrix[family] = {}
            for decoder_id in config.decoders:
                cell = totals[family][decoder_id]
                total = int(cell["total"])
                matrix[family][decoder_id] = {
                    "total": total,
                    "passed": int(cell["passed"]),
                    "pass_rate": cell["passed"] / total if total else 0.0,
                    "hard_pass_rate": cell["hard_passed"] / total if total else 0.0,
                    "error_rate": cell["errors"] / total if total else 0.0,
                    "mean_fidelity": {
                        name: cell["score_sums"][name] / total if total else 0.0
                        for name in _SCORE_NAMES
                    },
                    "budget_bytes": family_budgets[family],
                }

        family_consensus: dict[str, dict[str, float]] = {}
        decoder_pairs = tuple(itertools.combinations(config.decoders, 2))
        for family in config.families:
            values = []
            for record in records:
                outputs = first_outputs[(record.artifact_id, family)]
                for left, right in decoder_pairs:
                    values.append(_semantic_consensus(outputs.get(left, ""), outputs.get(right, "")))
            family_consensus[family] = {
                "pair_count": float(len(values)),
                "mean_pairwise_consensus": sum(values) / len(values) if values else 0.0,
            }

        active_channels = {
            family: decoder_id
            for family, decoder_id in HOME_DECODERS.items()
            if family in config.families and decoder_id in config.decoders
        }
        diagonal_values = [matrix[family][home]["pass_rate"] for family, home in active_channels.items()]
        off_diagonal_values = [
            matrix[family][decoder_id]["pass_rate"]
            for family, home in active_channels.items()
            for decoder_id in config.decoders
            if decoder_id != home
        ]
        diagonal_pass_rate = sum(diagonal_values) / len(diagonal_values) if diagonal_values else 0.0
        off_diagonal_pass_rate = (
            sum(off_diagonal_values) / len(off_diagonal_values) if off_diagonal_values else 0.0
        )

        control_stats: dict[str, dict[str, float]] = {
            name: {
                "total": 0.0,
                "passed": 0.0,
                "pass_rate": 0.0,
                "pair_count": 0.0,
                "mean_pairwise_consensus": 0.0,
            }
            for name in ("random", "relation_shuffle", "contradiction", "unrelated")
        }
        control_consensus_sums = {name: 0.0 for name in control_stats}
        if config.include_controls and "structured" in config.families:
            for index, record in enumerate(records):
                other = records[(index + 1) % len(records)]
                seed = seeds_by_artifact[record.artifact_id]["structured"]
                unrelated = seeds_by_artifact[other.artifact_id]["structured"]
                controls = make_controls(seed, unrelated)
                source_text = self.artifacts.read_text(record.artifact_id)
                with self.db.batch():
                    for name, control_seed in controls.items():
                        self.db.record_seed_candidate(control_seed)
                        first_control_outputs: dict[str, str] = {}
                        for decoder_id, decoder in decoders.items():
                            for run_index in range(config.repetitions):
                                result = decoder.decode(control_seed, run_index)
                                self.db.record_reconstruction_run(result)
                                evaluation = self.evaluator.evaluate(source_text, result)
                                self.db.record_evaluation(evaluation)
                                control_stats[name]["total"] += 1.0
                                control_stats[name]["passed"] += float(evaluation.passed)
                                visibility_violations += int(result.source_visible_to_decoder)
                                if run_index == 0:
                                    first_control_outputs[decoder_id] = result.text
                        for left, right in decoder_pairs:
                            control_consensus_sums[name] += _semantic_consensus(
                                first_control_outputs.get(left, ""),
                                first_control_outputs.get(right, ""),
                            )
                            control_stats[name]["pair_count"] += 1.0
            for name, stats in control_stats.items():
                stats["pass_rate"] = stats["passed"] / stats["total"] if stats["total"] else 0.0
                stats["mean_pairwise_consensus"] = (
                    control_consensus_sums[name] / stats["pair_count"]
                    if stats["pair_count"]
                    else 0.0
                )

        return CrossDecoderReport(
            experiment_id=_experiment_id(config),
            artifact_count=len(records),
            families=tuple(config.families),
            decoders=tuple(config.decoders),
            family_budgets=family_budgets,
            matrix=matrix,
            family_consensus=family_consensus,
            channel_home_decoders=active_channels,
            diagonal_pass_rate=diagonal_pass_rate,
            off_diagonal_pass_rate=off_diagonal_pass_rate,
            interoperability_gap=diagonal_pass_rate - off_diagonal_pass_rate,
            control_stats=control_stats,
            source_visibility_violations=visibility_violations,
            certificate_passed=certificate_passed,
            certificate_total=certificate_total,
            metadata={
                "runtime_version": "0.3.0",
                "evidence_level": "INTERNAL_REFERENCE_VARIANTS",
                "independent_cross_model_claim": False,
                "decoder_count": len(config.decoders),
                "repetitions": config.repetitions,
                "consensus_note": "pairwise decoder agreement is reported separately from target fidelity",
            },
        )
