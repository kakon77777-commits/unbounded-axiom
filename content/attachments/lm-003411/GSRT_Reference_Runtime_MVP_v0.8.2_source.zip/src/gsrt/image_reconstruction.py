from __future__ import annotations

import hashlib
import json

from .image_extraction import decode_visual_compact
from .image_semantics import ImageSemantics, render_reference_image
from .models import ImageReconstructionResult, SeedCandidate
from .store import ArtifactStore


def _run_id(seed_id: str, run_index: int) -> str:
    return "sha256:" + hashlib.sha256(f"image:{seed_id}:{run_index}".encode("utf-8")).hexdigest()


def _parse_description(payload: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for chunk in payload.split(";"):
        if "=" not in chunk:
            continue
        key, value = chunk.split("=", 1)
        values[key] = value
    return values


def _full_semantics(values: dict[str, object]) -> ImageSemantics:
    required = ("subject", "identity", "composition", "spatial", "camera", "lighting", "palette", "style")
    missing = [name for name in required if name not in values]
    if missing:
        raise ValueError(f"incomplete visual seed: {missing[0]}")
    return ImageSemantics(*(str(values[name]) for name in required))


class ReferenceImageReconstructor:
    generator_id = "reference-image-reconstructor:v0.4"

    def __init__(self, output_store: ArtifactStore):
        self.output_store = output_store

    def reconstruct(self, seed: SeedCandidate, run_index: int = 0) -> ImageReconstructionResult:
        run_id = _run_id(seed.seed_id, run_index)
        try:
            if seed.family == "visual_description":
                semantics = _full_semantics(_parse_description(seed.payload))
            elif seed.family == "visual_partial":
                partial = _parse_description(seed.payload)
                semantics = ImageSemantics(
                    subject=partial["subject"],
                    identity="alpha",
                    composition=partial["composition"],
                    spatial="above",
                    camera="medium",
                    lighting="flat",
                    palette=partial["palette"],
                    style=partial["style"],
                )
            elif seed.family == "visual_structured":
                semantics = _full_semantics(json.loads(seed.payload))
            elif seed.family == "visual_compact":
                semantics = decode_visual_compact(seed.payload)
            else:
                raise ValueError(f"unsupported image seed family: {seed.family}")
            png_bytes = render_reference_image(semantics)
            output = self.output_store.ingest_bytes(
                png_bytes,
                "image",
                {"generated_by": self.generator_id, "seed_id": seed.seed_id, "run_index": run_index},
            )
            output_artifact_id = output.artifact_id
            error = None
        except Exception as exc:
            output_artifact_id = None
            error = f"{type(exc).__name__}: {exc}"
        return ImageReconstructionResult(
            run_id=run_id,
            seed_id=seed.seed_id,
            output_artifact_id=output_artifact_id,
            source_visible_to_decoder=False,
            error=error,
            metadata={"generator": self.generator_id, "run_index": run_index},
        )
