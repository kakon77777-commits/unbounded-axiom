from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

from .db import RuntimeDB


@dataclass(frozen=True)
class LibraryQuery:
    required_factors: dict[str, str]
    optional_factors: dict[str, str] = field(default_factory=dict)
    exclude_seed_ids: tuple[str, ...] = ()
    modality: str = "image"
    family: str = "visual_compact"
    require_certificate: bool = True
    allowed_statuses: tuple[str, ...] = ("VALIDATED", "REUSABLE", "PORTABLE")
    max_candidates: int = 10

    def __post_init__(self) -> None:
        if self.max_candidates < 1:
            raise ValueError("max_candidates must be positive")
        overlap = set(self.required_factors) & set(self.optional_factors)
        if overlap:
            raise ValueError(f"factor cannot be both required and optional: {sorted(overlap)[0]}")


@dataclass(frozen=True)
class RecallCandidate:
    seed_id: str
    artifact_id: str
    optional_matches: int
    factors: dict[str, str]
    reasons: tuple[str, ...]
    record: dict[str, Any]


@dataclass(frozen=True)
class RecallPortfolio:
    query_id: str
    selected_seed_id: str | None
    candidates: tuple[RecallCandidate, ...]
    metadata: dict[str, Any] = field(default_factory=dict)


class SeedRetriever:
    """Explainable deterministic multi-index retrieval for v0.6.

    Factor/identity/freshness/certificate filters are authoritative in this reference
    runtime. Embedding/vector search is intentionally not part of v0.6 authority.
    """

    def __init__(self, db: RuntimeDB):
        self.db = db

    @staticmethod
    def _query_id(query: LibraryQuery) -> str:
        raw = json.dumps(
            {
                "required": query.required_factors,
                "optional": query.optional_factors,
                "exclude": query.exclude_seed_ids,
                "modality": query.modality,
                "family": query.family,
                "require_certificate": query.require_certificate,
                "allowed_statuses": query.allowed_statuses,
                "max_candidates": query.max_candidates,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def retrieve(self, query: LibraryQuery) -> RecallPortfolio:
        rows = self.db.query_validated_seeds(
            query.required_factors,
            allowed_statuses=query.allowed_statuses,
            require_certificate=query.require_certificate,
            exclude_seed_ids=query.exclude_seed_ids,
            modality=query.modality,
            family=query.family,
        )
        candidates: list[RecallCandidate] = []
        for record in rows:
            factors = self.db.get_seed_factors(record["seed_id"])
            optional_matches = sum(
                factors.get(name) == value for name, value in query.optional_factors.items()
            )
            reasons = [
                f"required:{name}={value}"
                for name, value in sorted(query.required_factors.items())
            ]
            reasons.extend(
                f"optional:{name}={value}"
                for name, value in sorted(query.optional_factors.items())
                if factors.get(name) == value
            )
            candidates.append(
                RecallCandidate(
                    seed_id=record["seed_id"],
                    artifact_id=record["artifact_id"],
                    optional_matches=optional_matches,
                    factors=factors,
                    reasons=tuple(reasons),
                    record=record,
                )
            )
        candidates.sort(key=lambda item: (-item.optional_matches, item.seed_id))
        selected = tuple(candidates[: query.max_candidates])
        return RecallPortfolio(
            query_id=self._query_id(query),
            selected_seed_id=selected[0].seed_id if selected else None,
            candidates=selected,
            metadata={
                "reason": "matched" if selected else "no_compatible_seed",
                "candidate_count_before_limit": len(candidates),
                "retrieval_authority": "factor+status+certificate:v0.6",
            },
        )
