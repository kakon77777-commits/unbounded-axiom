from __future__ import annotations

from dataclasses import dataclass

from .png_codec import decode_rgb_png, encode_rgb_png

WIDTH = 64
HEIGHT = 64
SUBJECTS = ("orb", "block", "spire")
IDENTITIES = ("alpha", "beta", "gamma")
COMPOSITIONS = ("left", "center", "right")
SPATIALS = ("above", "below", "beside")
CAMERAS = ("wide", "medium", "close")
LIGHTINGS = ("left", "right", "flat")
PALETTES = ("warm", "cool", "mono")
STYLES = ("solid", "striped", "outline")

_PALETTE_RGB = {
    "warm": ((245, 230, 210), (210, 70, 50), (240, 170, 60)),
    "cool": ((210, 230, 245), (50, 100, 210), (70, 190, 180)),
    "mono": ((225, 225, 225), (70, 70, 70), (150, 150, 150)),
}
_COMPOSITION_X = {"left": 18, "center": 32, "right": 46}
_CAMERA_RADIUS = {"wide": 6, "medium": 9, "close": 12}
_BLACK = (8, 8, 8)
_WHITE = (255, 255, 255)


@dataclass(frozen=True)
class ImageSemantics:
    subject: str
    identity: str
    composition: str
    spatial: str
    camera: str
    lighting: str
    palette: str
    style: str

    def __post_init__(self) -> None:
        fields = (
            ("subject", self.subject, SUBJECTS),
            ("identity", self.identity, IDENTITIES),
            ("composition", self.composition, COMPOSITIONS),
            ("spatial", self.spatial, SPATIALS),
            ("camera", self.camera, CAMERAS),
            ("lighting", self.lighting, LIGHTINGS),
            ("palette", self.palette, PALETTES),
            ("style", self.style, STYLES),
        )
        for name, value, allowed in fields:
            if value not in allowed:
                raise ValueError(f"unsupported {name}: {value}")


def _shape_contains(subject: str, dx: int, dy: int, radius: int) -> bool:
    if subject == "block":
        return abs(dx) <= radius and abs(dy) <= radius
    if subject == "orb":
        return dx * dx + dy * dy <= radius * radius
    if subject == "spire":
        if dy < -radius or dy > radius:
            return False
        half_width = (dy + radius) // 2
        return abs(dx) <= half_width
    raise ValueError(subject)


def _shape_border(subject: str, dx: int, dy: int, radius: int) -> bool:
    if not _shape_contains(subject, dx, dy, radius):
        return False
    for ox, oy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        if not _shape_contains(subject, dx + ox, dy + oy, radius):
            return True
    return False


def _identity_points(identity: str) -> set[tuple[int, int]]:
    if identity == "alpha":
        return {(0, d) for d in range(-2, 3)} | {(d, 0) for d in range(-2, 3)}
    if identity == "beta":
        return {(d, d) for d in range(-2, 3)} | {(d, -d) for d in range(-2, 3)}
    if identity == "gamma":
        return {
            (dx, dy)
            for dx in range(-2, 3)
            for dy in range(-2, 3)
            if abs(dx) == 2 or abs(dy) == 2
        }
    raise ValueError(identity)


def _set_pixel(pixels: bytearray, x: int, y: int, rgb: tuple[int, int, int]) -> None:
    if not (0 <= x < WIDTH and 0 <= y < HEIGHT):
        return
    i = (y * WIDTH + x) * 3
    pixels[i : i + 3] = bytes(rgb)


def _get_pixel(pixels: bytes, width: int, x: int, y: int) -> tuple[int, int, int]:
    i = (y * width + x) * 3
    return pixels[i], pixels[i + 1], pixels[i + 2]


def render_reference_image(semantics: ImageSemantics) -> bytes:
    bg, primary, secondary = _PALETTE_RGB[semantics.palette]
    pixels = bytearray(bytes(bg) * (WIDTH * HEIGHT))
    cx = _COMPOSITION_X[semantics.composition]
    cy = 32
    radius = _CAMERA_RADIUS[semantics.camera]

    for y in range(cy - radius, cy + radius + 1):
        for x in range(cx - radius, cx + radius + 1):
            dx, dy = x - cx, y - cy
            if not _shape_contains(semantics.subject, dx, dy, radius):
                continue
            border = _shape_border(semantics.subject, dx, dy, radius)
            fill = semantics.style == "solid" or (
                semantics.style == "striped" and ((y - cy + radius) % 4 < 2)
            )
            if border or fill:
                _set_pixel(pixels, x, y, primary)

    if semantics.spatial == "above":
        sx, sy = cx, cy - 15
    elif semantics.spatial == "below":
        sx, sy = cx, cy + 15
    else:
        sx, sy = cx + 15, cy
    for y in range(sy - 2, sy + 3):
        for x in range(sx - 2, sx + 3):
            _set_pixel(pixels, x, y, secondary)

    if semantics.lighting != "flat":
        sign = -1 if semantics.lighting == "left" else 1
        hx = cx + sign * max(3, radius // 2)
        hy = cy + max(3, radius // 2)
        for oy in (0, 1):
            for ox in (0, 1):
                x, y = hx + ox, hy + oy
                if _shape_contains(semantics.subject, x - cx, y - cy, radius):
                    _set_pixel(pixels, x, y, _WHITE)

    for dx, dy in _identity_points(semantics.identity):
        _set_pixel(pixels, cx + dx, cy + dy, _BLACK)

    return encode_rgb_png(WIDTH, HEIGHT, bytes(pixels))


def analyze_reference_image(png_bytes: bytes) -> ImageSemantics:
    width, height, pixels = decode_rgb_png(png_bytes)
    if (width, height) != (WIDTH, HEIGHT):
        raise ValueError("unexpected reference image dimensions")

    corner = _get_pixel(pixels, width, 0, 0)
    palette = next((name for name, (bg, _, _) in _PALETTE_RGB.items() if bg == corner), None)
    if palette is None:
        raise ValueError("unknown reference palette")
    bg, primary, secondary = _PALETTE_RGB[palette]

    associated: list[tuple[int, int]] = []
    secondary_points: list[tuple[int, int]] = []
    black_points_abs: list[tuple[int, int]] = []
    white_points: list[tuple[int, int]] = []
    for y in range(height):
        for x in range(width):
            rgb = _get_pixel(pixels, width, x, y)
            if rgb == secondary:
                secondary_points.append((x, y))
            elif rgb != bg:
                associated.append((x, y))
                if rgb == _BLACK:
                    black_points_abs.append((x, y))
                elif rgb == _WHITE:
                    white_points.append((x, y))

    if not associated or not secondary_points:
        raise ValueError("reference image missing expected visual components")
    min_x = min(x for x, _ in associated)
    max_x = max(x for x, _ in associated)
    min_y = min(y for _, y in associated)
    max_y = max(y for _, y in associated)
    cx = (min_x + max_x) // 2
    cy = (min_y + max_y) // 2

    composition = min(_COMPOSITION_X, key=lambda key: abs(_COMPOSITION_X[key] - cx))
    radius_observed = max(max_x - min_x, max_y - min_y) // 2
    camera = min(_CAMERA_RADIUS, key=lambda key: abs(_CAMERA_RADIUS[key] - radius_observed))
    radius = _CAMERA_RADIUS[camera]

    top_left = (cx - radius, cy - radius)
    bottom_left = (cx - radius, cy + radius)
    assoc_set = set(associated)
    if top_left in assoc_set:
        subject = "block"
    elif bottom_left in assoc_set:
        subject = "spire"
    else:
        subject = "orb"

    sx = sum(x for x, _ in secondary_points) / len(secondary_points)
    sy = sum(y for _, y in secondary_points) / len(secondary_points)
    if sy < cy - 6:
        spatial = "above"
    elif sy > cy + 6:
        spatial = "below"
    else:
        spatial = "beside"

    if not white_points:
        lighting = "flat"
    else:
        mean_white_x = sum(x for x, _ in white_points) / len(white_points)
        lighting = "left" if mean_white_x < cx else "right"

    black_rel = {(x - cx, y - cy) for x, y in black_points_abs}
    identity = None
    for candidate in IDENTITIES:
        if black_rel == _identity_points(candidate):
            identity = candidate
            break
    if identity is None:
        raise ValueError("unknown reference identity marker")

    interior = [
        (cx + dx, cy + dy)
        for dy in range(-radius, radius + 1)
        for dx in range(-radius, radius + 1)
        if _shape_contains(subject, dx, dy, radius) and not _shape_border(subject, dx, dy, radius)
    ]
    if not interior:
        raise ValueError("reference shape has no interior")
    primary_interior = sum(
        _get_pixel(pixels, width, x, y) == primary for x, y in interior
    )
    fill_ratio = primary_interior / len(interior)
    if fill_ratio < 0.15:
        style = "outline"
    elif fill_ratio < 0.60:
        style = "striped"
    else:
        style = "solid"

    return ImageSemantics(
        subject=subject,
        identity=identity,
        composition=composition,
        spatial=spatial,
        camera=camera,
        lighting=lighting,
        palette=palette,
        style=style,
    )
