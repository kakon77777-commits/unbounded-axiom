from __future__ import annotations

import hashlib
import json

from .dependencies import DependencyAudit
from .models import EvaluationResult, SeedCandidate, ValidationCertificate


class CertificateIssuer:
    def __init__(self, min_success_probability: float = 1.0):
        if not 0 <= min_success_probability <= 1:
            raise ValueError("min_success_probability must be in [0,1]")
        self.min_success_probability = min_success_probability

    def issue(
        self,
        seed: SeedCandidate,
        dependency_audit: DependencyAudit,
        evaluations: list[EvaluationResult],
        generator_scope: str,
    ) -> ValidationCertificate:
        success_probability = (
            sum(1 for item in evaluations if item.passed) / len(evaluations) if evaluations else 0.0
        )
        passed = (
            dependency_audit.passed
            and bool(evaluations)
            and success_probability >= self.min_success_probability
        )
        material = json.dumps(
            {
                "seed": seed.seed_id,
                "generator": generator_scope,
                "runs": [item.evaluation_id for item in evaluations],
                "dep": dependency_audit.passed,
                "threshold": self.min_success_probability,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        certificate_id = "sha256:" + hashlib.sha256(material).hexdigest()
        return ValidationCertificate(
            certificate_id=certificate_id,
            seed_id=seed.seed_id,
            generator_scope=generator_scope,
            repeated_runs=len(evaluations),
            success_probability=success_probability,
            dependency_passed=dependency_audit.passed,
            passed=passed,
            metadata={
                "min_success_probability": self.min_success_probability,
                "violations": list(dependency_audit.violations),
            },
        )
