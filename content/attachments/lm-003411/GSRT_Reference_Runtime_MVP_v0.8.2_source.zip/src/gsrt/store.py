from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .models import ArtifactRecord


class ArtifactStore:
    """Content-addressed exact source storage."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def ingest_bytes(
        self, data: bytes, modality: str, metadata: dict[str, Any] | None = None
    ) -> ArtifactRecord:
        if not modality:
            raise ValueError("modality must not be empty")
        raw = bytes(data)
        digest = hashlib.sha256(raw).hexdigest()
        artifact_id = f"sha256:{digest}"
        path = self.root / digest
        if not path.exists():
            path.write_bytes(raw)
        elif path.read_bytes() != raw:
            raise RuntimeError("content-address collision")
        return ArtifactRecord(
            artifact_id=artifact_id,
            modality=modality,
            source_hash=artifact_id,
            source_bytes=len(raw),
            metadata=dict(metadata or {}),
        )

    def ingest_text(self, text: str, metadata: dict[str, Any] | None = None) -> ArtifactRecord:
        return self.ingest_bytes(text.encode("utf-8"), "text", metadata)

    def read_bytes(self, artifact_id: str) -> bytes:
        algo, digest = artifact_id.split(":", 1)
        if algo != "sha256":
            raise ValueError(f"unsupported artifact id: {artifact_id}")
        return (self.root / digest).read_bytes()

    def read_text(self, artifact_id: str) -> str:
        return self.read_bytes(artifact_id).decode("utf-8")
