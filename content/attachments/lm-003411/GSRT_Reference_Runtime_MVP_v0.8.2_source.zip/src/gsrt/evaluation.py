from __future__ import annotations

import hashlib

from .models import EvaluationResult, ReconstructionResult
from .text_semantics import parse_fixture_text


class TextFidelityEvaluator:
    evaluator_id = "reference-text-fidelity:v0.1"

    def evaluate(self, source_text: str, result: ReconstructionResult) -> EvaluationResult:
        try:
            src = parse_fixture_text(source_text)
            out = parse_fixture_text(result.text)
            concept_parts = [
                src.subject == out.subject,
                src.object == out.object,
                src.condition == out.condition,
                src.consequence == out.consequence,
            ]
            scores = {
                "concept": sum(concept_parts) / len(concept_parts),
                "relation": float(src.relation == out.relation),
                "negation": float(src.negated_implication == out.negated_implication),
                "qualifier": float(src.condition == out.condition),
                "epistemic": float(src.epistemic == out.epistemic),
                "order": float(
                    src.subject == out.subject
                    and src.object == out.object
                    and src.relation == out.relation
                ),
                "style": float(src.style == out.style),
            }
            scores["functional"] = float(
                scores["relation"] == 1.0
                and scores["negation"] == 1.0
                and scores["qualifier"] == 1.0
                and scores["epistemic"] == 1.0
            )
            scores["overall"] = sum(scores.values()) / len(scores)
            hard_pass = all(
                scores[name] == 1.0
                for name in ("relation", "negation", "qualifier", "epistemic", "order")
            )
            passed = hard_pass and scores["concept"] == 1.0
            parse_error = None
        except Exception as exc:
            scores = {
                "concept": 0.0,
                "relation": 0.0,
                "negation": 0.0,
                "qualifier": 0.0,
                "epistemic": 0.0,
                "order": 0.0,
                "style": 0.0,
                "functional": 0.0,
                "overall": 0.0,
            }
            hard_pass = False
            passed = False
            parse_error = f"{type(exc).__name__}: {exc}"
        material = f"{result.run_id}:{self.evaluator_id}".encode("utf-8")
        evaluation_id = "sha256:" + hashlib.sha256(material).hexdigest()
        return EvaluationResult(
            evaluation_id=evaluation_id,
            run_id=result.run_id,
            seed_id=result.seed_id,
            scores=scores,
            hard_pass=hard_pass,
            passed=passed,
            metadata={"evaluator": self.evaluator_id, "parse_error": parse_error},
        )
