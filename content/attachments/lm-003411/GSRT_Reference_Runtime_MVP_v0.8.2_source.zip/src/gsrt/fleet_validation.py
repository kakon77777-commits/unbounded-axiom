from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass

from .certificates import CertificateIssuer
from .dependencies import DependencyAuditor, DependencyPolicy
from .fleet import MutationProposal
from .image_evaluation import ImageFidelityEvaluator
from .image_extraction import ReferenceImageSeedExtractor, decode_visual_compact
from .image_factors import semantic_delta
from .image_reconstruction import ReferenceImageReconstructor
from .image_semantics import render_reference_image
from .library import SeedLibrary


@dataclass(frozen=True)
class ValidatedMutation:
    seed_id: str
    passed: bool
    duplicate_existing: bool
    lineage_edge_id: str
    factor: str
    worker_id: str
    prior_name: str
    validation_cost: float


class MutationValidator:
    def __init__(self, library: SeedLibrary):
        self.library = library
        self.extractor = ReferenceImageSeedExtractor(library.artifacts.read_bytes)
        self.reconstructor = ReferenceImageReconstructor(library.outputs)
        self.evaluator = ImageFidelityEvaluator(library.outputs.read_bytes)
        self.auditor = DependencyAuditor()
        self.issuer = CertificateIssuer(1.0)

    @staticmethod
    def _edge_id(parent_seed_id: str, child_seed_id: str, proposal: MutationProposal) -> str:
        material = json.dumps(
            {
                "parent": parent_seed_id,
                "child": child_seed_id,
                "factor": proposal.factor,
                "prior": proposal.prior_name,
                "worker": proposal.worker_id,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(material).hexdigest()

    def validate(self, parent_seed_id: str, proposal: MutationProposal) -> ValidatedMutation:
        parent_record = self.library.db.get_validated_seed(parent_seed_id)
        if parent_record is None:
            raise KeyError(parent_seed_id)
        if str(parent_record.get("status")) not in {"VALIDATED", "REUSABLE", "PORTABLE"}:
            raise ValueError("mutation parent must be reusable")
        if str(parent_record.get("family")) != "visual_compact":
            raise ValueError("mutation parent must be visual_compact")
        parent_semantics = decode_visual_compact(str(parent_record["payload"]))
        if parent_semantics != proposal.parent:
            raise ValueError("proposal parent does not match parent seed")
        changed = semantic_delta(proposal.parent, proposal.child)
        if changed != {proposal.factor}:
            raise ValueError("proposal delta must change exactly its declared factor")
        if getattr(proposal.parent, proposal.factor) != proposal.old_value:
            raise ValueError("proposal old value mismatch")
        if getattr(proposal.child, proposal.factor) != proposal.new_value:
            raise ValueError("proposal new value mismatch")

        png_bytes = render_reference_image(proposal.child)
        artifact = self.library.artifacts.ingest_bytes(
            png_bytes,
            "image",
            {
                "generated_by": "synthetic-mutation-fleet:v0.8.2",
                "parent_seed_id": parent_seed_id,
                "worker_id": proposal.worker_id,
                "prior_name": proposal.prior_name,
                "factor": proposal.factor,
            },
        )
        seed = self.extractor.extract(artifact, "visual_compact", 8)
        audit = self.auditor.audit(seed, DependencyPolicy.strict())
        reconstruction = self.reconstructor.reconstruct(seed, 0)
        evaluation = self.evaluator.evaluate(proposal.child, png_bytes, reconstruction)
        certificate = self.issuer.issue(seed, audit, [evaluation], self.reconstructor.generator_id)
        if not certificate.passed:
            raise ValueError("mutation candidate failed validation")

        existing = self.library.db.get_validated_seed(seed.seed_id)
        duplicate_existing = existing is not None
        if existing is not None:
            if (
                str(existing.get("artifact_id")) != artifact.artifact_id
                or str(existing.get("family")) != seed.family
                or str(existing.get("payload")) != seed.payload
            ):
                raise ValueError("seed identity collision")
            if str(existing.get("status")) not in {"VALIDATED", "REUSABLE", "PORTABLE"}:
                raise ValueError("existing seed is not reusable")
        else:
            with self.library.db.batch():
                self.library.db.record_artifact(artifact)
                self.library.db.record_seed_candidate(seed)
                self.library.db.record_reconstruction_run(reconstruction)
                self.library.db.record_evaluation(evaluation)
                self.library.db.record_certificate(certificate)
            promoted = self.library.promote_image_seed(artifact, seed, certificate)
            metadata = dict(promoted.get("metadata", {}))
            metadata.update(
                {
                    "mutation_source": "heterogeneous-fleet:v0.8.2",
                    "parent_seed_id": parent_seed_id,
                    "worker_id": proposal.worker_id,
                    "prior_name": proposal.prior_name,
                    "factor": proposal.factor,
                }
            )
            promoted = dict(promoted)
            promoted["metadata"] = metadata
            self.library.db.record_validated_seed(promoted)

        edge_id = self._edge_id(parent_seed_id, seed.seed_id, proposal)
        self.library.db.record_lineage_edge(
            edge_id,
            parent_seed_id,
            seed.seed_id,
            "mutated_from",
            {
                "worker_id": proposal.worker_id,
                "prior_name": proposal.prior_name,
                "factor": proposal.factor,
                "duplicate_existing": duplicate_existing,
                "experiment": "heterogeneous-mutation-fleet:v0.8.2",
            },
        )
        return ValidatedMutation(
            seed_id=seed.seed_id,
            passed=True,
            duplicate_existing=duplicate_existing,
            lineage_edge_id=edge_id,
            factor=proposal.factor,
            worker_id=proposal.worker_id,
            prior_name=proposal.prior_name,
            validation_cost=3.0,
        )
