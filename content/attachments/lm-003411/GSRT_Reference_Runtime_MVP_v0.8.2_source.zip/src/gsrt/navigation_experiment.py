from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .image_extraction import decode_visual_compact, encode_visual_compact
from .image_factors import FACTOR_SPECS, replace_factor
from .image_semantics import ImageSemantics, analyze_reference_image, render_reference_image
from .library_experiment import (
    LibraryExperimentRunner,
    _FACTOR_NAMES,
    _SPACE_SIZE,
    _fresh_sequence,
    _state_from_index,
)
from .models import NavigationExperimentReport
from .navigation import (
    FailureMap,
    GoalCompiler,
    NavigationExecutor,
    QueryPlanner,
    RuleBasedNavigationPlanner,
    hamming_distance,
)
from .retrieval import LibraryQuery, SeedRetriever

_DISTANCE_BUCKETS = (1, 2, 3)


@dataclass(frozen=True)
class NavigationExperimentConfig:
    count: int = 96
    tasks_per_distance: int = 32
    max_fresh_attempts: int = _SPACE_SIZE
    max_navigation_steps: int = 5


def _experiment_id(config: NavigationExperimentConfig) -> str:
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _mapping(state: ImageSemantics) -> dict[str, str]:
    return {name: getattr(state, name) for name in _FACTOR_NAMES}


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _condition_cost(metrics: dict[str, Any]) -> float:
    return float(
        metrics["generation_count"]
        + metrics["evaluator_calls"]
        + metrics["retrieval_calls"]
        + metrics["planner_calls"]
        + metrics["known_failure_revisits"]
    )


class NavigationExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.library_runner = LibraryExperimentRunner(self.root)
        self.library = self.library_runner.library
        self.retriever = SeedRetriever(self.library.db)
        self.failure_map = FailureMap(self.library.db)
        self.planner = RuleBasedNavigationPlanner(self.library.db, self.failure_map)
        self.executor = NavigationExecutor(self.library.db, self.planner)
        self.goal_compiler = GoalCompiler()
        self.query_planner = QueryPlanner()

    def _build_initial_library(self, count: int) -> list[dict[str, Any]]:
        return self.library_runner._build_library(count)

    @staticmethod
    def _goal_sort_key(distance: int, state_index: int) -> str:
        return hashlib.sha256(f"gsrt-v0.8-goal:{distance}:{state_index}".encode("utf-8")).hexdigest()

    def _held_out_goals(
        self,
        records: list[dict[str, Any]],
        tasks_per_distance: int,
    ) -> dict[int, list[ImageSemantics]]:
        initial_states = [decode_visual_compact(str(record["payload"])) for record in records]
        initial_payloads = {str(record["payload"]) for record in records}
        buckets: dict[int, list[tuple[int, ImageSemantics]]] = {d: [] for d in _DISTANCE_BUCKETS}
        for state_index in range(_SPACE_SIZE):
            state = _state_from_index(state_index)
            if encode_visual_compact(state) in initial_payloads:
                continue
            distance = min(
                hamming_distance(_mapping(state), _mapping(initial))
                for initial in initial_states
            )
            if distance in buckets:
                buckets[distance].append((state_index, state))
        selected: dict[int, list[ImageSemantics]] = {}
        for distance in _DISTANCE_BUCKETS:
            ordered = sorted(
                buckets[distance],
                key=lambda item: self._goal_sort_key(distance, item[0]),
            )
            if len(ordered) < tasks_per_distance:
                raise ValueError(
                    f"insufficient held-out goals at distance {distance}: "
                    f"{len(ordered)} < {tasks_per_distance}"
                )
            selected[distance] = [state for _, state in ordered[:tasks_per_distance]]
        return selected

    @staticmethod
    def _fresh_condition(task_id: str, target: ImageSemantics, max_attempts: int) -> dict[str, Any]:
        attempts = 0
        success = False
        for state_index in _fresh_sequence(task_id):
            if attempts >= max_attempts:
                break
            attempts += 1
            if _state_from_index(state_index) == target:
                success = True
                break
        metrics = {
            "success": success,
            "generation_count": attempts,
            "evaluator_calls": attempts,
            "retrieval_calls": 0,
            "planner_calls": 0,
            "known_failure_revisits": 0,
            "path_length": 0,
            "protected_leakage": 0.0,
        }
        metrics["reference_cost"] = _condition_cost(metrics)
        return metrics

    def _nearest_condition(self, selected_seed_id: str, target: ImageSemantics) -> dict[str, Any]:
        record = self.library.db.get_validated_seed(selected_seed_id)
        if record is None:
            raise KeyError(selected_seed_id)
        observed = analyze_reference_image(
            render_reference_image(decode_visual_compact(str(record["payload"])))
        )
        metrics = {
            "success": observed == target,
            "generation_count": 1,
            "evaluator_calls": 1,
            "retrieval_calls": 1,
            "planner_calls": 0,
            "known_failure_revisits": 0,
            "path_length": 0,
            "protected_leakage": 0.0,
        }
        metrics["reference_cost"] = _condition_cost(metrics)
        return metrics

    def _local_mutation_condition(
        self,
        start: ImageSemantics,
        goal,
    ) -> dict[str, Any]:
        mismatch = next(
            name for name in _FACTOR_NAMES
            if getattr(start, name) != goal.hard_constraints[name]
        )
        target_value = goal.hard_constraints[mismatch]
        donor_portfolio = self.retriever.retrieve(
            LibraryQuery(
                required_factors={mismatch: target_value},
                optional_factors={
                    name: goal.hard_constraints[name]
                    for name in _FACTOR_NAMES
                    if name != mismatch
                },
                max_candidates=1024,
            )
        )
        if donor_portfolio.selected_seed_id is None:
            raise RuntimeError(f"local mutation has no donor for factor: {mismatch}")
        donor_factors = self.library.db.get_seed_factors(donor_portfolio.selected_seed_id)
        if donor_factors.get(mismatch) != target_value:
            raise RuntimeError("local mutation donor does not carry target value")
        candidate = replace_factor(start, mismatch, target_value)
        observed = analyze_reference_image(render_reference_image(candidate))
        changed = {
            name for name in _FACTOR_NAMES if getattr(start, name) != getattr(observed, name)
        }
        leakage = len(changed - {mismatch}) / max(1, len(_FACTOR_NAMES) - 1)
        metrics = {
            "success": observed == ImageSemantics(**goal.hard_constraints),
            "generation_count": 1,
            "evaluator_calls": 1,
            "retrieval_calls": 2,  # nearest/base retrieval + donor retrieval
            "planner_calls": 0,    # fixed first-mismatch operator; no route planning
            "known_failure_revisits": 0,
            "path_length": 1,
            "protected_leakage": leakage,
        }
        metrics["reference_cost"] = _condition_cost(metrics)
        return metrics

    def _seed_prior_failures(
        self,
        start: ImageSemantics,
        goal,
    ) -> int:
        """Create one deterministic prior failed donor route for every required step."""
        current = start
        opportunities = 0
        while _mapping(current) != goal.hard_constraints:
            action = self.planner.next_action(current, goal, use_history=False)
            self.failure_map.record(
                state_signature=encode_visual_compact(current),
                operator_id=action.operator_id,
                donor_seed_id=action.donor_seed_id,
                goal_id=goal.goal_id,
                failure_class="KNOWN_ROUTE_CONFLICT",
                metadata={"source": "preexisting-navigation-history:v0.8"},
            )
            current = replace_factor(current, action.factor_name, action.target_value)
            opportunities += 1
        return opportunities

    def _count_no_history_revisits(self, start: ImageSemantics, goal) -> int:
        current = start
        revisits = 0
        while _mapping(current) != goal.hard_constraints:
            action = self.planner.next_action(current, goal, use_history=False)
            revisits += int(
                self.failure_map.is_known(
                    encode_visual_compact(current),
                    action.operator_id,
                    action.donor_seed_id,
                    goal.goal_id,
                )
            )
            current = replace_factor(current, action.factor_name, action.target_value)
        return revisits

    def _full_navigation_condition(
        self,
        start_seed_id: str,
        goal,
        *,
        max_steps: int,
    ) -> tuple[dict[str, Any], Any]:
        outcome = self.executor.navigate(
            start_seed_id,
            goal,
            max_steps=max_steps,
            use_history=True,
        )
        metrics = {
            "success": outcome.success,
            "generation_count": outcome.generation_count,
            "evaluator_calls": outcome.evaluator_calls,
            "retrieval_calls": 1 + outcome.donor_retrieval_calls,
            "planner_calls": outcome.planner_calls,
            "known_failure_revisits": outcome.known_failure_revisits,
            "path_length": outcome.path_length,
            "protected_leakage": outcome.mean_protected_leakage,
        }
        metrics["reference_cost"] = _condition_cost(metrics)
        return metrics, outcome

    @staticmethod
    def _summarize_condition(rows: list[dict[str, Any]], key: str) -> dict[str, float]:
        values = [row[key] for row in rows]
        total = len(values)
        return {
            "success_rate": sum(float(item["success"]) for item in values) / total,
            "mean_reference_cost": _mean([float(item["reference_cost"]) for item in values]),
            "mean_generation_count": _mean([float(item["generation_count"]) for item in values]),
            "mean_evaluator_calls": _mean([float(item["evaluator_calls"]) for item in values]),
            "mean_retrieval_calls": _mean([float(item["retrieval_calls"]) for item in values]),
            "mean_planner_calls": _mean([float(item["planner_calls"]) for item in values]),
            "mean_known_failure_revisits": _mean(
                [float(item["known_failure_revisits"]) for item in values]
            ),
            "mean_path_length": _mean([float(item["path_length"]) for item in values]),
            "mean_protected_leakage": _mean(
                [float(item["protected_leakage"]) for item in values]
            ),
        }

    def run(self, config: NavigationExperimentConfig) -> NavigationExperimentReport:
        if config.count < 2:
            raise ValueError("count must be at least two")
        if config.tasks_per_distance < 1:
            raise ValueError("tasks_per_distance must be positive")
        if config.max_fresh_attempts < 1 or config.max_fresh_attempts > _SPACE_SIZE:
            raise ValueError("max_fresh_attempts must be within the reference state space")
        if config.max_navigation_steps < 3:
            raise ValueError("max_navigation_steps must support d3 goals")

        records = self._build_initial_library(config.count)
        initial_snapshot = self.library.snapshot_digest()
        initial_payloads = {str(record["payload"]) for record in records}
        goals = self._held_out_goals(records, config.tasks_per_distance)
        task_records: list[dict[str, Any]] = []
        held_out_violations = 0
        distance_violations = 0
        start_seed_mutation_violations = 0
        failure_opportunities = 0
        no_history_revisits = 0
        history_revisits = 0
        avoided_failures = 0
        oracle_successes = 0
        oracle_costs: list[float] = []

        for distance in _DISTANCE_BUCKETS:
            for target in goals[distance]:
                goal = self.goal_compiler.compile(target)
                target_payload = encode_visual_compact(target)
                held_out_violations += int(target_payload in initial_payloads)
                task_id = "sha256:" + hashlib.sha256(
                    json.dumps(
                        {"distance": distance, "target": target_payload},
                        sort_keys=True,
                        separators=(",", ":"),
                    ).encode("utf-8")
                ).hexdigest()
                plan = self.query_planner.compile(goal, max_candidates=config.count)
                portfolio = self.retriever.retrieve(plan.library_query)
                if portfolio.selected_seed_id is None:
                    raise RuntimeError("nearest-seed retrieval returned no candidate")
                start_record = self.library.db.get_validated_seed(portfolio.selected_seed_id)
                if start_record is None:
                    raise RuntimeError("selected start seed disappeared")
                start_record_before = json.loads(
                    json.dumps(start_record, sort_keys=True, ensure_ascii=False)
                )
                start = decode_visual_compact(str(start_record["payload"]))
                actual_distance = hamming_distance(_mapping(start), goal.hard_constraints)
                distance_violations += int(actual_distance != distance)

                a = self._fresh_condition(task_id, target, config.max_fresh_attempts)
                b = self._nearest_condition(portfolio.selected_seed_id, target)
                c = self._local_mutation_condition(start, goal)
                oracle_observed = analyze_reference_image(render_reference_image(target))
                oracle_success = oracle_observed == target
                oracle_successes += int(oracle_success)
                oracle_cost = 2.0
                oracle_costs.append(oracle_cost)

                opportunities = self._seed_prior_failures(start, goal)
                failure_opportunities += opportunities
                no_history = self._count_no_history_revisits(start, goal)
                no_history_revisits += no_history
                d, outcome = self._full_navigation_condition(
                    portfolio.selected_seed_id,
                    goal,
                    max_steps=config.max_navigation_steps,
                )
                history_revisits += int(d["known_failure_revisits"])
                avoided_failures += outcome.avoided_known_failures
                start_seed_mutation_violations += int(
                    self.library.db.get_validated_seed(portfolio.selected_seed_id)
                    != start_record_before
                )

                task_records.append(
                    {
                        "task_id": task_id,
                        "goal_id": goal.goal_id,
                        "distance_bucket": f"d{distance}",
                        "initial_distance": actual_distance,
                        "target_payload": target_payload,
                        "start_seed_id": portfolio.selected_seed_id,
                        "start_optional_matches": portfolio.candidates[0].optional_matches,
                        "A_fresh": a,
                        "B_nearest_reuse": b,
                        "C_local_mutation": c,
                        "D_full_navigation": d,
                        "oracle_direct": {
                            "success": oracle_success,
                            "generation_count": 1,
                            "evaluator_calls": 1,
                            "reference_cost": oracle_cost,
                        },
                        "known_failure_opportunities": opportunities,
                        "no_history_known_failure_revisits": no_history,
                        "history_avoided_known_failures": outcome.avoided_known_failures,
                        "D_changed_factor_path": [
                            step.action.factor_name for step in outcome.steps
                        ],
                    }
                )

        conditions = {
            key: self._summarize_condition(task_records, key)
            for key in (
                "A_fresh",
                "B_nearest_reuse",
                "C_local_mutation",
                "D_full_navigation",
            )
        }
        by_distance: dict[str, dict[str, float]] = {}
        for distance in _DISTANCE_BUCKETS:
            label = f"d{distance}"
            rows = [row for row in task_records if row["distance_bucket"] == label]
            by_distance[label] = {
                "task_count": float(len(rows)),
                "A_fresh_success_rate": _mean([float(row["A_fresh"]["success"]) for row in rows]),
                "B_nearest_reuse_success_rate": _mean(
                    [float(row["B_nearest_reuse"]["success"]) for row in rows]
                ),
                "C_local_mutation_success_rate": _mean(
                    [float(row["C_local_mutation"]["success"]) for row in rows]
                ),
                "D_full_navigation_success_rate": _mean(
                    [float(row["D_full_navigation"]["success"]) for row in rows]
                ),
                "D_mean_path_length": _mean(
                    [float(row["D_full_navigation"]["path_length"]) for row in rows]
                ),
                "D_mean_reference_cost": _mean(
                    [float(row["D_full_navigation"]["reference_cost"]) for row in rows]
                ),
                "mean_navigation_gain": _mean(
                    [
                        float(row["A_fresh"]["reference_cost"])
                        - float(row["D_full_navigation"]["reference_cost"])
                        for row in rows
                    ]
                ),
            }

        a_total = sum(float(row["A_fresh"]["reference_cost"]) for row in task_records)
        d_total = sum(float(row["D_full_navigation"]["reference_cost"]) for row in task_records)
        overall = {
            "mean_navigation_gain": _mean(
                [
                    float(row["A_fresh"]["reference_cost"])
                    - float(row["D_full_navigation"]["reference_cost"])
                    for row in task_records
                ]
            ),
            "relative_navigation_gain": 1.0 - (d_total / a_total),
            "mean_D_path_length": conditions["D_full_navigation"]["mean_path_length"],
            "mean_D_protected_leakage": conditions["D_full_navigation"]["mean_protected_leakage"],
            "navigation_vs_oracle_gain": _mean(
                [
                    float(row["oracle_direct"]["reference_cost"])
                    - float(row["D_full_navigation"]["reference_cost"])
                    for row in task_records
                ]
            ),
        }
        failure_memory = {
            "known_failure_opportunities": float(failure_opportunities),
            "history_known_failure_revisits": float(history_revisits),
            "no_history_known_failure_revisits": float(no_history_revisits),
            "history_revisit_rate": history_revisits / failure_opportunities if failure_opportunities else 0.0,
            "no_history_revisit_rate": no_history_revisits / failure_opportunities if failure_opportunities else 0.0,
            "avoided_known_failures": float(avoided_failures),
            "reference_failure_memory_gain": float(no_history_revisits - history_revisits),
        }
        final_snapshot = self.library.snapshot_digest()
        controls = {
            "held_out_goal_violations": float(held_out_violations),
            "distance_bucket_violations": float(distance_violations),
            "library_snapshot_changed": float(final_snapshot != initial_snapshot),
            "start_seed_mutation_violations": float(start_seed_mutation_violations),
            "failure_map_record_count": float(self.library.db.count("navigation_failures")),
            "oracle_direct_success_rate": oracle_successes / len(task_records),
            "oracle_direct_mean_reference_cost": _mean(oracle_costs),
        }
        return NavigationExperimentReport(
            experiment_id=_experiment_id(config),
            artifact_count=config.count,
            initial_library_seed_count=len(records),
            task_count=len(task_records),
            goal_distance_counts={
                f"d{distance}": len(goals[distance]) for distance in _DISTANCE_BUCKETS
            },
            conditions=conditions,
            by_distance=by_distance,
            overall=overall,
            failure_memory=failure_memory,
            controls=controls,
            task_records=task_records,
            metadata={
                "runtime_version": "0.8.0",
                "experiment": "seed-space-navigation:v0.8",
                "evidence_level": "SYNTHETIC_VISUAL_SEED_SPACE_NAVIGATION",
                "real_world_navigation_claim": False,
                "initial_library_snapshot": initial_snapshot,
                "final_library_snapshot": final_snapshot,
                "held_out_goal_policy": "complete states absent from initial library, bucketed by nearest-seed Hamming distance",
                "goal_distances": list(_DISTANCE_BUCKETS),
                "conditions": {
                    "A": "memoryless deterministic full-space exact search",
                    "B": "nearest reusable seed, no mutation",
                    "C": "nearest reusable seed + exactly one local factor mutation",
                    "D": "nearest reusable seed + history-aware multi-step factor navigation",
                },
                "failure_history_policy": "one preexisting failed donor route per required navigation step",
                "search_space_size": _SPACE_SIZE,
                "fresh_proposal_conditioning": "goal is used only for pass/fail; it does not reshape the proposal permutation",
                "oracle_control": "direct deterministic target compilation; negative control against universal navigation superiority",
                "cost_model": {
                    "generation": 1.0,
                    "evaluation": 1.0,
                    "retrieval": 1.0,
                    "planner": 1.0,
                    "known_failure_revisit": 1.0,
                    "claim": "reference operation count; not a universal economic scalar",
                },
            },
        )
