from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from .certificates import CertificateIssuer
from .controls import make_controls
from .corpus import generate_reference_corpus
from .db import RuntimeDB
from .dependencies import DependencyAuditor, DependencyPolicy
from .evaluation import TextFidelityEvaluator
from .extraction import ReferenceSeedExtractor
from .models import ExperimentReport, SeedCandidate
from .reconstruction import ReferenceReconstructor
from .store import ArtifactStore


@dataclass(frozen=True)
class ExperimentConfig:
    count: int = 120
    budget_bytes: int = 512
    repetitions: int = 2
    families: tuple[str, ...] = ("summary", "keyword", "freeform", "structured")
    min_success_probability: float = 1.0
    include_controls: bool = True


class ExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = ArtifactStore(self.root / "artifacts")
        self.db = RuntimeDB(self.root / "runtime.sqlite3")
        self.extractor = ReferenceSeedExtractor(self.artifacts.read_text)
        self.reconstructor = ReferenceReconstructor()
        self.evaluator = TextFidelityEvaluator()
        self.auditor = DependencyAuditor()

    def _edge_id(self, source: str, target: str, operation: str) -> str:
        raw = f"{source}:{target}:{operation}".encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def run(self, config: ExperimentConfig) -> ExperimentReport:
        if config.repetitions < 1:
            raise ValueError("repetitions must be positive")
        corpus = generate_reference_corpus(config.count)
        artifact_records = []
        for item in corpus:
            record = self.artifacts.ingest_text(item.text, item.metadata)
            self.db.record_artifact(record)
            artifact_records.append(record)

        seeds_by_artifact: dict[str, dict[str, SeedCandidate]] = {}
        for record in artifact_records:
            by_family: dict[str, SeedCandidate] = {}
            for family in config.families:
                seed = self.extractor.extract(record, family, config.budget_bytes)
                self.db.record_seed_candidate(seed)
                self.db.record_lineage_edge(
                    self._edge_id(record.artifact_id, seed.seed_id, "extracted_from"),
                    record.artifact_id,
                    seed.seed_id,
                    "extracted_from",
                    {"family": family},
                )
                by_family[family] = seed
            seeds_by_artifact[record.artifact_id] = by_family

        score_names = (
            "concept",
            "relation",
            "negation",
            "qualifier",
            "epistemic",
            "order",
            "style",
            "functional",
            "overall",
        )
        family_totals = {
            family: {
                "total": 0,
                "passed": 0,
                "payload_bytes": 0,
                "adjusted_cost_bytes": 0,
                "evaluation_runs": 0,
                "score_sums": {name: 0.0 for name in score_names},
            }
            for family in config.families
        }
        control_totals = {
            name: {"total": 0, "passed": 0}
            for name in ("random", "relation_shuffle", "contradiction", "unrelated")
        }
        visibility_violations = 0
        certificate_passed = 0
        certificate_total = 0
        issuer = CertificateIssuer(config.min_success_probability)

        for record in artifact_records:
            source_text = self.artifacts.read_text(record.artifact_id)
            for family, seed in seeds_by_artifact[record.artifact_id].items():
                audit = self.auditor.audit(seed, DependencyPolicy.strict())
                family_totals[family]["payload_bytes"] += seed.payload_bytes
                family_totals[family]["adjusted_cost_bytes"] += audit.adjusted_cost_bytes
                evaluations = []
                for run_index in range(config.repetitions):
                    result = self.reconstructor.reconstruct(seed, run_index)
                    visibility_violations += int(result.source_visible_to_decoder)
                    self.db.record_reconstruction_run(result)
                    evaluation = self.evaluator.evaluate(source_text, result)
                    self.db.record_evaluation(evaluation)
                    evaluations.append(evaluation)
                    family_totals[family]["evaluation_runs"] += 1
                    for score_name in score_names:
                        family_totals[family]["score_sums"][score_name] += evaluation.scores[score_name]
                cert = issuer.issue(seed, audit, evaluations, self.reconstructor.generator_id)
                self.db.record_certificate(cert)
                family_totals[family]["total"] += 1
                family_totals[family]["passed"] += int(cert.passed)
                certificate_total += 1
                certificate_passed += int(cert.passed)

        # Negative controls use a different artifact's structured seed as the unrelated control.
        structured_available = "structured" in config.families
        if config.include_controls and structured_available and len(artifact_records) > 1:
            for idx, record in enumerate(artifact_records):
                source_text = self.artifacts.read_text(record.artifact_id)
                seed = seeds_by_artifact[record.artifact_id]["structured"]
                other_record = artifact_records[(idx + 1) % len(artifact_records)]
                unrelated = seeds_by_artifact[other_record.artifact_id]["structured"]
                for name, control in make_controls(seed, unrelated).items():
                    self.db.record_seed_candidate(control)
                    for run_index in range(config.repetitions):
                        result = self.reconstructor.reconstruct(control, run_index)
                        visibility_violations += int(result.source_visible_to_decoder)
                        self.db.record_reconstruction_run(result)
                        evaluation = self.evaluator.evaluate(source_text, result)
                        self.db.record_evaluation(evaluation)
                        control_totals[name]["total"] += 1
                        control_totals[name]["passed"] += int(evaluation.passed)

        family_stats = {}
        for family, values in family_totals.items():
            total = values["total"]
            evaluation_runs = values["evaluation_runs"]
            stats = {
                "total": float(total),
                "passed": float(values["passed"]),
                "pass_rate": values["passed"] / total if total else 0.0,
                "mean_payload_bytes": values["payload_bytes"] / total if total else 0.0,
                "mean_adjusted_cost_bytes": values["adjusted_cost_bytes"] / total if total else 0.0,
                "evaluation_runs": float(evaluation_runs),
            }
            for score_name in score_names:
                stats[f"mean_{score_name}"] = (
                    values["score_sums"][score_name] / evaluation_runs if evaluation_runs else 0.0
                )
            family_stats[family] = stats
        control_stats = {
            name: {
                "total": float(values["total"]),
                "passed": float(values["passed"]),
                "pass_rate": values["passed"] / values["total"] if values["total"] else 0.0,
            }
            for name, values in control_totals.items()
        }
        config_json = json.dumps(config.__dict__, sort_keys=True, default=list)
        experiment_id = "sha256:" + hashlib.sha256(config_json.encode("utf-8")).hexdigest()
        return ExperimentReport(
            experiment_id=experiment_id,
            artifact_count=len(artifact_records),
            seed_count=len(artifact_records) * len(config.families),
            family_stats=family_stats,
            control_stats=control_stats,
            source_visibility_violations=visibility_violations,
            certificate_passed=certificate_passed,
            certificate_total=certificate_total,
            metadata={
                "budget_bytes": config.budget_bytes,
                "repetitions": config.repetitions,
                "families": list(config.families),
                "evidence_level": "OFFLINE_REFERENCE_FIXTURE",
            },
        )
