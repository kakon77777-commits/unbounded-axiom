"""GSRT reference runtime."""

__version__ = "0.8.2"
