from __future__ import annotations

import hashlib
import json

from .composition import CompatibilityResult, CompositionContract
from .db import RuntimeDB
from .image_extraction import decode_visual_compact, encode_visual_compact
from .image_factors import FACTOR_SPECS, replace_factor
from .models import SeedCandidate, ValidationCertificate


class BranchManager:
    """Isolated candidate branches for v0.7 composition/mutation."""

    def __init__(self, db: RuntimeDB):
        self.db = db

    @staticmethod
    def _branch_id(
        contract: CompositionContract,
        compatibility: CompatibilityResult,
        base_payload_hash: str,
        candidate_payload: str,
    ) -> str:
        raw = json.dumps(
            {
                "recipient": contract.recipient_seed_id,
                "assignments": [
                    {"factor": item.factor_name, "donor": item.donor_seed_id}
                    for item in contract.assignments
                ],
                "protected": contract.protected_factors,
                "base_payload_hash": base_payload_hash,
                "candidate_payload": candidate_payload,
                "resolved": compatibility.resolved_values,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def create(
        self,
        contract: CompositionContract,
        compatibility: CompatibilityResult,
    ) -> dict:
        if not compatibility.passed:
            raise ValueError("composition compatibility must pass before branching")
        if compatibility.recipient_seed_id != contract.recipient_seed_id:
            raise ValueError("compatibility recipient mismatch")
        recipient = self.db.get_validated_seed(contract.recipient_seed_id)
        if recipient is None:
            raise ValueError("missing recipient")
        if recipient.get("family") != "visual_compact":
            raise ValueError("v0.7 reference branches require visual_compact recipient")

        semantics = decode_visual_compact(str(recipient["payload"]))
        for factor_name in compatibility.target_factors:
            semantics = replace_factor(
                semantics,
                factor_name,
                compatibility.resolved_values[factor_name],
            )
        candidate_payload = encode_visual_compact(semantics)
        branch_id = self._branch_id(
            contract,
            compatibility,
            str(recipient["payload_hash"]),
            candidate_payload,
        )
        record = {
            "branch_id": branch_id,
            "base_seed_id": contract.recipient_seed_id,
            "base_payload_hash": str(recipient["payload_hash"]),
            "status": "OPEN",
            "candidate_payload": candidate_payload,
            "target_factors": list(compatibility.target_factors),
            "protected_factors": list(contract.protected_factors),
            "resolved_values": dict(compatibility.resolved_values),
            "donor_seed_ids": dict(compatibility.donor_seed_ids),
            "compatibility_status": compatibility.status,
            "compatibility_reasons": list(compatibility.reasons),
            "promoted_seed_id": None,
            "metadata": dict(contract.metadata),
        }
        self.db.record_composition_branch(record)
        return record

    def set_status(self, branch_id: str, status: str, **updates) -> dict:
        record = self.db.get_composition_branch(branch_id)
        if record is None:
            raise KeyError(branch_id)
        updated = dict(record)
        updated.update(updates)
        updated["status"] = status
        self.db.record_composition_branch(updated)
        return updated


class PromotionGate:
    """The only ordinary v0.7 path from a composition branch into reusable memory."""

    def __init__(self, db: RuntimeDB):
        self.db = db
        self.branches = BranchManager(db)

    @staticmethod
    def _edge_id(source_id: str, target_id: str, operation: str, suffix: str = "") -> str:
        material = f"{source_id}:{target_id}:{operation}:{suffix}".encode("utf-8")
        return "sha256:" + hashlib.sha256(material).hexdigest()

    def _record_composition_lineage(self, branch: dict, target_seed_id: str) -> None:
        self.db.record_lineage_edge(
            self._edge_id(branch["base_seed_id"], target_seed_id, "composed_from"),
            branch["base_seed_id"],
            target_seed_id,
            "composed_from",
            {"branch_id": branch["branch_id"], "role": "recipient"},
        )
        donors_to_factors: dict[str, list[str]] = {}
        for factor_name, donor_seed_id in branch["donor_seed_ids"].items():
            donors_to_factors.setdefault(donor_seed_id, []).append(factor_name)
        for donor_seed_id, factor_names in sorted(donors_to_factors.items()):
            self.db.record_lineage_edge(
                self._edge_id(
                    donor_seed_id,
                    target_seed_id,
                    "donated_factor",
                    ",".join(sorted(factor_names)),
                ),
                donor_seed_id,
                target_seed_id,
                "donated_factor",
                {"branch_id": branch["branch_id"], "factors": sorted(factor_names)},
            )

    def promote(
        self,
        branch_id: str,
        seed: SeedCandidate,
        certificate: ValidationCertificate,
    ) -> dict:
        branch = self.db.get_composition_branch(branch_id)
        if branch is None:
            raise KeyError(branch_id)
        if branch["status"] != "OPEN":
            raise ValueError(f"branch not promotable: {branch['status']}")
        if not certificate.passed or certificate.seed_id != seed.seed_id:
            self.branches.set_status(branch_id, "REJECTED", rejection_reason="certificate_failed")
            raise ValueError("promotion requires passing certificate")
        if seed.family != "visual_compact":
            self.branches.set_status(branch_id, "REJECTED", rejection_reason="wrong_seed_family")
            raise ValueError("promotion requires visual_compact seed")
        if seed.payload != branch["candidate_payload"]:
            self.branches.set_status(branch_id, "REJECTED", rejection_reason="candidate_payload_mismatch")
            raise ValueError("branch candidate payload mismatch")

        base = self.db.get_validated_seed(branch["base_seed_id"])
        if base is None or base.get("payload_hash") != branch["base_payload_hash"]:
            self.branches.set_status(branch_id, "STALE", stale_reason="branch_base_moved")
            raise ValueError("branch base moved")
        artifact = self.db.get_artifact(seed.artifact_id)
        if artifact is None or artifact.modality != "image":
            self.branches.set_status(branch_id, "REJECTED", rejection_reason="missing_realized_artifact")
            raise ValueError("promotion requires realized image artifact")

        existing = self.db.get_validated_seed(seed.seed_id)
        if existing is not None:
            same_identity_material = (
                existing.get("artifact_id") == seed.artifact_id
                and existing.get("family") == seed.family
                and existing.get("payload") == seed.payload
            )
            if not same_identity_material:
                self.branches.set_status(
                    branch_id,
                    "REJECTED",
                    rejection_reason="seed_identity_collision",
                )
                raise ValueError("seed identity collision")
            if existing.get("status") not in {"VALIDATED", "REUSABLE", "PORTABLE"}:
                self.branches.set_status(
                    branch_id,
                    "REJECTED",
                    rejection_reason="existing_seed_not_reusable",
                )
                raise ValueError("existing seed is not reusable")
            with self.db.batch():
                self.db.record_seed_candidate(seed)
                self.db.record_certificate(certificate)
                self.branches.set_status(
                    branch_id,
                    "PROMOTED",
                    promoted_seed_id=seed.seed_id,
                    promotion_mode="EXISTING_REUSABLE",
                )
                self._record_composition_lineage(branch, seed.seed_id)
            return existing

        semantics = decode_visual_compact(seed.payload)
        payload_hash = hashlib.sha256(seed.payload.encode("utf-8")).hexdigest()
        promoted = {
            "seed_id": seed.seed_id,
            "artifact_id": seed.artifact_id,
            "modality": "image",
            "family": seed.family,
            "payload": seed.payload,
            "payload_hash": payload_hash,
            "status": "REUSABLE",
            "certificate_id": certificate.certificate_id,
            "freshness_key": certificate.generator_scope,
            "metadata": {
                "promotion": "composition-branch:v0.7",
                "branch_id": branch_id,
                "source_authority": "artifact-store",
                "target_factors": list(branch["target_factors"]),
                "donor_seed_ids": dict(branch["donor_seed_ids"]),
            },
        }
        with self.db.batch():
            self.db.record_seed_candidate(seed)
            self.db.record_certificate(certificate)
            self.db.record_validated_seed(promoted)
            for factor_name in FACTOR_SPECS:
                self.db.record_seed_factor(seed.seed_id, factor_name, getattr(semantics, factor_name))
            self.branches.set_status(
                branch_id,
                "PROMOTED",
                promoted_seed_id=seed.seed_id,
                promotion_mode="NEW_REUSABLE",
            )
            self._record_composition_lineage(branch, seed.seed_id)
        return promoted
