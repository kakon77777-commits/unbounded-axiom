from __future__ import annotations

import hashlib
import json

from .models import ReconstructionResult, SeedCandidate
from .reference_codebook import decode_compact
from .text_semantics import TextSemantics, parse_fixture_text, render_fixture_text


def _run_id(seed_id: str, run_index: int) -> str:
    raw = f"{seed_id}:{run_index}".encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _from_freeform(payload: str) -> TextSemantics:
    parts = {}
    for chunk in payload.split(";"):
        if ":" not in chunk:
            continue
        key, value = chunk.split(":", 1)
        parts[key] = value
    required = {"S", "E", "R", "O", "C", "N", "Q", "T"}
    if not required.issubset(parts):
        raise ValueError("incomplete freeform seed")
    return TextSemantics(
        subject=parts["S"],
        epistemic=parts["E"],
        relation=parts["R"],
        object=parts["O"],
        condition=parts["C"],
        negated_implication=parts["N"] == "1",
        consequence=parts["Q"],
        style=parts["T"],
    )


def _from_structured(payload: str) -> TextSemantics:
    obj = json.loads(payload)
    return TextSemantics(
        subject=obj["s"],
        epistemic=obj["e"],
        relation=obj["r"],
        object=obj["o"],
        condition=obj["c"],
        negated_implication=bool(obj["n"]),
        consequence=obj["q"],
        style=obj["t"],
    )


class ReferenceReconstructor:
    """Seed-only deterministic reconstructor for offline MVP validation."""

    generator_id = "reference-reconstructor:v0.2"

    def reconstruct(self, seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult:
        run_id = _run_id(seed.seed_id, run_index)
        try:
            if seed.family == "summary":
                semantics = parse_fixture_text(seed.payload)
            elif seed.family == "keyword":
                parts = seed.payload.split("|")
                if len(parts) != 4:
                    raise ValueError("incomplete keyword seed")
                semantics = TextSemantics(
                    subject=parts[0],
                    epistemic="may",
                    relation="support",
                    object=parts[1],
                    condition=parts[2],
                    negated_implication=False,
                    consequence=parts[3],
                    style="neutral",
                )
            elif seed.family == "freeform":
                semantics = _from_freeform(seed.payload)
            elif seed.family == "structured":
                semantics = _from_structured(seed.payload)
            elif seed.family == "compact":
                semantics = decode_compact(seed.payload)
            else:
                raise ValueError(f"unsupported seed family: {seed.family}")
            text = render_fixture_text(semantics)
            error = None
        except Exception as exc:  # explicit failed reconstruction record
            text = ""
            error = f"{type(exc).__name__}: {exc}"
        return ReconstructionResult(
            run_id=run_id,
            seed_id=seed.seed_id,
            text=text,
            source_visible_to_decoder=False,
            error=error,
            metadata={"generator": self.generator_id, "run_index": run_index},
        )
