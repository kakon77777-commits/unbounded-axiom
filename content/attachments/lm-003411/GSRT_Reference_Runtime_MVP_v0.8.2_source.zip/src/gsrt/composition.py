from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .db import RuntimeDB
from .image_factors import FACTOR_SPECS

_REUSABLE_STATUSES = {"VALIDATED", "REUSABLE", "PORTABLE"}


@dataclass(frozen=True)
class FactorAssignment:
    factor_name: str
    donor_seed_id: str


@dataclass(frozen=True)
class CompositionContract:
    recipient_seed_id: str
    assignments: tuple[FactorAssignment, ...]
    protected_factors: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class CompatibilityResult:
    status: str
    recipient_seed_id: str
    target_factors: tuple[str, ...]
    protected_factors: tuple[str, ...]
    resolved_values: dict[str, str]
    donor_seed_ids: dict[str, str]
    reasons: tuple[str, ...] = ()

    @property
    def passed(self) -> bool:
        return self.status == "PASS"


class CompatibilityEngine:
    """Fail-closed factor-composition compatibility for v0.7.

    The engine resolves factor values from persistent validated donor records. It does
    not infer compatibility from semantic/vector similarity and does not modify seeds.
    """

    def __init__(self, db: RuntimeDB):
        self.db = db

    def check(self, contract: CompositionContract) -> CompatibilityResult:
        reasons: list[str] = []
        resolved: dict[str, str] = {}
        donor_ids: dict[str, str] = {}
        target_factors = tuple(item.factor_name for item in contract.assignments)

        recipient = self.db.get_validated_seed(contract.recipient_seed_id)
        if recipient is None:
            reasons.append(f"missing_recipient:{contract.recipient_seed_id}")
        elif str(recipient.get("status")) not in _REUSABLE_STATUSES:
            reasons.append(f"recipient_not_reusable:{recipient.get('status')}")

        seen: set[str] = set()
        protected = set(contract.protected_factors)
        for assignment in contract.assignments:
            factor_name = assignment.factor_name
            if factor_name not in FACTOR_SPECS:
                reasons.append(f"unknown_factor:{factor_name}")
                continue
            if factor_name in seen:
                reasons.append(f"duplicate_target:{factor_name}")
                continue
            seen.add(factor_name)
            if factor_name in protected:
                reasons.append(f"protected_target_overlap:{factor_name}")

            donor = self.db.get_validated_seed(assignment.donor_seed_id)
            if donor is None:
                reasons.append(f"missing_donor:{assignment.donor_seed_id}")
                continue
            donor_status = str(donor.get("status"))
            if donor_status not in _REUSABLE_STATUSES:
                reasons.append(
                    f"donor_not_reusable:{assignment.donor_seed_id}:{donor_status}"
                )
                continue
            donor_factors = self.db.get_seed_factors(assignment.donor_seed_id)
            if factor_name not in donor_factors:
                reasons.append(f"donor_missing_factor:{assignment.donor_seed_id}:{factor_name}")
                continue
            resolved[factor_name] = donor_factors[factor_name]
            donor_ids[factor_name] = assignment.donor_seed_id

        return CompatibilityResult(
            status="FAIL" if reasons else "PASS",
            recipient_seed_id=contract.recipient_seed_id,
            target_factors=target_factors,
            protected_factors=contract.protected_factors,
            resolved_values=resolved,
            donor_seed_ids=donor_ids,
            reasons=tuple(reasons),
        )
