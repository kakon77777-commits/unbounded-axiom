from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class ArtifactRecord:
    artifact_id: str
    modality: str
    source_hash: str
    source_bytes: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DependencyRef:
    kind: str
    ref: str
    cost_bytes: int = 0


@dataclass(frozen=True)
class SeedCandidate:
    seed_id: str
    artifact_id: str
    family: str
    payload: str
    payload_bytes: int
    budget_bytes: int
    dependencies: tuple[DependencyRef, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ReconstructionResult:
    run_id: str
    seed_id: str
    text: str
    source_visible_to_decoder: bool
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ImageReconstructionResult:
    run_id: str
    seed_id: str
    output_artifact_id: str | None
    source_visible_to_decoder: bool
    error: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class EvaluationResult:
    evaluation_id: str
    run_id: str
    seed_id: str
    scores: dict[str, float]
    hard_pass: bool
    passed: bool
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ValidationCertificate:
    certificate_id: str
    seed_id: str
    generator_scope: str
    repeated_runs: int
    success_probability: float
    dependency_passed: bool
    passed: bool
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class CorpusItem:
    text: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ExperimentReport:
    experiment_id: str
    artifact_count: int
    seed_count: int
    family_stats: dict[str, dict[str, float]]
    control_stats: dict[str, dict[str, float]]
    source_visibility_violations: int
    certificate_passed: int
    certificate_total: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass(frozen=True)
class BudgetSweepReport:
    sweep_id: str
    artifact_count: int
    budgets: tuple[int, ...]
    families: tuple[str, ...]
    curves: dict[str, list[dict[str, Any]]]
    minimums: dict[str, dict[str, Any]]
    artifact_minima: list[dict[str, Any]]
    cliffs: dict[str, dict[str, Any] | None]
    control_budget_bytes: int
    control_stats: dict[str, dict[str, float]]
    source_visibility_violations: int
    certificate_passed: int
    certificate_total: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass(frozen=True)
class CrossDecoderReport:
    experiment_id: str
    artifact_count: int
    families: tuple[str, ...]
    decoders: tuple[str, ...]
    family_budgets: dict[str, int]
    matrix: dict[str, dict[str, dict[str, Any]]]
    family_consensus: dict[str, dict[str, float]]
    channel_home_decoders: dict[str, str]
    diagonal_pass_rate: float
    off_diagonal_pass_rate: float
    interoperability_gap: float
    control_stats: dict[str, dict[str, float]]
    source_visibility_violations: int
    certificate_passed: int
    certificate_total: int
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)



@dataclass(frozen=True)
class FactorExperimentReport:
    experiment_id: str
    artifact_count: int
    factor_count: int
    ablation_stats: dict[str, dict[str, float]]
    transplant_stats: dict[str, dict[str, float]]
    semantic_coupling_matrix: dict[str, dict[str, float]]
    pixel_interaction_matrix: dict[str, dict[str, float]]
    strongest_pixel_interactions: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

@dataclass(frozen=True)
class LibraryExperimentReport:
    experiment_id: str
    artifact_count: int
    library_seed_count: int
    task_count: int
    library_snapshot: str
    by_specificity: dict[str, dict[str, float]]
    overall: dict[str, float]
    controls: dict[str, float]
    source_seed_reuse_violations: int
    library_reuse_failure_count: int
    fresh_search_failure_count: int
    recorded_failure_count: int
    task_records: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)



@dataclass(frozen=True)
class CompositionExperimentReport:
    experiment_id: str
    artifact_count: int
    initial_library_seed_count: int
    task_count: int
    promoted_seed_count: int
    new_seed_count: int
    existing_state_hit_count: int
    by_specificity: dict[str, dict[str, float]]
    overall: dict[str, float]
    pairwise_composability_matrix: dict[str, dict[str, dict[str, float]]]
    controls: dict[str, float]
    branch_isolation_violations: int
    task_records: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class NavigationExperimentReport:
    experiment_id: str
    artifact_count: int
    initial_library_seed_count: int
    task_count: int
    goal_distance_counts: dict[str, int]
    conditions: dict[str, dict[str, float]]
    by_distance: dict[str, dict[str, float]]
    overall: dict[str, float]
    failure_memory: dict[str, float]
    controls: dict[str, float]
    task_records: list[dict[str, Any]]
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
