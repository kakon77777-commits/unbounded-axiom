from __future__ import annotations

from dataclasses import dataclass

from .models import SeedCandidate


@dataclass(frozen=True)
class DependencyPolicy:
    forbidden_kinds: frozenset[str]
    private_kinds: frozenset[str]

    @classmethod
    def strict(cls) -> "DependencyPolicy":
        private = frozenset({"PRIVATE_PER_ITEM", "HIDDEN_CACHE", "SOURCE_ARTIFACT"})
        return cls(forbidden_kinds=private, private_kinds=private)


@dataclass(frozen=True)
class DependencyAudit:
    passed: bool
    private_cost_bytes: int
    adjusted_cost_bytes: int
    violations: tuple[str, ...]


class DependencyAuditor:
    def audit(self, seed: SeedCandidate, policy: DependencyPolicy) -> DependencyAudit:
        private_cost = sum(
            max(0, dep.cost_bytes) for dep in seed.dependencies if dep.kind in policy.private_kinds
        )
        violations = tuple(sorted({dep.kind for dep in seed.dependencies if dep.kind in policy.forbidden_kinds}))
        return DependencyAudit(
            passed=not violations,
            private_cost_bytes=private_cost,
            adjusted_cost_bytes=seed.payload_bytes + private_cost,
            violations=violations,
        )
