from __future__ import annotations

import itertools
import json
from dataclasses import dataclass
from typing import Mapping, Sequence

from .db import RuntimeDB
from .image_extraction import decode_visual_compact
from .image_factors import FACTOR_SPECS
from .image_semantics import ImageSemantics


@dataclass(frozen=True)
class NoveltyScore:
    nearest: float
    mean: float


@dataclass(frozen=True)
class ArchiveStats:
    total_niches: int
    filled_niches: int
    coverage: float
    qd_score: float
    mean_quality: float
    mean_novelty: float


def descriptor_distance(left: Sequence[str], right: Sequence[str]) -> float:
    if len(left) != len(right) or not left:
        raise ValueError("descriptor vectors must have equal non-zero length")
    return sum(a != b for a, b in zip(left, right, strict=True)) / len(left)


def novelty_score(
    candidate: Sequence[str], occupied: Sequence[Sequence[str]]
) -> NoveltyScore:
    if not occupied:
        return NoveltyScore(0.0, 0.0)
    distances = [descriptor_distance(candidate, other) for other in occupied]
    return NoveltyScore(min(distances), sum(distances) / len(distances))


@dataclass(frozen=True)
class BehaviorDescriptorSchema:
    descriptor_id: str
    version: str
    dimensions: tuple[str, ...]
    bins: Mapping[str, tuple[str, ...]]

    @classmethod
    def visual_v081(cls) -> "BehaviorDescriptorSchema":
        dimensions = ("style", "composition", "camera")
        return cls(
            descriptor_id="visual-style-composition-camera",
            version="0.8.1",
            dimensions=dimensions,
            bins={name: tuple(FACTOR_SPECS[name].allowed) for name in dimensions},
        )

    @property
    def key(self) -> str:
        return f"{self.descriptor_id}@{self.version}"

    def schema_dict(self) -> dict[str, object]:
        return {
            "descriptor_id": self.descriptor_id,
            "version": self.version,
            "dimensions": list(self.dimensions),
            "bins": {name: list(self.bins[name]) for name in self.dimensions},
        }

    def all_niches(self) -> tuple[str, ...]:
        values = itertools.product(*(self.bins[name] for name in self.dimensions))
        return tuple(sorted("|".join(parts) for parts in values))

    def describe(self, semantics: ImageSemantics) -> "BehaviorDescriptor":
        values = tuple(getattr(semantics, name) for name in self.dimensions)
        for name, value in zip(self.dimensions, values, strict=True):
            if value not in self.bins[name]:
                raise ValueError(f"value outside descriptor bins: {name}={value}")
        return BehaviorDescriptor(
            descriptor_key=self.key,
            dimensions=self.dimensions,
            values=values,
        )


@dataclass(frozen=True)
class BehaviorDescriptor:
    descriptor_key: str
    dimensions: tuple[str, ...]
    values: tuple[str, ...]

    @property
    def niche_key(self) -> str:
        return "|".join(self.values)


@dataclass(frozen=True)
class QDCell:
    descriptor_key: str
    niche_key: str
    elite_seed_id: str
    quality: float
    novelty_nearest: float
    novelty_mean: float
    updated_seq: int


@dataclass(frozen=True)
class AdmissionResult:
    accepted: bool
    reason: str
    niche_key: str
    elite_seed_id: str


class QDArchive:
    """Derived quality-diversity archive over validated reusable SeedStore records."""

    def __init__(self, db: RuntimeDB, schema: BehaviorDescriptorSchema):
        self.db = db
        self.schema = schema
        self.db.record_qd_descriptor(
            {
                "descriptor_key": schema.key,
                "descriptor_id": schema.descriptor_id,
                "descriptor_version": schema.version,
                "schema": schema.schema_dict(),
            }
        )

    def _cell_from_record(self, record: dict) -> QDCell:
        if str(record.get("descriptor_version", "")) != self.schema.version:
            raise ValueError("descriptor version mismatch")
        if str(record.get("descriptor_key", "")) != self.schema.key:
            raise ValueError("descriptor key mismatch")
        return QDCell(
            descriptor_key=str(record["descriptor_key"]),
            niche_key=str(record["niche_key"]),
            elite_seed_id=str(record["elite_seed_id"]),
            quality=float(record["quality"]),
            novelty_nearest=float(record.get("novelty_nearest", 0.0)),
            novelty_mean=float(record.get("novelty_mean", 0.0)),
            updated_seq=int(record.get("updated_seq", 0)),
        )

    def cells(self) -> list[QDCell]:
        return [self._cell_from_record(record) for record in self.db.query_qd_cells(self.schema.key)]

    def _recompute_novelty(self) -> None:
        records = self.db.query_qd_cells(self.schema.key)
        vectors = {
            str(record["niche_key"]): tuple(str(value) for value in record["descriptor_values"])
            for record in records
        }
        for record in records:
            niche_key = str(record["niche_key"])
            occupied = [values for key, values in vectors.items() if key != niche_key]
            score = novelty_score(vectors[niche_key], occupied)
            updated = dict(record)
            updated["novelty_nearest"] = score.nearest
            updated["novelty_mean"] = score.mean
            self.db.record_qd_cell(updated)

    def stats(self) -> ArchiveStats:
        cells = self.cells()
        total = len(self.schema.all_niches())
        filled = len(cells)
        return ArchiveStats(
            total_niches=total,
            filled_niches=filled,
            coverage=filled / total,
            qd_score=sum(cell.quality for cell in cells),
            mean_quality=(sum(cell.quality for cell in cells) / filled if filled else 0.0),
            mean_novelty=(sum(cell.novelty_mean for cell in cells) / filled if filled else 0.0),
        )

    def consider(self, seed_id: str, *, quality: float) -> AdmissionResult:
        if not 0.0 <= quality <= 1.0:
            raise ValueError("quality must be in [0, 1]")
        seed = self.db.get_validated_seed(seed_id)
        if seed is None:
            raise KeyError(seed_id)
        if str(seed.get("status")) not in {"VALIDATED", "REUSABLE", "PORTABLE"}:
            raise ValueError("QD admission requires reusable seed")
        if str(seed.get("family")) != "visual_compact":
            raise ValueError("v0.8.1 QD archive requires visual_compact seed")
        semantics = decode_visual_compact(str(seed["payload"]))
        descriptor = self.schema.describe(semantics)
        current = self.db.get_qd_cell(self.schema.key, descriptor.niche_key)
        if current is None:
            accepted = True
            reason = "EMPTY_NICHE"
            elite_seed_id = seed_id
            updated_seq = len(self.cells()) + 1
        else:
            current_quality = float(current["quality"])
            current_seed_id = str(current["elite_seed_id"])
            better = quality > current_quality or (
                quality == current_quality and seed_id < current_seed_id
            )
            if not better:
                return AdmissionResult(False, "NOT_BETTER", descriptor.niche_key, current_seed_id)
            accepted = True
            reason = "QUALITY_IMPROVEMENT" if quality > current_quality else "TIE_BREAK"
            elite_seed_id = seed_id
            updated_seq = int(current.get("updated_seq", 0)) + 1
        record = {
            "descriptor_key": self.schema.key,
            "descriptor_version": self.schema.version,
            "niche_key": descriptor.niche_key,
            "descriptor_values": list(descriptor.values),
            "elite_seed_id": elite_seed_id,
            "quality": quality,
            "novelty_nearest": 0.0,
            "novelty_mean": 0.0,
            "updated_seq": updated_seq,
        }
        with self.db.batch():
            self.db.record_qd_cell(record)
            self._recompute_novelty()
        return AdmissionResult(accepted, reason, descriptor.niche_key, elite_seed_id)

    def filled_niches(self) -> int:
        return len(self.cells())

    def coverage(self) -> float:
        return self.filled_niches() / len(self.schema.all_niches())

    def qd_score(self) -> float:
        return sum(cell.quality for cell in self.cells())

    def rebuild(self, seed_ids: Sequence[str], *, quality: float = 1.0) -> None:
        self.db.clear_qd_cells(self.schema.key)
        for seed_id in sorted(seed_ids):
            self.consider(seed_id, quality=quality)
