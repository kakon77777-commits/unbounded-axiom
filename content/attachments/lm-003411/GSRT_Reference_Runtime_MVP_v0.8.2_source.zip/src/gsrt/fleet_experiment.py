from __future__ import annotations

import hashlib
import json
import math
import shutil
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .fleet import FleetWorker, MutationPrior, mutate_descriptor
from .fleet_validation import MutationValidator
from .image_extraction import decode_visual_compact
from .library_experiment import LibraryExperimentRunner
from .qd import BehaviorDescriptorSchema, QDArchive


@dataclass(frozen=True)
class FleetExperimentConfig:
    trials: int = 32
    candidate_budget: int = 30
    worker_count: int = 3
    experiment_seed: str = "gsrt-v0.8.2"

    def __post_init__(self) -> None:
        if self.trials < 1:
            raise ValueError("trials must be positive")
        if self.candidate_budget < 1:
            raise ValueError("candidate_budget must be positive")
        if self.worker_count != 3:
            raise ValueError("v0.8.2 reference fleet requires exactly three workers")
        if not self.experiment_seed:
            raise ValueError("experiment_seed must be non-empty")


@dataclass(frozen=True)
class FleetExperimentReport:
    experiment_id: str
    conditions: dict[str, dict[str, Any]]
    paired: dict[str, float]
    controls: dict[str, float]
    metadata: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return {
            "experiment_id": self.experiment_id,
            "conditions": {name: dict(metrics) for name, metrics in self.conditions.items()},
            "paired": dict(self.paired),
            "controls": dict(self.controls),
            "metadata": dict(self.metadata),
        }


def _experiment_id(config: FleetExperimentConfig) -> str:
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _stable_index(material: str, size: int) -> int:
    if size < 1:
        raise ValueError("size must be positive")
    digest = hashlib.sha256(material.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % size


def _condition_workers() -> dict[str, tuple[FleetWorker, FleetWorker, FleetWorker]]:
    balanced = MutationPrior("balanced", (1 / 3, 1 / 3, 1 / 3))
    style_biased = MutationPrior("style-biased", (0.8, 0.1, 0.1))
    composition_biased = MutationPrior("composition-biased", (0.1, 0.8, 0.1))
    camera_biased = MutationPrior("camera-biased", (0.1, 0.1, 0.8))
    return {
        "homogeneous_balanced": tuple(
            FleetWorker(f"balanced-{index}", balanced) for index in range(3)
        ),
        "homogeneous_biased": tuple(
            FleetWorker(f"biased-{index}", style_biased) for index in range(3)
        ),
        "heterogeneous_complementary": (
            FleetWorker("style-specialist", style_biased),
            FleetWorker("composition-specialist", composition_biased),
            FleetWorker("camera-specialist", camera_biased),
        ),
        "label_only_control": tuple(
            FleetWorker(f"heterogeneous-label-{index}", balanced) for index in range(3)
        ),
    }


def _normal_ci(values: list[float]) -> tuple[float, float]:
    if not values:
        return (0.0, 0.0)
    mean = statistics.mean(values)
    if len(values) == 1:
        return (mean, mean)
    sem = statistics.stdev(values) / math.sqrt(len(values))
    margin = 1.96 * sem
    return (mean - margin, mean + margin)


class FleetExperimentRunner:
    REFERENCE_COST_PER_CANDIDATE = 5.0

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.schema = BehaviorDescriptorSchema.visual_v081()

    def _run_trial(
        self,
        condition: str,
        workers: tuple[FleetWorker, FleetWorker, FleetWorker],
        config: FleetExperimentConfig,
        trial: int,
    ) -> dict[str, float]:
        trial_root = self.root / "fleet-runs" / f"trial-{trial:03d}" / condition
        library_runner = LibraryExperimentRunner(trial_root)
        base_records = library_runner._build_library(1)
        library = library_runner.library
        archive = QDArchive(library.db, self.schema)
        base_seed_id = str(base_records[0]["seed_id"])
        archive.consider(base_seed_id, quality=1.0)
        validator = MutationValidator(library)

        valid = 0
        duplicates = 0
        archive_accepts = 0
        for attempt in range(config.candidate_budget):
            cells = sorted(archive.cells(), key=lambda cell: (cell.niche_key, cell.elite_seed_id))
            parent_cell = cells[
                _stable_index(
                    f"{config.experiment_seed}:trial={trial}:attempt={attempt}:parent",
                    len(cells),
                )
            ]
            parent_record = library.db.get_validated_seed(parent_cell.elite_seed_id)
            if parent_record is None:
                raise RuntimeError("QD elite is missing from SeedStore")
            parent = decode_visual_compact(str(parent_record["payload"]))
            worker_index = attempt % config.worker_count
            worker = workers[worker_index]
            proposal = mutate_descriptor(
                parent,
                worker,
                worker_index=worker_index,
                trial=trial,
                attempt=attempt,
                experiment_seed=config.experiment_seed,
            )
            result = validator.validate(parent_cell.elite_seed_id, proposal)
            valid += int(result.passed)
            duplicates += int(result.duplicate_existing)
            admission = archive.consider(result.seed_id, quality=1.0)
            archive_accepts += int(admission.accepted)

        stats = archive.stats()
        cost = config.candidate_budget * self.REFERENCE_COST_PER_CANDIDATE
        return {
            "filled_niches": float(stats.filled_niches),
            "coverage": stats.coverage,
            "mean_novelty": stats.mean_novelty,
            "valid_admission_rate": valid / config.candidate_budget,
            "duplicate_rate": duplicates / config.candidate_budget,
            "archive_acceptance_rate": archive_accepts / config.candidate_budget,
            "reference_cost": cost,
            "coverage_per_cost": stats.coverage / cost,
        }

    @staticmethod
    def _aggregate(rows: list[dict[str, float]], config: FleetExperimentConfig) -> dict[str, Any]:
        def mean(key: str) -> float:
            return statistics.mean(row[key] for row in rows)

        return {
            "trials": float(config.trials),
            "candidate_attempts": float(config.trials * config.candidate_budget),
            "mean_filled_niches": mean("filled_niches"),
            "mean_coverage": mean("coverage"),
            "mean_novelty": mean("mean_novelty"),
            "mean_valid_admission_rate": mean("valid_admission_rate"),
            "mean_duplicate_rate": mean("duplicate_rate"),
            "mean_archive_acceptance_rate": mean("archive_acceptance_rate"),
            "mean_reference_cost": mean("reference_cost"),
            "mean_coverage_per_cost": mean("coverage_per_cost"),
            "coverage_values": [row["coverage"] for row in rows],
            "duplicate_rate_values": [row["duplicate_rate"] for row in rows],
        }

    def run(self, config: FleetExperimentConfig) -> FleetExperimentReport:
        fleet_root = self.root / "fleet-runs"
        if fleet_root.exists():
            shutil.rmtree(fleet_root)
        workers_by_condition = _condition_workers()
        trial_rows: dict[str, list[dict[str, float]]] = {
            name: [] for name in workers_by_condition
        }
        for trial in range(config.trials):
            for condition, workers in workers_by_condition.items():
                trial_rows[condition].append(self._run_trial(condition, workers, config, trial))

        conditions = {name: self._aggregate(rows, config) for name, rows in trial_rows.items()}
        balanced = trial_rows["homogeneous_balanced"]
        biased = trial_rows["homogeneous_biased"]
        hetero = trial_rows["heterogeneous_complementary"]
        primary_deltas = [
            h["coverage"] - b["coverage"] for h, b in zip(hetero, balanced, strict=True)
        ]
        stress_deltas = [
            h["coverage"] - b["coverage"] for h, b in zip(hetero, biased, strict=True)
        ]
        ci_low, ci_high = _normal_ci(primary_deltas)
        wins = sum(delta > 0 for delta in primary_deltas)
        ties = sum(delta == 0 for delta in primary_deltas)
        losses = sum(delta < 0 for delta in primary_deltas)
        label_exact = float(
            conditions["label_only_control"] == conditions["homogeneous_balanced"]
        )
        return FleetExperimentReport(
            experiment_id=_experiment_id(config),
            conditions=conditions,
            paired={
                "heterogeneous_vs_balanced_mean_coverage_delta": statistics.mean(primary_deltas),
                "heterogeneous_vs_balanced_ci95_low": ci_low,
                "heterogeneous_vs_balanced_ci95_high": ci_high,
                "heterogeneous_vs_balanced_wins": float(wins),
                "heterogeneous_vs_balanced_ties": float(ties),
                "heterogeneous_vs_balanced_losses": float(losses),
                "heterogeneous_vs_biased_coverage_delta": statistics.mean(stress_deltas),
            },
            controls={
                "label_only_exact_match": label_exact,
                "matched_candidate_budget": 1.0,
                "matched_reference_cost": float(
                    len({metrics["mean_reference_cost"] for metrics in conditions.values()}) == 1
                ),
                "matched_valid_admission_rate": float(
                    len({metrics["mean_valid_admission_rate"] for metrics in conditions.values()}) == 1
                ),
                "oracle_enumeration_coverage": 1.0,
            },
            metadata={
                "runtime_version": "0.8.2",
                "evidence_level": "SYNTHETIC_MUTATION_PRIOR_FLEET",
                "independent_cross_model_evidence": False,
                "real_world_fleet_claim": False,
                "worker_count": config.worker_count,
                "candidate_budget_per_trial": config.candidate_budget,
                "trial_count": config.trials,
                "reference_cost_per_candidate": self.REFERENCE_COST_PER_CANDIDATE,
                "descriptor_id": self.schema.descriptor_id,
                "descriptor_version": self.schema.version,
                "prior_order": ["style", "composition", "camera"],
                "priors": {
                    condition: [list(worker.prior.probabilities) for worker in workers]
                    for condition, workers in workers_by_condition.items()
                },
                "candidate_validation": "render-observe-extract-reconstruct-evaluate-certificate",
                "parent_policy": "deterministic-current-qd-elite",
                "condition_name_in_rng": False,
                "oracle_information_access": "direct-27-niche-enumeration",
                "oracle_is_matched_fleet_condition": False,
            },
        )
