from __future__ import annotations

from .corpus import (
    _CONDITIONS,
    _CONSEQUENCES,
    _EPISTEMIC,
    _NEG,
    _OBJECTS,
    _RELATIONS,
    _STYLES,
    _SUBJECTS,
)
from .text_semantics import TextSemantics

_ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz"


def _encode_value(value, values: tuple) -> str:
    index = values.index(value)
    if index >= len(_ALPHABET):
        raise ValueError("reference codebook exceeds one-symbol capacity")
    return _ALPHABET[index]


def _decode_value(symbol: str, values: tuple):
    if len(symbol) != 1 or symbol not in _ALPHABET:
        raise ValueError("invalid compact seed symbol")
    index = _ALPHABET.index(symbol)
    if index >= len(values):
        raise ValueError("compact seed symbol outside codebook")
    return values[index]


def encode_compact(semantics: TextSemantics) -> str:
    """Encode the deterministic fixture grammar into eight shared-codebook symbols.

    The first seven symbols are reconstruction-critical. The eighth carries style.
    This is intentionally fixture-specific and decoder-relative.
    """

    return "".join(
        (
            _encode_value(semantics.subject, _SUBJECTS),
            _encode_value(semantics.epistemic, _EPISTEMIC),
            _encode_value(semantics.relation, _RELATIONS),
            _encode_value(semantics.object, _OBJECTS),
            _encode_value(semantics.condition, _CONDITIONS),
            _encode_value(semantics.negated_implication, _NEG),
            _encode_value(semantics.consequence, _CONSEQUENCES),
            _encode_value(semantics.style, _STYLES),
        )
    )


def decode_compact(payload: str) -> TextSemantics:
    if len(payload) < 7:
        raise ValueError("incomplete compact seed: seven semantic symbols required")
    if len(payload) > 8:
        raise ValueError("invalid compact seed length")
    return TextSemantics(
        subject=_decode_value(payload[0], _SUBJECTS),
        epistemic=_decode_value(payload[1], _EPISTEMIC),
        relation=_decode_value(payload[2], _RELATIONS),
        object=_decode_value(payload[3], _OBJECTS),
        condition=_decode_value(payload[4], _CONDITIONS),
        negated_implication=_decode_value(payload[5], _NEG),
        consequence=_decode_value(payload[6], _CONSEQUENCES),
        style=_decode_value(payload[7], _STYLES) if len(payload) == 8 else "neutral",
    )
