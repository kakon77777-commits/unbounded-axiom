from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .models import BudgetSweepReport, CompositionExperimentReport, CrossDecoderReport, ExperimentReport, FactorExperimentReport, LibraryExperimentReport, NavigationExperimentReport
from .qd_experiment import QDExperimentReport
from .fleet_experiment import FleetExperimentReport


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def export_bundle(report: ExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.1.0",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "seed_count": report.seed_count,
        "evidence_level": report.metadata.get("evidence_level"),
        "source_visibility_violations": report.source_visibility_violations,
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(
            f"{_sha256(path)}  {path.name}\n"
            for path in (manifest_path, report_path)
        ),
        encoding="utf-8",
    )
    return root

def export_budget_bundle(report: BudgetSweepReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.2.0",
        "sweep_id": report.sweep_id,
        "artifact_count": report.artifact_count,
        "budgets": list(report.budgets),
        "families": list(report.families),
        "evidence_level": report.metadata.get("evidence_level"),
        "control_budget_bytes": report.control_budget_bytes,
        "source_visibility_violations": report.source_visibility_violations,
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(
            f"{_sha256(path)}  {path.name}\n"
            for path in (manifest_path, report_path)
        ),
        encoding="utf-8",
    )
    return root

def export_cross_decoder_bundle(report: CrossDecoderReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.3.0",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "families": list(report.families),
        "decoders": list(report.decoders),
        "evidence_level": report.metadata.get("evidence_level"),
        "independent_cross_model_claim": report.metadata.get("independent_cross_model_claim"),
        "source_visibility_violations": report.source_visibility_violations,
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(
            f"{_sha256(path)}  {path.name}\n"
            for path in (manifest_path, report_path)
        ),
        encoding="utf-8",
    )
    return root



def export_image_bundle(report: ExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.4.0",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "seed_count": report.seed_count,
        "modality": "image",
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_image_claim": report.metadata.get("real_world_image_claim"),
        "source_input": report.metadata.get("source_input"),
        "source_visibility_violations": report.source_visibility_violations,
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root


def export_factor_bundle(report: FactorExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.5.0",
        "experiment": "factorization_ablation",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "factor_count": report.factor_count,
        "modality": "image",
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_disentanglement_claim": report.metadata.get("real_world_disentanglement_claim"),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root


def export_library_bundle(report: LibraryExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.6.0",
        "experiment": "seed_library_reuse",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "library_seed_count": report.library_seed_count,
        "task_count": report.task_count,
        "library_snapshot": report.library_snapshot,
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_reuse_claim": report.metadata.get("real_world_reuse_claim"),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root


def export_composition_bundle(report: CompositionExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.7.0",
        "experiment": "composition_mutation",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "initial_library_seed_count": report.initial_library_seed_count,
        "task_count": report.task_count,
        "promoted_seed_count": report.promoted_seed_count,
        "new_seed_count": report.new_seed_count,
        "existing_state_hit_count": report.existing_state_hit_count,
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_composition_claim": report.metadata.get("real_world_composition_claim"),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root


def export_navigation_bundle(report: NavigationExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.8.0",
        "experiment": "seed_space_navigation",
        "experiment_id": report.experiment_id,
        "artifact_count": report.artifact_count,
        "initial_library_seed_count": report.initial_library_seed_count,
        "task_count": report.task_count,
        "goal_distance_counts": report.goal_distance_counts,
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_navigation_claim": report.metadata.get("real_world_navigation_claim"),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root

def export_qd_bundle(report: QDExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.8.1",
        "experiment": "quality_diversity_archive",
        "experiment_id": report.experiment_id,
        "initial_library_seed_count": report.initial_library_seed_count,
        "candidate_budget": report.candidate_budget,
        "validated_candidate_count": report.validated_candidate_count,
        "descriptor_id": report.metadata.get("descriptor_id"),
        "descriptor_version": report.metadata.get("descriptor_version"),
        "filled_niches": report.qd_archive.get("filled_niches"),
        "coverage": report.qd_archive.get("coverage"),
        "qd_score": report.qd_archive.get("qd_score"),
        "mean_novelty": report.qd_archive.get("mean_novelty"),
        "evidence_level": report.metadata.get("evidence_level"),
        "real_world_qd_claim": report.metadata.get("real_world_qd_claim"),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root


def export_fleet_bundle(report: FleetExperimentReport, destination: str | Path) -> Path:
    root = Path(destination)
    root.mkdir(parents=True, exist_ok=True)

    report_path = root / "report.json"
    report_path.write_text(
        json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    manifest = {
        "bundle_version": "0.8.2",
        "experiment": "heterogeneous_mutation_fleet",
        "experiment_id": report.experiment_id,
        "trial_count": report.metadata.get("trial_count"),
        "candidate_budget_per_trial": report.metadata.get("candidate_budget_per_trial"),
        "worker_count": report.metadata.get("worker_count"),
        "evidence_level": report.metadata.get("evidence_level"),
        "heterogeneous_vs_balanced_mean_coverage_delta": report.paired.get(
            "heterogeneous_vs_balanced_mean_coverage_delta"
        ),
        "heterogeneous_vs_biased_coverage_delta": report.paired.get(
            "heterogeneous_vs_biased_coverage_delta"
        ),
    }
    manifest_path = root / "manifest.json"
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    checksum_path = root / "CHECKSUMS.sha256"
    checksum_path.write_text(
        "".join(f"{_sha256(path)}  {path.name}\n" for path in (manifest_path, report_path)),
        encoding="utf-8",
    )
    return root
