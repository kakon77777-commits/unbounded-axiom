from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

from .certificates import CertificateIssuer
from .db import RuntimeDB
from .dependencies import DependencyAuditor, DependencyPolicy
from .image_controls import make_image_controls
from .image_corpus import generate_reference_image_corpus
from .image_evaluation import ImageFidelityEvaluator
from .image_extraction import ReferenceImageSeedExtractor
from .image_reconstruction import ReferenceImageReconstructor
from .models import ExperimentReport, SeedCandidate
from .store import ArtifactStore


DEFAULT_IMAGE_FAMILIES = (
    "visual_description",
    "visual_partial",
    "visual_structured",
    "visual_compact",
)

_SCORE_NAMES = (
    "subject",
    "identity",
    "composition",
    "spatial",
    "camera",
    "lighting",
    "palette",
    "style",
    "pixel_similarity",
    "pixel_exact",
    "semantic_overall",
    "overall",
)


@dataclass(frozen=True)
class ImageExperimentConfig:
    count: int = 96
    budget_bytes: int = 512
    repetitions: int = 2
    families: tuple[str, ...] = DEFAULT_IMAGE_FAMILIES
    min_success_probability: float = 1.0
    include_controls: bool = True


def _experiment_id(config: ImageExperimentConfig) -> str:
    material = json.dumps(
        {
            "count": config.count,
            "budget_bytes": config.budget_bytes,
            "repetitions": config.repetitions,
            "families": config.families,
            "min_success_probability": config.min_success_probability,
            "include_controls": config.include_controls,
        },
        sort_keys=True,
        default=list,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


class ImageExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = ArtifactStore(self.root / "artifacts")
        self.outputs = ArtifactStore(self.root / "reconstructions")
        self.db = RuntimeDB(self.root / "runtime.sqlite3")
        self.extractor = ReferenceImageSeedExtractor(self.artifacts.read_bytes)
        self.reconstructor = ReferenceImageReconstructor(self.outputs)
        self.evaluator = ImageFidelityEvaluator(self.outputs.read_bytes)
        self.auditor = DependencyAuditor()

    @staticmethod
    def _edge_id(source: str, target: str, operation: str) -> str:
        return "sha256:" + hashlib.sha256(f"{source}:{target}:{operation}".encode("utf-8")).hexdigest()

    def run(self, config: ImageExperimentConfig) -> ExperimentReport:
        if config.count < 1:
            raise ValueError("count must be positive")
        if config.repetitions < 1:
            raise ValueError("repetitions must be positive")
        if config.budget_bytes < 1:
            raise ValueError("budget_bytes must be positive")
        unknown = [family for family in config.families if family not in ReferenceImageSeedExtractor.FAMILIES]
        if unknown:
            raise ValueError(f"unknown image seed family: {unknown[0]}")
        if config.include_controls and "visual_structured" not in config.families:
            raise ValueError("image controls require visual_structured family")
        if config.include_controls and config.count < 2:
            raise ValueError("image controls require at least two artifacts")

        corpus = generate_reference_image_corpus(config.count)
        records = []
        semantics_by_artifact = {}
        source_bytes_by_artifact = {}
        for item in corpus:
            record = self.artifacts.ingest_bytes(item.png_bytes, "image", item.metadata)
            self.db.record_artifact(record)
            records.append(record)
            semantics_by_artifact[record.artifact_id] = item.semantics
            source_bytes_by_artifact[record.artifact_id] = item.png_bytes

        seeds_by_artifact: dict[str, dict[str, SeedCandidate]] = {}
        for record in records:
            by_family: dict[str, SeedCandidate] = {}
            with self.db.batch():
                for family in config.families:
                    seed = self.extractor.extract(record, family, config.budget_bytes)
                    self.db.record_seed_candidate(seed)
                    self.db.record_lineage_edge(
                        self._edge_id(record.artifact_id, seed.seed_id, "extracted_from"),
                        record.artifact_id,
                        seed.seed_id,
                        "extracted_from",
                        {"family": family, "experiment": "image-reconstruction:v0.4"},
                    )
                    by_family[family] = seed
            seeds_by_artifact[record.artifact_id] = by_family

        family_totals = {
            family: {
                "total": 0,
                "passed": 0,
                "payload_bytes": 0,
                "adjusted_cost_bytes": 0,
                "evaluation_runs": 0,
                "score_sums": {name: 0.0 for name in _SCORE_NAMES},
            }
            for family in config.families
        }
        control_names = ("random", "wrong_identity", "spatial_flip", "style_swap", "unrelated")
        control_totals = {name: {"total": 0, "passed": 0} for name in control_names}
        visibility_violations = 0
        certificate_passed = 0
        certificate_total = 0
        issuer = CertificateIssuer(config.min_success_probability)

        for record in records:
            source_png = source_bytes_by_artifact[record.artifact_id]
            source_semantics = semantics_by_artifact[record.artifact_id]
            with self.db.batch():
                for family, seed in seeds_by_artifact[record.artifact_id].items():
                    audit = self.auditor.audit(seed, DependencyPolicy.strict())
                    totals = family_totals[family]
                    totals["payload_bytes"] += seed.payload_bytes
                    totals["adjusted_cost_bytes"] += audit.adjusted_cost_bytes
                    evaluations = []
                    for run_index in range(config.repetitions):
                        result = self.reconstructor.reconstruct(seed, run_index)
                        self.db.record_reconstruction_run(result)
                        visibility_violations += int(result.source_visible_to_decoder)
                        evaluation = self.evaluator.evaluate(source_semantics, source_png, result)
                        self.db.record_evaluation(evaluation)
                        evaluations.append(evaluation)
                        totals["evaluation_runs"] += 1
                        for score_name in _SCORE_NAMES:
                            totals["score_sums"][score_name] += evaluation.scores[score_name]
                    certificate = issuer.issue(seed, audit, evaluations, self.reconstructor.generator_id)
                    self.db.record_certificate(certificate)
                    totals["total"] += 1
                    totals["passed"] += int(certificate.passed)
                    certificate_total += 1
                    certificate_passed += int(certificate.passed)

        if config.include_controls:
            for index, record in enumerate(records):
                source_png = source_bytes_by_artifact[record.artifact_id]
                source_semantics = semantics_by_artifact[record.artifact_id]
                other = records[(index + 1) % len(records)]
                base = seeds_by_artifact[record.artifact_id]["visual_structured"]
                unrelated = seeds_by_artifact[other.artifact_id]["visual_structured"]
                controls = make_image_controls(base, unrelated)
                with self.db.batch():
                    for name, control in controls.items():
                        self.db.record_seed_candidate(control)
                        for run_index in range(config.repetitions):
                            result = self.reconstructor.reconstruct(control, run_index)
                            self.db.record_reconstruction_run(result)
                            visibility_violations += int(result.source_visible_to_decoder)
                            evaluation = self.evaluator.evaluate(source_semantics, source_png, result)
                            self.db.record_evaluation(evaluation)
                            control_totals[name]["total"] += 1
                            control_totals[name]["passed"] += int(evaluation.passed)

        family_stats: dict[str, dict[str, float]] = {}
        for family, values in family_totals.items():
            total = int(values["total"])
            runs = int(values["evaluation_runs"])
            stats = {
                "total": float(total),
                "passed": float(values["passed"]),
                "pass_rate": values["passed"] / total if total else 0.0,
                "mean_payload_bytes": values["payload_bytes"] / total if total else 0.0,
                "mean_adjusted_cost_bytes": values["adjusted_cost_bytes"] / total if total else 0.0,
                "evaluation_runs": float(runs),
            }
            for score_name in _SCORE_NAMES:
                stats[f"mean_{score_name}"] = values["score_sums"][score_name] / runs if runs else 0.0
            family_stats[family] = stats

        control_stats = {
            name: {
                "total": float(values["total"]),
                "passed": float(values["passed"]),
                "pass_rate": values["passed"] / values["total"] if values["total"] else 0.0,
            }
            for name, values in control_totals.items()
        }

        return ExperimentReport(
            experiment_id=_experiment_id(config),
            artifact_count=len(records),
            seed_count=len(records) * len(config.families),
            family_stats=family_stats,
            control_stats=control_stats,
            source_visibility_violations=visibility_violations,
            certificate_passed=certificate_passed,
            certificate_total=certificate_total,
            metadata={
                "runtime_version": "0.4.0",
                "modality": "image",
                "evidence_level": "SYNTHETIC_VISUAL_GRAMMAR",
                "real_world_image_claim": False,
                "source_input": "finished_png_bytes_only",
                "source_metadata_visible_to_extractor": False,
                "source_visible_to_decoder": False,
                "budget_bytes": config.budget_bytes,
                "repetitions": config.repetitions,
                "families": list(config.families),
                "visual_factors": [
                    "subject",
                    "identity",
                    "composition",
                    "spatial",
                    "camera",
                    "lighting",
                    "palette",
                    "style",
                ],
            },
        )
