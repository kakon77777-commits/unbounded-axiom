from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .db import RuntimeDB
from .image_extraction import decode_visual_compact
from .image_semantics import analyze_reference_image
from .models import ArtifactRecord, SeedCandidate, ValidationCertificate
from .store import ArtifactStore


class SeedLibrary:
    """Persistent validated generative memory for the v0.6 reference runtime.

    This store is deliberately distinct from candidate evidence. Promotion requires
    an already-passing reconstruction certificate and re-observes the finished
    artifact so hidden fixture semantics never become library authority.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = ArtifactStore(self.root / "artifacts")
        self.outputs = ArtifactStore(self.root / "reconstructions")
        self.db = RuntimeDB(self.root / "runtime.sqlite3")

    @staticmethod
    def _hash_event(kind: str, *parts: str) -> str:
        material = json.dumps([kind, *parts], separators=(",", ":")).encode("utf-8")
        return "sha256:" + hashlib.sha256(material).hexdigest()

    def promote_image_seed(
        self,
        artifact: ArtifactRecord,
        seed: SeedCandidate,
        certificate: ValidationCertificate,
    ) -> dict[str, Any]:
        if artifact.modality != "image":
            raise ValueError("image promotion requires image artifact")
        if seed.artifact_id != artifact.artifact_id:
            raise ValueError("seed artifact mismatch")
        if seed.family != "visual_compact":
            raise ValueError("v0.6 reusable image library requires visual_compact seed")
        if certificate.seed_id != seed.seed_id:
            raise ValueError("certificate seed mismatch")
        if not certificate.passed:
            raise ValueError("promotion requires passing certificate")

        source_png = self.artifacts.read_bytes(artifact.artifact_id)
        observed = analyze_reference_image(source_png)
        decoded = decode_visual_compact(seed.payload)
        if decoded != observed:
            raise ValueError("seed payload does not match observed finished artifact")

        payload_hash = hashlib.sha256(seed.payload.encode("utf-8")).hexdigest()
        record: dict[str, Any] = {
            "seed_id": seed.seed_id,
            "artifact_id": artifact.artifact_id,
            "modality": "image",
            "family": seed.family,
            "payload": seed.payload,
            "payload_hash": payload_hash,
            "status": "REUSABLE",
            "certificate_id": certificate.certificate_id,
            "freshness_key": certificate.generator_scope,
            "metadata": {
                "promotion": "validated-retrospective-image:v0.6",
                "source_authority": "artifact-store",
                "factor_source": "finished-png-observation",
                "certificate_success_probability": certificate.success_probability,
            },
        }
        with self.db.batch():
            self.db.record_artifact(artifact)
            self.db.record_validated_seed(record)
            for factor_name in (
                "subject",
                "identity",
                "composition",
                "spatial",
                "camera",
                "lighting",
                "palette",
                "style",
            ):
                self.db.record_seed_factor(seed.seed_id, factor_name, getattr(observed, factor_name))
            self.db.record_library_event(
                {
                    "event_id": self._hash_event("PROMOTED", seed.seed_id, certificate.certificate_id),
                    "subject_id": seed.seed_id,
                    "event_type": "PROMOTED",
                    "metadata": {"certificate_id": certificate.certificate_id},
                }
            )
        return record

    def records(self, *, include_stale: bool = False) -> list[dict[str, Any]]:
        statuses = () if include_stale else ("VALIDATED", "REUSABLE", "PORTABLE")
        return self.db.query_validated_seeds(
            {},
            allowed_statuses=statuses,
            require_certificate=False,
        )

    def snapshot_digest(self) -> str:
        payload: list[dict[str, Any]] = []
        for record in self.records(include_stale=True):
            payload.append(
                {
                    "seed": record,
                    "factors": self.db.get_seed_factors(record["seed_id"]),
                }
            )
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def mark_stale(self, seed_id: str, *, reason: str) -> dict[str, Any]:
        record = self.db.get_validated_seed(seed_id)
        if record is None:
            raise KeyError(seed_id)
        updated = dict(record)
        updated["status"] = "STALE"
        metadata = dict(updated.get("metadata", {}))
        metadata["stale_reason"] = reason
        updated["metadata"] = metadata
        with self.db.batch():
            self.db.record_validated_seed(updated)
            self.db.record_library_event(
                {
                    "event_id": self._hash_event("STALE", seed_id, reason),
                    "subject_id": seed_id,
                    "event_type": "STALE",
                    "metadata": {"reason": reason},
                }
            )
        return updated

    def record_failure(
        self,
        *,
        query_id: str,
        failure_class: str,
        seed_id: str | None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        metadata = metadata or {}
        failure_id = self._hash_event(
            "FAILURE",
            query_id,
            seed_id or "",
            failure_class,
            json.dumps(metadata, sort_keys=True, ensure_ascii=False, separators=(",", ":")),
        )
        record = {
            "failure_id": failure_id,
            "seed_id": seed_id,
            "query_id": query_id,
            "failure_class": failure_class,
            "metadata": metadata,
        }
        self.db.record_library_failure(record)
        return record
