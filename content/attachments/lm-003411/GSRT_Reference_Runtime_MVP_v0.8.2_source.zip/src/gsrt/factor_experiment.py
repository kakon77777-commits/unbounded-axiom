from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

from .image_corpus import generate_reference_image_corpus
from .image_factor_interactions import pixel_interaction_matrix, semantic_coupling_matrix
from .image_factors import (
    FACTOR_SPECS,
    ablate_factor,
    round_trip_factor,
    transplant_factor,
    transplant_metrics,
)
from .image_semantics import ImageSemantics, analyze_reference_image, render_reference_image
from .models import FactorExperimentReport
from .png_codec import decode_rgb_png
from .store import ArtifactStore


@dataclass(frozen=True)
class FactorExperimentConfig:
    count: int = 96


def _experiment_id(config: FactorExperimentConfig) -> str:
    material = json.dumps(
        {"count": config.count, "experiment": "factorization-ablation:v0.5"},
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


def _pixel_metrics(source_png: bytes, output_png: bytes) -> tuple[float, float]:
    sw, sh, sp = decode_rgb_png(source_png)
    ow, oh, op = decode_rgb_png(output_png)
    if (sw, sh) != (ow, oh) or len(sp) != len(op):
        return 0.0, 0.0
    distance = sum(abs(a - b) for a, b in zip(sp, op, strict=True))
    similarity = 1.0 - distance / (255 * len(sp))
    return similarity, float(sp == op)


def _donor_for(states: list[ImageSemantics], index: int, factor_name: str) -> ImageSemantics:
    recipient_value = getattr(states[index], factor_name)
    for offset in range(1, len(states)):
        donor = states[(index + offset) % len(states)]
        if getattr(donor, factor_name) != recipient_value:
            return donor
    raise ValueError(f"corpus has no distinct donor for factor: {factor_name}")


class FactorExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.artifacts = ArtifactStore(self.root / "artifacts")

    def run(self, config: FactorExperimentConfig) -> FactorExperimentReport:
        if config.count < 2:
            raise ValueError("factor experiment requires at least two artifacts")
        corpus = generate_reference_image_corpus(config.count)

        source_pngs: list[bytes] = []
        states: list[ImageSemantics] = []
        for item in corpus:
            record = self.artifacts.ingest_bytes(
                item.png_bytes,
                "image",
                {"grammar": "gsrt-reference-visual-v0.5", "source_role": "finished_artifact"},
            )
            source_png = self.artifacts.read_bytes(record.artifact_id)
            source_pngs.append(source_png)
            states.append(analyze_reference_image(source_png))

        ablation_raw = {
            name: {
                "eligible": 0,
                "target_lost": 0,
                "protected_sum": 0.0,
                "pixel_exact": 0,
                "pixel_similarity_sum": 0.0,
            }
            for name in FACTOR_SPECS
        }
        transplant_raw = {
            name: {
                "tested": 0,
                "transfer_sum": 0.0,
                "preservation_sum": 0.0,
                "leakage_sum": 0.0,
                "normalized_locality_sum": 0.0,
                "locality_ratio_sum": 0.0,
                "repair_cost_sum": 0.0,
                "portable": 0,
                "round_trip_semantic": 0,
                "round_trip_pixel": 0,
            }
            for name in FACTOR_SPECS
        }
        semantic_sum = {
            changed: {observed: 0.0 for observed in FACTOR_SPECS}
            for changed in FACTOR_SPECS
        }
        pixel_sum = {
            first: {second: 0.0 for second in FACTOR_SPECS}
            for first in FACTOR_SPECS
        }
        pixel_max = {
            first: {second: 0.0 for second in FACTOR_SPECS}
            for first in FACTOR_SPECS
        }

        for index, (source_png, source) in enumerate(zip(source_pngs, states, strict=True)):
            for factor_name, spec in FACTOR_SPECS.items():
                if getattr(source, factor_name) != spec.default:
                    output_png = render_reference_image(ablate_factor(source, factor_name))
                    observed = analyze_reference_image(output_png)
                    protected = [name for name in FACTOR_SPECS if name != factor_name]
                    protected_preservation = sum(
                        getattr(observed, name) == getattr(source, name) for name in protected
                    ) / len(protected)
                    similarity, exact = _pixel_metrics(source_png, output_png)
                    raw = ablation_raw[factor_name]
                    raw["eligible"] += 1
                    raw["target_lost"] += int(
                        getattr(observed, factor_name) != getattr(source, factor_name)
                    )
                    raw["protected_sum"] += protected_preservation
                    raw["pixel_exact"] += int(exact)
                    raw["pixel_similarity_sum"] += similarity

                donor = _donor_for(states, index, factor_name)
                hybrid = transplant_factor(source, donor, factor_name)
                hybrid_observed = analyze_reference_image(render_reference_image(hybrid))
                metrics = transplant_metrics(source, donor, hybrid_observed, factor_name)
                _, restored = round_trip_factor(source, donor, factor_name)
                restored_png = render_reference_image(restored)
                restored_observed = analyze_reference_image(restored_png)
                raw_t = transplant_raw[factor_name]
                raw_t["tested"] += 1
                raw_t["transfer_sum"] += metrics["target_transfer"]
                raw_t["preservation_sum"] += metrics["protected_preservation"]
                raw_t["leakage_sum"] += metrics["preservation_leakage"]
                raw_t["normalized_locality_sum"] += metrics["normalized_locality"]
                raw_t["locality_ratio_sum"] += metrics["locality_ratio"]
                raw_t["repair_cost_sum"] += metrics["repair_cost"]
                raw_t["portable"] += int(
                    metrics["target_transfer"] == 1.0
                    and metrics["protected_preservation"] == 1.0
                )
                raw_t["round_trip_semantic"] += int(restored_observed == source)
                raw_t["round_trip_pixel"] += int(_pixel_metrics(source_png, restored_png)[1])

            semantic = semantic_coupling_matrix(source)
            pixel = pixel_interaction_matrix(source)
            for first in FACTOR_SPECS:
                for second in FACTOR_SPECS:
                    semantic_sum[first][second] += semantic[first][second]
                    pixel_sum[first][second] += pixel[first][second]
                    pixel_max[first][second] = max(pixel_max[first][second], pixel[first][second])

        ablation_stats: dict[str, dict[str, float]] = {}
        for factor_name, raw in ablation_raw.items():
            eligible = int(raw["eligible"])
            ablation_stats[factor_name] = {
                "eligible": float(eligible),
                "necessity_rate": raw["target_lost"] / eligible if eligible else 0.0,
                "mean_protected_preservation": raw["protected_sum"] / eligible if eligible else 0.0,
                "pixel_exact_rate": raw["pixel_exact"] / eligible if eligible else 0.0,
                "mean_pixel_similarity": raw["pixel_similarity_sum"] / eligible if eligible else 0.0,
                "default_value": FACTOR_SPECS[factor_name].default,
            }

        transplant_stats: dict[str, dict[str, float]] = {}
        for factor_name, raw in transplant_raw.items():
            tested = int(raw["tested"])
            transplant_stats[factor_name] = {
                "tested": float(tested),
                "target_transfer": raw["transfer_sum"] / tested if tested else 0.0,
                "protected_preservation": raw["preservation_sum"] / tested if tested else 0.0,
                "preservation_leakage": raw["leakage_sum"] / tested if tested else 0.0,
                "normalized_locality": raw["normalized_locality_sum"] / tested if tested else 0.0,
                "mean_locality_ratio": raw["locality_ratio_sum"] / tested if tested else 0.0,
                "portability": raw["portable"] / tested if tested else 0.0,
                "round_trip_semantic_exact": raw["round_trip_semantic"] / tested if tested else 0.0,
                "round_trip_pixel_exact": raw["round_trip_pixel"] / tested if tested else 0.0,
                "mean_repair_cost": raw["repair_cost_sum"] / tested if tested else 0.0,
            }

        semantic_average = {
            first: {second: semantic_sum[first][second] / config.count for second in FACTOR_SPECS}
            for first in FACTOR_SPECS
        }
        pixel_average = {
            first: {second: pixel_sum[first][second] / config.count for second in FACTOR_SPECS}
            for first in FACTOR_SPECS
        }
        strongest: list[dict[str, object]] = []
        for first, second in combinations(FACTOR_SPECS, 2):
            strongest.append(
                {
                    "factor_a": first,
                    "factor_b": second,
                    "mean_residual": pixel_average[first][second],
                    "max_residual": pixel_max[first][second],
                }
            )
        strongest.sort(key=lambda row: (float(row["mean_residual"]), str(row["factor_a"]), str(row["factor_b"])), reverse=True)

        return FactorExperimentReport(
            experiment_id=_experiment_id(config),
            artifact_count=config.count,
            factor_count=len(FACTOR_SPECS),
            ablation_stats=ablation_stats,
            transplant_stats=transplant_stats,
            semantic_coupling_matrix=semantic_average,
            pixel_interaction_matrix=pixel_average,
            strongest_pixel_interactions=strongest,
            metadata={
                "runtime_version": "0.5.0",
                "modality": "image",
                "evidence_level": "SYNTHETIC_VISUAL_GRAMMAR",
                "real_world_disentanglement_claim": False,
                "ablation_mode": "default_substitution",
                "source_input": "finished_png_bytes_only",
                "source_semantics_visible_to_factorizer": False,
                "factor_names": list(FACTOR_SPECS),
                "factor_definition": "reusable_intervention_boundary_candidate",
                "semantic_and_render_interaction_separated": True,
                "compatibility_domain": "full_cartesian_reference_visual_grammar",
                "repair_policy": "no_repair_needed_for_valid_reference_factor_transplants",
                "pixel_interaction_residual_definition": "mismatch_between_pair_change_mask_and_union_of_single_change_masks_normalized_by_union_size",
                "pixel_interaction_residual_bounded_to_unit_interval": False,
                "operation_counts": {
                    "ablation_eligible": int(sum(row["eligible"] for row in ablation_raw.values())),
                    "transplants": config.count * len(FACTOR_SPECS),
                    "round_trips": config.count * len(FACTOR_SPECS),
                    "semantic_single_interventions": config.count * len(FACTOR_SPECS),
                    "pixel_pair_interactions": config.count * len(strongest),
                },
            },
        )
