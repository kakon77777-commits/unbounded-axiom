from __future__ import annotations

import struct
import zlib

_PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


def _chunk(kind: bytes, payload: bytes) -> bytes:
    crc = zlib.crc32(kind)
    crc = zlib.crc32(payload, crc) & 0xFFFFFFFF
    return struct.pack(">I", len(payload)) + kind + payload + struct.pack(">I", crc)


def encode_rgb_png(width: int, height: int, pixels: bytes) -> bytes:
    if width <= 0 or height <= 0:
        raise ValueError("width and height must be positive")
    expected = width * height * 3
    if len(pixels) != expected:
        raise ValueError(f"pixel length must be {expected} bytes")
    if width > 4096 or height > 4096:
        raise ValueError("reference PNG dimensions exceed safety bound")

    rows = bytearray()
    stride = width * 3
    for y in range(height):
        rows.append(0)  # PNG filter type 0 (None)
        start = y * stride
        rows.extend(pixels[start : start + stride])

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return b"".join(
        (
            _PNG_SIGNATURE,
            _chunk(b"IHDR", ihdr),
            _chunk(b"IDAT", zlib.compress(bytes(rows), level=9)),
            _chunk(b"IEND", b""),
        )
    )


def decode_rgb_png(data: bytes) -> tuple[int, int, bytes]:
    if not data.startswith(_PNG_SIGNATURE):
        raise ValueError("invalid PNG signature")
    offset = len(_PNG_SIGNATURE)
    width = height = None
    idat_parts: list[bytes] = []
    saw_iend = False

    while offset < len(data):
        if offset + 12 > len(data):
            raise ValueError("truncated PNG chunk")
        length = struct.unpack(">I", data[offset : offset + 4])[0]
        offset += 4
        kind = data[offset : offset + 4]
        offset += 4
        if length > 64 * 1024 * 1024:
            raise ValueError("PNG chunk exceeds safety bound")
        if offset + length + 4 > len(data):
            raise ValueError("truncated PNG payload")
        payload = data[offset : offset + length]
        offset += length
        expected_crc = struct.unpack(">I", data[offset : offset + 4])[0]
        offset += 4
        crc = zlib.crc32(kind)
        crc = zlib.crc32(payload, crc) & 0xFFFFFFFF
        if crc != expected_crc:
            raise ValueError("PNG CRC mismatch")

        if kind == b"IHDR":
            if len(payload) != 13:
                raise ValueError("invalid IHDR length")
            width, height, bit_depth, color_type, compression, filter_method, interlace = struct.unpack(
                ">IIBBBBB", payload
            )
            if width <= 0 or height <= 0 or width > 4096 or height > 4096:
                raise ValueError("PNG dimensions outside reference bounds")
            if (bit_depth, color_type, compression, filter_method, interlace) != (8, 2, 0, 0, 0):
                raise ValueError("unsupported PNG profile")
        elif kind == b"IDAT":
            idat_parts.append(payload)
        elif kind == b"IEND":
            saw_iend = True
            break

    if width is None or height is None:
        raise ValueError("PNG missing IHDR")
    if not idat_parts:
        raise ValueError("PNG missing IDAT")
    if not saw_iend:
        raise ValueError("PNG missing IEND")

    try:
        raw = zlib.decompress(b"".join(idat_parts))
    except zlib.error as exc:
        raise ValueError("invalid PNG compressed data") from exc

    stride = width * 3
    expected_raw = height * (stride + 1)
    if len(raw) != expected_raw:
        raise ValueError("unexpected decompressed PNG size")
    pixels = bytearray()
    offset = 0
    for _ in range(height):
        filter_type = raw[offset]
        offset += 1
        if filter_type != 0:
            raise ValueError("reference decoder supports filter type 0 only")
        pixels.extend(raw[offset : offset + stride])
        offset += stride
    return width, height, bytes(pixels)
