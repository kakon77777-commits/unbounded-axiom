from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass

from .image_factors import FACTOR_SPECS, replace_factor
from .image_semantics import ImageSemantics

QD_DIMENSIONS = ("style", "composition", "camera")


def _unit_interval(material: str) -> float:
    digest = hashlib.sha256(material.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") / 2**64


def _index(material: str, size: int) -> int:
    if size < 1:
        raise ValueError("size must be positive")
    digest = hashlib.sha256(material.encode("utf-8")).digest()
    return int.from_bytes(digest[8:16], "big") % size


@dataclass(frozen=True)
class MutationPrior:
    name: str
    probabilities: tuple[float, float, float]

    def __post_init__(self) -> None:
        if len(self.probabilities) != len(QD_DIMENSIONS):
            raise ValueError("mutation prior must contain three descriptor probabilities")
        if any(value < 0.0 or value > 1.0 for value in self.probabilities):
            raise ValueError("mutation probabilities must be in [0, 1]")
        if not math.isclose(sum(self.probabilities), 1.0, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError("mutation probabilities must sum to one")


@dataclass(frozen=True)
class FleetWorker:
    worker_id: str
    prior: MutationPrior


@dataclass(frozen=True)
class MutationProposal:
    parent: ImageSemantics
    child: ImageSemantics
    factor: str
    old_value: str
    new_value: str
    worker_id: str
    prior_name: str


def _choose_factor(prior: MutationPrior, material: str) -> str:
    sample = _unit_interval(material)
    cumulative = 0.0
    for factor, probability in zip(QD_DIMENSIONS, prior.probabilities, strict=True):
        cumulative += probability
        if sample < cumulative:
            return factor
    return QD_DIMENSIONS[-1]


def mutate_descriptor(
    parent: ImageSemantics,
    worker: FleetWorker,
    *,
    worker_index: int,
    trial: int,
    attempt: int,
    experiment_seed: str,
) -> MutationProposal:
    if worker_index < 0 or trial < 0 or attempt < 0:
        raise ValueError("worker_index, trial, and attempt must be non-negative")
    # worker_id is intentionally excluded from sampling material. Renaming a worker
    # must not create fake diversity.
    base = f"{experiment_seed}:trial={trial}:attempt={attempt}:worker={worker_index}"
    factor = _choose_factor(worker.prior, base + ":factor")
    old_value = getattr(parent, factor)
    alternatives = tuple(value for value in FACTOR_SPECS[factor].allowed if value != old_value)
    new_value = alternatives[_index(base + f":value:{factor}:{old_value}", len(alternatives))]
    child = replace_factor(parent, factor, new_value)
    return MutationProposal(
        parent=parent,
        child=child,
        factor=factor,
        old_value=old_value,
        new_value=new_value,
        worker_id=worker.worker_id,
        prior_name=worker.prior.name,
    )
