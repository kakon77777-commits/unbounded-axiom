from __future__ import annotations

import argparse
import json
from pathlib import Path

from .budget import DEFAULT_BUDGETS, BudgetSweepConfig, BudgetSweepRunner
from .bundle import export_budget_bundle, export_bundle, export_composition_bundle, export_cross_decoder_bundle, export_factor_bundle, export_image_bundle, export_library_bundle, export_navigation_bundle, export_qd_bundle, export_fleet_bundle
from .composition_experiment import CompositionExperimentConfig, CompositionExperimentRunner
from .cross_decoder import CrossDecoderConfig, CrossDecoderRunner, DEFAULT_DECODERS, DEFAULT_FAMILIES
from .db import RuntimeDB
from .experiment import ExperimentConfig, ExperimentRunner
from .factor_experiment import FactorExperimentConfig, FactorExperimentRunner
from .image_experiment import ImageExperimentConfig, ImageExperimentRunner
from .library import SeedLibrary
from .library_experiment import LibraryExperimentConfig, LibraryExperimentRunner
from .navigation_experiment import NavigationExperimentConfig, NavigationExperimentRunner
from .qd_experiment import QDExperimentConfig, QDExperimentRunner
from .fleet_experiment import FleetExperimentConfig, FleetExperimentRunner


def _report_json(report) -> str:
    return json.dumps(report.to_dict(), ensure_ascii=False, sort_keys=True, indent=2)


def _run_corpus(args: argparse.Namespace) -> int:
    runner = ExperimentRunner(args.root)
    report = runner.run(
        ExperimentConfig(
            count=args.count,
            budget_bytes=args.budget_bytes,
            repetitions=args.repetitions,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_bundle(report, args.bundle)
    return 0




def _parse_budgets(value: str) -> tuple[int, ...]:
    try:
        budgets = tuple(int(part.strip()) for part in value.split(",") if part.strip())
    except ValueError as exc:
        raise argparse.ArgumentTypeError("budgets must be comma-separated integers") from exc
    if not budgets:
        raise argparse.ArgumentTypeError("budgets must not be empty")
    return budgets


def _parse_csv_strings(value: str) -> tuple[str, ...]:
    values = tuple(part.strip() for part in value.split(",") if part.strip())
    if not values:
        raise argparse.ArgumentTypeError("value must contain at least one comma-separated item")
    return values


def _run_cross_decoder(args: argparse.Namespace) -> int:
    runner = CrossDecoderRunner(args.root)
    report = runner.run(
        CrossDecoderConfig(
            count=args.count,
            repetitions=args.repetitions,
            families=args.families,
            decoders=args.decoders,
            budget_bytes=args.budget_bytes,
            include_controls=args.controls,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_cross_decoder_bundle(report, args.bundle)
    return 0


def _run_image(args: argparse.Namespace) -> int:
    runner = ImageExperimentRunner(args.root)
    report = runner.run(
        ImageExperimentConfig(
            count=args.count,
            budget_bytes=args.budget_bytes,
            repetitions=args.repetitions,
            include_controls=args.controls,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_image_bundle(report, args.bundle)
    return 0



def _run_factor(args: argparse.Namespace) -> int:
    runner = FactorExperimentRunner(args.root)
    report = runner.run(FactorExperimentConfig(count=args.count))
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_factor_bundle(report, args.bundle)
    return 0

def _run_library(args: argparse.Namespace) -> int:
    runner = LibraryExperimentRunner(args.root)
    report = runner.run(
        LibraryExperimentConfig(
            count=args.count,
            tasks_per_specificity=args.tasks_per_specificity,
            max_fresh_attempts=args.max_fresh_attempts,
            repetitions=args.repetitions,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_library_bundle(report, args.bundle)
    return 0


def _run_composition(args: argparse.Namespace) -> int:
    runner = CompositionExperimentRunner(args.root)
    report = runner.run(
        CompositionExperimentConfig(
            count=args.count,
            tasks_per_specificity=args.tasks_per_specificity,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_composition_bundle(report, args.bundle)
    return 0


def _run_navigation(args: argparse.Namespace) -> int:
    runner = NavigationExperimentRunner(args.root)
    report = runner.run(
        NavigationExperimentConfig(
            count=args.count,
            tasks_per_distance=args.tasks_per_distance,
            max_fresh_attempts=args.max_fresh_attempts,
            max_navigation_steps=args.max_navigation_steps,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_navigation_bundle(report, args.bundle)
    return 0


def _run_qd(args: argparse.Namespace) -> int:
    runner = QDExperimentRunner(args.root)
    report = runner.run(
        QDExperimentConfig(
            initial_count=args.initial_count,
            candidate_budget=args.candidate_budget,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_qd_bundle(report, args.bundle)
    return 0


def _run_fleet(args: argparse.Namespace) -> int:
    runner = FleetExperimentRunner(args.root)
    report = runner.run(
        FleetExperimentConfig(
            trials=args.trials,
            candidate_budget=args.candidate_budget,
            experiment_seed=args.experiment_seed,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_fleet_bundle(report, args.bundle)
    return 0


def _inspect_library(args: argparse.Namespace) -> int:
    library = SeedLibrary(args.root)
    payload = {
        "reusable_seed_count": len(library.records()),
        "factor_count": library.db.count("seed_factors"),
        "candidate_seed_count": library.db.count("seed_candidates"),
        "certificate_count": library.db.count("certificates"),
        "failure_count": library.db.count("library_failures"),
        "event_count": library.db.count("library_events"),
        "snapshot_digest": library.snapshot_digest(),
    }
    print(json.dumps(payload, sort_keys=True, indent=2))
    return 0


def _run_budget_sweep(args: argparse.Namespace) -> int:
    runner = BudgetSweepRunner(args.root)
    report = runner.run(
        BudgetSweepConfig(
            count=args.count,
            budgets=args.budgets,
            repetitions=args.repetitions,
            near_minimal_eta_bytes=args.near_minimal_eta_bytes,
        )
    )
    text = _report_json(report) + "\n"
    if args.out:
        out = Path(args.out)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")
    if args.bundle:
        export_budget_bundle(report, args.bundle)
    return 0


def _inspect_db(args: argparse.Namespace) -> int:
    db = RuntimeDB(Path(args.root) / "runtime.sqlite3")
    counts = {
        table: db.count(table)
        for table in (
            "artifacts",
            "seed_candidates",
            "reconstruction_runs",
            "evaluations",
            "certificates",
            "lineage_edges",
        )
    }
    print(json.dumps(counts, sort_keys=True, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="gsrt", description="GSRT reference runtime v0.8.2")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("corpus-run", help="run deterministic text blind-reconstruction corpus")
    run.add_argument("--root", default=".gsrt-runtime")
    run.add_argument("--count", type=int, default=120)
    run.add_argument("--budget-bytes", type=int, default=512)
    run.add_argument("--repetitions", type=int, default=2)
    run.add_argument("--out")
    run.add_argument("--bundle")
    run.set_defaults(func=_run_corpus)

    demo = sub.add_parser("demo", help="run a small four-artifact reference demo")
    demo.add_argument("--root", default=".gsrt-demo")
    demo.add_argument("--count", type=int, default=4)
    demo.add_argument("--budget-bytes", type=int, default=512)
    demo.add_argument("--repetitions", type=int, default=1)
    demo.add_argument("--out")
    demo.add_argument("--bundle")
    demo.set_defaults(func=_run_corpus)


    sweep = sub.add_parser("budget-sweep", help="run matched-budget seed compression sweep")
    sweep.add_argument("--root", default=".gsrt-budget-sweep")
    sweep.add_argument("--count", type=int, default=120)
    sweep.add_argument(
        "--budgets",
        type=_parse_budgets,
        default=DEFAULT_BUDGETS,
        help="comma-separated byte budgets",
    )
    sweep.add_argument("--repetitions", type=int, default=2)
    sweep.add_argument("--near-minimal-eta-bytes", type=int, default=4)
    sweep.add_argument("--out")
    sweep.add_argument("--bundle")
    sweep.set_defaults(func=_run_budget_sweep)

    cross = sub.add_parser("cross-decoder", help="run internal reference cross-decoder reconstruction matrix")
    cross.add_argument("--root", default=".gsrt-cross-decoder")
    cross.add_argument("--count", type=int, default=120)
    cross.add_argument("--budget-bytes", type=int, default=512)
    cross.add_argument("--repetitions", type=int, default=2)
    cross.add_argument(
        "--families",
        type=_parse_csv_strings,
        default=DEFAULT_FAMILIES,
        help="comma-separated seed families",
    )
    cross.add_argument(
        "--decoders",
        type=_parse_csv_strings,
        default=DEFAULT_DECODERS,
        help="comma-separated decoder ids",
    )
    cross.add_argument("--controls", action=argparse.BooleanOptionalAction, default=True)
    cross.add_argument("--out")
    cross.add_argument("--bundle")
    cross.set_defaults(func=_run_cross_decoder)

    image = sub.add_parser("image-run", help="run retrospective synthetic image-seed reconstruction corpus")
    image.add_argument("--root", default=".gsrt-image")
    image.add_argument("--count", type=int, default=96)
    image.add_argument("--budget-bytes", type=int, default=512)
    image.add_argument("--repetitions", type=int, default=2)
    image.add_argument("--controls", action=argparse.BooleanOptionalAction, default=True)
    image.add_argument("--out")
    image.add_argument("--bundle")
    image.set_defaults(func=_run_image)

    factor = sub.add_parser("factor-run", help="run v0.5 image factorization / ablation experiment")
    factor.add_argument("--root", default=".gsrt-factor")
    factor.add_argument("--count", type=int, default=96)
    factor.add_argument("--out")
    factor.add_argument("--bundle")
    factor.set_defaults(func=_run_factor)

    library = sub.add_parser("library-run", help="run v0.6 persistent seed-library reuse benchmark")
    library.add_argument("--root", default=".gsrt-library")
    library.add_argument("--count", type=int, default=96)
    library.add_argument("--tasks-per-specificity", type=int, default=32)
    library.add_argument("--max-fresh-attempts", type=int, default=512)
    library.add_argument("--repetitions", type=int, default=1)
    library.add_argument("--out")
    library.add_argument("--bundle")
    library.set_defaults(func=_run_library)

    composition = sub.add_parser("composition-run", help="run v0.7 factor composition / mutation benchmark")
    composition.add_argument("--root", default=".gsrt-composition")
    composition.add_argument("--count", type=int, default=96)
    composition.add_argument("--tasks-per-specificity", type=int, default=32)
    composition.add_argument("--out")
    composition.add_argument("--bundle")
    composition.set_defaults(func=_run_composition)

    navigation = sub.add_parser("navigation-run", help="run v0.8 history-aware seed-space navigation benchmark")
    navigation.add_argument("--root", default=".gsrt-navigation")
    navigation.add_argument("--count", type=int, default=96)
    navigation.add_argument("--tasks-per-distance", type=int, default=32)
    navigation.add_argument("--max-fresh-attempts", type=int, default=6561)
    navigation.add_argument("--max-navigation-steps", type=int, default=5)
    navigation.add_argument("--out")
    navigation.add_argument("--bundle")
    navigation.set_defaults(func=_run_navigation)

    qd = sub.add_parser("qd-run", help="run v0.8.1 quality-diversity archive benchmark")
    qd.add_argument("--root", default=".gsrt-qd")
    qd.add_argument("--initial-count", type=int, default=96)
    qd.add_argument("--candidate-budget", type=int, default=243)
    qd.add_argument("--out")
    qd.add_argument("--bundle")
    qd.set_defaults(func=_run_qd)

    fleet = sub.add_parser("fleet-run", help="run v0.8.2 matched heterogeneous mutation-fleet benchmark")
    fleet.add_argument("--root", default=".gsrt-fleet")
    fleet.add_argument("--trials", type=int, default=32)
    fleet.add_argument("--candidate-budget", type=int, default=30)
    fleet.add_argument("--experiment-seed", default="gsrt-v0.8.2")
    fleet.add_argument("--out")
    fleet.add_argument("--bundle")
    fleet.set_defaults(func=_run_fleet)

    library_inspect = sub.add_parser("library-inspect", help="inspect v0.6 persistent seed library")
    library_inspect.add_argument("--root", default=".gsrt-library")
    library_inspect.set_defaults(func=_inspect_library)

    inspect = sub.add_parser("inspect-db", help="show persisted runtime record counts")
    inspect.add_argument("--root", default=".gsrt-runtime")
    inspect.set_defaults(func=_inspect_db)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))
