from __future__ import annotations

import hashlib
import json
from collections.abc import Callable

from .image_semantics import (
    CAMERAS,
    COMPOSITIONS,
    IDENTITIES,
    LIGHTINGS,
    PALETTES,
    SPATIALS,
    STYLES,
    SUBJECTS,
    ImageSemantics,
    analyze_reference_image,
)
from .models import ArtifactRecord, DependencyRef, SeedCandidate

_FIELDS = (
    ("subject", SUBJECTS),
    ("identity", IDENTITIES),
    ("composition", COMPOSITIONS),
    ("spatial", SPATIALS),
    ("camera", CAMERAS),
    ("lighting", LIGHTINGS),
    ("palette", PALETTES),
    ("style", STYLES),
)


def _truncate_utf8(text: str, budget_bytes: int) -> str:
    if budget_bytes < 0:
        raise ValueError("budget_bytes must be non-negative")
    raw = text.encode("utf-8")
    if len(raw) <= budget_bytes:
        return text
    raw = raw[:budget_bytes]
    while raw:
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            raw = raw[:-1]
    return ""


def _seed_id(artifact_id: str, family: str, payload: str, budget_bytes: int) -> str:
    material = json.dumps(
        {"artifact_id": artifact_id, "family": family, "payload": payload, "budget_bytes": budget_bytes},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


def encode_visual_compact(semantics: ImageSemantics) -> str:
    chars: list[str] = []
    for field_name, allowed in _FIELDS:
        value = getattr(semantics, field_name)
        chars.append(chr(ord("A") + allowed.index(value)))
    return "".join(chars)


def decode_visual_compact(payload: str) -> ImageSemantics:
    if len(payload) != len(_FIELDS):
        raise ValueError("compact visual seed must contain eight symbols")
    values: list[str] = []
    for char, (_, allowed) in zip(payload, _FIELDS, strict=True):
        index = ord(char) - ord("A")
        if index < 0 or index >= len(allowed):
            raise ValueError("invalid compact visual seed symbol")
        values.append(allowed[index])
    return ImageSemantics(*values)


class ReferenceImageSeedExtractor:
    """Retrospective extractor that derives seed factors from finished PNG bytes only."""

    FAMILIES = ("visual_description", "visual_partial", "visual_structured", "visual_compact")

    def __init__(self, source_reader: Callable[[str], bytes]):
        self.source_reader = source_reader

    def extract(self, artifact: ArtifactRecord, family: str, budget_bytes: int) -> SeedCandidate:
        if artifact.modality != "image":
            raise ValueError("image extractor requires image artifact")
        if family not in self.FAMILIES:
            raise ValueError(f"unsupported image seed family: {family}")
        semantics = analyze_reference_image(self.source_reader(artifact.artifact_id))

        if family == "visual_description":
            payload = ";".join(f"{name}={getattr(semantics, name)}" for name, _ in _FIELDS)
        elif family == "visual_partial":
            payload = ";".join(
                f"{name}={getattr(semantics, name)}"
                for name in ("subject", "composition", "palette", "style")
            )
        elif family == "visual_structured":
            payload = json.dumps(
                {name: getattr(semantics, name) for name, _ in _FIELDS},
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        else:
            payload = encode_visual_compact(semantics)

        payload = _truncate_utf8(payload, budget_bytes)
        dependencies = [DependencyRef("SHARED_BASELINE", "reference-visual-grammar:v0.4", 0)]
        if family == "visual_compact":
            dependencies.append(DependencyRef("SHARED_BASELINE", "reference-visual-codebook:v0.4", 0))
        return SeedCandidate(
            seed_id=_seed_id(artifact.artifact_id, family, payload, budget_bytes),
            artifact_id=artifact.artifact_id,
            family=family,
            payload=payload,
            payload_bytes=len(payload.encode("utf-8")),
            budget_bytes=budget_bytes,
            dependencies=tuple(dependencies),
            metadata={
                "extractor": "reference-image-retrospective:v0.4",
                "source_input": "finished_png_bytes_only",
                "source_metadata_visible": False,
                "shared_codebook": "reference-visual-codebook:v0.4" if family == "visual_compact" else None,
            },
        )
