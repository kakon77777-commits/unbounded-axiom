from __future__ import annotations

from dataclasses import dataclass, replace

from .image_semantics import (
    CAMERAS,
    COMPOSITIONS,
    IDENTITIES,
    LIGHTINGS,
    PALETTES,
    SPATIALS,
    STYLES,
    SUBJECTS,
    ImageSemantics,
)


@dataclass(frozen=True)
class FactorSpec:
    name: str
    allowed: tuple[str, ...]
    default: str


FACTOR_SPECS: dict[str, FactorSpec] = {
    "subject": FactorSpec("subject", SUBJECTS, SUBJECTS[0]),
    "identity": FactorSpec("identity", IDENTITIES, IDENTITIES[0]),
    "composition": FactorSpec("composition", COMPOSITIONS, COMPOSITIONS[0]),
    "spatial": FactorSpec("spatial", SPATIALS, SPATIALS[0]),
    "camera": FactorSpec("camera", CAMERAS, CAMERAS[0]),
    "lighting": FactorSpec("lighting", LIGHTINGS, LIGHTINGS[0]),
    "palette": FactorSpec("palette", PALETTES, PALETTES[0]),
    "style": FactorSpec("style", STYLES, STYLES[0]),
}


def replace_factor(semantics: ImageSemantics, factor_name: str, value: str) -> ImageSemantics:
    try:
        spec = FACTOR_SPECS[factor_name]
    except KeyError as exc:
        raise ValueError(f"unknown image factor: {factor_name}") from exc
    if value not in spec.allowed:
        raise ValueError(f"unsupported {factor_name}: {value}")
    return replace(semantics, **{factor_name: value})


def next_factor_value(semantics: ImageSemantics, factor_name: str) -> str:
    try:
        spec = FACTOR_SPECS[factor_name]
    except KeyError as exc:
        raise ValueError(f"unknown image factor: {factor_name}") from exc
    current = getattr(semantics, factor_name)
    index = spec.allowed.index(current)
    return spec.allowed[(index + 1) % len(spec.allowed)]


def semantic_delta(before: ImageSemantics, after: ImageSemantics) -> set[str]:
    return {
        factor_name
        for factor_name in FACTOR_SPECS
        if getattr(before, factor_name) != getattr(after, factor_name)
    }


def factor_locality_metrics(
    before: ImageSemantics,
    after: ImageSemantics,
    target_factor: str,
    *,
    epsilon0: float = 1e-6,
) -> dict[str, float]:
    if target_factor not in FACTOR_SPECS:
        raise ValueError(f"unknown image factor: {target_factor}")
    changed = semantic_delta(before, after)
    target_effect = float(target_factor in changed)
    collateral_changed = float(len(changed - {target_factor}))
    protected_count = max(1, len(FACTOR_SPECS) - 1)
    preservation_leakage = collateral_changed / protected_count
    protected_preservation = 1.0 - preservation_leakage
    normalized_locality = (
        target_effect / (target_effect + collateral_changed)
        if target_effect + collateral_changed > 0
        else 0.0
    )
    locality_ratio = target_effect / (collateral_changed + epsilon0)
    return {
        "target_effect": target_effect,
        "collateral_changed": collateral_changed,
        "preservation_leakage": preservation_leakage,
        "protected_preservation": protected_preservation,
        "normalized_locality": normalized_locality,
        "locality_ratio": locality_ratio,
    }


def ablate_factor(semantics: ImageSemantics, factor_name: str) -> ImageSemantics:
    try:
        default = FACTOR_SPECS[factor_name].default
    except KeyError as exc:
        raise ValueError(f"unknown image factor: {factor_name}") from exc
    return replace_factor(semantics, factor_name, default)


def transplant_factor(
    recipient: ImageSemantics,
    donor: ImageSemantics,
    factor_name: str,
) -> ImageSemantics:
    if factor_name not in FACTOR_SPECS:
        raise ValueError(f"unknown image factor: {factor_name}")
    return replace_factor(recipient, factor_name, getattr(donor, factor_name))


def transplant_metrics(
    recipient: ImageSemantics,
    donor: ImageSemantics,
    observed_hybrid: ImageSemantics,
    factor_name: str,
) -> dict[str, float]:
    if factor_name not in FACTOR_SPECS:
        raise ValueError(f"unknown image factor: {factor_name}")
    target_transfer = float(
        getattr(observed_hybrid, factor_name) == getattr(donor, factor_name)
    )
    protected = [name for name in FACTOR_SPECS if name != factor_name]
    protected_matches = sum(
        getattr(observed_hybrid, name) == getattr(recipient, name)
        for name in protected
    )
    protected_preservation = protected_matches / len(protected)
    preservation_leakage = 1.0 - protected_preservation
    locality = factor_locality_metrics(recipient, observed_hybrid, factor_name)
    return {
        "target_transfer": target_transfer,
        "protected_preservation": protected_preservation,
        "preservation_leakage": preservation_leakage,
        "normalized_locality": locality["normalized_locality"],
        "locality_ratio": locality["locality_ratio"],
        "repair_cost": 0.0,
    }


def round_trip_factor(
    recipient: ImageSemantics,
    donor: ImageSemantics,
    factor_name: str,
) -> tuple[ImageSemantics, ImageSemantics]:
    hybrid = transplant_factor(recipient, donor, factor_name)
    restored = replace_factor(hybrid, factor_name, getattr(recipient, factor_name))
    return hybrid, restored
