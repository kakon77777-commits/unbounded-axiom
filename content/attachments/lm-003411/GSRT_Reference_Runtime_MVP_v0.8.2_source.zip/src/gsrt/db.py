from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from .models import ArtifactRecord


class RuntimeDB:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._active_conn: sqlite3.Connection | None = None
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    @contextmanager
    def batch(self):
        """Group runtime evidence writes into one atomic SQLite transaction."""
        if self._active_conn is not None:
            raise RuntimeError("nested RuntimeDB batches are not supported")
        conn = self._connect()
        self._active_conn = conn
        try:
            conn.execute("BEGIN")
            yield self
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            self._active_conn = None
            conn.close()

    def _write(self, sql: str, values: tuple) -> None:
        if self._active_conn is not None:
            self._active_conn.execute(sql, values)
            return
        with self._connect() as conn:
            conn.execute(sql, values)

    def _fetchone(self, sql: str, values: tuple = ()):
        if self._active_conn is not None:
            return self._active_conn.execute(sql, values).fetchone()
        with self._connect() as conn:
            return conn.execute(sql, values).fetchone()

    def _fetchall(self, sql: str, values: tuple = ()):
        if self._active_conn is not None:
            return self._active_conn.execute(sql, values).fetchall()
        with self._connect() as conn:
            return conn.execute(sql, values).fetchall()

    def _init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS artifacts (
                    artifact_id TEXT PRIMARY KEY,
                    modality TEXT NOT NULL,
                    source_hash TEXT NOT NULL,
                    source_bytes INTEGER NOT NULL,
                    metadata_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS seed_candidates (
                    seed_id TEXT PRIMARY KEY,
                    artifact_id TEXT NOT NULL,
                    family TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS reconstruction_runs (
                    run_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS evaluations (
                    evaluation_id TEXT PRIMARY KEY,
                    run_id TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS certificates (
                    certificate_id TEXT PRIMARY KEY,
                    seed_id TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS lineage_edges (
                    edge_id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL,
                    target_id TEXT NOT NULL,
                    operation TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS validated_seeds (
                    seed_id TEXT PRIMARY KEY,
                    artifact_id TEXT NOT NULL,
                    modality TEXT NOT NULL,
                    family TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    payload_hash TEXT NOT NULL,
                    status TEXT NOT NULL,
                    certificate_id TEXT NOT NULL,
                    freshness_key TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS seed_factors (
                    seed_id TEXT NOT NULL,
                    factor_name TEXT NOT NULL,
                    factor_value TEXT NOT NULL,
                    PRIMARY KEY (seed_id, factor_name)
                );
                CREATE INDEX IF NOT EXISTS idx_seed_factors_lookup
                    ON seed_factors (factor_name, factor_value, seed_id);
                CREATE INDEX IF NOT EXISTS idx_validated_seed_status
                    ON validated_seeds (status, modality, family);
                CREATE TABLE IF NOT EXISTS library_failures (
                    failure_id TEXT PRIMARY KEY,
                    seed_id TEXT,
                    query_id TEXT NOT NULL,
                    failure_class TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS library_events (
                    event_id TEXT PRIMARY KEY,
                    subject_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS composition_branches (
                    branch_id TEXT PRIMARY KEY,
                    base_seed_id TEXT NOT NULL,
                    base_payload_hash TEXT NOT NULL,
                    status TEXT NOT NULL,
                    candidate_payload TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_composition_branch_base
                    ON composition_branches (base_seed_id, status);
                CREATE TABLE IF NOT EXISTS navigation_failures (
                    failure_id TEXT PRIMARY KEY,
                    state_signature TEXT NOT NULL,
                    operator_id TEXT NOT NULL,
                    donor_seed_id TEXT NOT NULL,
                    goal_id TEXT NOT NULL,
                    failure_class TEXT NOT NULL,
                    record_json TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_navigation_failure_lookup
                    ON navigation_failures
                    (goal_id, state_signature, operator_id, donor_seed_id);
                CREATE TABLE IF NOT EXISTS qd_descriptors (
                    descriptor_key TEXT PRIMARY KEY,
                    descriptor_id TEXT NOT NULL,
                    descriptor_version TEXT NOT NULL,
                    schema_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS qd_cells (
                    descriptor_key TEXT NOT NULL,
                    niche_key TEXT NOT NULL,
                    elite_seed_id TEXT NOT NULL,
                    quality REAL NOT NULL,
                    novelty_nearest REAL NOT NULL,
                    novelty_mean REAL NOT NULL,
                    updated_seq INTEGER NOT NULL,
                    record_json TEXT NOT NULL,
                    PRIMARY KEY (descriptor_key, niche_key)
                );
                CREATE INDEX IF NOT EXISTS idx_qd_cells_elite
                    ON qd_cells (descriptor_key, elite_seed_id);
                """
            )

    def record_artifact(self, record: ArtifactRecord) -> None:
        self._write(
            """
            INSERT OR REPLACE INTO artifacts
            (artifact_id, modality, source_hash, source_bytes, metadata_json)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                record.artifact_id,
                record.modality,
                record.source_hash,
                record.source_bytes,
                json.dumps(record.metadata, sort_keys=True, ensure_ascii=False),
            ),
        )

    def get_artifact(self, artifact_id: str) -> ArtifactRecord | None:
        row = self._fetchone("SELECT * FROM artifacts WHERE artifact_id = ?", (artifact_id,))
        if row is None:
            return None
        return ArtifactRecord(
            artifact_id=row["artifact_id"],
            modality=row["modality"],
            source_hash=row["source_hash"],
            source_bytes=row["source_bytes"],
            metadata=json.loads(row["metadata_json"]),
        )

    def count(self, table: str) -> int:
        allowed = {
            "artifacts",
            "seed_candidates",
            "reconstruction_runs",
            "evaluations",
            "certificates",
            "lineage_edges",
            "validated_seeds",
            "seed_factors",
            "library_failures",
            "library_events",
            "composition_branches",
            "navigation_failures",
            "qd_descriptors",
            "qd_cells",
        }
        if table not in allowed:
            raise ValueError(table)
        row = self._fetchone(f"SELECT COUNT(*) FROM {table}")
        return int(row[0])

    def record_seed_candidate(self, record) -> None:
        payload = json.dumps(record.to_dict(), sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO seed_candidates
            (seed_id, artifact_id, family, payload, record_json) VALUES (?, ?, ?, ?, ?)""",
            (record.seed_id, record.artifact_id, record.family, record.payload, payload),
        )

    def record_reconstruction_run(self, record) -> None:
        payload = json.dumps(record.to_dict(), sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO reconstruction_runs
            (run_id, seed_id, record_json) VALUES (?, ?, ?)""",
            (record.run_id, record.seed_id, payload),
        )

    def record_evaluation(self, record) -> None:
        payload = json.dumps(record.to_dict(), sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO evaluations
            (evaluation_id, run_id, record_json) VALUES (?, ?, ?)""",
            (record.evaluation_id, record.run_id, payload),
        )

    def record_certificate(self, record) -> None:
        payload = json.dumps(record.to_dict(), sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO certificates
            (certificate_id, seed_id, record_json) VALUES (?, ?, ?)""",
            (record.certificate_id, record.seed_id, payload),
        )

    def record_lineage_edge(
        self,
        edge_id: str,
        source_id: str,
        target_id: str,
        operation: str,
        metadata: dict | None = None,
    ) -> None:
        record = {
            "edge_id": edge_id,
            "source_id": source_id,
            "target_id": target_id,
            "operation": operation,
            "metadata": metadata or {},
        }
        self._write(
            """INSERT OR REPLACE INTO lineage_edges
            (edge_id, source_id, target_id, operation, record_json) VALUES (?, ?, ?, ?, ?)""",
            (
                edge_id,
                source_id,
                target_id,
                operation,
                json.dumps(record, sort_keys=True, ensure_ascii=False),
            ),
        )


    def query_lineage_edges(self, *, operation: str | None = None) -> list[dict]:
        if operation is None:
            rows = self._fetchall(
                "SELECT record_json FROM lineage_edges ORDER BY edge_id"
            )
        else:
            rows = self._fetchall(
                "SELECT record_json FROM lineage_edges WHERE operation = ? ORDER BY edge_id",
                (operation,),
            )
        return [json.loads(row["record_json"]) for row in rows]

    def record_validated_seed(self, record: dict) -> None:
        payload = json.dumps(record, sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO validated_seeds
            (seed_id, artifact_id, modality, family, payload, payload_hash, status,
             certificate_id, freshness_key, record_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record["seed_id"],
                record["artifact_id"],
                record["modality"],
                record["family"],
                record["payload"],
                record["payload_hash"],
                record["status"],
                record.get("certificate_id", ""),
                record.get("freshness_key", ""),
                payload,
            ),
        )

    def get_validated_seed(self, seed_id: str) -> dict | None:
        row = self._fetchone(
            "SELECT record_json FROM validated_seeds WHERE seed_id = ?",
            (seed_id,),
        )
        return None if row is None else json.loads(row["record_json"])

    def record_seed_factor(self, seed_id: str, factor_name: str, factor_value: str) -> None:
        self._write(
            """INSERT OR REPLACE INTO seed_factors
            (seed_id, factor_name, factor_value) VALUES (?, ?, ?)""",
            (seed_id, factor_name, factor_value),
        )

    def get_seed_factors(self, seed_id: str) -> dict[str, str]:
        rows = self._fetchall(
            """SELECT factor_name, factor_value FROM seed_factors
            WHERE seed_id = ? ORDER BY factor_name""",
            (seed_id,),
        )
        return {str(row["factor_name"]): str(row["factor_value"]) for row in rows}

    def query_validated_seeds(
        self,
        required_factors: dict[str, str] | None = None,
        *,
        allowed_statuses: tuple[str, ...] = ("VALIDATED", "REUSABLE", "PORTABLE"),
        require_certificate: bool = True,
        exclude_seed_ids: tuple[str, ...] = (),
        modality: str | None = None,
        family: str | None = None,
    ) -> list[dict]:
        required_factors = required_factors or {}
        conditions: list[str] = []
        values: list[object] = []
        if allowed_statuses:
            conditions.append("v.status IN (%s)" % ",".join("?" for _ in allowed_statuses))
            values.extend(allowed_statuses)
        if require_certificate:
            conditions.append("v.certificate_id <> ''")
        if exclude_seed_ids:
            conditions.append("v.seed_id NOT IN (%s)" % ",".join("?" for _ in exclude_seed_ids))
            values.extend(exclude_seed_ids)
        if modality is not None:
            conditions.append("v.modality = ?")
            values.append(modality)
        if family is not None:
            conditions.append("v.family = ?")
            values.append(family)
        for index, (factor_name, factor_value) in enumerate(sorted(required_factors.items())):
            alias = f"f{index}"
            conditions.append(
                f"EXISTS (SELECT 1 FROM seed_factors AS {alias} "
                f"WHERE {alias}.seed_id = v.seed_id AND {alias}.factor_name = ? "
                f"AND {alias}.factor_value = ?)"
            )
            values.extend((factor_name, factor_value))
        where = " AND ".join(conditions) if conditions else "1=1"
        rows = self._fetchall(
            f"SELECT v.record_json FROM validated_seeds AS v WHERE {where} ORDER BY v.seed_id",
            tuple(values),
        )
        return [json.loads(row["record_json"]) for row in rows]

    def record_library_failure(self, record: dict) -> None:
        payload = json.dumps(record, sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO library_failures
            (failure_id, seed_id, query_id, failure_class, record_json)
            VALUES (?, ?, ?, ?, ?)""",
            (
                record["failure_id"],
                record.get("seed_id"),
                record["query_id"],
                record["failure_class"],
                payload,
            ),
        )

    def record_library_event(self, record: dict) -> None:
        payload = json.dumps(record, sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO library_events
            (event_id, subject_id, event_type, record_json) VALUES (?, ?, ?, ?)""",
            (record["event_id"], record["subject_id"], record["event_type"], payload),
        )


    def record_composition_branch(self, record: dict) -> None:
        payload = json.dumps(record, sort_keys=True, ensure_ascii=False)
        self._write(
            """INSERT OR REPLACE INTO composition_branches
            (branch_id, base_seed_id, base_payload_hash, status, candidate_payload, record_json)
            VALUES (?, ?, ?, ?, ?, ?)""",
            (
                record["branch_id"],
                record["base_seed_id"],
                record["base_payload_hash"],
                record["status"],
                record["candidate_payload"],
                payload,
            ),
        )

    def get_composition_branch(self, branch_id: str) -> dict | None:
        row = self._fetchone(
            "SELECT record_json FROM composition_branches WHERE branch_id = ?",
            (branch_id,),
        )
        return None if row is None else json.loads(row["record_json"])

    def seed_certificate_outcomes(self) -> list[dict]:
        """Return persisted candidate/certificate evidence joined to source size.

        This is an experimental evidence query, not a canonical seed identity API.
        """
        rows = self._fetchall(
            """
            SELECT s.record_json AS seed_json, c.record_json AS certificate_json,
                   a.source_bytes AS source_bytes
            FROM seed_candidates AS s
            JOIN certificates AS c ON c.seed_id = s.seed_id
            JOIN artifacts AS a ON a.artifact_id = s.artifact_id
            ORDER BY s.artifact_id, s.family, s.seed_id
            """
        )
        outcomes: list[dict] = []
        private_kinds = {"PRIVATE_PER_ITEM", "HIDDEN_CACHE", "SOURCE_ARTIFACT"}
        for row in rows:
            seed = json.loads(row["seed_json"])
            certificate = json.loads(row["certificate_json"])
            private_cost = sum(
                max(0, int(dep.get("cost_bytes", 0)))
                for dep in seed.get("dependencies", [])
                if dep.get("kind") in private_kinds
            )
            outcomes.append(
                {
                    "artifact_id": seed["artifact_id"],
                    "source_bytes": int(row["source_bytes"]),
                    "seed_id": seed["seed_id"],
                    "family": seed["family"],
                    "budget_bytes": int(seed["budget_bytes"]),
                    "payload_bytes": int(seed["payload_bytes"]),
                    "adjusted_cost_bytes": int(seed["payload_bytes"]) + private_cost,
                    "passed": bool(certificate["passed"]),
                    "success_probability": float(certificate["success_probability"]),
                }
            )
        return outcomes
    def record_navigation_failure(self, record: dict) -> None:
        self._write(
            """INSERT OR REPLACE INTO navigation_failures
            (failure_id, state_signature, operator_id, donor_seed_id, goal_id,
             failure_class, record_json) VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                record["failure_id"],
                record["state_signature"],
                record["operator_id"],
                record["donor_seed_id"],
                record["goal_id"],
                record["failure_class"],
                json.dumps(record, sort_keys=True, ensure_ascii=False),
            ),
        )

    def navigation_failure_exists(
        self,
        state_signature: str,
        operator_id: str,
        donor_seed_id: str,
        goal_id: str,
    ) -> bool:
        row = self._fetchone(
            """SELECT 1 FROM navigation_failures
            WHERE state_signature = ? AND operator_id = ? AND donor_seed_id = ?
              AND goal_id = ? LIMIT 1""",
            (state_signature, operator_id, donor_seed_id, goal_id),
        )
        return row is not None

    def query_navigation_failures(self, *, goal_id: str | None = None) -> list[dict]:
        if goal_id is None:
            rows = self._fetchall(
                "SELECT record_json FROM navigation_failures ORDER BY failure_id"
            )
        else:
            rows = self._fetchall(
                """SELECT record_json FROM navigation_failures
                WHERE goal_id = ? ORDER BY failure_id""",
                (goal_id,),
            )
        return [json.loads(row["record_json"]) for row in rows]

    def record_qd_descriptor(self, record: dict) -> None:
        descriptor_key = str(record["descriptor_key"])
        schema_json = json.dumps(record["schema"], sort_keys=True, ensure_ascii=False)
        existing = self._fetchone(
            "SELECT descriptor_id, descriptor_version, schema_json FROM qd_descriptors WHERE descriptor_key = ?",
            (descriptor_key,),
        )
        if existing is not None:
            if (
                str(existing["descriptor_id"]) != str(record["descriptor_id"])
                or str(existing["descriptor_version"]) != str(record["descriptor_version"])
                or str(existing["schema_json"]) != schema_json
            ):
                raise ValueError("descriptor schema mismatch")
            return
        self._write(
            """INSERT INTO qd_descriptors
            (descriptor_key, descriptor_id, descriptor_version, schema_json)
            VALUES (?, ?, ?, ?)""",
            (
                descriptor_key,
                record["descriptor_id"],
                record["descriptor_version"],
                schema_json,
            ),
        )

    def get_qd_descriptor(self, descriptor_key: str) -> dict | None:
        row = self._fetchone(
            "SELECT * FROM qd_descriptors WHERE descriptor_key = ?",
            (descriptor_key,),
        )
        if row is None:
            return None
        return {
            "descriptor_key": str(row["descriptor_key"]),
            "descriptor_id": str(row["descriptor_id"]),
            "descriptor_version": str(row["descriptor_version"]),
            "schema": json.loads(row["schema_json"]),
        }

    def record_qd_cell(self, record: dict) -> None:
        self._write(
            """INSERT OR REPLACE INTO qd_cells
            (descriptor_key, niche_key, elite_seed_id, quality, novelty_nearest,
             novelty_mean, updated_seq, record_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                record["descriptor_key"],
                record["niche_key"],
                record["elite_seed_id"],
                float(record["quality"]),
                float(record.get("novelty_nearest", 0.0)),
                float(record.get("novelty_mean", 0.0)),
                int(record.get("updated_seq", 0)),
                json.dumps(record, sort_keys=True, ensure_ascii=False),
            ),
        )

    def get_qd_cell(self, descriptor_key: str, niche_key: str) -> dict | None:
        row = self._fetchone(
            """SELECT record_json FROM qd_cells
            WHERE descriptor_key = ? AND niche_key = ?""",
            (descriptor_key, niche_key),
        )
        return None if row is None else json.loads(row["record_json"])

    def query_qd_cells(self, descriptor_key: str) -> list[dict]:
        rows = self._fetchall(
            """SELECT record_json FROM qd_cells
            WHERE descriptor_key = ? ORDER BY niche_key""",
            (descriptor_key,),
        )
        return [json.loads(row["record_json"]) for row in rows]

    def clear_qd_cells(self, descriptor_key: str) -> None:
        if self._active_conn is not None:
            self._active_conn.execute(
                "DELETE FROM qd_cells WHERE descriptor_key = ?", (descriptor_key,)
            )
            return
        with self._connect() as conn:
            conn.execute("DELETE FROM qd_cells WHERE descriptor_key = ?", (descriptor_key,))
