from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .models import ReconstructionResult, SeedCandidate
from .reconstruction import ReferenceReconstructor, _from_freeform, _from_structured
from .reference_codebook import decode_compact
from .text_semantics import parse_fixture_text, render_fixture_text


def _decoder_run_id(seed_id: str, decoder_id: str, run_index: int) -> str:
    raw = f"{seed_id}:{decoder_id}:{run_index}".encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True)
class DecoderSpec:
    decoder_id: str
    evidence_level: str
    supported_families: tuple[str, ...]
    description: str


class CrossDecoder:
    spec: DecoderSpec

    @property
    def decoder_id(self) -> str:
        return self.spec.decoder_id

    @property
    def evidence_level(self) -> str:
        return self.spec.evidence_level

    def decode(self, seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult:
        raise NotImplementedError

    def _result(
        self,
        seed: SeedCandidate,
        run_index: int,
        *,
        text: str = "",
        error: str | None = None,
    ) -> ReconstructionResult:
        return ReconstructionResult(
            run_id=_decoder_run_id(seed.seed_id, self.spec.decoder_id, run_index),
            seed_id=seed.seed_id,
            text=text,
            source_visible_to_decoder=False,
            error=error,
            metadata={
                "generator": self.spec.decoder_id,
                "decoder_id": self.spec.decoder_id,
                "evidence_level": self.spec.evidence_level,
                "run_index": run_index,
            },
        )


class ReferenceExactDecoder(CrossDecoder):
    spec = DecoderSpec(
        decoder_id="reference_exact:v0.3",
        evidence_level="INTERNAL_REFERENCE_VARIANTS",
        supported_families=("summary", "keyword", "freeform", "structured", "compact"),
        description="v0.2 family-aware reference decoder wrapped with decoder-specific run identity",
    )

    def __init__(self):
        self._inner = ReferenceReconstructor()

    def decode(self, seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult:
        inner = self._inner.reconstruct(seed, run_index=run_index)
        return self._result(seed, run_index, text=inner.text, error=inner.error)


class RelationalInterlinguaDecoder(CrossDecoder):
    spec = DecoderSpec(
        decoder_id="relational_interlingua:v0.3",
        evidence_level="INTERNAL_REFERENCE_VARIANTS",
        supported_families=("summary", "keyword", "freeform", "structured"),
        description="relation-oriented textual decoder with no access to the compact codebook",
    )

    def decode(self, seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult:
        try:
            if seed.family == "summary":
                semantics = parse_fixture_text(seed.payload)
            elif seed.family == "freeform":
                semantics = _from_freeform(seed.payload)
            elif seed.family == "structured":
                semantics = _from_structured(seed.payload)
            elif seed.family == "keyword":
                parts = seed.payload.split("|")
                if len(parts) != 4:
                    raise ValueError("incomplete keyword seed")
                # Keyword bags intentionally cannot recover relation/epistemic invariants.
                from .text_semantics import TextSemantics

                semantics = TextSemantics(
                    subject=parts[0],
                    epistemic="may",
                    relation="support",
                    object=parts[1],
                    condition=parts[2],
                    negated_implication=False,
                    consequence=parts[3],
                    style="neutral",
                )
            else:
                raise ValueError(f"unsupported family for relational decoder: {seed.family}")
            return self._result(seed, run_index, text=render_fixture_text(semantics))
        except Exception as exc:
            return self._result(seed, run_index, error=f"{type(exc).__name__}: {exc}")


class CompactCoreDecoder(CrossDecoder):
    spec = DecoderSpec(
        decoder_id="compact_core:v0.3",
        evidence_level="INTERNAL_REFERENCE_VARIANTS",
        supported_families=("compact", "freeform", "structured"),
        description="compact-codebook-first decoder that does not accept raw summary text",
    )

    def decode(self, seed: SeedCandidate, run_index: int = 0) -> ReconstructionResult:
        try:
            if seed.family == "compact":
                semantics = decode_compact(seed.payload)
            elif seed.family == "freeform":
                semantics = _from_freeform(seed.payload)
            elif seed.family == "structured":
                semantics = _from_structured(seed.payload)
            else:
                raise ValueError(f"unsupported family for compact decoder: {seed.family}")
            return self._result(seed, run_index, text=render_fixture_text(semantics))
        except Exception as exc:
            return self._result(seed, run_index, error=f"{type(exc).__name__}: {exc}")


def reference_decoder_registry() -> dict[str, CrossDecoder]:
    decoders: tuple[CrossDecoder, ...] = (
        ReferenceExactDecoder(),
        RelationalInterlinguaDecoder(),
        CompactCoreDecoder(),
    )
    return {decoder.spec.decoder_id: decoder for decoder in decoders}
