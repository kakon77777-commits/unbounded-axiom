from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Mapping

from .db import RuntimeDB
from .image_extraction import decode_visual_compact, encode_visual_compact
from .image_factors import FACTOR_SPECS, replace_factor, semantic_delta
from .image_semantics import ImageSemantics, analyze_reference_image, render_reference_image
from .retrieval import LibraryQuery, SeedRetriever

_FACTOR_NAMES = tuple(FACTOR_SPECS)


def hamming_distance(left: Mapping[str, str], right: Mapping[str, str]) -> int:
    """Count factor-value disagreements over the complete visual factor set."""
    return sum(left.get(name) != right.get(name) for name in _FACTOR_NAMES)


@dataclass(frozen=True)
class GenerationGoal:
    hard_constraints: dict[str, str]
    modality: str = "image"
    family: str = "visual_compact"
    metadata: dict[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        unknown = sorted(set(self.hard_constraints) - set(_FACTOR_NAMES))
        if unknown:
            raise ValueError(f"unknown factor: {unknown[0]}")
        missing = sorted(set(_FACTOR_NAMES) - set(self.hard_constraints))
        if missing:
            raise ValueError(f"complete visual goal required; missing factor: {missing[0]}")
        for name in _FACTOR_NAMES:
            domain = FACTOR_SPECS[name].allowed
            value = self.hard_constraints[name]
            if value not in domain:
                raise ValueError(f"invalid factor value: {name}={value}")

    @property
    def goal_id(self) -> str:
        raw = json.dumps(
            self.hard_constraints, sort_keys=True, separators=(",", ":")
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()


class GoalCompiler:
    def compile(self, target: ImageSemantics) -> GenerationGoal:
        return GenerationGoal(
            hard_constraints={name: getattr(target, name) for name in _FACTOR_NAMES},
            metadata={"compiler": "complete-visual-goal:v0.8"},
        )


@dataclass(frozen=True)
class QueryPlan:
    goal: GenerationGoal
    library_query: LibraryQuery


class QueryPlanner:
    """Compile a complete target into an explainable nearest-seed retrieval query."""

    def compile(self, goal: GenerationGoal, *, max_candidates: int = 10) -> QueryPlan:
        return QueryPlan(
            goal=goal,
            library_query=LibraryQuery(
                required_factors={},
                optional_factors=dict(goal.hard_constraints),
                modality=goal.modality,
                family=goal.family,
                max_candidates=max_candidates,
            ),
        )


class FailureMap:
    def __init__(self, db: RuntimeDB):
        self.db = db

    @staticmethod
    def _failure_id(
        state_signature: str,
        operator_id: str,
        donor_seed_id: str,
        goal_id: str,
        failure_class: str,
    ) -> str:
        raw = json.dumps(
            [state_signature, operator_id, donor_seed_id, goal_id, failure_class],
            separators=(",", ":"),
        ).encode("utf-8")
        return "sha256:" + hashlib.sha256(raw).hexdigest()

    def record(
        self,
        *,
        state_signature: str,
        operator_id: str,
        donor_seed_id: str,
        goal_id: str,
        failure_class: str,
        metadata: dict[str, object] | None = None,
    ) -> dict[str, object]:
        record: dict[str, object] = {
            "failure_id": self._failure_id(
                state_signature, operator_id, donor_seed_id, goal_id, failure_class
            ),
            "state_signature": state_signature,
            "operator_id": operator_id,
            "donor_seed_id": donor_seed_id,
            "goal_id": goal_id,
            "failure_class": failure_class,
            "metadata": metadata or {},
        }
        self.db.record_navigation_failure(record)
        return record

    def is_known(
        self,
        state_signature: str,
        operator_id: str,
        donor_seed_id: str,
        goal_id: str,
    ) -> bool:
        return self.db.navigation_failure_exists(
            state_signature, operator_id, donor_seed_id, goal_id
        )

    def records(self, *, goal_id: str | None = None) -> list[dict]:
        return self.db.query_navigation_failures(goal_id=goal_id)


@dataclass(frozen=True)
class NavigationAction:
    factor_name: str
    target_value: str
    donor_seed_id: str
    operator_id: str
    avoided_known_failures: int = 0


class RuleBasedNavigationPlanner:
    """Deterministic first-mismatch factor router for the v0.8 reference runtime."""

    def __init__(self, db: RuntimeDB, failure_map: FailureMap):
        self.db = db
        self.failure_map = failure_map
        self.retriever = SeedRetriever(db)

    def next_action(
        self,
        current: ImageSemantics,
        goal: GenerationGoal,
        *,
        use_history: bool = True,
    ) -> NavigationAction:
        mismatch = next(
            (name for name in _FACTOR_NAMES if getattr(current, name) != goal.hard_constraints[name]),
            None,
        )
        if mismatch is None:
            raise ValueError("goal already satisfied")
        target_value = goal.hard_constraints[mismatch]
        operator_id = f"replace_factor:{mismatch}"
        query = LibraryQuery(
            required_factors={mismatch: target_value},
            optional_factors={
                name: goal.hard_constraints[name]
                for name in _FACTOR_NAMES
                if name != mismatch
            },
            max_candidates=1024,
        )
        portfolio = self.retriever.retrieve(query)
        state_signature = encode_visual_compact(current)
        avoided = 0
        for candidate in portfolio.candidates:
            if use_history and self.failure_map.is_known(
                state_signature,
                operator_id,
                candidate.seed_id,
                goal.goal_id,
            ):
                avoided += 1
                continue
            return NavigationAction(
                factor_name=mismatch,
                target_value=target_value,
                donor_seed_id=candidate.seed_id,
                operator_id=operator_id,
                avoided_known_failures=avoided,
            )
        raise ValueError(f"no usable donor for factor: {mismatch}")


@dataclass(frozen=True)
class NavigationStep:
    step_index: int
    before_signature: str
    after_signature: str
    action: NavigationAction
    changed_factors: tuple[str, ...]
    protected_leakage: float


@dataclass(frozen=True)
class NavigationOutcome:
    success: bool
    initial_distance: int
    path_length: int
    final_semantics: ImageSemantics
    steps: tuple[NavigationStep, ...]
    mean_protected_leakage: float
    known_failure_revisits: int
    avoided_known_failures: int
    planner_calls: int
    donor_retrieval_calls: int
    generation_count: int
    evaluator_calls: int


class NavigationExecutor:
    """Isolated v0.8 search workspace executor.

    Intermediate states are rendered and re-observed, but never inserted into the
    validated Seed Library. This keeps every benchmark task pinned to the same
    initial library snapshot.
    """

    def __init__(self, db: RuntimeDB, planner: RuleBasedNavigationPlanner):
        self.db = db
        self.planner = planner

    @staticmethod
    def _mapping(semantics: ImageSemantics) -> dict[str, str]:
        return {name: getattr(semantics, name) for name in _FACTOR_NAMES}

    def navigate(
        self,
        start_seed_id: str,
        goal: GenerationGoal,
        *,
        max_steps: int = 5,
        use_history: bool = True,
    ) -> NavigationOutcome:
        if max_steps < 1:
            raise ValueError("max_steps must be positive")
        record = self.db.get_validated_seed(start_seed_id)
        if record is None:
            raise KeyError(start_seed_id)
        if str(record.get("status")) not in {"VALIDATED", "REUSABLE", "PORTABLE"}:
            raise ValueError("start seed must be reusable")
        current = decode_visual_compact(str(record["payload"]))
        initial_distance = hamming_distance(self._mapping(current), goal.hard_constraints)
        steps: list[NavigationStep] = []
        known_revisits = 0
        avoided = 0

        while hamming_distance(self._mapping(current), goal.hard_constraints) > 0:
            if len(steps) >= max_steps:
                break
            action = self.planner.next_action(current, goal, use_history=use_history)
            state_signature = encode_visual_compact(current)
            known_revisits += int(
                self.planner.failure_map.is_known(
                    state_signature,
                    action.operator_id,
                    action.donor_seed_id,
                    goal.goal_id,
                )
            )
            avoided += action.avoided_known_failures
            donor_factors = self.db.get_seed_factors(action.donor_seed_id)
            if donor_factors.get(action.factor_name) != action.target_value:
                raise RuntimeError("planner selected donor with wrong target factor")
            candidate = replace_factor(current, action.factor_name, action.target_value)
            observed = analyze_reference_image(render_reference_image(candidate))
            changed_set = semantic_delta(current, observed)
            changed = tuple(name for name in _FACTOR_NAMES if name in changed_set)
            collateral = len(changed_set - {action.factor_name})
            protected_leakage = collateral / max(1, len(_FACTOR_NAMES) - 1)
            steps.append(
                NavigationStep(
                    step_index=len(steps),
                    before_signature=state_signature,
                    after_signature=encode_visual_compact(observed),
                    action=action,
                    changed_factors=changed,
                    protected_leakage=protected_leakage,
                )
            )
            current = observed

        success = hamming_distance(self._mapping(current), goal.hard_constraints) == 0
        mean_leakage = (
            sum(step.protected_leakage for step in steps) / len(steps) if steps else 0.0
        )
        return NavigationOutcome(
            success=success,
            initial_distance=initial_distance,
            path_length=len(steps),
            final_semantics=current,
            steps=tuple(steps),
            mean_protected_leakage=mean_leakage,
            known_failure_revisits=known_revisits,
            avoided_known_failures=avoided,
            planner_calls=len(steps),
            donor_retrieval_calls=len(steps),
            generation_count=len(steps),
            evaluator_calls=len(steps),
        )
