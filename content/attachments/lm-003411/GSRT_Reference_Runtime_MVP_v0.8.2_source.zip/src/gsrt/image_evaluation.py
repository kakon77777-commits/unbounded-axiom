from __future__ import annotations

import hashlib
from collections.abc import Callable

from .image_semantics import ImageSemantics, analyze_reference_image
from .models import EvaluationResult, ImageReconstructionResult
from .png_codec import decode_rgb_png


class ImageFidelityEvaluator:
    evaluator_id = "reference-image-fidelity:v0.4"

    def __init__(self, output_reader: Callable[[str], bytes]):
        self.output_reader = output_reader

    def evaluate(
        self,
        source_semantics: ImageSemantics,
        source_png: bytes,
        result: ImageReconstructionResult,
    ) -> EvaluationResult:
        try:
            if result.output_artifact_id is None:
                raise ValueError(result.error or "missing reconstruction artifact")
            output_png = self.output_reader(result.output_artifact_id)
            out = analyze_reference_image(output_png)
            semantic_names = (
                "subject",
                "identity",
                "composition",
                "spatial",
                "camera",
                "lighting",
                "palette",
                "style",
            )
            scores = {
                name: float(getattr(source_semantics, name) == getattr(out, name))
                for name in semantic_names
            }
            sw, sh, sp = decode_rgb_png(source_png)
            ow, oh, op = decode_rgb_png(output_png)
            same_shape = (sw, sh) == (ow, oh) and len(sp) == len(op)
            if same_shape:
                distance = sum(abs(a - b) for a, b in zip(sp, op, strict=True))
                pixel_similarity = 1.0 - distance / (255 * len(sp))
                pixel_exact = float(sp == op)
            else:
                pixel_similarity = 0.0
                pixel_exact = 0.0
            scores["pixel_similarity"] = pixel_similarity
            scores["pixel_exact"] = pixel_exact
            scores["semantic_overall"] = sum(scores[name] for name in semantic_names) / len(semantic_names)
            scores["overall"] = sum(scores.values()) / len(scores)
            hard_pass = all(scores[name] == 1.0 for name in semantic_names)
            passed = hard_pass
            parse_error = None
        except Exception as exc:
            scores = {
                "subject": 0.0,
                "identity": 0.0,
                "composition": 0.0,
                "spatial": 0.0,
                "camera": 0.0,
                "lighting": 0.0,
                "palette": 0.0,
                "style": 0.0,
                "pixel_similarity": 0.0,
                "pixel_exact": 0.0,
                "semantic_overall": 0.0,
                "overall": 0.0,
            }
            hard_pass = False
            passed = False
            parse_error = f"{type(exc).__name__}: {exc}"
        material = f"{result.run_id}:{self.evaluator_id}".encode("utf-8")
        return EvaluationResult(
            evaluation_id="sha256:" + hashlib.sha256(material).hexdigest(),
            run_id=result.run_id,
            seed_id=result.seed_id,
            scores=scores,
            hard_pass=hard_pass,
            passed=passed,
            metadata={"evaluator": self.evaluator_id, "parse_error": parse_error},
        )
