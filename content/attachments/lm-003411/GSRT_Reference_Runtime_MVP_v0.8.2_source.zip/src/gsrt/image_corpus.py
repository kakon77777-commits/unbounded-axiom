from __future__ import annotations

import hashlib
from dataclasses import dataclass
from itertools import product

from .image_semantics import (
    CAMERAS,
    COMPOSITIONS,
    IDENTITIES,
    LIGHTINGS,
    PALETTES,
    SPATIALS,
    STYLES,
    SUBJECTS,
    ImageSemantics,
    render_reference_image,
)


@dataclass(frozen=True)
class ImageCorpusItem:
    png_bytes: bytes
    semantics: ImageSemantics
    metadata: dict[str, object]


def _order_key(values: tuple[str, ...]) -> bytes:
    return hashlib.sha256("|".join(values).encode("utf-8")).digest()


def generate_reference_image_corpus(count: int = 96) -> list[ImageCorpusItem]:
    if count < 1:
        raise ValueError("count must be positive")
    combinations = list(
        product(
            SUBJECTS,
            IDENTITIES,
            COMPOSITIONS,
            SPATIALS,
            CAMERAS,
            LIGHTINGS,
            PALETTES,
            STYLES,
        )
    )
    if count > len(combinations):
        raise ValueError("requested corpus larger than visual fixture space")
    combinations.sort(key=_order_key)

    items: list[ImageCorpusItem] = []
    for index, values in enumerate(combinations[:count]):
        semantics = ImageSemantics(*values)
        items.append(
            ImageCorpusItem(
                png_bytes=render_reference_image(semantics),
                semantics=semantics,
                metadata={
                    "fixture_index": index,
                    "grammar": "gsrt-reference-visual-v0.4",
                },
            )
        )
    return items
