from __future__ import annotations

import hashlib
import json

from .models import SeedCandidate


def _control_seed(base: SeedCandidate, name: str, payload: str) -> SeedCandidate:
    material = f"{base.seed_id}:{name}:{payload}".encode("utf-8")
    return SeedCandidate(
        seed_id="sha256:" + hashlib.sha256(material).hexdigest(),
        artifact_id=base.artifact_id,
        family=base.family,
        payload=payload,
        payload_bytes=len(payload.encode("utf-8")),
        budget_bytes=base.budget_bytes,
        dependencies=base.dependencies,
        metadata={**base.metadata, "control": name},
    )


def _next(value: str, values: tuple[str, ...]) -> str:
    return values[(values.index(value) + 1) % len(values)]


def make_image_controls(seed: SeedCandidate, unrelated_seed: SeedCandidate) -> dict[str, SeedCandidate]:
    if seed.family != "visual_structured" or unrelated_seed.family != "visual_structured":
        raise ValueError("reference image controls require visual_structured seeds")
    obj = json.loads(seed.payload)

    wrong_identity = dict(obj)
    wrong_identity["identity"] = _next(obj["identity"], ("alpha", "beta", "gamma"))

    spatial_flip = dict(obj)
    spatial_flip["spatial"] = _next(obj["spatial"], ("above", "below", "beside"))

    style_swap = dict(obj)
    style_swap["style"] = _next(obj["style"], ("solid", "striped", "outline"))

    random_payload = json.dumps(
        {"opaque": hashlib.sha256(seed.seed_id.encode("utf-8")).hexdigest()[:24]},
        sort_keys=True,
        separators=(",", ":"),
    )
    unrelated_payload = unrelated_seed.payload

    def dump(value: dict) -> str:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))

    return {
        "random": _control_seed(seed, "random", random_payload),
        "wrong_identity": _control_seed(seed, "wrong_identity", dump(wrong_identity)),
        "spatial_flip": _control_seed(seed, "spatial_flip", dump(spatial_flip)),
        "style_swap": _control_seed(seed, "style_swap", dump(style_swap)),
        "unrelated": _control_seed(seed, "unrelated", unrelated_payload),
    }
