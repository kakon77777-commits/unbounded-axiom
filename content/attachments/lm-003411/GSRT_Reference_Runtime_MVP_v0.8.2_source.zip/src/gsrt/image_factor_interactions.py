from __future__ import annotations

from itertools import combinations

from .image_factors import FACTOR_SPECS, next_factor_value, replace_factor, semantic_delta
from .image_semantics import ImageSemantics, analyze_reference_image, render_reference_image
from .png_codec import decode_rgb_png


def _pixel_bytes(png_bytes: bytes) -> tuple[int, int, bytes]:
    return decode_rgb_png(png_bytes)


def pixel_change_mask(base_png: bytes, changed_png: bytes) -> tuple[bool, ...]:
    bw, bh, bp = _pixel_bytes(base_png)
    cw, ch, cp = _pixel_bytes(changed_png)
    if (bw, bh) != (cw, ch) or len(bp) != len(cp):
        raise ValueError("pixel interaction requires equal image dimensions")
    return tuple(bp[i : i + 3] != cp[i : i + 3] for i in range(0, len(bp), 3))


def pixel_interaction_residual(
    base_png: bytes,
    first_png: bytes,
    second_png: bytes,
    pair_png: bytes,
) -> float:
    first = pixel_change_mask(base_png, first_png)
    second = pixel_change_mask(base_png, second_png)
    pair = pixel_change_mask(base_png, pair_png)
    expected_union = tuple(a or b for a, b in zip(first, second, strict=True))
    union_size = sum(expected_union)
    if union_size == 0:
        return 0.0
    mismatch = sum(
        observed != expected
        for observed, expected in zip(pair, expected_union, strict=True)
    )
    return mismatch / union_size


def semantic_coupling_matrix(semantics: ImageSemantics) -> dict[str, dict[str, float]]:
    matrix = {
        changed: {observed: 0.0 for observed in FACTOR_SPECS}
        for changed in FACTOR_SPECS
    }
    for changed_factor in FACTOR_SPECS:
        changed = replace_factor(
            semantics,
            changed_factor,
            next_factor_value(semantics, changed_factor),
        )
        observed = analyze_reference_image(render_reference_image(changed))
        changes = semantic_delta(semantics, observed)
        for observed_factor in changes:
            matrix[changed_factor][observed_factor] = 1.0
    return matrix


def pixel_interaction_matrix(semantics: ImageSemantics) -> dict[str, dict[str, float]]:
    matrix = {
        first: {second: 0.0 for second in FACTOR_SPECS}
        for first in FACTOR_SPECS
    }
    base_png = render_reference_image(semantics)
    singles: dict[str, ImageSemantics] = {}
    single_pngs: dict[str, bytes] = {}
    for factor_name in FACTOR_SPECS:
        changed = replace_factor(
            semantics,
            factor_name,
            next_factor_value(semantics, factor_name),
        )
        singles[factor_name] = changed
        single_pngs[factor_name] = render_reference_image(changed)

    for first, second in combinations(FACTOR_SPECS, 2):
        pair = replace_factor(
            singles[first],
            second,
            getattr(singles[second], second),
        )
        residual = pixel_interaction_residual(
            base_png,
            single_pngs[first],
            single_pngs[second],
            render_reference_image(pair),
        )
        matrix[first][second] = residual
        matrix[second][first] = residual
    return matrix
