from __future__ import annotations

from itertools import product

from .models import CorpusItem
from .text_semantics import TextSemantics, render_fixture_text


_SUBJECTS = (
    "redundant replicas",
    "causal logs",
    "semantic seeds",
    "bounded planners",
    "versioned registries",
)
_OBJECTS = (
    "service continuity",
    "replay fidelity",
    "relational structure",
    "search stability",
    "historical identity",
)
_CONDITIONS = (
    "partial node loss",
    "stale state",
    "bounded context",
    "cross model transfer",
)
_CONSEQUENCES = (
    "higher safety",
    "exact recovery",
    "universal portability",
    "lower search cost",
)
_EPISTEMIC = ("may", "likely", "must")
_RELATIONS = ("preserve", "support", "constrain", "enable", "reduce", "increase")
_STYLES = ("technical", "practical", "concise")
_NEG = (True, False)


def generate_reference_corpus(count: int = 120) -> list[CorpusItem]:
    if count < 1:
        raise ValueError("count must be positive")
    items: list[CorpusItem] = []
    for index, (subject, epistemic, relation, obj, condition, neg, consequence, style) in enumerate(
        product(_SUBJECTS, _EPISTEMIC, _RELATIONS, _OBJECTS, _CONDITIONS, _NEG, _CONSEQUENCES, _STYLES)
    ):
        semantics = TextSemantics(
            subject=subject,
            epistemic=epistemic,
            relation=relation,
            object=obj,
            condition=condition,
            negated_implication=neg,
            consequence=consequence,
            style=style,
        )
        items.append(
            CorpusItem(
                text=render_fixture_text(semantics),
                metadata={"fixture_index": index, "grammar": "gsrt-reference-v0.1"},
            )
        )
        if len(items) == count:
            return items
    raise ValueError("requested corpus larger than deterministic fixture space")
