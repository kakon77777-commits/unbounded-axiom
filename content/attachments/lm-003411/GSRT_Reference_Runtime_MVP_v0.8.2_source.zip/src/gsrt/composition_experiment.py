from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from itertools import combinations
from pathlib import Path
from typing import Any

from .branches import BranchManager, PromotionGate
from .certificates import CertificateIssuer
from .composition import CompatibilityEngine, CompositionContract, FactorAssignment
from .db import RuntimeDB
from .dependencies import DependencyAuditor, DependencyPolicy
from .image_evaluation import ImageFidelityEvaluator
from .image_extraction import ReferenceImageSeedExtractor, decode_visual_compact
from .image_factors import FACTOR_SPECS, replace_factor
from .image_reconstruction import ReferenceImageReconstructor
from .image_semantics import ImageSemantics, analyze_reference_image, render_reference_image
from .library_experiment import LibraryExperimentRunner
from .models import ArtifactRecord, CompositionExperimentReport, SeedCandidate, ValidationCertificate

_FACTOR_NAMES = tuple(FACTOR_SPECS)
_SPECIFICITY_SIZES = {"k1": 1, "k2": 2, "k3": 3}


@dataclass(frozen=True)
class CompositionExperimentConfig:
    count: int = 96
    tasks_per_specificity: int = 32
    min_success_probability: float = 1.0


def _experiment_id(config: CompositionExperimentConfig) -> str:
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _factor_sets(size: int) -> tuple[tuple[str, ...], ...]:
    return tuple(combinations(_FACTOR_NAMES, size))


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _copy_seed_to_db(source_db: RuntimeDB, target_db: RuntimeDB, record: dict[str, Any], *, status: str | None = None) -> None:
    copied = dict(record)
    if status is not None:
        copied["status"] = status
    target_db.record_validated_seed(copied)
    for name, value in source_db.get_seed_factors(record["seed_id"]).items():
        target_db.record_seed_factor(record["seed_id"], name, value)


class CompositionExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.library_runner = LibraryExperimentRunner(self.root)
        self.library = self.library_runner.library
        self.extractor = ReferenceImageSeedExtractor(self.library.artifacts.read_bytes)
        self.reconstructor = ReferenceImageReconstructor(self.library.outputs)
        self.evaluator = ImageFidelityEvaluator(self.library.outputs.read_bytes)
        self.auditor = DependencyAuditor()
        self.issuer = CertificateIssuer(1.0)
        self.compatibility = CompatibilityEngine(self.library.db)
        self.branches = BranchManager(self.library.db)
        self.promotion = PromotionGate(self.library.db)

    def _choose_donors(
        self,
        records: list[dict[str, Any]],
        recipient: dict[str, Any],
        target_factors: tuple[str, ...],
        task_index: int,
    ) -> tuple[FactorAssignment, ...]:
        recipient_factors = self.library.db.get_seed_factors(recipient["seed_id"])
        used = {recipient["seed_id"]}
        assignments: list[FactorAssignment] = []
        ordered = sorted(records, key=lambda item: item["seed_id"])
        for offset, factor_name in enumerate(target_factors):
            candidates = [
                record
                for record in ordered
                if record["seed_id"] not in used
                and self.library.db.get_seed_factors(record["seed_id"])[factor_name]
                != recipient_factors[factor_name]
            ]
            if not candidates:
                raise ValueError(f"no distinct donor for factor: {factor_name}")
            donor = candidates[(task_index + offset) % len(candidates)]
            used.add(donor["seed_id"])
            assignments.append(FactorAssignment(factor_name, donor["seed_id"]))
        return tuple(assignments)

    def _realize_validate_promote(
        self,
        branch: dict[str, Any],
    ) -> tuple[dict[str, Any], ImageSemantics, bytes, bool]:
        candidate_semantics = decode_visual_compact(branch["candidate_payload"])
        candidate_png = render_reference_image(candidate_semantics)
        artifact = self.library.artifacts.ingest_bytes(
            candidate_png,
            "image",
            {
                "source_role": "composition-realized-artifact",
                "branch_id": branch["branch_id"],
                "grammar": "gsrt-reference-visual-v0.7",
            },
        )
        self.library.db.record_artifact(artifact)
        seed = self.extractor.extract(artifact, "visual_compact", 8)
        audit = self.auditor.audit(seed, DependencyPolicy.strict())
        reconstruction = self.reconstructor.reconstruct(seed, 0)
        evaluation = self.evaluator.evaluate(
            analyze_reference_image(candidate_png),
            candidate_png,
            reconstruction,
        )
        certificate = self.issuer.issue(seed, audit, [evaluation], self.reconstructor.generator_id)
        with self.library.db.batch():
            self.library.db.record_reconstruction_run(reconstruction)
            self.library.db.record_evaluation(evaluation)
        promoted = self.promotion.promote(branch["branch_id"], seed, certificate)
        return promoted, candidate_semantics, candidate_png, evaluation.passed

    @staticmethod
    def _round_trip(
        composed: ImageSemantics,
        recipient: ImageSemantics,
        target_factors: tuple[str, ...],
    ) -> ImageSemantics:
        restored = composed
        for factor_name in target_factors:
            restored = replace_factor(restored, factor_name, getattr(recipient, factor_name))
        return restored

    def _controls(self, initial_records: list[dict[str, Any]]) -> dict[str, float]:
        recipient = initial_records[0]
        donor = next(record for record in initial_records[1:] if record["seed_id"] != recipient["seed_id"])

        def control_db(name: str, *, donor_status: str = "REUSABLE") -> RuntimeDB:
            db = RuntimeDB(self.root / f"control-{name}.sqlite3")
            _copy_seed_to_db(self.library.db, db, recipient)
            _copy_seed_to_db(self.library.db, db, donor, status=donor_status)
            return db

        duplicate_db = control_db("duplicate")
        duplicate = CompatibilityEngine(duplicate_db).check(
            CompositionContract(
                recipient_seed_id=recipient["seed_id"],
                assignments=(
                    FactorAssignment("lighting", donor["seed_id"]),
                    FactorAssignment("lighting", donor["seed_id"]),
                ),
            )
        )

        protected_db = control_db("protected")
        protected = CompatibilityEngine(protected_db).check(
            CompositionContract(
                recipient_seed_id=recipient["seed_id"],
                assignments=(FactorAssignment("lighting", donor["seed_id"]),),
                protected_factors=("identity", "lighting"),
            )
        )

        unknown_db = control_db("unknown")
        unknown = CompatibilityEngine(unknown_db).check(
            CompositionContract(
                recipient_seed_id=recipient["seed_id"],
                assignments=(FactorAssignment("not_a_factor", donor["seed_id"]),),
            )
        )

        stale_db = control_db("stale", donor_status="STALE")
        stale = CompatibilityEngine(stale_db).check(
            CompositionContract(
                recipient_seed_id=recipient["seed_id"],
                assignments=(FactorAssignment("lighting", donor["seed_id"]),),
            )
        )

        def promotion_control(name: str, *, moved: bool, certificate_passed: bool) -> float:
            db = control_db(name)
            contract = CompositionContract(
                recipient_seed_id=recipient["seed_id"],
                assignments=(FactorAssignment("lighting", donor["seed_id"]),),
                protected_factors=tuple(f for f in _FACTOR_NAMES if f != "lighting"),
            )
            compatibility = CompatibilityEngine(db).check(contract)
            branch = BranchManager(db).create(contract, compatibility)
            if moved:
                moved_record = dict(db.get_validated_seed(recipient["seed_id"]) or {})
                moved_record["payload_hash"] = "control:moved"
                db.record_validated_seed(moved_record)
            artifact_id = f"artifact:control:{name}"
            db.record_artifact(ArtifactRecord(artifact_id, "image", f"hash:{name}", 1))
            seed = SeedCandidate(
                seed_id=f"seed:control:{name}",
                artifact_id=artifact_id,
                family="visual_compact",
                payload=branch["candidate_payload"],
                payload_bytes=8,
                budget_bytes=8,
            )
            certificate = ValidationCertificate(
                certificate_id=f"cert:control:{name}",
                seed_id=seed.seed_id,
                generator_scope="reference-image-reconstructor:v0.4",
                repeated_runs=1,
                success_probability=1.0 if certificate_passed else 0.0,
                dependency_passed=True,
                passed=certificate_passed,
            )
            try:
                PromotionGate(db).promote(branch["branch_id"], seed, certificate)
            except ValueError:
                return 1.0
            return 0.0

        return {
            "duplicate_target_rejected": float(duplicate.status == "FAIL"),
            "protected_overlap_rejected": float(protected.status == "FAIL"),
            "unknown_factor_rejected": float(unknown.status == "FAIL"),
            "stale_donor_rejected": float(stale.status == "FAIL"),
            "moved_base_promotion_blocked": promotion_control(
                "moved-base", moved=True, certificate_passed=True
            ),
            "failed_certificate_promotion_blocked": promotion_control(
                "failed-certificate", moved=False, certificate_passed=False
            ),
        }

    def run(self, config: CompositionExperimentConfig) -> CompositionExperimentReport:
        if config.count < 4:
            raise ValueError("composition experiment requires at least four artifacts")
        if config.tasks_per_specificity < 1:
            raise ValueError("tasks_per_specificity must be positive")

        initial_records = self.library_runner._build_library(config.count)
        initial_records = sorted(initial_records, key=lambda item: item["seed_id"])
        initial_snapshot = self.library.snapshot_digest()
        task_records: list[dict[str, Any]] = []
        isolation_violations = 0
        promoted_count = 0
        new_seed_count = 0
        existing_state_hit_count = 0

        pair_raw = {
            first: {second: {"total": 0, "passed": 0} for second in _FACTOR_NAMES}
            for first in _FACTOR_NAMES
        }

        for spec_index, (specificity, target_count) in enumerate(_SPECIFICITY_SIZES.items()):
            patterns = _factor_sets(target_count)
            for task_index in range(config.tasks_per_specificity):
                recipient = initial_records[(spec_index * config.tasks_per_specificity + task_index) % len(initial_records)]
                recipient_before = self.library.db.get_validated_seed(recipient["seed_id"])
                if recipient_before is None:
                    raise RuntimeError("recipient disappeared from library")
                recipient_semantics = decode_visual_compact(str(recipient_before["payload"]))
                target_factors = patterns[task_index % len(patterns)]
                assignments = self._choose_donors(
                    initial_records, recipient, target_factors, task_index + spec_index
                )
                protected_factors = tuple(name for name in _FACTOR_NAMES if name not in target_factors)
                contract = CompositionContract(
                    recipient_seed_id=recipient["seed_id"],
                    assignments=assignments,
                    protected_factors=protected_factors,
                    metadata={"specificity": specificity},
                )
                compatibility = self.compatibility.check(contract)
                if not compatibility.passed:
                    raise RuntimeError(f"primary composition unexpectedly incompatible: {compatibility.reasons}")
                branch = self.branches.create(contract, compatibility)
                promoted, composed_semantics, composed_png, evaluation_passed = self._realize_validate_promote(branch)
                promoted_count += int(promoted["status"] == "REUSABLE")
                persisted_branch = self.library.db.get_composition_branch(branch["branch_id"])
                if persisted_branch is None:
                    raise RuntimeError("promoted branch disappeared")
                promotion_mode = str(persisted_branch.get("promotion_mode", "UNKNOWN"))
                new_seed_count += int(promotion_mode == "NEW_REUSABLE")
                existing_state_hit_count += int(promotion_mode == "EXISTING_REUSABLE")

                target_transfer = _mean(
                    [
                        float(getattr(composed_semantics, name) == compatibility.resolved_values[name])
                        for name in target_factors
                    ]
                )
                protected_preservation = _mean(
                    [
                        float(getattr(composed_semantics, name) == getattr(recipient_semantics, name))
                        for name in protected_factors
                    ]
                )
                preservation_leakage = 1.0 - protected_preservation
                restored = self._round_trip(composed_semantics, recipient_semantics, target_factors)
                round_trip_semantic = float(restored == recipient_semantics)
                recipient_png = self.library.artifacts.read_bytes(recipient["artifact_id"])
                round_trip_pixel = float(render_reference_image(restored) == recipient_png)
                source_seed_unchanged = self.library.db.get_validated_seed(recipient["seed_id"]) == recipient_before
                isolation_violations += int(not source_seed_unchanged)
                composition_pass = float(
                    evaluation_passed
                    and target_transfer == 1.0
                    and protected_preservation == 1.0
                )

                if len(target_factors) == 2:
                    first, second = target_factors
                    for a, b in ((first, second), (second, first)):
                        pair_raw[a][b]["total"] += 1
                        pair_raw[a][b]["passed"] += int(composition_pass)

                task_id_raw = json.dumps(
                    {
                        "specificity": specificity,
                        "recipient": recipient["seed_id"],
                        "targets": target_factors,
                        "donors": [assignment.donor_seed_id for assignment in assignments],
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ).encode("utf-8")
                task_records.append(
                    {
                        "task_id": "sha256:" + hashlib.sha256(task_id_raw).hexdigest(),
                        "specificity": specificity,
                        "recipient_seed_id": recipient["seed_id"],
                        "branch_id": branch["branch_id"],
                        "promoted_seed_id": promoted["seed_id"],
                        "promotion_mode": promotion_mode,
                        "target_factors": list(target_factors),
                        "target_factor_count": len(target_factors),
                        "donor_seed_ids": [assignment.donor_seed_id for assignment in assignments],
                        "donor_count": len({assignment.donor_seed_id for assignment in assignments}),
                        "target_transfer": target_transfer,
                        "protected_preservation": protected_preservation,
                        "preservation_leakage": preservation_leakage,
                        "round_trip_semantic_exact": round_trip_semantic,
                        "round_trip_pixel_exact": round_trip_pixel,
                        "composition_pass": composition_pass,
                        "source_seed_unchanged": source_seed_unchanged,
                        "candidate_pixel_exact_to_realized_artifact": float(
                            render_reference_image(composed_semantics) == composed_png
                        ),
                    }
                )

        by_specificity: dict[str, dict[str, float]] = {}
        for specificity in _SPECIFICITY_SIZES:
            rows = [row for row in task_records if row["specificity"] == specificity]
            by_specificity[specificity] = {
                "total": float(len(rows)),
                "composition_pass_rate": _mean([float(row["composition_pass"]) for row in rows]),
                "mean_target_transfer": _mean([float(row["target_transfer"]) for row in rows]),
                "mean_protected_preservation": _mean(
                    [float(row["protected_preservation"]) for row in rows]
                ),
                "mean_preservation_leakage": _mean(
                    [float(row["preservation_leakage"]) for row in rows]
                ),
                "round_trip_semantic_exact_rate": _mean(
                    [float(row["round_trip_semantic_exact"]) for row in rows]
                ),
                "round_trip_pixel_exact_rate": _mean(
                    [float(row["round_trip_pixel_exact"]) for row in rows]
                ),
            }

        overall = {
            "composition_pass_rate": _mean([float(row["composition_pass"]) for row in task_records]),
            "mean_target_transfer": _mean([float(row["target_transfer"]) for row in task_records]),
            "mean_protected_preservation": _mean(
                [float(row["protected_preservation"]) for row in task_records]
            ),
            "mean_preservation_leakage": _mean(
                [float(row["preservation_leakage"]) for row in task_records]
            ),
            "round_trip_semantic_exact_rate": _mean(
                [float(row["round_trip_semantic_exact"]) for row in task_records]
            ),
            "round_trip_pixel_exact_rate": _mean(
                [float(row["round_trip_pixel_exact"]) for row in task_records]
            ),
        }
        pairwise_matrix = {
            first: {
                second: {
                    "total": float(values["total"]),
                    "passed": float(values["passed"]),
                    "pass_rate": values["passed"] / values["total"] if values["total"] else 0.0,
                }
                for second, values in row.items()
            }
            for first, row in pair_raw.items()
        }
        controls = self._controls(initial_records)
        return CompositionExperimentReport(
            experiment_id=_experiment_id(config),
            artifact_count=config.count,
            initial_library_seed_count=len(initial_records),
            task_count=len(task_records),
            promoted_seed_count=promoted_count,
            new_seed_count=new_seed_count,
            existing_state_hit_count=existing_state_hit_count,
            by_specificity=by_specificity,
            overall=overall,
            pairwise_composability_matrix=pairwise_matrix,
            controls=controls,
            branch_isolation_violations=isolation_violations,
            task_records=task_records,
            metadata={
                "experiment": "composition-mutation:v0.7",
                "evidence_level": "SYNTHETIC_VISUAL_COMPOSITION_REFERENCE",
                "real_world_composition_claim": False,
                "initial_library_snapshot": initial_snapshot,
                "factor_source": "validated-retrospective-image-seeds",
                "composition_semantics": "typed-factor-transfer-with-branch-isolation",
                "promotion_boundary": "passing-realized-artifact-certificate",
                "runtime_version": "0.7.0",
            },
        )
