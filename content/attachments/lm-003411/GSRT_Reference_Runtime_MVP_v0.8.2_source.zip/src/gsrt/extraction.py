from __future__ import annotations

import hashlib
import json
from collections.abc import Callable

from .models import ArtifactRecord, DependencyRef, SeedCandidate
from .reference_codebook import encode_compact
from .text_semantics import parse_fixture_text


def _truncate_utf8(text: str, budget_bytes: int) -> str:
    if budget_bytes < 0:
        raise ValueError("budget_bytes must be non-negative")
    raw = text.encode("utf-8")
    if len(raw) <= budget_bytes:
        return text
    raw = raw[:budget_bytes]
    while raw:
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            raw = raw[:-1]
    return ""


def _seed_id(artifact_id: str, family: str, payload: str, budget_bytes: int) -> str:
    material = json.dumps(
        {"artifact_id": artifact_id, "family": family, "payload": payload, "budget_bytes": budget_bytes},
        sort_keys=True,
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(material).hexdigest()


class ReferenceSeedExtractor:
    """Deterministic offline extractor for the reference fixture grammar.

    Real model adapters should implement the same conceptual interface without relying on
    fixture-specific parsing.
    """

    FAMILIES = ("summary", "keyword", "freeform", "structured", "compact")

    def __init__(self, source_reader: Callable[[str], str]):
        self.source_reader = source_reader

    def extract(self, artifact: ArtifactRecord, family: str, budget_bytes: int) -> SeedCandidate:
        if family not in self.FAMILIES:
            raise ValueError(f"unsupported seed family: {family}")
        source = self.source_reader(artifact.artifact_id)
        semantics = parse_fixture_text(source)

        if family == "summary":
            payload = source
        elif family == "keyword":
            payload = "|".join(
                [semantics.subject, semantics.object, semantics.condition, semantics.consequence]
            )
        elif family == "freeform":
            payload = (
                f"S:{semantics.subject};E:{semantics.epistemic};R:{semantics.relation};"
                f"O:{semantics.object};C:{semantics.condition};"
                f"N:{int(semantics.negated_implication)};Q:{semantics.consequence};T:{semantics.style}"
            )
        elif family == "structured":
            payload = json.dumps(
                {
                    "s": semantics.subject,
                    "e": semantics.epistemic,
                    "r": semantics.relation,
                    "o": semantics.object,
                    "c": semantics.condition,
                    "n": semantics.negated_implication,
                    "q": semantics.consequence,
                    "t": semantics.style,
                },
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            )
        else:
            payload = encode_compact(semantics)

        payload = _truncate_utf8(payload, budget_bytes)
        return SeedCandidate(
            seed_id=_seed_id(artifact.artifact_id, family, payload, budget_bytes),
            artifact_id=artifact.artifact_id,
            family=family,
            payload=payload,
            payload_bytes=len(payload.encode("utf-8")),
            budget_bytes=budget_bytes,
            dependencies=(DependencyRef("SHARED_BASELINE", "reference-fixture-grammar:v0.2", 0),),
            metadata={
                "extractor": "reference-deterministic:v0.2",
                "shared_codebook": "reference-compact-codebook:v0.2" if family == "compact" else None,
            },
        )
