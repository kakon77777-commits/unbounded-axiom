from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .db import RuntimeDB
from .library_experiment import LibraryExperimentRunner
from .qd import BehaviorDescriptorSchema, QDArchive


@dataclass(frozen=True)
class QDExperimentConfig:
    initial_count: int = 96
    candidate_budget: int = 243

    def __post_init__(self) -> None:
        if self.initial_count < 1:
            raise ValueError("initial_count must be positive")
        if self.candidate_budget < 1:
            raise ValueError("candidate_budget must be positive")


@dataclass(frozen=True)
class QDExperimentReport:
    experiment_id: str
    initial_library_seed_count: int
    candidate_budget: int
    validated_candidate_count: int
    single_best: dict[str, float]
    qd_archive: dict[str, float]
    controls: dict[str, float]
    metadata: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        return {
            "experiment_id": self.experiment_id,
            "initial_library_seed_count": self.initial_library_seed_count,
            "candidate_budget": self.candidate_budget,
            "validated_candidate_count": self.validated_candidate_count,
            "single_best": dict(self.single_best),
            "qd_archive": dict(self.qd_archive),
            "controls": dict(self.controls),
            "metadata": dict(self.metadata),
        }


def _experiment_id(config: QDExperimentConfig) -> str:
    raw = json.dumps(asdict(config), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


class QDExperimentRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.library_runner = LibraryExperimentRunner(self.root)
        self.library = self.library_runner.library
        self.schema = BehaviorDescriptorSchema.visual_v081()

    def _niche_key(self, seed_id: str) -> str:
        factors = self.library.db.get_seed_factors(seed_id)
        return "|".join(factors[name] for name in self.schema.dimensions)

    def _empty_niche_first_stream(self, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        groups: dict[str, list[dict[str, Any]]] = {}
        for record in sorted(records, key=lambda item: str(item["seed_id"])):
            groups.setdefault(self._niche_key(str(record["seed_id"])), []).append(record)
        first_round = [groups[key][0] for key in sorted(groups)]
        remainder: list[dict[str, Any]] = []
        for key in sorted(groups):
            remainder.extend(groups[key][1:])
        remainder.sort(key=lambda item: str(item["seed_id"]))
        return first_round + remainder

    def _seed_descriptor_matches_niche(self, seed_id: str, niche_key: str) -> bool:
        return self._niche_key(seed_id) == niche_key

    def _archive_goal_coverage(self, archive: QDArchive) -> float:
        hits = sum(
            self._seed_descriptor_matches_niche(cell.elite_seed_id, cell.niche_key)
            for cell in archive.cells()
        )
        return hits / len(self.schema.all_niches())

    def _descriptor_shuffle_control(self, records: list[dict[str, Any]]) -> tuple[float, float]:
        niches = self.schema.all_niches()
        shifted = {niche: niches[(index + 1) % len(niches)] for index, niche in enumerate(niches)}
        cells: dict[str, str] = {}
        for record in records:
            seed_id = str(record["seed_id"])
            destination = shifted[self._niche_key(seed_id)]
            current = cells.get(destination)
            if current is None or seed_id < current:
                cells[destination] = seed_id
        archive_coverage = len(cells) / len(niches)
        hits = sum(self._niche_key(seed_id) == niche for niche, seed_id in cells.items())
        return archive_coverage, hits / len(niches)

    def _novelty_only_invalid_control(self, records: list[dict[str, Any]]) -> float:
        if not records:
            return 0.0
        control_db = RuntimeDB(self.root / "qd-invalid-control.sqlite3")
        source = records[0]
        stale = dict(source)
        stale["status"] = "STALE"
        control_db.record_validated_seed(stale)
        for name, value in self.library.db.get_seed_factors(str(source["seed_id"])).items():
            control_db.record_seed_factor(str(source["seed_id"]), name, value)
        archive = QDArchive(control_db, self.schema)
        try:
            archive.consider(str(source["seed_id"]), quality=1.0)
        except ValueError:
            return 0.0
        return 1.0

    def _single_best_metrics(self, records: list[dict[str, Any]]) -> dict[str, float]:
        if not records:
            return {
                "filled_niches": 0.0,
                "coverage": 0.0,
                "qd_score": 0.0,
                "mean_quality": 0.0,
                "mean_novelty": 0.0,
                "goal_coverage": 0.0,
            }
        winner = min(records, key=lambda item: str(item["seed_id"]))
        niche = self._niche_key(str(winner["seed_id"]))
        return {
            "filled_niches": 1.0,
            "coverage": 1 / len(self.schema.all_niches()),
            "qd_score": 1.0,
            "mean_quality": 1.0,
            "mean_novelty": 0.0,
            "goal_coverage": float(
                self._seed_descriptor_matches_niche(str(winner["seed_id"]), niche)
            )
            / len(self.schema.all_niches()),
        }

    def run(self, config: QDExperimentConfig) -> QDExperimentReport:
        records = self.library_runner._build_library(config.initial_count)
        snapshot_before = self.library.snapshot_digest()
        stream = self._empty_niche_first_stream(records)
        candidates = stream[: min(config.candidate_budget, len(stream))]

        archive = QDArchive(self.library.db, self.schema)
        for record in candidates:
            archive.consider(str(record["seed_id"]), quality=1.0)

        stats = archive.stats()
        primary_coverage = archive.coverage()
        if candidates:
            duplicate_seed = str(candidates[0]["seed_id"])
            for _ in range(10):
                archive.consider(duplicate_seed, quality=1.0)
        duplicate_coverage_inflation = archive.coverage() - primary_coverage
        shuffle_archive_coverage, shuffle_goal_coverage = self._descriptor_shuffle_control(candidates)
        novelty_only_invalid_admissions = self._novelty_only_invalid_control(candidates)
        snapshot_after = self.library.snapshot_digest()

        qd_metrics = {
            "filled_niches": float(stats.filled_niches),
            "coverage": stats.coverage,
            "qd_score": stats.qd_score,
            "mean_quality": stats.mean_quality,
            "mean_novelty": stats.mean_novelty,
            "goal_coverage": self._archive_goal_coverage(archive),
        }
        return QDExperimentReport(
            experiment_id=_experiment_id(config),
            initial_library_seed_count=len(records),
            candidate_budget=config.candidate_budget,
            validated_candidate_count=len(candidates),
            single_best=self._single_best_metrics(candidates),
            qd_archive=qd_metrics,
            controls={
                "duplicate_coverage_inflation": duplicate_coverage_inflation,
                "seedstore_mutation_violations": float(snapshot_before != snapshot_after),
                "descriptor_shuffle_archive_coverage": shuffle_archive_coverage,
                "descriptor_shuffle_goal_coverage": shuffle_goal_coverage,
                "novelty_only_invalid_admissions": novelty_only_invalid_admissions,
            },
            metadata={
                "runtime_version": "0.8.1",
                "evidence_level": "SYNTHETIC_VISUAL_QUALITY_DIVERSITY",
                "real_world_qd_claim": False,
                "candidate_source": "validated_reusable_seed_memory",
                "descriptor_id": self.schema.descriptor_id,
                "descriptor_version": self.schema.version,
                "target_niche_count": len(self.schema.all_niches()),
                "scheduler": "deterministic-empty-niche-first:v0.8.1",
                "quality_policy": "validated-reusable-reference-integrity:v0.8.1",
            },
        )
