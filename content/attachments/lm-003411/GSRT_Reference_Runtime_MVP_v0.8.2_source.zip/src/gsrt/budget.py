from __future__ import annotations

import hashlib
import json
import statistics
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .corpus import generate_reference_corpus
from .experiment import ExperimentConfig, ExperimentRunner
from .models import BudgetSweepReport


DEFAULT_BUDGETS = (
    512,
    256,
    160,
    144,
    140,
    136,
    132,
    128,
    124,
    120,
    116,
    112,
    108,
    104,
    96,
    80,
    64,
    48,
    32,
    24,
    16,
    12,
    10,
    9,
    8,
    7,
    6,
    5,
    4,
)


@dataclass(frozen=True)
class BudgetSweepConfig:
    count: int = 120
    budgets: tuple[int, ...] = DEFAULT_BUDGETS
    repetitions: int = 2
    families: tuple[str, ...] = ("summary", "keyword", "freeform", "structured", "compact")
    min_success_probability: float = 1.0
    near_minimal_eta_bytes: int = 4


def _artifact_ids(count: int) -> set[str]:
    ids: set[str] = set()
    for item in generate_reference_corpus(count):
        digest = hashlib.sha256(item.text.encode("utf-8")).hexdigest()
        ids.add(f"sha256:{digest}")
    return ids


def _cliff(points: list[dict[str, Any]]) -> dict[str, Any] | None:
    best: dict[str, Any] | None = None
    for upper, lower in zip(points, points[1:]):
        pass_drop = max(0.0, float(upper["pass_rate"]) - float(lower["pass_rate"]))
        fidelity_drop = max(
            0.0,
            float(upper.get("mean_overall", 0.0)) - float(lower.get("mean_overall", 0.0)),
        )
        candidate = {
            "upper_budget": int(upper["budget_bytes"]),
            "lower_budget": int(lower["budget_bytes"]),
            "pass_rate_drop": pass_drop,
            "mean_overall_drop": fidelity_drop,
        }
        if best is None or (pass_drop, fidelity_drop) > (
            best["pass_rate_drop"],
            best["mean_overall_drop"],
        ):
            best = candidate
    if best is None or (
        best["pass_rate_drop"] <= 0.0 and best["mean_overall_drop"] <= 0.0
    ):
        return None
    return best


def _summary(values: list[dict[str, Any]], family: str) -> dict[str, Any]:
    resolved = [row for row in values if row["min_budget_bytes"] is not None]
    unresolved = len(values) - len(resolved)
    result: dict[str, Any] = {
        "family": family,
        "resolved": len(resolved),
        "unresolved": unresolved,
    }
    if not resolved:
        result.update(
            {
                "min_budget_min": None,
                "min_budget_max": None,
                "min_budget_mean": None,
                "min_budget_median": None,
                "min_payload_min": None,
                "min_payload_max": None,
                "min_payload_mean": None,
                "min_payload_median": None,
                "min_adjusted_cost_min": None,
                "min_adjusted_cost_max": None,
                "compression_gain_mean": None,
                "compression_gain_median": None,
                "min_budget_histogram": {},
            }
        )
        return result

    budgets = [int(row["min_budget_bytes"]) for row in resolved]
    payloads = [int(row["min_payload_bytes"]) for row in resolved]
    adjusted = [int(row["min_adjusted_cost_bytes"]) for row in resolved]
    gains = [float(row["compression_gain"]) for row in resolved if row["compression_gain"] is not None]
    histogram: dict[str, int] = {}
    for value in budgets:
        key = str(value)
        histogram[key] = histogram.get(key, 0) + 1
    result.update(
        {
            "min_budget_min": min(budgets),
            "min_budget_max": max(budgets),
            "min_budget_mean": statistics.fmean(budgets),
            "min_budget_median": float(statistics.median(budgets)),
            "min_payload_min": min(payloads),
            "min_payload_max": max(payloads),
            "min_payload_mean": statistics.fmean(payloads),
            "min_payload_median": float(statistics.median(payloads)),
            "min_adjusted_cost_min": min(adjusted),
            "min_adjusted_cost_max": max(adjusted),
            "compression_gain_mean": statistics.fmean(gains) if gains else None,
            "compression_gain_median": float(statistics.median(gains)) if gains else None,
            "min_budget_histogram": histogram,
        }
    )
    return result


class BudgetSweepRunner:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.runner = ExperimentRunner(self.root)

    def run(self, config: BudgetSweepConfig) -> BudgetSweepReport:
        if config.count < 1:
            raise ValueError("count must be positive")
        if config.repetitions < 1:
            raise ValueError("repetitions must be positive")
        if config.near_minimal_eta_bytes < 0:
            raise ValueError("near_minimal_eta_bytes must be non-negative")
        if not config.budgets:
            raise ValueError("budgets must not be empty")
        if any(budget <= 0 for budget in config.budgets):
            raise ValueError("budgets must be positive")
        if len(set(config.budgets)) != len(config.budgets):
            raise ValueError("budgets must be unique")

        budgets = tuple(sorted(config.budgets, reverse=True))
        control_budget = max(budgets)
        curves: dict[str, list[dict[str, Any]]] = {family: [] for family in config.families}
        control_stats: dict[str, dict[str, float]] = {}
        visibility_violations = 0
        certificate_passed = 0
        certificate_total = 0

        for budget in budgets:
            with self.runner.db.batch():
                report = self.runner.run(
                    ExperimentConfig(
                        count=config.count,
                        budget_bytes=budget,
                        repetitions=config.repetitions,
                        families=config.families,
                        min_success_probability=config.min_success_probability,
                        include_controls=budget == control_budget,
                    )
                )
            visibility_violations += report.source_visibility_violations
            certificate_passed += report.certificate_passed
            certificate_total += report.certificate_total
            if budget == control_budget:
                control_stats = report.control_stats
            for family in config.families:
                curves[family].append(
                    {
                        "budget_bytes": budget,
                        **report.family_stats[family],
                    }
                )

        expected_artifacts = _artifact_ids(config.count)
        outcomes = [
            row
            for row in self.runner.db.seed_certificate_outcomes()
            if row["artifact_id"] in expected_artifacts
            and row["family"] in config.families
            and row["budget_bytes"] in budgets
        ]
        grouped: dict[tuple[str, str], list[dict[str, Any]]] = {}
        for row in outcomes:
            grouped.setdefault((row["artifact_id"], row["family"]), []).append(row)

        artifact_minima: list[dict[str, Any]] = []
        for artifact_id in sorted(expected_artifacts):
            for family in config.families:
                rows = grouped.get((artifact_id, family), [])
                passing = [row for row in rows if row["passed"]]
                source_bytes = rows[0]["source_bytes"] if rows else len(
                    self.runner.artifacts.read_text(artifact_id).encode("utf-8")
                )
                if not passing:
                    artifact_minima.append(
                        {
                            "artifact_id": artifact_id,
                            "family": family,
                            "source_bytes": source_bytes,
                            "min_budget_bytes": None,
                            "min_payload_bytes": None,
                            "min_adjusted_cost_bytes": None,
                            "compression_gain": None,
                            "near_minimal_points": [],
                        }
                    )
                    continue

                min_budget = min(int(row["budget_bytes"]) for row in passing)
                min_payload = min(int(row["payload_bytes"]) for row in passing)
                min_adjusted = min(int(row["adjusted_cost_bytes"]) for row in passing)
                near = [
                    {
                        "budget_bytes": int(row["budget_bytes"]),
                        "payload_bytes": int(row["payload_bytes"]),
                        "adjusted_cost_bytes": int(row["adjusted_cost_bytes"]),
                        "success_probability": float(row["success_probability"]),
                    }
                    for row in passing
                    if int(row["adjusted_cost_bytes"])
                    <= min_adjusted + config.near_minimal_eta_bytes
                ]
                near.sort(key=lambda item: (-item["budget_bytes"], item["adjusted_cost_bytes"]))
                artifact_minima.append(
                    {
                        "artifact_id": artifact_id,
                        "family": family,
                        "source_bytes": source_bytes,
                        "min_budget_bytes": min_budget,
                        "min_payload_bytes": min_payload,
                        "min_adjusted_cost_bytes": min_adjusted,
                        "compression_gain": source_bytes / min_adjusted if min_adjusted else None,
                        "near_minimal_points": near,
                    }
                )

        minimums = {
            family: _summary(
                [row for row in artifact_minima if row["family"] == family],
                family,
            )
            for family in config.families
        }
        cliffs = {family: _cliff(curves[family]) for family in config.families}

        config_material = json.dumps(
            asdict(config),
            sort_keys=True,
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        sweep_id = "sha256:" + hashlib.sha256(config_material).hexdigest()
        return BudgetSweepReport(
            sweep_id=sweep_id,
            artifact_count=config.count,
            budgets=budgets,
            families=config.families,
            curves=curves,
            minimums=minimums,
            artifact_minima=artifact_minima,
            cliffs=cliffs,
            control_budget_bytes=control_budget,
            control_stats=control_stats,
            source_visibility_violations=visibility_violations,
            certificate_passed=certificate_passed,
            certificate_total=certificate_total,
            metadata={
                "evidence_level": "OFFLINE_REFERENCE_FIXTURE",
                "empirical_minimum": "smallest tested passing budget; payload cost reported separately",
                "near_minimal_eta_bytes": config.near_minimal_eta_bytes,
                "control_budget_bytes": control_budget,
                "compact_family_boundary": "shared deterministic fixture codebook; not a universal codec",
            },
        )
