# GSRT Reference Runtime v0.8.2

Reference implementation for the **Generative Seed Reconstruction Theory (GSRT)** experimental program.

v0.8.2 adds a matched-budget **Heterogeneous Mutation Fleet** experiment on top of the v0.8.1 Quality-Diversity archive. The release asks a narrow question: under the same validated candidate budget, does a fleet of complementary mutation priors explore more useful behavior niches than homogeneous mutation priors?

## Recovery provenance

The previous v0.8.2 scientific run completed, but its unuploaded final source/Git workspace was lost in a CaaS reset. This release was reconstructed from the verified v0.8.1 source release (`9f975c00662e063b2c74698f2316cf952d7f6f94f762e81c38900311e84c3d1e`) and the frozen v0.8.2 protocol/evidence record. The reconstructed runtime reproduces the original formal experiment ID and measured results exactly. Git ancestry is therefore labeled as an imported release lineage rather than pretending the erased original branch still exists.

## Scientific boundary

Evidence level:

```text
SYNTHETIC_MUTATION_PRIOR_FLEET
```

This is **not** independent cross-model or cross-provider evidence. All candidates are generated inside the deterministic synthetic visual grammar introduced in v0.4. The experiment isolates mutation-prior diversity, not vendor/model identity.

Core boundary:

```text
Different worker labels != heterogeneous search
Different mutation priors may alter finite-budget search trajectories
Synthetic mutation-prior advantage != real-model fleet superiority
```

## Matched conditions

All four conditions use exactly:

```text
32 paired trials
30 candidates per trial
3 workers
reference cost per candidate = 5
150 reference operations per condition/trial
same starting validated seed
same retrospective validation pipeline
same QD descriptor/archive logic
```

Only the mutation priors differ.

Prior order is `(style, composition, camera)`:

```text
homogeneous_balanced
  worker 1 = (1/3, 1/3, 1/3)
  worker 2 = (1/3, 1/3, 1/3)
  worker 3 = (1/3, 1/3, 1/3)

homogeneous_biased
  worker 1..3 = (0.8, 0.1, 0.1)

heterogeneous_complementary
  style specialist       = (0.8, 0.1, 0.1)
  composition specialist = (0.1, 0.8, 0.1)
  camera specialist      = (0.1, 0.1, 0.8)

label_only_control
  three different worker labels
  all priors = (1/3, 1/3, 1/3)
```

Worker labels and condition names do not enter deterministic proposal RNG.

## Candidate validation

Every mutation attempt follows:

```text
select current QD elite
-> propose exactly one descriptor-factor mutation
-> render finished PNG
-> retrospective compact-seed extraction
-> blind reconstruction
-> image fidelity evaluation
-> passing certificate
-> reusable SeedStore identity/dedup
-> QD archive consideration
```

Duplicate states consume budget/cost but reuse existing seed identity and append `mutated_from` lineage rather than overwriting provenance.

## Formal release result

Formal experiment ID:

```text
sha256:964285b6e5817d77b00d9ac3528f74d9b2e3442ca9546eb8da36879b53411048
```

Total validated mutation attempts:

```text
32 trials x 30 candidates x 4 conditions = 3840
```

| Metric | Homogeneous balanced | Heterogeneous complementary | Homogeneous biased |
|---|---:|---:|---:|
| Mean filled niches | 16.03125 | **17.28125** | 11.3125 |
| Coverage | 0.593750 | **0.640046** | 0.418981 |
| Mean novelty | 0.668436 | **0.678553** | 0.607560 |
| Valid admission rate | 1.000000 | 1.000000 | 1.000000 |
| Duplicate rate | 0.498958 | **0.457292** | 0.656250 |
| Archive acceptance | 0.501042 | **0.542708** | 0.343750 |
| Reference cost | 150 | 150 | 150 |

Primary paired result, heterogeneous complementary minus homogeneous balanced:

```text
mean coverage delta = +0.046296296296296294
95% normal-approx CI = [0.013701260002548253, 0.07889133259004433]
wins / ties / losses = 21 / 4 / 7
```

Stress comparison against the narrow homogeneous bias:

```text
coverage delta = +0.22106481481481483
```

The stress comparison is not the primary headline; the balanced homogeneous fleet is the stronger matched baseline.

## Important interpretation

The complementary heterogeneous priors have the same aggregate marginal over the three mutation dimensions as the balanced homogeneous fleet:

```text
mean heterogeneous prior = (1/3, 1/3, 1/3)
homogeneous balanced      = (1/3, 1/3, 1/3)
```

Yet their finite-budget trajectories differ because specialist workers interact with the evolving QD archive and parent-selection history. Therefore this reference runtime observes:

```text
Same aggregate mutation marginal != same finite-budget search trajectory
```

This is an operational observation in the synthetic runtime, not a universal theorem.

## Controls

```text
label-only control == homogeneous-balanced aggregate EXACT
matched candidate budget = PASS
matched reference cost = PASS
matched valid-admission rate = PASS
oracle enumeration coverage = 1.0
```

The oracle knows the complete 27-niche map and is explicitly **not a matched fleet competitor**.

## Runtime additions

```text
MutationPrior
FleetWorker
MutationProposal
mutate_descriptor
MutationValidator
ValidatedMutation
FleetExperimentConfig
FleetExperimentRunner
FleetExperimentReport
export_fleet_bundle
fleet-run CLI
```

QD persistence was also tightened so one accepted archive update plus full novelty refresh executes in one atomic SQLite batch transaction. This is a persistence/performance change only; it does not alter QD metrics, priors, or admission semantics.

## Quickstart

```bash
python -m pip install gsrt_reference_runtime-0.8.2-py3-none-any.whl

gsrt fleet-run \
  --root .gsrt-fleet \
  --trials 32 \
  --candidate-budget 30 \
  --experiment-seed gsrt-v0.8.2 \
  --out fleet-report.json \
  --bundle fleet-bundle
```

## Next stage

v0.9 moves away from search-policy experiments and begins the optional **Canonical / ISQL Adapter** boundary. The scientific GSRT evidence and canonical protocol conformance remain separate validation tracks.
