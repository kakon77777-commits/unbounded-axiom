from __future__ import annotations

import csv
import json
import math
import statistics
import time
from pathlib import Path

from mmpf_prototype import (
    adpms_factor,
    adpms_prime_registry,
    mmpf_factor,
    naive_odd_factor,
)

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
CERTS = ROOT / "certificates"
RESULTS.mkdir(exist_ok=True)
CERTS.mkdir(exist_ok=True)

CASES = {
    "small_prime": 99991,
    "prime_square": 99991**2,
    "close_semiprime_1e10": 104729 * 104759,
    "close_semiprime_1e12": 1000003 * 1000033,
    "many_small_factors": (2**10) * (3**5) * (5**2) * 7 * 11,
    "carmichael_like": 3215031751,
    "project_euler_3": 600851475143,
    "large_prime": 1000000007,
}

REPEATS = 7
BLOCK_SIZES = [16, 64, 256]


def timed_call(fn, *args, repeats=REPEATS, **kwargs):
    times = []
    last = None
    for _ in range(repeats):
        start = time.perf_counter_ns()
        last = fn(*args, **kwargs)
        elapsed = (time.perf_counter_ns() - start) / 1_000_000
        times.append(elapsed)
    return statistics.median(times), min(times), last


max_limit = max(math.isqrt(n) for n in CASES.values())
registry_start = time.perf_counter_ns()
prime_registry, registry_stats = adpms_prime_registry(max_limit)
registry_ms = (time.perf_counter_ns() - registry_start) / 1_000_000

rows = []
all_outputs = {}

for case_name, n in CASES.items():
    baseline_ms, baseline_min, (baseline_factors, baseline_stats) = timed_call(naive_odd_factor, n)
    adpms_ms, adpms_min, (adpms_factors, adpms_stats) = timed_call(adpms_factor, n)

    if baseline_factors != adpms_factors:
        raise AssertionError(f"baseline/adpms mismatch for {case_name}")

    for block_size in BLOCK_SIZES:
        mmpf_ms, mmpf_min, (mmpf_factors, mmpf_stats, cert) = timed_call(
            mmpf_factor,
            n,
            prime_registry,
            block_size,
            False,
        )
        if mmpf_factors != baseline_factors:
            raise AssertionError(f"MMPF mismatch for {case_name}, block {block_size}")

        row = {
            "case": case_name,
            "n": n,
            "digits": len(str(n)),
            "method": f"mmpf_b{block_size}",
            "median_ms": round(mmpf_ms, 6),
            "min_ms": round(mmpf_min, 6),
            "candidate_tests": mmpf_stats.candidate_tests,
            "divisions": mmpf_stats.divisions,
            "modular_multiplications": mmpf_stats.modular_multiplications,
            "gcd_calls": mmpf_stats.gcd_calls,
            "blocks": mmpf_stats.blocks,
            "excluded_candidates": mmpf_stats.excluded_candidates,
            "investigated_candidates": mmpf_stats.investigated_candidates,
            "events": mmpf_stats.events,
            "factors": json.dumps(mmpf_factors, sort_keys=True),
        }
        rows.append(row)

    rows.extend([
        {
            "case": case_name,
            "n": n,
            "digits": len(str(n)),
            "method": "naive_odd",
            "median_ms": round(baseline_ms, 6),
            "min_ms": round(baseline_min, 6),
            "candidate_tests": baseline_stats.candidate_tests,
            "divisions": baseline_stats.divisions,
            "modular_multiplications": 0,
            "gcd_calls": 0,
            "blocks": 0,
            "excluded_candidates": 0,
            "investigated_candidates": 0,
            "events": 0,
            "factors": json.dumps(baseline_factors, sort_keys=True),
        },
        {
            "case": case_name,
            "n": n,
            "digits": len(str(n)),
            "method": "adpms_6k",
            "median_ms": round(adpms_ms, 6),
            "min_ms": round(adpms_min, 6),
            "candidate_tests": adpms_stats.candidate_tests,
            "divisions": adpms_stats.divisions,
            "modular_multiplications": 0,
            "gcd_calls": 0,
            "blocks": 0,
            "excluded_candidates": 0,
            "investigated_candidates": 0,
            "events": 0,
            "factors": json.dumps(adpms_factors, sort_keys=True),
        },
    ])

    # Write one full certificate per case at the default block size.
    factors, stats, cert = mmpf_factor(n, prime_registry, 64, True)
    (CERTS / f"{case_name}.mmpf-cert.json").write_text(
        json.dumps(cert, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    all_outputs[case_name] = {
        "n": n,
        "factors": factors,
        "certificate": str(CERTS / f"{case_name}.mmpf-cert.json"),
    }

csv_path = RESULTS / "benchmark_results.csv"
with csv_path.open("w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

json_path = RESULTS / "benchmark_results.json"
json_path.write_text(
    json.dumps({
        "registry": {
            **registry_stats,
            "build_ms": registry_ms,
        },
        "repeats": REPEATS,
        "block_sizes": BLOCK_SIZES,
        "cases": CASES,
        "rows": rows,
    }, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

# Aggregate method medians across cases.
methods = sorted({r["method"] for r in rows})
aggregate = {}
for method in methods:
    subset = [r for r in rows if r["method"] == method]
    aggregate[method] = {
        "total_median_ms": sum(r["median_ms"] for r in subset),
        "total_candidate_tests": sum(r["candidate_tests"] for r in subset),
        "total_divisions": sum(r["divisions"] for r in subset),
        "total_modular_multiplications": sum(r["modular_multiplications"] for r in subset),
        "total_gcd_calls": sum(r["gcd_calls"] for r in subset),
        "total_excluded_candidates": sum(r["excluded_candidates"] for r in subset),
    }

best_mmpf = min(
    (m for m in methods if m.startswith("mmpf_")),
    key=lambda m: aggregate[m]["total_median_ms"],
)

report = []
report.append("# MMPF v0.1 第一輪實驗報告\n")
report.append("## 測試設計\n")
report.append(f"- 測試案例：{len(CASES)} 個固定整數")
report.append(f"- 每個方法重複：{REPEATS} 次，報告中位數")
report.append(f"- ADPMS 質數登錄上限：{max_limit:,}")
report.append(f"- 質數登錄建置時間：{registry_ms:.3f} ms")
report.append(f"- 登錄質數數量：{registry_stats['prime_count']:,}")
report.append("- MMPF 使用共享質數登錄；表中 MMPF 時間屬於 warm runtime，未重複計入登錄建置。")
report.append("- MMPF 同時產生追加式事件與重建證書，因此不能只與裸試除的時間直接等價。\n")

report.append("## 聚合結果\n")
report.append("| 方法 | 8 案例中位時間合計 ms | 候選級測試 | 除法 | 模乘 | GCD | 區塊排除候選 |")
report.append("|---|---:|---:|---:|---:|---:|---:|")
for method in methods:
    a = aggregate[method]
    report.append(
        f"| {method} | {a['total_median_ms']:.3f} | {a['total_candidate_tests']:,} | "
        f"{a['total_divisions']:,} | {a['total_modular_multiplications']:,} | "
        f"{a['total_gcd_calls']:,} | {a['total_excluded_candidates']:,} |"
    )

report.append("\n## 各案例結果\n")
report.append("| 案例 | N | 因數 | naive ms | ADPMS ms | 最佳 MMPF ms | 最佳 MMPF |")
report.append("|---|---:|---|---:|---:|---:|---|")
for case_name, n in CASES.items():
    case_rows = [r for r in rows if r["case"] == case_name]
    naive = next(r for r in case_rows if r["method"] == "naive_odd")
    adpms = next(r for r in case_rows if r["method"] == "adpms_6k")
    mmpfs = [r for r in case_rows if r["method"].startswith("mmpf_")]
    best = min(mmpfs, key=lambda r: r["median_ms"])
    report.append(
        f"| {case_name} | {n:,} | `{naive['factors']}` | "
        f"{naive['median_ms']:.3f} | {adpms['median_ms']:.3f} | "
        f"{best['median_ms']:.3f} | {best['method']} |"
    )

report.append("\n## 初步判讀\n")
report.append(f"1. 本批資料中聚合時間最快的 MMPF 區塊大小是 **{best_mmpf}**。")
report.append("2. ADPMS 的主要收益是減少候選級除法；對需要掃到接近平方根的質數或半質數，效果最明顯。")
report.append("3. MMPF block-GCD 能用一個 GCD 證明整個質數區塊都不含因數，因此候選級除法數大幅下降；代價是每個候選仍需一次模乘，並增加 GCD、事件與證書成本。")
report.append("4. 對小因數很多的整數，序列法的早停與快速殘值下降通常更便宜，MMPF 的區塊與帳本開銷可能不划算。")
report.append("5. 對質數、質數平方與接近平方根的半質數，MMPF 最能展示『整區排除』，但 Python 標準函式庫原型未必在牆鐘時間上勝過裸除法。")
report.append("6. 因此第一輪結果主要支持：MMPF 確實提供候選區塊淘汰、重播與證書價值；尚不能據此宣稱一般速度突破。\n")

report.append("## 可證偽結論\n")
report.append("- 所有方法的質因數結果一致，重建檢查全部通過。")
report.append("- MMPF 的區塊排除是真實可驗證的，不是名稱重包裝。")
report.append("- MMPF 是否更快取決於整數類型、區塊大小、語言實現與是否能利用真正 SIMD／GPU／多程序。")
report.append("- 下一輪應把 block product／GCD 改為產品樹或 NumPy／C／GPU 核心，再測 warm registry 與 batch factorization。")

report_path = RESULTS / "MMPF_v0.1_第一輪實驗報告.md"
report_path.write_text("\n".join(report), encoding="utf-8")

summary_path = RESULTS / "summary.json"
summary_path.write_text(
    json.dumps({
        "best_mmpf_method": best_mmpf,
        "registry_build_ms": registry_ms,
        "aggregate": aggregate,
        "outputs": all_outputs,
    }, ensure_ascii=False, indent=2),
    encoding="utf-8",
)

print(json.dumps({
    "registry_build_ms": round(registry_ms, 3),
    "registry_prime_count": registry_stats["prime_count"],
    "best_mmpf": best_mmpf,
    "aggregate": aggregate,
    "report": str(report_path),
}, ensure_ascii=False, indent=2))
