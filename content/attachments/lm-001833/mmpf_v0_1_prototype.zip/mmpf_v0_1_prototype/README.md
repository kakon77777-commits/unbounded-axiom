# MMPF v0.1 Prototype

第一輪可執行原型，包含：

- `naive_odd_factor`：標準奇數試除基準；
- `adpms_factor`：6k±1 序列候選；
- `adpms_prime_registry`：ADPMS／wheel 質數登錄；
- `mmpf_factor`：block-GCD 候選矩陣篩選、事件鏈與重建證書；
- 8 類固定測試整數；
- 16／64／256 三種區塊大小比較。

執行：

```bash
python benchmark_mmpf.py
```

結果位於 `results/`，完整證書位於 `certificates/`。
