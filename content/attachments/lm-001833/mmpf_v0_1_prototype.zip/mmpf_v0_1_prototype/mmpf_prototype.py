from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, asdict
from typing import Dict, Iterable, List, Sequence, Tuple


@dataclass
class OpStats:
    candidate_tests: int = 0
    divisions: int = 0
    modular_multiplications: int = 0
    gcd_calls: int = 0
    blocks: int = 0
    excluded_candidates: int = 0
    investigated_candidates: int = 0
    events: int = 0


def factor_product(factors: Dict[int, int]) -> int:
    value = 1
    for p, e in factors.items():
        value *= p ** e
    return value


def naive_odd_factor(n: int) -> Tuple[Dict[int, int], OpStats]:
    if n < 2:
        raise ValueError("n must be >= 2")
    original = n
    factors: Dict[int, int] = {}
    stats = OpStats()

    for p in (2,):
        stats.candidate_tests += 1
        stats.divisions += 1
        if n % p == 0:
            e = 0
            while n % p == 0:
                stats.divisions += 1
                n //= p
                e += 1
            factors[p] = e

    p = 3
    while p * p <= n:
        stats.candidate_tests += 1
        stats.divisions += 1
        if n % p == 0:
            e = 0
            while n % p == 0:
                stats.divisions += 1
                n //= p
                e += 1
            factors[p] = e
        p += 2

    if n > 1:
        factors[n] = factors.get(n, 0) + 1

    if factor_product(factors) != original:
        raise AssertionError("reconstruction failed")
    return dict(sorted(factors.items())), stats


def adpms_factor(n: int) -> Tuple[Dict[int, int], OpStats]:
    """6k±1 sequential candidate traversal."""
    if n < 2:
        raise ValueError("n must be >= 2")
    original = n
    factors: Dict[int, int] = {}
    stats = OpStats()

    for p in (2, 3):
        stats.candidate_tests += 1
        stats.divisions += 1
        if n % p == 0:
            e = 0
            while n % p == 0:
                stats.divisions += 1
                n //= p
                e += 1
            factors[p] = e

    k = 1
    while True:
        progressed = False
        for p in (6 * k - 1, 6 * k + 1):
            if p * p > n:
                if n > 1:
                    factors[n] = factors.get(n, 0) + 1
                    n = 1
                progressed = True
                break
            stats.candidate_tests += 1
            stats.divisions += 1
            if n % p == 0:
                e = 0
                while n % p == 0:
                    stats.divisions += 1
                    n //= p
                    e += 1
                factors[p] = factors.get(p, 0) + e
        if n == 1 or progressed:
            break
        k += 1

    if factor_product(factors) != original:
        raise AssertionError("reconstruction failed")
    return dict(sorted(factors.items())), stats


def adpms_prime_registry(limit: int) -> Tuple[List[int], Dict[str, int]]:
    """Wheel-restricted sieve: 2, 3, then 6k±1 candidates."""
    if limit < 2:
        return [], {"limit": limit, "candidate_slots": 0, "mark_operations": 0}

    alive = bytearray(b"\x01") * (limit + 1)
    alive[0:2] = b"\x00\x00"
    mark_ops = 0

    for n in range(4, limit + 1, 2):
        alive[n] = 0
    for n in range(6, limit + 1, 3):
        alive[n] = 0

    max_p = math.isqrt(limit)
    k = 1
    while 6 * k - 1 <= max_p:
        for p in (6 * k - 1, 6 * k + 1):
            if p <= max_p and alive[p]:
                start = p * p
                for m in range(start, limit + 1, p):
                    if alive[m]:
                        alive[m] = 0
                    mark_ops += 1
        k += 1

    primes = [2] if limit >= 2 else []
    if limit >= 3:
        primes.append(3)
    candidate_slots = 0
    k = 1
    while 6 * k - 1 <= limit:
        for p in (6 * k - 1, 6 * k + 1):
            if p <= limit:
                candidate_slots += 1
                if alive[p]:
                    primes.append(p)
        k += 1

    return primes, {
        "limit": limit,
        "candidate_slots": candidate_slots,
        "prime_count": len(primes),
        "mark_operations": mark_ops,
    }


def _event_chain(events: List[dict]) -> str:
    prev = "0" * 64
    for event in events:
        payload = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        prev = hashlib.sha256((prev + payload).encode("utf-8")).hexdigest()
    return prev


def mmpf_factor(
    n: int,
    prime_registry: Sequence[int],
    block_size: int = 64,
    include_certificate: bool = True,
) -> Tuple[Dict[int, int], OpStats, dict]:
    """
    Block-GCD MMPF prototype.

    A prime block is screened by gcd(product(block) mod residual, residual).
    gcd == 1 certifies that the whole block contains no factor of the current residual.
    gcd > 1 triggers candidate-level investigation within that block.
    """
    if n < 2:
        raise ValueError("n must be >= 2")
    if block_size < 1:
        raise ValueError("block_size must be >= 1")

    original = n
    residual = n
    factors: Dict[int, int] = {}
    stats = OpStats()
    events: List[dict] = []

    source_hash = hashlib.sha256(str(original).encode("utf-8")).hexdigest()

    # Handle 2 and 3 directly, keeping ADPMS front-end semantics.
    for p in (2, 3):
        stats.candidate_tests += 1
        stats.divisions += 1
        if residual % p == 0:
            before = residual
            e = 0
            while residual % p == 0:
                stats.divisions += 1
                residual //= p
                e += 1
            factors[p] = factors.get(p, 0) + e
            events.append({
                "type": "factor_fixed",
                "prime": p,
                "multiplicity": e,
                "residual_before": before,
                "residual_after": residual,
            })

    candidates = [p for p in prime_registry if p >= 5]
    index = 0

    while residual > 1 and index < len(candidates):
        if candidates[index] * candidates[index] > residual:
            break

        block = []
        while index < len(candidates) and len(block) < block_size:
            p = candidates[index]
            index += 1
            if p * p <= residual:
                block.append(p)
            else:
                break

        if not block:
            break

        stats.blocks += 1
        product_mod = 1
        for p in block:
            product_mod = (product_mod * p) % residual
            stats.modular_multiplications += 1

        g = math.gcd(product_mod, residual)
        stats.gcd_calls += 1

        if g == 1:
            stats.excluded_candidates += len(block)
            events.append({
                "type": "block_excluded",
                "first_candidate": block[0],
                "last_candidate": block[-1],
                "candidate_count": len(block),
                "residual": residual,
                "gcd": 1,
            })
            continue

        events.append({
            "type": "block_investigate",
            "first_candidate": block[0],
            "last_candidate": block[-1],
            "candidate_count": len(block),
            "residual": residual,
            "gcd": g,
        })

        for p in block:
            if p * p > residual:
                break
            stats.investigated_candidates += 1
            stats.candidate_tests += 1
            stats.divisions += 1
            if residual % p == 0:
                before = residual
                e = 0
                while residual % p == 0:
                    stats.divisions += 1
                    residual //= p
                    e += 1
                factors[p] = factors.get(p, 0) + e
                events.append({
                    "type": "factor_fixed",
                    "prime": p,
                    "multiplicity": e,
                    "residual_before": before,
                    "residual_after": residual,
                })

    if residual > 1:
        # All registered primes <= sqrt(residual) have been excluded or processed.
        factors[residual] = factors.get(residual, 0) + 1
        events.append({
            "type": "residual_fixed_as_prime",
            "prime": residual,
            "reason": "no_remaining_registered_prime_le_sqrt",
        })
        residual = 1

    stats.events = len(events)
    factors = dict(sorted(factors.items()))
    reconstruction = factor_product(factors)
    if reconstruction != original:
        raise AssertionError(f"reconstruction failed: {reconstruction} != {original}")

    certificate = {
        "schema": "mmpf-cert-0.1",
        "source": {
            "integer_decimal": str(original),
            "source_hash_sha256": source_hash,
        },
        "algorithm": {
            "name": "MMPF block-gcd prototype",
            "block_size": block_size,
            "prime_registry_count": len(prime_registry),
        },
        "factors": [
            {"prime": p, "multiplicity": e, "status": "FIXED"}
            for p, e in factors.items()
        ],
        "reconstruction": {
            "product_decimal": str(reconstruction),
            "matches_source": reconstruction == original,
        },
        "stats": asdict(stats),
        "event_chain_root_sha256": _event_chain(events),
    }
    if include_certificate:
        certificate["events"] = events
    return factors, stats, certificate
