from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

def event_chain(events):
    prev = "0" * 64
    for event in events:
        payload = json.dumps(event, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        prev = hashlib.sha256((prev + payload).encode("utf-8")).hexdigest()
    return prev

def verify(path: Path) -> bool:
    cert = json.loads(path.read_text(encoding="utf-8"))
    n = int(cert["source"]["integer_decimal"])
    source_ok = hashlib.sha256(str(n).encode()).hexdigest() == cert["source"]["source_hash_sha256"]
    product = 1
    for item in cert["factors"]:
        product *= int(item["prime"]) ** int(item["multiplicity"])
    reconstruction_ok = product == n
    chain_ok = event_chain(cert.get("events", [])) == cert["event_chain_root_sha256"]
    print(json.dumps({
        "source_hash_ok": source_ok,
        "reconstruction_ok": reconstruction_ok,
        "event_chain_ok": chain_ok,
        "valid": source_ok and reconstruction_ok and chain_ok,
    }, indent=2))
    return source_ok and reconstruction_ok and chain_ok

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python verify_certificate.py CERT.json")
    raise SystemExit(0 if verify(Path(sys.argv[1])) else 1)
