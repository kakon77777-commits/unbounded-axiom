# Spec A — ABFR Methodology v0.1

## Architecture Backtrace and Fresh Reconstruction Methodology

**文件類型：** Canonical Engineering Method Specification  
**系列：** TDD × MSSP Architecture Backtrace and Fresh Reconstruction  
**規格代號：** ABFR-SPEC-A  
**版本：** v0.1  
**日期：** 2026-08-28  
**作者：** Neo.K / EveMissLab  

---

# 0. 規格目的

本文件定義 **ABFR（Architecture Backtrace and Fresh Reconstruction）v0.1** 的 canonical 工程方法。

本規格不是論文摘要，不是討論稿，不是可選建議集。

它定義一個 Agent / engineer 若聲稱「依 ABFR v0.1 執行」，至少必須完成哪些步驟、提供哪些證據、遵守哪些停止條件，以及什麼情況下可以或不可以宣稱 closure。

本規格的核心工程順序固定為：

$$
\boxed{
\text{TDD}
\rightarrow
\text{Architecture Backtrace}
\rightarrow
\text{Fresh Reconstruction}
\rightarrow
\text{Replay}
\rightarrow
\text{Attack}
\rightarrow
\text{Closure}
\rightarrow
\text{Direct Runtime/UI}
}
$$

任何將 Direct Runtime / UI plan 提前到 closure 之前的流程，不符合本版 ABFR v0.1 canonical sequence。

---

# 1. 執行模式

ABFR v0.1 固定：

```text
EXECUTION_MODE = INLINE
SUBAGENT_PATH = NOT PROVIDED
```

不得把主要方法拆給：

- sub-agent；
- hidden worker；
- delegated secondary model；
- automatic parallel worker；
- unseen background executor。

本版要驗證的是：

$$
\boxed{
\text{Single Executor}
+
\text{Canonical Method}
\rightarrow
\text{Complete ABFR Execution}
}
$$

若未來建立 multi-agent ABFR，必須另立新規格版本。

---

# 2. 三閉包目標

ABFR v0.1 的完成條件建立在三個 closure：

$$
C_B
=
\text{Behavioral Closure}
$$

$$
C_S
=
\text{Structural Reconstruction Closure}
$$

$$
C_D
=
\text{Discriminative Closure}
$$

最終 engineering gate：

$$
\boxed{
G_{\text{3C}}
=
C_B
\land
C_S
\land
C_D
}
$$

只有當 mandatory scope 上：

$$
G_{\text{3C}}=1
$$

才允許進入：

```text
Direct Runtime / UI planning
```

---

# 3. Structural Reconstruction Closure

Structural Reconstruction Closure：

$$
C_S
=
C_{BT}
\land
C_{\text{MSRS}}
\land
C_F
\land
C_R
$$

其中：

- $C_{BT}$：Backtrace Closure；
- $C_{\text{MSRS}}$：Minimal Sufficient Reconstruction Set 已建立並驗證；
- $C_F$：Freshness Contract 成立；
- $C_R$：Replay Equivalence 成立。

---

# 4. Discriminative Closure

對 mandatory architecture clause $c$：

$$
C_D(c)
=
C_{\text{witness}}
\land
C_{\text{axis}}
\land
C_{\text{reach}}
\land
C_{\text{continuity}}
\land
C_{\text{eq}}
$$

分別要求：

- 有具名 positive / falsifying witness；
- validator 在正確語義軸上辨識；
- falsifying witness 可實際到達；
- 舊 witness 不得靜默消失；
- authorized / equivalent variant 不得被錯誤拒絕。

---

# 5. 必要輸入

每次 ABFR execution 必須有以下輸入。

## 5.1 Baseline Identity

至少：

```text
repository
branch
commit SHA
working tree status
runtime version
dependency lock identity
test command
```

若 baseline 不可凍結，必須標：

```text
BASELINE_STATUS = UNSTABLE
```

並不得宣稱 release-level closure。

## 5.2 Behavioral Requirements

$$
R
=
\{
r_1,\ldots,r_n
\}
$$

每個 requirement 應對應一個或多個可執行 test / check。

## 5.3 Replay Targets

$$
Q
=
\{
q_1,\ldots,q_m
\}
$$

target 可以是：

- test；
- API behavior；
- state transition；
- architecture invariant；
- recovery behavior；
- authority rule；
- artifact；
- representative workflow。

## 5.4 Declared Architecture

$$
A_d
$$

可以來自：

- MSSP / SSD state；
- ADR；
- architecture docs；
- manifests；
- service catalog；
- API schema；
- dependency map；
- policy；
- runtime contract。

## 5.5 Architecture Invariants

$$
\mathcal I
$$

例如：

```text
only CommitGate may write World
TMS-A must not depend on TMS-B
no undeclared runtime dependency
authority does not propagate implicitly
```

## 5.6 Freshness Contract

$$
\mathcal F
=
(
F_C,
F_W,
F_D,
F_R,
F_A,
F_X,
F_N
)
$$

## 5.7 Replay Equivalence

$$
\simeq_Q
$$

必須在 replay 前定義。

## 5.8 Witness Registry

至少對 critical clause 定義：

$$
\mathcal W(c)
=
(
W_c^+,
W_c^-,
W_c^{\equiv}
)
$$

---

# 6. 禁止輸入

以下資訊不得作為未宣告隱性支援：

- 上一個 Agent 的私人 reasoning；
- 未記錄的聊天補充；
- 原作者記憶中的必要步驟；
- untracked workspace files；
- previous-run cache；
- 未 manifest dependency；
- 隱藏 credentials；
- 未描述 external service state；
- 未聲明 local manual setup。

若任一項被證明為必要，必須轉成 canonical input，或將 closure 降級。

---

# 7. Phase 0 — Freeze Baseline

執行前：

1. 記錄 repository identity。
2. 記錄 commit SHA。
3. 確認 working tree。
4. 記錄 runtime / dependency identity。
5. 記錄 test entrypoints。
6. 保存 baseline test results。
7. 建立 execution manifest。

輸出：

```text
baseline.json
```

最低 verdict：

```text
BASELINE = FROZEN | UNSTABLE | INVALID
```

若：

```text
BASELINE = INVALID
```

停止。

---

# 8. Phase 1 — Precise TDD Plan

先建立精確 TDD plan。

不得直接開始 implementation。

每個 requirement $r_i$ 必須至少有：

```text
requirement_id
expected_behavior
test_target
red_condition
green_condition
scope
out_of_scope
```

建立：

$$
R
\rightarrow
T
$$

的可追蹤映射。

---

# 9. Phase 2 — Red

新增或確認測試後，必須證明：

$$
\text{pre-implementation state}
\rightarrow
FAIL
$$

若測試一開始就綠：

1. 判定是否 feature 已存在；
2. 判定 test 是否無辨識力；
3. 判定 requirement 是否描述錯誤；
4. 不得直接宣稱 TDD 成功。

---

# 10. Phase 3 — Implement

只實作本次 requirement 所需最小範圍。

禁止在此階段：

- 預先建立 Direct UI；
- 預先擴大 runtime surface；
- 重構無關 architecture；
- 加入與 target 無關的大型功能。

---

# 11. Phase 4 — Green

執行：

- focused tests；
- relevant regression；
- 必要 contract / integration tests。

若：

$$
T(P)=PASS
$$

只可宣稱 Behavioral Closure 候選成立。

不得直接宣稱 architecture closure。

---

# 12. Phase 5 — Refactor

允許：

- 清理 implementation；
- 移除 duplication；
- 改善 naming；
- 收斂 interfaces。

任何 refactor 後必須重新：

$$
T(P)=PASS
$$

---

# 13. Phase 6 — Freeze Behavioral Baseline

在進入 backtrace 前，重新凍結：

```text
behavioral_baseline_commit
test_results
artifact identity
```

定義：

$$
C_B
$$

若 mandatory behavioral requirements 全部具有效 test 且通過：

$$
C_B=1
$$

否則：

$$
C_B=0
$$

或：

```text
PARTIAL
```

---

# 14. Phase 7 — Seed Architecture Backtrace

從 targets：

$$
Q
$$

建立：

$$
F_0
=
\operatorname{Seed}(Q)
$$

每個 seed 必須能指向：

- architecture entity；
- assertion；
- runtime output；
- state transition；
- authority rule；
- evidence。

禁止用：

> 我覺得整個 repo 都相關。

作為唯一 seed strategy。

---

# 15. Phase 8 — Backtrace Traversal

對 frontier：

$$
F_k
$$

沿至少必要的 relation type 回溯：

- compile dependency；
- runtime dependency；
- data read/write；
- interface；
- event；
- authority；
- config origin；
- external service；
- state provenance；
- evidence provenance；
- recovery；
- compensation；
- AI context dependency。

更新：

$$
F_{k+1}
=
\left(
\bigcup_{x\in F_k}
\operatorname{Pred}(x)
\right)
\setminus
V_k
$$

---

# 16. Grounded Root

回溯只能在以下 root 停止：

```text
CANONICAL_SOURCE
PINNED_DEPENDENCY
CONTROLLED_EXTERNAL_CONTRACT
DECLARED_RUNTIME_PRIMITIVE
EXPLICIT_UNRESOLVED
```

若 root 未落在以上類別：

```text
BT-03 UNGROUNDED_ROOT
```

---

# 17. Declared / Observed / Effective Reconciliation

每個 critical assertion 盡可能分類：

$$
A_d
$$

$$
A_o
$$

$$
A_e
$$

並記錄 divergence：

```text
declared_only
observed_only
effective_override
unresolved
```

不得把：

$$
A_o
$$

自動當成：

$$
A_e
$$

也不得把：

$$
A_d
$$

自動當成 runtime truth。

---

# 18. Backtrace Closure

定義：

$$
C_{BT}
$$

只有當：

1. mandatory targets 都有 structural support path；
2. necessary predecessor 已拜訪或明示排除；
3. stopping roots 都合法；
4. critical unresolved 沒被隱藏；
5. declared / observed / effective divergence 已記錄；
6. evidence provenance 足以追查 critical claims；

才可：

$$
C_{BT}=1
$$

若仍有非 blocking unresolved：

```text
C_BT = PARTIAL
```

---

# 19. Phase 9 — Derive Reconstruction Candidate

由 backtrace result：

$$
B_Q
$$

導出 reconstruction candidate：

$$
S
$$

其內容只保留 target $Q$ 所需的 structural support。

---

# 20. Minimal Sufficient Reconstruction Set

若：

$$
\operatorname{Sufficient}(S,Q)=1
$$

且：

$$
\forall S'\subsetneq S,
\quad
\operatorname{Sufficient}(S',Q)=0
$$

則：

$$
S
$$

是 inclusion-minimal sufficient reconstruction set。

記：

$$
S\in\mathfrak M_Q
$$

本版只要求 **minimal**，不要求 global minimum。

不得假設：

$$
|\mathfrak M_Q|=1
$$

---

# 21. MSRS Derivation Procedure

建議：

1. 從 backtrace support set 開始。
2. 選 candidate item。
3. 暫時移除。
4. reconstruct / replay focused target。
5. 若仍充分，保留移除。
6. 若不充分，恢復。
7. 重複直到 chosen search order 下 inclusion-minimal。

必須記錄：

```text
search_order
removed_item
replay_result
keep_removed | restore
```

---

# 22. MSRS Verdict

可輸出：

```text
MSRS = VERIFIED
MSRS = PARTIAL
MSRS = FAILED
MSRS = INCONCLUSIVE
```

若存在多個合法 candidate，全部可保留。

---

# 23. Phase 10 — Fresh Reconstruction

Fresh 不等於新資料夾。

核心要求：

$$
\boxed{
\operatorname{Support}(P_S)
\cap
H_{\text{hidden}}
=
\varnothing
}
$$

也就是 reconstruction 不得依賴上一輪未宣告因果支援。

---

# 24. Freshness Contract 七維

## 24.1 Context Freshness

```text
F_C
```

不得依賴前一 executor 的 private reasoning。

## 24.2 Workspace Freshness

```text
F_W
```

不得依賴 untracked / temporary / previous-run state。

## 24.3 Dependency Freshness

```text
F_D
```

dependency 透過 manifest / lock / digest / container / declared procedure 重建。

## 24.4 Runtime-State Freshness

```text
F_R
```

database / queue / cache / session / filesystem state 必須 reset、fixture、snapshot-pin 或 externalize。

## 24.5 Authority Freshness

```text
F_A
```

credential / token / role 必須依 contract 取得。

## 24.6 External Dependency Freshness

```text
F_X
```

external service 必須 pin、mock、stub、sandbox 或 contract-test。

## 24.7 Nondeterminism Control

```text
F_N
```

time / random / scheduler / locale / hostname / network variability 必須 fixed、bounded 或明示 unresolved。

---

# 25. Freshness Verdict

若七維 mandatory contract 都成立：

$$
C_F=1
$$

若 critical hidden support 被發現：

$$
C_F=0
$$

並分類：

```text
FR-01 CONTEXT_LEAKAGE
FR-02 WORKSPACE_LEAKAGE
FR-03 DEPENDENCY_LEAKAGE
FR-04 RUNTIME_STATE_LEAKAGE
FR-05 AUTHORITY_LEAKAGE
FR-06 EXTERNAL_STATE_LEAKAGE
FR-07 NONDETERMINISM_LEAKAGE
```

---

# 26. Phase 11 — Replay

replay 前必須固定：

$$
\simeq_Q
$$

與：

$$
\mathcal I_Q
$$

禁止執行後才修改「什麼算相同」。

---

# 27. Replay Equivalence Profiles

可使用：

```text
BITWISE
SCHEMA
BEHAVIORAL
STATE_TRANSITION
AUTHORITY
ARCHITECTURE_INVARIANT
EVIDENCE
COMPOSITE
```

若使用 COMPOSITE，必須列出 component。

---

# 28. Replay Closure

若：

$$
\mathcal O_Q(P_S,E_f)
\simeq_Q
\mathcal O_Q(P_{\text{ref}},E_{\text{ref}})
$$

且：

$$
\mathcal I_Q(P_S)=1
$$

則：

$$
C_R=1
$$

否則依：

```text
RP-01 BEHAVIORAL_DIVERGENCE
RP-02 STATE_DIVERGENCE
RP-03 AUTHORITY_DIVERGENCE
RP-04 ARCHITECTURE_INVARIANT_VIOLATION
RP-05 EVIDENCE_DIVERGENCE
RP-06 UNDEFINED_EQUIVALENCE
```

分類。

---

# 29. Phase 12 — Freeze Validator

進入 attack 前，必須凍結：

- validator；
- equivalence profile；
- architecture claims；
- expected verdicts；
- witness identities。

禁止 attack 執行後為了維持綠燈而無治理紀錄修改標準。

---

# 30. Phase 13 — Positive Witness

對每個 mandatory clause：

$$
c
$$

至少有一個：

$$
w^+
$$

使：

$$
V(w^+)=PASS
$$

避免 constant-red validator。

---

# 31. Phase 14 — Falsifying Witness

對每個 mandatory clause：

$$
c
$$

至少有一個具名：

$$
w^-
$$

使：

$$
w^-\not\models c
$$

且：

$$
V(w^-)=FAIL
$$

不得只說：

> 理論上它應該會 fail。

必須實際執行。

---

# 32. Phase 15 — Axis Binding

對 claim-relevant dimensions：

$$
\Theta_c
$$

建立：

$$
(w^+,w^-)
$$

使：

$$
\Delta(w^+,w^-)
\subseteq
\Theta_c
$$

並確認 verdict 的變化是因 target axis，而非 unrelated failure。

若 wrong-axis：

```text
DC-03 WRONG_AXIS_DISCRIMINATION
```

---

# 33. Phase 16 — Witness Reachability

falsifying witness 必須：

$$
w^-
\in
\mathcal X(H)
$$

即 test / replay harness 能真的生成。

若只存在紙上：

```text
DC-05 UNREACHABLE_WITNESS
```

---

# 34. Phase 17 — Witness Continuity

對上一版 mandatory witness：

$$
w
$$

必須是：

```text
PRESERVED
REPLACED
RETIRED_WITH_REASON
```

禁止：

```text
SILENTLY_DROPPED
```

若 silent drop：

```text
DC-06 SILENT_WITNESS_LOSS
```

---

# 35. Phase 18 — Authorized Equivalence

對：

$$
W_c^{\equiv}
$$

要求：

$$
V(w)=PASS
$$

或合法：

```text
ALLOWED
```

若 validator 把合法替代全部打紅：

```text
DC-07 EQUIVALENT_VARIANT_REJECTION
```

---

# 36. Discriminative Closure Verdict

對 mandatory clause：

$$
c
$$

若：

$$
C_{\text{witness}}
=
C_{\text{axis}}
=
C_{\text{reach}}
=
C_{\text{continuity}}
=
C_{\text{eq}}
=
1
$$

則：

$$
C_D(c)=1
$$

system-level：

$$
C_D
=
\bigwedge_{c\in\mathcal C_M}C_D(c)
$$

---

# 37. Three-Closure Verdict

最終：

$$
G_{\text{3C}}
=
C_B
\land
C_S
\land
C_D
$$

verdict：

```text
PASS
PARTIAL
FAIL
INCONCLUSIVE
```

### PASS
所有 mandatory closure 成立。

### PARTIAL
有明示、非 blocking unresolved / deferred items。

### FAIL
至少一個 blocking closure 失敗。

### INCONCLUSIVE
evidence 不足，無法合理判定。

---

# 38. Direct Runtime / UI Gate

只有：

```text
THREE_CLOSURE_VERDICT = PASS
```

或事前允許的：

```text
PARTIAL_WITH_NONBLOCKING_DEFERRED_ITEMS
```

才可建立下一階段：

```text
Direct Runtime Plan
UI Plan
Projection Layer Plan
```

若：

```text
FAIL
INCONCLUSIVE
```

禁止用 UI / runtime 擴張掩蓋底層 closure 缺口。

---

# 39. Stop Conditions

ABFR execution 必須在以下情況停止：

```text
SC-01 THREE_CLOSURE_PASS
SC-02 BLOCKING_BEHAVIORAL_FAIL
SC-03 BLOCKING_BACKTRACE_FAIL
SC-04 BLOCKING_FRESHNESS_FAIL
SC-05 BLOCKING_REPLAY_FAIL
SC-06 BLOCKING_DISCRIMINATIVE_FAIL
SC-07 CRITICAL_UNRESOLVED
SC-08 ENVIRONMENT_IMPOSSIBLE_UNDER_CONTRACT
SC-09 BUDGET_EXHAUSTED
SC-10 PROTOCOL_VIOLATION
```

停止時必須輸出 reason code。

---

# 40. Protocol Violations

以下屬 protocol violation：

```text
PV-01 SUBAGENT_USED
PV-02 ORACLE_ACCESSED
PV-03 PREVIOUS_RUN_STATE_USED
PV-04 FRESH_RECONSTRUCTION_SKIPPED
PV-05 HIDDEN_TEST_MODIFIED
PV-06 EQUIVALENCE_CHANGED_POST_HOC
PV-07 WITNESS_EXPECTATION_CHANGED_POST_HOC
PV-08 UNDECLARED_HUMAN_ANSWER_INJECTION
PV-09 BASELINE_CHANGED
PV-10 EVIDENCE_FABRICATED
```

若發生：

```text
PROTOCOL_COMPLIANCE = FAIL
```

即使最終 code 正確，也不得算 ABFR PASS。

---

# 41. Evidence Output

每次 ABFR execution 至少輸出：

```text
abfr-run/
  manifest.json
  baseline.json
  tdd-plan.md
  behavioral-results.json
  backtrace.json
  architecture-diff.json
  msrs.json
  freshness.json
  replay.json
  witness-results.json
  closure.json
  unresolved.json
```

---

# 42. Manifest

最低欄位：

```text
spec_version
run_id
executor
model
agent_shell
execution_mode
repository
commit
method_condition
started_at
ended_at
tool_contract
authority_contract
```

---

# 43. Backtrace Output

至少：

```text
target
visited_nodes
relations
grounded_roots
declared_only
observed_only
effective_relations
unresolved
evidence_refs
```

---

# 44. MSRS Output

至少：

```text
candidate_id
members
search_order
removal_attempts
sufficiency_results
equivalence_profile
alternative_candidates
```

---

# 45. Freshness Output

至少：

```text
context
workspace
dependencies
runtime_state
authority
external_dependencies
nondeterminism
violations
evidence
```

---

# 46. Witness Output

每個 witness：

```text
witness_id
claim_id
semantic_case
witness_type
affected_axis
expected_verdict
actual_verdict
failure_reason_expected
failure_reason_actual
reachable
evidence
introduced_in
disposition
```

---

# 47. Closure Output

至少：

```text
C_B
C_BT
C_MSRS
C_F
C_R
C_D
THREE_CLOSURE_VERDICT
STOP_REASON
BLOCKERS
NONBLOCKING_DEFERRED
```

---

# 48. Additional Information Requests

任何 executor 要求的額外資訊都必須記錄：

```text
AIR-1 CANONICAL_NAVIGATION
AIR-2 MISSING_DOCUMENTATION
AIR-3 HIDDEN_ENVIRONMENT
AIR-4 HIDDEN_DECISION
AIR-5 AUTHORITY_REQUEST
```

並記：

```text
request
response
whether canonical
whether closure affected
```

---

# 49. Human Intervention

記錄：

$$
H_I
$$

所有非 canonical human intervention。

若：

$$
H_I>0
$$

且 intervention 對 PASS 為必要，則：

```text
FRESH_AUTONOMOUS_CLOSURE = FAIL
```

除非本次 experiment 明示為 assisted condition。

---

# 50. ABFR Attack Object Classes

attack 可以作用於：

```text
CODE
DEPENDENCY
ARCHITECTURE_DECLARATION
AUTHORITY
EVIDENCE_BINDING
RUNTIME_STATE
RECONSTRUCTION_MATERIAL
EXTERNAL_CONTRACT
SCHEDULE
EQUIVALENCE_CONTRACT
```

所有 attack 必須：

- 有 ID；
- 可回復；
- 有 expected verdict；
- 有 evidence；
- 有 cleanup。

---

# 51. 禁止 Attack 行為

不得：

- 對 production environment 施加未授權破壞；
- 改動無關使用者資料；
- 使用不可回復 mutation；
- 讓 attack 超出事先授權 scope；
- 把真實 secrets 寫入 evidence；
- 使用與 claim 無關的大範圍破壞只為了「讓它紅」。

ABFR attack 是可控驗證，不是破壞性測試的免責名詞。

---

# 52. Error Taxonomy

## Backtrace

```text
BT-01 MISSING_SEED
BT-02 FRONTIER_EXPLOSION
BT-03 UNGROUNDED_ROOT
BT-04 EVIDENCE_GAP
BT-05 DECLARED_OBSERVED_DRIFT
```

## MSRS

```text
MS-01 HIDDEN_NECESSARY_DEPENDENCY
MS-02 FALSE_CORE
MS-03 NON_ISOLATABLE_MODULE
MS-04 SEARCH_ORDER_SENSITIVITY
```

## Freshness

```text
FR-01 CONTEXT_LEAKAGE
FR-02 WORKSPACE_LEAKAGE
FR-03 DEPENDENCY_LEAKAGE
FR-04 RUNTIME_STATE_LEAKAGE
FR-05 AUTHORITY_LEAKAGE
FR-06 EXTERNAL_STATE_LEAKAGE
FR-07 NONDETERMINISM_LEAKAGE
```

## Replay

```text
RP-01 BEHAVIORAL_DIVERGENCE
RP-02 STATE_DIVERGENCE
RP-03 AUTHORITY_DIVERGENCE
RP-04 ARCHITECTURE_INVARIANT_VIOLATION
RP-05 EVIDENCE_DIVERGENCE
RP-06 UNDEFINED_EQUIVALENCE
```

## Discrimination

```text
DC-01 CONSTANT_GREEN
DC-02 CONSTANT_RED
DC-03 WRONG_AXIS_DISCRIMINATION
DC-04 DUPLICATE_WITNESS_INFLATION
DC-05 UNREACHABLE_WITNESS
DC-06 SILENT_WITNESS_LOSS
DC-07 EQUIVALENT_VARIANT_REJECTION
DC-08 DEAD_PATH_MUTATION
DC-09 WRONG_REASON_KILL
DC-10 POST_HOC_EQUIVALENCE_RELAXATION
DC-11 SCOPE_LAUNDERING
DC-12 ATTACK_CONTAMINATION
```

## Closure

```text
CL-01 PREMATURE_CLOSURE
CL-02 SINGLE_EXECUTOR_DEPENDENCE
CL-03 NON_REPLAYABLE_PROCEDURE
```

---

# 53. 最小執行摘要

若需要把完整方法壓縮成 Agent instruction，必須至少保留：

```text
1. Freeze baseline.
2. Write precise TDD plan.
3. Prove Red.
4. Implement minimum scope.
5. Prove Green.
6. Refactor and revalidate.
7. Freeze behavioral baseline.
8. Backtrace architecture from explicit targets.
9. Reconcile declared / observed / effective structure.
10. Derive and validate an inclusion-minimal sufficient reconstruction set.
11. Reconstruct under the full Freshness Contract.
12. Replay using a predeclared equivalence profile.
13. Freeze validators and expected verdicts.
14. Run named positive and falsifying witnesses.
15. Check axis binding, reachability, continuity, and authorized equivalence.
16. Decide C_B, C_S, C_D and the three-closure verdict.
17. Only after closure, write Direct Runtime / UI plan.
18. Execution mode is Inline. No sub-agent path is provided.
```

任何更短版本若刪除 Freshness、Replay 或 Discriminative Closure，不得稱為完整 ABFR v0.1。

---

# 54. Canonical Invariants

以下是 ABFR v0.1 不可靜默更改的不變量。

### INV-01
$$
\text{Test Pass}
\not\Rightarrow
\text{Architecture Closure}
$$

### INV-02
$$
\text{Fresh}
\neq
\text{New Folder}
$$

### INV-03
$$
\text{Freshness}
=
\text{No Undeclared Causal Support}
$$

### INV-04
$$
\text{Minimal}
\neq
\text{Minimum}
$$

### INV-05
$$
|\mathfrak M_Q|
$$
可能大於 $1$。

### INV-06
$$
\text{Observed}
\neq
\text{Effective}
$$

### INV-07
$$
\text{Can Fail}
\not\Rightarrow
\text{Can Discriminate}
$$

### INV-08
$$
\text{Agreement}
\not\Rightarrow
\text{Correctness}
$$

### INV-09
$$
\text{Vocabulary Adoption}
\not\Rightarrow
\text{Method Adoption}
$$

### INV-10
Direct Runtime / UI 不得位於三閉包之前。

### INV-11
ABFR v0.1 固定 Inline Execution。

### INV-12
ABFR v0.1 不提供 sub-agent execution path。

---

# 55. Versioning

若未來變更以下任一項，必須升版：

- closure semantics；
- Freshness Contract；
- MSRS 定義；
- Replay Equivalence；
- witness semantics；
- execution mode；
- Direct Runtime / UI gate；
- protocol violation rules。

不得使用相同 `v0.1` 名稱靜默改義。

---

# 56. Completion Criteria

一個 ABFR v0.1 execution 只有在以下 artifact 全部存在時，才算 procedure complete：

```text
baseline identity
precise TDD plan
red evidence
green evidence
backtrace result
declared/observed/effective diff
MSRS candidate + derivation
freshness evidence
replay evidence
witness evidence
three-closure verdict
stop reason
unresolved list
```

若缺任一 mandatory artifact：

```text
PROCEDURE_COMPLETE = false
```

---

# 57. Method-Level Fresh Replay

本規格本身也應能被另一個 fresh executor 使用。

若另一個 Agent 只收到：

- 本 Spec A；
- project canonical inputs；
- tool / authority contract；

就能重建相容的 ABFR execution，則：

$$
\text{Method-Level Fresh Replay}
$$

得到初步支持。

此項正式驗證由 Spec B 與後續 cross-AI experiment 負責。

---

# 58. 一句話定義

ABFR v0.1 是：

> **先以 TDD 證明行為，再從已工作的系統回溯其實際結構支援，將宣告、觀察與有效架構重新對齊；接著在移除所有未宣告因果支援的 fresh boundary 中，以最小充分結構重新構成系統，依事先定義的等價關係重播，再用具名反例證明 validator 真的能在正確語義軸上失敗；只有三閉包成立後，才進入 Direct Runtime / UI。**

形式上：

$$
\boxed{
\text{ABFR}
=
\text{TDD}
+
\text{Backtrace}
+
\text{Fresh Reconstruction}
+
\text{Replay}
+
\text{Discriminative Attack}
}
$$

最終 gate：

$$
\boxed{
G_{\text{3C}}
=
C_B
\land
C_S
\land
C_D
}
$$

---

## Canonical status

本文為 **Spec A — ABFR Methodology v0.1**。

狀態：

- Canonical sequence: defined.
- Inline Execution: mandatory.
- Sub-agent path: not provided.
- TDD gate: defined.
- Backtrace: defined.
- Declared / observed / effective reconciliation: defined.
- MSRS: defined.
- Freshness Contract: defined.
- Replay Equivalence: defined.
- Discriminative Closure: defined.
- Witness continuity: defined.
- Direct Runtime / UI gate: defined.
- Stop conditions: defined.
- Protocol violations: defined.
- Evidence artifact schema: defined.
- Cross-AI validation: pending.
- General methodology claim: not yet empirically established.
