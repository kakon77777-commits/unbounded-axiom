# ABFR Full Methodology Pack v0.1

## TDD × MSSP Architecture Backtrace and Fresh Reconstruction

**版本：** v0.1  
**日期：** 2026-08-28  
**狀態：** Core theory + canonical methodology + cross-AI validation protocol complete

---

# 1. 這一包是什麼

ABFR v0.1 將：

$$
\text{TDD}
$$

與：

$$
\text{Architecture Backtrace}
+
\text{Fresh Reconstruction}
+
\text{Replay}
+
\text{Discriminative Attack}
$$

接成一個三閉包工程方法。

最終 gate：

$$
\boxed{
G_{\text{3C}}
=
C_B
\land
C_S
\land
C_D
}
$$

也就是：

$$
\boxed{
\text{Works}
\land
\text{Reconstructs}
\land
\text{Discriminates}
}
$$

---

# 2. Canonical 閱讀順序

1. `ABFR_Series_Paper_01_From_TDD_to_Architecture_Level_Revalidation_v0.1_zh-TW.md`
2. `ABFR_Series_Paper_02_MSSP_as_AI_Structural_Attention_Substrate_v0.1_zh-TW.md`
3. `ABFR_Series_Paper_03_Architecture_Backtrace_and_Fresh_Reconstruction_v0.1_zh-TW.md`
4. `ABFR_Series_Paper_04_Behavioral_Structural_and_Discriminative_Closure_v0.1_zh-TW.md`
5. `ABFR_Series_Paper_05_Cross_Agent_Reproducibility_of_Architecture_Reasoning_v0.1_zh-TW.md`
6. `ABFR_Spec_A_Methodology_v0.1_zh-TW.md`
7. `ABFR_Spec_B_Cross_AI_Validation_Protocol_v0.1_zh-TW.md`
8. `ABFR_Cross_AI_Executor_Prompt_v0.1_zh-TW.md`

---

# 3. 五篇論文的角色

## Paper 01

定義：

$$
\text{Test Pass}
\not\Rightarrow
\text{Architecture Reconstructible}
$$

並提出 Behavioral Closure 與 Structural Reconstruction Closure 的分離。

## Paper 02

定義 MSSP 的 AI-native 二次用途：

$$
\text{Human Cognitive Reduction}
\rightarrow
\text{AI Structured Global Attention}
$$

## Paper 03

形式化：

- Architecture Backtrace；
- Declared / Observed / Effective；
- MSRS；
- Freshness Contract；
- Replay Equivalence。

## Paper 04

加入：

$$
C_D
=
\text{Discriminative Closure}
$$

要求 validator 必須能在正確語義軸上被具名反例打紅。

## Paper 05

定義：

- repeatability；
- cross-agent reproducibility；
- cross-model transportability；
- cross-project generalizability。

---

# 4. Spec A 是什麼

`ABFR_Spec_A_Methodology_v0.1_zh-TW.md`

是 canonical execution method。

若某個 Agent 宣稱：

```text
I executed ABFR v0.1
```

最低必須遵守 Spec A。

核心順序：

```text
TDD
→ Backtrace
→ Fresh Reconstruction
→ Replay
→ Attack
→ Closure
→ Direct Runtime/UI
```

固定：

```text
EXECUTION_MODE = INLINE
SUBAGENT_PATH = NOT PROVIDED
```

---

# 5. Spec B 是什麼

`ABFR_Spec_B_Cross_AI_Validation_Protocol_v0.1_zh-TW.md`

是 evaluator / benchmark owner 使用的 cross-AI experiment protocol。

它包含：

- hidden oracle；
- experiment integrity；
- method conditions；
- blindness levels；
- tool / authority / budget control；
- structural coverage；
- divergence recall；
- fresh reconstruction；
- witness reproduction；
- three-closure scoring；
- protocol violations。

**不要把整份 Spec B 中 evaluator-only / oracle 內容直接餵給被測 AI。**

---

# 6. 真正丟給其他 AI 的檔案

使用：

`ABFR_Cross_AI_Executor_Prompt_v0.1_zh-TW.md`

再加：

- Spec A；
- target project；
- frozen baseline；
- task；
- executor-visible canonical architecture artifacts；
- tool / authority contract；
- replay targets / equivalence profile；
- benchmark 明示可見的 witnesses。

不要加入：

- hidden defect；
- oracle；
- other Agent result；
- previous run summary。

---

# 7. 第一輪 Pilot

建議先：

```text
Phase A — Same-Agent Smoke Test
Phase B — Cross-Agent Pilot
Phase C — TDD-only / Clean-Rerun Controls
Phase D — Non-MSSP Transfer
```

最低 cross-agent pilot：

$$
3
\text{ executors}
\times
3
\text{ fresh runs}
$$

若加入兩個 project 與兩個 method conditions：

$$
3
\times
2
\times
2
\times
3
=
36
$$

runs。

---

# 8. 第一輪不要做的事

不要：

- 讓不同 AI 看彼此結果；
- 開 sub-agent；
- 改 baseline；
- execution 後才修改 equivalence；
- execution 後才改 witness expected verdict；
- 用作者口頭提示補 hidden architecture answer；
- 只比較 final code pass/fail；
- 把 high agreement 當成 correctness；
- 把一次成功當成 general methodology 已證明。

---

# 9. 下一篇論文

只有 cross-AI pilot 產生實際資料後，才寫：

**Paper 06 — A Multi-Agent Empirical Evaluation of Architecture Backtrace and Fresh Reconstruction**

不得在資料出現前預寫：

- 成功率；
- effect size；
- model ranking；
- generality conclusion。

---

# 10. Current Claim Boundary

目前合法的最強敘述：

> **ABFR v0.1 已完成理論核心、canonical engineering methodology 與 cross-AI fresh validation protocol；其 cross-agent reproducibility、cross-model transportability、cross-project generalizability 與相對 TDD-only 的實證效益仍待正式實驗。**

---

# 11. Canonical Source Rule

聊天畫面不是 canonical source。

正式內容以本 pack 中 UTF-8 Markdown artifacts 為準。

所有數學 source 使用：

$$
\texttt{\$\$...\$\$}
$$

與：

$\texttt{\$...\$}$

作為 canonical delimiters。

---

# 12. Integrity

使用 `ABFR_Full_Methodology_Pack_v0.1_MANIFEST.json` 驗證每個 canonical file 的 SHA-256。

若任一檔案修改，必須重新產生 manifest，並視語義變更決定是否升版。
