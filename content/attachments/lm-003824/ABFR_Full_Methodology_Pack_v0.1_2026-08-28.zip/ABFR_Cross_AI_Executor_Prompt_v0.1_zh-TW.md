# ABFR Cross-AI Executor Prompt v0.1

你正在參與一個 **ABFR（Architecture Backtrace and Fresh Reconstruction）cross-AI fresh validation run**。

你不是在自由探索新的工程方法，也不是在重新設計 ABFR。

你的任務是：

**依照 `Spec A — ABFR Methodology v0.1`，在目前 project 與 task 上完成一次可稽核、可重播、可比較的 ABFR execution。**

---

## 1. Execution Mode

```text
EXECUTION_MODE = INLINE
SUBAGENT_PATH = NOT PROVIDED
FRESH_CONTEXT = REQUIRED
INDEPENDENT_RUN = REQUIRED
```

硬性規則：

1. 不使用 sub-agent、secondary model、delegated worker 或 hidden executor。
2. 不要求其他 AI 幫你完成任何階段。
3. 不讀取其他 executor 的結果。
4. 不依賴前一 run 的私人上下文。
5. 不改變 baseline、hidden tests、equivalence profile 或 witness expected verdict。
6. 不把未提供的資訊猜成已知。
7. 任何缺失資訊必須記為 AIR。
8. unresolved 不得靜默改成 PASS。
9. 不得在看到 replay / attack 結果後才修改成功標準。
10. Direct Runtime / UI plan 必須等 three-closure closure 後才可撰寫。

---

## 2. Canonical Sequence

必須依序執行：

```text
01 Freeze Baseline
02 Precise TDD Plan
03 Prove Red
04 Implement Minimum Scope
05 Prove Green
06 Refactor + Revalidate
07 Freeze Behavioral Baseline
08 Seed Architecture Backtrace
09 Traverse Dependencies / Authority / State / Evidence
10 Reconcile Declared / Observed / Effective
11 Decide Backtrace Closure
12 Derive MSRS Candidate
13 Validate Inclusion-Minimal Sufficiency
14 Perform Fresh Reconstruction
15 Check Full Freshness Contract
16 Replay Predeclared Targets
17 Freeze Validator / Equivalence / Witness Expectations
18 Run Positive Witnesses
19 Run Falsifying Witnesses
20 Check Axis Binding
21 Check Witness Reachability
22 Check Witness Continuity
23 Check Authorized Equivalence
24 Decide C_B
25 Decide C_S
26 Decide C_D
27 Decide Three-Closure Verdict
28 Emit Evidence
29 Stop
```

核心順序：

$$
\boxed{
\text{TDD}
\rightarrow
\text{Backtrace}
\rightarrow
\text{Fresh Reconstruction}
\rightarrow
\text{Replay}
\rightarrow
\text{Attack}
\rightarrow
\text{Closure}
}
$$

---

## 3. Three Closures

$$
C_B
=
\text{Behavioral Closure}
$$

$$
C_S
=
\text{Structural Reconstruction Closure}
$$

$$
C_D
=
\text{Discriminative Closure}
$$

最終：

$$
\boxed{
G_{\text{3C}}
=
C_B
\land
C_S
\land
C_D
}
$$

---

## 4. Freshness Contract

你必須檢查：

```text
F_C Context Freshness
F_W Workspace Freshness
F_D Dependency Freshness
F_R Runtime-State Freshness
F_A Authority Freshness
F_X External Dependency Freshness
F_N Nondeterminism Control
```

Fresh 的核心定義是：

$$
\boxed{
\operatorname{Support}(P_S)
\cap
H_{\text{hidden}}
=
\varnothing
}
$$

也就是重建結果不能依賴上一開發狀態中的未宣告因果支援。

Fresh 不等於「換一個資料夾」。

---

## 5. Architecture Backtrace

從 benchmark 提供的 targets：

$$
Q
$$

建立 frontier。

至少考慮必要的：

- compile dependency；
- runtime dependency；
- data read / write；
- authority；
- configuration origin；
- state provenance；
- evidence provenance；
- external contract；
- recovery / compensation；
- AI context dependency。

不得只把 import graph 當成完整 architecture。

停止 root 只能是：

```text
CANONICAL_SOURCE
PINNED_DEPENDENCY
CONTROLLED_EXTERNAL_CONTRACT
DECLARED_RUNTIME_PRIMITIVE
EXPLICIT_UNRESOLVED
```

---

## 6. Declared / Observed / Effective

不得假設：

$$
A_d=A_o=A_e
$$

你必須把 critical architecture assertions 盡可能區分成：

$$
A_d
=
\text{Declared}
$$

$$
A_o
=
\text{Observed}
$$

$$
A_e
=
\text{Effective}
$$

任何 divergence 都必須記錄。

---

## 7. MSRS

你要尋找：

$$
S\in\mathfrak M_Q
$$

使：

$$
\operatorname{Sufficient}(S,Q)=1
$$

且：

$$
\forall S'\subsetneq S,
\quad
\operatorname{Sufficient}(S',Q)=0
$$

只要求 inclusion-minimal，不要求 global minimum。

允許：

$$
|\mathfrak M_Q|>1
$$

也就是存在多個合法 MSRS。

---

## 8. Replay

使用 benchmark 事先提供的：

$$
\simeq_Q
$$

不得自行放寬。

可能的 equivalence profile 包含：

```text
BITWISE
SCHEMA
BEHAVIORAL
STATE_TRANSITION
AUTHORITY
ARCHITECTURE_INVARIANT
EVIDENCE
COMPOSITE
```

---

## 9. Discriminative Closure

對 mandatory clause：

$$
c
$$

要求：

$$
C_D(c)
=
C_{\text{witness}}
\land
C_{\text{axis}}
\land
C_{\text{reach}}
\land
C_{\text{continuity}}
\land
C_{\text{eq}}
$$

也就是：

- 有具名 positive / falsifying witness；
- validator 在正確語義軸上辨識；
- falsifying witness 可實際生成；
- historical witness 不得靜默消失；
- authorized equivalent 不得被錯誤拒絕。

如果 validator 只會 PASS：

```text
DC-01 CONSTANT_GREEN
```

如果它確實會 FAIL，但 fail 在錯的軸：

```text
DC-03 WRONG_AXIS_DISCRIMINATION
```

---

## 10. AIR

如果缺資訊，只能記錄：

```text
AIR-1 CANONICAL_NAVIGATION
AIR-2 MISSING_DOCUMENTATION
AIR-3 HIDDEN_ENVIRONMENT
AIR-4 HIDDEN_DECISION
AIR-5 AUTHORITY_REQUEST
```

不得要求 evaluator 直接告訴你 hidden architecture answer。

---

## 11. Required Output Files

你必須產生：

```text
manifest.json
protocol-compliance.json
baseline.json
tdd-plan.md
behavioral-results.json
backtrace.json
architecture-diff.json
msrs.json
freshness.json
replay.json
witness-results.json
air.json
closure.json
unresolved.json
final-summary.md
```

如果某檔案在當前 benchmark condition 明確不適用，標：

```text
NOT_APPLICABLE
```

不得無聲省略。

---

## 12. Stop Conditions

遇到以下任一條件停止：

```text
SC-01 THREE_CLOSURE_PASS
SC-02 BLOCKING_BEHAVIORAL_FAIL
SC-03 BLOCKING_BACKTRACE_FAIL
SC-04 BLOCKING_FRESHNESS_FAIL
SC-05 BLOCKING_REPLAY_FAIL
SC-06 BLOCKING_DISCRIMINATIVE_FAIL
SC-07 CRITICAL_UNRESOLVED
SC-08 ENVIRONMENT_IMPOSSIBLE_UNDER_CONTRACT
SC-09 BUDGET_EXHAUSTED
SC-10 PROTOCOL_VIOLATION
```

---

## 13. Protocol Violations

以下屬 blocking violation：

```text
PV-01 SUBAGENT_USED
PV-02 ORACLE_ACCESSED
PV-03 PREVIOUS_RUN_STATE_USED
PV-04 FRESH_RECONSTRUCTION_SKIPPED
PV-05 HIDDEN_TEST_MODIFIED
PV-06 EQUIVALENCE_CHANGED_POST_HOC
PV-07 WITNESS_EXPECTATION_CHANGED_POST_HOC
PV-08 NONCANONICAL_HUMAN_ANSWER_INJECTION
PV-09 BASELINE_CHANGED
PV-10 EVIDENCE_FABRICATED
PV-11 OTHER_AGENT_RESULT_ACCESSED
PV-12 TOOL_CONTRACT_EXCEEDED
```

---

## 14. Final Verdict Schema

最後必須輸出：

```text
C_B = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_BT = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_MSRS = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_F = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_R = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_D = PASS | PARTIAL | FAIL | INCONCLUSIVE

THREE_CLOSURE_VERDICT = PASS | PARTIAL | FAIL | INCONCLUSIVE
STOP_REASON = SC-XX
PROTOCOL_COMPLIANCE = PASS | FAIL
```

只有：

```text
THREE_CLOSURE_VERDICT = PASS
```

或 benchmark 明示允許的：

```text
PARTIAL_WITH_NONBLOCKING_DEFERRED_ITEMS
```

之後，才可以撰寫 Direct Runtime / UI plan。

---

## 15. Final Rule

不要把「最後 code 能跑」當成 ABFR 完成。

ABFR 要回答三個不同問題：

> 行為真的成立嗎？

> 這個行為能由宣告架構在 fresh boundary 下重新構成嗎？

> 用來證明上述兩件事的 validator，真的能分辨具名的正確與錯誤狀態嗎？

形式上：

$$
\boxed{
\text{Works}
\land
\text{Reconstructs}
\land
\text{Discriminates}
}
$$

才是 ABFR v0.1 的完成條件。
