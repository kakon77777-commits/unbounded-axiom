# Spec B — Cross-AI ABFR Validation Protocol v0.1

## Cross-AI Architecture Backtrace and Fresh Reconstruction Validation Protocol

**文件類型：** Canonical Cross-Agent Validation Protocol  
**系列：** TDD × MSSP Architecture Backtrace and Fresh Reconstruction  
**規格代號：** ABFR-SPEC-B  
**版本：** v0.1  
**日期：** 2026-08-28  
**作者：** Neo.K / EveMissLab  

---

# 0. 規格目的

本文件定義如何將 **Spec A — ABFR Methodology v0.1** 交給不同 AI executor，在 fresh、independent、可比較的條件下執行，並判定：

$$
\boxed{
\text{Same Method}
+
\text{Same Canonical Inputs}
+
\text{Fresh AI}
\overset{?}{\Longrightarrow}
\text{Comparable ABFR Execution}
}
$$

本規格分成兩個明確隔離的部分：

1. **Evaluator / Benchmark Owner Protocol**  
   保存 baseline、oracle、hidden defect、expected witness、ground truth 與 scoring logic。

2. **Executor Prompt Contract**  
   只提供被測 AI 執行 ABFR 所需的 canonical inputs，不提供 hidden oracle。

兩者不得混用。

---

# 1. 第一輪固定條件

ABFR cross-AI v0.1 第一輪固定：

```text
EXECUTION_MODE = INLINE
SUBAGENT_PATH = NOT PROVIDED
FRESH_CONTEXT = REQUIRED
INDEPENDENT_RUN = REQUIRED
ORACLE_VISIBILITY = HIDDEN
```

禁止：

- sub-agent；
- delegated worker；
- secondary model；
- hidden multi-agent route；
- other-agent result sharing；
- previous-run private context reuse。

第一輪要測的是：

$$
\boxed{
\text{One Fresh Executor}
+
\text{Spec A}
\rightarrow
\text{Complete ABFR Run}
}
$$

---

# 2. Primary Research Questions

## RQ-1 — Intra-Agent Repeatability

同一 executor configuration 在多次 fresh runs 中：

$$
A_i^{(1)},A_i^{(2)},\ldots
$$

是否能穩定完成 ABFR？

## RQ-2 — Cross-Agent Reproducibility

不同 executor：

$$
A_i\neq A_j
$$

是否能得到相容的 critical structural conclusions？

## RQ-3 — Method Benefit

相對：

$$
G_0=\text{TDD-only}
$$

與：

$$
G_1=\text{TDD + generic clean rerun}
$$

ABFR：

$$
G_2=\text{TDD + ABFR}
$$

是否提升 architecture defect detection、fresh reconstruction success 與 witness reproduction？

## RQ-4 — Cross-Project Transfer

ABFR 是否能從 MSSP-native project 延伸至 non-MSSP project？

---

# 3. Roles

## 3.1 Evaluator

Evaluator 負責：

- 建 benchmark；
- 凍結 baseline；
- 保存 oracle；
- 注入或記錄 hidden defect；
- 產生 hidden tests / witnesses；
- 收集 run artifacts；
- 執行 deterministic evaluation；
- 判定 protocol compliance；
- 不在 primary run 中提供非 canonical答案。

## 3.2 Executor

Executor 是被測 AI。

Executor 負責：

- 依 Spec A 執行；
- 不使用 sub-agent；
- 不讀 oracle；
- 不依賴 previous-run state；
- 產生完整 evidence；
- 遵守 stop conditions。

## 3.3 Optional Independent Reviewer

所有 primary runs 完成後，可加入 independent reviewer。

Reviewer 不得影響 primary run。

---

# 4. Experiment Identity

每個 experiment 必須有：

```text
EXPERIMENT_ID
BENCHMARK_ID
PROJECT_ID
TASK_ID
SPEC_A_VERSION
SPEC_B_VERSION
METHOD_CONDITION
BLINDNESS_LEVEL
```

建議：

```text
EXPERIMENT_ID = ABFR-XAI-YYYYMMDD-XXX
```

---

# 5. Run Identity

每個 run 必須有：

```text
RUN_ID
AGENT_ID
MODEL_ID
AGENT_SHELL
MODEL_VERSION_IF_EXPOSED
RUN_INDEX
START_TIME
END_TIME
```

例如：

```text
RUN_ID = ABFR-XAI-001-GPT-R03
```

---

# 6. Method Conditions

至少定義：

## MC-0 — TDD Only

```text
METHOD_CONDITION = TDD_ONLY
```

只執行 precise TDD plan、Red、Implement、Green、Refactor。

不要求 architecture backtrace / fresh reconstruction / replay / attack。

## MC-1 — Generic Clean Rerun

```text
METHOD_CONDITION = TDD_CLEAN_RERUN
```

TDD 後要求 clean environment rerun，但不提供 ABFR backtrace、MSRS、three-closure structure。

## MC-2 — Full ABFR

```text
METHOD_CONDITION = TDD_ABFR
```

完整執行 Spec A。

---

# 7. Blindness Levels

## B0 — Open

Executor 知道 defect 類型。

## B1 — Method-Blind Defect

Executor 知道要使用 ABFR，但不知道 injected defect。

**第一輪推薦。**

## B2 — Area-Blind

只知道 task，不知道 defect 所在架構區。

## B3 — Fully Hidden Oracle

只知道正常需求；所有 defect truth 由 evaluator 隱藏。

---

# 8. Baseline Freeze

Evaluator 在任何 run 前必須凍結：

```text
repository
branch
commit SHA
working tree status
runtime version
dependency lock identity
test commands
fixture identity
container / environment identity
```

並建立：

```text
baseline-manifest.json
```

若 baseline 改變：

```text
EXPERIMENT_INTEGRITY = FAIL
```

---

# 9. Executor Canonical Packet

Executor 只能取得：

$$
I_{\text{executor}}
$$

最低包含：

```text
Spec A
Spec B Executor Prompt Contract
repository / source
baseline identity
task / requirements
declared architecture artifacts
allowed tests
tool contract
authority contract
freshness requirements
replay targets if condition = TDD_ABFR
equivalence profile if condition = TDD_ABFR
public witness registry if experiment design includes it
output schema
stop conditions
budget
```

---

# 10. Hidden Oracle Packet

Evaluator 額外保存：

$$
I_{\text{oracle}}
$$

可包含：

```text
injected defect
critical structural nodes
critical relations
expected divergences
hidden tests
hidden falsifying witnesses
expected three-closure verdict
authorized-equivalence cases
ground-truth MSRS equivalence classes
oracle evaluator scripts
```

任何 hidden oracle 不得暴露給 executor。

---

# 11. Oracle Leakage Rule

若 executor 直接或間接取得：

$$
I_{\text{oracle}}
$$

則：

```text
PV-02 ORACLE_ACCESSED
RUN_VALIDITY = INVALID
```

即使 final answer 正確也不計入 primary result。

---

# 12. Fresh Context Contract

每個 run 必須：

```text
FRESH_CONTEXT = true
```

不得提供：

- previous run transcripts；
- previous run summaries；
- other Agent reports；
- prior private scratch state；
- manually transferred hidden decisions。

允許：

- canonical source；
- Spec A；
- Spec B Executor Contract；
- explicitly versioned architecture artifacts。

---

# 13. Fresh Workspace Contract

若 experiment 要測 full Fresh Reconstruction，必須確保：

$$
\operatorname{Support}(P_S)
\cap
H_{\text{hidden}}
=
\varnothing
$$

可使用：

- clean checkout；
- disposable worktree；
- clean container；
- declared cache；
- pinned dependency store。

重點不是物理全新，而是沒有未宣告 previous-state causal support。

---

# 14. Tool Contract

Evaluator 固定：

```text
TOOLS_ALLOWED
TOOLS_FORBIDDEN
NETWORK_POLICY
PACKAGE_INSTALL_POLICY
FILE_WRITE_POLICY
TEST_EXECUTION_POLICY
CONTAINER_POLICY
```

理想上不同 Agent 使用 common denominator：

$$
T_{\cap}
=
\bigcap_iT_i
$$

若 Agent 缺必要工具：

```text
RUN_CLASS = CAPABILITY_LIMITED
```

不得直接歸類成 reasoning failure。

---

# 15. Authority Contract

固定：

```text
READ_SOURCE
WRITE_WORKTREE
RUN_TESTS
NETWORK
PUSH_GIT
DEPLOY
ACCESS_SECRETS
MODIFY_EXTERNAL_STATE
```

範例：

```text
READ_SOURCE = YES
WRITE_WORKTREE = YES
RUN_TESTS = YES
NETWORK = NO
PUSH_GIT = NO
DEPLOY = NO
ACCESS_SECRETS = NO
MODIFY_EXTERNAL_STATE = NO
```

---

# 16. Budget Contract

每個 condition 應固定或至少記錄：

```text
MAX_WALL_TIME
MAX_TOOL_CALLS
MAX_RECONSTRUCTION_ATTEMPTS
MAX_TEST_RUNS
MAX_TOKEN_BUDGET_IF_EXPOSED
```

平台不提供 token 時：

```text
TOKEN_BUDGET = UNKNOWN
```

禁止自行估造假數據。

---

# 17. Human Interaction Policy

primary run 原則：

$$
\boxed{
\text{No Non-Canonical Answer Injection}
}
$$

若 executor 問問題，只允許：

## Response Type A — Canonical Navigation

指出資訊已存在於哪個 canonical artifact。

## Response Type B — Missing Information

不直接補答案，記：

```text
AIR-2 MISSING_DOCUMENTATION
```

## Response Type C — Authority

依事先 contract 回應是否有權限。

任何新增設計答案、hidden dependency 提示、下一步建議都屬非 canonical intervention。

---

# 18. Additional Information Requests

所有 AIR 記錄：

```text
AIR_ID
RUN_ID
AIR_TYPE
REQUEST_TEXT
RESPONSE_TEXT
CANONICAL = true | false
CLOSURE_IMPACT
```

類型：

```text
AIR-1 CANONICAL_NAVIGATION
AIR-2 MISSING_DOCUMENTATION
AIR-3 HIDDEN_ENVIRONMENT
AIR-4 HIDDEN_DECISION
AIR-5 AUTHORITY_REQUEST
```

---

# 19. Human Intervention Count

定義：

$$
H_I(r)
$$

若 primary autonomous condition 中：

$$
H_I(r)>0
$$

且 intervention 對成功為必要：

```text
FRESH_AUTONOMOUS_CLOSURE = FAIL
```

run 仍可保留為 assisted evidence，但不能算 primary autonomous success。

---

# 20. Execution Protocol — TDD_ONLY

MC-0 只要求：

```text
1. Freeze baseline.
2. Write precise TDD plan.
3. Prove Red.
4. Implement minimum scope.
5. Prove Green.
6. Refactor.
7. Run relevant regression.
8. Emit final task result.
```

不得偷用 hidden ABFR oracle。

---

# 21. Execution Protocol — TDD_CLEAN_RERUN

MC-1 要求：

```text
1. Complete TDD flow.
2. Create clean / fresh-enough workspace.
3. Reinstall / restore declared dependencies.
4. Rerun tests.
5. Report whether clean rerun succeeds.
```

但不要求：

- architecture backtrace；
- MSRS；
- declared/observed/effective reconciliation；
- witness continuity；
- three-closure verdict。

---

# 22. Execution Protocol — TDD_ABFR

MC-2 必須完整執行：

$$
\boxed{
\text{TDD}
\rightarrow
\text{Backtrace}
\rightarrow
\text{Fresh Reconstruction}
\rightarrow
\text{Replay}
\rightarrow
\text{Attack}
\rightarrow
\text{Closure}
}
$$

並遵守 Spec A。

---

# 23. Executor Output Root

每個 run 產出：

```text
run/
  manifest.json
  protocol-compliance.json
  baseline.json
  tdd-plan.md
  behavioral-results.json
  backtrace.json
  architecture-diff.json
  msrs.json
  freshness.json
  replay.json
  witness-results.json
  air.json
  closure.json
  unresolved.json
  final-summary.md
```

MC-0 / MC-1 可省略不適用檔案，但 manifest 必須標：

```text
NOT_APPLICABLE
```

不能假裝缺檔不存在。

---

# 24. Protocol Compliance

最低欄位：

```text
execution_mode
subagent_used
oracle_accessed
previous_run_state_used
fresh_reconstruction_performed
equivalence_changed_post_hoc
witness_expectation_changed_post_hoc
baseline_changed
noncanonical_human_answer_used
```

---

# 25. Critical Structural Ground Truth

對 controlled benchmark，Evaluator 定義：

$$
K^*
$$

為 critical structural node set。

Executor 得到：

$$
V_r
$$

則：

$$
CSC(r)
=
\frac{
|V_r\cap K^*|
}{
|K^*|
}
$$

第一輪 critical defect benchmark 可要求：

$$
CSC=1
$$

或事前定義 threshold。

---

# 26. Critical Relation Ground Truth

Evaluator 定義：

$$
E^*
$$

Executor 得到：

$$
E_r
$$

則：

$$
CRA(r)
=
\frac{
|E_r\cap E^*|
}{
|E^*|
}
$$

---

# 27. Structural Jaccard

不同 Agent：

$$
V_i,V_j
$$

可計算：

$$
J_V(i,j)
=
\frac{
|V_i\cap V_j|
}{
|V_i\cup V_j|
}
$$

relation 同理：

$$
J_E(i,j)
=
\frac{
|E_i\cap E_j|
}{
|E_i\cup E_j|
}
$$

這些是 secondary metrics。

---

# 28. Divergence Ground Truth

Evaluator 定義：

$$
D^*
=
\{
d_1,\ldots,d_m
\}
$$

Executor 回報：

$$
\hat D_r
$$

計算：

$$
Precision_D
=
\frac{
|\hat D_r\cap D^*|
}{
|\hat D_r|
}
$$

$$
Recall_D
=
\frac{
|\hat D_r\cap D^*|
}{
|D^*|
}
$$

若：

$$
\hat D_r=\varnothing
$$

precision 記：

```text
UNDEFINED_NO_PREDICTIONS
```

不得自行設成 $1$。

---

# 29. Fresh Reconstruction Success

定義：

$$
FRS(r)
=
\begin{cases}
1,&\text{fresh reconstruction succeeds}\\
0,&\text{otherwise}
\end{cases}
$$

失敗必須再分類：

```text
FR-01 ... FR-07
```

不能只有「failed」。

---

# 30. Replay Verdict

每個 target：

$$
q_i
$$

輸出：

```text
PASS
PARTIAL
FAIL
INCONCLUSIVE
```

並附：

```text
equivalence_profile
observed_output
expected_relation
evidence
```

---

# 31. Witness Reproduction

Evaluator 可以保留 hidden critical witnesses：

$$
W^-_{\text{hidden}}
$$

或提供 public witness registry。

對 executor 成功重現者：

$$
Rep_r(w)=1
$$

定義：

$$
WRR(r)
=
\frac{
\sum_{w\in W^-}Rep_r(w)
}{
|W^-|
}
$$

---

# 32. Novel Witness

若 executor 找到新的：

$$
w_{\text{new}}
$$

Evaluator 必須 independent validate。

若有效：

```text
NOVEL_WITNESS = ACCEPTED
```

若其實 duplicate：

```text
NOVEL_WITNESS = DUPLICATE_SEMANTIC_CASE
```

若無效：

```text
NOVEL_WITNESS = REJECTED
```

---

# 33. Three-Closure Verdict Oracle

對 MC-2，Evaluator 可保存 expected：

$$
V^*_{3C}
$$

Executor 回報：

$$
\hat V_{3C}
$$

比較：

```text
EXACT_MATCH
COMPATIBLE_PARTIAL
WRONG_PASS
WRONG_FAIL
WRONG_INCONCLUSIVE
```

特別嚴格處理：

```text
WRONG_PASS
```

因為把 critical failure 當 PASS 是最危險錯誤。

---

# 34. Stage Vector

每個 MC-2 run 記：

$$
Z_r
=
(
z_B,
z_{BT},
z_{REC},
z_{MS},
z_F,
z_R,
z_D
)
$$

每個：

$$
z_i
\in
\{
PASS,
PARTIAL,
FAIL,
INCONCLUSIVE,
NOT\_APPLICABLE
\}
$$

---

# 35. Repeatability Metrics

同一 Agent 多次 fresh runs：

$$
r_1,\ldots,r_n
$$

對 scalar metric $m$：

$$
\bar m
=
\frac{1}{n}\sum_i m_i
$$

$$
s_m
=
\sqrt{
\frac{
\sum_i(m_i-\bar m)^2
}{
n-1
}
}
$$

對 categorical verdict：

- frequency；
- entropy；
- agreement。

---

# 36. Cross-Agent Verdict Agreement

可報：

- percent agreement；
- pairwise agreement；
- 適用時 Cohen's kappa；
- Fleiss' kappa；
- Krippendorff's alpha。

但：

$$
\boxed{
\text{Agreement}
\not\Rightarrow
\text{Correctness}
}
$$

所以必須與 oracle correctness 並列。

---

# 37. MSRS Comparison

不同 Agent 的 MSRS 不要求 literal identity。

若：

$$
M_i
\sim_{Q,\mathcal I}
M_j
$$

則：

```text
MSRS_AGREEMENT = EQUIVALENT
```

即使：

$$
M_i\neq M_j
$$

可輸出：

```text
IDENTICAL
EQUIVALENT
NON_EQUIVALENT
INCONCLUSIVE
```

---

# 38. Cost Metrics

每 run 記：

```text
tool_calls
test_runs
files_inspected
structural_nodes_visited
reconstruction_attempts
wall_time
token_usage_if_exposed
human_interventions
AIR_count
```

只有在 closure class 相同時，才比較 efficiency。

---

# 39. Experiment Integrity Gate

在任何 scoring 前：

$$
G_E
=
B_F
\land
T_F
\land
A_F
\land
C_F
\land
O_H
$$

其中：

- $B_F$：baseline frozen；
- $T_F$：tool contract fixed；
- $A_F$：authority fixed；
- $C_F$：fresh context；
- $O_H$：oracle hidden。

若：

$$
G_E=0
$$

則：

```text
RUN_VALIDITY = INVALID_FOR_PRIMARY_ANALYSIS
```

---

# 40. Protocol Violations

```text
PV-01 SUBAGENT_USED
PV-02 ORACLE_ACCESSED
PV-03 PREVIOUS_RUN_STATE_USED
PV-04 FRESH_RECONSTRUCTION_SKIPPED
PV-05 HIDDEN_TEST_MODIFIED
PV-06 EQUIVALENCE_CHANGED_POST_HOC
PV-07 WITNESS_EXPECTATION_CHANGED_POST_HOC
PV-08 NONCANONICAL_HUMAN_ANSWER_INJECTION
PV-09 BASELINE_CHANGED
PV-10 EVIDENCE_FABRICATED
PV-11 OTHER_AGENT_RESULT_ACCESSED
PV-12 TOOL_CONTRACT_EXCEEDED
```

任何 blocking PV：

```text
PROTOCOL_COMPLIANCE = FAIL
```

---

# 41. Primary Success Criteria

一個 MC-2 run 可標：

```text
ABFR_RUN_SUCCESS = true
```

最低要求：

1. Protocol Compliance PASS；
2. $C_B$ 正確；
3. critical $C_{BT}$ 不漏；
4. MSRS candidate 有效；
5. Freshness Contract 成立；
6. replay verdict 正確；
7. critical witness 正確；
8. $C_D$ 正確；
9. three-closure verdict 與 oracle 相容；
10. $H_I=0$。

---

# 42. Cross-Agent Reproducibility Criterion

對 project-task：

$$
(P,Q)
$$

若至少兩個不同 executor：

$$
A_i\neq A_j
$$

在多次 fresh runs 中滿足：

1. primary run validity；
2. critical structural coverage 達 threshold；
3. critical divergence detection 達 threshold；
4. fresh reconstruction 成功；
5. critical witness reproduction 達 threshold；
6. three-closure verdict 與 oracle 相容；
7. 不依賴非 canonical human intervention；

則：

$$
\boxed{
CAR(P,Q)=1
}
$$

---

# 43. Generalization Support Criterion

若：

$$
CAR(P_M,Q_M)=1
$$

且：

$$
CAR(P_N,Q_N)=1
$$

其中 $P_M$ 為 MSSP-native，$P_N$ 為 non-MSSP profile，則：

```text
CROSS_PROJECT_GENERALIZATION = SUPPORTED
```

只能寫：

```text
SUPPORTED
```

不得寫：

```text
PROVEN UNIVERSAL
```

---

# 44. Negative Result Handling

如果多數 Agent 無法完成 ABFR，不得偷偷修改 protocol 讓它們看起來成功。

應分類：

```text
METHOD_TOO_COMPLEX
AGENT_CAPABILITY_LIMIT
BENCHMARK_AMBIGUITY
ENVIRONMENT_RECONSTRUCTION_FAILURE
ADAPTER_FAILURE
WITNESS_PROTOCOL_TOO_COSTLY
OTHER
```

負面結果是合法研究結果。

---

# 45. Recommended Pilot

## Phase A — Smoke Test

同一 Agent：

$$
3
$$

次 fresh run。

目的：

- 檢查 protocol；
- 檢查 output schema；
- 檢查 reset；
- 檢查 oracle leakage。

## Phase B — Cross-Agent Pilot

至少：

$$
3
$$

個 AI executor，各：

$$
3
$$

次 fresh run。

## Phase C — Controls

同樣 executors 跑：

$$
MC\text{-}0,
MC\text{-}1,
MC\text{-}2
$$

## Phase D — Non-MSSP Transfer

加入至少一個 non-MSSP project。

---

# 46. Recommended Small Matrix

第一輪可：

$$
3
\text{ executors}
\times
2
\text{ projects}
\times
3
\text{ method conditions}
\times
3
\text{ runs}
=
54
\text{ runs}
$$

若資源不足，可先只比較 MC-0 與 MC-2：

$$
3
\times
2
\times
2
\times
3
=
36
$$

runs。

---

# 47. Evaluator Output

最終 evaluator 產出：

```text
evaluation/
  experiment-integrity.json
  per-run-results.json
  repeatability.json
  cross-agent-agreement.json
  structural-coverage.json
  divergence-detection.json
  freshness-results.json
  witness-results.json
  three-closure-results.json
  cost-results.json
  disagreement-review.md
  final-report.md
```

---

# 48. Disagreement Review

每個 critical disagreement：

| Claim | Agent A | Agent B | Oracle | Category | Resolution |
|---|---|---|---|---|---|

分類沿 Paper 05：

```text
DG-01 COVERAGE_DISAGREEMENT
DG-02 RELATION_INTERPRETATION
DG-03 EFFECTIVE_STATE_INTERPRETATION
DG-04 EQUIVALENCE_INTERPRETATION
DG-05 EVIDENCE_WEIGHTING
DG-06 TOOL_OBSERVATION
DG-07 ENVIRONMENT_DRIFT
DG-08 PROTOCOL_VIOLATION
DG-09 BENCHMARK_AMBIGUITY
DG-10 LEGITIMATE_ALTERNATIVE_ARCHITECTURE
```

---

# 49. Executor Prompt Contract

以下區塊可以直接提供給被測 AI。

不得把 evaluator-only oracle 區塊一起提供。

---

## ABFR Cross-AI Executor Prompt v0.1

你正在參與一個 **ABFR（Architecture Backtrace and Fresh Reconstruction）cross-AI fresh validation run**。

你不是在自由探索新的工程方法，也不是在重新設計 ABFR。

你要做的是：

**依照 Spec A — ABFR Methodology v0.1，在目前 project 與 task 上完成一次可稽核、可重播、可比較的 ABFR execution。**

### 執行模式

```text
EXECUTION_MODE = INLINE
SUBAGENT_PATH = NOT PROVIDED
FRESH_CONTEXT = REQUIRED
```

硬性規則：

1. 不使用 sub-agent、secondary model、delegated worker 或 hidden executor。
2. 不要求其他 AI 幫你完成任何階段。
3. 不讀取其他 executor 的結果。
4. 不依賴前一 run 的私人上下文。
5. 不改變 baseline、hidden tests、equivalence profile 或 witness expected verdict。
6. 不將未提供的資訊猜成已知。
7. 任何缺失資訊必須記為 AIR。
8. 任何 unresolved 不得靜默改成 PASS。
9. 不得在看到 replay / attack 結果後才修改成功標準。
10. Direct Runtime / UI plan 必須等三閉包 closure 後才可撰寫。

### 必須依序執行

```text
01 Freeze Baseline
02 Precise TDD Plan
03 Prove Red
04 Implement Minimum Scope
05 Prove Green
06 Refactor + Revalidate
07 Freeze Behavioral Baseline
08 Seed Architecture Backtrace
09 Traverse Dependencies / Authority / State / Evidence
10 Reconcile Declared / Observed / Effective
11 Decide Backtrace Closure
12 Derive MSRS Candidate
13 Validate Inclusion-Minimal Sufficiency
14 Perform Fresh Reconstruction
15 Check Full Freshness Contract
16 Replay Predeclared Targets
17 Freeze Validator / Equivalence / Witness Expectations
18 Run Positive Witnesses
19 Run Falsifying Witnesses
20 Check Axis Binding
21 Check Witness Reachability
22 Check Witness Continuity
23 Check Authorized Equivalence
24 Decide C_B
25 Decide C_S
26 Decide C_D
27 Decide Three-Closure Verdict
28 Emit Evidence
29 Stop
```

### Freshness Contract

你必須檢查：

```text
F_C Context Freshness
F_W Workspace Freshness
F_D Dependency Freshness
F_R Runtime-State Freshness
F_A Authority Freshness
F_X External Dependency Freshness
F_N Nondeterminism Control
```

Fresh 的意思是：

$$
\boxed{
\operatorname{Support}(P_S)
\cap
H_{\text{hidden}}
=
\varnothing
}
$$

不是「換一個資料夾」而已。

### MSRS

你要尋找：

$$
S\in\mathfrak M_Q
$$

使：

$$
\operatorname{Sufficient}(S,Q)=1
$$

且：

$$
\forall S'\subsetneq S,
\operatorname{Sufficient}(S',Q)=0
$$

只要求 inclusion-minimal，不要求 global minimum。

允許多個合法 MSRS。

### Replay

Replay equivalence 必須使用 benchmark 提供的：

$$
\simeq_Q
$$

不得自行放寬。

### Discriminative Closure

對 mandatory clause：

$$
C_D(c)
=
C_{\text{witness}}
\land
C_{\text{axis}}
\land
C_{\text{reach}}
\land
C_{\text{continuity}}
\land
C_{\text{eq}}
$$

如果 validator 只會 PASS，失敗。

如果 validator 會 FAIL 但 fail 在錯的語義軸，也失敗。

### Output

你必須產生：

```text
manifest.json
protocol-compliance.json
baseline.json
tdd-plan.md
behavioral-results.json
backtrace.json
architecture-diff.json
msrs.json
freshness.json
replay.json
witness-results.json
air.json
closure.json
unresolved.json
final-summary.md
```

### AIR

若你缺資訊，只能記錄：

```text
AIR-1 CANONICAL_NAVIGATION
AIR-2 MISSING_DOCUMENTATION
AIR-3 HIDDEN_ENVIRONMENT
AIR-4 HIDDEN_DECISION
AIR-5 AUTHORITY_REQUEST
```

不得要求 evaluator 直接告訴你 hidden architecture answer。

### Stop Conditions

遇到以下任一條件停止：

```text
SC-01 THREE_CLOSURE_PASS
SC-02 BLOCKING_BEHAVIORAL_FAIL
SC-03 BLOCKING_BACKTRACE_FAIL
SC-04 BLOCKING_FRESHNESS_FAIL
SC-05 BLOCKING_REPLAY_FAIL
SC-06 BLOCKING_DISCRIMINATIVE_FAIL
SC-07 CRITICAL_UNRESOLVED
SC-08 ENVIRONMENT_IMPOSSIBLE_UNDER_CONTRACT
SC-09 BUDGET_EXHAUSTED
SC-10 PROTOCOL_VIOLATION
```

### Final Verdict

輸出：

```text
C_B = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_BT = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_MSRS = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_F = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_R = PASS | PARTIAL | FAIL | INCONCLUSIVE
C_D = PASS | PARTIAL | FAIL | INCONCLUSIVE
THREE_CLOSURE_VERDICT = PASS | PARTIAL | FAIL | INCONCLUSIVE
STOP_REASON = SC-XX
PROTOCOL_COMPLIANCE = PASS | FAIL
```

只有：

```text
THREE_CLOSURE_VERDICT = PASS
```

或 benchmark 明示允許的：

```text
PARTIAL_WITH_NONBLOCKING_DEFERRED_ITEMS
```

之後，才可以撰寫 Direct Runtime / UI plan。

---

# 50. Evaluator Scoring Order

Evaluator 必須依序評分：

1. Experiment Integrity；
2. Protocol Compliance；
3. Behavioral Correctness；
4. Structural Coverage；
5. Divergence Detection；
6. MSRS Validity；
7. Freshness；
8. Replay；
9. Witness Reproduction；
10. Discriminative Closure；
11. Three-Closure Verdict；
12. Efficiency。

不得先用 final task success 覆蓋 protocol failure。

---

# 51. Closure Correctness 優先

如果 Agent A：

$$
G_{\text{3C}}(A)=0
$$

但成本很低，

Agent B：

$$
G_{\text{3C}}(B)=1
$$

但成本較高，

不得因 A 更省 token 就判 A 較好。

排序原則：

$$
\boxed{
\text{Closure Correctness}
>
\text{Protocol Compliance}
>
\text{Efficiency}
}
$$

---

# 52. Method-Level Fresh Replay Criterion

若至少兩個不同 fresh AI executor 能在相同 canonical protocol 下獨立完成相容 ABFR run，則：

```text
METHOD_LEVEL_FRESH_REPLAY = SUPPORTED
```

若只能原始 Agent 成功：

```text
METHOD_LEVEL_FRESH_REPLAY = NOT_SUPPORTED
```

若 evidence 不足：

```text
METHOD_LEVEL_FRESH_REPLAY = INCONCLUSIVE
```

---

# 53. General Method Claim Levels

## Level 0 — Anecdotal

```text
single executor
single project
```

## Level 1 — Repeatable

```text
same executor
multiple fresh runs
```

## Level 2 — Cross-Agent Reproducible

```text
multiple independent executors
```

## Level 3 — Cross-Model Transportable

```text
same shell
different models
```

## Level 4 — Cross-Project Generalizable

```text
MSSP + non-MSSP
```

## Level 5 — Comparative Benefit

```text
ABFR outperforms controls on predefined primary endpoints
```

只有 Level 4–5 才適合較強的「通用方法論」措辭。

---

# 54. 不宣稱事項

本規格明確不宣稱：

1. 所有 AI 都必須成功。
2. trace 必須一致。
3. agreement 等於 correctness。
4. 高 Jaccard 等於 architecture reasoning 正確。
5. 三次 run 足以證明統計顯著。
6. public repository 無 contamination。
7. Agent shell 可忽略。
8. environment construction 不是方法的一部分。
9. LLM judge 可取代 deterministic oracle。
10. sub-agent 永遠無效。
11. Inline Execution 是最終最佳形式。
12. ABFR 已經優於 TDD-only。
13. ABFR 已經具有 cross-agent reproducibility。
14. MSSP-native 成功等於 generalization。
15. 一次 non-MSSP 成功等於 universal applicability。

---

# 55. Canonical Result Statement

在第一輪 pilot 前，唯一合法的狀態敘述是：

> **ABFR 已具備 cross-AI validation protocol，但 cross-agent reproducibility、cross-model transportability、cross-project generalizability 與 comparative benefit 仍待實驗。**

不得提前宣稱：

```text
ABFR is a universal AI engineering methodology.
```

---

# 56. 完成條件

Spec B v0.1 完成後，可以正式開始：

```text
Cross-AI Pilot Round 1
```

建議順序：

```text
1. Protocol Smoke Test
2. Same-Agent Repeatability
3. Cross-Agent Pilot
4. TDD-only Control
5. Generic Clean-Rerun Control
6. Non-MSSP Transfer
7. Disagreement Review
8. Empirical Paper 06
```

---

## Canonical status

本文為 **Spec B — Cross-AI ABFR Validation Protocol v0.1**。

狀態：

- Evaluator / Executor separation: defined.
- Oracle isolation: defined.
- Fresh independent run: required.
- Inline Execution: mandatory.
- Sub-agent path: not provided.
- Method conditions: defined.
- Blindness levels: defined.
- Tool / authority / budget contracts: defined.
- AIR / human intervention policy: defined.
- Structured artifacts: defined.
- Structural coverage metrics: defined.
- Divergence metrics: defined.
- MSRS comparison: defined.
- Fresh reconstruction scoring: defined.
- Witness reproduction: defined.
- Three-closure scoring: defined.
- Experiment integrity gate: defined.
- Protocol violations: defined.
- Cross-Agent Reproducibility criterion: defined.
- Method-Level Fresh Replay criterion: defined.
- General-method claim levels: defined.
- Empirical validation: pending.
