# MHCR v0.2 Validation Report

**Version:** 0.2.0  
**Branch:** `workbench/mhcr-v0.2-persistent-fast-path`  
**Baseline:** accepted MHCR v0.1 reference MVP (27/27 tests)  
**Scope:** Persistent Core & Fast Path only; no remote provider, GCM, PCMT, or unrestricted constructor expansion.

## Implemented scope

- Repository protocol and stdlib SQLite schema v1.
- Persistent capability/provider semantic metadata.
- Persistent trusted/revoked state across restart.
- Explicit local executor rebinding; missing bindings restore providers as unavailable.
- Trusted semantic index keyed by `(task_family, input_type, output_type, exactness)`.
- `Resolver.resolve_one()` exact indexed lookup.
- Replayable canonical registry mutation events in JSONL.
- Explicit `fast` and `full` runtime paths.
- Fast path bypasses composition and construction while retaining verification and minimal accounting.
- Persistent provider cost profiles; task-local accounting can remain ephemeral.
- Resolver microbenchmark against a v0.1-style full scan reference.
- Persistent restart demo: first task constructs/promotes, SQLite closes, runtime restarts/rebinds, second unseen input reuses the persisted solver through the fast path.

## Fresh regression evidence

Command:

```bash
PYTHONPATH=src pytest -q
```

Result:

```text
...........................................                              [100%]
43 passed
```

The original v0.1 27-test behavior remains covered inside the expanded suite.

## Compile evidence

```bash
python -m compileall -q src
```

Result: exit 0.

## Persistent demo evidence

```bash
PYTHONPATH=src python -m mhcr.demo
```

Observed release-tree result included:

```json
{
  "constructor_count": 1,
  "first": {
    "value": 16,
    "source": "constructed",
    "execution_path": "full",
    "acquisition_events": 1,
    "accounting": "closed_accounted"
  },
  "restart_count": 1,
  "second": {
    "value": 49,
    "source": "resolved",
    "execution_path": "fast",
    "acquisition_events": 0,
    "accounting": "closed_accounted"
  },
  "trusted_capability_count": 1
}
```

The second run occurs after SQLite close/reopen and explicit executor rebinding. The restored runtime has no constructor, so success cannot come from reconstructing the solver.

## Resolver performance evidence

Fresh release-tree benchmark, 2,000 iterations per size:

```text
registry_size=1000
indexed_ns_per_lookup=250.107
scan_ns_per_lookup=43810.11
speedup_ratio=175.16546917919132

registry_size=5000
indexed_ns_per_lookup=259.315
scan_ns_per_lookup=224436.8415
speedup_ratio=865.4988778126989
```

These are environment-relative measurements, not universal hardware guarantees. The acceptance claim is only that the indexed path measurably beats the deliberately v0.1-style linear scan on the tested synthetic registries.

## Snapshot / replay consistency

A fresh validation created candidate/trusted/revoked capabilities and provider records through a registry connected to both SQLite and JSONL history. The resulting semantic state was restored independently from:

1. SQLite snapshot; and
2. JSONL registry-event replay.

With the same explicit executor bindings, capability semantic/trust state and provider identity/availability metadata matched exactly.

Result:

```text
snapshot_replay_equivalent=PASS
```

## Wheel and clean-install evidence

Build:

```bash
python -m pip wheel . --no-deps --no-build-isolation -w dist_v02
```

Result:

```text
mhcr-0.2.0-py3-none-any.whl
```

The wheel was installed into a new venv with `--no-deps`.

Validation inside that venv:

```text
clean_import=PASS version=0.2.0
```

The installed wheel then ran `python -m mhcr.demo` successfully and again produced full-path first acquisition followed by post-restart fast-path unseen reuse.

## Acceptance gates

- [x] Trusted registry survives restart.
- [x] Revocation survives restart.
- [x] Provider callable is not serialized; executor rebinding is explicit.
- [x] Missing executor binding restores provider unavailable, not executable.
- [x] Exact trusted resolution uses semantic index.
- [x] Revocation and promotion update the index.
- [x] Fast path bypasses composer and constructor.
- [x] Verification remains mandatory on fast path.
- [x] GCAL provider cost profile survives restart.
- [x] Task-local cost can remain non-persistent.
- [x] Registry mutations are replayable from JSONL.
- [x] SQLite snapshot and JSONL replay produce equivalent semantic state in validation.
- [x] Indexed resolver beats full-scan reference in measured synthetic benchmarks.
- [x] Full suite passes on version 0.2.0 tree.
- [x] Wheel builds and installs in a clean venv.

## Deliberate v0.2 limits

- Providers remain local Python realizations; no HTTP/cloud adapter is included.
- Python executor and verifier callables are not serialized.
- SQLite is a reference persistence backend, not a production mandate.
- Task dependency graphs are runtime scoped; v0.2 persists provider cost profiles rather than a universal historical task graph.
- Constructor remains safe-template based.
- No GCM or PCMT routing is included.
- GCAL does not infer unknown external physical cost.

## Verdict

MHCR v0.2 meets the **Persistent Core & Fast Path** milestone: the v0.1 mutable capability loop now survives process restart, preserves trust/revocation semantics, can be reconstructed from canonical events, and gives known trusted capabilities an indexed execution path that avoids acquisition machinery. The next planned milestone remains v0.3 Provider Fabric and is not part of this release.
