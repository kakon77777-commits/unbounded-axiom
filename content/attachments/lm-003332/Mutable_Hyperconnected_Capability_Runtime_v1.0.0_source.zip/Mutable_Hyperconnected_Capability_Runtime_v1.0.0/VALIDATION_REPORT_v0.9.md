# MHCR v0.9.0 Validation Report

**Milestone:** MHCR v0.9 — Heterogeneous Substrate Routing  
**Date:** 2026-08-30  
**Package version:** `0.9.0`  
**Engineering branch:** `workbench/mhcr-v0.9-heterogeneous-substrate-routing`  
**Pre-seal feature commit:** `a559d3c`  

## 0. Baseline identity

v0.9 began from the immutable MHCR v0.8 source archive:

```text
Mutable_Hyperconnected_Capability_Runtime_v0.8.0_source.zip
SHA-256 = 5817eee99a295602f7a6739d3736854bfa0311fe0f41533f78805c830b21e39f
```

The GCM integration target remained the accepted C2 candidate:

```text
GCM_Phase_C_C2_Goal_Decomposition_Candidate_Proposal_FINAL_CANDIDATE.zip
SHA-256 = c11895b856100285710d97b8996ee9fa1e5d12c8f9796ec8fecc9d2ede3584bc
package = gcm-reference-runtime 0.4.0
```

The outer accepted delivery inspected for that candidate was:

```text
GCM_Phase_C_C2_FINAL_ACCEPTED_Delivery_2026-08-30.zip
SHA-256 = 8c073e638cb8310dfd8547f6b5c854216ad5aaa86cb5d39c6c3c1c2dfe4d641f
```

MHCR consumes only the accepted GCM Phase-B deterministic planning/resource/allocation APIs. v0.9 does not grant MHCR GCM World/Foundation mutation authority and does not treat GCM allocation as execution authority or World commit.

## 1. v0.9 production scope

v0.9 adds a typed substrate layer between provider routing and GCM logical allocation.

New/extended production surfaces include:

- `src/mhcr/substrate.py`
  - `SubstrateKind`
  - `SubstrateRealization`
  - `TransitionLawClass`
  - `PCMTProfile`
  - `ComputationalMorphologyProfile`
  - `SubstrateProfile`
  - `SubstrateProfileStore`
  - `SubstrateSelectionCertificate`
  - `SubstrateSelection`
  - `SubstrateSelector`
- `TaskContract.substrate_policy`
- `GCMProviderBinding.substrate_profile_id`
- substrate evidence in `GCMAllocationDecision`
- substrate evidence in `COMPUTE_ALLOCATION_APPLIED`
- SQLite substrate-profile persistence / schema v8
- JSONL substrate-profile replay
- `src/mhcr/substrate_demo.py`

v0.9 deliberately does **not** add a physical FPGA/neuromorphic/phase/quantum scheduler or hardware backend.

## 2. Canonical substrate vocabulary

`SubstrateKind` contains:

```text
CPU
GPU
FPGA
EVENT_DRIVEN
NEUROMORPHIC
PHASE
QUANTUM
SPECIAL_ACCELERATOR
```

Every profile separately declares realization:

```text
NATIVE
SIMULATED
EMULATED
REMOTE_SERVICE
HYBRID
```

This preserves:

```text
Substrate Profile != Physical Hardware Proof
SIMULATED / EMULATED != NATIVE
```

The reference demo uses only:

```text
CPU          -> NATIVE
EVENT_DRIVEN -> SIMULATED
PHASE        -> SIMULATED
```

No physical phase machine, quantum device, neuromorphic chip or FPGA is claimed by this artifact.

## 3. PCMT / 24–72 extension boundary

`SubstrateProfile` can carry optional PCMT seven-coordinate metadata:

```text
Phase Ontology
Phase Representation
Architecture
Dynamics
Coupling
Memory
Output
```

and optional computational morphology metadata:

```text
bottom_space
update_organization
observation_mode
transition_law
```

These are extension profiles. MHCR core capability identity and trust do not depend on PCMT/GIPE theory being installed or accepted as a physical-hardware claim.

## 4. Substrate selector semantics

The selector applies hard filtering before soft preference ordering.

Validated hard boundaries include:

- exact task vs `supports_exact`;
- allowed profile/kind;
- required feature tags;
- required transition-law classes;
- native-only execution;
- simulated/emulated/remote/hybrid opt-in/out;
- energy ceiling;
- switching-cost ceiling;
- UNKNOWN hard-limit evidence fails closed.

Soft preference ordering supports preferred profile IDs and preferred kinds and emits deterministic `SubstrateSelectionCertificate` evidence.

Default substrate policy preserves v0.8 legacy unprofiled bindings. Non-default substrate policy fails closed on unprofiled bindings.

## 5. GCM integration semantics

The v0.9 bridge performs:

```text
RDR health/provider-policy ordering
-> substrate hard filter / deterministic substrate ordering
-> accepted GCM B2 resource snapshot
-> accepted GCM B1 safe planning
-> accepted GCM B3 capacity-constrained allocation
-> MHCR provider allowlist
-> execution
-> verifier
```

A v0.9 integration bug found during TDD was repaired before seal: substrate selector order originally filtered bindings correctly but `mhcr_priority` still used the pre-substrate RDR provider order. The regression test showed an event-driven preference being replaced by the original phase-first order inside GCM B1. The root fix derives GCM candidate rank from the post-substrate binding order. This preserves default behavior while allowing explicit substrate preference to reach GCM.

## 6. Runtime / verification boundary

Validated runtime invariants:

```text
Capability Semantics != Substrate
Substrate Preference != Resource Feasibility
GCM Allocation != Provider Execution
GCM Allocation != Authority Grant
GCM Allocation != World Commit
```

The same capability verifier accepts outputs produced by native CPU, simulated event-driven, and simulated phase providers when they implement the same semantic transition.

When a selected phase provider fails during actual execution, MHCR does not silently cross-substrate fail over to CPU/event providers that were not selected by the current GCM allocation.

When a preferred substrate is capacity-infeasible, GCM B3 can legally select another still-admissible substrate. That fallback is recorded in allocation/runtime evidence.

## 7. SQLite lineage / restart

SQLite schema advances from v7 to v8 by adding the substrate-profile catalog.

A migration probe was performed using the actual v0.8 `SQLiteRepository` to construct a genuine schema-v7 database containing:

- one trusted capability;
- one GCM resource binding.

The same file was opened by v0.9 and validated as:

```text
v0.8 schema = 7
v0.9 schema = 8
capability preserved = PASS
GCM binding preserved = PASS
new substrate catalog initially empty = PASS
```

Runtime restart tests also preserve substrate profiles and GCM bindings and reproduce the same semantic phase selection after executor rebinding.

## 8. Standalone MHCR regression

The standalone source tree was validated without `gcm_runtime` on `PYTHONPATH`.

Collected executable non-historical-demo tests:

```text
179
```

Result:

```text
179 PASS
```

Historical demo regression was isolated because sandbox-heavy process startup can exceed a single harness command timeout when combined with the whole suite:

```text
first shard  = 5/5 PASS
second shard = 5/5 PASS
historical total = 10/10 PASS
```

Thus standalone executable regression coverage is:

```text
189 PASS
```

The seven modules requiring the optional GCM package were separately checked without GCM installed/on `PYTHONPATH`; each was skipped explicitly with `No module named 'gcm_runtime'`, while a normal MHCR control test passed. This confirms the optional-dependency boundary rather than treating absence of GCM as a runtime failure.

## 9. Accepted-GCM focused integration gate

With the accepted GCM candidate source on `PYTHONPATH`, the focused v0.8/v0.9 integration modules collected and passed:

```text
24 / 24 PASS
```

The gate includes:

- Phase-B adapter behavior;
- provider policy/resource routing;
- allocation-gated runtime execution;
- v0.8 GCM demo;
- substrate/GCM adapter integration;
- cross-substrate runtime verification;
- fallback/no-unauthorized-failover;
- restart substrate semantics;
- v0.9 substrate demo.

## 10. Source demo semantic evidence

`python -m mhcr.substrate_demo` with accepted GCM source produced deterministic semantic results:

```text
phase preference          -> provider.phase / phase / simulated
simulation disallowed     -> provider.cpu   / cpu   / native
event preference          -> provider.event / event_driven / simulated
phase energy ceiling      -> provider.cpu   / cpu   / native / fallback=true
restart                    -> provider.phase / phase / simulated
restored profile count    -> 3
restored binding count    -> 3
World commit events       -> 0
```

Actual execution trace:

```text
phase
cpu
event
cpu
phase-restart
```

## 11. Compile gate

```text
python -m compileall -q src
```

Result: PASS.

## 12. Dual-wheel package integration

Locally built wheels:

```text
mhcr-0.9.0-py3-none-any.whl
pre-seal SHA-256 = 0ee4f34efbb255bbc88b47fffee7ab52ee6e587f96bb8a602e727e4bba7c571a

gcm_reference_runtime-0.4.0-py3-none-any.whl
SHA-256 = 10231bbbc43cd1c39fa8cf6c72020b9600cb7f33b92a7d677cb48db7aa6ee1c9
```

Both local wheels were installed into a fresh venv with `--no-deps`. This harness currently stores the already-installed `jsonschema` dependency under `/opt/pyvenv`, while a nested `venv --system-site-packages` resolves system paths from `/usr/bin` and therefore does not inherit that harness site-packages directory. For the offline integration probe, `/opt/pyvenv/lib/python3.13/site-packages` was injected only as the dependency path.

Package origins were explicitly verified:

```text
mhcr         -> <fresh venv>/site-packages/mhcr/__init__.py
gcm_runtime  -> <fresh venv>/site-packages/gcm_runtime/__init__.py
jsonschema   -> /opt/pyvenv/lib/python3.13/site-packages/jsonschema/__init__.py
```

Installed versions:

```text
mhcr = 0.9.0
gcm-reference-runtime = 0.4.0
```

Installed `python -m mhcr.substrate_demo` produced byte-for-byte identical JSON to the source-tree demo:

```text
source semantic JSON == installed semantic JSON : PASS
```

## 13. Deliberate non-claims

v0.9 does not claim:

- physical CPU/GPU reservation;
- production distributed scheduling;
- real FPGA execution;
- real neuromorphic execution;
- physical/native phase-computer execution;
- quantum-hardware execution;
- substrate preference is globally optimal;
- PCMT/24–72 theory is a physical-hardware proof;
- v1.0 final convergence is complete.

## 14. Core acceptance matrix

```text
Persistent substrate profile catalog          PASS
PCMT seven-coordinate round-trip               PASS
24/72 morphology extension round-trip          PASS
Realization honesty (native/sim/etc.)           PASS
Default legacy binding behavior                 PASS
Non-default unprofiled fail-closed              PASS
Exact/native/simulation hard filtering          PASS
Feature / transition-law filtering              PASS
Unknown hard metric != zero                     PASS
Energy / switching ceilings                     PASS
Deterministic substrate certificate             PASS
Accepted GCM ResourceKind.OTHER integration      PASS
Profile/GCM resource-kind mismatch rejection    PASS
Substrate preference reaches GCM ranking        PASS
GCM B3 may override preference by capacity      PASS
Same verifier across substrates                 PASS
No unauthorized post-allocation failover        PASS
Runtime substrate evidence                      PASS
SQLite v7 -> v8 migration                       PASS
Restart semantic selection                      PASS
Standalone optional-GCM boundary                PASS
Source demo                                     PASS
Dual-wheel installed demo                       PASS
Source/installed semantic equality              PASS
World commit events = 0                         PASS
```

## 15. Implementation-side verdict

Under the v0.9 reference scope:

```text
MHCR v0.9 = IMPLEMENTATION VALIDATED / READY FOR FINAL ARTIFACT SEAL
```

The strongest correct capability statement is:

> MHCR v0.9 extends its optional GCM Phase-B compute-allocation bridge with persistent, typed heterogeneous-substrate profiles; deterministic substrate hard filtering and preference certificates; GCM-backed logical resource feasibility; allocation-gated execution; substrate-aware evidence, fallback and restart semantics; and reference routing demonstrations across native CPU plus simulated event-driven and phase profiles, without claiming physical specialized hardware.

The final source ZIP / wheel / external validation-report checksum manifest is intentionally produced outside the immutable source commit to avoid recursive self-checksum coupling.
