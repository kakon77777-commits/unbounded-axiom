from __future__ import annotations

import sqlite3
from pathlib import Path

from mhcr.gcm_integration import (
    GCMCapacityBinding,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.history import EventLog
from mhcr.sqlite_repository import SQLiteRepository


def _binding() -> GCMProviderBinding:
    return GCMProviderBinding(
        binding_id="bind.gpu",
        provider_id="provider.gpu",
        resource_id="resource.gpu",
        configuration_id="cfg.fast",
        executor_id="provider.gpu",
        resource_kind="gpu",
        capabilities=("numeric", "square"),
        dimensions=(GCMCapacityBinding("memory.vram.bytes", "byte", 64, 12),),
        estimates={"latency_ms": 2.5, "monetary_cost": 0.01},
        metadata={"source": "test"},
    )


def test_sqlite_schema_v7_round_trips_gcm_bindings(tmp_path: Path) -> None:
    repo = SQLiteRepository(tmp_path / "mhcr.db")
    history = EventLog(tmp_path / "history.jsonl")
    store = GCMResourceBindingStore(repository=repo, event_log=history)
    stored = store.upsert(_binding())

    assert repo.schema_version == 8
    repo.close()

    reopened = SQLiteRepository(tmp_path / "mhcr.db")
    store2 = GCMResourceBindingStore(repository=reopened)
    assert store2.get(stored.binding_id) == stored
    assert store2.for_provider("provider.gpu") == (stored,)
    reopened.close()


def test_v6_database_migrates_to_v7_without_losing_existing_tables(tmp_path: Path) -> None:
    db = tmp_path / "legacy.db"
    repo = SQLiteRepository(db)
    repo.close()
    with sqlite3.connect(db) as connection:
        connection.execute("UPDATE metadata SET value='6' WHERE key='schema_version'")
        connection.execute("DROP TABLE IF EXISTS gcm_resource_bindings")
        connection.commit()

    migrated = SQLiteRepository(db)
    assert migrated.schema_version == 8
    migrated.save_gcm_resource_binding(_binding())
    assert migrated.load_gcm_resource_bindings()[0].binding_id == "bind.gpu"
    migrated.close()


def test_jsonl_replays_gcm_resource_binding_semantics(tmp_path: Path) -> None:
    history = EventLog(tmp_path / "history.jsonl")
    store = GCMResourceBindingStore(event_log=history)
    binding = store.upsert(_binding())
    store.remove(binding.binding_id)
    restored = history.replay_gcm_resource_bindings()
    assert restored.records() == ()

    store.upsert(binding)
    restored = history.replay_gcm_resource_bindings()
    assert restored.get(binding.binding_id) == binding
