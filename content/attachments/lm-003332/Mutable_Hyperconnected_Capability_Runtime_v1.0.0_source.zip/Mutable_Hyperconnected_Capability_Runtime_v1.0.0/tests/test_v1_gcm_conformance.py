import pytest

pytest.importorskip("gcm_runtime")

from mhcr.acceptance import run_acceptance
from mhcr.conformance import ConformanceCaseStatus, ConformanceClaim, run_conformance


def test_v1_gcm_extension_conformance_is_8_of_8_pass():
    result = run_conformance("MHCR-GCM-R1")
    assert result.claim is ConformanceClaim.CONFORMANT
    assert result.required_passed == 8
    assert result.required_failed == 0
    assert [case.case_id for case in result.cases] == [f"G{i:02d}" for i in range(1, 9)]
    assert all(case.status is ConformanceCaseStatus.PASS for case in result.cases)


def test_v1_acceptance_with_gcm_requires_gcm_profile():
    result = run_acceptance(include_gcm=True)
    assert result.accepted is True
    assert result.gcm is not None
    assert result.gcm.required_passed == 8
