from __future__ import annotations

import sqlite3

from mhcr.gcm_integration import GCMProviderBinding, GCMResourceBindingStore
from mhcr.history import EventLog
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.substrate import (
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
    TransitionLawClass,
)


def profile() -> SubstrateProfile:
    return SubstrateProfile(
        profile_id="substrate.event.sim.v1",
        kind=SubstrateKind.EVENT_DRIVEN,
        realization=SubstrateRealization.SIMULATED,
        gcm_resource_kind="other",
        features=("event", "stream"),
        transition_laws=(TransitionLawClass.DETERMINISTIC,),
        supports_exact=True,
    )


def test_sqlite_v8_round_trips_substrate_profiles(tmp_path):
    repo = SQLiteRepository(tmp_path / "mhcr.db")
    store = SubstrateProfileStore(repository=repo)
    item = store.upsert(profile())
    assert repo.schema_version == 8
    repo.close()

    reopened = SQLiteRepository(tmp_path / "mhcr.db")
    restored = SubstrateProfileStore(repository=reopened)
    assert restored.get(item.profile_id) == item
    assert restored.records() == (item,)
    reopened.close()


def test_v7_database_migrates_to_v8_without_losing_gcm_bindings(tmp_path):
    db = tmp_path / "legacy.db"
    repo = SQLiteRepository(db)
    binding = GCMProviderBinding(
        binding_id="bind.cpu",
        provider_id="provider.cpu",
        resource_id="resource.cpu",
        configuration_id="cfg.cpu",
        executor_id="provider.cpu",
        resource_kind="cpu",
    )
    repo.save_gcm_resource_binding(binding)
    repo.close()

    with sqlite3.connect(db) as connection:
        connection.execute("DROP TABLE IF EXISTS substrate_profiles")
        connection.execute("UPDATE metadata SET value='7' WHERE key='schema_version'")
        connection.commit()

    migrated = SQLiteRepository(db)
    assert migrated.schema_version == 8
    assert migrated.load_gcm_resource_bindings() == (binding,)
    assert migrated.load_substrate_profiles() == ()
    migrated.close()


def test_jsonl_replays_substrate_profile_catalog(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    store = SubstrateProfileStore(event_log=log)
    item = store.upsert(profile())
    replayed = log.replay_substrate_profiles()
    assert replayed.get(item.profile_id) == item

    store.remove(item.profile_id)
    replayed = log.replay_substrate_profiles()
    assert replayed.records() == ()
