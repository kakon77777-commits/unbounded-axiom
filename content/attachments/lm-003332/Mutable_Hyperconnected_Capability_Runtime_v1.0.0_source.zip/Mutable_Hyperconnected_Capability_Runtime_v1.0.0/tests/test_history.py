import json

from mhcr.history import Event, EventLog


def test_event_log_appends_jsonl_without_overwriting_existing_events(tmp_path):
    path = tmp_path / "events.jsonl"
    log = EventLog(path)
    log.append(Event("CAPABILITY_CANDIDATE_CREATED", {"capability_id": "cap.foo"}))
    log.append(Event("CAPABILITY_PROMOTED", {"capability_id": "cap.foo"}))

    lines = path.read_text(encoding="utf-8").splitlines()

    assert len(lines) == 2
    assert json.loads(lines[0])["event_type"] == "CAPABILITY_CANDIDATE_CREATED"
    assert json.loads(lines[1])["event_type"] == "CAPABILITY_PROMOTED"


def test_event_log_reads_back_typed_events(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    original = Event("SOLVER_FAILED", {"reason": "counterexample"})
    log.append(original)

    events = log.read_all()

    assert len(events) == 1
    assert events[0].event_type == "SOLVER_FAILED"
    assert events[0].data == {"reason": "counterexample"}


def test_replay_counts_preserves_promotion_and_failure_history(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    log.append(Event("CAPABILITY_PROMOTED", {"id": "a"}))
    log.append(Event("CAPABILITY_PROMOTED", {"id": "b"}))
    log.append(Event("SOLVER_FAILED", {"id": "c"}))

    counts = log.replay_counts()

    assert counts == {"CAPABILITY_PROMOTED": 2, "SOLVER_FAILED": 1}
