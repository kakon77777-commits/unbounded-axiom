from __future__ import annotations

import pytest

pytest.importorskip("gcm_runtime")

from mhcr.gcm_integration import (
    GCMCapacityBinding,
    GCMIntegrationError,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.models import Capability, SubstratePolicy, TaskContract, TrustState
from mhcr.routing import CostEvidence, CostMetric
from mhcr.substrate import (
    PCMTProfile,
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
    TransitionLawClass,
)


def capability() -> Capability:
    return Capability(
        capability_id="cap.transform",
        version="1.0.0",
        task_family="transform",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.phase", "provider.event", "provider.cpu"),
        verifier_id="verify.transform",
        trust_state=TrustState.TRUSTED,
    )


def profiles() -> SubstrateProfileStore:
    store = SubstrateProfileStore()
    store.upsert(SubstrateProfile(
        "substrate.cpu.native.v1", SubstrateKind.CPU, SubstrateRealization.NATIVE,
        gcm_resource_kind="cpu", features=("scalar",),
        energy_units=CostMetric(3, CostEvidence.MEASURED),
        switching_cost_units=CostMetric(0.5, CostEvidence.DECLARED),
    ))
    store.upsert(SubstrateProfile(
        "substrate.event.sim.v1", SubstrateKind.EVENT_DRIVEN, SubstrateRealization.SIMULATED,
        gcm_resource_kind="other", features=("event", "stream"),
        transition_laws=(TransitionLawClass.DETERMINISTIC,),
        energy_units=CostMetric(4, CostEvidence.ESTIMATED),
    ))
    store.upsert(SubstrateProfile(
        "substrate.phase.sim.v1", SubstrateKind.PHASE, SubstrateRealization.SIMULATED,
        gcm_resource_kind="other", features=("phase",),
        transition_laws=(TransitionLawClass.DETERMINISTIC,),
        energy_units=CostMetric(8, CostEvidence.ESTIMATED),
        pcmt=PCMTProfile(
            "relational", "complex-state", "von-neumann-simulated", "coupled-update",
            "explicit", "persistent-state", "typed-result",
        ),
    ))
    return store


def binding(
    binding_id: str,
    provider_id: str,
    resource_id: str,
    config_id: str,
    resource_kind: str,
    profile_id: str,
    capacity: int = 16,
    required: int = 8,
) -> GCMProviderBinding:
    return GCMProviderBinding(
        binding_id=binding_id,
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=config_id,
        executor_id=provider_id,
        resource_kind=resource_kind,
        capabilities=("transform",),
        dimensions=(GCMCapacityBinding("work.units", "unit", capacity, required),),
        substrate_profile_id=profile_id,
    )


def adapter(*, phase_capacity: int = 16, phase_kind: str = "other") -> GCMPhaseBAdapter:
    bindings = GCMResourceBindingStore()
    bindings.upsert(binding(
        "bind.phase", "provider.phase", "resource.phase", "cfg.phase", phase_kind,
        "substrate.phase.sim.v1", capacity=phase_capacity,
    ))
    bindings.upsert(binding(
        "bind.event", "provider.event", "resource.event", "cfg.event", "other",
        "substrate.event.sim.v1",
    ))
    bindings.upsert(binding(
        "bind.cpu", "provider.cpu", "resource.cpu", "cfg.cpu", "cpu",
        "substrate.cpu.native.v1",
    ))
    return GCMPhaseBAdapter(bindings, substrate_catalog=profiles())


def task(policy: SubstratePolicy, task_id: str = "task.substrate") -> TaskContract:
    return TaskContract(
        task_id, "transform", "number", "number", 4,
        substrate_policy=policy,
    )


def test_actual_gcm_selects_simulated_phase_profile_via_resource_kind_other():
    decision = adapter().allocate(
        task(SubstratePolicy(preferred_kinds=("phase",), allow_simulated=True)),
        capability(),
        ("provider.phase", "provider.event", "provider.cpu"),
    )
    assert decision.provider_id == "provider.phase"
    assert decision.substrate_profile_id == "substrate.phase.sim.v1"
    assert decision.substrate_kind == "phase"
    assert decision.substrate_realization == "simulated"
    assert decision.evidence["resource_kind"] == "other"
    assert decision.substrate_selection_id


def test_profile_gcm_resource_kind_mismatch_is_rejected_before_gcm_enum_conversion():
    with pytest.raises(GCMIntegrationError, match="substrate profile/resource kind mismatch"):
        adapter(phase_kind="cpu").allocate(
            task(SubstratePolicy(preferred_kinds=("phase",))),
            capability(),
            ("provider.phase", "provider.cpu"),
        )


def test_energy_ceiling_filters_phase_and_selects_cpu_with_rejection_evidence():
    decision = adapter().allocate(
        task(SubstratePolicy(preferred_kinds=("phase",), max_energy_units=5), "task.energy"),
        capability(),
        ("provider.phase", "provider.cpu"),
    )
    assert decision.provider_id == "provider.cpu"
    assert decision.substrate_profile_id == "substrate.cpu.native.v1"
    assert decision.substrate_fallback_used is True
    rejected = dict(decision.evidence["substrate_rejected"])
    assert rejected["bind.phase"] == "energy_exceeds_ceiling"


def test_gcm_capacity_can_override_phase_preference_and_mark_fallback():
    decision = adapter(phase_capacity=4).allocate(
        task(SubstratePolicy(preferred_kinds=("phase",)), "task.capacity"),
        capability(),
        ("provider.phase", "provider.cpu"),
    )
    assert decision.provider_id == "provider.cpu"
    assert decision.substrate_kind == "cpu"
    assert decision.substrate_fallback_used is True
    assert decision.evidence["b3_states_explored"] >= 2


def test_native_required_rejects_simulated_phase_before_gcm_and_uses_cpu():
    decision = adapter().allocate(
        task(SubstratePolicy(preferred_kinds=("phase",), require_native=True), "task.native"),
        capability(),
        ("provider.phase", "provider.cpu"),
    )
    assert decision.provider_id == "provider.cpu"
    assert decision.substrate_realization == "native"
    assert dict(decision.evidence["substrate_rejected"])["bind.phase"] == "native_required"
