from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.resolver import Resolver
from mhcr.verification import VerificationResult


def capability(state=TrustState.TRUSTED):
    return Capability(
        capability_id="cap.math.double",
        version="1.0.0",
        task_family="double",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.double",),
        verifier_id="verify.double",
        trust_state=state,
    )


def task():
    return TaskContract("task-double", "double", "number", "number", 4)


def test_resolve_one_uses_trusted_index_without_enumerating_capabilities():
    registry = CapabilityRegistry()
    registry.register_capability(capability())

    class ValuesForbidden(dict):
        def values(self):
            raise AssertionError("trusted resolution performed a full capability scan")

    registry._capabilities = ValuesForbidden(registry._capabilities)
    resolved = Resolver(registry).resolve_one(task())

    assert resolved is not None
    assert resolved.capability_id == "cap.math.double"
    assert registry.indexed_lookup_count == 1


def test_revocation_removes_capability_from_trusted_index():
    registry = CapabilityRegistry()
    registry.register_capability(capability())
    assert Resolver(registry).resolve_one(task()) is not None

    registry.revoke("cap.math.double")

    assert Resolver(registry).resolve_one(task()) is None


def test_promotion_adds_candidate_to_trusted_index():
    registry = CapabilityRegistry()
    registry.register_capability(capability(TrustState.CANDIDATE))
    resolver = Resolver(registry)
    assert resolver.resolve_one(task()) is None

    registry.promote("cap.math.double", VerificationResult(True, "valid"))

    assert resolver.resolve_one(task()) is not None


def test_restored_registry_rebuilds_trusted_index(tmp_path):
    from mhcr.sqlite_repository import SQLiteRepository

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    original = CapabilityRegistry(repository=repo)
    original.register_capability(capability())
    original.register_provider(Provider("provider.double", "cap.math.double", lambda value: value * 2))
    repo.close()

    reopened = SQLiteRepository(path)
    restored = CapabilityRegistry.from_repository(
        reopened,
        provider_executors={"provider.double": lambda value: value * 2},
    )
    assert Resolver(restored).resolve_one(task()) is not None
    assert restored.indexed_lookup_count == 1
    reopened.close()


def test_runtime_fast_path_bypasses_composition_and_constructor(tmp_path):
    from mhcr.accounting import CostRecord, CostVector, GCAL
    from mhcr.history import EventLog
    from mhcr.runtime import MHCRRuntime
    from mhcr.verification import VerifierRegistry

    class BombConstructor:
        def construct(self, _task):
            raise AssertionError("constructor touched on fast path")

    registry = CapabilityRegistry()
    cap = capability()
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.double", cap.capability_id, lambda value: value * 2))
    verifiers = VerifierRegistry()
    verifiers.register("verify.double", lambda current_task, result: result == current_task.payload * 2)
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.double", CostVector(local_work=2.0)))
    runtime = MHCRRuntime(
        registry,
        verifiers,
        gcal,
        EventLog(tmp_path / "events.jsonl"),
        constructor=BombConstructor(),
    )

    def bomb_compose(_task):
        raise AssertionError("composer touched on fast path")

    runtime.resolver.compose = bomb_compose
    solved = runtime.solve(task())

    assert solved.value == 8
    assert solved.source == "resolved"
    assert solved.execution_path == "fast"
    assert solved.accounting.is_closed_complete is True


def test_constructed_capability_reports_full_execution_path(tmp_path):
    from mhcr.accounting import GCAL
    from mhcr.constructor import TemplateConstructor, TemplateSpec
    from mhcr.history import EventLog
    from mhcr.runtime import MHCRRuntime
    from mhcr.verification import VerifierRegistry

    constructor = TemplateConstructor(
        [
            TemplateSpec(
                task_family="square",
                input_type="number",
                output_type="number",
                execute=lambda value: value * value,
                verifier_id="verify.square",
            )
        ]
    )
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda current_task, result: result == current_task.payload ** 2)
    runtime = MHCRRuntime(
        registry,
        verifiers,
        GCAL(),
        EventLog(tmp_path / "events.jsonl"),
        constructor=constructor,
    )

    solved = runtime.solve(TaskContract("task-square", "square", "number", "number", 5))

    assert solved.value == 25
    assert solved.source == "constructed"
    assert solved.execution_path == "full"
