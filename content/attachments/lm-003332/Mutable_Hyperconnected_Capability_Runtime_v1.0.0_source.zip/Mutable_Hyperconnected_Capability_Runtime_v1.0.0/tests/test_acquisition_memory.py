import sqlite3

import pytest

from mhcr.acquisition import AcquisitionMemoryKind, AcquisitionMemoryRecord, AcquisitionMemoryStore
from mhcr.history import EventLog
from mhcr.models import TaskContract
from mhcr.sqlite_repository import SQLiteRepository


def record(kind=AcquisitionMemoryKind.SOLVER, *, subject_id="cap.square"):
    return AcquisitionMemoryRecord(
        memory_id=f"mem:{kind.value}:{subject_id}",
        kind=kind,
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        subject_id=subject_id,
        metadata={"source_task_id": "task-1"},
        source="runtime",
    )


def test_memory_record_rejects_instance_answer_payload():
    with pytest.raises(ValueError, match="instance answer"):
        AcquisitionMemoryRecord(
            memory_id="mem.bad",
            kind=AcquisitionMemoryKind.SOLVER,
            task_family="square",
            input_type="number",
            output_type="number",
            exactness="exact",
            subject_id="cap.square",
            metadata={"answer": 16},
            source="runtime",
        )


def test_memory_store_scopes_hits_and_tracks_reuse(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    store = AcquisitionMemoryStore(event_log=log)
    item = record()
    store.upsert(item)

    task = TaskContract("task-2", "square", "number", "number", 7)
    found = store.find(AcquisitionMemoryKind.SOLVER, task)
    assert found == (item,)

    reused = store.mark_reused(item.memory_id)
    assert reused.reuse_count == 1
    assert store.get(item.memory_id).reuse_count == 1
    assert log.replay_counts()["ACQUISITION_MEMORY_REUSED"] == 1


def test_sqlite_v5_round_trips_acquisition_memory(tmp_path):
    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    item = record(AcquisitionMemoryKind.REPRESENTATION, subject_id="type:numbers")
    repo.save_acquisition_memory(item)
    repo.close()

    reopened = SQLiteRepository(path)
    assert reopened.schema_version == 8
    assert reopened.load_acquisition_memories() == (item,)
    reopened.close()


def test_sqlite_v4_migrates_to_v5_without_losing_existing_data(tmp_path):
    path = tmp_path / "mhcr.sqlite3"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT INTO metadata(key, value) VALUES('schema_version', '4');
        CREATE TABLE capabilities (
            capability_id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            task_family TEXT NOT NULL,
            input_type TEXT NOT NULL,
            output_type TEXT NOT NULL,
            exactness TEXT NOT NULL,
            provider_ids_json TEXT NOT NULL,
            verifier_id TEXT,
            trust_state TEXT NOT NULL,
            scope TEXT NOT NULL,
            fidelity TEXT NOT NULL DEFAULT 'exact',
            component_capability_ids_json TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE providers (
            provider_id TEXT PRIMARY KEY,
            capability_id TEXT NOT NULL,
            active INTEGER NOT NULL,
            kind TEXT NOT NULL DEFAULT 'local_python',
            health TEXT NOT NULL DEFAULT 'healthy',
            boundary TEXT NOT NULL DEFAULT 'local',
            endpoint TEXT
        );
        CREATE TABLE cost_records (
            node_id TEXT PRIMARY KEY,
            local_work REAL NOT NULL,
            external_work REAL NOT NULL,
            offline_work REAL NOT NULL,
            verification_work REAL NOT NULL,
            monetary_cost REAL NOT NULL,
            known INTEGER NOT NULL,
            shared_cost_id TEXT
        );
        CREATE TABLE provider_cost_profiles (
            provider_id TEXT PRIMARY KEY,
            profile_json TEXT NOT NULL
        );
        INSERT INTO capabilities VALUES(
            'cap.keep', '1.0.0', 'keep', 'number', 'number', 'exact', '[]',
            NULL, 'trusted', 'unbounded', 'exact', '[]'
        );
        """
    )
    connection.commit()
    connection.close()

    repo = SQLiteRepository(path)
    assert repo.schema_version == 8
    assert repo.load_capabilities()[0].capability_id == "cap.keep"
    assert repo.load_acquisition_memories() == ()
    repo.close()


def test_event_log_replays_memory_reuse_and_invalidation(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    store = AcquisitionMemoryStore(event_log=log)
    item = record(AcquisitionMemoryKind.COMPOSITION, subject_id="cap.composite.pipeline")
    store.upsert(item)
    store.mark_reused(item.memory_id)
    store.invalidate_by_subject(item.subject_id, "component revoked")

    replayed = log.replay_acquisition_memories()
    restored = replayed.get(item.memory_id)
    assert restored.reuse_count == 1
    assert restored.active is False
    assert restored.invalidation_reason == "component revoked"
