from __future__ import annotations

import pytest

pytest.importorskip("gcm_runtime")

from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.gcm_integration import (
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, SubstratePolicy, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.routing import CostEvidence, CostMetric
from mhcr.runtime import MHCRRuntime
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.substrate import (
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
)
from mhcr.verification import VerifierRegistry


def _install_profiles(store: SubstrateProfileStore) -> None:
    store.upsert(
        SubstrateProfile(
            "substrate.cpu.native.v1",
            SubstrateKind.CPU,
            SubstrateRealization.NATIVE,
            gcm_resource_kind="cpu",
            energy_units=CostMetric(3, CostEvidence.MEASURED),
        )
    )
    store.upsert(
        SubstrateProfile(
            "substrate.phase.sim.v1",
            SubstrateKind.PHASE,
            SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            energy_units=CostMetric(8, CostEvidence.ESTIMATED),
        )
    )


def _install_bindings(store: GCMResourceBindingStore) -> None:
    store.upsert(
        GCMProviderBinding(
            "binding:phase",
            "provider.phase",
            "resource.phase",
            "cfg.phase",
            "provider.phase",
            "other",
            capabilities=("transform",),
            dimensions=(GCMCapacityBinding("work.units", "unit", 16, 8),),
            substrate_profile_id="substrate.phase.sim.v1",
        )
    )
    store.upsert(
        GCMProviderBinding(
            "binding:cpu",
            "provider.cpu",
            "resource.cpu",
            "cfg.cpu",
            "provider.cpu",
            "cpu",
            capabilities=("transform",),
            dimensions=(GCMCapacityBinding("work.units", "unit", 16, 8),),
            substrate_profile_id="substrate.cpu.native.v1",
        )
    )


def _verifiers() -> VerifierRegistry:
    registry = VerifierRegistry()
    registry.register("verify.transform", lambda task, result: result == task.payload * 2)
    return registry


def test_restart_preserves_substrate_profiles_bindings_and_semantic_selection(tmp_path) -> None:
    db = tmp_path / "mhcr.db"
    events = tmp_path / "events.jsonl"
    calls: list[str] = []

    repo = SQLiteRepository(db)
    history = EventLog(events)
    registry = CapabilityRegistry(repository=repo, event_log=history)
    capability = Capability(
        "cap.transform",
        "1.0.0",
        "transform",
        "number",
        "number",
        "exact",
        ("provider.phase", "provider.cpu"),
        verifier_id="verify.transform",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(capability)
    registry.register_provider(
        Provider("provider.phase", capability.capability_id, lambda x: calls.append("phase-1") or x * 2)
    )
    registry.register_provider(
        Provider("provider.cpu", capability.capability_id, lambda x: calls.append("cpu-1") or x * 2)
    )
    profiles = SubstrateProfileStore(repository=repo, event_log=history)
    _install_profiles(profiles)
    bindings = GCMResourceBindingStore(repository=repo, event_log=history)
    _install_bindings(bindings)
    gcal = GCAL(repository=repo)
    gcal.register_cost(CostRecord("provider.phase", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.cpu", CostVector(local_work=1.0)))
    runtime = MHCRRuntime(
        registry,
        _verifiers(),
        gcal,
        history,
        compute_allocator=GCMPhaseBAdapter(bindings, substrate_catalog=profiles, event_log=history),
    )
    first = runtime.solve(
        TaskContract(
            "task.before-restart",
            "transform",
            "number",
            "number",
            4,
            substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
        )
    )
    assert first.compute_allocations[0].substrate_profile_id == "substrate.phase.sim.v1"
    repo.close()

    reopened = SQLiteRepository(db)
    history2 = EventLog(events)
    restored_registry = CapabilityRegistry.from_repository(
        reopened,
        provider_executors={
            "provider.phase": lambda x: calls.append("phase-2") or x * 2,
            "provider.cpu": lambda x: calls.append("cpu-2") or x * 2,
        },
        event_log=history2,
    )
    restored_profiles = SubstrateProfileStore(repository=reopened, event_log=history2)
    restored_bindings = GCMResourceBindingStore(repository=reopened, event_log=history2)
    restored = MHCRRuntime(
        restored_registry,
        _verifiers(),
        GCAL(repository=reopened),
        history2,
        compute_allocator=GCMPhaseBAdapter(
            restored_bindings,
            substrate_catalog=restored_profiles,
            event_log=history2,
        ),
    )
    second = restored.solve(
        TaskContract(
            "task.after-restart",
            "transform",
            "number",
            "number",
            5,
            substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
        )
    )

    assert second.value == 10
    assert second.compute_allocations[0].substrate_profile_id == "substrate.phase.sim.v1"
    assert second.compute_allocations[0].substrate_kind == "phase"
    assert calls == ["phase-1", "phase-2"]
    assert tuple(profile.profile_id for profile in restored_profiles.records()) == (
        "substrate.cpu.native.v1",
        "substrate.phase.sim.v1",
    )
    reopened.close()
