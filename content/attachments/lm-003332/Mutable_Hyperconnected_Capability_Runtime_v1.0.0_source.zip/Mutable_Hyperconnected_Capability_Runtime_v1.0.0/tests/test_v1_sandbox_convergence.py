from mhcr.sandbox import SandboxPolicy


def test_v1_default_reference_sandbox_cpu_budget_has_two_second_headroom():
    policy = SandboxPolicy()
    assert policy.timeout_seconds == 2.0
    assert policy.cpu_seconds >= 2
