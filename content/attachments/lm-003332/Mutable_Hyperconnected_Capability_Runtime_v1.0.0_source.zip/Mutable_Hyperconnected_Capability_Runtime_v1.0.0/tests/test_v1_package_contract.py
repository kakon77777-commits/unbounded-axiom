from importlib import resources
from pathlib import Path
import tomllib

from mhcr.sqlite_repository import SQLiteRepository


def test_v1_package_metadata_and_console_script_are_final():
    data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    assert data["project"]["version"] == "1.0.0"
    assert data["project"]["scripts"]["mhcr"] == "mhcr.cli:main"
    assert "GCM" not in " ".join(data["project"].get("dependencies", []))


def test_v1_conformance_manifests_are_package_resources():
    root = resources.files("mhcr").joinpath("data", "v1_conformance")
    for name in ("core_manifest.json", "gcm_manifest.json", "failure_manifest.json"):
        assert root.joinpath(name).is_file()


def test_v1_final_convergence_does_not_bump_sqlite_schema(tmp_path):
    repo = SQLiteRepository(tmp_path / "mhcr.sqlite3")
    assert repo.schema_version == 8
    repo.close()


def test_v1_quickstart_contains_literal_standalone_and_optional_gcm_flows():
    text = Path("docs/v1/QUICKSTART.md").read_text(encoding="utf-8")
    for command in (
        "mhcr --help",
        "mhcr conformance",
        "mhcr failure-matrix",
        "mhcr longrun",
        "mhcr acceptance",
        "mhcr demo",
        "mhcr conformance --profile MHCR-GCM-R1",
        "mhcr substrate-demo",
    ):
        assert command in text
