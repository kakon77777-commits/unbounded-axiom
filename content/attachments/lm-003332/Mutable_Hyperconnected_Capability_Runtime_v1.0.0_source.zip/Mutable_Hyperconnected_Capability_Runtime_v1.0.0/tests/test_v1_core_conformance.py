from mhcr.conformance import ConformanceCaseStatus, ConformanceClaim, run_conformance


def test_v1_core_conformance_is_exactly_32_of_32_pass():
    result = run_conformance("MHCR-CORE-R1")
    assert result.claim is ConformanceClaim.CONFORMANT
    assert result.required_passed == 32
    assert result.required_failed == 0
    assert result.required_indeterminate == 0
    assert [case.case_id for case in result.cases] == [f"C{i:02d}" for i in range(1, 33)]
    assert all(case.status is ConformanceCaseStatus.PASS for case in result.cases)


def test_v1_core_conformance_preserves_schema_8_and_no_world_commit_claim():
    result = run_conformance("MHCR-CORE-R1")
    by_id = {case.case_id: case for case in result.cases}
    assert by_id["C30"].evidence["schema_version"] == 8
    assert by_id["C32"].evidence["world_commit_events"] == 0
