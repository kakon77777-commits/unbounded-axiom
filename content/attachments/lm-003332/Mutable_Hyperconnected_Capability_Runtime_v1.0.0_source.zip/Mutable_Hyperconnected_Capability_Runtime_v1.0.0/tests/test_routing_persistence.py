from __future__ import annotations

import json
import sqlite3

from mhcr.accounting import CostRecord, CostVector
from mhcr.models import Capability, ProviderBoundary, ProviderHealth, ProviderKind, TrustState
from mhcr.repository import ProviderRecord
from mhcr.routing import CostEvidence, CostMetric, ProviderCostProfile
from mhcr.sqlite_repository import SQLiteRepository


def profile() -> ProviderCostProfile:
    return ProviderCostProfile(
        "provider.remote",
        latency_ms=CostMetric(12.5, CostEvidence.DECLARED),
        monetary_cost_usd=CostMetric(0.03, CostEvidence.ESTIMATED),
        network_bytes=CostMetric(4096, CostEvidence.MEASURED, sample_count=2),
        verification_work=CostMetric(1.5, CostEvidence.FORMALLY_BOUNDED),
        risk_score=CostMetric(),
    )


def test_sqlite_v3_round_trips_provider_cost_profiles(tmp_path):
    repo = SQLiteRepository(tmp_path / "mhcr.sqlite3")
    assert repo.schema_version == 8

    repo.save_provider_cost_profile(profile())
    restored = repo.load_provider_cost_profiles()

    assert restored == (profile(),)
    repo.close()


def test_v2_database_migrates_to_v3_without_losing_existing_rows(tmp_path):
    path = tmp_path / "legacy.sqlite3"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT INTO metadata(key, value) VALUES('schema_version', '2');
        CREATE TABLE capabilities (
            capability_id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            task_family TEXT NOT NULL,
            input_type TEXT NOT NULL,
            output_type TEXT NOT NULL,
            exactness TEXT NOT NULL,
            provider_ids_json TEXT NOT NULL,
            verifier_id TEXT,
            trust_state TEXT NOT NULL,
            scope TEXT NOT NULL
        );
        CREATE TABLE providers (
            provider_id TEXT PRIMARY KEY,
            capability_id TEXT NOT NULL,
            active INTEGER NOT NULL,
            kind TEXT NOT NULL DEFAULT 'local_python',
            health TEXT NOT NULL DEFAULT 'healthy',
            boundary TEXT NOT NULL DEFAULT 'local',
            endpoint TEXT
        );
        CREATE TABLE cost_records (
            node_id TEXT PRIMARY KEY,
            local_work REAL NOT NULL,
            external_work REAL NOT NULL,
            offline_work REAL NOT NULL,
            verification_work REAL NOT NULL,
            monetary_cost REAL NOT NULL,
            known INTEGER NOT NULL,
            shared_cost_id TEXT
        );
        """
    )
    connection.execute(
        "INSERT INTO capabilities VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            "cap.echo", "1.0.0", "echo", "text", "text", "exact",
            json.dumps(["provider.echo"]), "verify.echo", "trusted", "unbounded",
        ),
    )
    connection.execute(
        "INSERT INTO providers VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            "provider.echo", "cap.echo", 1, "remote_api", "healthy", "network",
            "https://example.invalid/echo",
        ),
    )
    connection.execute(
        "INSERT INTO cost_records VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        ("provider.echo", 0.0, 1.0, 0.0, 0.2, 0.01, 1, None),
    )
    connection.commit()
    connection.close()

    repo = SQLiteRepository(path)

    assert repo.schema_version == 8
    assert repo.load_capabilities()[0].capability_id == "cap.echo"
    provider = repo.load_provider_records()[0]
    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.boundary is ProviderBoundary.NETWORK
    assert repo.load_costs()[0] == CostRecord(
        "provider.echo",
        CostVector(external_work=1.0, verification_work=0.2, monetary_cost=0.01),
    )
    assert repo.load_provider_cost_profiles() == ()

    repo.save_provider_cost_profile(profile())
    assert repo.load_provider_cost_profiles() == (profile(),)
    repo.close()


def test_v3_database_migrates_to_v4_preserving_routing_and_registry_rows(tmp_path):
    path = tmp_path / "legacy-v3.sqlite3"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT INTO metadata(key, value) VALUES('schema_version', '3');
        CREATE TABLE capabilities (
            capability_id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            task_family TEXT NOT NULL,
            input_type TEXT NOT NULL,
            output_type TEXT NOT NULL,
            exactness TEXT NOT NULL,
            provider_ids_json TEXT NOT NULL,
            verifier_id TEXT,
            trust_state TEXT NOT NULL,
            scope TEXT NOT NULL
        );
        CREATE TABLE providers (
            provider_id TEXT PRIMARY KEY,
            capability_id TEXT NOT NULL,
            active INTEGER NOT NULL,
            kind TEXT NOT NULL DEFAULT 'local_python',
            health TEXT NOT NULL DEFAULT 'healthy',
            boundary TEXT NOT NULL DEFAULT 'local',
            endpoint TEXT
        );
        CREATE TABLE cost_records (
            node_id TEXT PRIMARY KEY,
            local_work REAL NOT NULL,
            external_work REAL NOT NULL,
            offline_work REAL NOT NULL,
            verification_work REAL NOT NULL,
            monetary_cost REAL NOT NULL,
            known INTEGER NOT NULL,
            shared_cost_id TEXT
        );
        CREATE TABLE provider_cost_profiles (
            provider_id TEXT PRIMARY KEY,
            profile_json TEXT NOT NULL
        );
        """
    )
    connection.execute(
        "INSERT INTO capabilities VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            "cap.echo", "1.0.0", "echo", "text", "text", "exact",
            json.dumps(["provider.echo"]), "verify.echo", "trusted", "unbounded",
        ),
    )
    connection.execute(
        "INSERT INTO providers VALUES (?, ?, ?, ?, ?, ?, ?)",
        (
            "provider.echo", "cap.echo", 1, "remote_api", "healthy", "network",
            "https://example.invalid/echo",
        ),
    )
    connection.execute(
        "INSERT INTO provider_cost_profiles(provider_id, profile_json) VALUES (?, ?)",
        (
            "provider.echo",
            json.dumps(
                {
                    "provider_id": "provider.echo",
                    "latency_ms": {"value": 7.0, "evidence": "declared", "sample_count": 0},
                    "monetary_cost_usd": {"value": None, "evidence": "unknown", "sample_count": 0},
                    "network_bytes": {"value": None, "evidence": "unknown", "sample_count": 0},
                    "verification_work": {"value": None, "evidence": "unknown", "sample_count": 0},
                    "risk_score": {"value": None, "evidence": "unknown", "sample_count": 0},
                }
            ),
        ),
    )
    connection.commit()
    connection.close()

    repo = SQLiteRepository(path)

    assert repo.schema_version == 8
    capability = repo.load_capabilities()[0]
    assert capability.capability_id == "cap.echo"
    assert capability.fidelity.value == "exact"
    assert capability.component_capability_ids == ()
    assert repo.load_provider_records()[0].provider_id == "provider.echo"
    assert repo.load_provider_cost_profiles()[0].latency_ms.value == 7.0
    repo.close()
