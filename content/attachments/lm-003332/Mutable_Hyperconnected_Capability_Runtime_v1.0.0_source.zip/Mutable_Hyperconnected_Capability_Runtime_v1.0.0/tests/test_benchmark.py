from mhcr.benchmark import BenchmarkResult, benchmark_resolver


def test_benchmark_resolver_reports_indexed_and_scan_timings():
    result = benchmark_resolver(registry_size=200, iterations=50)

    assert isinstance(result, BenchmarkResult)
    assert result.registry_size == 200
    assert result.iterations == 50
    assert result.indexed_ns_per_lookup > 0
    assert result.scan_ns_per_lookup > 0
    assert result.speedup_ratio > 0
