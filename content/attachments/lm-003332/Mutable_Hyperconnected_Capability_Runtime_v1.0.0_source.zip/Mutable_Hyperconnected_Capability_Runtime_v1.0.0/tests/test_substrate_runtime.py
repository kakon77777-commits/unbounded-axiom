from __future__ import annotations

import pytest

pytest.importorskip("gcm_runtime")

from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.gcm_integration import (
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, SubstratePolicy, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.routing import CostEvidence, CostMetric
from mhcr.runtime import MHCRRuntime
from mhcr.substrate import (
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
)
from mhcr.verification import VerifierRegistry


def _profile_store() -> SubstrateProfileStore:
    store = SubstrateProfileStore()
    store.upsert(
        SubstrateProfile(
            "substrate.cpu.native.v1",
            SubstrateKind.CPU,
            SubstrateRealization.NATIVE,
            gcm_resource_kind="cpu",
            energy_units=CostMetric(3, CostEvidence.MEASURED),
        )
    )
    store.upsert(
        SubstrateProfile(
            "substrate.event.sim.v1",
            SubstrateKind.EVENT_DRIVEN,
            SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            features=("event",),
            energy_units=CostMetric(4, CostEvidence.ESTIMATED),
        )
    )
    store.upsert(
        SubstrateProfile(
            "substrate.phase.sim.v1",
            SubstrateKind.PHASE,
            SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            features=("phase",),
            energy_units=CostMetric(8, CostEvidence.ESTIMATED),
        )
    )
    return store


def _binding(provider_id: str, resource_id: str, kind: str, profile_id: str, *, capacity: int = 16):
    return GCMProviderBinding(
        binding_id=f"binding:{provider_id}",
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=f"cfg:{provider_id}",
        executor_id=provider_id,
        resource_kind=kind,
        capabilities=("transform",),
        dimensions=(GCMCapacityBinding("work.units", "unit", capacity, 8),),
        substrate_profile_id=profile_id,
    )


def _runtime(tmp_path, calls: list[str], *, phase_capacity: int = 16, phase_executor=None):
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    gcal = GCAL()
    history = EventLog(tmp_path / "events.jsonl")
    capability = Capability(
        "cap.transform",
        "1.0.0",
        "transform",
        "number",
        "number",
        "exact",
        ("provider.phase", "provider.event", "provider.cpu"),
        verifier_id="verify.transform",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(capability)

    phase_fn = phase_executor or (lambda x: calls.append("phase") or x * 2)
    registry.register_provider(Provider("provider.phase", capability.capability_id, phase_fn))
    registry.register_provider(
        Provider("provider.event", capability.capability_id, lambda x: calls.append("event") or x * 2)
    )
    registry.register_provider(
        Provider("provider.cpu", capability.capability_id, lambda x: calls.append("cpu") or x * 2)
    )
    verifiers.register("verify.transform", lambda task, result: result == task.payload * 2)
    for provider_id in capability.provider_ids:
        gcal.register_cost(CostRecord(provider_id, CostVector(local_work=1.0)))

    bindings = GCMResourceBindingStore()
    bindings.upsert(
        _binding(
            "provider.phase",
            "resource.phase",
            "other",
            "substrate.phase.sim.v1",
            capacity=phase_capacity,
        )
    )
    bindings.upsert(
        _binding("provider.event", "resource.event", "other", "substrate.event.sim.v1")
    )
    bindings.upsert(
        _binding("provider.cpu", "resource.cpu", "cpu", "substrate.cpu.native.v1")
    )
    adapter = GCMPhaseBAdapter(bindings, substrate_catalog=_profile_store(), event_log=history)
    return MHCRRuntime(registry, verifiers, gcal, history, compute_allocator=adapter), history


def test_runtime_allocation_event_records_selected_substrate_evidence(tmp_path) -> None:
    calls: list[str] = []
    runtime, history = _runtime(tmp_path, calls)
    result = runtime.solve(
        TaskContract(
            "task.event",
            "transform",
            "number",
            "number",
            5,
            substrate_policy=SubstratePolicy(preferred_kinds=("event_driven",)),
        )
    )

    assert result.value == 10
    assert calls == ["event"]
    applied = [e for e in history.read_all() if e.event_type == "COMPUTE_ALLOCATION_APPLIED"][-1]
    assert applied.data["substrate_profile_id"] == "substrate.event.sim.v1"
    assert applied.data["substrate_kind"] == "event_driven"
    assert applied.data["substrate_realization"] == "simulated"
    assert applied.data["substrate_selection_id"]
    assert applied.data["substrate_fallback_used"] is False


def test_same_capability_verifier_accepts_phase_and_event_realizations(tmp_path) -> None:
    calls: list[str] = []
    runtime, _history = _runtime(tmp_path, calls)

    phase = runtime.solve(
        TaskContract(
            "task.phase",
            "transform",
            "number",
            "number",
            6,
            substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
        )
    )
    event = runtime.solve(
        TaskContract(
            "task.event2",
            "transform",
            "number",
            "number",
            7,
            substrate_policy=SubstratePolicy(preferred_kinds=("event_driven",)),
        )
    )

    assert phase.value == 12
    assert event.value == 14
    assert calls == ["phase", "event"]
    assert phase.verification.passed is True
    assert event.verification.passed is True
    assert phase.compute_allocations[0].substrate_kind == "phase"
    assert event.compute_allocations[0].substrate_kind == "event_driven"


def test_phase_preference_capacity_falls_back_to_cpu_with_runtime_evidence(tmp_path) -> None:
    calls: list[str] = []
    runtime, history = _runtime(tmp_path, calls, phase_capacity=4)
    result = runtime.solve(
        TaskContract(
            "task.capacity-fallback",
            "transform",
            "number",
            "number",
            8,
            substrate_policy=SubstratePolicy(
                allowed_kinds=("phase", "cpu"),
                preferred_kinds=("phase",),
            ),
        )
    )

    assert result.value == 16
    assert calls == ["cpu"]
    allocation = result.compute_allocations[0]
    assert allocation.provider_id == "provider.cpu"
    assert allocation.substrate_kind == "cpu"
    assert allocation.substrate_fallback_used is True
    applied = [e for e in history.read_all() if e.event_type == "COMPUTE_ALLOCATION_APPLIED"][-1]
    assert applied.data["substrate_fallback_used"] is True
    assert applied.data["substrate_kind"] == "cpu"


def test_selected_phase_execution_failure_does_not_cross_substrate_failover(tmp_path) -> None:
    calls: list[str] = []

    def broken_phase(_value):
        calls.append("phase")
        raise RuntimeError("phase execution failed")

    runtime, _history = _runtime(tmp_path, calls, phase_executor=broken_phase)
    with pytest.raises(RuntimeError, match="all eligible providers failed"):
        runtime.solve(
            TaskContract(
                "task.no-cross-failover",
                "transform",
                "number",
                "number",
                9,
                substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
            )
        )

    assert calls == ["phase"]


def test_simulation_disallowed_policy_uses_native_cpu(tmp_path) -> None:
    calls: list[str] = []
    runtime, _history = _runtime(tmp_path, calls)
    result = runtime.solve(
        TaskContract(
            "task.native-only",
            "transform",
            "number",
            "number",
            10,
            substrate_policy=SubstratePolicy(
                preferred_kinds=("phase", "event_driven"),
                allow_simulated=False,
            ),
        )
    )

    assert result.value == 20
    assert calls == ["cpu"]
    allocation = result.compute_allocations[0]
    assert allocation.substrate_kind == "cpu"
    assert allocation.substrate_realization == "native"
