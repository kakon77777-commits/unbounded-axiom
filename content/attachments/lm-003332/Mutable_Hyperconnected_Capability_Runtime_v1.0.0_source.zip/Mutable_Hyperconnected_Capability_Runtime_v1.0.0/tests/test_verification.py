import pytest

from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.rdr import RDR
from mhcr.verification import VerificationResult, VerifierRegistry


def candidate_capability():
    return Capability(
        capability_id="cap.generated.square",
        version="1.0.0",
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.generated.square",),
        verifier_id="verify.square",
        trust_state=TrustState.CANDIDATE,
    )


def test_execution_success_does_not_promote_candidate():
    registry = CapabilityRegistry()
    cap = candidate_capability()
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.generated.square", cap.capability_id, lambda x: x * x))

    result = RDR(registry).execute(RDR(registry).materialize(cap), 4)

    assert result == 16
    assert registry.get_capability(cap.capability_id).trust_state is TrustState.CANDIDATE


def test_valid_verification_promotes_candidate_to_trusted():
    registry = CapabilityRegistry()
    cap = candidate_capability()
    registry.register_capability(cap)
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    task = TaskContract("t1", "square", "number", "number", 5)

    verification = verifiers.verify(cap.verifier_id, task, 25)
    promoted = registry.promote(cap.capability_id, verification)

    assert verification.passed is True
    assert promoted.trust_state is TrustState.TRUSTED


def test_invalid_verification_cannot_promote_candidate():
    registry = CapabilityRegistry()
    cap = candidate_capability()
    registry.register_capability(cap)
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: False)
    task = TaskContract("t2", "square", "number", "number", 5)

    verification = verifiers.verify(cap.verifier_id, task, 24)

    with pytest.raises(ValueError, match="verification did not pass"):
        registry.promote(cap.capability_id, verification)
    assert registry.get_capability(cap.capability_id).trust_state is TrustState.CANDIDATE


def test_missing_verifier_is_not_silently_treated_as_success():
    verifiers = VerifierRegistry()
    task = TaskContract("t3", "square", "number", "number", 3)

    result = verifiers.verify("verify.missing", task, 9)

    assert result == VerificationResult(False, "missing verifier: verify.missing")
