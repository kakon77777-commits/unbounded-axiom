from __future__ import annotations

import pytest

from mhcr.accounting import AccountingStatus, GCAL
from mhcr.history import EventLog
from mhcr.models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderKind,
    RoutingPreference,
    TaskContract,
    TaskPolicy,
    TrustState,
)
from mhcr.rdr import RDR
from mhcr.registry import CapabilityRegistry
from mhcr.routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile
from mhcr.runtime import MHCRRuntime
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.verification import VerifierRegistry


def trusted(provider_ids: tuple[str, ...], family: str = "double") -> Capability:
    return Capability(
        capability_id=f"cap.{family}",
        version="1.0.0",
        task_family=family,
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=provider_ids,
        verifier_id=f"verify.{family}",
        trust_state=TrustState.TRUSTED,
    )


def declared(value: float) -> CostMetric:
    return CostMetric(value, CostEvidence.DECLARED)


def test_non_default_policy_emits_routing_decision_with_rejections(tmp_path):
    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = trusted(("provider.unknown", "provider.fast"), "route")
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.unknown", capability.capability_id, lambda value: value * 2))
    registry.register_provider(Provider("provider.fast", capability.capability_id, lambda value: value * 2))
    catalog = ProviderCostCatalog()
    catalog.upsert(ProviderCostProfile("provider.fast", latency_ms=declared(5.0)), persist=False)
    clock = iter((1.0, 1.004)).__next__

    outcome = RDR(registry, event_log=history, cost_catalog=catalog, clock=clock).execute_capability(
        capability,
        3,
        task_id="task.route",
        policy=TaskPolicy(max_latency_ms=10.0, prefer=(RoutingPreference.LATENCY,)),
    )

    assert outcome.value == 6
    events = [event for event in history.read_all() if event.event_type == "PROVIDER_ROUTING_DECISION"]
    assert len(events) == 1
    assert events[0].data["ordered_provider_ids"] == ["provider.fast"]
    assert events[0].data["rejected"] == [
        {"provider_id": "provider.unknown", "reason": "latency_unknown"}
    ]


def test_observed_latency_replaces_declared_latency_persists_and_records_drift(tmp_path):
    repo = SQLiteRepository(tmp_path / "mhcr.sqlite3")
    history = EventLog(tmp_path / "events.jsonl")
    catalog = ProviderCostCatalog(repo, drift_ratio=0.5)
    catalog.upsert(
        ProviderCostProfile("provider.double", latency_ms=declared(5.0))
    )
    registry = CapabilityRegistry()
    capability = trusted(("provider.double",))
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.double", capability.capability_id, lambda value: value * 2))
    clock = iter((10.0, 10.012)).__next__

    outcome = RDR(registry, event_log=history, cost_catalog=catalog, clock=clock).execute_capability(
        capability, 4, task_id="task.observe"
    )

    assert outcome.attempts[0].provider_id == "provider.double"
    assert outcome.attempts[0].elapsed_ms == pytest.approx(12.0)
    observed = catalog.get("provider.double").latency_ms
    assert observed.value == pytest.approx(12.0)
    assert observed.evidence is CostEvidence.MEASURED
    assert observed.sample_count == 1
    types = [event.event_type for event in history.read_all()]
    assert "PROVIDER_COST_OBSERVED" in types
    assert "PROVIDER_COST_DRIFTED" in types

    repo.close()
    reopened = SQLiteRepository(tmp_path / "mhcr.sqlite3")
    restored = ProviderCostCatalog(reopened).get("provider.double").latency_ms
    assert restored.value == pytest.approx(12.0)
    assert restored.evidence is CostEvidence.MEASURED
    assert restored.sample_count == 1
    reopened.close()


def test_measured_routing_latency_does_not_close_independent_gcal_accounting(tmp_path):
    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = trusted(("provider.remote",), "remote-double")
    registry.register_capability(capability)
    registry.register_provider(
        Provider(
            "provider.remote",
            capability.capability_id,
            lambda value: value * 2,
            kind=ProviderKind.REMOTE_API,
            boundary=ProviderBoundary.NETWORK,
        )
    )
    catalog = ProviderCostCatalog()
    catalog.upsert(
        ProviderCostProfile(
            "provider.remote",
            latency_ms=declared(5.0),
            monetary_cost_usd=declared(0.01),
            network_bytes=declared(1000),
            verification_work=declared(1.0),
            risk_score=declared(0.1),
        ),
        persist=False,
    )
    verifiers = VerifierRegistry()
    verifiers.register("verify.remote-double", lambda task, value: value == task.payload * 2)
    clock = iter((20.0, 20.003)).__next__
    runtime = MHCRRuntime(
        registry,
        verifiers,
        GCAL(),
        history,
        cost_catalog=catalog,
        clock=clock,
    )

    result = runtime.solve(
        TaskContract(
            "task.remote",
            "remote-double",
            "int",
            "int",
            7,
            policy=TaskPolicy(prefer=(RoutingPreference.LATENCY,)),
        )
    )

    assert result.value == 14
    assert result.provider_ids == ("provider.remote",)
    assert result.accounting.status is AccountingStatus.ACCOUNTING_INCOMPLETE
    assert "provider.remote" in result.accounting.unknown_nodes
