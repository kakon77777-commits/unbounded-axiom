from mhcr.history import EventLog
from mhcr.models import Capability, TrustState
from mhcr.registry import CapabilityRegistry


def cap(capability_id, family, input_type, output_type, components=()):
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type=input_type,
        output_type=output_type,
        exactness="exact",
        provider_ids=() if components else (f"provider.{capability_id}",),
        trust_state=TrustState.TRUSTED,
        scope="composite" if components else "unbounded",
        component_capability_ids=components,
    )


def test_revoking_component_deprecates_direct_composite_and_removes_from_index(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=log)
    primitive = cap("cap.a", "a", "raw", "mid")
    composite = cap("cap.pipeline", "pipeline", "raw", "final", ("cap.a",))
    registry.register_capability(primitive)
    registry.register_capability(composite)

    registry.revoke("cap.a")

    assert registry.get_capability("cap.a").trust_state is TrustState.REVOKED
    assert registry.get_capability("cap.pipeline").trust_state is TrustState.DEPRECATED
    assert registry.find_trusted(
        task_family="pipeline",
        input_type="raw",
        output_type="final",
        exactness="exact",
    ) == []
    assert log.replay_counts()["REGISTRY_COMPOSITE_INVALIDATED"] == 1


def test_component_revocation_invalidates_transitive_composite_chain(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=log)
    primitive = cap("cap.a", "a", "raw", "mid")
    first = cap("cap.first", "first", "raw", "stage", ("cap.a",))
    second = cap("cap.second", "second", "raw", "final", ("cap.first",))
    for item in (primitive, first, second):
        registry.register_capability(item)

    registry.revoke("cap.a")

    assert registry.get_capability("cap.first").trust_state is TrustState.DEPRECATED
    assert registry.get_capability("cap.second").trust_state is TrustState.DEPRECATED
    assert log.replay_counts()["REGISTRY_COMPOSITE_INVALIDATED"] == 2

    replayed = log.replay_registry()
    assert replayed.get_capability("cap.first").trust_state is TrustState.DEPRECATED
    assert replayed.get_capability("cap.second").trust_state is TrustState.DEPRECATED
