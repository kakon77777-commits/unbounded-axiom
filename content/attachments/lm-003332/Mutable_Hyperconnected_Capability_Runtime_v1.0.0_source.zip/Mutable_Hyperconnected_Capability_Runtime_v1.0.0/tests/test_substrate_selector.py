from __future__ import annotations

from dataclasses import dataclass

from mhcr.models import SubstratePolicy, TaskContract
from mhcr.routing import CostEvidence, CostMetric
from mhcr.substrate import (
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
    SubstrateSelector,
    TransitionLawClass,
)


@dataclass(frozen=True)
class Binding:
    binding_id: str
    substrate_profile_id: str | None = None
    priority: int = 0


def task(policy: SubstratePolicy = SubstratePolicy(), *, exactness: str = "exact") -> TaskContract:
    return TaskContract(
        "task.substrate", "numeric", "number", "number", 4,
        exactness=exactness,
        substrate_policy=policy,
    )


def profile(
    profile_id: str,
    kind: SubstrateKind,
    realization: SubstrateRealization,
    *,
    features: tuple[str, ...] = (),
    laws: tuple[TransitionLawClass, ...] = (TransitionLawClass.DETERMINISTIC,),
    exact: bool = True,
    energy: CostMetric = CostMetric(),
    switching: CostMetric = CostMetric(),
) -> SubstrateProfile:
    return SubstrateProfile(
        profile_id=profile_id,
        kind=kind,
        realization=realization,
        features=features,
        transition_laws=laws,
        supports_exact=exact,
        energy_units=energy,
        switching_cost_units=switching,
    )


def selector() -> SubstrateSelector:
    store = SubstrateProfileStore()
    store.upsert(profile("cpu.native", SubstrateKind.CPU, SubstrateRealization.NATIVE, features=("scalar",)))
    store.upsert(profile("event.sim", SubstrateKind.EVENT_DRIVEN, SubstrateRealization.SIMULATED, features=("event", "stream")))
    store.upsert(profile("phase.sim", SubstrateKind.PHASE, SubstrateRealization.SIMULATED, features=("phase",), energy=CostMetric(8, CostEvidence.ESTIMATED)))
    store.upsert(profile("approx.fpga", SubstrateKind.FPGA, SubstrateRealization.EMULATED, exact=False))
    store.upsert(profile("quantum.sim", SubstrateKind.QUANTUM, SubstrateRealization.SIMULATED, laws=(TransitionLawClass.COHERENT,)))
    return SubstrateSelector(store)


def test_default_policy_preserves_legacy_unprofiled_binding_order():
    bindings = (Binding("legacy.2"), Binding("legacy.1"))
    result = selector().select(task(), "cap.numeric", bindings)
    assert tuple(item.binding_id for item in result.bindings) == ("legacy.2", "legacy.1")
    assert result.certificate.rejected == ()


def test_nondefault_policy_rejects_unprofiled_binding_fail_closed():
    policy = SubstratePolicy(preferred_kinds=("cpu",))
    result = selector().select(task(policy), "cap.numeric", (Binding("legacy"),))
    assert result.bindings == ()
    assert result.certificate.rejected == (("legacy", "substrate_profile_missing"),)


def test_preferred_kind_and_profile_order_are_deterministic():
    policy = SubstratePolicy(
        preferred_profile_ids=("event.sim",),
        preferred_kinds=("phase", "cpu"),
    )
    bindings = (
        Binding("b.cpu", "cpu.native", priority=0),
        Binding("b.phase", "phase.sim", priority=0),
        Binding("b.event", "event.sim", priority=9),
    )
    result = selector().select(task(policy), "cap.numeric", bindings)
    assert tuple(item.binding_id for item in result.bindings) == ("b.event", "b.phase", "b.cpu")
    replay = selector().select(task(policy), "cap.numeric", bindings)
    assert replay.certificate.selection_id == result.certificate.selection_id


def test_hard_filters_cover_features_transition_law_exactness_and_realization():
    policy = SubstratePolicy(
        required_features=("event",),
        required_transition_laws=("deterministic",),
        allow_simulated=True,
    )
    bindings = (
        Binding("b.event", "event.sim"),
        Binding("b.phase", "phase.sim"),
        Binding("b.quantum", "quantum.sim"),
        Binding("b.approx", "approx.fpga"),
    )
    result = selector().select(task(policy), "cap.numeric", bindings)
    assert tuple(item.binding_id for item in result.bindings) == ("b.event",)
    rejected = dict(result.certificate.rejected)
    assert rejected["b.phase"] == "required_features_missing"
    assert rejected["b.quantum"] in {"required_features_missing", "required_transition_law_missing"}
    assert rejected["b.approx"] in {"required_features_missing", "exact_not_supported"}


def test_require_native_and_simulation_disallow_fall_back_to_cpu():
    policy = SubstratePolicy(preferred_kinds=("phase",), require_native=True)
    result = selector().select(
        task(policy),
        "cap.numeric",
        (Binding("b.phase", "phase.sim"), Binding("b.cpu", "cpu.native")),
    )
    assert tuple(item.binding_id for item in result.bindings) == ("b.cpu",)
    assert dict(result.certificate.rejected)["b.phase"] == "native_required"


def test_energy_limit_rejects_unknown_and_over_ceiling_without_treating_unknown_as_zero():
    store = SubstrateProfileStore()
    store.upsert(profile("unknown.energy", SubstrateKind.PHASE, SubstrateRealization.SIMULATED))
    store.upsert(profile("high.energy", SubstrateKind.EVENT_DRIVEN, SubstrateRealization.SIMULATED, energy=CostMetric(9, CostEvidence.DECLARED)))
    store.upsert(profile("low.energy", SubstrateKind.CPU, SubstrateRealization.NATIVE, energy=CostMetric(3, CostEvidence.MEASURED)))
    result = SubstrateSelector(store).select(
        task(SubstratePolicy(max_energy_units=5)),
        "cap.numeric",
        (
            Binding("b.unknown", "unknown.energy"),
            Binding("b.high", "high.energy"),
            Binding("b.low", "low.energy"),
        ),
    )
    assert tuple(item.binding_id for item in result.bindings) == ("b.low",)
    rejected = dict(result.certificate.rejected)
    assert rejected["b.unknown"] == "energy_unknown"
    assert rejected["b.high"] == "energy_exceeds_ceiling"


def test_switching_limit_uses_same_fail_closed_semantics():
    store = SubstrateProfileStore()
    store.upsert(profile("switch.ok", SubstrateKind.CPU, SubstrateRealization.NATIVE, switching=CostMetric(1, CostEvidence.DECLARED)))
    store.upsert(profile("switch.unknown", SubstrateKind.FPGA, SubstrateRealization.EMULATED))
    result = SubstrateSelector(store).select(
        task(SubstratePolicy(max_switching_cost_units=2)),
        "cap.numeric",
        (Binding("b.ok", "switch.ok"), Binding("b.unknown", "switch.unknown")),
    )
    assert tuple(item.binding_id for item in result.bindings) == ("b.ok",)
    assert dict(result.certificate.rejected)["b.unknown"] == "switching_cost_unknown"
