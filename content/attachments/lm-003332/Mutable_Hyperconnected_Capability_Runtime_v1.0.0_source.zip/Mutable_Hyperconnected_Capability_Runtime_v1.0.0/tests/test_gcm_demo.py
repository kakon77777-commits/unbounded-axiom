from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

pytest.importorskip("gcm_runtime")


def test_gcm_demo_proves_resource_allocation_capacity_fallback_and_restart():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    # The active validation environment provides gcm_runtime on PYTHONPATH/site-packages.
    env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(root / "src"), env.get("PYTHONPATH", ""))))
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.gcm_demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    assert payload["gpu_feasible"]["provider_id"] == "provider.gpu"
    assert payload["gpu_capacity_fallback"]["provider_id"] == "provider.cpu"
    assert payload["restart"]["provider_id"] == "provider.cpu"
    assert payload["restart"]["binding_count"] == 2
    assert payload["world_commit_events"] == 0
