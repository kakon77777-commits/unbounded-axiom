from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import sys
from threading import Thread

import pytest

from mhcr.models import ProviderBoundary, ProviderHealth, ProviderKind
from mhcr.provider_adapters import (
    HttpJsonAdapter,
    LocalPythonAdapter,
    ProviderAdapterError,
    SubprocessJsonAdapter,
    provider_from_adapter,
)


def test_local_python_adapter_builds_local_provider():
    adapter = LocalPythonAdapter(lambda value: value + 3)
    provider = provider_from_adapter("provider.local.add3", "cap.add3", adapter)

    assert provider.execute(4) == 7
    assert provider.kind is ProviderKind.LOCAL_PYTHON
    assert provider.boundary is ProviderBoundary.LOCAL
    assert provider.health is ProviderHealth.HEALTHY
    assert provider.endpoint is None


def test_subprocess_json_adapter_round_trips_json_payload():
    adapter = SubprocessJsonAdapter(
        (
            sys.executable,
            "-c",
            "import json,sys; value=json.load(sys.stdin); json.dump(value*2, sys.stdout)",
        ),
        timeout=2.0,
    )
    provider = provider_from_adapter("provider.process.double", "cap.double", adapter)

    assert provider.execute(6) == 12
    assert provider.kind is ProviderKind.SUBPROCESS
    assert provider.boundary is ProviderBoundary.PROCESS
    assert sys.executable in provider.endpoint


def test_subprocess_nonzero_exit_is_provider_adapter_error():
    adapter = SubprocessJsonAdapter(
        (sys.executable, "-c", "import sys; sys.stderr.write('bad'); sys.exit(7)"),
        timeout=2.0,
    )
    with pytest.raises(ProviderAdapterError, match="exit 7"):
        adapter.execute({"value": 1})


class _JsonHandler(BaseHTTPRequestHandler):
    def do_POST(self):  # noqa: N802 - stdlib handler API
        length = int(self.headers["Content-Length"])
        value = json.loads(self.rfile.read(length))
        body = json.dumps(value + 5).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *_args):
        return


def test_http_json_adapter_calls_loopback_endpoint():
    server = ThreadingHTTPServer(("127.0.0.1", 0), _JsonHandler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        endpoint = f"http://127.0.0.1:{server.server_port}/execute"
        adapter = HttpJsonAdapter(endpoint, kind=ProviderKind.LAN_WORKER, timeout=2.0)
        provider = provider_from_adapter("provider.lan.add5", "cap.add5", adapter)

        assert provider.execute(7) == 12
        assert provider.kind is ProviderKind.LAN_WORKER
        assert provider.boundary is ProviderBoundary.NETWORK
        assert provider.endpoint == endpoint
    finally:
        server.shutdown()
        thread.join(timeout=2.0)
        server.server_close()


def test_container_kind_reuses_subprocess_transport_with_container_boundary():
    adapter = SubprocessJsonAdapter(
        (sys.executable, "-c", "import json,sys; json.dump(json.load(sys.stdin), sys.stdout)"),
        kind=ProviderKind.CONTAINER,
        timeout=2.0,
    )
    provider = provider_from_adapter("provider.container.echo", "cap.echo", adapter)
    assert provider.execute({"ok": True}) == {"ok": True}
    assert provider.kind is ProviderKind.CONTAINER
    assert provider.boundary is ProviderBoundary.CONTAINER


def test_remote_api_kind_reuses_http_transport_contract_metadata():
    adapter = HttpJsonAdapter(
        "https://example.invalid/execute",
        kind=ProviderKind.REMOTE_API,
        timeout=1.0,
    )
    provider = provider_from_adapter("provider.remote.echo", "cap.echo", adapter)
    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.boundary is ProviderBoundary.NETWORK
    assert provider.endpoint == "https://example.invalid/execute"


def test_provider_fabric_types_are_exported_from_package_root():
    import mhcr

    assert mhcr.ProviderKind is ProviderKind
    assert mhcr.ProviderHealth is ProviderHealth
    assert mhcr.ProviderBoundary is ProviderBoundary
    assert mhcr.LocalPythonAdapter is LocalPythonAdapter
    assert mhcr.SubprocessJsonAdapter is SubprocessJsonAdapter
    assert mhcr.HttpJsonAdapter is HttpJsonAdapter
    assert mhcr.ProviderAdapterError is ProviderAdapterError
