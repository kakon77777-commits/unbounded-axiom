from mhcr.history import EventLog
from mhcr.models import Capability, Provider, ProviderBoundary, ProviderHealth, ProviderKind, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.verification import VerificationResult


def make_capability(capability_id: str, state: TrustState) -> Capability:
    family = capability_id.rsplit(".", 1)[-1]
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=(f"provider.{family}",),
        verifier_id=f"verify.{family}",
        trust_state=state,
    )


def test_registry_events_replay_trusted_and_revoked_semantic_state(tmp_path):
    log = EventLog(tmp_path / "registry.jsonl")
    registry = CapabilityRegistry(event_log=log)

    candidate = make_capability("cap.math.double", TrustState.CANDIDATE)
    registry.register_capability(candidate)
    registry.register_provider(Provider("provider.double", candidate.capability_id, lambda value: value * 2))
    registry.promote(candidate.capability_id, VerificationResult(True, "valid"))

    revoked = make_capability("cap.math.triple", TrustState.TRUSTED)
    registry.register_capability(revoked)
    registry.register_provider(Provider("provider.triple", revoked.capability_id, lambda value: value * 3))
    registry.revoke(revoked.capability_id)

    replayed = log.replay_registry(
        provider_executors={
            "provider.double": lambda value: value * 2,
            "provider.triple": lambda value: value * 3,
        }
    )

    assert replayed.get_capability(candidate.capability_id).trust_state is TrustState.TRUSTED
    assert replayed.get_provider("provider.double").execute(5) == 10
    assert replayed.get_capability(revoked.capability_id).trust_state is TrustState.REVOKED
    assert replayed.providers_for(revoked.capability_id)[0].execute(5) == 15


def test_replay_without_executor_binding_restores_provider_unavailable(tmp_path):
    log = EventLog(tmp_path / "registry.jsonl")
    registry = CapabilityRegistry(event_log=log)
    capability = make_capability("cap.math.double", TrustState.TRUSTED)
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.double", capability.capability_id, lambda value: value * 2))

    replayed = log.replay_registry()

    assert replayed.get_provider("provider.double").active is False
    assert replayed.providers_for(capability.capability_id) == []


def test_provider_health_and_transport_metadata_replay_after_failure_state_change(tmp_path):
    log = EventLog(tmp_path / "registry.jsonl")
    registry = CapabilityRegistry(event_log=log)
    capability = make_capability("cap.math.double", TrustState.TRUSTED)
    registry.register_capability(capability)
    registry.register_provider(
        Provider(
            "provider.double",
            capability.capability_id,
            lambda value: value * 2,
            kind=ProviderKind.REMOTE_API,
            health=ProviderHealth.HEALTHY,
            boundary=ProviderBoundary.NETWORK,
            endpoint="https://example.invalid/double",
        )
    )
    registry.set_provider_health("provider.double", ProviderHealth.UNAVAILABLE)

    replayed = log.replay_registry(
        provider_executors={"provider.double": lambda value: value * 2}
    )
    provider = replayed.get_provider("provider.double")

    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.boundary is ProviderBoundary.NETWORK
    assert provider.endpoint == "https://example.invalid/double"
    assert provider.health is ProviderHealth.UNAVAILABLE
    assert replayed.get_capability(capability.capability_id).trust_state is TrustState.TRUSTED


def test_replay_preserves_composite_fidelity_and_component_lineage(tmp_path):
    from mhcr.models import TransitionFidelity

    log = EventLog(tmp_path / "registry.jsonl")
    registry = CapabilityRegistry(event_log=log)
    capability = Capability(
        capability_id="cap.composite.pipeline",
        version="1.0.0",
        task_family="pipeline",
        input_type="raw",
        output_type="final",
        exactness="exact",
        provider_ids=(),
        verifier_id="verify.pipeline",
        trust_state=TrustState.TRUSTED,
        scope="composite",
        fidelity=TransitionFidelity.EXACT,
        component_capability_ids=("cap.parse", "cap.normalize", "cap.finish"),
    )
    registry.register_capability(capability)

    replayed = log.replay_registry()
    restored = replayed.get_capability(capability.capability_id)

    assert restored.fidelity is TransitionFidelity.EXACT
    assert restored.component_capability_ids == capability.component_capability_ids
    assert restored.is_composite is True
