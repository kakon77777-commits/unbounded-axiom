import pytest

from mhcr.sandbox import CandidateInspector, CandidatePolicyViolation, SandboxPolicy


def inspect(source: str, *, policy: SandboxPolicy | None = None):
    return CandidateInspector(policy or SandboxPolicy()).inspect(source, "solve")


def test_safe_pure_solver_and_local_helper_are_accepted():
    source = """
def helper(value):
    return value * value

def solve(payload):
    total = 0
    for item in payload:
        if item > 0:
            total += helper(item)
    return total
"""
    report = inspect(source)
    assert report.entrypoint == "solve"
    assert report.function_names == ("helper", "solve")
    assert report.ast_nodes > 0
    assert report.source_bytes == len(source.encode("utf-8"))


@pytest.mark.parametrize(
    ("source", "needle"),
    [
        ("import socket\ndef solve(payload): return payload", "Import"),
        ("import subprocess\ndef solve(payload): return payload", "Import"),
        ("def solve(payload):\n    return open('/tmp/x').read()", "open"),
        ("def solve(payload):\n    return eval('1+1')", "eval"),
        ("def solve(payload):\n    return payload.__class__", "private attribute"),
        ("def solve(payload):\n    global SECRET\n    return payload", "Global"),
        ("class X: pass\ndef solve(payload): return payload", "ClassDef"),
        ("async def solve(payload): return payload", "AsyncFunctionDef"),
    ],
)
def test_forbidden_constructs_are_rejected(source, needle):
    with pytest.raises(CandidatePolicyViolation, match=needle):
        inspect(source)


def test_missing_entrypoint_is_rejected():
    with pytest.raises(CandidatePolicyViolation, match="entrypoint"):
        inspect("def other(payload):\n    return payload\n")


def test_entrypoint_must_have_exactly_one_plain_positional_parameter():
    with pytest.raises(CandidatePolicyViolation, match="exactly one"):
        inspect("def solve(a, b):\n    return a + b\n")
    with pytest.raises(CandidatePolicyViolation, match="exactly one"):
        inspect("def solve(*args):\n    return 1\n")


def test_source_size_limit_is_enforced_before_parsing():
    policy = SandboxPolicy(max_source_bytes=30)
    with pytest.raises(CandidatePolicyViolation, match="source size"):
        CandidateInspector(policy).inspect(
            "def solve(payload):\n    return payload * payload\n", "solve"
        )


def test_ast_node_limit_is_enforced():
    policy = SandboxPolicy(max_ast_nodes=15)
    source = "def solve(payload):\n" + "    x = payload + 1\n" * 10 + "    return x\n"
    with pytest.raises(CandidatePolicyViolation, match="AST node"):
        CandidateInspector(policy).inspect(source, "solve")


def test_syntax_error_is_reported_as_policy_violation():
    with pytest.raises(CandidatePolicyViolation, match="syntax error"):
        inspect("def solve(payload) return payload")


def test_top_level_executable_statement_is_rejected():
    with pytest.raises(CandidatePolicyViolation, match="top-level"):
        inspect("x = 3\ndef solve(payload):\n    return payload + x\n")
