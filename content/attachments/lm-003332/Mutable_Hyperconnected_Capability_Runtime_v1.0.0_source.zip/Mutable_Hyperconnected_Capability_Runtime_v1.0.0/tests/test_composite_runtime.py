from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.routing import ProviderCostCatalog
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def primitive(capability_id, family, input_type, output_type, provider_id, verifier_id=None):
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type=input_type,
        output_type=output_type,
        exactness="exact",
        provider_ids=(provider_id,),
        verifier_id=verifier_id,
        trust_state=TrustState.TRUSTED,
    )


def build_runtime(tmp_path):
    registry = CapabilityRegistry()
    parse = primitive("cap.parse", "parse", "text", "numbers", "provider.parse")
    double = primitive("cap.double-list", "double-list", "numbers", "doubled", "provider.double-list")
    sum_cap = primitive("cap.sum", "sum", "doubled", "number", "provider.sum", "verify.pipeline")
    for cap in (parse, double, sum_cap):
        registry.register_capability(cap)
    registry.register_provider(
        Provider("provider.parse", parse.capability_id, lambda text: [int(item) for item in text.split(",")])
    )
    registry.register_provider(
        Provider("provider.double-list", double.capability_id, lambda values: [value * 2 for value in values])
    )
    registry.register_provider(
        Provider("provider.sum", sum_cap.capability_id, sum)
    )
    gcal = GCAL()
    for provider_id in ("provider.parse", "provider.double-list", "provider.sum"):
        gcal.register_cost(CostRecord(provider_id, CostVector(local_work=1.0)))
    verifiers = VerifierRegistry()
    verifiers.register(
        "verify.pipeline",
        lambda task, result: result == sum(int(item) * 2 for item in task.payload.split(",")),
    )
    history = EventLog(tmp_path / "events.jsonl")
    runtime = MHCRRuntime(
        registry,
        verifiers,
        gcal,
        history,
        cost_catalog=ProviderCostCatalog(),
    )
    return runtime, registry, history


def test_composed_plan_is_canonicalized_and_second_unseen_input_reuses_without_graph_search(tmp_path):
    runtime, registry, history = build_runtime(tmp_path)

    first = runtime.solve(TaskContract("task.first", "pipeline", "text", "number", "1,2,3"))
    searches_after_first = runtime.resolver.planner.search_invocations
    composites = [cap for cap in registry.capabilities() if cap.is_composite]

    assert first.source == "composed"
    assert first.value == 12
    assert searches_after_first == 1
    assert len(composites) == 1
    composite = composites[0]
    assert composite.trust_state is TrustState.TRUSTED
    assert composite.component_capability_ids == ("cap.parse", "cap.double-list", "cap.sum")

    second = runtime.solve(TaskContract("task.second", "pipeline", "text", "number", "4,5"))

    assert second.source == "resolved"
    assert second.execution_path == "fast"
    assert second.value == 18
    assert second.capability_ids == (composite.capability_id,)
    assert runtime.resolver.planner.search_invocations == searches_after_first
    assert second.provider_ids == ("provider.parse", "provider.double-list", "provider.sum")
    counts = history.replay_counts()
    assert counts["COMPOSITION_PLAN_SELECTED"] == 1
    assert counts["COMPOSITE_CAPABILITY_PROMOTED"] == 1


def test_direct_composite_fast_path_requires_current_component_executability(tmp_path):
    runtime, registry, _history = build_runtime(tmp_path)
    runtime.solve(TaskContract("task.first", "pipeline", "text", "number", "1,2"))
    composite = next(cap for cap in registry.capabilities() if cap.is_composite)

    registry.get_provider("provider.double-list").execute  # prove provider exists
    provider = registry.get_provider("provider.double-list")
    registry._providers[provider.provider_id] = Provider(
        provider.provider_id,
        provider.capability_id,
        provider.execute,
        active=False,
        kind=provider.kind,
        health=provider.health,
        boundary=provider.boundary,
        endpoint=provider.endpoint,
    )

    assert runtime.resolver.resolve_one(
        TaskContract("task.second", "pipeline", "text", "number", "2,3")
    ).capability_id == composite.capability_id

    try:
        runtime.solve(TaskContract("task.second", "pipeline", "text", "number", "2,3"))
    except LookupError:
        pass
    else:
        raise AssertionError("composite should not execute when a component has no eligible provider")
