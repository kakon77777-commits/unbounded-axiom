from __future__ import annotations

from mhcr.history import EventLog
from mhcr.models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderHealth,
    ProviderKind,
    TrustState,
)
from mhcr.rdr import RDR
from mhcr.registry import CapabilityRegistry


def capability(provider_ids: tuple[str, ...]) -> Capability:
    return Capability(
        capability_id="cap.double",
        version="1.0.0",
        task_family="double",
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=provider_ids,
        trust_state=TrustState.TRUSTED,
    )


def test_rdr_prefers_healthy_provider_over_degraded_provider():
    registry = CapabilityRegistry()
    cap = capability(("provider.degraded", "provider.healthy"))
    registry.register_capability(cap)
    registry.register_provider(
        Provider(
            "provider.degraded",
            cap.capability_id,
            lambda value: value * 20,
            health=ProviderHealth.DEGRADED,
        )
    )
    registry.register_provider(
        Provider("provider.healthy", cap.capability_id, lambda value: value * 2)
    )

    materialized = RDR(registry).materialize(cap)
    assert materialized.provider.provider_id == "provider.healthy"


def test_rdr_preserves_declared_order_within_same_health_tier():
    registry = CapabilityRegistry()
    cap = capability(("provider.second-registered", "provider.first-registered"))
    registry.register_capability(cap)
    registry.register_provider(
        Provider("provider.first-registered", cap.capability_id, lambda value: value + 100)
    )
    registry.register_provider(
        Provider("provider.second-registered", cap.capability_id, lambda value: value * 2)
    )

    materialized = RDR(registry).materialize(cap)
    assert materialized.provider.provider_id == "provider.second-registered"


def test_provider_failure_marks_only_provider_unavailable_and_fails_over(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=log)
    cap = capability(("provider.bad", "provider.good"))
    registry.register_capability(cap)

    def fail(_value):
        raise RuntimeError("provider exploded")

    registry.register_provider(
        Provider(
            "provider.bad",
            cap.capability_id,
            fail,
            kind=ProviderKind.REMOTE_API,
            boundary=ProviderBoundary.NETWORK,
        )
    )
    registry.register_provider(
        Provider("provider.good", cap.capability_id, lambda value: value * 2)
    )

    outcome = RDR(registry, event_log=log).execute_capability(cap, 9, task_id="task-1")

    assert outcome.value == 18
    assert outcome.provider.provider_id == "provider.good"
    assert outcome.failed_provider_ids == ("provider.bad",)
    assert registry.get_provider("provider.bad").health is ProviderHealth.UNAVAILABLE
    assert registry.get_capability(cap.capability_id).trust_state is TrustState.TRUSTED
    event_types = [event.event_type for event in log.read_all()]
    assert "PROVIDER_EXECUTION_FAILED" in event_types
    assert "REGISTRY_PROVIDER_HEALTH_CHANGED" in event_types


def test_unavailable_and_quarantined_providers_are_not_materializable():
    registry = CapabilityRegistry()
    cap = capability(("provider.unavailable", "provider.quarantined"))
    registry.register_capability(cap)
    registry.register_provider(
        Provider(
            "provider.unavailable",
            cap.capability_id,
            lambda value: value,
            health=ProviderHealth.UNAVAILABLE,
        )
    )
    registry.register_provider(
        Provider(
            "provider.quarantined",
            cap.capability_id,
            lambda value: value,
            health=ProviderHealth.QUARANTINED,
        )
    )

    try:
        RDR(registry).materialize(cap)
    except RuntimeError as exc:
        assert "no eligible provider" in str(exc)
    else:
        raise AssertionError("expected no eligible provider")
