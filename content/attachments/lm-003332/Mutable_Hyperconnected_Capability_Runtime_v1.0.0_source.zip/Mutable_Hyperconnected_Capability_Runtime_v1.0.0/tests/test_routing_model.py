from __future__ import annotations

import pytest

from mhcr.models import RoutingPreference, TaskContract, TaskPolicy
from mhcr.routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile


def test_task_contract_default_policy_preserves_no_constraints_or_preferences():
    task = TaskContract("task-1", "double", "int", "int", 3)

    assert task.policy == TaskPolicy()
    assert task.policy.is_default is True
    assert task.policy.prefer == ()


def test_task_policy_accepts_ordered_preferences_and_hard_ceilings():
    policy = TaskPolicy(
        local_only=True,
        max_latency_ms=25.0,
        max_external_cost_usd=0.05,
        max_network_bytes=2048,
        max_verification_work=3.0,
        max_risk_score=0.2,
        prefer=(RoutingPreference.LATENCY, RoutingPreference.MONETARY_COST),
    )

    assert policy.is_default is False
    assert policy.prefer[0] is RoutingPreference.LATENCY
    assert policy.max_external_cost_usd == 0.05


def test_unknown_cost_metric_is_none_and_never_implicit_zero():
    metric = CostMetric()

    assert metric.value is None
    assert metric.evidence is CostEvidence.UNKNOWN
    assert metric.known is False


def test_inconsistent_unknown_metric_is_rejected():
    with pytest.raises(ValueError, match="UNKNOWN metric cannot carry a value"):
        CostMetric(0.0, CostEvidence.UNKNOWN)


def test_provider_cost_profile_defaults_every_dimension_to_unknown():
    profile = ProviderCostProfile("provider.remote")

    assert profile.latency_ms.known is False
    assert profile.monetary_cost_usd.known is False
    assert profile.network_bytes.known is False
    assert profile.verification_work.known is False
    assert profile.risk_score.known is False


def test_cost_catalog_upserts_and_reads_profile_without_mutating_other_metrics():
    catalog = ProviderCostCatalog()
    profile = ProviderCostProfile(
        "provider.remote",
        latency_ms=CostMetric(10.0, CostEvidence.DECLARED),
        monetary_cost_usd=CostMetric(0.02, CostEvidence.ESTIMATED),
    )

    catalog.upsert(profile, persist=False)
    restored = catalog.get("provider.remote")

    assert restored == profile
    assert restored.network_bytes.known is False


def test_cost_catalog_returns_unknown_profile_for_missing_provider():
    profile = ProviderCostCatalog().get("provider.missing")

    assert profile.provider_id == "provider.missing"
    assert profile.latency_ms.known is False
