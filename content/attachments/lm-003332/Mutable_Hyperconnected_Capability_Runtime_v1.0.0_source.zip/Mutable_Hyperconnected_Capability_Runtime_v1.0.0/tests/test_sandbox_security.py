from pathlib import Path

import pytest

from mhcr.accounting import GCAL
from mhcr.constructor import CandidateConstructionError, GeneratedSourceSpec, SandboxedSourceConstructor
from mhcr.history import EventLog
from mhcr.models import TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.sandbox import (
    CandidateArtifactStatus,
    GeneratedArtifactStore,
    PythonSandboxRunner,
    SandboxPolicy,
    load_sandbox_provider_bindings,
)
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.verification import VerifierRegistry


def build_runtime(tmp_path, source: str, *, policy=None, persistent=False):
    repo = SQLiteRepository(tmp_path / "mhcr.sqlite3") if persistent else None
    history = EventLog(tmp_path / "events.jsonl")
    store = GeneratedArtifactStore(repository=repo, event_log=history)
    runner = PythonSandboxRunner(policy=policy or SandboxPolicy(timeout_seconds=2.0))
    constructor = SandboxedSourceConstructor(
        lambda _task: GeneratedSourceSpec(source),
        artifact_store=store,
        runner=runner,
        verifier_id="verify.square",
    )
    registry = CapabilityRegistry(repository=repo, event_log=history)
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(registry, verifiers, GCAL(repo), history, constructor=constructor)
    return runtime, registry, store, runner, repo


def task(task_id="task.security", value=4):
    return TaskContract(task_id, "square", "number", "number", value)


def test_forbidden_file_write_is_rejected_before_marker_can_exist(tmp_path):
    marker = tmp_path / "must-not-exist.txt"
    source = f"def solve(payload):\n    open({str(marker)!r}, 'w').write('bad')\n    return payload\n"
    runtime, _registry, store, _runner, _repo = build_runtime(tmp_path, source)

    with pytest.raises(CandidateConstructionError, match="inspection"):
        runtime.solve(task())

    assert marker.exists() is False
    assert store.records()[0].status is CandidateArtifactStatus.REJECTED


def test_forbidden_network_and_shell_imports_are_rejected_before_execution(tmp_path):
    for index, module in enumerate(("socket", "subprocess")):
        root = tmp_path / str(index)
        root.mkdir()
        source = f"import {module}\ndef solve(payload):\n    return payload\n"
        runtime, _registry, store, _runner, _repo = build_runtime(root, source)
        with pytest.raises(CandidateConstructionError, match="inspection"):
            runtime.solve(task(f"task.{module}"))
        assert store.records()[0].status is CandidateArtifactStatus.REJECTED


def test_sandbox_timeout_rejects_candidate_without_trust(tmp_path):
    policy = SandboxPolicy(timeout_seconds=0.1, cpu_seconds=1)
    runtime, registry, store, _runner, _repo = build_runtime(
        tmp_path,
        "def solve(payload):\n    while True:\n        pass\n",
        policy=policy,
    )
    with pytest.raises(CandidateConstructionError, match="sandbox"):
        runtime.solve(task("task.timeout"))
    with pytest.raises(KeyError):
        registry.get_capability("cap.generated.square")
    assert store.records()[0].status is CandidateArtifactStatus.REJECTED


def test_runtime_revocation_marks_artifact_revoked_and_binding_helper_skips_it(tmp_path):
    runtime, registry, store, runner, repo = build_runtime(
        tmp_path,
        "def solve(payload):\n    return payload * payload\n",
        persistent=True,
    )
    assert repo is not None
    solved = runtime.solve(task("task.promote", 5))
    assert solved.value == 25
    assert registry.get_capability("cap.generated.square").trust_state is TrustState.TRUSTED
    assert store.records()[0].status is CandidateArtifactStatus.PROMOTED

    registry.revoke("cap.generated.square")
    assert store.records()[0].status is CandidateArtifactStatus.REVOKED
    assert load_sandbox_provider_bindings(repo, runner) == {}
    repo.close()
