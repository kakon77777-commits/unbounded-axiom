from mhcr.accounting import AccountingStatus, CostRecord, CostVector, Dependency, GCAL


def test_local_and_closed_cost_are_reported_separately():
    gcal = GCAL()
    gcal.register_cost(CostRecord("local", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("remote", CostVector(external_work=10.0)))
    gcal.register_dependency(Dependency("local", "remote", required=True))

    report = gcal.account("local")

    assert report.local.local_work == 1.0
    assert report.local.external_work == 0.0
    assert report.closed.local_work == 1.0
    assert report.closed.external_work == 10.0
    assert report.status is AccountingStatus.CLOSED_ACCOUNTED


def test_unknown_required_cost_makes_closed_accounting_incomplete_not_zero():
    gcal = GCAL()
    gcal.register_cost(CostRecord("local", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("mystery-api", CostVector(), known=False))
    gcal.register_dependency(Dependency("local", "mystery-api", required=True))

    report = gcal.account("local")

    assert report.status is AccountingStatus.ACCOUNTING_INCOMPLETE
    assert report.unknown_nodes == ("mystery-api",)
    assert report.is_closed_complete is False


def test_responsibility_closure_recursively_includes_required_dependencies():
    gcal = GCAL()
    for node in ("root", "provider", "model"):
        gcal.register_cost(CostRecord(node, CostVector(local_work=1.0)))
    gcal.register_dependency(Dependency("root", "provider"))
    gcal.register_dependency(Dependency("provider", "model"))

    report = gcal.account("root")

    assert report.closure == ("model", "provider", "root")
    assert report.closed.local_work == 3.0


def test_shared_formation_cost_is_deduplicated_in_closed_view():
    gcal = GCAL()
    gcal.register_cost(CostRecord("root", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("step-a", CostVector(offline_work=100.0), shared_cost_id="model.foo"))
    gcal.register_cost(CostRecord("step-b", CostVector(offline_work=100.0), shared_cost_id="model.foo"))
    gcal.register_dependency(Dependency("root", "step-a"))
    gcal.register_dependency(Dependency("root", "step-b"))

    report = gcal.account("root")

    assert report.closed.offline_work == 100.0
