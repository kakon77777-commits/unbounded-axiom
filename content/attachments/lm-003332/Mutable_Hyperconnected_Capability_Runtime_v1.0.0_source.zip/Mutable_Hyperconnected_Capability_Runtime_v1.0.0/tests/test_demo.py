import json
import os
from pathlib import Path
import subprocess
import sys


def test_demo_proves_construct_promote_and_unseen_reuse():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)

    assert payload["first"]["value"] == 16
    assert payload["first"]["source"] == "constructed"
    assert payload["second"]["value"] == 49
    assert payload["second"]["source"] == "resolved"
    assert payload["second"]["execution_path"] == "fast"
    assert payload["restart_count"] == 1
    assert payload["benchmark"]["speedup_ratio"] > 1
    assert payload["constructor_count"] == 1
    assert payload["trusted_capability_count"] == 1
    assert payload["history"]["CAPABILITY_PROMOTED"] == 1
    assert payload["history"]["TASK_COMPLETED"] == 4


def test_demo_proves_provider_failover_health_persistence_and_replay():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    fabric = payload["provider_fabric"]

    assert fabric["first_value"] == 18
    assert fabric["first_accounting"] == "accounting_incomplete"
    assert fabric["failed_provider_health"] == "unavailable"
    assert fabric["restart_value"] == 22
    assert fabric["restart_execution_path"] == "fast"
    assert fabric["restart_failed_provider_health"] == "unavailable"
    assert fabric["capability_trust"] == "trusted"
    assert fabric["boundary_events"] == 1
    assert fabric["failure_events"] == 1
    assert fabric["replay_provider_kind"] == "subprocess"
    assert fabric["replay_provider_health"] == "unavailable"


def test_demo_proves_cost_aware_policy_selection_and_profile_restart():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    routing = payload["cost_routing"]

    assert routing["latency_provider"] == "provider.route.fast"
    assert routing["money_provider"] == "provider.route.cheap"
    assert routing["local_only_provider"] == "provider.route.local"
    assert routing["ceiling_provider"] == "provider.route.cheap"
    assert routing["latency_accounting"] == "accounting_incomplete"
    assert routing["restored_fast_latency_evidence"] == "measured"
    assert routing["restored_fast_price"] == 0.08
    assert routing["restored_unknown_price_evidence"] == "unknown"
    assert routing["routing_decision_events"] >= 4


def test_v04_public_api_exports_cost_routing_contracts():
    from mhcr import (
        CostEvidence,
        CostMetric,
        ProviderCostCatalog,
        ProviderCostProfile,
        RoutingPreference,
        TaskPolicy,
    )

    assert TaskPolicy().is_default is True
    assert RoutingPreference.LATENCY.value == "latency"
    assert CostMetric().evidence is CostEvidence.UNKNOWN
    assert ProviderCostCatalog().get("provider.x") == ProviderCostProfile("provider.x")


def test_demo_proves_weighted_composition_canonicalization_restart_reuse_and_invalidation():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    composition = payload["composition"]

    assert composition["first_value"] == 12
    assert composition["first_source"] == "composed"
    assert composition["first_graph_searches"] == 1
    assert composition["first_graph_expansions"] > 0
    assert composition["component_ids"] == [
        "cap.demo.parse",
        "cap.demo.double-list",
        "cap.demo.sum",
    ]
    assert composition["composite_trust_before_restart"] == "trusted"
    assert composition["restart_value"] == 18
    assert composition["restart_source"] == "resolved"
    assert composition["restart_execution_path"] == "fast"
    assert composition["restart_graph_searches"] == 0
    assert composition["persisted_component_ids"] == composition["component_ids"]
    assert composition["trust_after_component_revoke"] == "deprecated"
    assert composition["replay_trust_after_revoke"] == "deprecated"
    assert composition["invalidation_events"] == 1


def test_v05_public_api_exports_composition_contracts():
    from mhcr import (
        CompositionPlan,
        CompositionPlanner,
        CompositionPolicy,
        TransitionFidelity,
    )

    assert CompositionPolicy().max_steps == 6
    assert TransitionFidelity.EXACT.value == "exact"
    assert CompositionPlanner is not None
    assert CompositionPlan is not None


def test_demo_proves_v06_persistent_acquisition_learning_without_answer_cache():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    learning = payload["acquisition_learning"]

    assert learning["stateless_constructor_invocations"] == 4
    assert learning["persistent_constructor_invocations"] == 1
    assert learning["persistent_total_work"] < learning["stateless_total_work"]
    assert learning["work_reduction_ratio"] > 1.0
    assert learning["all_cache_hits_false"] is True
    assert learning["persistent_solver_memory_hits"] >= 3
    assert learning["persistent_verification_memory_hits"] >= 3


def test_v06_public_api_exports_acquisition_memory_and_benchmark_contracts():
    from mhcr import (
        AcquisitionMemoryKind,
        AcquisitionMemoryRecord,
        AcquisitionMemoryStore,
        AcquisitionTrace,
        AcquisitionBenchmarkResult,
        benchmark_acquisition_learning,
    )

    assert AcquisitionMemoryKind.SOLVER.value == "solver"
    assert AcquisitionMemoryRecord is not None
    assert AcquisitionMemoryStore is not None
    assert AcquisitionTrace().acquisition_work == 0.0
    assert AcquisitionBenchmarkResult is not None
    assert callable(benchmark_acquisition_learning)


def test_demo_proves_v07_generated_sandbox_promotion_restart_and_unseen_reuse():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(root / "src")
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    sandbox = payload["generated_sandbox"]

    assert sandbox["first_value"] == 36
    assert sandbox["first_source"] == "constructed"
    assert sandbox["first_artifact_status"] == "promoted"
    assert sandbox["first_capability_trust"] == "trusted"
    assert sandbox["restart_value"] == 81
    assert sandbox["restart_source"] == "resolved"
    assert sandbox["restart_execution_path"] == "fast"
    assert sandbox["restart_cache_hit"] is False
    assert sandbox["constructor_invocations"] == 1
    assert sandbox["artifact_source_hash_matches"] is True
    assert sandbox["sandbox_provider_boundary"] == "process"


def test_v07_public_api_exports_sandbox_contracts():
    from mhcr import (
        CandidateArtifactStatus,
        CandidateInspector,
        GeneratedArtifactStore,
        GeneratedCandidateArtifact,
        GeneratedSourceSpec,
        PythonSandboxRunner,
        SandboxedSourceConstructor,
        SandboxPolicy,
        load_sandbox_provider_bindings,
    )

    assert CandidateArtifactStatus.PROPOSED.value == "proposed"
    assert SandboxPolicy().allow_network is False
    assert CandidateInspector is not None
    assert GeneratedArtifactStore is not None
    assert GeneratedCandidateArtifact is not None
    assert GeneratedSourceSpec is not None
    assert PythonSandboxRunner is not None
    assert SandboxedSourceConstructor is not None
    assert callable(load_sandbox_provider_bindings)
