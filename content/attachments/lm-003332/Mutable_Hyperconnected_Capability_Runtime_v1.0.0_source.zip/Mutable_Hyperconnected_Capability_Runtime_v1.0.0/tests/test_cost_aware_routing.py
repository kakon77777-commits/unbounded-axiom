from __future__ import annotations

from mhcr.models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderHealth,
    ProviderKind,
    RoutingPreference,
    TaskPolicy,
    TrustState,
)
from mhcr.rdr import RDR
from mhcr.registry import CapabilityRegistry
from mhcr.routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile


def cap(provider_ids: tuple[str, ...]) -> Capability:
    return Capability(
        capability_id="cap.route",
        version="1.0.0",
        task_family="route",
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=provider_ids,
        trust_state=TrustState.TRUSTED,
    )


def provider(
    provider_id: str,
    capability_id: str,
    *,
    boundary: ProviderBoundary = ProviderBoundary.LOCAL,
    health: ProviderHealth = ProviderHealth.HEALTHY,
) -> Provider:
    kind = ProviderKind.REMOTE_API if boundary is ProviderBoundary.NETWORK else ProviderKind.LOCAL_PYTHON
    return Provider(
        provider_id,
        capability_id,
        lambda value: value,
        kind=kind,
        boundary=boundary,
        health=health,
    )


def metric(value: float) -> CostMetric:
    return CostMetric(value, CostEvidence.DECLARED)


def test_default_policy_preserves_v03_declared_order_within_health_tier():
    registry = CapabilityRegistry()
    capability = cap(("provider.second", "provider.first"))
    registry.register_capability(capability)
    registry.register_provider(provider("provider.first", capability.capability_id))
    registry.register_provider(provider("provider.second", capability.capability_id))
    catalog = ProviderCostCatalog()
    catalog.upsert(ProviderCostProfile("provider.first", latency_ms=metric(1.0)), persist=False)
    catalog.upsert(ProviderCostProfile("provider.second", latency_ms=metric(100.0)), persist=False)

    ordered = RDR(registry, cost_catalog=catalog).eligible_providers(capability, TaskPolicy())

    assert [item.provider_id for item in ordered] == ["provider.second", "provider.first"]


def test_local_only_excludes_network_but_allows_process_boundary():
    registry = CapabilityRegistry()
    capability = cap(("provider.remote", "provider.process"))
    registry.register_capability(capability)
    registry.register_provider(provider("provider.remote", capability.capability_id, boundary=ProviderBoundary.NETWORK))
    registry.register_provider(provider("provider.process", capability.capability_id, boundary=ProviderBoundary.PROCESS))

    ordered = RDR(registry, cost_catalog=ProviderCostCatalog()).eligible_providers(
        capability, TaskPolicy(local_only=True)
    )

    assert [item.provider_id for item in ordered] == ["provider.process"]


def test_hard_latency_ceiling_rejects_unknown_and_over_ceiling_metrics():
    registry = CapabilityRegistry()
    capability = cap(("provider.unknown", "provider.slow", "provider.fast"))
    registry.register_capability(capability)
    catalog = ProviderCostCatalog()
    for provider_id in capability.provider_ids:
        registry.register_provider(provider(provider_id, capability.capability_id))
    catalog.upsert(ProviderCostProfile("provider.slow", latency_ms=metric(40.0)), persist=False)
    catalog.upsert(ProviderCostProfile("provider.fast", latency_ms=metric(10.0)), persist=False)

    ordered = RDR(registry, cost_catalog=catalog).eligible_providers(
        capability, TaskPolicy(max_latency_ms=20.0)
    )

    assert [item.provider_id for item in ordered] == ["provider.fast"]


def test_external_money_ceiling_rejects_unknown_remote_price_but_not_local_provider():
    registry = CapabilityRegistry()
    capability = cap(("provider.remote", "provider.local"))
    registry.register_capability(capability)
    registry.register_provider(provider("provider.remote", capability.capability_id, boundary=ProviderBoundary.NETWORK))
    registry.register_provider(provider("provider.local", capability.capability_id))

    ordered = RDR(registry, cost_catalog=ProviderCostCatalog()).eligible_providers(
        capability, TaskPolicy(max_external_cost_usd=0.05)
    )

    assert [item.provider_id for item in ordered] == ["provider.local"]


def test_latency_and_money_preferences_choose_different_providers():
    registry = CapabilityRegistry()
    capability = cap(("provider.fast", "provider.cheap"))
    registry.register_capability(capability)
    catalog = ProviderCostCatalog()
    for provider_id in capability.provider_ids:
        registry.register_provider(provider(provider_id, capability.capability_id, boundary=ProviderBoundary.NETWORK))
    catalog.upsert(
        ProviderCostProfile("provider.fast", latency_ms=metric(5.0), monetary_cost_usd=metric(0.09)),
        persist=False,
    )
    catalog.upsert(
        ProviderCostProfile("provider.cheap", latency_ms=metric(50.0), monetary_cost_usd=metric(0.01)),
        persist=False,
    )
    rdr = RDR(registry, cost_catalog=catalog)

    fastest = rdr.eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.LATENCY,))
    )
    cheapest = rdr.eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.MONETARY_COST,))
    )

    assert fastest[0].provider_id == "provider.fast"
    assert cheapest[0].provider_id == "provider.cheap"


def test_known_preference_metric_ranks_before_unknown_metric():
    registry = CapabilityRegistry()
    capability = cap(("provider.unknown", "provider.known"))
    registry.register_capability(capability)
    registry.register_provider(provider("provider.unknown", capability.capability_id))
    registry.register_provider(provider("provider.known", capability.capability_id))
    catalog = ProviderCostCatalog()
    catalog.upsert(ProviderCostProfile("provider.known", latency_ms=metric(30.0)), persist=False)

    ordered = RDR(registry, cost_catalog=catalog).eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.LATENCY,))
    )

    assert [item.provider_id for item in ordered] == ["provider.known", "provider.unknown"]


def test_health_priority_remains_above_cost_preference():
    registry = CapabilityRegistry()
    capability = cap(("provider.degraded-fast", "provider.healthy-slow"))
    registry.register_capability(capability)
    registry.register_provider(
        provider("provider.degraded-fast", capability.capability_id, health=ProviderHealth.DEGRADED)
    )
    registry.register_provider(provider("provider.healthy-slow", capability.capability_id))
    catalog = ProviderCostCatalog()
    catalog.upsert(ProviderCostProfile("provider.degraded-fast", latency_ms=metric(1.0)), persist=False)
    catalog.upsert(ProviderCostProfile("provider.healthy-slow", latency_ms=metric(100.0)), persist=False)

    ordered = RDR(registry, cost_catalog=catalog).eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.LATENCY,))
    )

    assert ordered[0].provider_id == "provider.healthy-slow"


def test_runtime_propagates_task_policy_to_rdr_provider_selection(tmp_path):
    from mhcr.accounting import CostRecord, CostVector, GCAL
    from mhcr.history import EventLog
    from mhcr.models import TaskContract
    from mhcr.runtime import MHCRRuntime
    from mhcr.verification import VerifierRegistry

    called: list[str] = []
    registry = CapabilityRegistry()
    capability = Capability(
        capability_id="cap.runtime.route",
        version="1.0.0",
        task_family="runtime-route",
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=("provider.slow", "provider.fast"),
        verifier_id="verify.route",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(capability)
    registry.register_provider(
        Provider("provider.slow", capability.capability_id, lambda value: (called.append("slow"), value * 2)[1])
    )
    registry.register_provider(
        Provider("provider.fast", capability.capability_id, lambda value: (called.append("fast"), value * 2)[1])
    )
    catalog = ProviderCostCatalog()
    catalog.upsert(ProviderCostProfile("provider.slow", latency_ms=metric(50.0)), persist=False)
    catalog.upsert(ProviderCostProfile("provider.fast", latency_ms=metric(5.0)), persist=False)
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.slow", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.fast", CostVector(local_work=1.0)))
    verifiers = VerifierRegistry()
    verifiers.register("verify.route", lambda task, result: result == task.payload * 2)
    runtime = MHCRRuntime(
        registry,
        verifiers,
        gcal,
        EventLog(tmp_path / "events.jsonl"),
        cost_catalog=catalog,
    )

    result = runtime.solve(
        TaskContract(
            "task.route",
            "runtime-route",
            "int",
            "int",
            4,
            policy=TaskPolicy(prefer=(RoutingPreference.LATENCY,)),
        )
    )

    assert result.value == 8
    assert called == ["fast"]


def test_network_verification_and_risk_ceilings_filter_noncompliant_providers():
    registry = CapabilityRegistry()
    capability = cap(("provider.network-heavy", "provider.verify-heavy", "provider.risky", "provider.good"))
    registry.register_capability(capability)
    catalog = ProviderCostCatalog()
    for provider_id in capability.provider_ids:
        registry.register_provider(
            provider(provider_id, capability.capability_id, boundary=ProviderBoundary.NETWORK)
        )
    catalog.upsert(
        ProviderCostProfile(
            "provider.network-heavy",
            network_bytes=metric(9000), verification_work=metric(1), risk_score=metric(0.1),
        ), persist=False,
    )
    catalog.upsert(
        ProviderCostProfile(
            "provider.verify-heavy",
            network_bytes=metric(1000), verification_work=metric(9), risk_score=metric(0.1),
        ), persist=False,
    )
    catalog.upsert(
        ProviderCostProfile(
            "provider.risky",
            network_bytes=metric(1000), verification_work=metric(1), risk_score=metric(0.9),
        ), persist=False,
    )
    catalog.upsert(
        ProviderCostProfile(
            "provider.good",
            network_bytes=metric(1000), verification_work=metric(1), risk_score=metric(0.1),
        ), persist=False,
    )

    ordered = RDR(registry, cost_catalog=catalog).eligible_providers(
        capability,
        TaskPolicy(max_network_bytes=2000, max_verification_work=2, max_risk_score=0.2),
    )

    assert [item.provider_id for item in ordered] == ["provider.good"]


def test_network_and_verification_preferences_can_reorder_same_health_providers():
    registry = CapabilityRegistry()
    capability = cap(("provider.low-network", "provider.low-verify"))
    registry.register_capability(capability)
    registry.register_provider(
        provider("provider.low-network", capability.capability_id, boundary=ProviderBoundary.NETWORK)
    )
    registry.register_provider(
        provider("provider.low-verify", capability.capability_id, boundary=ProviderBoundary.NETWORK)
    )
    catalog = ProviderCostCatalog()
    catalog.upsert(
        ProviderCostProfile(
            "provider.low-network", network_bytes=metric(100), verification_work=metric(10)
        ), persist=False,
    )
    catalog.upsert(
        ProviderCostProfile(
            "provider.low-verify", network_bytes=metric(1000), verification_work=metric(1)
        ), persist=False,
    )
    rdr = RDR(registry, cost_catalog=catalog)

    network_first = rdr.eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.NETWORK_BYTES,))
    )
    verify_first = rdr.eligible_providers(
        capability, TaskPolicy(prefer=(RoutingPreference.VERIFICATION_WORK,))
    )

    assert network_first[0].provider_id == "provider.low-network"
    assert verify_first[0].provider_id == "provider.low-verify"
