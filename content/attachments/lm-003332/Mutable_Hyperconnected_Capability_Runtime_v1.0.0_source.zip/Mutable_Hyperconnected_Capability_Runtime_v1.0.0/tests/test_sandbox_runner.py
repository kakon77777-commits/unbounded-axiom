import os
from pathlib import Path

import pytest

from mhcr.sandbox import (
    CandidateInspector,
    CandidatePolicyViolation,
    GeneratedCandidateArtifact,
    PythonSandboxRunner,
    SandboxExecutionError,
    SandboxPolicy,
    SandboxSerializationError,
    SandboxTimeoutError,
)


def artifact(source: str, *, policy: SandboxPolicy | None = None):
    policy = policy or SandboxPolicy(timeout_seconds=2.0, cpu_seconds=1)
    return GeneratedCandidateArtifact.create(
        artifact_id="artifact.runner",
        capability_id="cap.runner",
        provider_id="provider.runner",
        task_family="runner",
        input_type="json",
        output_type="json",
        exactness="exact",
        source=source,
        entrypoint="solve",
        policy_id=policy.policy_id,
    ), policy


def test_runner_executes_pure_generated_code_in_subprocess():
    item, policy = artifact(
        "def solve(payload):\n"
        "    total = 0\n"
        "    for value in payload:\n"
        "        total += value * value\n"
        "    return total\n"
    )
    runner = PythonSandboxRunner(policy=policy)
    assert runner.run(item, [2, 3, 4]) == 29


def test_runner_scrubs_parent_environment_and_uses_temporary_cwd(monkeypatch):
    monkeypatch.setenv("MHCR_SUPER_SECRET", "do-not-leak")
    item, policy = artifact("def solve(payload):\n    return payload\n")
    report = PythonSandboxRunner(policy=policy).run_detailed(item, {"ok": True})

    assert report.value == {"ok": True}
    assert "MHCR_SUPER_SECRET" not in report.environment_keys
    assert set(report.environment_keys).issubset(
        {"PYTHONIOENCODING", "PYTHONUTF8", "MHCR_SANDBOX_CPU_SECONDS", "MHCR_SANDBOX_MEMORY_BYTES", "LC_CTYPE"}
    )
    assert Path(report.cwd) != Path.cwd()
    assert Path(report.cwd).exists() is False


def test_runner_rechecks_policy_before_starting_subprocess():
    item, policy = artifact("def solve(payload):\n    return open('/tmp/x', 'w')\n")
    with pytest.raises(CandidatePolicyViolation, match="open"):
        PythonSandboxRunner(policy=policy).run(item, 1)


def test_runner_times_out_infinite_loop():
    policy = SandboxPolicy(timeout_seconds=0.1, cpu_seconds=1)
    item, _ = artifact("def solve(payload):\n    while True:\n        pass\n", policy=policy)
    with pytest.raises(SandboxTimeoutError, match="timed out"):
        PythonSandboxRunner(policy=policy).run(item, 1)


def test_runner_reports_generated_runtime_error():
    item, policy = artifact("def solve(payload):\n    return 1 / 0\n")
    with pytest.raises(SandboxExecutionError, match="ZeroDivisionError"):
        PythonSandboxRunner(policy=policy).run(item, 1)


def test_runner_rejects_non_json_serializable_result():
    item, policy = artifact("def solve(payload):\n    return {1, 2, 3}\n")
    with pytest.raises(SandboxSerializationError, match="JSON"):
        PythonSandboxRunner(policy=policy).run(item, 1)


def test_runner_reports_resource_limit_support_without_exposing_generated_privilege():
    item, policy = artifact("def solve(payload):\n    return payload + 1\n")
    report = PythonSandboxRunner(policy=policy).run_detailed(item, 4)
    assert report.value == 5
    assert report.worker_pid != os.getpid()
    assert isinstance(report.resource_limits_applied, bool)
    # The trusted worker may use resource/os internally; generated source receives neither name.
    assert "os" not in report.generated_global_names
    assert "resource" not in report.generated_global_names
