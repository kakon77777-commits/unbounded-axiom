from __future__ import annotations

from dataclasses import dataclass

import pytest

from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.gcm_integration import GCMAllocationDecision, GCMAllocationRejectedError
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, ProviderHealth, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def decision(task: TaskContract, capability: Capability, provider_id: str) -> GCMAllocationDecision:
    return GCMAllocationDecision(
        decision_id=f"decision:{task.task_id}:{provider_id}",
        task_id=task.task_id,
        capability_id=capability.capability_id,
        provider_id=provider_id,
        binding_id=f"binding:{provider_id}",
        resource_id=f"resource:{provider_id}",
        configuration_id=f"cfg:{provider_id}",
        executor_id=provider_id,
        resource_snapshot_id="snapshot:test",
        b1_plan_id="plan:b1",
        allocation_plan_id="allocation-plan:test",
        allocation_plan_digest="sha256:test",
        gcm_package_version="0.4.0",
        reason="test allocation",
    )


@dataclass
class FakeAllocator:
    provider_id: str
    calls: int = 0

    def allocate(self, task, capability, ordered_provider_ids):
        self.calls += 1
        assert self.provider_id in ordered_provider_ids
        return decision(task, capability, self.provider_id)


class RejectingAllocator:
    def allocate(self, task, capability, ordered_provider_ids):
        raise GCMAllocationRejectedError("no capacity", ({"failure_code": "CAPACITY_EXCEEDED"},))


def make_runtime(tmp_path, allocator, gpu_execute, cpu_execute):
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    gcal = GCAL()
    history = EventLog(tmp_path / "events.jsonl")
    cap = Capability(
        capability_id="cap.square",
        version="1.0.0",
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.cpu", "provider.gpu"),
        verifier_id="verify.square",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.cpu", cap.capability_id, cpu_execute))
    registry.register_provider(Provider("provider.gpu", cap.capability_id, gpu_execute))
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    gcal.register_cost(CostRecord("provider.cpu", CostVector(local_work=2.0)))
    gcal.register_cost(CostRecord("provider.gpu", CostVector(local_work=1.0)))
    runtime = MHCRRuntime(
        registry, verifiers, gcal, history, compute_allocator=allocator
    )
    return runtime, registry, cap


def test_gcm_selected_provider_is_the_only_provider_executed(tmp_path) -> None:
    calls: list[str] = []
    runtime, _registry, _cap = make_runtime(
        tmp_path,
        FakeAllocator("provider.gpu"),
        lambda x: calls.append("gpu") or x * x,
        lambda x: calls.append("cpu") or x * x,
    )
    result = runtime.solve(TaskContract("task.gpu", "square", "number", "number", 5))

    assert result.value == 25
    assert calls == ["gpu"]
    assert result.provider_ids == ("provider.gpu",)
    assert len(result.compute_allocations) == 1
    assert result.compute_allocations[0].provider_id == "provider.gpu"


def test_gcm_allocation_rejection_executes_no_provider(tmp_path) -> None:
    calls: list[str] = []
    runtime, _registry, _cap = make_runtime(
        tmp_path,
        RejectingAllocator(),
        lambda x: calls.append("gpu") or x * x,
        lambda x: calls.append("cpu") or x * x,
    )
    with pytest.raises(GCMAllocationRejectedError):
        runtime.solve(TaskContract("task.reject", "square", "number", "number", 5))
    assert calls == []


def test_selected_provider_failure_does_not_bypass_gcm_with_unallocated_failover(tmp_path) -> None:
    calls: list[str] = []

    def gpu(_x):
        calls.append("gpu")
        raise RuntimeError("gpu failed")

    runtime, registry, _cap = make_runtime(
        tmp_path,
        FakeAllocator("provider.gpu"),
        gpu,
        lambda x: calls.append("cpu") or x * x,
    )
    with pytest.raises(RuntimeError, match="all eligible providers failed"):
        runtime.solve(TaskContract("task.fail", "square", "number", "number", 5))

    assert calls == ["gpu"]
    assert registry.get_provider("provider.gpu").health is ProviderHealth.UNAVAILABLE
    assert registry.get_provider("provider.cpu").health is ProviderHealth.HEALTHY


def test_no_compute_allocator_preserves_v07_provider_failover(tmp_path) -> None:
    calls: list[str] = []
    runtime, registry, cap = make_runtime(
        tmp_path,
        None,
        lambda x: calls.append("gpu") or x * x,
        lambda x: calls.append("cpu") or x * x,
    )
    # Existing declared order is CPU then GPU when no compute allocator is configured.
    result = runtime.solve(TaskContract("task.no-gcm", "square", "number", "number", 4))
    assert result.value == 16
    assert calls == ["cpu"]
    assert result.compute_allocations == ()
    assert registry.get_capability(cap.capability_id).trust_state is TrustState.TRUSTED
