from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.acquisition import AcquisitionMemoryKind
from mhcr.constructor import TemplateConstructor, TemplateSpec
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.verification import VerifierRegistry


def test_constructed_solver_and_verifier_memory_are_reused_on_unseen_payload(tmp_path):
    constructor = TemplateConstructor([
        TemplateSpec(
            task_family="square",
            input_type="number",
            output_type="number",
            execute=lambda x: x * x,
            verifier_id="verify.square",
        )
    ])
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(
        registry, verifiers, GCAL(), EventLog(tmp_path / "events.jsonl"), constructor=constructor
    )

    first = runtime.solve(TaskContract("task.square.1", "square", "number", "number", 4))
    probe = TaskContract("probe", "square", "number", "number", 9)
    solver_mem = runtime.acquisition_memory.find(AcquisitionMemoryKind.SOLVER, probe)
    verifier_mem = runtime.acquisition_memory.find(AcquisitionMemoryKind.VERIFICATION, probe)
    assert first.source == "constructed"
    assert len(solver_mem) == 1
    assert len(verifier_mem) == 1
    assert solver_mem[0].subject_id == "cap.generated.square"

    second = runtime.solve(TaskContract("task.square.2", "square", "number", "number", 9))
    assert second.source == "resolved"
    assert second.cache_hit is False
    assert second.acquisition_trace is not None
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.SOLVER) == 1
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.VERIFICATION) == 1
    assert constructor.construct_count == 1


def _primitive(capability_id, family, input_type, output_type, provider_id, verifier_id=None):
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type=input_type,
        output_type=output_type,
        exactness="exact",
        provider_ids=(provider_id,),
        verifier_id=verifier_id,
        trust_state=TrustState.TRUSTED,
    )


def test_composition_solver_verification_memory_survives_restart_and_reuses(tmp_path):
    db = tmp_path / "mhcr.sqlite3"
    events = tmp_path / "events.jsonl"
    repo = SQLiteRepository(db)
    history = EventLog(events)
    registry = CapabilityRegistry(repository=repo, event_log=history)
    parse = _primitive("cap.parse", "parse", "text", "numbers", "provider.parse")
    total = _primitive("cap.total", "total", "numbers", "number", "provider.total", "verify.pipeline")
    for capability in (parse, total):
        registry.register_capability(capability)
    registry.register_provider(Provider("provider.parse", parse.capability_id, lambda text: [int(x) for x in text.split(",")]))
    registry.register_provider(Provider("provider.total", total.capability_id, sum))
    gcal = GCAL(repository=repo)
    gcal.register_cost(CostRecord("provider.parse", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.total", CostVector(local_work=1.0)))
    verifiers = VerifierRegistry()
    verifiers.register("verify.pipeline", lambda task, result: result == sum(int(x) for x in task.payload.split(",")))
    runtime = MHCRRuntime(registry, verifiers, gcal, history)

    first = runtime.solve(TaskContract("task.pipe.1", "pipeline", "text", "number", "1,2,3"))
    composite_id = next(cap.capability_id for cap in registry.capabilities() if cap.is_composite)
    repo.close()

    reopened = SQLiteRepository(db)
    restored_registry = CapabilityRegistry.from_repository(
        reopened,
        provider_executors={
            "provider.parse": lambda text: [int(x) for x in text.split(",")],
            "provider.total": sum,
        },
        event_log=history,
    )
    restored_gcal = GCAL(repository=reopened)
    restored_verifiers = VerifierRegistry()
    restored_verifiers.register(
        "verify.pipeline", lambda task, result: result == sum(int(x) for x in task.payload.split(","))
    )
    restored_runtime = MHCRRuntime(restored_registry, restored_verifiers, restored_gcal, history)

    second = restored_runtime.solve(TaskContract("task.pipe.2", "pipeline", "text", "number", "9,10"))
    assert first.source == "composed"
    assert second.source == "resolved"
    assert second.capability_ids == (composite_id,)
    assert second.cache_hit is False
    assert second.acquisition_trace is not None
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.COMPOSITION) == 1
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.SOLVER) == 1
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.VERIFICATION) == 1
    reopened.close()


def test_revocation_immediately_invalidates_solver_and_verification_memory(tmp_path):
    constructor = TemplateConstructor([
        TemplateSpec(
            task_family="square",
            input_type="number",
            output_type="number",
            execute=lambda x: x * x,
            verifier_id="verify.square",
        )
    ])
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(
        registry, verifiers, GCAL(), EventLog(tmp_path / "events.jsonl"), constructor=constructor
    )
    runtime.solve(TaskContract("task.square.1", "square", "number", "number", 4))
    probe = TaskContract("probe", "square", "number", "number", 9)

    registry.revoke("cap.generated.square")

    solver = runtime.acquisition_memory.find(AcquisitionMemoryKind.SOLVER, probe, active_only=False)[0]
    verification = runtime.acquisition_memory.find(AcquisitionMemoryKind.VERIFICATION, probe, active_only=False)[0]
    assert solver.active is False
    assert verification.active is False
    assert "revoked" in (solver.invalidation_reason or "")
