import pytest

from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.acquisition import AcquisitionMemoryKind
from mhcr.constructor import TemplateConstructor, TemplateSpec
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def test_failed_deterministic_constructor_path_is_not_retried_for_unseen_payload(tmp_path):
    constructor = TemplateConstructor([
        TemplateSpec(
            task_family="square",
            input_type="number",
            output_type="number",
            execute=lambda x: x * x + 1,
            verifier_id="verify.square",
        )
    ])
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(
        registry,
        verifiers,
        GCAL(),
        EventLog(tmp_path / "events.jsonl"),
        constructor=constructor,
    )

    with pytest.raises(RuntimeError, match="verification failed"):
        runtime.solve(TaskContract("task.bad.1", "square", "number", "number", 4))
    assert constructor.construct_count == 1
    failures = runtime.acquisition_memory.find(
        AcquisitionMemoryKind.FAILURE,
        TaskContract("probe", "square", "number", "number", 9),
    )
    assert len(failures) == 1

    with pytest.raises(LookupError, match="known failed acquisition path"):
        runtime.solve(TaskContract("task.bad.2", "square", "number", "number", 9))

    assert constructor.construct_count == 1
    assert runtime.acquisition_memory.get(failures[0].memory_id).reuse_count == 1


def test_composition_records_representation_and_unseen_fast_reuse_marks_hit(tmp_path):
    registry = CapabilityRegistry()
    parse = Capability(
        "cap.parse", "1.0.0", "parse", "text", "numbers", "exact",
        ("provider.parse",), None, TrustState.TRUSTED,
    )
    total = Capability(
        "cap.total", "1.0.0", "total", "numbers", "number", "exact",
        ("provider.total",), "verify.pipeline", TrustState.TRUSTED,
    )
    for capability in (parse, total):
        registry.register_capability(capability)
    registry.register_provider(Provider("provider.parse", "cap.parse", lambda text: [int(x) for x in text.split(",")]))
    registry.register_provider(Provider("provider.total", "cap.total", sum))
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.parse", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.total", CostVector(local_work=1.0)))
    verifiers = VerifierRegistry()
    verifiers.register("verify.pipeline", lambda task, result: result == sum(int(x) for x in task.payload.split(",")))
    runtime = MHCRRuntime(registry, verifiers, gcal, EventLog(tmp_path / "events.jsonl"))

    first = runtime.solve(TaskContract("task.rep.1", "pipeline", "text", "number", "1,2,3"))
    representation = runtime.acquisition_memory.find(
        AcquisitionMemoryKind.REPRESENTATION,
        TaskContract("probe", "pipeline", "text", "number", "9,10"),
    )
    assert first.source == "composed"
    assert len(representation) == 1
    assert representation[0].metadata["type_path"] == ["text", "numbers", "number"]

    second = runtime.solve(TaskContract("task.rep.2", "pipeline", "text", "number", "9,10"))
    assert second.source == "resolved"
    assert second.cache_hit is False
    assert second.acquisition_trace is not None
    assert second.acquisition_trace.memory_hit_count(AcquisitionMemoryKind.REPRESENTATION) == 1
    assert runtime.acquisition_memory.get(representation[0].memory_id).reuse_count == 1
