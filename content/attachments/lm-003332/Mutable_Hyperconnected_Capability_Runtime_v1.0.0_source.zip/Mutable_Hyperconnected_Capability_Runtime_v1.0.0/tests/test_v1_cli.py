import json
import subprocess
import sys


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "mhcr.cli", *args],
        check=False,
        capture_output=True,
        text=True,
    )


def test_cli_help_exposes_v1_commands():
    completed = run_cli("--help")
    assert completed.returncode == 0
    for command in ("conformance", "failure-matrix", "longrun", "acceptance", "demo"):
        assert command in completed.stdout


def test_cli_explicit_missing_gcm_profile_returns_machine_readable_not_available():
    completed = run_cli("conformance", "--profile", "MHCR-GCM-R1")
    assert completed.returncode == 3
    payload = json.loads(completed.stdout)
    assert payload["profile_id"] == "MHCR-GCM-R1"
    assert payload["claim"] == "not_available"
