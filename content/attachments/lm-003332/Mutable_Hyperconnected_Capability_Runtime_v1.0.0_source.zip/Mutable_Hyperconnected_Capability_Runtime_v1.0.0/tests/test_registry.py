import pytest

from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry


def make_capability(state=TrustState.CANDIDATE):
    return Capability(
        capability_id="cap.graph.shortest_path",
        version="1.0.0",
        task_family="shortest_path",
        input_type="weighted_graph",
        output_type="path_result",
        exactness="exact",
        provider_ids=("provider.dijkstra",),
        verifier_id="verify.shortest_path",
        trust_state=state,
    )


def test_candidate_is_not_returned_by_trusted_resolution():
    registry = CapabilityRegistry()
    registry.register_capability(make_capability(TrustState.CANDIDATE))

    results = registry.find_trusted(
        task_family="shortest_path",
        input_type="weighted_graph",
        output_type="path_result",
        exactness="exact",
    )

    assert results == []


def test_trusted_capability_is_resolved_by_semantics():
    registry = CapabilityRegistry()
    capability = make_capability(TrustState.TRUSTED)
    registry.register_capability(capability)

    results = registry.find_trusted(
        task_family="shortest_path",
        input_type="weighted_graph",
        output_type="path_result",
        exactness="exact",
    )

    assert [c.address for c in results] == ["cap.graph.shortest_path@1"]


def test_provider_identity_is_separate_from_capability_identity():
    registry = CapabilityRegistry()
    capability = make_capability(TrustState.TRUSTED)
    registry.register_capability(capability)
    provider = Provider(
        provider_id="provider.dijkstra",
        capability_id=capability.capability_id,
        execute=lambda value: value,
    )
    registry.register_provider(provider)

    assert registry.get_capability(capability.capability_id).capability_id == capability.capability_id
    assert registry.get_provider("provider.dijkstra").provider_id == "provider.dijkstra"
    assert registry.get_provider("provider.dijkstra").provider_id != capability.capability_id


def test_revoked_capability_is_not_resolved():
    registry = CapabilityRegistry()
    capability = make_capability(TrustState.TRUSTED)
    registry.register_capability(capability)
    registry.revoke(capability.capability_id)

    assert registry.get_capability(capability.capability_id).trust_state is TrustState.REVOKED
    assert registry.find_trusted(
        task_family="shortest_path",
        input_type="weighted_graph",
        output_type="path_result",
        exactness="exact",
    ) == []


def test_task_contract_keeps_payload_separate_from_semantic_identity():
    task = TaskContract(
        task_id="task-1",
        family="shortest_path",
        input_type="weighted_graph",
        output_type="path_result",
        payload={"graph": "g1"},
        exactness="exact",
    )
    assert task.family == "shortest_path"
    assert task.payload == {"graph": "g1"}


def test_revoked_capability_cannot_be_silently_reintroduced_as_candidate():
    registry = CapabilityRegistry()
    trusted = make_capability(TrustState.TRUSTED)
    registry.register_capability(trusted)
    registry.revoke(trusted.capability_id)

    with pytest.raises(ValueError, match="revoked capability cannot be overwritten"):
        registry.register_capability(make_capability(TrustState.CANDIDATE))


def test_provider_id_cannot_be_rebound_to_different_capability():
    registry = CapabilityRegistry()
    first = make_capability(TrustState.TRUSTED)
    second = Capability(
        capability_id="cap.graph.other",
        version="1.0.0",
        task_family="other",
        input_type="weighted_graph",
        output_type="path_result",
        exactness="exact",
        provider_ids=("provider.dijkstra",),
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(first)
    registry.register_capability(second)
    registry.register_provider(Provider("provider.dijkstra", first.capability_id, lambda value: value))

    with pytest.raises(ValueError, match="provider id already bound"):
        registry.register_provider(Provider("provider.dijkstra", second.capability_id, lambda value: value))
