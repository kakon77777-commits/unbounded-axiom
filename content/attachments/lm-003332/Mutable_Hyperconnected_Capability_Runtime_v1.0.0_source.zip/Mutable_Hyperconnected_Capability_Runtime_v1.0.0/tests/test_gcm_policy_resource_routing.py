from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("gcm_runtime")

from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.gcm_integration import (
    GCMAllocationRejectedError,
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.history import EventLog
from mhcr.models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderKind,
    RoutingPreference,
    TaskContract,
    TaskPolicy,
    TrustState,
)
from mhcr.registry import CapabilityRegistry
from mhcr.routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile
from mhcr.runtime import MHCRRuntime
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.verification import VerifierRegistry


def binding(provider_id: str, *, resource_id: str, kind: str, locality: str, capacity: int = 16):
    return GCMProviderBinding(
        binding_id=f"binding:{provider_id}",
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=f"cfg:{provider_id}",
        executor_id=provider_id,
        resource_kind=kind,
        capabilities=("square",),
        locality=locality,
        dimensions=(GCMCapacityBinding("slots", "logical-unit", capacity, 8),),
    )


def make_runtime(tmp_path: Path, local_profile: ProviderCostProfile, remote_profile: ProviderCostProfile):
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    gcal = GCAL()
    history = EventLog(tmp_path / "history.jsonl")
    cap = Capability(
        "cap.square", "1.0.0", "square", "number", "number", "exact",
        ("provider.local", "provider.remote"), verifier_id="verify.square",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(cap)
    registry.register_provider(
        Provider("provider.local", cap.capability_id, lambda x: x*x, kind=ProviderKind.LOCAL_PYTHON)
    )
    registry.register_provider(
        Provider(
            "provider.remote", cap.capability_id, lambda x: x*x,
            kind=ProviderKind.REMOTE_API, boundary=ProviderBoundary.NETWORK,
        )
    )
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    gcal.register_cost(CostRecord("provider.local", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.remote", CostVector(external_work=1.0, monetary_cost=0.01)))
    catalog = ProviderCostCatalog()
    catalog.upsert(local_profile, persist=False)
    catalog.upsert(remote_profile, persist=False)
    store = GCMResourceBindingStore()
    store.upsert(binding("provider.local", resource_id="resource.cpu", kind="cpu", locality="local"))
    store.upsert(binding("provider.remote", resource_id="resource.remote", kind="remote_api", locality="remote"))
    adapter = GCMPhaseBAdapter(store, cost_catalog=catalog, event_log=history)
    runtime = MHCRRuntime(
        registry, verifiers, gcal, history,
        cost_catalog=catalog, compute_allocator=adapter,
    )
    return runtime, history


def profile(provider_id: str, *, latency: float, money: float) -> ProviderCostProfile:
    return ProviderCostProfile(
        provider_id,
        latency_ms=CostMetric(latency, CostEvidence.DECLARED),
        monetary_cost_usd=CostMetric(money, CostEvidence.DECLARED),
    )


def test_local_faster_policy_flows_through_gcm_and_selects_local(tmp_path: Path) -> None:
    runtime, history = make_runtime(
        tmp_path,
        profile("provider.local", latency=1.0, money=0.20),
        profile("provider.remote", latency=10.0, money=0.01),
    )
    result = runtime.solve(
        TaskContract(
            "task.fast-local", "square", "number", "number", 6,
            policy=TaskPolicy(prefer=(RoutingPreference.LATENCY,)),
        )
    )
    assert result.compute_allocations[0].provider_id == "provider.local"
    assert result.value == 36
    assert history.replay_counts()["GCM_ALLOCATION_SELECTED"] == 1


def test_external_cheaper_policy_flows_through_gcm_and_selects_remote(tmp_path: Path) -> None:
    runtime, _history = make_runtime(
        tmp_path,
        profile("provider.local", latency=1.0, money=0.20),
        profile("provider.remote", latency=10.0, money=0.01),
    )
    result = runtime.solve(
        TaskContract(
            "task.cheap-remote", "square", "number", "number", 7,
            policy=TaskPolicy(prefer=(RoutingPreference.MONETARY_COST,)),
        )
    )
    assert result.compute_allocations[0].provider_id == "provider.remote"
    assert result.value == 49


def test_gcm_b1_missing_hard_limit_evidence_fails_closed_before_execution() -> None:
    store = GCMResourceBindingStore()
    store.upsert(binding("provider.unknown", resource_id="resource.unknown", kind="cpu", locality="local"))
    adapter = GCMPhaseBAdapter(store, cost_catalog=ProviderCostCatalog())
    cap = Capability(
        "cap.square", "1.0.0", "square", "number", "number", "exact",
        ("provider.unknown",), trust_state=TrustState.TRUSTED,
    )
    task = TaskContract(
        "task.limit", "square", "number", "number", 8,
        policy=TaskPolicy(max_latency_ms=5.0),
    )
    with pytest.raises(GCMAllocationRejectedError) as exc:
        adapter.allocate(task, cap, ("provider.unknown",))
    assert any(
        "missing estimate: latency_ms" in reason
        for failure in exc.value.failures
        for reason in failure.get("reasons", [])
    )


def test_gcm_bindings_survive_sqlite_restart_and_repeat_semantic_allocation(tmp_path: Path) -> None:
    db = tmp_path / "mhcr.db"
    repo = SQLiteRepository(db)
    store = GCMResourceBindingStore(repository=repo)
    store.upsert(binding("provider.local", resource_id="resource.cpu", kind="cpu", locality="local"))
    repo.close()

    reopened = SQLiteRepository(db)
    restored = GCMResourceBindingStore(repository=reopened)
    adapter = GCMPhaseBAdapter(restored)
    cap = Capability(
        "cap.square", "1.0.0", "square", "number", "number", "exact",
        ("provider.local",), trust_state=TrustState.TRUSTED,
    )
    first = adapter.allocate(TaskContract("task.restart", "square", "number", "number", 2), cap, ("provider.local",))
    assert first.provider_id == "provider.local"
    assert first.resource_id == "resource.cpu"
    reopened.close()
