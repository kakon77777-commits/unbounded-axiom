import sqlite3

from mhcr.models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderHealth,
    ProviderKind,
    TrustState,
)
from mhcr.repository import ProviderRecord
from mhcr.sqlite_repository import SQLiteRepository


def trusted_capability() -> Capability:
    return Capability(
        capability_id="cap.echo",
        version="1.0.0",
        task_family="echo",
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=("provider.remote.echo",),
        trust_state=TrustState.TRUSTED,
    )


def test_provider_metadata_round_trips_without_executor(tmp_path):
    repo = SQLiteRepository(tmp_path / "registry.db")
    repo.save_capability(trusted_capability())
    repo.save_provider(
        ProviderRecord(
            provider_id="provider.remote.echo",
            capability_id="cap.echo",
            active=True,
            kind=ProviderKind.REMOTE_API,
            health=ProviderHealth.DEGRADED,
            boundary=ProviderBoundary.NETWORK,
            endpoint="https://example.invalid/echo",
        )
    )
    repo.close()

    reopened = SQLiteRepository(tmp_path / "registry.db")
    assert reopened.schema_version == 8
    assert reopened.load_provider_records() == (
        ProviderRecord(
            provider_id="provider.remote.echo",
            capability_id="cap.echo",
            active=True,
            kind=ProviderKind.REMOTE_API,
            health=ProviderHealth.DEGRADED,
            boundary=ProviderBoundary.NETWORK,
            endpoint="https://example.invalid/echo",
        ),
    )
    reopened.close()


def test_sqlite_v1_database_migrates_provider_defaults_through_v3(tmp_path):
    path = tmp_path / "legacy.db"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        INSERT INTO metadata(key, value) VALUES('schema_version', '1');
        CREATE TABLE capabilities (
            capability_id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            task_family TEXT NOT NULL,
            input_type TEXT NOT NULL,
            output_type TEXT NOT NULL,
            exactness TEXT NOT NULL,
            provider_ids_json TEXT NOT NULL,
            verifier_id TEXT,
            trust_state TEXT NOT NULL,
            scope TEXT NOT NULL
        );
        CREATE TABLE providers (
            provider_id TEXT PRIMARY KEY,
            capability_id TEXT NOT NULL,
            active INTEGER NOT NULL
        );
        CREATE TABLE cost_records (
            node_id TEXT PRIMARY KEY,
            local_work REAL NOT NULL,
            external_work REAL NOT NULL,
            offline_work REAL NOT NULL,
            verification_work REAL NOT NULL,
            monetary_cost REAL NOT NULL,
            known INTEGER NOT NULL,
            shared_cost_id TEXT
        );
        INSERT INTO providers(provider_id, capability_id, active)
        VALUES('provider.local.echo', 'cap.echo', 1);
        """
    )
    connection.commit()
    connection.close()

    repo = SQLiteRepository(path)
    assert repo.schema_version == 8
    assert repo.load_provider_records() == (
        ProviderRecord(
            "provider.local.echo",
            "cap.echo",
            active=True,
            kind=ProviderKind.LOCAL_PYTHON,
            health=ProviderHealth.HEALTHY,
            boundary=ProviderBoundary.LOCAL,
            endpoint=None,
        ),
    )
    repo.close()


def test_provider_runtime_object_keeps_semantic_metadata():
    provider = Provider(
        "provider.remote.echo",
        "cap.echo",
        lambda value: value,
        kind=ProviderKind.REMOTE_API,
        health=ProviderHealth.HEALTHY,
        boundary=ProviderBoundary.NETWORK,
        endpoint="https://example.invalid/echo",
    )
    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.health is ProviderHealth.HEALTHY
    assert provider.boundary is ProviderBoundary.NETWORK
    assert provider.endpoint.endswith("/echo")


def test_registry_restore_preserves_provider_metadata_with_explicit_binding(tmp_path):
    from mhcr.registry import CapabilityRegistry

    path = tmp_path / "registry.db"
    repo = SQLiteRepository(path)
    registry = CapabilityRegistry(repository=repo)
    registry.register_capability(trusted_capability())
    registry.register_provider(
        Provider(
            "provider.remote.echo",
            "cap.echo",
            lambda value: value,
            kind=ProviderKind.REMOTE_API,
            health=ProviderHealth.DEGRADED,
            boundary=ProviderBoundary.NETWORK,
            endpoint="https://example.invalid/echo",
        )
    )
    repo.close()

    reopened = SQLiteRepository(path)
    restored = CapabilityRegistry.from_repository(
        reopened,
        provider_executors={"provider.remote.echo": lambda value: value},
    )
    provider = restored.get_provider("provider.remote.echo")
    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.health is ProviderHealth.DEGRADED
    assert provider.boundary is ProviderBoundary.NETWORK
    assert provider.endpoint == "https://example.invalid/echo"
    reopened.close()


def test_registry_event_replay_preserves_provider_metadata(tmp_path):
    from mhcr.history import EventLog
    from mhcr.registry import CapabilityRegistry

    log = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=log)
    registry.register_capability(trusted_capability())
    registry.register_provider(
        Provider(
            "provider.remote.echo",
            "cap.echo",
            lambda value: value,
            kind=ProviderKind.REMOTE_API,
            health=ProviderHealth.DEGRADED,
            boundary=ProviderBoundary.NETWORK,
            endpoint="https://example.invalid/echo",
        )
    )

    replayed = log.replay_registry(
        provider_executors={"provider.remote.echo": lambda value: value}
    )
    provider = replayed.get_provider("provider.remote.echo")
    assert provider.kind is ProviderKind.REMOTE_API
    assert provider.health is ProviderHealth.DEGRADED
    assert provider.boundary is ProviderBoundary.NETWORK
    assert provider.endpoint == "https://example.invalid/echo"
