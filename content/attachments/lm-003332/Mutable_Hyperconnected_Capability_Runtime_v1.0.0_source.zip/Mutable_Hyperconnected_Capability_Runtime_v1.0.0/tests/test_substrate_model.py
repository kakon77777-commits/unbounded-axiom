from __future__ import annotations

import pytest

from mhcr.models import SubstratePolicy, TaskContract
from mhcr.routing import CostEvidence, CostMetric
from mhcr.substrate import (
    ComputationalMorphologyProfile,
    PCMTProfile,
    SubstrateKind,
    SubstrateProfile,
    SubstrateRealization,
    TransitionLawClass,
)


def phase_profile() -> SubstrateProfile:
    return SubstrateProfile(
        profile_id="substrate.phase.sim.v1",
        kind=SubstrateKind.PHASE,
        realization=SubstrateRealization.SIMULATED,
        gcm_resource_kind="other",
        features=("phase_graph", "oscillation"),
        transition_laws=(TransitionLawClass.DETERMINISTIC,),
        supports_exact=True,
        energy_units=CostMetric(7.5, CostEvidence.ESTIMATED),
        switching_cost_units=CostMetric(2.0, CostEvidence.DECLARED),
        pcmt=PCMTProfile(
            phase_ontology="relational",
            phase_representation="complex-state",
            architecture="von-neumann-simulated",
            dynamics="coupled-update",
            coupling="explicit",
            memory="persistent-state",
            output="typed-result",
        ),
        morphology=ComputationalMorphologyProfile(
            bottom_space="digital",
            update_organization="coupled",
            observation_mode="explicit",
            transition_law=TransitionLawClass.DETERMINISTIC,
        ),
        fallback_profile_ids=("substrate.cpu.native.v1",),
        metadata={"evidence": "reference-simulation"},
    )


def test_substrate_profile_round_trip_preserves_extensions_and_cost_evidence():
    profile = phase_profile()
    restored = SubstrateProfile.from_dict(profile.as_dict())
    assert restored == profile
    assert restored.energy_units.evidence is CostEvidence.ESTIMATED
    assert restored.pcmt is not None
    assert restored.pcmt.architecture == "von-neumann-simulated"
    assert restored.morphology is not None
    assert restored.morphology.transition_law is TransitionLawClass.DETERMINISTIC


def test_unknown_substrate_metric_cannot_carry_zero():
    with pytest.raises(ValueError, match="UNKNOWN"):
        SubstrateProfile(
            profile_id="substrate.bad",
            kind=SubstrateKind.QUANTUM,
            realization=SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            energy_units=CostMetric(0.0, CostEvidence.UNKNOWN),
        )


def test_substrate_policy_default_is_inert_on_task_contract():
    task = TaskContract("t", "f", "number", "number", 3)
    assert task.substrate_policy == SubstratePolicy()
    assert task.substrate_policy.is_default


def test_substrate_policy_rejects_negative_hard_limits():
    with pytest.raises(ValueError, match="max_energy_units"):
        SubstratePolicy(max_energy_units=-1)


def test_substrate_policy_preserves_preference_order_but_deduplicates():
    policy = SubstratePolicy(
        preferred_kinds=("phase", "event_driven", "phase"),
        required_features=("stream", "stream", "event"),
    )
    assert policy.preferred_kinds == ("phase", "event_driven")
    assert policy.required_features == ("event", "stream")
