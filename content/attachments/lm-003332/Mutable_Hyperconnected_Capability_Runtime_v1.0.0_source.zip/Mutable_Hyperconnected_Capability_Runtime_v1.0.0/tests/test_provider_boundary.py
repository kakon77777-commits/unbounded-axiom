from __future__ import annotations

import sys

from mhcr.accounting import AccountingStatus, CostRecord, CostVector, GCAL
from mhcr.history import EventLog
from mhcr.models import Capability, ProviderBoundary, ProviderKind, TaskContract, TrustState
from mhcr.provider_adapters import SubprocessJsonAdapter, provider_from_adapter
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def trusted_capability(provider_id: str, family: str = "double") -> Capability:
    return Capability(
        capability_id=f"cap.{family}",
        version="1.0.0",
        task_family=family,
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=(provider_id,),
        verifier_id="verify.double",
        trust_state=TrustState.TRUSTED,
    )


def verifier_registry() -> VerifierRegistry:
    verifiers = VerifierRegistry()
    verifiers.register("verify.double", lambda task, value: value == task.payload * 2)
    return verifiers


def test_network_provider_emits_boundary_event_and_unknown_cost_is_not_zero(tmp_path):
    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = trusted_capability("provider.remote.double")
    registry.register_capability(capability)
    registry.register_provider(
        provider_from_adapter(
            "provider.remote.double",
            capability.capability_id,
            type(
                "RemoteAdapter",
                (),
                {
                    "kind": ProviderKind.REMOTE_API,
                    "boundary": ProviderBoundary.NETWORK,
                    "endpoint": "https://example.invalid/double",
                    "execute": staticmethod(lambda value: value * 2),
                },
            )(),
        )
    )
    runtime = MHCRRuntime(registry, verifier_registry(), GCAL(), history)

    result = runtime.solve(TaskContract("task.remote", "double", "int", "int", 8))

    assert result.value == 16
    assert result.accounting.status is AccountingStatus.ACCOUNTING_INCOMPLETE
    assert "provider.remote.double" in result.accounting.unknown_nodes
    boundary_events = [
        event for event in history.read_all()
        if event.event_type == "PROVIDER_BOUNDARY_CROSSED"
    ]
    assert len(boundary_events) == 1
    assert boundary_events[0].data["provider_id"] == "provider.remote.double"
    assert boundary_events[0].data["provider_kind"] == "remote_api"
    assert boundary_events[0].data["boundary"] == "network"


def test_real_subprocess_provider_emits_process_boundary_event(tmp_path):
    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = trusted_capability("provider.process.double")
    registry.register_capability(capability)
    adapter = SubprocessJsonAdapter(
        (
            sys.executable,
            "-c",
            "import json,sys; value=json.load(sys.stdin); json.dump(value*2, sys.stdout)",
        ),
        timeout=2.0,
    )
    registry.register_provider(
        provider_from_adapter("provider.process.double", capability.capability_id, adapter)
    )
    gcal = GCAL()
    gcal.register_cost(
        CostRecord("provider.process.double", CostVector(external_work=1.0), known=True)
    )
    runtime = MHCRRuntime(registry, verifier_registry(), gcal, history)

    result = runtime.solve(TaskContract("task.process", "double", "int", "int", 11))

    assert result.value == 22
    assert result.accounting.status is AccountingStatus.CLOSED_ACCOUNTED
    boundary_events = [
        event for event in history.read_all()
        if event.event_type == "PROVIDER_BOUNDARY_CROSSED"
    ]
    assert len(boundary_events) == 1
    assert boundary_events[0].data["boundary"] == "process"
    assert boundary_events[0].data["provider_kind"] == "subprocess"


def test_local_provider_does_not_emit_boundary_crossing(tmp_path):
    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = trusted_capability("provider.local.double")
    registry.register_capability(capability)
    from mhcr.provider_adapters import LocalPythonAdapter

    registry.register_provider(
        provider_from_adapter(
            "provider.local.double", capability.capability_id, LocalPythonAdapter(lambda value: value * 2)
        )
    )
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.local.double", CostVector(local_work=1.0), known=True))
    runtime = MHCRRuntime(registry, verifier_registry(), gcal, history)

    runtime.solve(TaskContract("task.local", "double", "int", "int", 3))

    assert not any(
        event.event_type == "PROVIDER_BOUNDARY_CROSSED"
        for event in history.read_all()
    )


def test_failed_remote_attempt_remains_in_closed_accounting_after_local_failover(tmp_path):
    from mhcr.models import Provider, ProviderHealth

    history = EventLog(tmp_path / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = Capability(
        capability_id="cap.double.failover",
        version="1.0.0",
        task_family="double-failover",
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=("provider.remote.bad", "provider.local.good"),
        verifier_id="verify.double.failover",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(capability)

    def remote_failure(_value):
        raise RuntimeError("remote failed")

    registry.register_provider(
        Provider(
            "provider.remote.bad",
            capability.capability_id,
            remote_failure,
            kind=ProviderKind.REMOTE_API,
            boundary=ProviderBoundary.NETWORK,
        )
    )
    registry.register_provider(
        Provider("provider.local.good", capability.capability_id, lambda value: value * 2)
    )
    verifiers = VerifierRegistry()
    verifiers.register("verify.double.failover", lambda task, value: value == task.payload * 2)
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.local.good", CostVector(local_work=1.0), known=True))
    runtime = MHCRRuntime(registry, verifiers, gcal, history)

    result = runtime.solve(
        TaskContract("task.failover", "double-failover", "int", "int", 5)
    )

    assert result.value == 10
    assert result.accounting.status is AccountingStatus.ACCOUNTING_INCOMPLETE
    assert "provider.remote.bad" in result.accounting.closure
    assert "provider.remote.bad" in result.accounting.unknown_nodes
    assert "provider.local.good" in result.accounting.closure
    assert registry.get_provider("provider.remote.bad").health is ProviderHealth.UNAVAILABLE
