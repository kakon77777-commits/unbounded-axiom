from mhcr.longrun import run_longrun


def test_v1_longrun_32_unseen_tasks_survive_three_restarts_without_answer_cache():
    result = run_longrun(payload_count=32, restart_interval=8)
    assert result.passed is True
    assert result.payload_count == 32
    assert result.restart_count == 3
    assert result.stateless_constructor_invocations == 32
    assert result.persistent_constructor_invocations == 1
    assert result.persistent_fast_after_first is True
    assert result.all_cache_hits_false is True
    assert result.final_trust_state == "trusted"
    assert result.schema_version == 8


def test_v1_longrun_persistent_acquisition_is_lower_and_memory_survives_restart():
    result = run_longrun(payload_count=32, restart_interval=8)
    assert result.persistent_total_work < result.stateless_total_work
    assert result.persistent_post_first_mean_work < result.stateless_post_first_mean_work
    assert result.work_reduction_ratio > 3.0
    assert result.solver_memory_reuse_count >= 31
    assert result.verification_memory_reuse_count >= 31
    assert result.resolver_speedup_ratio > 1.0
