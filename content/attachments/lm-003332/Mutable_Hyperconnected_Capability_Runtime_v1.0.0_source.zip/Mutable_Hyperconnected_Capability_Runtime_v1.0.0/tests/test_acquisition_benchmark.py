from mhcr.acquisition import AcquisitionMemoryKind
from mhcr.acquisition_benchmark import benchmark_acquisition_learning


def test_persistent_runtime_reduces_acquisition_work_on_unseen_payloads_without_cache():
    result = benchmark_acquisition_learning((2, 3, 5, 7))

    assert [sample.payload for sample in result.stateless_samples] == [2, 3, 5, 7]
    assert [sample.source for sample in result.stateless_samples] == ["constructed"] * 4
    assert result.persistent_samples[0].source == "constructed"
    assert [sample.source for sample in result.persistent_samples[1:]] == ["resolved"] * 3
    assert [sample.execution_path for sample in result.persistent_samples[1:]] == ["fast"] * 3
    assert all(sample.cache_hit is False for sample in result.stateless_samples)
    assert all(sample.cache_hit is False for sample in result.persistent_samples)

    assert result.persistent_total_work < result.stateless_total_work
    assert result.persistent_post_first_mean_work < result.stateless_post_first_mean_work
    assert result.work_reduction_ratio > 1.0
    assert result.persistent_constructor_invocations == 1
    assert result.stateless_constructor_invocations == 4
    assert result.persistent_memory_hits[AcquisitionMemoryKind.SOLVER.value] >= 3
    assert result.persistent_memory_hits[AcquisitionMemoryKind.VERIFICATION.value] >= 3
