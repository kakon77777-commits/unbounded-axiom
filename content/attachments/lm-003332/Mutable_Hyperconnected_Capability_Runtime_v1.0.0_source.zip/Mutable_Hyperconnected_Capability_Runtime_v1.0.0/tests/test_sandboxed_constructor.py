from dataclasses import fields

import pytest

from mhcr.accounting import GCAL
from mhcr.acquisition import AcquisitionMemoryKind
from mhcr.constructor import (
    CandidateConstructionError,
    GeneratedSourceSpec,
    SandboxedSourceConstructor,
)
from mhcr.history import EventLog
from mhcr.models import ProviderBoundary, ProviderKind, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.sandbox import (
    CandidateArtifactStatus,
    GeneratedArtifactStore,
    PythonSandboxRunner,
    SandboxPolicy,
    load_sandbox_provider_bindings,
)
from mhcr.sqlite_repository import SQLiteRepository
from mhcr.verification import VerifierRegistry


def make_constructor(tmp_path, generator, *, repo=None, history=None, policy=None):
    history = history or EventLog(tmp_path / "events.jsonl")
    store = GeneratedArtifactStore(repository=repo, event_log=history)
    runner = PythonSandboxRunner(policy=policy or SandboxPolicy(timeout_seconds=2.0))
    constructor = SandboxedSourceConstructor(
        generator,
        artifact_store=store,
        runner=runner,
        verifier_id="verify.square",
    )
    return constructor, store, runner, history


def task(task_id="task.square.1", payload=4):
    return TaskContract(task_id, "square", "number", "number", payload)


def square_generator(_task):
    return GeneratedSourceSpec("def solve(payload):\n    return payload * payload\n")


def test_generated_source_spec_does_not_offer_policy_or_authority_field():
    names = {item.name for item in fields(GeneratedSourceSpec)}
    assert "policy" not in names
    assert "authority" not in names
    with pytest.raises(TypeError):
        GeneratedSourceSpec(
            "def solve(payload): return payload",
            policy=SandboxPolicy(),  # type: ignore[call-arg]
        )


def test_constructor_alone_only_creates_sandbox_tested_candidate(tmp_path):
    constructor, store, _runner, _history = make_constructor(tmp_path, square_generator)
    bundle = constructor.construct(task())

    assert bundle.capability.trust_state is TrustState.CANDIDATE
    assert bundle.provider.kind is ProviderKind.SUBPROCESS
    assert bundle.provider.boundary is ProviderBoundary.PROCESS
    artifact = store.find_by_capability(bundle.capability.capability_id)[0]
    assert artifact.status is CandidateArtifactStatus.SANDBOX_TESTED
    assert artifact.active is True
    assert constructor.construct_count == 1


def test_runtime_verifier_promotes_generated_candidate_then_unseen_payload_reuses(tmp_path):
    constructor, store, _runner, history = make_constructor(tmp_path, square_generator)
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(registry, verifiers, GCAL(), history, constructor=constructor)

    first = runtime.solve(task("task.square.1", 4))
    second = runtime.solve(task("task.square.2", 7))

    assert first.value == 16 and first.source == "constructed"
    assert second.value == 49 and second.source == "resolved"
    assert first.cache_hit is False and second.cache_hit is False
    assert constructor.construct_count == 1
    capability = registry.get_capability("cap.generated.square")
    assert capability.trust_state is TrustState.TRUSTED
    artifact = store.find_by_capability(capability.capability_id)[0]
    assert artifact.status is CandidateArtifactStatus.PROMOTED
    assert artifact.promotion_task_id == "task.square.1"


def test_policy_rejection_persists_rejected_artifact_and_failure_memory(tmp_path):
    def bad_generator(_task):
        return GeneratedSourceSpec("import os\ndef solve(payload):\n    return payload\n")

    constructor, store, _runner, history = make_constructor(tmp_path, bad_generator)
    runtime = MHCRRuntime(
        CapabilityRegistry(), VerifierRegistry(), GCAL(), history, constructor=constructor
    )

    with pytest.raises(CandidateConstructionError, match="inspection"):
        runtime.solve(task("task.bad.1", 4))

    item = store.records()[0]
    assert item.status is CandidateArtifactStatus.REJECTED
    assert item.active is False
    failures = runtime.acquisition_memory.find(
        AcquisitionMemoryKind.FAILURE,
        task("probe", 9),
        subject_id="cap.generated.square",
    )
    assert len(failures) == 1
    with pytest.raises(KeyError):
        runtime.registry.get_capability("cap.generated.square")

    with pytest.raises(LookupError, match="known failed acquisition path"):
        runtime.solve(task("task.bad.2", 9))
    assert constructor.construct_count == 1


def test_verifier_failure_keeps_capability_candidate_and_rejects_artifact(tmp_path):
    def wrong_generator(_task):
        return GeneratedSourceSpec("def solve(payload):\n    return payload * payload + 1\n")

    constructor, store, _runner, history = make_constructor(tmp_path, wrong_generator)
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(registry, verifiers, GCAL(), history, constructor=constructor)

    with pytest.raises(RuntimeError, match="verification failed"):
        runtime.solve(task("task.wrong", 4))

    assert registry.get_capability("cap.generated.square").trust_state is TrustState.CANDIDATE
    artifact = store.records()[0]
    assert artifact.status is CandidateArtifactStatus.REJECTED
    assert "verification" in (artifact.rejection_reason or "")


def test_promoted_generated_solver_rebinds_after_restart_and_reuses_unseen_payload(tmp_path):
    db_path = tmp_path / "mhcr.sqlite3"
    event_path = tmp_path / "events.jsonl"
    repo = SQLiteRepository(db_path)
    history = EventLog(event_path)
    constructor, store, runner, _ = make_constructor(
        tmp_path, square_generator, repo=repo, history=history
    )
    registry = CapabilityRegistry(repository=repo, event_log=history)
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(registry, verifiers, GCAL(repo), history, constructor=constructor)
    first = runtime.solve(task("task.restart.1", 5))
    assert first.value == 25
    repo.close()

    reopened = SQLiteRepository(db_path)
    rebound_runner = PythonSandboxRunner(policy=SandboxPolicy(timeout_seconds=2.0))
    bindings = load_sandbox_provider_bindings(reopened, rebound_runner)
    assert set(bindings) == {"provider.generated.square"}
    restored_registry = CapabilityRegistry.from_repository(
        reopened,
        provider_executors=bindings,
        event_log=history,
    )
    restored_verifiers = VerifierRegistry()
    restored_verifiers.register(
        "verify.square", lambda task, result: result == task.payload * task.payload
    )
    restored = MHCRRuntime(restored_registry, restored_verifiers, GCAL(reopened), history)

    second = restored.solve(task("task.restart.2", 8))
    assert second.value == 64
    assert second.source == "resolved"
    assert second.execution_path == "fast"
    assert second.cache_hit is False
    persisted = reopened.load_generated_artifacts()[0]
    assert persisted.status is CandidateArtifactStatus.PROMOTED
    reopened.close()


def test_binding_helper_skips_rejected_or_policy_mismatched_artifacts(tmp_path):
    repo = SQLiteRepository(tmp_path / "mhcr.sqlite3")
    constructor, store, runner, _history = make_constructor(
        tmp_path, square_generator, repo=repo
    )
    bundle = constructor.construct(task())
    item = store.find_by_capability(bundle.capability.capability_id)[0]
    store.upsert(item.rejected("no"))
    assert load_sandbox_provider_bindings(repo, runner) == {}
    repo.close()
