from mhcr.failure_matrix import FailureCaseStatus, load_failure_manifest, run_failure_matrix


def test_v1_failure_manifest_is_exactly_f01_to_f10():
    manifest = load_failure_manifest()
    assert [case["case_id"] for case in manifest["cases"]] == [f"F{i:02d}" for i in range(1, 11)]
    assert all(case["required"] is True for case in manifest["cases"])


def test_v1_failure_matrix_is_10_of_10_pass():
    result = run_failure_matrix()
    assert result.passed is True
    assert result.passed_count == 10
    assert result.failed_count == 0
    assert [case.case_id for case in result.cases] == [f"F{i:02d}" for i in range(1, 11)]
    assert all(case.status is FailureCaseStatus.PASS for case in result.cases)


def test_failure_matrix_preserves_key_governance_evidence():
    result = run_failure_matrix()
    by_id = {case.case_id: case for case in result.cases}
    assert by_id["F03"].evidence["accounting"] == "accounting_incomplete"
    assert by_id["F06"].evidence["all_cache_hits_false"] is True
    assert by_id["F09"].evidence["rebind_count_after_revoke"] == 0
