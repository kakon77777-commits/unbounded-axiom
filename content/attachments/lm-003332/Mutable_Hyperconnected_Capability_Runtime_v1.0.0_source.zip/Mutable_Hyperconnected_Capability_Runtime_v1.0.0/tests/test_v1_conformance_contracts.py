import json
from dataclasses import FrozenInstanceError

import pytest

from mhcr.conformance import (
    ConformanceCaseResult,
    ConformanceCaseStatus,
    ConformanceClaim,
    load_conformance_manifest,
    run_conformance,
)


def test_v1_core_manifest_is_packaged_and_exactly_32_required_cases():
    manifest = load_conformance_manifest("MHCR-CORE-R1")
    assert manifest["profile_id"] == "MHCR-CORE-R1"
    assert len(manifest["cases"]) == 32
    assert [case["case_id"] for case in manifest["cases"]] == [f"C{i:02d}" for i in range(1, 33)]
    assert all(case["required"] is True for case in manifest["cases"])


def test_v1_gcm_manifest_is_packaged_and_optional_profile():
    manifest = load_conformance_manifest("MHCR-GCM-R1")
    assert manifest["profile_id"] == "MHCR-GCM-R1"
    assert manifest["optional_dependency"] == "gcm_runtime"
    assert len(manifest["cases"]) == 8
    assert [case["case_id"] for case in manifest["cases"]] == [f"G{i:02d}" for i in range(1, 9)]


def test_conformance_result_contracts_are_immutable():
    result = ConformanceCaseResult("C01", ConformanceCaseStatus.PASS, "ok", {})
    with pytest.raises(FrozenInstanceError):
        result.case_id = "changed"


def test_explicit_gcm_profile_is_not_available_without_dependency(monkeypatch):
    import mhcr.conformance as module
    monkeypatch.setattr(module, "_gcm_available", lambda: False)
    result = run_conformance("MHCR-GCM-R1")
    assert result.claim is ConformanceClaim.NOT_AVAILABLE
    assert result.required_passed == 0
    assert result.required_failed == 0
