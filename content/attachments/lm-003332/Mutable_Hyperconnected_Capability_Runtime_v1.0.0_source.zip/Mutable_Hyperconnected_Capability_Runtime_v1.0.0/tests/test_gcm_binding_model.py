from __future__ import annotations

import pytest

from mhcr.gcm_integration import (
    GCMAllocationContext,
    GCMCapacityBinding,
    GCMProviderBinding,
)


def test_gcm_capacity_binding_requires_canonical_nonnegative_integer_evidence() -> None:
    dim = GCMCapacityBinding("memory.vram.bytes", "byte", capacity=16, required=8)
    assert dim.capacity == 16
    assert dim.required == 8

    with pytest.raises(ValueError, match="capacity"):
        GCMCapacityBinding("memory", "unit", capacity=1.5, required=1)
    with pytest.raises(ValueError, match="required"):
        GCMCapacityBinding("memory", "unit", capacity=2, required=-1)


def test_one_provider_can_expose_multiple_compute_configurations() -> None:
    cpu = GCMProviderBinding(
        binding_id="bind.cpu",
        provider_id="provider.numeric",
        resource_id="resource.cpu",
        configuration_id="cfg.cpu",
        executor_id="provider.numeric",
        resource_kind="cpu",
        capabilities=("numeric",),
        dimensions=(GCMCapacityBinding("memory.bytes", "byte", 64, 8),),
        estimates={"latency_ms": 10.0},
    )
    gpu = GCMProviderBinding(
        binding_id="bind.gpu",
        provider_id="provider.numeric",
        resource_id="resource.gpu",
        configuration_id="cfg.gpu",
        executor_id="provider.numeric",
        resource_kind="gpu",
        capabilities=("numeric",),
        dimensions=(GCMCapacityBinding("memory.vram.bytes", "byte", 32, 8),),
        estimates={"latency_ms": 2.0},
        priority=1,
    )
    assert cpu.provider_id == gpu.provider_id
    assert cpu.configuration_id != gpu.configuration_id


def test_gcm_allocation_context_is_logical_and_does_not_imply_world_authority() -> None:
    context = GCMAllocationContext()
    assert context.world_boundary.startswith("world:mhcr")
    assert context.foundation_id.startswith("foundation:mhcr")
    assert "compute" in context.effective_permissions
    assert context.authority_ref.startswith("authority:mhcr")
