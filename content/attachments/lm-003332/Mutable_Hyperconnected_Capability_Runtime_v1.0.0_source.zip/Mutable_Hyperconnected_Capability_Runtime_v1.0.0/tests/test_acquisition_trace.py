from mhcr.accounting import CostRecord, CostVector, GCAL
from mhcr.constructor import TemplateConstructor, TemplateSpec
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def make_runtime(tmp_path, *, constructor=None):
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    gcal = GCAL()
    history = EventLog(tmp_path / "events.jsonl")
    return (
        MHCRRuntime(registry, verifiers, gcal, history, constructor=constructor),
        registry,
        verifiers,
        gcal,
    )


def test_fast_path_reports_minimal_acquisition_trace(tmp_path):
    runtime, registry, verifiers, gcal = make_runtime(tmp_path)
    capability = Capability(
        "cap.inc", "1.0.0", "increment", "number", "number", "exact",
        ("provider.inc",), "verify.inc", TrustState.TRUSTED,
    )
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.inc", capability.capability_id, lambda x: x + 1))
    verifiers.register("verify.inc", lambda task, result: result == task.payload + 1)
    gcal.register_cost(CostRecord("provider.inc", CostVector(local_work=1.0)))

    solved = runtime.solve(TaskContract("task.fast", "increment", "number", "number", 4))
    trace = solved.acquisition_trace

    assert trace is not None
    assert trace.resolver_lookups == 1
    assert trace.graph_searches == 0
    assert trace.graph_expansions == 0
    assert trace.constructor_invocations == 0
    assert trace.verifier_invocations == 1
    assert trace.acquisition_work == 2.0
    assert trace.memory_hits == ()


def test_constructed_path_reports_constructor_and_failed_graph_search_work(tmp_path):
    constructor = TemplateConstructor([
        TemplateSpec(
            task_family="square",
            input_type="number",
            output_type="number",
            execute=lambda x: x * x,
            verifier_id="verify.square",
        )
    ])
    runtime, _registry, verifiers, _gcal = make_runtime(tmp_path, constructor=constructor)
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)

    solved = runtime.solve(TaskContract("task.construct", "square", "number", "number", 5))
    trace = solved.acquisition_trace

    assert trace is not None
    assert trace.resolver_lookups == 1
    assert trace.graph_searches == 1
    assert trace.graph_expansions >= 1
    assert trace.constructor_invocations == 1
    assert trace.verifier_invocations == 1
    assert trace.acquisition_work == (
        trace.resolver_lookups
        + trace.graph_expansions
        + 5 * trace.constructor_invocations
        + trace.verifier_invocations
    )


def test_composed_path_reports_graph_expansions_without_constructor(tmp_path):
    runtime, registry, verifiers, gcal = make_runtime(tmp_path)
    caps = (
        Capability("cap.a", "1.0.0", "a", "raw", "mid", "exact", ("provider.a",), None, TrustState.TRUSTED),
        Capability("cap.b", "1.0.0", "b", "mid", "final", "exact", ("provider.b",), "verify.pipeline", TrustState.TRUSTED),
    )
    registry.register_capability(caps[0])
    registry.register_capability(caps[1])
    registry.register_provider(Provider("provider.a", "cap.a", lambda x: x + 1))
    registry.register_provider(Provider("provider.b", "cap.b", lambda x: x * 2))
    gcal.register_cost(CostRecord("provider.a", CostVector(local_work=1.0)))
    gcal.register_cost(CostRecord("provider.b", CostVector(local_work=1.0)))
    verifiers.register("verify.pipeline", lambda task, result: result == (task.payload + 1) * 2)

    solved = runtime.solve(TaskContract("task.compose", "pipeline", "raw", "final", 3))
    trace = solved.acquisition_trace

    assert solved.source == "composed"
    assert trace is not None
    assert trace.resolver_lookups == 1
    assert trace.graph_searches == 1
    assert trace.graph_expansions >= 3
    assert trace.constructor_invocations == 0
    assert trace.verifier_invocations == 1
