from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

pytest.importorskip("gcm_runtime")


def test_substrate_demo_proves_routing_fallback_restart_and_zero_world_commit():
    root = Path(__file__).resolve().parents[1]
    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join(filter(None, (str(root / "src"), env.get("PYTHONPATH", ""))))
    completed = subprocess.run(
        [sys.executable, "-m", "mhcr.substrate_demo"],
        cwd=root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)

    assert payload["phase_preference"]["provider_id"] == "provider.phase"
    assert payload["phase_preference"]["substrate_kind"] == "phase"
    assert payload["phase_preference"]["substrate_realization"] == "simulated"
    assert payload["native_fallback"]["provider_id"] == "provider.cpu"
    assert payload["native_fallback"]["substrate_realization"] == "native"
    assert payload["event_preference"]["provider_id"] == "provider.event"
    assert payload["event_preference"]["substrate_kind"] == "event_driven"
    assert payload["energy_fallback"]["provider_id"] == "provider.cpu"
    assert payload["energy_fallback"]["substrate_fallback_used"] is True
    assert payload["restart"]["provider_id"] == "provider.phase"
    assert payload["restart"]["profile_count"] == 3
    assert payload["restart"]["binding_count"] == 3
    assert payload["world_commit_events"] == 0
    assert payload["executed"] == ["phase", "cpu", "event", "cpu", "phase-restart"]
