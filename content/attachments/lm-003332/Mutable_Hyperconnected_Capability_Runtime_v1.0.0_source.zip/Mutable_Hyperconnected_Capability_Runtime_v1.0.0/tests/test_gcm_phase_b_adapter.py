from __future__ import annotations

import pytest

pytest.importorskip("gcm_runtime")

from mhcr.gcm_integration import (
    GCMAllocationRejectedError,
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from mhcr.models import Capability, TaskContract, TrustState


def capability() -> Capability:
    return Capability(
        capability_id="cap.square",
        version="1.0.0",
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.gpu", "provider.cpu"),
        verifier_id="verify.square",
        trust_state=TrustState.TRUSTED,
    )


def task(task_id: str = "task.square") -> TaskContract:
    return TaskContract(task_id, "square", "number", "number", 9)


def binding(
    binding_id: str,
    provider_id: str,
    resource_id: str,
    configuration_id: str,
    kind: str,
    dimension_id: str,
    capacity: int,
    required: int,
    *,
    priority: int = 0,
) -> GCMProviderBinding:
    return GCMProviderBinding(
        binding_id=binding_id,
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=configuration_id,
        executor_id=provider_id,
        resource_kind=kind,
        capabilities=("square",),
        dimensions=(GCMCapacityBinding(dimension_id, "logical-unit", capacity, required),),
        estimates={"latency_ms": 2.0 if kind == "gpu" else 12.0},
        priority=priority,
    )


def adapter(gpu_capacity: int, cpu_capacity: int) -> GCMPhaseBAdapter:
    store = GCMResourceBindingStore()
    store.upsert(
        binding(
            "bind.gpu", "provider.gpu", "resource.gpu", "cfg.gpu", "gpu",
            "vram", gpu_capacity, 8,
        )
    )
    store.upsert(
        binding(
            "bind.cpu", "provider.cpu", "resource.cpu", "cfg.cpu", "cpu",
            "memory", cpu_capacity, 8,
        )
    )
    return GCMPhaseBAdapter(store)


def test_actual_gcm_phase_b_selects_first_ranked_feasible_gpu() -> None:
    decision = adapter(16, 16).allocate(
        task(), capability(), ("provider.gpu", "provider.cpu")
    )
    assert decision.provider_id == "provider.gpu"
    assert decision.resource_id == "resource.gpu"
    assert decision.configuration_id == "cfg.gpu"
    assert decision.allocation_plan_id.startswith("allocation-plan:")
    assert decision.gcm_package_version


def test_gcm_b3_capacity_failure_falls_through_to_lower_ranked_cpu() -> None:
    decision = adapter(4, 16).allocate(
        task("task.fallback"), capability(), ("provider.gpu", "provider.cpu")
    )
    assert decision.provider_id == "provider.cpu"
    assert decision.resource_id == "resource.cpu"
    assert decision.evidence["b3_states_explored"] >= 2


def test_gcm_allocation_rejects_when_no_binding_has_capacity() -> None:
    with pytest.raises(GCMAllocationRejectedError) as exc:
        adapter(4, 4).allocate(
            task("task.reject"), capability(), ("provider.gpu", "provider.cpu")
        )
    assert exc.value.failures
    assert {item["failure_code"] for item in exc.value.failures} >= {"CAPACITY_EXCEEDED"}
