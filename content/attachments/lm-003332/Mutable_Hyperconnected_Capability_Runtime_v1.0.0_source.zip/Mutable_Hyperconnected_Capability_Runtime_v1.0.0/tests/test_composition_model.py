from mhcr.models import (
    Capability,
    CompositionPolicy,
    TaskContract,
    TransitionFidelity,
    TrustState,
)


def test_composition_metadata_defaults_preserve_v04_semantics():
    task = TaskContract("t", "family", "a", "b", 1)
    capability = Capability(
        capability_id="cap.a.b",
        version="1.0.0",
        task_family="family",
        input_type="a",
        output_type="b",
        exactness="exact",
        provider_ids=("provider.a.b",),
        trust_state=TrustState.TRUSTED,
    )

    assert task.composition_policy == CompositionPolicy()
    assert task.composition_policy.max_steps == 6
    assert capability.fidelity is TransitionFidelity.EXACT
    assert capability.component_capability_ids == ()
    assert capability.is_composite is False


def test_composite_capability_exposes_lineage_and_lossy_fidelity():
    capability = Capability(
        capability_id="cap.composite",
        version="1.0.0",
        task_family="family",
        input_type="a",
        output_type="c",
        exactness="approximate",
        provider_ids=(),
        trust_state=TrustState.TRUSTED,
        fidelity=TransitionFidelity.LOSSY,
        component_capability_ids=("cap.a.b", "cap.b.c"),
    )

    assert capability.is_composite is True
    assert capability.fidelity is TransitionFidelity.LOSSY
    assert capability.component_capability_ids == ("cap.a.b", "cap.b.c")
