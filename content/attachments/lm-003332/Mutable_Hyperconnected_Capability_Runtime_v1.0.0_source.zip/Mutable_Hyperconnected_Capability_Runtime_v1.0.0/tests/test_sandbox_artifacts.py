import sqlite3

import pytest

from mhcr.history import EventLog
from mhcr.models import Capability, TrustState
from mhcr.sandbox import (
    CandidateArtifactStatus,
    GeneratedArtifactStore,
    GeneratedCandidateArtifact,
    SandboxPolicy,
)
from mhcr.sqlite_repository import SQLiteRepository


def artifact() -> GeneratedCandidateArtifact:
    source = "def solve(payload):\n    return payload * payload\n"
    return GeneratedCandidateArtifact.create(
        artifact_id="artifact.generated.square.v1",
        capability_id="cap.generated.square",
        provider_id="provider.generated.square",
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        source=source,
        entrypoint="solve",
        policy_id="sandbox.default.v1",
    )


def test_generated_artifact_hash_is_derived_and_lifecycle_is_explicit():
    item = artifact()
    assert len(item.source_sha256) == 64
    assert item.status is CandidateArtifactStatus.PROPOSED
    inspected = item.with_status(CandidateArtifactStatus.INSPECTED)
    assert inspected.status is CandidateArtifactStatus.INSPECTED
    rejected = inspected.rejected("forbidden import")
    assert rejected.status is CandidateArtifactStatus.REJECTED
    assert rejected.active is False
    assert rejected.rejection_reason == "forbidden import"


def test_generated_artifact_rejects_mismatched_hash():
    with pytest.raises(ValueError, match="source_sha256"):
        GeneratedCandidateArtifact(
            artifact_id="artifact.bad",
            capability_id="cap.bad",
            provider_id="provider.bad",
            task_family="bad",
            input_type="number",
            output_type="number",
            exactness="exact",
            source="def solve(payload): return payload",
            entrypoint="solve",
            source_sha256="0" * 64,
            policy_id="sandbox.default.v1",
        )


def test_sqlite_v6_round_trips_generated_artifact(tmp_path):
    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    store = GeneratedArtifactStore(repository=repo)
    item = artifact().with_status(CandidateArtifactStatus.SANDBOX_TESTED)
    store.upsert(item)
    repo.close()

    reopened = SQLiteRepository(path)
    assert reopened.schema_version == 8
    restored = reopened.load_generated_artifacts()
    assert restored == (item,)
    reopened.close()


def test_sqlite_v5_migrates_to_v6_without_losing_capabilities_or_memory(tmp_path):
    from mhcr.acquisition import AcquisitionMemoryKind, AcquisitionMemoryRecord

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    capability = Capability(
        capability_id="cap.old",
        version="1.0.0",
        task_family="old",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=(),
        trust_state=TrustState.TRUSTED,
    )
    memory = AcquisitionMemoryRecord(
        memory_id="mem.old",
        kind=AcquisitionMemoryKind.SOLVER,
        task_family="old",
        input_type="number",
        output_type="number",
        exactness="exact",
        subject_id="cap.old",
    )
    repo.save_capability(capability)
    repo.save_acquisition_memory(memory)
    repo.close()

    connection = sqlite3.connect(path)
    connection.execute("DROP TABLE IF EXISTS generated_candidate_artifacts")
    connection.execute("UPDATE metadata SET value='5' WHERE key='schema_version'")
    connection.commit()
    connection.close()

    migrated = SQLiteRepository(path)
    assert migrated.schema_version == 8
    assert migrated.load_capabilities() == (capability,)
    assert migrated.load_acquisition_memories() == (memory,)
    assert migrated.load_generated_artifacts() == ()
    migrated.close()


def test_generated_artifact_jsonl_replay_preserves_promotion_and_rejection(tmp_path):
    log = EventLog(tmp_path / "events.jsonl")
    store = GeneratedArtifactStore(event_log=log)
    first = artifact()
    store.upsert(first)
    store.upsert(first.with_status(CandidateArtifactStatus.INSPECTED))
    store.upsert(first.with_status(CandidateArtifactStatus.SANDBOX_TESTED))
    store.upsert(first.promoted("task.square.1"))

    rejected = GeneratedCandidateArtifact.create(
        artifact_id="artifact.generated.bad.v1",
        capability_id="cap.generated.bad",
        provider_id="provider.generated.bad",
        task_family="bad",
        input_type="number",
        output_type="number",
        exactness="exact",
        source="def solve(payload):\n    return payload\n",
        entrypoint="solve",
        policy_id="sandbox.default.v1",
    ).rejected("policy")
    store.upsert(rejected)

    replayed = log.replay_generated_artifacts()
    assert replayed.get(first.artifact_id).status is CandidateArtifactStatus.PROMOTED
    assert replayed.get(first.artifact_id).promotion_task_id == "task.square.1"
    assert replayed.get(rejected.artifact_id).status is CandidateArtifactStatus.REJECTED
    assert replayed.get(rejected.artifact_id).active is False


def test_sandbox_policy_defaults_are_non_privileged():
    policy = SandboxPolicy()
    assert policy.allow_imports is False
    assert policy.allow_file_io is False
    assert policy.allow_network is False
    assert policy.allow_shell is False
    assert policy.allow_secret_environment is False
