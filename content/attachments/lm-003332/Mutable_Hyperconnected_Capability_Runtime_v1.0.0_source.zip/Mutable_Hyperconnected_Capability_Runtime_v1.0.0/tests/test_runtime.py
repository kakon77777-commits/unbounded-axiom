import pytest

from mhcr.accounting import AccountingStatus, CostRecord, CostVector, GCAL
from mhcr.constructor import TemplateConstructor, TemplateSpec
from mhcr.history import EventLog
from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.runtime import MHCRRuntime
from mhcr.verification import VerifierRegistry


def make_runtime(tmp_path, constructor=None):
    registry = CapabilityRegistry()
    verifiers = VerifierRegistry()
    gcal = GCAL()
    history = EventLog(tmp_path / "events.jsonl")
    runtime = MHCRRuntime(registry, verifiers, gcal, history, constructor=constructor)
    return runtime, registry, verifiers, gcal, history


def test_known_trusted_capability_resolves_executes_verifies_and_accounts(tmp_path):
    runtime, registry, verifiers, gcal, history = make_runtime(tmp_path)
    cap = Capability(
        capability_id="cap.math.increment",
        version="1.0.0",
        task_family="increment",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.increment",),
        verifier_id="verify.increment",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.increment", cap.capability_id, lambda x: x + 1))
    verifiers.register("verify.increment", lambda task, result: result == task.payload + 1)
    gcal.register_cost(CostRecord("provider.increment", CostVector(local_work=2.0)))

    solved = runtime.solve(TaskContract("task-known", "increment", "number", "number", 4))

    assert solved.value == 5
    assert solved.source == "resolved"
    assert solved.verification.passed is True
    assert solved.accounting.status is AccountingStatus.CLOSED_ACCOUNTED
    assert solved.accounting.closed.local_work == 3.0  # 1 invocation + 2 provider work
    assert solved.cache_hit is False
    assert history.replay_counts()["TASK_COMPLETED"] == 1


def test_candidate_is_constructed_verified_promoted_and_reused_on_unseen_input(tmp_path):
    constructor = TemplateConstructor(
        [
            TemplateSpec(
                task_family="square",
                input_type="number",
                output_type="number",
                execute=lambda x: x * x,
                verifier_id="verify.square",
                provider_local_work=3.0,
            )
        ]
    )
    runtime, registry, verifiers, _gcal, history = make_runtime(tmp_path, constructor)
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)

    first = runtime.solve(TaskContract("task-square-1", "square", "number", "number", 4))
    second = runtime.solve(TaskContract("task-square-2", "square", "number", "number", 7))

    assert first.value == 16
    assert first.source == "constructed"
    assert first.acquisition_events == 1
    assert second.value == 49
    assert second.source == "resolved"
    assert second.acquisition_events == 0
    assert first.cache_hit is False and second.cache_hit is False
    assert constructor.construct_count == 1
    assert registry.get_capability("cap.generated.square").trust_state is TrustState.TRUSTED
    counts = history.replay_counts()
    assert counts["CAPABILITY_CANDIDATE_CREATED"] == 1
    assert counts["CAPABILITY_PROMOTED"] == 1
    assert counts["TASK_COMPLETED"] == 2


def test_failed_candidate_verification_does_not_pollute_trusted_registry(tmp_path):
    constructor = TemplateConstructor(
        [
            TemplateSpec(
                task_family="square",
                input_type="number",
                output_type="number",
                execute=lambda x: x * x + 1,
                verifier_id="verify.square",
            )
        ]
    )
    runtime, registry, verifiers, _gcal, history = make_runtime(tmp_path, constructor)
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)

    with pytest.raises(RuntimeError, match="verification failed"):
        runtime.solve(TaskContract("task-bad", "square", "number", "number", 4))

    assert registry.get_capability("cap.generated.square").trust_state is TrustState.CANDIDATE
    assert history.replay_counts()["SOLVER_FAILED"] == 1


def test_missing_provider_cost_keeps_execution_possible_but_closed_accounting_incomplete(tmp_path):
    runtime, registry, verifiers, _gcal, _history = make_runtime(tmp_path)
    cap = Capability(
        capability_id="cap.external.echo",
        version="1.0.0",
        task_family="echo",
        input_type="text",
        output_type="text",
        exactness="exact",
        provider_ids=("provider.external.echo",),
        verifier_id="verify.echo",
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.external.echo", cap.capability_id, lambda x: x))
    verifiers.register("verify.echo", lambda task, result: result == task.payload)

    solved = runtime.solve(TaskContract("task-unknown-cost", "echo", "text", "text", "hello"))

    assert solved.value == "hello"
    assert solved.accounting.status is AccountingStatus.ACCOUNTING_INCOMPLETE
    assert "provider.external.echo" in solved.accounting.unknown_nodes
