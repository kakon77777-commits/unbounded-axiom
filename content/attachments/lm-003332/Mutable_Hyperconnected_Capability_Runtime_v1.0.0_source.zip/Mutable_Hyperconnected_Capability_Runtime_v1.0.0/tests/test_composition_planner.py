from mhcr.models import (
    Capability,
    CompositionPolicy,
    Provider,
    TaskContract,
    TransitionFidelity,
    TrustState,
)
from mhcr.rdr import RDR
from mhcr.registry import CapabilityRegistry
from mhcr.resolver import Resolver
from mhcr.routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile


def capability(capability_id: str, input_type: str, output_type: str, *, fidelity=TransitionFidelity.EXACT):
    provider_id = f"provider.{capability_id}"
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=capability_id,
        input_type=input_type,
        output_type=output_type,
        exactness="exact",
        provider_ids=(provider_id,),
        trust_state=TrustState.TRUSTED,
        fidelity=fidelity,
    )


def add_executable(registry: CapabilityRegistry, cap: Capability) -> None:
    registry.register_capability(cap)
    registry.register_provider(Provider(cap.provider_ids[0], cap.capability_id, lambda value: value))


def declared(value: float) -> CostMetric:
    return CostMetric(value, CostEvidence.DECLARED)


def test_planner_finds_three_step_typed_path():
    registry = CapabilityRegistry()
    for cap in (
        capability("cap.parse", "raw", "parsed"),
        capability("cap.normalize", "parsed", "normalized"),
        capability("cap.finish", "normalized", "final"),
    ):
        registry.register_capability(cap)

    task = TaskContract("t", "pipeline", "raw", "final", "payload")
    plan = Resolver(registry).plan(task)

    assert plan is not None
    assert [cap.capability_id for cap in plan.capabilities] == [
        "cap.parse",
        "cap.normalize",
        "cap.finish",
    ]
    assert plan.graph_expansions > 0


def test_planner_rejects_type_incompatible_edges():
    registry = CapabilityRegistry()
    registry.register_capability(capability("cap.parse", "raw", "parsed"))
    registry.register_capability(capability("cap.finish", "different", "final"))

    task = TaskContract("t", "pipeline", "raw", "final", "payload")

    assert Resolver(registry).plan(task) is None


def test_exact_task_rejects_lossy_bridge():
    registry = CapabilityRegistry()
    registry.register_capability(capability("cap.lossy", "raw", "middle", fidelity=TransitionFidelity.LOSSY))
    registry.register_capability(capability("cap.finish", "middle", "final"))

    task = TaskContract("t", "pipeline", "raw", "final", "payload", exactness="exact")

    assert Resolver(registry).plan(task) is None


def test_max_step_bound_rejects_path_that_is_too_long():
    registry = CapabilityRegistry()
    for cap in (
        capability("cap.a", "raw", "a"),
        capability("cap.b", "a", "b"),
        capability("cap.c", "b", "final"),
    ):
        registry.register_capability(cap)
    task = TaskContract(
        "t",
        "pipeline",
        "raw",
        "final",
        "payload",
        composition_policy=CompositionPolicy(max_steps=2),
    )

    assert Resolver(registry).plan(task) is None


def test_weighted_planner_can_choose_longer_but_cheaper_path():
    registry = CapabilityRegistry()
    short = (
        capability("cap.short.1", "raw", "short-mid"),
        capability("cap.short.2", "short-mid", "final"),
    )
    long = (
        capability("cap.long.1", "raw", "long-a"),
        capability("cap.long.2", "long-a", "long-b"),
        capability("cap.long.3", "long-b", "final"),
    )
    for cap in short + long:
        add_executable(registry, cap)

    catalog = ProviderCostCatalog()
    for cap in short:
        catalog.upsert(
            ProviderCostProfile(cap.provider_ids[0], latency_ms=declared(100.0)),
            persist=False,
        )
    for cap in long:
        catalog.upsert(
            ProviderCostProfile(cap.provider_ids[0], latency_ms=declared(1.0)),
            persist=False,
        )
    rdr = RDR(registry, cost_catalog=catalog)
    task = TaskContract(
        "t",
        "pipeline",
        "raw",
        "final",
        "payload",
        composition_policy=CompositionPolicy(step_weight=1.0, latency_weight=1.0),
    )

    plan = Resolver(registry, rdr=rdr).plan(task)

    assert plan is not None
    assert [cap.capability_id for cap in plan.capabilities] == [
        "cap.long.1",
        "cap.long.2",
        "cap.long.3",
    ]
    assert plan.provider_ids == tuple(cap.provider_ids[0] for cap in long)


def test_unknown_weighted_cost_is_penalized_instead_of_treated_as_zero():
    registry = CapabilityRegistry()
    unknown = (
        capability("cap.unknown.1", "raw", "unknown-mid"),
        capability("cap.unknown.2", "unknown-mid", "final"),
    )
    known = (
        capability("cap.known.1", "raw", "known-mid"),
        capability("cap.known.2", "known-mid", "final"),
    )
    for cap in unknown + known:
        add_executable(registry, cap)
    catalog = ProviderCostCatalog()
    for cap in known:
        catalog.upsert(
            ProviderCostProfile(cap.provider_ids[0], latency_ms=declared(10.0)),
            persist=False,
        )
    rdr = RDR(registry, cost_catalog=catalog)
    task = TaskContract(
        "t",
        "pipeline",
        "raw",
        "final",
        "payload",
        composition_policy=CompositionPolicy(
            step_weight=1.0,
            latency_weight=1.0,
            unknown_metric_penalty=1000.0,
        ),
    )

    plan = Resolver(registry, rdr=rdr).plan(task)

    assert plan is not None
    assert [cap.capability_id for cap in plan.capabilities] == ["cap.known.1", "cap.known.2"]
