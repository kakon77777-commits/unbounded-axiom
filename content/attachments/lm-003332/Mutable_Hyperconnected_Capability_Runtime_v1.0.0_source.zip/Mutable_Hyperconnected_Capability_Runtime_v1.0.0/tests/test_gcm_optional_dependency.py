from __future__ import annotations

import importlib

import pytest

from mhcr.gcm_integration import (
    GCMPhaseBAdapter,
    GCMResourceBindingStore,
    GCMUnavailableError,
)
from mhcr.models import Capability, TaskContract, TrustState


def test_adapter_fails_explicitly_when_optional_gcm_dependency_is_unavailable(monkeypatch) -> None:
    original = importlib.import_module

    def blocked(name: str, package=None):
        if name == "gcm_runtime" or name.startswith("gcm_runtime."):
            raise ModuleNotFoundError(name)
        return original(name, package)

    monkeypatch.setattr(importlib, "import_module", blocked)
    adapter = GCMPhaseBAdapter(GCMResourceBindingStore())
    capability = Capability(
        "cap.echo", "1.0.0", "echo", "text", "text", "exact", (),
        trust_state=TrustState.TRUSTED,
    )
    task = TaskContract("task.echo", "echo", "text", "text", "hello")
    with pytest.raises(GCMUnavailableError):
        adapter.allocate(task, capability, ())
