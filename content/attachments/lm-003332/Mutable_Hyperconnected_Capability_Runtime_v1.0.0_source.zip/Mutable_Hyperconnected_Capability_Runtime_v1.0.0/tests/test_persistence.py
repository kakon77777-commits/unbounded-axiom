from mhcr.accounting import CostRecord, CostVector
from mhcr.models import Capability, TrustState
from mhcr.repository import ProviderRecord
from mhcr.sqlite_repository import SQLiteRepository


def sample_capability(state=TrustState.TRUSTED):
    return Capability(
        capability_id="cap.math.double",
        version="1.2.0",
        task_family="double",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.double",),
        verifier_id="verify.double",
        trust_state=state,
        scope="local",
    )


def test_sqlite_repository_round_trips_semantic_state_without_callable(tmp_path):
    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    repo.save_capability(sample_capability())
    repo.save_provider(ProviderRecord("provider.double", "cap.math.double", active=True))
    repo.save_cost(CostRecord("provider.double", CostVector(local_work=2.5), known=True))
    repo.close()

    reopened = SQLiteRepository(path)
    assert reopened.schema_version == 8
    assert reopened.load_capabilities() == (sample_capability(),)
    assert reopened.load_provider_records() == (
        ProviderRecord("provider.double", "cap.math.double", active=True),
    )
    assert reopened.load_costs() == (
        CostRecord("provider.double", CostVector(local_work=2.5), known=True),
    )
    reopened.close()


def test_sqlite_schema_can_be_reopened_idempotently(tmp_path):
    path = tmp_path / "mhcr.sqlite3"
    first = SQLiteRepository(path)
    first.close()
    second = SQLiteRepository(path)
    assert second.schema_version == 8
    second.close()


def test_registry_restores_trusted_capability_and_rebinds_local_executor(tmp_path):
    from mhcr.models import Provider
    from mhcr.registry import CapabilityRegistry

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    registry = CapabilityRegistry(repository=repo)
    capability = sample_capability()
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.double", capability.capability_id, lambda value: value * 2))
    repo.close()

    reopened = SQLiteRepository(path)
    restored = CapabilityRegistry.from_repository(
        reopened,
        provider_executors={"provider.double": lambda value: value * 2},
    )

    assert restored.get_capability(capability.capability_id) == capability
    providers = restored.providers_for(capability.capability_id)
    assert len(providers) == 1
    assert providers[0].execute(6) == 12
    reopened.close()


def test_registry_revocation_survives_restart(tmp_path):
    from mhcr.registry import CapabilityRegistry

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    registry = CapabilityRegistry(repository=repo)
    capability = sample_capability()
    registry.register_capability(capability)
    registry.revoke(capability.capability_id)
    repo.close()

    reopened = SQLiteRepository(path)
    restored = CapabilityRegistry.from_repository(reopened)
    assert restored.get_capability(capability.capability_id).trust_state is TrustState.REVOKED
    assert restored.find_trusted(
        task_family="double",
        input_type="number",
        output_type="number",
        exactness="exact",
    ) == []
    reopened.close()


def test_missing_executor_binding_restores_provider_as_unavailable(tmp_path):
    from mhcr.models import Provider
    from mhcr.registry import CapabilityRegistry

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    registry = CapabilityRegistry(repository=repo)
    capability = sample_capability()
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.double", capability.capability_id, lambda value: value * 2))
    repo.close()

    reopened = SQLiteRepository(path)
    restored = CapabilityRegistry.from_repository(reopened)
    assert restored.providers_for(capability.capability_id, active_only=True) == []
    provider = restored.get_provider("provider.double")
    assert provider.active is False
    reopened.close()


def test_gcal_provider_cost_profile_survives_restart(tmp_path):
    from mhcr.accounting import Dependency, GCAL

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    first = GCAL(repository=repo)
    first.register_cost(CostRecord("provider.double", CostVector(local_work=2.0)))
    repo.close()

    reopened = SQLiteRepository(path)
    restored = GCAL(repository=reopened)
    restored.register_cost(CostRecord("task:restart", CostVector(local_work=1.0)))
    restored.register_dependency(Dependency("task:restart", "provider.double", required=True))
    report = restored.account("task:restart")

    assert report.is_closed_complete is True
    assert report.closed.local_work == 3.0
    reopened.close()


def test_ephemeral_task_cost_can_skip_persistence(tmp_path):
    from mhcr.accounting import GCAL

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    gcal = GCAL(repository=repo)
    gcal.register_cost(CostRecord("task:ephemeral", CostVector(local_work=1.0)), persist=False)
    repo.close()

    reopened = SQLiteRepository(path)
    assert reopened.load_costs() == ()
    reopened.close()


def test_sqlite_v4_round_trips_composition_metadata(tmp_path):
    from mhcr.models import TransitionFidelity

    path = tmp_path / "mhcr.sqlite3"
    repo = SQLiteRepository(path)
    capability = Capability(
        capability_id="cap.composite.pipeline",
        version="1.0.0",
        task_family="pipeline",
        input_type="raw",
        output_type="final",
        exactness="exact",
        provider_ids=(),
        verifier_id="verify.pipeline",
        trust_state=TrustState.TRUSTED,
        scope="composite",
        fidelity=TransitionFidelity.EXACT,
        component_capability_ids=("cap.parse", "cap.normalize", "cap.finish"),
    )
    repo.save_capability(capability)
    repo.close()

    reopened = SQLiteRepository(path)
    assert reopened.schema_version == 8
    assert reopened.load_capabilities() == (capability,)
    reopened.close()
