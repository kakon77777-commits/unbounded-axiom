from mhcr.models import Capability, Provider, TaskContract, TrustState
from mhcr.registry import CapabilityRegistry
from mhcr.resolver import Resolver
from mhcr.rdr import RDR


def trusted_cap(capability_id, family, input_type, output_type, provider_id):
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type=input_type,
        output_type=output_type,
        exactness="exact",
        provider_ids=(provider_id,),
        trust_state=TrustState.TRUSTED,
    )


def test_resolver_prefers_exact_typed_semantic_match():
    registry = CapabilityRegistry()
    right = trusted_cap("cap.math.square", "square", "number", "number", "provider.square")
    wrong = trusted_cap("cap.text.square_word", "square", "text", "text", "provider.text")
    registry.register_capability(right)
    registry.register_capability(wrong)

    task = TaskContract("t1", "square", "number", "number", 4)
    result = Resolver(registry).resolve(task)

    assert [cap.capability_id for cap in result] == ["cap.math.square"]


def test_resolver_can_find_two_step_typed_composition():
    registry = CapabilityRegistry()
    first = trusted_cap("cap.parse", "parse", "text", "table", "provider.parse")
    second = trusted_cap("cap.sum", "sum_table", "table", "number", "provider.sum")
    registry.register_capability(first)
    registry.register_capability(second)

    task = TaskContract("t2", "parse_then_sum", "text", "number", "1,2,3")
    composition = Resolver(registry).compose(task)

    assert composition is not None
    assert [cap.capability_id for cap in composition] == ["cap.parse", "cap.sum"]


def test_rdr_materializes_active_provider_and_executes():
    registry = CapabilityRegistry()
    cap = trusted_cap("cap.math.square", "square", "number", "number", "provider.square")
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.square", cap.capability_id, lambda x: x * x))

    rdr = RDR(registry)
    materialized = rdr.materialize(cap)
    result = rdr.execute(materialized, 5)

    assert materialized.capability.capability_id == "cap.math.square"
    assert materialized.provider.provider_id == "provider.square"
    assert result == 25


def test_provider_can_change_without_changing_capability_identity():
    registry = CapabilityRegistry()
    cap = Capability(
        capability_id="cap.math.square",
        version="1.0.0",
        task_family="square",
        input_type="number",
        output_type="number",
        exactness="exact",
        provider_ids=("provider.a", "provider.b"),
        trust_state=TrustState.TRUSTED,
    )
    registry.register_capability(cap)
    registry.register_provider(Provider("provider.a", cap.capability_id, lambda x: x * x, active=False))
    registry.register_provider(Provider("provider.b", cap.capability_id, lambda x: pow(x, 2)))

    materialized = RDR(registry).materialize(cap)

    assert materialized.capability.address == "cap.math.square@1"
    assert materialized.provider.provider_id == "provider.b"
