from mhcr.acceptance import run_acceptance


def test_v1_standalone_acceptance_is_conjunction_of_core_failure_and_longrun():
    result = run_acceptance(include_gcm=False)
    assert result.accepted is True
    assert result.core.required_passed == 32
    assert result.failure_matrix.passed_count == 10
    assert result.longrun.passed is True
    assert result.gcm is None
