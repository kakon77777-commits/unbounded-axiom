# MHCR v0.5.0 Validation Report

**Date:** 2026-08-30  
**Branch:** `workbench/mhcr-v0.5-capability-composition-planner`

## Scope validated

- v0.4 cost-aware Provider Fabric retained.
- `TransitionFidelity` and `CompositionPolicy` model contracts.
- SQLite schema v4 and sequential v1/v2/v3 -> v4 migration.
- Fidelity and composite component lineage survive SQLite round-trip and JSONL replay.
- Deterministic typed capability graph planning for paths longer than two steps.
- Type-incompatible paths are rejected.
- Exact tasks reject lossy/approximate transition edges.
- Configurable maximum composition depth.
- Weighted path selection across step, latency, monetary, verification, and risk terms.
- Unknown weighted routing metrics receive explicit penalty and are never treated as zero.
- Planner delegates provider eligibility and provider ordering to the canonical v0.4 RDR.
- Successful composed execution is independently verified before composite canonicalization.
- Composite semantic identity is deterministic from task signature plus ordered component lineage.
- Composite capabilities persist without freezing provider identity or executor bindings.
- Direct composite reuse expands current trusted components and reuses live RDR provider routing.
- A second unseen payload with the same semantic task signature reuses the composite without a new graph search.
- Component revocation recursively deprecates dependent composite capabilities.
- Composite invalidation survives JSONL replay.

## Automated tests

Command:

```bash
PYTHONPATH=src pytest -q
```

Collected result:

```text
106 tests collected
106 / 106 passed
```

## Compile validation

```bash
python -m compileall -q src
```

Result: exit 0.

## v0.5 composition demo evidence

Command:

```bash
PYTHONPATH=src python -m mhcr.demo
```

Observed composition evidence:

```json
{
  "component_ids": [
    "cap.demo.parse",
    "cap.demo.double-list",
    "cap.demo.sum"
  ],
  "composite_id": "cap.composite.52cd18ae057dda43",
  "composite_trust_before_restart": "trusted",
  "first_graph_expansions": 4,
  "first_graph_searches": 1,
  "first_source": "composed",
  "first_value": 12,
  "invalidation_events": 1,
  "persisted_component_ids": [
    "cap.demo.parse",
    "cap.demo.double-list",
    "cap.demo.sum"
  ],
  "replay_trust_after_revoke": "deprecated",
  "restart_execution_path": "fast",
  "restart_graph_searches": 0,
  "restart_source": "resolved",
  "restart_value": 18,
  "trust_after_component_revoke": "deprecated"
}
```

This demonstrates:

1. first solve performs a real graph search and chooses a three-step plan;
2. the verified plan becomes a trusted composite capability;
3. SQLite restart preserves ordered component lineage;
4. the second different input resolves the composite through the fast path without invoking graph search;
5. revoking one component deprecates the composite;
6. event replay reconstructs the invalidated state.

## Weighted-path evidence

The test suite includes competing paths where a shorter two-step path has substantially higher provider latency than a three-step path. With composition latency weighting enabled, the planner selects the longer lower-cost path. Separate tests prove that unknown weighted latency is penalized rather than interpreted as zero.

## Fidelity / exactness evidence

For an exact task, a path containing a capability marked `TransitionFidelity.LOSSY` is rejected even when its input/output types connect. Type connectivity is therefore necessary but not sufficient for an exact composition route.

## Dependency invalidation evidence

`CapabilityRegistry.revoke(component_id)` now recursively finds trusted composite dependents, changes them to `DEPRECATED`, removes them from the trusted semantic index, persists the state, and emits `REGISTRY_COMPOSITE_INVALIDATED`. A transitive composite-on-composite invalidation test is included.

## SQLite migration validation

A synthetic schema-v3 database containing capability rows, provider metadata, and v0.4 routing profiles is opened by v0.5. The repository migrates in place to schema v4 while preserving previous rows. Existing capabilities receive:

```text
fidelity = exact
component_capability_ids = []
```

by default.

## Wheel build and clean-install validation

The environment is offline, so the wheel is built using locally installed build tooling:

```bash
python -m pip wheel . --no-deps --no-build-isolation -w <wheel-dir>
```

Result: `mhcr-0.5.0-py3-none-any.whl` built successfully.

The wheel is installed into a fresh virtual environment with `--no-deps`; `import mhcr`, package version lookup, and `python -m mhcr.demo` reproduce the v0.5 composition evidence above.

## Performance sample

The retained exact-resolver microbenchmark in this container, at 1000 registered capabilities and 500 iterations, observed approximately:

```text
indexed lookup: ~313 ns / lookup
v0.1-style full scan: ~48,018 ns / lookup
relative sample: ~153x
```

This is an environment-specific relative sample, not a cross-hardware performance guarantee. v0.5's new composition evidence is reported separately as graph-search expansion count and direct-reuse search count.

## Critical invariants retained

- `What != How`
- `Capability != Provider`
- `Candidate != Trusted`
- `Capability != Authority`
- `Execution Success != Verification Success`
- `Local Cost != Closed Cost`
- `Routing Profile != Closed Accounting Certificate`
- `Unknown != 0`
- `Provider Failure != Capability Nonexistence`
- `Composite Capability != Frozen Provider Route`
- `Exact Task != Lossy Bridge`
- `No Solver Found != No Solver Exists`
- `Remembering Answers != Learning Solvers`
- `Registered != Available != Executable != Verified`

## Deliberate v0.5 limits

- No v0.6 acquisition/failure/representation memory framework.
- Composite canonicalization stores verified semantic lineage; it is not arbitrary program synthesis.
- No unrestricted generated-code execution.
- No GCM compute allocator integration.
- No PCMT / heterogeneous substrate routing.
- No global scalar complexity claim.

## Verdict

The v0.5 implementation satisfies the planned Capability Composition Planner milestone: MHCR can search typed multi-step capability paths, weight them using current provider evidence, reject invalid/lossy exact routes, execute and verify the selected plan, persist it as a reusable composite semantic capability, bypass graph search on later structurally equivalent tasks, and invalidate the composite when its trusted dependency lineage breaks.

**Next planned milestone:** v0.6 — Acquisition Memory & Solver Learning.
