# Mutable Hyperconnected Capability Runtime MVP Design

## Goal
Build a minimal Python reference runtime proving that trusted capabilities can be registered, resolved, executed, verified, promoted, reused, and accounted without conflating local invocation cost with closed responsibility cost.

## Scope
The MVP implements seven cooperating units:

1. **STCC models/registry** — typed capability, provider, task, trust lifecycle, version identity.
2. **Resolver/composer** — exact typed resolution first; simple two-step composition through type compatibility.
3. **RDR materializer/executor** — bind semantic capability to an active conformant provider and execute it.
4. **Verifier/promotion** — candidate capabilities are untrusted until verification; execution success is not verification success.
5. **GCAL accounting** — local/external/offline/verification costs, dependency closure, unknown != zero, accounting status.
6. **History/event log** — append-only JSONL events for replay/audit; failed and promoted capability events persist.
7. **Runtime orchestration** — Task -> resolve/construct -> materialize -> execute -> verify -> account -> promote -> future reuse.

## Non-goals
No unrestricted self-modification, no network execution, no shell-generating candidate code, no formal P/NP claims, no distributed scheduler, no persistent database, no autonomous authority changes.

## Core invariants
- Capability identity != provider identity.
- Candidate != trusted capability.
- Capability != authority.
- Execution success != verification success.
- Local cost != closed cost.
- Unknown cost != zero.
- No solver found != no solver exists.
- Answer cache != learned solver.

## Minimal capability lifecycle
`candidate -> validated -> trusted -> revoked`.
Only trusted, non-revoked capabilities are returned by the normal resolver.

## Accounting model
Cost records are typed observations rather than a forced universal scalar. The MVP records `local_work`, `external_work`, `offline_work`, `verification_work`, and `monetary_cost`. Any required dependency with unknown cost makes closed accounting incomplete.

## Capability compounding experiment
The runtime includes a safe template constructor for a narrow arithmetic family. A first task can construct and promote a typed composite capability; a later unseen input in the same family resolves the promoted capability rather than reconstructing it. The test asserts lower acquisition-event count on reuse and distinguishes this from cached answer reuse.
