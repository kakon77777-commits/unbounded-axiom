# MHCR v1.0 Final Convergence Design

**Status:** Canonical implementation design  
**Baseline:** MHCR v0.9.0 immutable source archive  
**Target:** MHCR v1.0.0 — Trusted AI-Facing Capability Fabric  
**Date:** 2026-08-31

## 1. Goal

MHCR v1.0 adds no new computational paradigm. It proves that the v0.1–v0.9 capability fabric remains coherent when persistence, indexed fast-path resolution, provider fabric, cost routing, composition, acquisition memory, sandboxed construction, GCM allocation, and substrate routing are evaluated under one release gate.

The release claim is limited to a **developer-usable reference runtime**. It is not a production distributed scheduler, hardware certification, universal cost oracle, or AI sovereignty layer.

## 2. Unchanged invariants

- `What != How`.
- `Capability != Provider != Substrate`.
- `Candidate != Trusted`.
- `Capability != Authority`.
- `Execution Success != Verification Success`.
- `Local Cost != Closed Cost`.
- `Unknown != 0`.
- `Answer Cache != Solver Learning`.
- `GCM Allocation != Provider Execution != Authority Grant != World Commit`.
- Failure, revocation, and rejected-candidate evidence is not silently erased.

## 3. Architecture

v1.0 adds five release-only modules without changing the existing execution graph:

1. `conformance.py` — immutable conformance contracts, packaged manifests, core/GCM profile runners.
2. `failure_matrix.py` — executable F01–F10 failure and governance cases.
3. `longrun.py` — 32-unseen-task persistent/restart capability-compounding benchmark plus resolver benchmark.
4. `acceptance.py` — final conjunction gate combining conformance, failure matrix, long-run and package/developer evidence.
5. `cli.py` — installed developer surface for `conformance`, `failure-matrix`, `longrun`, `acceptance`, and existing demos.

No SQLite schema change is allowed. v1.0 must preserve schema version 8.

## 4. Core conformance profile

Profile ID: `MHCR-CORE-R1`.

Exactly 32 required cases are packaged and machine-readable. They cover:

- v0.1 candidate→verify→promote→unseen reuse;
- v0.2 persistence/indexed fast path;
- v0.3 provider health/failover/boundary evidence;
- v0.4 cost-aware routing and unknown-cost honesty;
- v0.5 typed composition, canonicalization and invalidation;
- v0.6 acquisition learning and no-answer-cache;
- v0.7 sandbox isolation/promotion/revocation;
- v0.8 optional GCM boundary remains optional in core profile;
- v0.9 substrate vocabulary/hardware-honesty boundary;
- append-only/replay and schema-8 continuity.

All 32 required cases must PASS for `CORE_CONFORMANT`.

## 5. Failure matrix

Exactly 10 required cases:

- F01 unavailable provider is not executable;
- F02 unknown monetary cost cannot satisfy a hard monetary ceiling;
- F03 failed external attempt remains in accounting responsibility;
- F04 component revocation invalidates direct/transitive composites;
- F05 deterministic failed constructor route is not retried;
- F06 solver reuse never reports answer-cache hit;
- F07 forbidden generated file/network/shell source is rejected before execution;
- F08 sandbox timeout never creates trusted capability;
- F09 revoked generated artifact cannot be rebound;
- F10 restart/replay preserves revocation/health truth.

Every case is executable from installed package code and produces PASS/FAIL evidence.

## 6. Long-run convergence benchmark

Use 32 distinct unseen square-task payloads.

### Stateless control

Each task starts from `Omega_0` and reacquires the solver.

### Persistent treatment

One durable SQLite runtime acquires the solver once, then executes the remaining 31 unseen payloads across three planned restarts. Restarts explicitly rebind the known provider executor; executor code is never serialized into SQLite.

Required gates:

- 32 distinct payloads;
- stateless constructor invocations = 32;
- persistent constructor invocations = 1;
- every persistent post-first execution path = `fast`;
- every sample `cache_hit = false`;
- persistent post-first acquisition work < stateless post-first acquisition work;
- solver and verification memory are reused after restart;
- durable registry remains trusted across restarts;
- resolver indexed lookup beats linear scan in the benchmark environment (ratio > 1, recorded as environment-relative evidence only).

## 7. Optional GCM extension profile

Profile ID: `MHCR-GCM-R1`.

The core wheel has no hard GCM dependency. If `gcm_runtime` is absent, GCM profile is `NOT_AVAILABLE`, not a core failure.

When accepted GCM 0.4.0 is installed, the extension must verify:

- B1 hard-safe candidate planning is actually used;
- B3 capacity can override substrate preference;
- allocation-selected provider allowlist is enforced;
- execution failure does not trigger unauthorized cross-substrate fallback;
- substrate profile evidence survives allocation;
- GCM allocation does not create MHCR/GCM World commit evidence;
- source and installed-wheel substrate demos agree semantically.

## 8. Developer usability

`pyproject.toml` adds console script:

```text
mhcr = mhcr.cli:main
```

Required installed commands:

```text
mhcr --help
mhcr conformance
mhcr failure-matrix
mhcr longrun
mhcr acceptance
mhcr demo
```

Optional GCM installation additionally supports:

```text
mhcr conformance --profile MHCR-GCM-R1
mhcr substrate-demo
```

The v1 manifests must be installed as package data and must not depend on repository-relative paths.

## 9. Final acceptance claim

`MHCR v1.0 = VALIDATED` only if:

```text
Core Conformance = 32/32 PASS
Failure Matrix = 10/10 PASS
Long-Run Gates = PASS
Standalone clean-wheel developer gate = PASS
Source archive extraction regression = PASS
Optional GCM extension gate = PASS in the separately tested dual-wheel environment
SHA-256 artifact seal = PASS
```

The strongest allowed statement is:

> MHCR v1.0 is a validated developer-usable reference implementation of a persistent, typed, multi-provider, cost-aware, composable, acquisition-learning, sandbox-generative, GCM-integrated and substrate-aware computational capability fabric.

It does not claim production readiness or physical heterogeneous-hardware control.
