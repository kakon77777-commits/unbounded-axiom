# MHCR v1.0 Final Convergence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Seal MHCR v1.0 by adding machine-verifiable conformance, failure, long-run and developer-acceptance surfaces without changing established execution semantics.

**Architecture:** Keep the v0.9 runtime graph unchanged. Add release-only runners and packaged manifests around the public runtime contracts, preserve SQLite schema 8, and expose deterministic installed CLI commands.

**Tech Stack:** Python 3.11+, stdlib, SQLite, pytest for development, setuptools wheel packaging; accepted `gcm-reference-runtime 0.4.0` only for optional extension validation.

**Spec:** `docs/superpowers/specs/2026-08-31-mhcr-v1-final-convergence-design.md`

## Global Constraints

- No SQLite schema bump beyond 8.
- No new provider/substrate/constructor authority.
- No hard dependency on GCM.
- No production-readiness claim.
- No answer cache.
- All new behavior follows RED → GREEN → full regression.

---

### Task 1: Conformance contracts, packaged manifests, and CLI shell

**Files:**
- Create: `src/mhcr/conformance.py`
- Create: `src/mhcr/cli.py`
- Create: `src/mhcr/__main__.py`
- Create: `src/mhcr/data/v1_conformance/core_manifest.json`
- Create: `src/mhcr/data/v1_conformance/gcm_manifest.json`
- Modify: `pyproject.toml`
- Modify: `src/mhcr/__init__.py`
- Test: `tests/test_v1_conformance_contracts.py`
- Test: `tests/test_v1_cli.py`

**Interfaces:**
- Produces `ConformanceCaseStatus`, `ConformanceClaim`, `ConformanceCaseResult`, `ConformanceProfileResult`, `run_conformance(profile_id)`.
- CLI returns non-zero when a requested required profile is nonconformant.

- [ ] Write failing contract/manifest/CLI tests.
- [ ] Run focused tests and verify RED.
- [ ] Implement immutable contracts, manifest loader, CLI parser and package data declaration.
- [ ] Run focused tests and verify GREEN.
- [ ] Run standalone regression and commit.

### Task 2: Core convergence runner

**Files:**
- Modify: `src/mhcr/conformance.py`
- Test: `tests/test_v1_core_conformance.py`

**Interfaces:**
- `run_conformance("MHCR-CORE-R1")` returns exactly 32 required PASS results on the accepted source tree.
- Uses production demos/public APIs; it must not import `tests`.

- [ ] Write failing 32-case profile test.
- [ ] Verify RED.
- [ ] Implement core evidence collection and case evaluators.
- [ ] Verify 32/32 GREEN and deterministic case ordering.
- [ ] Run full standalone regression and commit.

### Task 3: Executable failure matrix

**Files:**
- Create: `src/mhcr/failure_matrix.py`
- Create: `src/mhcr/data/v1_conformance/failure_manifest.json`
- Modify: `src/mhcr/cli.py`
- Modify: `src/mhcr/__init__.py`
- Test: `tests/test_v1_failure_matrix.py`

**Interfaces:**
- Produces `FailureCaseResult`, `FailureMatrixResult`, `run_failure_matrix()`.
- Exactly F01–F10; every required case must return PASS or the overall result is FAIL.

- [ ] Write failing F01–F10 tests.
- [ ] Verify RED.
- [ ] Implement isolated executable scenarios using public production contracts.
- [ ] Verify 10/10 GREEN.
- [ ] Run full regression and commit.

### Task 4: Long-run persistent convergence benchmark

**Files:**
- Create: `src/mhcr/longrun.py`
- Modify: `src/mhcr/cli.py`
- Modify: `src/mhcr/__init__.py`
- Test: `tests/test_v1_longrun.py`

**Interfaces:**
- Produces `LongRunResult` and `run_longrun(payload_count=32, restart_interval=8)`.
- Periodic restart uses real SQLite repository and explicit provider executor rebinding.

- [ ] Write failing 32-task/restart/no-cache tests.
- [ ] Verify RED.
- [ ] Implement stateless control, durable treatment, restart loop and resolver benchmark.
- [ ] Verify all long-run gates GREEN.
- [ ] Run full regression and commit.

### Task 5: Final acceptance aggregator and optional GCM extension

**Files:**
- Create: `src/mhcr/acceptance.py`
- Modify: `src/mhcr/conformance.py`
- Modify: `src/mhcr/cli.py`
- Modify: `src/mhcr/__init__.py`
- Test: `tests/test_v1_acceptance.py`
- Test: `tests/test_v1_gcm_conformance.py`

**Interfaces:**
- Produces `AcceptanceResult`, `run_acceptance(include_gcm=False)`.
- GCM absent: standalone acceptance remains valid; explicit GCM profile reports NOT_AVAILABLE.
- GCM installed: `MHCR-GCM-R1` executes the packaged extension cases.

- [ ] Write failing acceptance/GCM profile tests.
- [ ] Verify RED.
- [ ] Implement conjunction gate and optional-GCM evaluators.
- [ ] Verify standalone and accepted-GCM focused suites.
- [ ] Commit.

### Task 6: v1.0 developer closure and immutable artifact seal

**Files:**
- Modify: `pyproject.toml` version to `1.0.0`
- Modify: `README.md`
- Create: `docs/v1/QUICKSTART.md`
- Create: `VALIDATION_REPORT_v1.0.md`
- Test: `tests/test_v1_package_contract.py`

**Interfaces:**
- Installed wheel exposes `mhcr` console command and packaged manifests.
- Source and installed acceptance JSON agree on semantic fields.

- [ ] Write failing package/quickstart tests.
- [ ] Verify RED.
- [ ] Implement release metadata/docs only; do not add new runtime capability.
- [ ] Run complete standalone shards and optional-GCM focused gate.
- [ ] Build/install standalone wheel and run literal quickstart commands.
- [ ] Build/install dual MHCR+GCM wheels and run GCM extension.
- [ ] Create immutable source ZIP, re-extract, rerun gates, generate SHA-256 manifest, and verify it.
