# MHCR v1.0 Quickstart

MHCR v1.0 is a developer-usable **reference runtime**. GCM is optional for the core profile.

## POSIX — literal no-activation flow

From a directory containing the v1 wheel:

```bash
python -m venv .venv-mhcr
.venv-mhcr/bin/python -m pip install ./mhcr-1.0.0-py3-none-any.whl
.venv-mhcr/bin/mhcr --help
.venv-mhcr/bin/mhcr conformance
.venv-mhcr/bin/mhcr failure-matrix
.venv-mhcr/bin/mhcr longrun
.venv-mhcr/bin/mhcr acceptance
.venv-mhcr/bin/mhcr demo
```

If the virtual environment is activated, the equivalent short commands are:

```bash
mhcr --help
mhcr conformance
mhcr failure-matrix
mhcr longrun
mhcr acceptance
mhcr demo
```

Expected standalone acceptance summary:

```text
MHCR-CORE-R1: 32/32 required PASS
MHCR-FAILURE-R1: 10/10 PASS
long-run: PASS
acceptance: true
```

## Windows PowerShell — literal no-activation flow

```powershell
py -m venv .venv-mhcr
.\.venv-mhcr\Scripts\python.exe -m pip install .\mhcr-1.0.0-py3-none-any.whl
.\.venv-mhcr\Scripts\mhcr.exe --help
.\.venv-mhcr\Scripts\mhcr.exe conformance
.\.venv-mhcr\Scripts\mhcr.exe failure-matrix
.\.venv-mhcr\Scripts\mhcr.exe longrun
.\.venv-mhcr\Scripts\mhcr.exe acceptance
.\.venv-mhcr\Scripts\mhcr.exe demo
```

## Optional accepted GCM extension

Install the accepted `gcm-reference-runtime 0.4.0` wheel into the same environment, then run:

```bash
mhcr conformance --profile MHCR-GCM-R1
mhcr substrate-demo
mhcr acceptance --with-gcm
```

For a no-activation POSIX flow, use the same commands under `.venv-mhcr/bin/mhcr`.

The GCM profile is not required for standalone core conformance. If `gcm_runtime` is absent, an explicit GCM profile request returns `not_available` rather than converting that absence into a core failure.

## Source-tree development

```bash
PYTHONPATH=src python -m mhcr.cli conformance
PYTHONPATH=src python -m mhcr.cli failure-matrix
PYTHONPATH=src python -m mhcr.cli longrun
PYTHONPATH=src python -m mhcr.cli acceptance
```

## Scope boundary

v1.0 validates a persistent, typed, multi-provider, cost-aware, composable, acquisition-learning, sandbox-generative, optionally GCM-integrated and substrate-aware **reference capability fabric**.

It does not claim production distributed scheduling, physical heterogeneous-hardware certification, arbitrary hostile-code isolation, universal cost omniscience, or AI authority over GCM World/Foundation state.
