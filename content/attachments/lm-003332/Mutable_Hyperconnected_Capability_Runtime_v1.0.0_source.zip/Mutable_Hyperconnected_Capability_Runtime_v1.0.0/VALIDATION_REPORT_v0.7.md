# MHCR v0.7.0 Validation Report

**Milestone:** Sandboxed Constructor  
**Date:** 2026-08-30  
**Branch:** `workbench/mhcr-v0.7-sandboxed-constructor`  
**Baseline:** accepted MHCR v0.6.0 source package

## Scope validated

- Generated candidate artifact model with SHA-256 source provenance and explicit lifecycle.
- SQLite schema v6 with in-place v5 -> v6 migration.
- JSONL replay of generated artifact lifecycle.
- Restrictive AST candidate inspection.
- Generated source never executes in the parent MHCR interpreter.
- Isolated trusted worker process with minimal builtins, sanitized environment, temporary cwd, parent wall timeout, and POSIX resource limits when available.
- Typed sandbox execution / timeout / serialization failures.
- `GeneratedSourceSpec` contains no policy or authority field.
- Sandboxed constructor creates only CANDIDATE capabilities and process-bound providers.
- Existing Runtime verifier remains the only promotion gate.
- Policy/sandbox/verifier failures leave rejection/failure evidence and cannot promote a capability.
- Promoted generated artifacts persist and can rebuild provider executors after restart.
- Binding reconstruction requires active PROMOTED artifact + matching policy + currently TRUSTED capability.
- Capability revocation invalidates generated artifact state.
- Unseen payload reuse after restart remains `cache_hit=False`.
- All v0.1-v0.6 regression behavior remains green.

## Security status

v0.7 implements a **reference defense-in-depth sandbox**, not a production-grade hostile-code isolation boundary.

The reference policy rejects imports, file I/O, socket/subprocess access, eval/exec/import primitives, global/nonlocal mutation, classes/async/yield, private/dunder attribute access, oversized source, and oversized ASTs before generated code executes.

Accepted source executes in a fresh subprocess with a tiny builtin allowlist, scrubbed environment, temporary current directory, parent timeout, and POSIX CPU/address-space limits where supported.

This is useful as an engineering reference boundary, but Python language restrictions are not a substitute for container/microVM/seccomp/hypervisor isolation. Production deployment should wrap or replace `PythonSandboxRunner` with a stronger sandbox provider.

## Automated regression

Command:

```bash
PYTHONPATH=src pytest -q
```

Result:

```text
163 passed
```

A dedicated worker-PID assertion verifies that the sandbox worker PID differs from the parent MHCR process PID.

## Static inspection evidence

Focused tests verify rejection of:

- `import socket`;
- `import subprocess`;
- `open(...)` file access;
- `eval(...)`;
- private/dunder attribute access;
- `global` / `nonlocal` mutation;
- class definitions;
- async functions;
- top-level executable statements;
- invalid entrypoint signatures;
- syntax errors;
- source-byte limit violations;
- AST-node limit violations.

## Sandbox runner evidence

Focused tests verify:

- pure generated computation executes successfully;
- parent secret environment variables are not inherited by the worker;
- worker cwd is an ephemeral temporary directory removed after execution;
- infinite loops are terminated by the parent timeout;
- generated runtime exceptions are returned as typed sandbox errors;
- non-JSON-serializable outputs are rejected;
- resource-limit support is observable without exposing `os` or `resource` to generated globals;
- generated execution occurs in a different process from the MHCR parent.

## Generated candidate lifecycle evidence

Reference flow:

```text
GeneratedSourceSpec
-> GeneratedCandidateArtifact(PROPOSED)
-> INSPECTED
-> SANDBOX_TESTED
-> Capability(CANDIDATE)
-> sandbox provider execution
-> task verifier
-> registry.promote
-> artifact PROMOTED
```

No constructor method has promotion authority.

Policy rejection and sandbox failure occur before capability registration. Task verifier failure leaves the capability as `CANDIDATE` and marks the artifact `REJECTED`.

## Restart / unseen reuse demo

Observed v0.7 demo section:

```json
{
  "artifact_source_hash_matches": true,
  "constructor_invocations": 1,
  "first_artifact_status": "promoted",
  "first_capability_trust": "trusted",
  "first_source": "constructed",
  "first_value": 36,
  "restart_cache_hit": false,
  "restart_execution_path": "fast",
  "restart_source": "resolved",
  "restart_value": 81,
  "sandbox_provider_boundary": "process"
}
```

This demonstrates:

1. first unseen task generates source, enters sandbox, verifies, and promotes;
2. source SHA-256 provenance is stable;
3. provider realization is process-bound rather than direct in-process execution;
4. SQLite restart preserves capability/provider/artifact state;
5. provider executor is reconstructed from the persisted promoted artifact;
6. a different unseen payload uses the trusted fast path;
7. no answer-cache path is used.

## Schema migration

A manually constructed schema-v5 database was opened by v0.7.

Observed:

```text
MIGRATION_SCHEMA 6
ARTIFACT_ROWS 0
```

Existing v5 state remains readable and the new generated-artifact table is created empty.

## v0.6 acquisition-learning regression retained

Observed deterministic acquisition benchmark remains:

```text
stateless total work: 32
persistent total work: 14
stateless post-first mean: 8
persistent post-first mean: 2
stateless constructors: 4
persistent constructors: 1
persistent solver memory hits: 3
persistent verifier memory hits: 3
all cache hits: false
```

The v0.7 sandbox does not erase or replace the v0.6 solver-learning evidence.

## Resolver benchmark sample

Environment sample from the release candidate:

```text
registry size: 1000
iterations: 500
indexed: 252.352 ns/lookup
full scan: 47589.974 ns/lookup
ratio: ~188.59x
```

This is an environment-specific relative sample, not a cross-hardware guarantee.

## Build and clean-install validation

Commands:

```bash
python -m compileall -q src
python -m pip wheel . --no-deps --no-build-isolation -w dist
python -m venv <clean-venv>
<clean-venv>/bin/pip install --no-deps dist/mhcr-0.7.0-py3-none-any.whl
<clean-venv>/bin/python -m mhcr.demo
```

Observed installed package version:

```text
0.7.0
```

The installed demo reproduced the same generated-sandbox promotion/restart/unseen-reuse result.

## Core invariants retained

- What != How
- Capability != Provider
- Candidate != Trusted
- Capability != Authority
- Sandbox Pass != Verification Pass
- Generated Artifact != Trusted Capability
- Generated code != Parent Runtime execution
- Execution Success != Verification Success
- Local Cost != Closed Cost
- Routing Profile != Closed Accounting Certificate
- Unknown != 0
- Provider Failure != Capability Nonexistence
- Composite Capability != Frozen Provider Route
- Exact Task != Lossy Bridge
- No Solver Found != No Solver Exists
- Remembering Answers != Learning Solvers
- Memory != Authority
- Registered != Available != Executable != Verified

## Deliberate v0.7 limits

- Restricted Python subset only; imports/packages are not available to generated programs.
- JSON-compatible payloads/results only.
- Reference Python sandbox is not a production hostile-code security boundary.
- No GCM allocator integration.
- No PCMT/heterogeneous substrate routing.
- No distributed constructor federation.
- No self-granted authority or policy elevation.

## Verdict

v0.7 satisfies its milestone target: generated Python solver source can be proposed, persisted, statically inspected, executed outside the MHCR process under a restrictive reference sandbox, independently verified, promoted through the existing trust gate, restored across SQLite restart, and reused on an unseen payload without answer caching. Forbidden or failing candidates do not become trusted capabilities.
