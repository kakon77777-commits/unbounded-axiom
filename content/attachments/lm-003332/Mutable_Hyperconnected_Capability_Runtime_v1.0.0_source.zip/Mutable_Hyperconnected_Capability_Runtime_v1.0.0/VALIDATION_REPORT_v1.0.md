# MHCR v1.0 Final Convergence — Source Validation Report

**Date:** 2026-08-31  
**Package version:** `1.0.0`  
**Branch:** `workbench/mhcr-v1.0-final-convergence`  
**Baseline:** immutable MHCR v0.9.0 source archive  
**Scope:** source-level final-convergence validation before external wheel/ZIP seal

## 0. Final-convergence scope

v1.0 does not add a new computation family. It adds release verification surfaces around the v0.1–v0.9 runtime:

- `MHCR-CORE-R1` — 32 required conformance cases;
- `MHCR-FAILURE-R1` — F01–F10 executable failure matrix;
- 32-unseen-task durable long-run convergence benchmark;
- final acceptance conjunction;
- optional `MHCR-GCM-R1` — 8 required accepted-GCM extension cases;
- installed developer CLI / packaged manifests / literal Quickstart.

SQLite remains schema **8**.

## 1. Core conformance

`run_conformance("MHCR-CORE-R1")` validates exactly 32 required cases.

Observed source result:

```text
required_passed = 32
required_failed = 0
required_indeterminate = 0
claim = CONFORMANT
```

The profile spans candidate promotion, unseen reuse, persistent fast path, provider health/boundary/accounting, cost routing, typed composition, composite invalidation, acquisition memory/no-answer-cache, sandbox promotion/restart, optional-GCM separation, substrate vocabulary/hardware honesty, append-only history, schema-8 continuity, resolver evidence and World-commit isolation.

## 2. Failure matrix

`run_failure_matrix()` result:

```text
F01..F10 = 10/10 PASS
```

The matrix includes unavailable provider refusal, unknown hard-cost fail-closed behavior, failed external accounting responsibility, transitive composite invalidation, known-failed acquisition suppression, no-answer-cache, sandbox static rejection, sandbox timeout rejection, generated-artifact revoke/rebind refusal and restart/replay truth.

## 3. Long-run convergence

`run_longrun(payload_count=32, restart_interval=8)` validates:

- 32 distinct unseen payloads;
- stateless solver acquisition on every task;
- persistent constructor invocation count = 1;
- three real SQLite close/reopen cycles;
- explicit provider executor rebinding after restart;
- all persistent post-first tasks on fast path;
- all cache hits false;
- solver / verification memory reuse survives restart;
- final capability remains trusted;
- schema version remains 8;
- indexed resolver remains faster than the linear reference scan in the current environment.

Timing ratios are environment-relative benchmark evidence only.

## 4. Sandbox final-convergence hardening

During historical-demo convergence validation, a normal generated-square sandbox worker was observed exiting with POSIX `SIGXCPU` (`returncode = -24`). Root-cause inspection confirmed:

- the worker is executed by direct script path under `python -I`;
- generated code was not responsible for excessive work;
- the default reference policy used `timeout_seconds = 2.0` but `cpu_seconds = 1`;
- the 1-second RLIMIT_CPU soft limit could therefore kill a normal worker under a heavily loaded convergence run before the 2-second wall limit.

Minimal repair:

```text
SandboxPolicy.cpu_seconds: 1 -> 2
SandboxPolicy.timeout_seconds: unchanged at 2.0
```

Security boundaries remain unchanged:

- imports/file/network/shell remain forbidden by default;
- memory cap remains unchanged;
- subprocess isolation remains unchanged;
- explicit tight timeout tests still use their own stricter policies.

Post-repair focused sandbox suite: **19/19 PASS**. The previously failing historical demo was then repeated **3/3 PASS**.

## 5. Source regression

Standalone source selection excluding historical `test_demo.py` and optional-GCM-only modules:

```text
187 tests collected
187 PASS
```

Historical demo coverage:

```text
10 tests total
first shard = 5/5 PASS
remaining public/acquisition shard = 3/3 PASS
sandbox-heavy final cases = 2/2 PASS
```

Therefore standalone source coverage is:

```text
197/197 PASS
```

## 6. Accepted-GCM extension regression

Accepted GCM candidate source used for validation:

```text
GCM_Phase_C_C2_Goal_Decomposition_Candidate_Proposal_FINAL_CANDIDATE.zip
package = gcm-reference-runtime 0.4.0
```

Focused extension collection:

```text
25 tests collected
```

Observed shards:

```text
v1 GCM profile / acceptance          2/2 PASS
v0.8 GCM adapter/runtime/policy     11/11 PASS
v0.9 substrate integration/runtime  11/11 PASS
substrate demo                        1/1 PASS
-----------------------------------------------
TOTAL                                25/25 PASS
```

`MHCR-GCM-R1` itself reports **8/8 required PASS**.

## 7. Package contract before artifact seal

Source checks confirm:

- project version = `1.0.0`;
- console script = `mhcr = mhcr.cli:main`;
- core wheel still declares no hard GCM dependency;
- v1 conformance manifests are package resources;
- SQLite schema remains 8;
- POSIX and Windows literal no-activation Quickstart commands are documented.

## 8. Source hygiene

```text
python -m compileall -q src  -> PASS
git diff --check             -> PASS
```

## 9. Artifact-seal rule

This source report is committed before external artifact construction. The immutable final source commit must subsequently pass, without source modification:

1. standalone source shards;
2. accepted-GCM focused shards;
3. clean standalone wheel install and literal Quickstart commands;
4. clean dual MHCR+GCM wheel extension gate;
5. final source ZIP extraction and regression;
6. SHA-256 manifest verification.

The delivery-level validation report carries the final commit and artifact hashes after those steps complete.
