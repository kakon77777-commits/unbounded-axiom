# MHCR v0.3.0 Validation Report

**Date:** 2026-08-30  
**Branch:** `workbench/mhcr-v0.3-provider-fabric`  
**Baseline:** MHCR v0.2.0 accepted source

## Scope validated

- Provider taxonomy: local Python, subprocess, container, HTTP, LAN worker, remote API.
- Provider health states and execution boundaries.
- SQLite schema v2 with automatic v0.2 schema-v1 migration.
- Persistent provider kind/health/boundary/endpoint metadata without serializing executors.
- Registry and JSONL replay preservation of provider transport metadata and health state.
- Stdlib local Python adapter.
- Real JSON-over-stdin/stdout subprocess adapter.
- Real loopback JSON-over-HTTP adapter.
- Container/subprocess and LAN/remote/HTTP transport-contract aliases with distinct semantic provider kinds.
- Health-aware RDR provider eligibility and stable manifest ordering within the same health tier.
- Provider failover: execution failure marks only the failed provider unavailable and does not revoke the capability.
- External/process boundary-crossing evidence.
- Failed provider attempts remain inside GCAL responsibility closure.
- Unknown remote/process cost remains unknown and yields incomplete closed accounting rather than zero.
- Persistent restart behavior: an unavailable provider remains ineligible even after its executor is rebound.
- v0.2 fast-path, persistence, resolver benchmark, constructor/promotion, verification, and accounting behavior retained.

## Automated tests

Command:

```bash
PYTHONPATH=src pytest -q
```

Fresh result on the v0.3 release tree:

```text
65 passed
```

The suite includes all prior v0.1/v0.2 regression coverage plus provider metadata, schema migration, adapters, health/failover, boundary/accounting, restart, replay, and public API tests.

## Compile validation

Command:

```bash
python -m compileall -q src
```

Result: exit 0.

## Provider Fabric demo

Command:

```bash
PYTHONPATH=src python -m mhcr.demo
```

Observed provider-fabric evidence:

```json
{
  "first_value": 18,
  "first_accounting": "accounting_incomplete",
  "failed_provider_health": "unavailable",
  "restart_value": 22,
  "restart_execution_path": "fast",
  "restart_failed_provider_health": "unavailable",
  "capability_trust": "trusted",
  "boundary_events": 1,
  "failure_events": 1,
  "replay_provider_kind": "subprocess",
  "replay_provider_health": "unavailable"
}
```

Interpretation:

1. one trusted `double` capability declares a process provider and a local provider;
2. the process provider is attempted first and crosses a process boundary;
3. it fails, is marked `UNAVAILABLE`, and remains part of the task accounting closure;
4. local failover returns the correct result;
5. the capability remains `TRUSTED`;
6. after SQLite restart and executor rebinding, the failed provider remains unavailable and the local provider serves the next unseen input through the fast path;
7. JSONL replay reconstructs the process provider kind and unavailable health state.

The same demo also retains the v0.2 capability-compounding proof: `square(4)` is constructed/promoted once and `square(7)` resolves the persisted capability through the fast path after restart.

## Resolver performance sample

The release-tree demo measured a 1000-capability synthetic registry at approximately:

- indexed exact lookup: **314.5 ns / lookup**;
- v0.1-style full scan: **43,878.9 ns / lookup**;
- measured ratio: **139.5x**.

The clean-installed wheel demo measured approximately **158.6x** in the same environment. These are environment-relative samples, not cross-hardware latency guarantees. The v0.3 Provider Fabric does not replace or weaken the v0.2 indexed fast path.

## Wheel build and clean-install validation

Build command:

```bash
python -m pip wheel . --no-deps --no-build-isolation -w dist
```

Result: `mhcr-0.3.0-py3-none-any.whl` built successfully.

The wheel was installed into a fresh venv with `--no-deps`.

Verified inside the clean venv:

```text
installed_version 0.3.0
provider_kind remote_api
```

`python -m mhcr.demo` then reproduced the persistent capability and Provider Fabric demo successfully.

## SQLite migration boundary

v0.3 moves the local reference schema from version 1 to version 2. Opening a v0.2 database migrates the provider table in place and preserves legacy provider meaning with defaults:

- kind = `LOCAL_PYTHON`;
- health = `HEALTHY`;
- boundary = `LOCAL`;
- endpoint = `None`.

Executors remain explicit runtime bindings and are not serialized into SQLite or JSONL.

## Deliberate v0.3 limits

- Provider ranking is health-aware only; cost/price/latency utility ranking is deferred to v0.4.
- No service discovery or distributed scheduler.
- No automatic credentials persistence.
- No unrestricted generated-code execution.
- No GCM allocator integration.
- No PCMT / heterogeneous-substrate routing.
- Container support is an explicit command transport contract; Docker/Podman is not a runtime dependency.
- GCAL remains an accountable known/estimated/unknown model rather than a universal physical-cost oracle.

## Verdict

MHCR v0.3.0 satisfies the Provider Fabric milestone: a semantic capability can have multiple typed provider realizations across execution boundaries; provider health and transport metadata persist and replay; failures can trigger provider-local health degradation and failover without changing capability trust; external attempts remain visible in boundary evidence and closed-responsibility accounting; and the v0.2 persistent fast path remains intact.
