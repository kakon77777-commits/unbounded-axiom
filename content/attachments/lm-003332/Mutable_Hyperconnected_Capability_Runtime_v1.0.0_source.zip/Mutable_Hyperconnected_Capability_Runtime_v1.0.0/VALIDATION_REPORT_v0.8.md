# MHCR v0.8.0 Validation Report

**Milestone:** MHCR v0.8 — GCM Compute Orchestrator Integration  
**Date:** 2026-08-30  
**Package version:** `0.8.0`  
**SQLite schema:** `7`  
**Engineering branch:** `workbench/mhcr-v0.8-gcm-compute-orchestrator`

## 1. Canonical baseline

v0.8 began from the accepted MHCR v0.7 source package:

```text
Mutable_Hyperconnected_Capability_Runtime_v0.7.0_source.zip
```

Fresh pre-v0.8 baseline verification:

```text
163 / 163 PASS
package version = 0.7.0
```

The GCM integration target was not reconstructed from prose. The implementation was tested against the actual accepted GCM C2 delivery candidate:

```text
GCM_Phase_C_C2_Goal_Decomposition_Candidate_Proposal_FINAL_CANDIDATE.zip
SHA-256 = c11895b856100285710d97b8996ee9fa1e5d12c8f9796ec8fecc9d2ede3584bc
package = gcm-reference-runtime 0.4.0
```

MHCR v0.8 consumes only the already sealed/validated GCM **Phase-B deterministic allocator public APIs**. It does not depend on or exercise GCM Phase-C AI proposal authority.

## 2. v0.8 scope

v0.8 implements the separation:

```text
Capability Selection
-> GCM Logical Allocation
-> MHCR Provider Binding
-> Execution
-> Verification
-> GCAL / History
```

The core invariants are:

```text
Capability Selection != Compute Allocation
GCM Allocation != Provider Execution
GCM Allocation != Authority Grant
GCM Allocation != World Commit
No GCM Adapter => v0.7 behavior
```

The GCM dependency is optional and lazily imported. Standalone MHCR installation, import, testing, and normal runtime behavior do not require `gcm_runtime`.

## 3. Production changes

### 3.1 GCM binding contracts

Added `src/mhcr/gcm_integration.py` with:

- `GCMCapacityBinding`
- `GCMProviderBinding`
- `GCMAllocationContext`
- `GCMAllocationDecision`
- `GCMResourceBindingStore`
- `GCMIntegrationError`
- `GCMUnavailableError`
- `GCMAllocationRejectedError`
- `GCMPhaseBAdapter`

A provider may expose multiple GCM configurations. Capacity and required-demand values are canonical non-negative integer evidence; bindings contain metadata only and do not serialize provider callables.

### 3.2 Persistence

SQLite schema was migrated from v6 to v7 with persistent `gcm_resource_bindings` storage. JSONL history records binding upsert/removal and can replay the binding catalog.

### 3.3 Actual GCM Phase-B adapter

`GCMPhaseBAdapter` lazily imports the actual GCM package and performs the real public-contract sequence:

```text
B2 ResourceRecord / ResourceInventorySnapshot
-> B1 ComputationIntent / OperationRequest / PlanningContext / CandidateSpec
-> evaluate_and_select
-> build_allocation_candidates
-> AllocationRequest
-> B3 Allocator0.allocate
-> GCMAllocationDecision
```

MHCR does not reimplement GCM `Allocator0`.

### 3.4 Runtime allocation gate

When `MHCRRuntime` has no compute allocator, existing v0.7 semantics are retained.

When configured with a compute allocator:

1. RDR produces its existing health/policy ordered provider surface;
2. GCM performs logical resource/capacity allocation;
3. the selected provider becomes the execution allowlist;
4. RDR may execute only that selected provider.

If the allocated provider fails at execution time, v0.8 does not silently use an unallocated fallback. GCM/B5-aware replanning is deliberately out of v0.8 scope.

### 3.5 Policy and cost evidence

Existing MHCR provider cost evidence is mapped into GCM candidate estimates without converting missing information into zero. Task hard limits map into the GCM B1 hard-limit boundary. Therefore missing required estimate evidence fails closed inside GCM rather than being treated as cheap/free.

## 4. Test additions

Dedicated v0.8 tests cover:

- binding validation, SQLite v6->v7 migration, round-trip, and JSONL replay;
- optional GCM dependency behavior;
- actual GCM B1/B2/B3 adapter behavior;
- feasible GPU allocation;
- GPU capacity insufficiency with deterministic CPU fallback inside B3;
- all-capacity-insufficient typed rejection;
- allocation-gated provider execution;
- no bypass to unallocated failover provider;
- no-adapter v0.7 compatibility;
- provider policy + GCM resource-feasibility layering;
- missing hard-limit evidence fail-closed;
- restart persistence and deterministic semantic allocation;
- independent v0.8 GCM integration demo.

## 5. Standalone MHCR gate

Command:

```bash
PYTHONPATH=src pytest -ra
```

Fresh result before release freeze:

```text
174 passed, 3 skipped
```

The three skips are exactly the tests that require the optional GCM package:

```text
tests/test_gcm_demo.py
tests/test_gcm_phase_b_adapter.py
tests/test_gcm_policy_resource_routing.py
```

This is the explicit evidence that GCM remains optional rather than becoming an undeclared MHCR runtime dependency.

## 6. Accepted-GCM source integration gate

Using the exact accepted GCM candidate source on `PYTHONPATH`, the focused integration gates were run separately to avoid conflating two large test suites with v0.7 sandbox subprocess timing.

Results:

```text
binding + adapter focused suite: 10 PASS
runtime gate + policy suite:      8 PASS
GCM demo suite:                   1 PASS
----------------------------------------
true-GCM focused total:          19 PASS
```

A previous attempt to run the entire MHCR suite with GCM source globally added to `PYTHONPATH` exceeded the execution-harness time limit because many sandbox tests spawn subprocesses. That timed-out aggregate run is not counted as evidence. The standalone full regression and focused real-GCM gates above are the release criteria.

## 7. Compile and migration gates

```text
python -m compileall -q src -> PASS
SQLite v6 -> v7 migration probe -> PASS
```

Migration preserves existing MHCR capability/provider/acquisition/sandbox state while adding the GCM binding catalog.

## 8. Clean dual-wheel integration gate

Two wheels were built locally from source without network dependency resolution:

```text
mhcr-0.8.0-py3-none-any.whl
gcm_reference_runtime-0.4.0-py3-none-any.whl
```

A fresh venv was created and both local wheels installed. Because this execution environment is offline and no local `jsonschema` wheelhouse was available, the integration venv used `--system-site-packages` solely to satisfy the already-installed GCM `jsonschema` dependency. Both MHCR and GCM package code itself was loaded from the fresh venv `site-packages`, verified by module origin and package version:

```text
mhcr version = 0.8.0
gcm version  = 0.4.0
mhcr origin  = <fresh venv>/site-packages/mhcr/__init__.py
gcm origin   = <fresh venv>/site-packages/gcm_runtime/__init__.py
```

Installed command:

```bash
python -m mhcr.gcm_demo
```

produced the same semantic result as the source-tree integration demo.

## 9. v0.8 demo evidence

The independent `mhcr.gcm_demo` scenario demonstrates:

1. GPU is preferred and selected when feasible;
2. after reducing GPU logical capacity, GCM B3 deterministically selects CPU;
3. after SQLite restart the binding catalog restores both bindings;
4. the post-restart allocation repeats the same CPU semantic decision;
5. the integration emits no GCM World-commit event.

Representative semantic structure:

```json
{
  "allocation_events": 3,
  "gpu_feasible": {"provider_id": "provider.gpu"},
  "gpu_capacity_fallback": {"provider_id": "provider.cpu"},
  "restart": {"provider_id": "provider.cpu", "binding_count": 2},
  "world_commit_events": 0
}
```

Allocation IDs/snapshot IDs are evidence identifiers and are not used as authority grants.

## 10. Authority and semantic boundaries

v0.8 does **not** claim:

- physical CPU/GPU reservation;
- production resource enforcement;
- GCM World or Foundation mutation;
- GCM CommitGate authority;
- GCM Phase-C AI orchestration authority;
- distributed scheduling;
- B5 automatic replanning after execution failure;
- PCMT / 24-72 generalized substrate routing.

The strongest correct statement is:

> MHCR v0.8 can optionally bridge an already selected capability/provider surface into the accepted GCM Phase-B deterministic logical allocator, receive an immutable logical allocation decision, and gate MHCR execution to the selected provider while preserving MHCR trust/verification/accounting boundaries and GCM authority/World-mutation boundaries.

## 11. Verdict

Under the v0.8 reference scope:

```text
Persistent GCM bindings                    PASS
Optional dependency boundary               PASS
Actual accepted GCM B1/B2/B3 integration  PASS
Capacity-constrained fallback              PASS
Missing estimate fail-closed               PASS
Allocation-gated execution                 PASS
No allocation authority escalation         PASS
No World commit                            PASS
Restart persistence                        PASS
Standalone MHCR regression                 PASS
Dual-wheel installed integration           PASS
```

## 12. Pre-seal archive verification

A source archive was generated from the immutable release-evidence code state and extracted into a clean directory. The archive was then revalidated in shards to avoid execution-harness timeout from historical sandbox demos:

```text
archive non-demo/core suite: 164 PASS
archive historical demo shard A: 5 PASS
archive historical demo shard B: 5 PASS
archive compileall: PASS
```

No source mutation was performed by these checks.

**Implementation-side verdict:** `MHCR v0.8 = IMPLEMENTATION VALIDATED / READY FOR FINAL ARTIFACT SEAL`. The final delivery ZIP/wheel SHA-256 manifest is intentionally generated outside the immutable source commit to avoid recursive self-checksum coupling.
