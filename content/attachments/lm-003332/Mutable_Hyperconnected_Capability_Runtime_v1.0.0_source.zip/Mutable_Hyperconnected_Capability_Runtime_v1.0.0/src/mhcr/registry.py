from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

from .history import Event, EventLog
from .models import Capability, Provider, ProviderHealth, TrustState
from .repository import ProviderRecord, RegistryRepository


SemanticKey = tuple[str, str, str, str]


class CapabilityRegistry:
    def __init__(
        self,
        repository: RegistryRepository | None = None,
        event_log: EventLog | None = None,
    ) -> None:
        self._capabilities: dict[str, Capability] = {}
        self._providers: dict[str, Provider] = {}
        self._repository = repository
        self._event_log = event_log
        self._trusted_index: dict[SemanticKey, list[str]] = {}
        self._indexed_lookup_count = 0
        self._invalidation_listeners: list[Callable[[str, str], None]] = []


    @staticmethod
    def _capability_event_data(capability: Capability) -> dict[str, Any]:
        return {
            "capability_id": capability.capability_id,
            "version": capability.version,
            "task_family": capability.task_family,
            "input_type": capability.input_type,
            "output_type": capability.output_type,
            "exactness": capability.exactness,
            "provider_ids": list(capability.provider_ids),
            "verifier_id": capability.verifier_id,
            "trust_state": capability.trust_state.value,
            "scope": capability.scope,
            "fidelity": capability.fidelity.value,
            "component_capability_ids": list(capability.component_capability_ids),
        }

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self._event_log is not None:
            self._event_log.append(Event(event_type, data))

    @staticmethod
    def _semantic_key(capability: Capability) -> SemanticKey:
        return (
            capability.task_family,
            capability.input_type,
            capability.output_type,
            capability.exactness,
        )

    def _deindex(self, capability_id: str) -> None:
        empty: list[SemanticKey] = []
        for key, capability_ids in self._trusted_index.items():
            if capability_id in capability_ids:
                capability_ids[:] = [item for item in capability_ids if item != capability_id]
            if not capability_ids:
                empty.append(key)
        for key in empty:
            del self._trusted_index[key]

    def _index(self, capability: Capability) -> None:
        self._deindex(capability.capability_id)
        if capability.trust_state is not TrustState.TRUSTED:
            return
        key = self._semantic_key(capability)
        bucket = self._trusted_index.setdefault(key, [])
        if capability.capability_id not in bucket:
            bucket.append(capability.capability_id)

    def _rebuild_trusted_index(self) -> None:
        self._trusted_index.clear()
        for capability in self._capabilities.values():
            self._index(capability)

    @property
    def indexed_lookup_count(self) -> int:
        return self._indexed_lookup_count

    @property
    def repository(self) -> RegistryRepository | None:
        return self._repository

    def add_invalidation_listener(self, listener: Callable[[str, str], None]) -> None:
        self._invalidation_listeners.append(listener)

    def _notify_invalidation(self, capability_id: str, reason: str) -> None:
        for listener in tuple(self._invalidation_listeners):
            listener(capability_id, reason)


    @classmethod
    def from_repository(
        cls,
        repository: RegistryRepository,
        provider_executors: Mapping[str, Callable[[Any], Any]] | None = None,
        event_log: EventLog | None = None,
    ) -> "CapabilityRegistry":
        registry = cls(repository=repository, event_log=event_log)
        registry._capabilities = {
            capability.capability_id: capability
            for capability in repository.load_capabilities()
        }
        registry._rebuild_trusted_index()
        executors = provider_executors or {}
        for record in repository.load_provider_records():
            bound_executor = executors.get(record.provider_id)
            active = record.active and bound_executor is not None
            if bound_executor is None:
                provider_id = record.provider_id

                def unavailable_executor(_payload: Any, *, _provider_id: str = provider_id) -> Any:
                    raise RuntimeError(f"provider executor not bound: {_provider_id}")

                bound_executor = unavailable_executor

            registry._providers[record.provider_id] = Provider(
                record.provider_id,
                record.capability_id,
                bound_executor,
                active=active,
                kind=record.kind,
                health=record.health,
                boundary=record.boundary,
                endpoint=record.endpoint,
            )
        return registry

    def register_capability(self, capability: Capability) -> Capability:
        existing = self._capabilities.get(capability.capability_id)
        if existing and existing.trust_state is TrustState.REVOKED:
            raise ValueError("revoked capability cannot be overwritten")
        if existing and existing.major_version == capability.major_version:
            if (
                existing.task_family,
                existing.input_type,
                existing.output_type,
                existing.exactness,
            ) != (
                capability.task_family,
                capability.input_type,
                capability.output_type,
                capability.exactness,
            ):
                raise ValueError("incompatible semantic contract for same capability major version")
        self._capabilities[capability.capability_id] = capability
        self._index(capability)
        if self._repository is not None:
            self._repository.save_capability(capability)
        self._emit("REGISTRY_CAPABILITY_UPSERTED", self._capability_event_data(capability))
        return capability

    def _persist_provider(self, provider: Provider) -> None:
        if self._repository is not None:
            self._repository.save_provider(
                ProviderRecord(
                    provider.provider_id,
                    provider.capability_id,
                    provider.active,
                    provider.kind,
                    provider.health,
                    provider.boundary,
                    provider.endpoint,
                )
            )

    @staticmethod
    def _provider_event_data(provider: Provider) -> dict[str, Any]:
        return {
            "provider_id": provider.provider_id,
            "capability_id": provider.capability_id,
            "active": provider.active,
            "kind": provider.kind.value,
            "health": provider.health.value,
            "boundary": provider.boundary.value,
            "endpoint": provider.endpoint,
        }

    def register_provider(self, provider: Provider) -> Provider:
        if provider.capability_id not in self._capabilities:
            raise KeyError(f"unknown capability: {provider.capability_id}")
        existing = self._providers.get(provider.provider_id)
        if existing is not None and existing.capability_id != provider.capability_id:
            raise ValueError("provider id already bound to different capability")
        self._providers[provider.provider_id] = provider
        self._persist_provider(provider)
        self._emit("REGISTRY_PROVIDER_UPSERTED", self._provider_event_data(provider))
        return provider

    def set_provider_health(self, provider_id: str, health: ProviderHealth) -> Provider:
        provider = self._providers[provider_id]
        updated = provider.with_health(health)
        self._providers[provider_id] = updated
        self._persist_provider(updated)
        self._emit(
            "REGISTRY_PROVIDER_HEALTH_CHANGED",
            {"provider_id": provider_id, "health": health.value},
        )
        return updated

    def get_capability(self, capability_id: str) -> Capability:
        return self._capabilities[capability_id]

    def get_provider(self, provider_id: str) -> Provider:
        return self._providers[provider_id]

    def find_trusted(
        self,
        *,
        task_family: str,
        input_type: str,
        output_type: str,
        exactness: str,
    ) -> list[Capability]:
        self._indexed_lookup_count += 1
        key = (task_family, input_type, output_type, exactness)
        capability_ids = self._trusted_index.get(key, ())
        return [self._capabilities[capability_id] for capability_id in capability_ids]

    def promote(self, capability_id: str, verification) -> Capability:
        if not getattr(verification, "passed", False):
            raise ValueError("verification did not pass")
        capability = self._capabilities[capability_id]
        if capability.trust_state is TrustState.REVOKED:
            raise ValueError("revoked capability cannot be promoted")
        promoted = capability.with_trust_state(TrustState.TRUSTED)
        self._capabilities[capability_id] = promoted
        self._index(promoted)
        if self._repository is not None:
            self._repository.save_capability(promoted)
        self._emit("REGISTRY_CAPABILITY_PROMOTED", {"capability_id": capability_id})
        return promoted

    def _invalidate_composite_dependents(self, dependency_id: str) -> None:
        queue = [dependency_id]
        seen: set[str] = set()
        while queue:
            current = queue.pop(0)
            if current in seen:
                continue
            seen.add(current)
            dependents = sorted(
                (
                    capability
                    for capability in self._capabilities.values()
                    if capability.is_composite
                    and capability.trust_state is TrustState.TRUSTED
                    and current in capability.component_capability_ids
                ),
                key=lambda capability: capability.capability_id,
            )
            for capability in dependents:
                updated = capability.with_trust_state(TrustState.DEPRECATED)
                self._capabilities[capability.capability_id] = updated
                self._index(updated)
                if self._repository is not None:
                    self._repository.save_capability(updated)
                self._emit(
                    "REGISTRY_COMPOSITE_INVALIDATED",
                    {
                        "capability_id": capability.capability_id,
                        "dependency_id": current,
                        "trust_state": TrustState.DEPRECATED.value,
                    },
                )
                self._notify_invalidation(
                    capability.capability_id, f"deprecated: dependency {current} invalidated"
                )
                queue.append(capability.capability_id)

    def revoke(self, capability_id: str) -> Capability:
        capability = self._capabilities[capability_id].with_trust_state(TrustState.REVOKED)
        self._capabilities[capability_id] = capability
        self._index(capability)
        if self._repository is not None:
            self._repository.save_capability(capability)
        self._emit("REGISTRY_CAPABILITY_REVOKED", {"capability_id": capability_id})
        self._notify_invalidation(capability_id, "revoked capability")
        self._invalidate_composite_dependents(capability_id)
        return capability

    def replace_capability(self, capability: Capability) -> Capability:
        if capability.capability_id not in self._capabilities:
            raise KeyError(capability.capability_id)
        self._capabilities[capability.capability_id] = capability
        self._index(capability)
        if self._repository is not None:
            self._repository.save_capability(capability)
        self._emit("REGISTRY_CAPABILITY_UPSERTED", self._capability_event_data(capability))
        return capability

    def capabilities(self) -> tuple[Capability, ...]:
        return tuple(self._capabilities.values())

    def providers_for(self, capability_id: str, *, active_only: bool = True) -> list[Provider]:
        providers = [p for p in self._providers.values() if p.capability_id == capability_id]
        if active_only:
            providers = [p for p in providers if p.active]
        return providers
