from __future__ import annotations

import argparse
import json


def _emit(payload) -> None:
    if hasattr(payload, "as_dict"):
        payload = payload.as_dict()
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mhcr", description="MHCR v1 reference runtime developer CLI")
    sub = parser.add_subparsers(dest="command")

    conformance = sub.add_parser("conformance", help="run machine-verifiable conformance")
    conformance.add_argument("--profile", default="MHCR-CORE-R1")
    sub.add_parser("failure-matrix", help="run v1 failure matrix")
    sub.add_parser("longrun", help="run persistent long-run benchmark")
    acceptance = sub.add_parser("acceptance", help="run final v1 acceptance gate")
    acceptance.add_argument("--with-gcm", action="store_true")
    sub.add_parser("demo", help="run canonical standalone demo")
    sub.add_parser("substrate-demo", help="run optional GCM/substrate demo")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 0
    if args.command == "conformance":
        from .conformance import ConformanceClaim, run_conformance
        result = run_conformance(args.profile)
        _emit(result)
        if result.claim is ConformanceClaim.CONFORMANT:
            return 0
        if result.claim is ConformanceClaim.NOT_AVAILABLE:
            return 3
        return 2
    if args.command == "demo":
        from .demo import build_demo
        _emit(build_demo())
        return 0
    if args.command == "substrate-demo":
        from .substrate_demo import run_demo
        _emit(run_demo())
        return 0
    if args.command == "failure-matrix":
        from .failure_matrix import run_failure_matrix
        result = run_failure_matrix()
        _emit(result)
        return 0 if result.passed else 2
    if args.command == "longrun":
        from .longrun import run_longrun
        result = run_longrun()
        _emit(result)
        return 0 if result.passed else 2
    if args.command == "acceptance":
        from .acceptance import run_acceptance
        result = run_acceptance(include_gcm=args.with_gcm)
        _emit(result)
        return 0 if result.accepted else 2
    raise AssertionError(args.command)


if __name__ == "__main__":
    raise SystemExit(main())
