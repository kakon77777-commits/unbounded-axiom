from __future__ import annotations

from dataclasses import dataclass
import heapq
from typing import TYPE_CHECKING

from .models import Capability, TaskContract, TransitionFidelity, TrustState
from .routing import CostMetric

if TYPE_CHECKING:
    from .rdr import RDR
    from .registry import CapabilityRegistry


@dataclass(frozen=True, slots=True)
class CompositionPlan:
    capabilities: tuple[Capability, ...]
    provider_ids: tuple[str, ...]
    score: float
    graph_expansions: int

    @property
    def capability_ids(self) -> tuple[str, ...]:
        return tuple(capability.capability_id for capability in self.capabilities)


class CompositionPlanner:
    def __init__(self, registry: "CapabilityRegistry", rdr: "RDR | None" = None) -> None:
        self.registry = registry
        self.rdr = rdr
        self.search_invocations = 0
        self.graph_expansions_total = 0
        self.last_graph_expansions = 0

    @staticmethod
    def _capability_allowed(capability: Capability, task: TaskContract) -> bool:
        if capability.trust_state is not TrustState.TRUSTED:
            return False
        if capability.is_composite:
            # Direct composites are resolved by the semantic index. Graph search
            # operates over primitive capabilities to keep lineage explicit.
            return False
        if task.exactness == "exact":
            return (
                capability.exactness == "exact"
                and capability.fidelity is TransitionFidelity.EXACT
            )
        if capability.exactness not in {"exact", task.exactness}:
            return False
        return True

    @staticmethod
    def _weighted_metric(metric: CostMetric, weight: float, unknown_penalty: float) -> float:
        if weight == 0.0:
            return 0.0
        if not metric.known:
            return weight * unknown_penalty
        assert metric.value is not None
        return weight * metric.value

    def _edge_evaluation(
        self,
        capability: Capability,
        task: TaskContract,
    ) -> tuple[float, str | None] | None:
        policy = task.composition_policy
        score = policy.step_weight
        if capability.fidelity is TransitionFidelity.APPROXIMATE:
            score += policy.lossy_penalty * 0.5
        elif capability.fidelity is TransitionFidelity.LOSSY:
            score += policy.lossy_penalty

        if self.rdr is None:
            return score, None

        decision = self.rdr.routing_decision(capability, task.policy)
        if not decision.providers:
            return None
        provider = decision.providers[0]
        profile = self.rdr.cost_catalog.get(provider.provider_id)
        score += self._weighted_metric(
            profile.latency_ms,
            policy.latency_weight,
            policy.unknown_metric_penalty,
        )
        score += self._weighted_metric(
            profile.monetary_cost_usd,
            policy.monetary_weight,
            policy.unknown_metric_penalty,
        )
        score += self._weighted_metric(
            profile.verification_work,
            policy.verification_weight,
            policy.unknown_metric_penalty,
        )
        score += self._weighted_metric(
            profile.risk_score,
            policy.risk_weight,
            policy.unknown_metric_penalty,
        )
        return score, provider.provider_id

    def plan(self, task: TaskContract) -> CompositionPlan | None:
        self.search_invocations += 1
        adjacency: dict[str, list[Capability]] = {}
        for capability in self.registry.capabilities():
            if not self._capability_allowed(capability, task):
                continue
            adjacency.setdefault(capability.input_type, []).append(capability)
        for capabilities in adjacency.values():
            capabilities.sort(key=lambda item: item.capability_id)

        # heap item: score, steps, path ids, current type, type path, provider ids
        heap: list[
            tuple[float, int, tuple[str, ...], str, tuple[str, ...], tuple[str, ...]]
        ] = [(0.0, 0, (), task.input_type, (task.input_type,), ())]
        expansions = 0
        best: dict[tuple[str, int], float] = {(task.input_type, 0): 0.0}

        while heap:
            score, steps, path_ids, current_type, type_path, provider_ids = heapq.heappop(heap)
            expansions += 1
            if current_type == task.output_type and path_ids:
                self.last_graph_expansions = expansions
                self.graph_expansions_total += expansions
                return CompositionPlan(
                    capabilities=tuple(self.registry.get_capability(item) for item in path_ids),
                    provider_ids=provider_ids,
                    score=score,
                    graph_expansions=expansions,
                )
            if steps >= task.composition_policy.max_steps:
                continue

            for capability in adjacency.get(current_type, ()):
                if capability.capability_id in path_ids:
                    continue
                # Avoid type cycles. Reaching the final type is always allowed.
                if capability.output_type in type_path and capability.output_type != task.output_type:
                    continue
                evaluation = self._edge_evaluation(capability, task)
                if evaluation is None:
                    continue
                edge_score, provider_id = evaluation
                next_score = score + edge_score
                next_steps = steps + 1
                state = (capability.output_type, next_steps)
                previous = best.get(state)
                if previous is not None and next_score > previous:
                    continue
                if previous is None or next_score < previous:
                    best[state] = next_score
                next_ids = path_ids + (capability.capability_id,)
                next_providers = provider_ids + ((provider_id,) if provider_id is not None else ())
                heapq.heappush(
                    heap,
                    (
                        next_score,
                        next_steps,
                        next_ids,
                        capability.output_type,
                        type_path + (capability.output_type,),
                        next_providers,
                    ),
                )
        self.last_graph_expansions = expansions
        self.graph_expansions_total += expansions
        return None
