from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tempfile

from .accounting import GCAL
from .acquisition import AcquisitionMemoryKind
from .acquisition_benchmark import benchmark_acquisition_learning
from .benchmark import benchmark_resolver
from .constructor import TemplateConstructor, TemplateSpec
from .history import EventLog
from .models import TaskContract
from .registry import CapabilityRegistry
from .runtime import MHCRRuntime
from .sqlite_repository import SQLiteRepository
from .verification import VerifierRegistry


def _square(value: int) -> int:
    return value * value


def _verifiers() -> VerifierRegistry:
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    return verifiers


@dataclass(frozen=True, slots=True)
class LongRunResult:
    payload_count: int
    restart_interval: int
    restart_count: int
    stateless_total_work: float
    persistent_total_work: float
    stateless_post_first_mean_work: float
    persistent_post_first_mean_work: float
    work_reduction_ratio: float
    stateless_constructor_invocations: int
    persistent_constructor_invocations: int
    persistent_fast_after_first: bool
    all_cache_hits_false: bool
    solver_memory_reuse_count: int
    verification_memory_reuse_count: int
    final_trust_state: str
    schema_version: int
    resolver_speedup_ratio: float
    passed: bool

    def as_dict(self) -> dict[str, object]:
        return {
            "payload_count": self.payload_count,
            "restart_interval": self.restart_interval,
            "restart_count": self.restart_count,
            "stateless_total_work": self.stateless_total_work,
            "persistent_total_work": self.persistent_total_work,
            "stateless_post_first_mean_work": self.stateless_post_first_mean_work,
            "persistent_post_first_mean_work": self.persistent_post_first_mean_work,
            "work_reduction_ratio": self.work_reduction_ratio,
            "stateless_constructor_invocations": self.stateless_constructor_invocations,
            "persistent_constructor_invocations": self.persistent_constructor_invocations,
            "persistent_fast_after_first": self.persistent_fast_after_first,
            "all_cache_hits_false": self.all_cache_hits_false,
            "solver_memory_reuse_count": self.solver_memory_reuse_count,
            "verification_memory_reuse_count": self.verification_memory_reuse_count,
            "final_trust_state": self.final_trust_state,
            "schema_version": self.schema_version,
            "resolver_speedup_ratio": self.resolver_speedup_ratio,
            "passed": self.passed,
        }


def run_longrun(*, payload_count: int = 32, restart_interval: int = 8) -> LongRunResult:
    if payload_count < 2:
        raise ValueError("payload_count must be >= 2")
    if restart_interval < 1:
        raise ValueError("restart_interval must be >= 1")

    payloads = tuple(range(2, 2 + payload_count))
    stateless = benchmark_acquisition_learning(payloads)

    with tempfile.TemporaryDirectory(prefix="mhcr-v1-longrun-") as directory:
        root = Path(directory)
        db_path = root / "mhcr.sqlite3"
        history = EventLog(root / "events.jsonl")
        repo = SQLiteRepository(db_path)
        registry = CapabilityRegistry(repository=repo, event_log=history)
        constructor = TemplateConstructor([
            TemplateSpec("square", "number", "number", _square, "verify.square")
        ])
        runtime = MHCRRuntime(
            registry,
            _verifiers(),
            GCAL(repo),
            history,
            constructor=constructor,
        )

        persistent_work: list[float] = []
        persistent_paths: list[str] = []
        cache_hits: list[bool] = []
        memory_hit_counts = {kind: 0 for kind in AcquisitionMemoryKind}
        restart_count = 0

        for index, payload in enumerate(payloads):
            if index > 0 and index % restart_interval == 0:
                repo.close()
                repo = SQLiteRepository(db_path)
                registry = CapabilityRegistry.from_repository(
                    repo,
                    provider_executors={"provider.generated.square": _square},
                    event_log=history,
                )
                runtime = MHCRRuntime(
                    registry,
                    _verifiers(),
                    GCAL(repo),
                    history,
                    constructor=None,
                )
                restart_count += 1

            solved = runtime.solve(
                TaskContract(f"longrun-{index}", "square", "number", "number", payload)
            )
            if solved.value != payload * payload:
                raise AssertionError("long-run solver returned incorrect value")
            trace = solved.acquisition_trace
            if trace is None:
                raise AssertionError("long-run acquisition trace missing")
            persistent_work.append(trace.acquisition_work)
            persistent_paths.append(solved.execution_path)
            cache_hits.append(solved.cache_hit)
            for kind in trace.memory_hits:
                memory_hit_counts[kind] += 1

        final_capability = registry.get_capability("cap.generated.square")
        final_trust_state = final_capability.trust_state.value
        schema_version = repo.schema_version
        repo.close()

    persistent_total = sum(persistent_work)
    persistent_post_first = sum(persistent_work[1:]) / len(persistent_work[1:])
    resolver = benchmark_resolver(registry_size=5000, iterations=500)
    fast_after_first = all(path == "fast" for path in persistent_paths[1:])
    all_cache_false = not any(cache_hits) and stateless.all_cache_hits_false
    solver_reuse = memory_hit_counts[AcquisitionMemoryKind.SOLVER]
    verification_reuse = memory_hit_counts[AcquisitionMemoryKind.VERIFICATION]
    ratio = stateless.stateless_total_work / persistent_total if persistent_total else float("inf")

    passed = all([
        stateless.stateless_constructor_invocations == payload_count,
        constructor.construct_count == 1,
        restart_count == (payload_count - 1) // restart_interval,
        fast_after_first,
        all_cache_false,
        persistent_total < stateless.stateless_total_work,
        persistent_post_first < stateless.stateless_post_first_mean_work,
        solver_reuse >= payload_count - 1,
        verification_reuse >= payload_count - 1,
        final_trust_state == "trusted",
        schema_version == 8,
        resolver.speedup_ratio > 1.0,
    ])

    return LongRunResult(
        payload_count=payload_count,
        restart_interval=restart_interval,
        restart_count=restart_count,
        stateless_total_work=stateless.stateless_total_work,
        persistent_total_work=persistent_total,
        stateless_post_first_mean_work=stateless.stateless_post_first_mean_work,
        persistent_post_first_mean_work=persistent_post_first,
        work_reduction_ratio=ratio,
        stateless_constructor_invocations=stateless.stateless_constructor_invocations,
        persistent_constructor_invocations=constructor.construct_count,
        persistent_fast_after_first=fast_after_first,
        all_cache_hits_false=all_cache_false,
        solver_memory_reuse_count=solver_reuse,
        verification_memory_reuse_count=verification_reuse,
        final_trust_state=final_trust_state,
        schema_version=schema_version,
        resolver_speedup_ratio=resolver.speedup_ratio,
        passed=passed,
    )
