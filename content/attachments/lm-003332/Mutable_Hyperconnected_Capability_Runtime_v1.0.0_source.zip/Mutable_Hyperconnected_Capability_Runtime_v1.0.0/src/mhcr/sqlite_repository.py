from __future__ import annotations

import json
from pathlib import Path
import sqlite3

from .accounting import CostRecord, CostVector
from .acquisition import AcquisitionMemoryRecord
from .models import (
    Capability, ProviderBoundary, ProviderHealth, ProviderKind,
    TransitionFidelity, TrustState,
)
from .repository import ProviderRecord
from .routing import CostEvidence, CostMetric, ProviderCostProfile
from .sandbox import GeneratedCandidateArtifact
from .gcm_integration import GCMProviderBinding
from .substrate import SubstrateProfile


_SCHEMA_VERSION = 8


class SQLiteRepository:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self.path)
        self._connection.row_factory = sqlite3.Row
        self._initialize_schema()

    def _initialize_schema(self) -> None:
        connection = self._connection
        connection.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS capabilities (
                capability_id TEXT PRIMARY KEY,
                version TEXT NOT NULL,
                task_family TEXT NOT NULL,
                input_type TEXT NOT NULL,
                output_type TEXT NOT NULL,
                exactness TEXT NOT NULL,
                provider_ids_json TEXT NOT NULL,
                verifier_id TEXT,
                trust_state TEXT NOT NULL,
                scope TEXT NOT NULL,
                fidelity TEXT NOT NULL DEFAULT 'exact',
                component_capability_ids_json TEXT NOT NULL DEFAULT '[]'
            );

            CREATE TABLE IF NOT EXISTS providers (
                provider_id TEXT PRIMARY KEY,
                capability_id TEXT NOT NULL,
                active INTEGER NOT NULL,
                kind TEXT NOT NULL DEFAULT 'local_python',
                health TEXT NOT NULL DEFAULT 'healthy',
                boundary TEXT NOT NULL DEFAULT 'local',
                endpoint TEXT
            );

            CREATE TABLE IF NOT EXISTS cost_records (
                node_id TEXT PRIMARY KEY,
                local_work REAL NOT NULL,
                external_work REAL NOT NULL,
                offline_work REAL NOT NULL,
                verification_work REAL NOT NULL,
                monetary_cost REAL NOT NULL,
                known INTEGER NOT NULL,
                shared_cost_id TEXT
            );

            CREATE TABLE IF NOT EXISTS provider_cost_profiles (
                provider_id TEXT PRIMARY KEY,
                profile_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS acquisition_memories (
                memory_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS generated_candidate_artifacts (
                artifact_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS gcm_resource_bindings (
                binding_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS substrate_profiles (
                profile_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            );
            """
        )
        row = connection.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
        if row is None:
            connection.execute(
                "INSERT INTO metadata(key, value) VALUES('schema_version', ?)",
                (str(_SCHEMA_VERSION),),
            )
        else:
            version = int(row["value"])
            if version == 1:
                self._migrate_v1_to_v2()
                version = 2
            if version == 2:
                self._migrate_v2_to_v3()
                version = 3
            if version == 3:
                self._migrate_v3_to_v4()
                version = 4
            if version == 4:
                self._migrate_v4_to_v5()
                version = 5
            if version == 5:
                self._migrate_v5_to_v6()
                version = 6
            if version == 6:
                self._migrate_v6_to_v7()
                version = 7
            if version == 7:
                self._migrate_v7_to_v8()
                version = 8
            if version != _SCHEMA_VERSION:
                raise RuntimeError(f"unsupported schema version: {version}")
        connection.commit()

    def _migrate_v1_to_v2(self) -> None:
        columns = {row["name"] for row in self._connection.execute("PRAGMA table_info(providers)")}
        additions = {
            "kind": "TEXT NOT NULL DEFAULT 'local_python'",
            "health": "TEXT NOT NULL DEFAULT 'healthy'",
            "boundary": "TEXT NOT NULL DEFAULT 'local'",
            "endpoint": "TEXT",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self._connection.execute(f"ALTER TABLE providers ADD COLUMN {name} {declaration}")
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('2',),
        )

    def _migrate_v2_to_v3(self) -> None:
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS provider_cost_profiles (
                provider_id TEXT PRIMARY KEY,
                profile_json TEXT NOT NULL
            )
            """
        )
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('3',),
        )

    def _migrate_v3_to_v4(self) -> None:
        columns = {row["name"] for row in self._connection.execute("PRAGMA table_info(capabilities)")}
        additions = {
            "fidelity": "TEXT NOT NULL DEFAULT 'exact'",
            "component_capability_ids_json": "TEXT NOT NULL DEFAULT '[]'",
        }
        for name, declaration in additions.items():
            if name not in columns:
                self._connection.execute(f"ALTER TABLE capabilities ADD COLUMN {name} {declaration}")
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('4',),
        )

    def _migrate_v4_to_v5(self) -> None:
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS acquisition_memories (
                memory_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            )
            """
        )
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('5',),
        )


    def _migrate_v5_to_v6(self) -> None:
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS generated_candidate_artifacts (
                artifact_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            )
            """
        )
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('6',),
        )

    def _migrate_v6_to_v7(self) -> None:
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS gcm_resource_bindings (
                binding_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            )
            """
        )
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('7',),
        )


    def _migrate_v7_to_v8(self) -> None:
        self._connection.execute(
            """
            CREATE TABLE IF NOT EXISTS substrate_profiles (
                profile_id TEXT PRIMARY KEY,
                record_json TEXT NOT NULL
            )
            """
        )
        self._connection.execute(
            "UPDATE metadata SET value=? WHERE key='schema_version'",
            ('8',),
        )


    @property
    def schema_version(self) -> int:
        row = self._connection.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
        return int(row["value"])

    def save_capability(self, capability: Capability) -> None:
        self._connection.execute(
            """
            INSERT INTO capabilities(
                capability_id, version, task_family, input_type, output_type,
                exactness, provider_ids_json, verifier_id, trust_state, scope,
                fidelity, component_capability_ids_json
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(capability_id) DO UPDATE SET
                version=excluded.version,
                task_family=excluded.task_family,
                input_type=excluded.input_type,
                output_type=excluded.output_type,
                exactness=excluded.exactness,
                provider_ids_json=excluded.provider_ids_json,
                verifier_id=excluded.verifier_id,
                trust_state=excluded.trust_state,
                scope=excluded.scope,
                fidelity=excluded.fidelity,
                component_capability_ids_json=excluded.component_capability_ids_json
            """,
            (
                capability.capability_id,
                capability.version,
                capability.task_family,
                capability.input_type,
                capability.output_type,
                capability.exactness,
                json.dumps(capability.provider_ids),
                capability.verifier_id,
                capability.trust_state.value,
                capability.scope,
                capability.fidelity.value,
                json.dumps(capability.component_capability_ids),
            ),
        )
        self._connection.commit()

    def save_provider(self, provider: ProviderRecord) -> None:
        self._connection.execute(
            """
            INSERT INTO providers(provider_id, capability_id, active, kind, health, boundary, endpoint)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(provider_id) DO UPDATE SET
                capability_id=excluded.capability_id,
                active=excluded.active,
                kind=excluded.kind,
                health=excluded.health,
                boundary=excluded.boundary,
                endpoint=excluded.endpoint
            """,
            (
                provider.provider_id,
                provider.capability_id,
                int(provider.active),
                provider.kind.value,
                provider.health.value,
                provider.boundary.value,
                provider.endpoint,
            ),
        )
        self._connection.commit()

    def save_cost(self, record: CostRecord) -> None:
        cost = record.cost
        self._connection.execute(
            """
            INSERT INTO cost_records(
                node_id, local_work, external_work, offline_work,
                verification_work, monetary_cost, known, shared_cost_id
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(node_id) DO UPDATE SET
                local_work=excluded.local_work,
                external_work=excluded.external_work,
                offline_work=excluded.offline_work,
                verification_work=excluded.verification_work,
                monetary_cost=excluded.monetary_cost,
                known=excluded.known,
                shared_cost_id=excluded.shared_cost_id
            """,
            (
                record.node_id,
                cost.local_work,
                cost.external_work,
                cost.offline_work,
                cost.verification_work,
                cost.monetary_cost,
                int(record.known),
                record.shared_cost_id,
            ),
        )
        self._connection.commit()

    def load_capabilities(self) -> tuple[Capability, ...]:
        rows = self._connection.execute(
            "SELECT * FROM capabilities ORDER BY capability_id"
        ).fetchall()
        return tuple(
            Capability(
                capability_id=row["capability_id"],
                version=row["version"],
                task_family=row["task_family"],
                input_type=row["input_type"],
                output_type=row["output_type"],
                exactness=row["exactness"],
                provider_ids=tuple(json.loads(row["provider_ids_json"])),
                verifier_id=row["verifier_id"],
                trust_state=TrustState(row["trust_state"]),
                scope=row["scope"],
                fidelity=TransitionFidelity(row["fidelity"]),
                component_capability_ids=tuple(json.loads(row["component_capability_ids_json"])),
            )
            for row in rows
        )

    def load_provider_records(self) -> tuple[ProviderRecord, ...]:
        rows = self._connection.execute(
            "SELECT provider_id, capability_id, active, kind, health, boundary, endpoint "
            "FROM providers ORDER BY provider_id"
        ).fetchall()
        return tuple(
            ProviderRecord(
                row["provider_id"],
                row["capability_id"],
                bool(row["active"]),
                ProviderKind(row["kind"]),
                ProviderHealth(row["health"]),
                ProviderBoundary(row["boundary"]),
                row["endpoint"],
            )
            for row in rows
        )

    def load_costs(self) -> tuple[CostRecord, ...]:
        rows = self._connection.execute(
            "SELECT * FROM cost_records ORDER BY node_id"
        ).fetchall()
        return tuple(
            CostRecord(
                node_id=row["node_id"],
                cost=CostVector(
                    local_work=row["local_work"],
                    external_work=row["external_work"],
                    offline_work=row["offline_work"],
                    verification_work=row["verification_work"],
                    monetary_cost=row["monetary_cost"],
                ),
                known=bool(row["known"]),
                shared_cost_id=row["shared_cost_id"],
            )
            for row in rows
        )

    @staticmethod
    def _metric_to_json(metric: CostMetric) -> dict[str, object]:
        return {
            "value": metric.value,
            "evidence": metric.evidence.value,
            "sample_count": metric.sample_count,
        }

    @staticmethod
    def _metric_from_json(payload: dict[str, object]) -> CostMetric:
        return CostMetric(
            value=None if payload.get("value") is None else float(payload["value"]),
            evidence=CostEvidence(str(payload.get("evidence", "unknown"))),
            sample_count=int(payload.get("sample_count", 0)),
        )

    def save_provider_cost_profile(self, profile: ProviderCostProfile) -> None:
        payload = {
            "provider_id": profile.provider_id,
            "latency_ms": self._metric_to_json(profile.latency_ms),
            "monetary_cost_usd": self._metric_to_json(profile.monetary_cost_usd),
            "network_bytes": self._metric_to_json(profile.network_bytes),
            "verification_work": self._metric_to_json(profile.verification_work),
            "risk_score": self._metric_to_json(profile.risk_score),
        }
        self._connection.execute(
            """
            INSERT INTO provider_cost_profiles(provider_id, profile_json) VALUES (?, ?)
            ON CONFLICT(provider_id) DO UPDATE SET profile_json=excluded.profile_json
            """,
            (profile.provider_id, json.dumps(payload, sort_keys=True)),
        )
        self._connection.commit()

    def load_provider_cost_profiles(self) -> tuple[ProviderCostProfile, ...]:
        rows = self._connection.execute(
            "SELECT provider_id, profile_json FROM provider_cost_profiles ORDER BY provider_id"
        ).fetchall()
        profiles: list[ProviderCostProfile] = []
        for row in rows:
            payload = json.loads(row["profile_json"])
            profiles.append(
                ProviderCostProfile(
                    provider_id=row["provider_id"],
                    latency_ms=self._metric_from_json(payload["latency_ms"]),
                    monetary_cost_usd=self._metric_from_json(payload["monetary_cost_usd"]),
                    network_bytes=self._metric_from_json(payload["network_bytes"]),
                    verification_work=self._metric_from_json(payload["verification_work"]),
                    risk_score=self._metric_from_json(payload["risk_score"]),
                )
            )
        return tuple(profiles)

    def save_acquisition_memory(self, record: AcquisitionMemoryRecord) -> None:
        self._connection.execute(
            """
            INSERT INTO acquisition_memories(memory_id, record_json) VALUES (?, ?)
            ON CONFLICT(memory_id) DO UPDATE SET record_json=excluded.record_json
            """,
            (record.memory_id, json.dumps(record.as_event_data(), sort_keys=True)),
        )
        self._connection.commit()

    def load_acquisition_memories(self) -> tuple[AcquisitionMemoryRecord, ...]:
        rows = self._connection.execute(
            "SELECT memory_id, record_json FROM acquisition_memories ORDER BY memory_id"
        ).fetchall()
        return tuple(
            AcquisitionMemoryRecord.from_event_data(json.loads(row["record_json"]))
            for row in rows
        )


    def save_generated_artifact(self, artifact: GeneratedCandidateArtifact) -> None:
        self._connection.execute(
            """
            INSERT INTO generated_candidate_artifacts(artifact_id, record_json) VALUES (?, ?)
            ON CONFLICT(artifact_id) DO UPDATE SET record_json=excluded.record_json
            """,
            (artifact.artifact_id, json.dumps(artifact.as_event_data(), sort_keys=True)),
        )
        self._connection.commit()

    def load_generated_artifacts(self) -> tuple[GeneratedCandidateArtifact, ...]:
        rows = self._connection.execute(
            "SELECT artifact_id, record_json FROM generated_candidate_artifacts ORDER BY artifact_id"
        ).fetchall()
        return tuple(
            GeneratedCandidateArtifact.from_event_data(json.loads(row["record_json"]))
            for row in rows
        )

    def save_gcm_resource_binding(self, binding: GCMProviderBinding) -> None:
        self._connection.execute(
            """
            INSERT INTO gcm_resource_bindings(binding_id, record_json)
            VALUES (?, ?)
            ON CONFLICT(binding_id) DO UPDATE SET record_json=excluded.record_json
            """,
            (binding.binding_id, json.dumps(binding.as_dict(), sort_keys=True, separators=(",", ":"))),
        )
        self._connection.commit()

    def load_gcm_resource_bindings(self) -> tuple[GCMProviderBinding, ...]:
        rows = self._connection.execute(
            "SELECT record_json FROM gcm_resource_bindings ORDER BY binding_id"
        ).fetchall()
        return tuple(GCMProviderBinding.from_dict(json.loads(row["record_json"])) for row in rows)

    def delete_gcm_resource_binding(self, binding_id: str) -> None:
        self._connection.execute(
            "DELETE FROM gcm_resource_bindings WHERE binding_id=?", (binding_id,)
        )
        self._connection.commit()

    def save_substrate_profile(self, profile: SubstrateProfile) -> None:
        self._connection.execute(
            """
            INSERT INTO substrate_profiles(profile_id, record_json) VALUES (?, ?)
            ON CONFLICT(profile_id) DO UPDATE SET record_json=excluded.record_json
            """,
            (profile.profile_id, json.dumps(profile.as_dict(), sort_keys=True, separators=(",", ":"))),
        )
        self._connection.commit()

    def load_substrate_profiles(self) -> tuple[SubstrateProfile, ...]:
        rows = self._connection.execute(
            "SELECT record_json FROM substrate_profiles ORDER BY profile_id"
        ).fetchall()
        return tuple(SubstrateProfile.from_dict(json.loads(row["record_json"])) for row in rows)

    def delete_substrate_profile(self, profile_id: str) -> None:
        self._connection.execute(
            "DELETE FROM substrate_profiles WHERE profile_id=?", (profile_id,)
        )
        self._connection.commit()

    def close(self) -> None:
        self._connection.close()
