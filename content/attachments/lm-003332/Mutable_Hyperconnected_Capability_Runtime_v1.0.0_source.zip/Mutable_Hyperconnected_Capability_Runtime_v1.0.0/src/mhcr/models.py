from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Callable


class TrustState(str, Enum):
    DRAFT = "draft"
    CANDIDATE = "candidate"
    VALIDATED = "validated"
    TRUSTED = "trusted"
    DEPRECATED = "deprecated"
    REVOKED = "revoked"
    SUPERSEDED = "superseded"


class ProviderKind(str, Enum):
    LOCAL_PYTHON = "local_python"
    SUBPROCESS = "subprocess"
    CONTAINER = "container"
    HTTP = "http"
    LAN_WORKER = "lan_worker"
    REMOTE_API = "remote_api"


class ProviderHealth(str, Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"
    QUARANTINED = "quarantined"


class ProviderBoundary(str, Enum):
    LOCAL = "local"
    PROCESS = "process"
    CONTAINER = "container"
    NETWORK = "network"


class TransitionFidelity(str, Enum):
    EXACT = "exact"
    APPROXIMATE = "approximate"
    LOSSY = "lossy"


class RoutingPreference(str, Enum):
    LATENCY = "latency"
    MONETARY_COST = "monetary_cost"
    NETWORK_BYTES = "network_bytes"
    VERIFICATION_WORK = "verification_work"
    RISK = "risk"
    LOCALITY = "locality"
    KNOWN_COST = "known_cost"


@dataclass(frozen=True, slots=True)
class TaskPolicy:
    local_only: bool = False
    max_latency_ms: float | None = None
    max_external_cost_usd: float | None = None
    max_network_bytes: float | None = None
    max_verification_work: float | None = None
    max_risk_score: float | None = None
    prefer: tuple[RoutingPreference, ...] = ()

    @property
    def is_default(self) -> bool:
        return (
            not self.local_only
            and self.max_latency_ms is None
            and self.max_external_cost_usd is None
            and self.max_network_bytes is None
            and self.max_verification_work is None
            and self.max_risk_score is None
            and not self.prefer
        )




def _ordered_unique_text(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(str(value) for value in values if str(value)))


def _sorted_unique_text(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(sorted(set(str(value) for value in values if str(value))))


@dataclass(frozen=True, slots=True)
class SubstratePolicy:
    allowed_profile_ids: tuple[str, ...] = ()
    allowed_kinds: tuple[str, ...] = ()
    preferred_profile_ids: tuple[str, ...] = ()
    preferred_kinds: tuple[str, ...] = ()
    required_features: tuple[str, ...] = ()
    required_transition_laws: tuple[str, ...] = ()
    require_native: bool = False
    allow_simulated: bool = True
    allow_emulated: bool = True
    allow_remote_service: bool = True
    allow_hybrid: bool = True
    max_energy_units: float | None = None
    max_switching_cost_units: float | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "allowed_profile_ids", _sorted_unique_text(self.allowed_profile_ids))
        object.__setattr__(self, "allowed_kinds", _sorted_unique_text(self.allowed_kinds))
        object.__setattr__(self, "preferred_profile_ids", _ordered_unique_text(self.preferred_profile_ids))
        object.__setattr__(self, "preferred_kinds", _ordered_unique_text(self.preferred_kinds))
        object.__setattr__(self, "required_features", _sorted_unique_text(self.required_features))
        object.__setattr__(self, "required_transition_laws", _sorted_unique_text(self.required_transition_laws))
        for name in ("max_energy_units", "max_switching_cost_units"):
            value = getattr(self, name)
            if value is not None and float(value) < 0:
                raise ValueError(f"{name} cannot be negative")

    @property
    def is_default(self) -> bool:
        return (
            not self.allowed_profile_ids
            and not self.allowed_kinds
            and not self.preferred_profile_ids
            and not self.preferred_kinds
            and not self.required_features
            and not self.required_transition_laws
            and not self.require_native
            and self.allow_simulated
            and self.allow_emulated
            and self.allow_remote_service
            and self.allow_hybrid
            and self.max_energy_units is None
            and self.max_switching_cost_units is None
        )


@dataclass(frozen=True, slots=True)
class CompositionPolicy:
    max_steps: int = 6
    step_weight: float = 1.0
    latency_weight: float = 0.0
    monetary_weight: float = 0.0
    verification_weight: float = 0.0
    risk_weight: float = 0.0
    unknown_metric_penalty: float = 1000.0
    lossy_penalty: float = 1000.0

    def __post_init__(self) -> None:
        if self.max_steps < 1:
            raise ValueError("max_steps must be at least 1")
        for value in (
            self.step_weight,
            self.latency_weight,
            self.monetary_weight,
            self.verification_weight,
            self.risk_weight,
            self.unknown_metric_penalty,
            self.lossy_penalty,
        ):
            if value < 0:
                raise ValueError("composition weights cannot be negative")


@dataclass(frozen=True, slots=True)
class TaskContract:
    task_id: str
    family: str
    input_type: str
    output_type: str
    payload: Any
    exactness: str = "exact"
    policy: TaskPolicy = field(default_factory=TaskPolicy)
    composition_policy: CompositionPolicy = field(default_factory=CompositionPolicy)
    substrate_policy: SubstratePolicy = field(default_factory=SubstratePolicy)


@dataclass(frozen=True, slots=True)
class Capability:
    capability_id: str
    version: str
    task_family: str
    input_type: str
    output_type: str
    exactness: str
    provider_ids: tuple[str, ...]
    verifier_id: str | None = None
    trust_state: TrustState = TrustState.CANDIDATE
    scope: str = "unbounded"
    fidelity: TransitionFidelity = TransitionFidelity.EXACT
    component_capability_ids: tuple[str, ...] = ()

    @property
    def is_composite(self) -> bool:
        return bool(self.component_capability_ids)

    @property
    def major_version(self) -> str:
        return self.version.split(".", 1)[0]

    @property
    def address(self) -> str:
        return f"{self.capability_id}@{self.major_version}"

    def with_trust_state(self, state: TrustState) -> "Capability":
        return replace(self, trust_state=state)


@dataclass(frozen=True, slots=True)
class Provider:
    provider_id: str
    capability_id: str
    execute: Callable[[Any], Any]
    active: bool = True
    kind: ProviderKind = ProviderKind.LOCAL_PYTHON
    health: ProviderHealth = ProviderHealth.HEALTHY
    boundary: ProviderBoundary = ProviderBoundary.LOCAL
    endpoint: str | None = None

    def with_health(self, health: ProviderHealth) -> "Provider":
        return replace(self, health=health)
