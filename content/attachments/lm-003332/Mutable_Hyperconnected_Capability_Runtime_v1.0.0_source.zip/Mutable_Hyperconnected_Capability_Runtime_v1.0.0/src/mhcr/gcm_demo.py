from __future__ import annotations

import json
from pathlib import Path
import tempfile

from .gcm_integration import (
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from .history import EventLog
from .models import Capability, TaskContract, TrustState
from .sqlite_repository import SQLiteRepository


def _binding(provider_id: str, resource_id: str, configuration_id: str, kind: str, capacity: int):
    return GCMProviderBinding(
        binding_id=f"binding:{provider_id}",
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=configuration_id,
        executor_id=provider_id,
        resource_kind=kind,
        capabilities=("square",),
        dimensions=(
            GCMCapacityBinding(
                "vram" if kind == "gpu" else "memory",
                "logical-unit",
                capacity,
                8,
            ),
        ),
        estimates={"latency_ms": 1.0 if kind == "gpu" else 10.0},
    )


def _decision_data(decision):
    return {
        "provider_id": decision.provider_id,
        "resource_id": decision.resource_id,
        "configuration_id": decision.configuration_id,
        "allocation_plan_id": decision.allocation_plan_id,
        "resource_snapshot_id": decision.resource_snapshot_id,
    }


def run_demo() -> dict[str, object]:
    capability = Capability(
        "cap.square", "1.0.0", "square", "number", "number", "exact",
        ("provider.gpu", "provider.cpu"), trust_state=TrustState.TRUSTED,
    )
    with tempfile.TemporaryDirectory(prefix="mhcr-v08-gcm-") as td:
        root = Path(td)
        db = root / "mhcr.sqlite3"
        history = EventLog(root / "events.jsonl")
        repo = SQLiteRepository(db)
        store = GCMResourceBindingStore(repository=repo, event_log=history)
        gpu = _binding("provider.gpu", "resource.gpu", "cfg.gpu", "gpu", 16)
        cpu = _binding("provider.cpu", "resource.cpu", "cfg.cpu", "cpu", 16)
        store.upsert(gpu)
        store.upsert(cpu)
        adapter = GCMPhaseBAdapter(store, event_log=history)

        first = adapter.allocate(
            TaskContract("task.gpu-feasible", "square", "number", "number", 4),
            capability,
            ("provider.gpu", "provider.cpu"),
        )

        # Same preference surface; GCM B3 now rejects GPU capacity and falls through to CPU.
        store.upsert(_binding("provider.gpu", "resource.gpu", "cfg.gpu", "gpu", 4))
        fallback = adapter.allocate(
            TaskContract("task.gpu-fallback", "square", "number", "number", 5),
            capability,
            ("provider.gpu", "provider.cpu"),
        )
        repo.close()

        reopened = SQLiteRepository(db)
        restored = GCMResourceBindingStore(repository=reopened, event_log=history)
        restart_adapter = GCMPhaseBAdapter(restored, event_log=history)
        restart = restart_adapter.allocate(
            TaskContract("task.restart", "square", "number", "number", 6),
            capability,
            ("provider.gpu", "provider.cpu"),
        )
        binding_count = len(restored.records())
        reopened.close()

        world_commit_events = sum(
            "WORLD" in event.event_type and "COMMIT" in event.event_type
            for event in history.read_all()
        )
        return {
            "gpu_feasible": _decision_data(first),
            "gpu_capacity_fallback": _decision_data(fallback),
            "restart": {**_decision_data(restart), "binding_count": binding_count},
            "allocation_events": history.replay_counts().get("GCM_ALLOCATION_SELECTED", 0),
            "world_commit_events": world_commit_events,
        }


def main() -> None:
    print(json.dumps(run_demo(), sort_keys=True))


if __name__ == "__main__":
    main()
