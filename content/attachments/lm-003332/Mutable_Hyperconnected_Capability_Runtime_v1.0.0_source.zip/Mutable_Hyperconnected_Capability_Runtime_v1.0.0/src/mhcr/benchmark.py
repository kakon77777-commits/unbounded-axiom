from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter_ns

from .models import Capability, TaskContract, TrustState
from .registry import CapabilityRegistry
from .resolver import Resolver


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    registry_size: int
    iterations: int
    indexed_ns_per_lookup: float
    scan_ns_per_lookup: float
    speedup_ratio: float


def _scan_reference(registry: CapabilityRegistry, task: TaskContract) -> Capability | None:
    for capability in registry._capabilities.values():
        if (
            capability.trust_state is TrustState.TRUSTED
            and capability.task_family == task.family
            and capability.input_type == task.input_type
            and capability.output_type == task.output_type
            and capability.exactness == task.exactness
        ):
            return capability
    return None


def benchmark_resolver(*, registry_size: int = 1000, iterations: int = 1000) -> BenchmarkResult:
    if registry_size < 1:
        raise ValueError("registry_size must be >= 1")
    if iterations < 1:
        raise ValueError("iterations must be >= 1")

    registry = CapabilityRegistry()
    for index in range(registry_size):
        family = f"family-{index}"
        registry.register_capability(
            Capability(
                capability_id=f"cap.synthetic.{index}",
                version="1.0.0",
                task_family=family,
                input_type="number",
                output_type="number",
                exactness="exact",
                provider_ids=(),
                trust_state=TrustState.TRUSTED,
            )
        )

    target = registry_size - 1
    task = TaskContract(
        task_id="benchmark",
        family=f"family-{target}",
        input_type="number",
        output_type="number",
        payload=0,
        exactness="exact",
    )
    resolver = Resolver(registry)

    for _ in range(min(10, iterations)):
        resolver.resolve_one(task)
        _scan_reference(registry, task)

    start = perf_counter_ns()
    for _ in range(iterations):
        resolved = resolver.resolve_one(task)
        if resolved is None:
            raise AssertionError("indexed resolver lost benchmark target")
    indexed_elapsed = perf_counter_ns() - start

    start = perf_counter_ns()
    for _ in range(iterations):
        resolved = _scan_reference(registry, task)
        if resolved is None:
            raise AssertionError("scan reference lost benchmark target")
    scan_elapsed = perf_counter_ns() - start

    indexed_per = indexed_elapsed / iterations
    scan_per = scan_elapsed / iterations
    return BenchmarkResult(
        registry_size=registry_size,
        iterations=iterations,
        indexed_ns_per_lookup=indexed_per,
        scan_ns_per_lookup=scan_per,
        speedup_ratio=scan_per / indexed_per,
    )
