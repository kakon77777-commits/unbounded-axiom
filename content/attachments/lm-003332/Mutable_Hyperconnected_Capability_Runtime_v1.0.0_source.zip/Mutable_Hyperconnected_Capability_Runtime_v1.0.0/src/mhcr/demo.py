from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import tempfile
import sys

from .accounting import CostRecord, CostVector, GCAL
from .acquisition_benchmark import benchmark_acquisition_learning
from .benchmark import benchmark_resolver
from .constructor import GeneratedSourceSpec, SandboxedSourceConstructor, TemplateConstructor, TemplateSpec
from .history import EventLog
from .models import (
    Capability,
    CompositionPolicy,
    Provider,
    ProviderBoundary,
    ProviderKind,
    RoutingPreference,
    TaskContract,
    TaskPolicy,
    TrustState,
)
from .provider_adapters import LocalPythonAdapter, SubprocessJsonAdapter, provider_from_adapter
from .registry import CapabilityRegistry
from .runtime import MHCRRuntime
from .routing import CostEvidence, CostMetric, ProviderCostCatalog, ProviderCostProfile
from .sandbox import GeneratedArtifactStore, PythonSandboxRunner, SandboxPolicy, load_sandbox_provider_bindings
from .sqlite_repository import SQLiteRepository
from .verification import VerifierRegistry


def _square(value: int) -> int:
    return value * value


def _double(value: int) -> int:
    return value * 2


def _parse_numbers(text: str) -> list[int]:
    return [int(item) for item in text.split(",")]


def _double_numbers(values: list[int]) -> list[int]:
    return [value * 2 for value in values]


def _sum_numbers(values: list[int]) -> int:
    return sum(values)


def _parse_and_double(text: str) -> list[int]:
    return [int(item) * 2 for item in text.split(",")]


def _register_square_verifier(registry: VerifierRegistry) -> None:
    registry.register("verify.square", lambda task, result: result == task.payload * task.payload)


def _register_double_verifier(registry: VerifierRegistry) -> None:
    registry.register("verify.double", lambda task, result: result == task.payload * 2)


def _register_pipeline_verifier(registry: VerifierRegistry) -> None:
    registry.register(
        "verify.pipeline",
        lambda task, result: result == sum(int(item) * 2 for item in task.payload.split(",")),
    )


def build_demo() -> dict[str, object]:
    with tempfile.TemporaryDirectory(prefix="mhcr-demo-") as directory:
        root = Path(directory)
        db_path = root / "mhcr.sqlite3"
        history = EventLog(root / "events.jsonl")

        repository = SQLiteRepository(db_path)
        registry = CapabilityRegistry(repository=repository, event_log=history)
        verifiers = VerifierRegistry()
        _register_square_verifier(verifiers)
        _register_double_verifier(verifiers)
        gcal = GCAL(repository=repository)
        cost_catalog = ProviderCostCatalog(repository)
        constructor = TemplateConstructor(
            [
                TemplateSpec(
                    task_family="square",
                    input_type="number",
                    output_type="number",
                    execute=_square,
                    verifier_id="verify.square",
                    provider_local_work=3.0,
                    formation_work=5.0,
                )
            ]
        )
        runtime = MHCRRuntime(
            registry,
            verifiers,
            gcal,
            history,
            constructor=constructor,
            cost_catalog=cost_catalog,
        )
        first = runtime.solve(TaskContract("demo-square-4", "square", "number", "number", 4))
        constructor_count = constructor.construct_count

        double_capability = Capability(
            capability_id="cap.demo.double",
            version="1.0.0",
            task_family="double",
            input_type="number",
            output_type="number",
            exactness="exact",
            provider_ids=("provider.process.double", "provider.local.double"),
            verifier_id="verify.double",
            trust_state=TrustState.TRUSTED,
        )
        registry.register_capability(double_capability)
        failing_process = SubprocessJsonAdapter(
            (sys.executable, "-c", "import sys; sys.stderr.write('demo failure'); sys.exit(9)"),
            timeout=2.0,
        )
        registry.register_provider(
            provider_from_adapter(
                "provider.process.double",
                double_capability.capability_id,
                failing_process,
            )
        )
        registry.register_provider(
            provider_from_adapter(
                "provider.local.double",
                double_capability.capability_id,
                LocalPythonAdapter(_double),
            )
        )
        gcal.register_cost(
            CostRecord("provider.local.double", CostVector(local_work=1.0), known=True)
        )
        fabric_first = runtime.solve(
            TaskContract("demo-double-9", "double", "number", "number", 9)
        )
        failed_health = registry.get_provider("provider.process.double").health.value

        route_capability = Capability(
            capability_id="cap.demo.cost-route",
            version="1.0.0",
            task_family="cost-route",
            input_type="number",
            output_type="number",
            exactness="exact",
            provider_ids=(
                "provider.route.unknown",
                "provider.route.fast",
                "provider.route.cheap",
                "provider.route.local",
            ),
            verifier_id="verify.double",
            trust_state=TrustState.TRUSTED,
        )
        registry.register_capability(route_capability)
        registry.register_provider(
            Provider(
                "provider.route.unknown",
                route_capability.capability_id,
                _double,
                kind=ProviderKind.REMOTE_API,
                boundary=ProviderBoundary.NETWORK,
                endpoint="https://unknown.invalid/double",
            )
        )
        registry.register_provider(
            Provider(
                "provider.route.fast",
                route_capability.capability_id,
                _double,
                kind=ProviderKind.REMOTE_API,
                boundary=ProviderBoundary.NETWORK,
                endpoint="https://fast.invalid/double",
            )
        )
        registry.register_provider(
            Provider(
                "provider.route.cheap",
                route_capability.capability_id,
                _double,
                kind=ProviderKind.REMOTE_API,
                boundary=ProviderBoundary.NETWORK,
                endpoint="https://cheap.invalid/double",
            )
        )
        registry.register_provider(
            Provider("provider.route.local", route_capability.capability_id, _double)
        )
        cost_catalog.upsert(
            ProviderCostProfile(
                "provider.route.fast",
                latency_ms=CostMetric(5.0, CostEvidence.DECLARED),
                monetary_cost_usd=CostMetric(0.08, CostEvidence.DECLARED),
                network_bytes=CostMetric(500.0, CostEvidence.DECLARED),
                verification_work=CostMetric(1.0, CostEvidence.DECLARED),
                risk_score=CostMetric(0.1, CostEvidence.DECLARED),
            )
        )
        cost_catalog.upsert(
            ProviderCostProfile(
                "provider.route.cheap",
                latency_ms=CostMetric(50.0, CostEvidence.DECLARED),
                monetary_cost_usd=CostMetric(0.01, CostEvidence.DECLARED),
                network_bytes=CostMetric(1000.0, CostEvidence.DECLARED),
                verification_work=CostMetric(1.0, CostEvidence.DECLARED),
                risk_score=CostMetric(0.1, CostEvidence.DECLARED),
            )
        )
        cost_catalog.upsert(
            ProviderCostProfile(
                "provider.route.local",
                latency_ms=CostMetric(100.0, CostEvidence.DECLARED),
                verification_work=CostMetric(1.0, CostEvidence.DECLARED),
                risk_score=CostMetric(0.05, CostEvidence.DECLARED),
            )
        )
        routing_history = EventLog(root / "routing-events.jsonl")
        routing_runtime = MHCRRuntime(
            registry,
            verifiers,
            gcal,
            routing_history,
            constructor=None,
            cost_catalog=cost_catalog,
        )
        latency_route = routing_runtime.solve(
            TaskContract(
                "demo-route-latency",
                "cost-route",
                "number",
                "number",
                5,
                policy=TaskPolicy(prefer=(RoutingPreference.LATENCY,)),
            )
        )
        money_route = routing_runtime.solve(
            TaskContract(
                "demo-route-money",
                "cost-route",
                "number",
                "number",
                6,
                policy=TaskPolicy(prefer=(RoutingPreference.MONETARY_COST,)),
            )
        )
        ceiling_route = routing_runtime.solve(
            TaskContract(
                "demo-route-ceiling",
                "cost-route",
                "number",
                "number",
                7,
                policy=TaskPolicy(
                    max_external_cost_usd=0.05,
                    prefer=(RoutingPreference.LATENCY,),
                ),
            )
        )
        local_route = routing_runtime.solve(
            TaskContract(
                "demo-route-local",
                "cost-route",
                "number",
                "number",
                8,
                policy=TaskPolicy(
                    local_only=True,
                    prefer=(RoutingPreference.LATENCY,),
                ),
            )
        )
        repository.close()

        reopened = SQLiteRepository(db_path)
        restored_cost_catalog = ProviderCostCatalog(reopened)
        restored_registry = CapabilityRegistry.from_repository(
            reopened,
            provider_executors={
                "provider.generated.square": _square,
                "provider.process.double": lambda value: value * 200,
                "provider.local.double": _double,
                "provider.route.unknown": _double,
                "provider.route.fast": _double,
                "provider.route.cheap": _double,
                "provider.route.local": _double,
            },
            event_log=history,
        )
        restored_verifiers = VerifierRegistry()
        _register_square_verifier(restored_verifiers)
        _register_double_verifier(restored_verifiers)
        restored_gcal = GCAL(repository=reopened)
        restored_runtime = MHCRRuntime(
            restored_registry,
            restored_verifiers,
            restored_gcal,
            history,
            constructor=None,
        )
        second = restored_runtime.solve(TaskContract("demo-square-7", "square", "number", "number", 7))
        fabric_second = restored_runtime.solve(
            TaskContract("demo-double-11", "double", "number", "number", 11)
        )
        restored_failed_health = restored_registry.get_provider("provider.process.double").health.value
        replayed = history.replay_registry(
            provider_executors={
                "provider.generated.square": _square,
                "provider.process.double": lambda value: value * 200,
                "provider.local.double": _double,
                "provider.route.unknown": _double,
                "provider.route.fast": _double,
                "provider.route.cheap": _double,
                "provider.route.local": _double,
            }
        )
        replay_provider = replayed.get_provider("provider.process.double")
        replay_capability = replayed.get_capability("cap.demo.double")
        trusted = [
            capability
            for capability in restored_registry.capabilities()
            if capability.trust_state is TrustState.TRUSTED and capability.task_family == "square"
        ]
        events = history.read_all()
        boundary_events = sum(event.event_type == "PROVIDER_BOUNDARY_CROSSED" for event in events)
        failure_events = sum(event.event_type == "PROVIDER_EXECUTION_FAILED" for event in events)
        routing_decision_events = sum(
            event.event_type == "PROVIDER_ROUTING_DECISION"
            for event in routing_history.read_all()
        )
        restored_fast = restored_cost_catalog.get("provider.route.fast")
        restored_unknown = restored_cost_catalog.get("provider.route.unknown")
        reopened.close()

        # v0.5 composition scenario is intentionally isolated so historical
        # v0.2-v0.4 event counts above remain unchanged.
        composition_db = root / "composition.sqlite3"
        composition_history = EventLog(root / "composition-events.jsonl")
        composition_repo = SQLiteRepository(composition_db)
        composition_registry = CapabilityRegistry(
            repository=composition_repo, event_log=composition_history
        )
        composition_verifiers = VerifierRegistry()
        _register_pipeline_verifier(composition_verifiers)
        composition_gcal = GCAL(repository=composition_repo)
        composition_catalog = ProviderCostCatalog(composition_repo)

        composition_caps = (
            Capability(
                "cap.demo.parse", "1.0.0", "parse", "text", "numbers", "exact",
                ("provider.demo.parse",), trust_state=TrustState.TRUSTED,
            ),
            Capability(
                "cap.demo.double-list", "1.0.0", "double-list", "numbers", "doubled", "exact",
                ("provider.demo.double-list",), trust_state=TrustState.TRUSTED,
            ),
            Capability(
                "cap.demo.sum", "1.0.0", "sum", "doubled", "number", "exact",
                ("provider.demo.sum",), verifier_id="verify.pipeline", trust_state=TrustState.TRUSTED,
            ),
            Capability(
                "cap.demo.expensive-prepare", "1.0.0", "expensive-prepare", "text", "expensive-mid", "exact",
                ("provider.demo.expensive-prepare",), trust_state=TrustState.TRUSTED,
            ),
            Capability(
                "cap.demo.expensive-sum", "1.0.0", "expensive-sum", "expensive-mid", "number", "exact",
                ("provider.demo.expensive-sum",), verifier_id="verify.pipeline", trust_state=TrustState.TRUSTED,
            ),
        )
        for capability in composition_caps:
            composition_registry.register_capability(capability)
        composition_registry.register_provider(
            Provider("provider.demo.parse", "cap.demo.parse", _parse_numbers)
        )
        composition_registry.register_provider(
            Provider("provider.demo.double-list", "cap.demo.double-list", _double_numbers)
        )
        composition_registry.register_provider(
            Provider("provider.demo.sum", "cap.demo.sum", _sum_numbers)
        )
        composition_registry.register_provider(
            Provider("provider.demo.expensive-prepare", "cap.demo.expensive-prepare", _parse_and_double)
        )
        composition_registry.register_provider(
            Provider("provider.demo.expensive-sum", "cap.demo.expensive-sum", _sum_numbers)
        )
        for provider_id in (
            "provider.demo.parse",
            "provider.demo.double-list",
            "provider.demo.sum",
            "provider.demo.expensive-prepare",
            "provider.demo.expensive-sum",
        ):
            composition_gcal.register_cost(
                CostRecord(provider_id, CostVector(local_work=1.0), known=True)
            )
        for provider_id in (
            "provider.demo.parse",
            "provider.demo.double-list",
            "provider.demo.sum",
        ):
            composition_catalog.upsert(
                ProviderCostProfile(
                    provider_id,
                    latency_ms=CostMetric(1.0, CostEvidence.DECLARED),
                )
            )
        for provider_id in (
            "provider.demo.expensive-prepare",
            "provider.demo.expensive-sum",
        ):
            composition_catalog.upsert(
                ProviderCostProfile(
                    provider_id,
                    latency_ms=CostMetric(100.0, CostEvidence.DECLARED),
                )
            )

        composition_runtime = MHCRRuntime(
            composition_registry,
            composition_verifiers,
            composition_gcal,
            composition_history,
            constructor=None,
            cost_catalog=composition_catalog,
        )
        composition_policy = CompositionPolicy(step_weight=1.0, latency_weight=1.0)
        composition_first = composition_runtime.solve(
            TaskContract(
                "demo-compose-first",
                "pipeline",
                "text",
                "number",
                "1,2,3",
                composition_policy=composition_policy,
            )
        )
        composition_first_searches = composition_runtime.resolver.planner.search_invocations
        plan_event = next(
            event for event in composition_history.read_all()
            if event.event_type == "COMPOSITION_PLAN_SELECTED"
        )
        composite = next(
            capability for capability in composition_registry.capabilities()
            if capability.is_composite and capability.task_family == "pipeline"
        )
        composite_id = composite.capability_id
        component_ids = list(composite.component_capability_ids)
        composite_trust_before_restart = composite.trust_state.value
        composition_repo.close()

        composition_reopened = SQLiteRepository(composition_db)
        composition_restored_registry = CapabilityRegistry.from_repository(
            composition_reopened,
            provider_executors={
                "provider.demo.parse": _parse_numbers,
                "provider.demo.double-list": _double_numbers,
                "provider.demo.sum": _sum_numbers,
                "provider.demo.expensive-prepare": _parse_and_double,
                "provider.demo.expensive-sum": _sum_numbers,
            },
            event_log=composition_history,
        )
        composition_restored_verifiers = VerifierRegistry()
        _register_pipeline_verifier(composition_restored_verifiers)
        composition_restored_gcal = GCAL(repository=composition_reopened)
        composition_restored_catalog = ProviderCostCatalog(composition_reopened)
        composition_restored_runtime = MHCRRuntime(
            composition_restored_registry,
            composition_restored_verifiers,
            composition_restored_gcal,
            composition_history,
            constructor=None,
            cost_catalog=composition_restored_catalog,
        )
        persisted_composite = composition_restored_registry.get_capability(composite_id)
        composition_second = composition_restored_runtime.solve(
            TaskContract(
                "demo-compose-second",
                "pipeline",
                "text",
                "number",
                "4,5",
                composition_policy=composition_policy,
            )
        )
        restart_graph_searches = composition_restored_runtime.resolver.planner.search_invocations
        composition_restored_registry.revoke("cap.demo.parse")
        trust_after_revoke = composition_restored_registry.get_capability(composite_id).trust_state.value
        replayed_composition = composition_history.replay_registry()
        replay_trust_after_revoke = replayed_composition.get_capability(composite_id).trust_state.value
        invalidation_events = composition_history.replay_counts().get(
            "REGISTRY_COMPOSITE_INVALIDATED", 0
        )
        composition_reopened.close()

        benchmark = benchmark_resolver(registry_size=1000, iterations=500)
        acquisition_learning = benchmark_acquisition_learning((2, 3, 5, 7))

        # v0.7 generated sandbox scenario is isolated from earlier history counts.
        sandbox_db = root / "sandbox.sqlite3"
        sandbox_history = EventLog(root / "sandbox-events.jsonl")
        sandbox_repo = SQLiteRepository(sandbox_db)
        sandbox_store = GeneratedArtifactStore(repository=sandbox_repo, event_log=sandbox_history)
        sandbox_runner = PythonSandboxRunner(policy=SandboxPolicy(timeout_seconds=2.0))
        sandbox_constructor = SandboxedSourceConstructor(
            lambda _task: GeneratedSourceSpec(
                "def solve(payload):\n    return payload * payload\n"
            ),
            artifact_store=sandbox_store,
            runner=sandbox_runner,
            verifier_id="verify.square",
        )
        sandbox_registry = CapabilityRegistry(repository=sandbox_repo, event_log=sandbox_history)
        sandbox_verifiers = VerifierRegistry()
        _register_square_verifier(sandbox_verifiers)
        sandbox_runtime = MHCRRuntime(
            sandbox_registry,
            sandbox_verifiers,
            GCAL(sandbox_repo),
            sandbox_history,
            constructor=sandbox_constructor,
        )
        sandbox_first = sandbox_runtime.solve(
            TaskContract("demo-sandbox-6", "square", "number", "number", 6)
        )
        sandbox_first_artifact = sandbox_store.records()[0]
        sandbox_first_trust = sandbox_registry.get_capability(
            "cap.generated.square"
        ).trust_state.value
        sandbox_provider_boundary = sandbox_registry.get_provider(
            "provider.generated.square"
        ).boundary.value
        sandbox_constructor_invocations = sandbox_constructor.construct_count
        sandbox_repo.close()

        sandbox_reopened = SQLiteRepository(sandbox_db)
        sandbox_rebound_runner = PythonSandboxRunner(policy=SandboxPolicy(timeout_seconds=2.0))
        sandbox_bindings = load_sandbox_provider_bindings(
            sandbox_reopened, sandbox_rebound_runner
        )
        sandbox_restored_registry = CapabilityRegistry.from_repository(
            sandbox_reopened,
            provider_executors=sandbox_bindings,
            event_log=sandbox_history,
        )
        sandbox_restored_verifiers = VerifierRegistry()
        _register_square_verifier(sandbox_restored_verifiers)
        sandbox_restored_runtime = MHCRRuntime(
            sandbox_restored_registry,
            sandbox_restored_verifiers,
            GCAL(sandbox_reopened),
            sandbox_history,
        )
        sandbox_second = sandbox_restored_runtime.solve(
            TaskContract("demo-sandbox-9", "square", "number", "number", 9)
        )
        sandbox_persisted_artifact = sandbox_reopened.load_generated_artifacts()[0]
        sandbox_hash_matches = sandbox_persisted_artifact.source_sha256 == hashlib.sha256(
            sandbox_persisted_artifact.source.encode("utf-8")
        ).hexdigest()
        sandbox_reopened.close()
        return {
            "first": {
                "value": first.value,
                "source": first.source,
                "execution_path": first.execution_path,
                "acquisition_events": first.acquisition_events,
                "accounting": first.accounting.status.value,
            },
            "second": {
                "value": second.value,
                "source": second.source,
                "execution_path": second.execution_path,
                "acquisition_events": second.acquisition_events,
                "accounting": second.accounting.status.value,
            },
            "restart_count": 1,
            "constructor_count": constructor_count,
            "trusted_capability_count": len(trusted),
            "provider_fabric": {
                "first_value": fabric_first.value,
                "first_accounting": fabric_first.accounting.status.value,
                "failed_provider_health": failed_health,
                "restart_value": fabric_second.value,
                "restart_execution_path": fabric_second.execution_path,
                "restart_failed_provider_health": restored_failed_health,
                "capability_trust": replay_capability.trust_state.value,
                "boundary_events": boundary_events,
                "failure_events": failure_events,
                "replay_provider_kind": replay_provider.kind.value,
                "replay_provider_health": replay_provider.health.value,
            },
            "cost_routing": {
                "latency_provider": latency_route.provider_ids[-1],
                "money_provider": money_route.provider_ids[-1],
                "ceiling_provider": ceiling_route.provider_ids[-1],
                "local_only_provider": local_route.provider_ids[-1],
                "latency_accounting": latency_route.accounting.status.value,
                "restored_fast_latency_evidence": restored_fast.latency_ms.evidence.value,
                "restored_fast_price": restored_fast.monetary_cost_usd.value,
                "restored_unknown_price_evidence": restored_unknown.monetary_cost_usd.evidence.value,
                "routing_decision_events": routing_decision_events,
            },
            "composition": {
                "first_value": composition_first.value,
                "first_source": composition_first.source,
                "first_graph_searches": composition_first_searches,
                "first_graph_expansions": plan_event.data["graph_expansions"],
                "component_ids": component_ids,
                "composite_id": composite_id,
                "composite_trust_before_restart": composite_trust_before_restart,
                "restart_value": composition_second.value,
                "restart_source": composition_second.source,
                "restart_execution_path": composition_second.execution_path,
                "restart_graph_searches": restart_graph_searches,
                "persisted_component_ids": list(persisted_composite.component_capability_ids),
                "trust_after_component_revoke": trust_after_revoke,
                "replay_trust_after_revoke": replay_trust_after_revoke,
                "invalidation_events": invalidation_events,
            },
            "acquisition_learning": {
                "stateless_total_work": acquisition_learning.stateless_total_work,
                "persistent_total_work": acquisition_learning.persistent_total_work,
                "stateless_post_first_mean_work": acquisition_learning.stateless_post_first_mean_work,
                "persistent_post_first_mean_work": acquisition_learning.persistent_post_first_mean_work,
                "work_reduction_ratio": acquisition_learning.work_reduction_ratio,
                "stateless_constructor_invocations": acquisition_learning.stateless_constructor_invocations,
                "persistent_constructor_invocations": acquisition_learning.persistent_constructor_invocations,
                "persistent_solver_memory_hits": acquisition_learning.persistent_memory_hits["solver"],
                "persistent_verification_memory_hits": acquisition_learning.persistent_memory_hits["verification"],
                "all_cache_hits_false": acquisition_learning.all_cache_hits_false,
            },
            "generated_sandbox": {
                "first_value": sandbox_first.value,
                "first_source": sandbox_first.source,
                "first_artifact_status": sandbox_first_artifact.status.value,
                "first_capability_trust": sandbox_first_trust,
                "restart_value": sandbox_second.value,
                "restart_source": sandbox_second.source,
                "restart_execution_path": sandbox_second.execution_path,
                "restart_cache_hit": sandbox_second.cache_hit,
                "constructor_invocations": sandbox_constructor_invocations,
                "artifact_source_hash_matches": sandbox_hash_matches,
                "sandbox_provider_boundary": sandbox_provider_boundary,
            },
            "history": history.replay_counts(),
            "benchmark": asdict(benchmark),
        }


def main() -> None:
    print(json.dumps(build_demo(), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
