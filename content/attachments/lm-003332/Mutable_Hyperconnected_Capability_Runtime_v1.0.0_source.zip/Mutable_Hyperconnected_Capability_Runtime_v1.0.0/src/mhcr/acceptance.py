from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .conformance import ConformanceClaim, ConformanceProfileResult, run_conformance
from .failure_matrix import FailureMatrixResult, run_failure_matrix
from .longrun import LongRunResult, run_longrun


@dataclass(frozen=True, slots=True)
class AcceptanceResult:
    acceptance_id: str
    core: ConformanceProfileResult
    failure_matrix: FailureMatrixResult
    longrun: LongRunResult
    gcm: ConformanceProfileResult | None
    accepted: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "acceptance_id": self.acceptance_id,
            "accepted": self.accepted,
            "core": self.core.as_dict(),
            "failure_matrix": self.failure_matrix.as_dict(),
            "longrun": self.longrun.as_dict(),
            "gcm": None if self.gcm is None else self.gcm.as_dict(),
        }


def run_acceptance(*, include_gcm: bool = False) -> AcceptanceResult:
    core = run_conformance("MHCR-CORE-R1")
    failure = run_failure_matrix()
    longrun = run_longrun()
    gcm = run_conformance("MHCR-GCM-R1") if include_gcm else None
    accepted = (
        core.claim is ConformanceClaim.CONFORMANT
        and failure.passed
        and longrun.passed
        and (
            not include_gcm
            or (gcm is not None and gcm.claim is ConformanceClaim.CONFORMANT)
        )
    )
    return AcceptanceResult("MHCR-V1-ACCEPTANCE-R1", core, failure, longrun, gcm, accepted)
