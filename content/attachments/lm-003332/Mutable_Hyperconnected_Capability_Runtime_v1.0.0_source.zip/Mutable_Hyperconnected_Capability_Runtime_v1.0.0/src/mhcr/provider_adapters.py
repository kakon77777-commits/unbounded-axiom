from __future__ import annotations

from dataclasses import dataclass
import json
import shlex
import subprocess
from typing import Any, Callable, Protocol
from urllib import error as urllib_error
from urllib import request as urllib_request

from .models import Provider, ProviderBoundary, ProviderHealth, ProviderKind


class ProviderAdapterError(RuntimeError):
    pass


class ProviderAdapter(Protocol):
    kind: ProviderKind
    boundary: ProviderBoundary
    endpoint: str | None

    def execute(self, payload: Any) -> Any: ...


@dataclass(frozen=True, slots=True)
class LocalPythonAdapter:
    function: Callable[[Any], Any]
    kind: ProviderKind = ProviderKind.LOCAL_PYTHON
    boundary: ProviderBoundary = ProviderBoundary.LOCAL
    endpoint: str | None = None

    def execute(self, payload: Any) -> Any:
        return self.function(payload)


class SubprocessJsonAdapter:
    def __init__(
        self,
        command: tuple[str, ...] | list[str],
        *,
        kind: ProviderKind = ProviderKind.SUBPROCESS,
        timeout: float = 30.0,
    ) -> None:
        if kind not in {ProviderKind.SUBPROCESS, ProviderKind.CONTAINER}:
            raise ValueError("subprocess adapter kind must be SUBPROCESS or CONTAINER")
        if not command:
            raise ValueError("subprocess command cannot be empty")
        self.command = tuple(command)
        self.kind = kind
        self.boundary = (
            ProviderBoundary.CONTAINER
            if kind is ProviderKind.CONTAINER
            else ProviderBoundary.PROCESS
        )
        self.endpoint = shlex.join(self.command)
        self.timeout = timeout

    def execute(self, payload: Any) -> Any:
        try:
            completed = subprocess.run(
                self.command,
                input=json.dumps(payload, ensure_ascii=False),
                text=True,
                capture_output=True,
                timeout=self.timeout,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise ProviderAdapterError(f"subprocess execution failed: {exc}") from exc
        if completed.returncode != 0:
            stderr = completed.stderr.strip()
            detail = f": {stderr}" if stderr else ""
            raise ProviderAdapterError(
                f"subprocess provider exit {completed.returncode}{detail}"
            )
        try:
            return json.loads(completed.stdout)
        except json.JSONDecodeError as exc:
            raise ProviderAdapterError("subprocess provider returned invalid JSON") from exc


class HttpJsonAdapter:
    def __init__(
        self,
        endpoint: str,
        *,
        kind: ProviderKind = ProviderKind.HTTP,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
    ) -> None:
        if kind not in {ProviderKind.HTTP, ProviderKind.LAN_WORKER, ProviderKind.REMOTE_API}:
            raise ValueError("http adapter kind must be HTTP, LAN_WORKER, or REMOTE_API")
        self.endpoint = endpoint
        self.kind = kind
        self.boundary = ProviderBoundary.NETWORK
        self.timeout = timeout
        self.headers = dict(headers or {})

    def execute(self, payload: Any) -> Any:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json", **self.headers}
        req = urllib_request.Request(self.endpoint, data=body, headers=headers, method="POST")
        try:
            with urllib_request.urlopen(req, timeout=self.timeout) as response:
                raw = response.read()
        except (urllib_error.URLError, TimeoutError, OSError) as exc:
            raise ProviderAdapterError(f"HTTP provider request failed: {exc}") from exc
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ProviderAdapterError("HTTP provider returned invalid JSON") from exc


def provider_from_adapter(
    provider_id: str,
    capability_id: str,
    adapter: ProviderAdapter,
    *,
    active: bool = True,
    health: ProviderHealth = ProviderHealth.HEALTHY,
) -> Provider:
    return Provider(
        provider_id=provider_id,
        capability_id=capability_id,
        execute=adapter.execute,
        active=active,
        kind=adapter.kind,
        health=health,
        boundary=adapter.boundary,
        endpoint=adapter.endpoint,
    )
