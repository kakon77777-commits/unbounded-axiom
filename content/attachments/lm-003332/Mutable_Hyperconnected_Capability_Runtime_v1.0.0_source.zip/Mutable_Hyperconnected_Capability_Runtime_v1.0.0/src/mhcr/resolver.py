from __future__ import annotations

from typing import TYPE_CHECKING
import hashlib

from .composition import CompositionPlan, CompositionPlanner
from .models import Capability, TaskContract, TransitionFidelity, TrustState
from .registry import CapabilityRegistry

if TYPE_CHECKING:
    from .rdr import RDR


class Resolver:
    def __init__(self, registry: CapabilityRegistry, *, rdr: "RDR | None" = None) -> None:
        self.registry = registry
        self.planner = CompositionPlanner(registry, rdr=rdr)

    def resolve(self, task: TaskContract) -> list[Capability]:
        return self.registry.find_trusted(
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
        )

    def resolve_one(self, task: TaskContract) -> Capability | None:
        matches = self.resolve(task)
        return matches[0] if matches else None

    def plan(self, task: TaskContract) -> CompositionPlan | None:
        return self.planner.plan(task)

    def compose(self, task: TaskContract) -> tuple[Capability, ...] | None:
        plan = self.plan(task)
        return plan.capabilities if plan is not None else None
    @staticmethod
    def _composite_id(task: TaskContract, plan: CompositionPlan) -> str:
        payload = "|".join(
            (
                task.family,
                task.input_type,
                task.output_type,
                task.exactness,
                *plan.capability_ids,
            )
        )
        digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
        return f"cap.composite.{digest}"

    def canonicalize_plan(self, task: TaskContract, plan: CompositionPlan, verification) -> Capability:
        capability_id = self._composite_id(task, plan)
        try:
            existing = self.registry.get_capability(capability_id)
        except KeyError:
            existing = None
        if existing is not None and existing.trust_state is TrustState.TRUSTED:
            return existing

        fidelities = {capability.fidelity for capability in plan.capabilities}
        if TransitionFidelity.LOSSY in fidelities:
            fidelity = TransitionFidelity.LOSSY
        elif TransitionFidelity.APPROXIMATE in fidelities:
            fidelity = TransitionFidelity.APPROXIMATE
        else:
            fidelity = TransitionFidelity.EXACT

        candidate = Capability(
            capability_id=capability_id,
            version="1.0.0",
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
            provider_ids=(),
            verifier_id=plan.capabilities[-1].verifier_id,
            trust_state=TrustState.CANDIDATE,
            scope="composite",
            fidelity=fidelity,
            component_capability_ids=plan.capability_ids,
        )
        if existing is None:
            self.registry.register_capability(candidate)
        else:
            self.registry.replace_capability(candidate)
        return self.registry.promote(candidate.capability_id, verification)

