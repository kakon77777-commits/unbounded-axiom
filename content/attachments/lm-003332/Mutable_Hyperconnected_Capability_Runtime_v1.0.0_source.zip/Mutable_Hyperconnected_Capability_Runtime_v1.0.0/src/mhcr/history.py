from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
from collections.abc import Callable, Mapping
from typing import Any


@dataclass(frozen=True, slots=True)
class Event:
    event_type: str
    data: dict[str, Any]
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def as_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "data": self.data,
            "timestamp": self.timestamp,
        }


class EventLog:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, event: Event) -> None:
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event.as_dict(), ensure_ascii=False, sort_keys=True) + "\n")

    def read_all(self) -> tuple[Event, ...]:
        if not self.path.exists():
            return ()
        events: list[Event] = []
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                raw = json.loads(line)
                events.append(Event(raw["event_type"], raw["data"], raw["timestamp"]))
        return tuple(events)

    def replay_counts(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for event in self.read_all():
            counts[event.event_type] = counts.get(event.event_type, 0) + 1
        return counts

    def replay_acquisition_memories(self):
        from .acquisition import AcquisitionMemoryRecord, AcquisitionMemoryStore

        store = AcquisitionMemoryStore()
        for event in self.read_all():
            data = event.data
            if event.event_type == "ACQUISITION_MEMORY_UPSERTED":
                record = AcquisitionMemoryRecord.from_event_data(data)
                store._records[record.memory_id] = record
            elif event.event_type == "ACQUISITION_MEMORY_REUSED":
                memory_id = data["memory_id"]
                if memory_id in store._records:
                    current = store._records[memory_id]
                    store._records[memory_id] = current.__class__(
                        memory_id=current.memory_id,
                        kind=current.kind,
                        task_family=current.task_family,
                        input_type=current.input_type,
                        output_type=current.output_type,
                        exactness=current.exactness,
                        subject_id=current.subject_id,
                        metadata=current.metadata,
                        source=current.source,
                        reuse_count=int(data["reuse_count"]),
                        active=current.active,
                        invalidation_reason=current.invalidation_reason,
                    )
            elif event.event_type == "ACQUISITION_MEMORY_INVALIDATED":
                memory_id = data["memory_id"]
                if memory_id in store._records:
                    store._records[memory_id] = store._records[memory_id].invalidated(
                        data["reason"]
                    )
        return store


    def replay_generated_artifacts(self):
        from .sandbox import GeneratedArtifactStore, GeneratedCandidateArtifact

        store = GeneratedArtifactStore()
        for event in self.read_all():
            if event.event_type == "GENERATED_ARTIFACT_UPSERTED":
                artifact = GeneratedCandidateArtifact.from_event_data(event.data)
                store._records[artifact.artifact_id] = artifact
        return store

    def replay_gcm_resource_bindings(self):
        from .gcm_integration import GCMProviderBinding, GCMResourceBindingStore

        store = GCMResourceBindingStore()
        for event in self.read_all():
            if event.event_type == "GCM_RESOURCE_BINDING_UPSERTED":
                binding = GCMProviderBinding.from_dict(event.data)
                store._records[binding.binding_id] = binding
            elif event.event_type == "GCM_RESOURCE_BINDING_REMOVED":
                store._records.pop(event.data["binding_id"], None)
        return store

    def replay_substrate_profiles(self):
        from .substrate import SubstrateProfile, SubstrateProfileStore

        store = SubstrateProfileStore()
        for event in self.read_all():
            if event.event_type == "SUBSTRATE_PROFILE_UPSERTED":
                profile = SubstrateProfile.from_dict(event.data)
                store._records[profile.profile_id] = profile
            elif event.event_type == "SUBSTRATE_PROFILE_REMOVED":
                store._records.pop(event.data["profile_id"], None)
        return store

    def replay_registry(
        self,
        provider_executors: Mapping[str, Callable[[Any], Any]] | None = None,
    ):
        from .models import (
            Capability, Provider, ProviderBoundary, ProviderHealth, ProviderKind,
            TransitionFidelity, TrustState,
        )
        from .registry import CapabilityRegistry

        registry = CapabilityRegistry()
        executors = provider_executors or {}

        for event in self.read_all():
            data = event.data
            if event.event_type == "REGISTRY_CAPABILITY_UPSERTED":
                capability = Capability(
                    capability_id=data["capability_id"],
                    version=data["version"],
                    task_family=data["task_family"],
                    input_type=data["input_type"],
                    output_type=data["output_type"],
                    exactness=data["exactness"],
                    provider_ids=tuple(data["provider_ids"]),
                    verifier_id=data.get("verifier_id"),
                    trust_state=TrustState(data["trust_state"]),
                    scope=data.get("scope", "unbounded"),
                    fidelity=TransitionFidelity(data.get("fidelity", "exact")),
                    component_capability_ids=tuple(data.get("component_capability_ids", ())),
                )
                registry._capabilities[capability.capability_id] = capability
                registry._index(capability)
            elif event.event_type == "REGISTRY_PROVIDER_UPSERTED":
                provider_id = data["provider_id"]
                executor = executors.get(provider_id)
                active = bool(data["active"]) and executor is not None
                if executor is None:
                    def unavailable_executor(_payload: Any, *, _provider_id: str = provider_id) -> Any:
                        raise RuntimeError(f"provider executor not bound: {_provider_id}")
                    executor = unavailable_executor
                registry._providers[provider_id] = Provider(
                    provider_id,
                    data["capability_id"],
                    executor,
                    active=active,
                    kind=ProviderKind(data.get("kind", "local_python")),
                    health=ProviderHealth(data.get("health", "healthy")),
                    boundary=ProviderBoundary(data.get("boundary", "local")),
                    endpoint=data.get("endpoint"),
                )
            elif event.event_type == "REGISTRY_PROVIDER_HEALTH_CHANGED":
                provider_id = data["provider_id"]
                provider = registry._providers[provider_id]
                registry._providers[provider_id] = provider.with_health(
                    ProviderHealth(data["health"])
                )
            elif event.event_type == "REGISTRY_CAPABILITY_PROMOTED":
                capability_id = data["capability_id"]
                capability = registry._capabilities[capability_id].with_trust_state(TrustState.TRUSTED)
                registry._capabilities[capability_id] = capability
                registry._index(capability)
            elif event.event_type == "REGISTRY_CAPABILITY_REVOKED":
                capability_id = data["capability_id"]
                capability = registry._capabilities[capability_id].with_trust_state(TrustState.REVOKED)
                registry._capabilities[capability_id] = capability
                registry._index(capability)
            elif event.event_type == "REGISTRY_COMPOSITE_INVALIDATED":
                capability_id = data["capability_id"]
                capability = registry._capabilities[capability_id].with_trust_state(TrustState.DEPRECATED)
                registry._capabilities[capability_id] = capability
                registry._index(capability)

        return registry

