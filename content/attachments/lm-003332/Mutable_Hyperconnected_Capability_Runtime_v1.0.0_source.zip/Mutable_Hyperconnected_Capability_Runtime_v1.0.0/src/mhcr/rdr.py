from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Callable
from typing import Any

from .history import Event, EventLog
from .models import Capability, Provider, ProviderBoundary, ProviderHealth, TaskPolicy
from .routing import CostAwareRouter, ProviderCostCatalog
from .registry import CapabilityRegistry


@dataclass(frozen=True, slots=True)
class MaterializedCapability:
    capability: Capability
    provider: Provider


@dataclass(frozen=True, slots=True)
class ProviderAttempt:
    provider_id: str
    elapsed_ms: float
    succeeded: bool


@dataclass(frozen=True, slots=True)
class ProviderExecutionOutcome:
    value: Any
    provider: Provider
    failed_provider_ids: tuple[str, ...] = ()
    attempts: tuple[ProviderAttempt, ...] = ()


class RDR:
    _HEALTH_PRIORITY = {
        ProviderHealth.HEALTHY: 0,
        ProviderHealth.DEGRADED: 1,
    }

    def __init__(
        self,
        registry: CapabilityRegistry,
        event_log: EventLog | None = None,
        *,
        cost_catalog: ProviderCostCatalog | None = None,
        clock: Callable[[], float] | None = None,
    ) -> None:
        self.registry = registry
        self.event_log = event_log
        self.cost_catalog = cost_catalog or ProviderCostCatalog()
        self.cost_router = CostAwareRouter(self.cost_catalog)
        self.clock = clock or perf_counter

    def eligible_providers(
        self, capability: Capability, policy: TaskPolicy | None = None,
        allowed_provider_ids: tuple[str, ...] | None = None,
    ) -> list[Provider]:
        ordered: list[tuple[int, int, Provider]] = []
        allowed = None if allowed_provider_ids is None else frozenset(allowed_provider_ids)
        for declared_index, provider_id in enumerate(capability.provider_ids):
            if allowed is not None and provider_id not in allowed:
                continue
            try:
                provider = self.registry.get_provider(provider_id)
            except KeyError:
                continue
            if provider.capability_id != capability.capability_id or not provider.active:
                continue
            priority = self._HEALTH_PRIORITY.get(provider.health)
            if priority is None:
                continue
            ordered.append((priority, declared_index, provider))
        ordered.sort(key=lambda item: (item[0], item[1]))
        base = [provider for _, _, provider in ordered]
        decision = self.cost_router.route(base, policy or TaskPolicy())
        return list(decision.providers)

    def routing_decision(
        self, capability: Capability, policy: TaskPolicy | None = None,
        allowed_provider_ids: tuple[str, ...] | None = None,
    ):
        ordered: list[tuple[int, int, Provider]] = []
        allowed = None if allowed_provider_ids is None else frozenset(allowed_provider_ids)
        for declared_index, provider_id in enumerate(capability.provider_ids):
            if allowed is not None and provider_id not in allowed:
                continue
            try:
                provider = self.registry.get_provider(provider_id)
            except KeyError:
                continue
            if provider.capability_id != capability.capability_id or not provider.active:
                continue
            priority = self._HEALTH_PRIORITY.get(provider.health)
            if priority is None:
                continue
            ordered.append((priority, declared_index, provider))
        ordered.sort(key=lambda item: (item[0], item[1]))
        base = [provider for _, _, provider in ordered]
        return self.cost_router.route(base, policy or TaskPolicy())

    @staticmethod
    def _policy_data(policy: TaskPolicy) -> dict[str, Any]:
        return {
            "local_only": policy.local_only,
            "max_latency_ms": policy.max_latency_ms,
            "max_external_cost_usd": policy.max_external_cost_usd,
            "max_network_bytes": policy.max_network_bytes,
            "max_verification_work": policy.max_verification_work,
            "max_risk_score": policy.max_risk_score,
            "prefer": [preference.value for preference in policy.prefer],
        }

    def _observe_attempt(self, provider: Provider, elapsed_ms: float) -> None:
        observation = self.cost_catalog.observe_latency(provider.provider_id, elapsed_ms)
        latency = observation.profile.latency_ms
        self._emit(
            "PROVIDER_COST_OBSERVED",
            {
                "provider_id": provider.provider_id,
                "metric": "latency_ms",
                "observed": elapsed_ms,
                "calibrated": latency.value,
                "sample_count": latency.sample_count,
                "evidence": latency.evidence.value,
            },
        )
        if observation.drifted:
            self._emit(
                "PROVIDER_COST_DRIFTED",
                {
                    "provider_id": provider.provider_id,
                    "metric": "latency_ms",
                    "previous": observation.previous_value,
                    "observed": observation.observed_value,
                    "drift_ratio": observation.drift_ratio,
                },
            )

    def has_eligible_provider(
        self, capability: Capability, policy: TaskPolicy | None = None
    ) -> bool:
        return bool(self.eligible_providers(capability, policy))

    def materialize(
        self, capability: Capability, policy: TaskPolicy | None = None
    ) -> MaterializedCapability:
        providers = self.eligible_providers(capability, policy)
        if not providers:
            raise RuntimeError(f"no eligible provider for {capability.capability_id}")
        return MaterializedCapability(capability=capability, provider=providers[0])

    def execute(self, materialized: MaterializedCapability, payload: Any) -> Any:
        return materialized.provider.execute(payload)

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self.event_log is not None:
            self.event_log.append(Event(event_type, data))

    def _record_boundary(
        self,
        task_id: str | None,
        capability: Capability,
        provider: Provider,
    ) -> None:
        if provider.boundary is ProviderBoundary.LOCAL:
            return
        self._emit(
            "PROVIDER_BOUNDARY_CROSSED",
            {
                "task_id": task_id,
                "capability_id": capability.capability_id,
                "provider_id": provider.provider_id,
                "provider_kind": provider.kind.value,
                "boundary": provider.boundary.value,
                "direction": "outbound",
            },
        )

    def execute_capability(
        self,
        capability: Capability,
        payload: Any,
        *,
        task_id: str | None = None,
        policy: TaskPolicy | None = None,
        allowed_provider_ids: tuple[str, ...] | None = None,
    ) -> ProviderExecutionOutcome:
        effective_policy = policy or TaskPolicy()
        decision = self.routing_decision(
            capability, effective_policy, allowed_provider_ids=allowed_provider_ids
        )
        providers = list(decision.providers)
        if not effective_policy.is_default:
            self._emit(
                "PROVIDER_ROUTING_DECISION",
                {
                    "task_id": task_id,
                    "capability_id": capability.capability_id,
                    "policy": self._policy_data(effective_policy),
                    "ordered_provider_ids": [provider.provider_id for provider in providers],
                    "rejected": [
                        {"provider_id": provider_id, "reason": reason}
                        for provider_id, reason in decision.rejected
                    ],
                },
            )
        if not providers:
            raise RuntimeError(f"no eligible provider for {capability.capability_id}")

        failed: list[str] = []
        attempts: list[ProviderAttempt] = []
        last_error: Exception | None = None
        for provider in providers:
            self._record_boundary(task_id, capability, provider)
            started = self.clock()
            try:
                value = provider.execute(payload)
            except Exception as exc:
                elapsed_ms = (self.clock() - started) * 1000.0
                self._observe_attempt(provider, elapsed_ms)
                attempts.append(ProviderAttempt(provider.provider_id, elapsed_ms, False))
                last_error = exc
                failed.append(provider.provider_id)
                self.registry.set_provider_health(provider.provider_id, ProviderHealth.UNAVAILABLE)
                self._emit(
                    "PROVIDER_EXECUTION_FAILED",
                    {
                        "task_id": task_id,
                        "capability_id": capability.capability_id,
                        "provider_id": provider.provider_id,
                        "error_type": type(exc).__name__,
                        "error": str(exc),
                    },
                )
                continue
            elapsed_ms = (self.clock() - started) * 1000.0
            self._observe_attempt(provider, elapsed_ms)
            attempts.append(ProviderAttempt(provider.provider_id, elapsed_ms, True))
            self._emit(
                "PROVIDER_EXECUTION_SUCCEEDED",
                {
                    "task_id": task_id,
                    "capability_id": capability.capability_id,
                    "provider_id": provider.provider_id,
                },
            )
            return ProviderExecutionOutcome(
                value, provider, tuple(failed), tuple(attempts)
            )

        detail = f": {last_error}" if last_error is not None else ""
        raise RuntimeError(f"all eligible providers failed for {capability.capability_id}{detail}")
