from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from collections.abc import Mapping
from typing import Any
import hashlib
import importlib
import importlib.metadata

from .history import Event, EventLog
from .models import Capability, ProviderBoundary, TaskContract, TaskPolicy
from .routing import ProviderCostCatalog
from .substrate import SubstrateProfileStore, SubstrateSelector


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(k): _freeze(v) for k, v in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, tuple):
        return tuple(_freeze(v) for v in value)
    if isinstance(value, set):
        return frozenset(_freeze(v) for v in value)
    return value


def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(k): _plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return [_plain(v) for v in sorted(value, key=repr)]
    return value


def _text(value: str, name: str) -> str:
    value = str(value)
    if not value:
        raise ValueError(f"{name} is required")
    return value


def _canonical_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{name} must be a non-negative canonical integer")
    return int(value)


@dataclass(frozen=True, slots=True)
class GCMCapacityBinding:
    dimension_id: str
    unit: str
    capacity: int
    required: int
    estimate_kind: str = "KNOWN"
    hard_safe: bool = True

    def __post_init__(self) -> None:
        object.__setattr__(self, "dimension_id", _text(self.dimension_id, "dimension_id"))
        object.__setattr__(self, "unit", _text(self.unit, "unit"))
        object.__setattr__(self, "capacity", _canonical_int(self.capacity, "capacity"))
        object.__setattr__(self, "required", _canonical_int(self.required, "required"))
        kind = str(self.estimate_kind).upper()
        if kind not in {"KNOWN", "BOUNDED", "ESTIMATED", "UNKNOWN"}:
            raise ValueError("invalid estimate_kind")
        object.__setattr__(self, "estimate_kind", kind)

    def as_dict(self) -> dict[str, Any]:
        return {
            "dimension_id": self.dimension_id,
            "unit": self.unit,
            "capacity": self.capacity,
            "required": self.required,
            "estimate_kind": self.estimate_kind,
            "hard_safe": self.hard_safe,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GCMCapacityBinding":
        return cls(
            str(data["dimension_id"]),
            str(data["unit"]),
            int(data["capacity"]),
            int(data["required"]),
            str(data.get("estimate_kind", "KNOWN")),
            bool(data.get("hard_safe", True)),
        )


@dataclass(frozen=True, slots=True)
class GCMProviderBinding:
    binding_id: str
    provider_id: str
    resource_id: str
    configuration_id: str
    executor_id: str
    resource_kind: str
    availability: str = "AVAILABLE"
    capabilities: tuple[str, ...] = ()
    locality: str = "local"
    dimensions: tuple[GCMCapacityBinding, ...] = ()
    estimates: Mapping[str, float] = field(default_factory=dict)
    quality: float = 1.0
    priority: int = 0
    metadata: Mapping[str, Any] = field(default_factory=dict)
    substrate_profile_id: str | None = None

    def __post_init__(self) -> None:
        for name in (
            "binding_id", "provider_id", "resource_id", "configuration_id", "executor_id", "resource_kind", "locality"
        ):
            object.__setattr__(self, name, _text(getattr(self, name), name))
        availability = str(self.availability).upper()
        if availability not in {"AVAILABLE", "UNAVAILABLE", "UNKNOWN"}:
            raise ValueError("invalid availability")
        object.__setattr__(self, "availability", availability)
        capabilities = tuple(sorted({str(v) for v in self.capabilities if str(v)}))
        object.__setattr__(self, "capabilities", capabilities)
        dimensions = tuple(self.dimensions)
        if len({item.dimension_id for item in dimensions}) != len(dimensions):
            raise ValueError("duplicate capacity dimension")
        object.__setattr__(self, "dimensions", dimensions)
        estimates: dict[str, float] = {}
        for key, raw in self.estimates.items():
            key = _text(str(key), "estimate key")
            value = float(raw)
            if value < 0:
                raise ValueError(f"estimate cannot be negative: {key}")
            estimates[key] = value
        object.__setattr__(self, "estimates", MappingProxyType(dict(sorted(estimates.items()))))
        quality = float(self.quality)
        if quality < 0:
            raise ValueError("quality cannot be negative")
        object.__setattr__(self, "quality", quality)
        object.__setattr__(self, "priority", _canonical_int(self.priority, "priority"))
        if self.substrate_profile_id is not None:
            object.__setattr__(self, "substrate_profile_id", _text(self.substrate_profile_id, "substrate_profile_id"))
        object.__setattr__(self, "metadata", _freeze(self.metadata))

    def as_dict(self) -> dict[str, Any]:
        return {
            "binding_id": self.binding_id,
            "provider_id": self.provider_id,
            "resource_id": self.resource_id,
            "configuration_id": self.configuration_id,
            "executor_id": self.executor_id,
            "resource_kind": self.resource_kind,
            "availability": self.availability,
            "capabilities": list(self.capabilities),
            "locality": self.locality,
            "dimensions": [item.as_dict() for item in self.dimensions],
            "estimates": {key: float(value) for key, value in self.estimates.items()},
            "quality": self.quality,
            "priority": self.priority,
            "metadata": _plain(self.metadata),
            "substrate_profile_id": self.substrate_profile_id,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GCMProviderBinding":
        return cls(
            binding_id=str(data["binding_id"]),
            provider_id=str(data["provider_id"]),
            resource_id=str(data["resource_id"]),
            configuration_id=str(data["configuration_id"]),
            executor_id=str(data["executor_id"]),
            resource_kind=str(data["resource_kind"]),
            availability=str(data.get("availability", "AVAILABLE")),
            capabilities=tuple(data.get("capabilities", ())),
            locality=str(data.get("locality", "local")),
            dimensions=tuple(GCMCapacityBinding.from_dict(item) for item in data.get("dimensions", ())),
            estimates=dict(data.get("estimates", {})),
            quality=float(data.get("quality", 1.0)),
            priority=int(data.get("priority", 0)),
            metadata=dict(data.get("metadata", {})),
            substrate_profile_id=(
                None if data.get("substrate_profile_id") is None else str(data.get("substrate_profile_id"))
            ),
        )

    def as_event_data(self) -> dict[str, Any]:
        return self.as_dict()


@dataclass(frozen=True, slots=True)
class GCMAllocationContext:
    world_boundary: str = "world:mhcr-compute"
    world_revision: int = 1
    foundation_id: str = "foundation:mhcr-compute"
    foundation_version: int = 1
    authority_ref: str = "authority:mhcr-compute"
    principal: str = "mhcr:runtime"
    effective_permissions: tuple[str, ...] = ("compute",)
    budget_ref: str = "budget:mhcr-none"
    resource_tick: int = 1
    max_states: int = 100
    max_backtracks: int = 100

    def __post_init__(self) -> None:
        for name in ("world_boundary", "foundation_id", "authority_ref", "principal", "budget_ref"):
            object.__setattr__(self, name, _text(getattr(self, name), name))
        for name in ("world_revision", "foundation_version", "resource_tick", "max_states", "max_backtracks"):
            object.__setattr__(self, name, _canonical_int(getattr(self, name), name))
        if self.max_states < 1:
            raise ValueError("max_states must be positive")
        object.__setattr__(self, "effective_permissions", tuple(sorted(set(self.effective_permissions))))


@dataclass(frozen=True, slots=True)
class GCMAllocationDecision:
    decision_id: str
    task_id: str
    capability_id: str
    provider_id: str
    binding_id: str
    resource_id: str
    configuration_id: str
    executor_id: str
    resource_snapshot_id: str
    b1_plan_id: str
    allocation_plan_id: str
    allocation_plan_digest: str
    gcm_package_version: str
    reason: str
    evidence: Mapping[str, Any] = field(default_factory=dict)
    substrate_profile_id: str | None = None
    substrate_kind: str | None = None
    substrate_realization: str | None = None
    substrate_selection_id: str | None = None
    substrate_fallback_used: bool = False

    def __post_init__(self) -> None:
        for name in (
            "decision_id", "task_id", "capability_id", "provider_id", "binding_id", "resource_id",
            "configuration_id", "executor_id", "resource_snapshot_id", "b1_plan_id", "allocation_plan_id",
            "allocation_plan_digest", "gcm_package_version", "reason",
        ):
            object.__setattr__(self, name, _text(getattr(self, name), name))
        for name in ("substrate_profile_id", "substrate_kind", "substrate_realization", "substrate_selection_id"):
            value = getattr(self, name)
            if value is not None:
                object.__setattr__(self, name, _text(value, name))
        object.__setattr__(self, "evidence", _freeze(self.evidence))

    def as_event_data(self) -> dict[str, Any]:
        return {
            "decision_id": self.decision_id,
            "task_id": self.task_id,
            "capability_id": self.capability_id,
            "provider_id": self.provider_id,
            "binding_id": self.binding_id,
            "resource_id": self.resource_id,
            "configuration_id": self.configuration_id,
            "executor_id": self.executor_id,
            "resource_snapshot_id": self.resource_snapshot_id,
            "b1_plan_id": self.b1_plan_id,
            "allocation_plan_id": self.allocation_plan_id,
            "allocation_plan_digest": self.allocation_plan_digest,
            "gcm_package_version": self.gcm_package_version,
            "reason": self.reason,
            "evidence": _plain(self.evidence),
            "substrate_profile_id": self.substrate_profile_id,
            "substrate_kind": self.substrate_kind,
            "substrate_realization": self.substrate_realization,
            "substrate_selection_id": self.substrate_selection_id,
            "substrate_fallback_used": self.substrate_fallback_used,
        }


class GCMResourceBindingStore:
    def __init__(self, repository: Any | None = None, event_log: EventLog | None = None) -> None:
        self.repository = repository
        self.event_log = event_log
        self._records: dict[str, GCMProviderBinding] = {}
        if repository is not None:
            loader = getattr(repository, "load_gcm_resource_bindings", None)
            if callable(loader):
                self._records = {record.binding_id: record for record in loader()}

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self.event_log is not None:
            self.event_log.append(Event(event_type, data))

    def upsert(self, binding: GCMProviderBinding) -> GCMProviderBinding:
        existing = self._records.get(binding.binding_id)
        if existing is not None and existing.provider_id != binding.provider_id:
            raise ValueError("binding id cannot be rebound to another provider")
        self._records[binding.binding_id] = binding
        if self.repository is not None:
            saver = getattr(self.repository, "save_gcm_resource_binding", None)
            if callable(saver):
                saver(binding)
        self._emit("GCM_RESOURCE_BINDING_UPSERTED", binding.as_event_data())
        return binding

    def remove(self, binding_id: str) -> None:
        if binding_id not in self._records:
            raise KeyError(binding_id)
        del self._records[binding_id]
        if self.repository is not None:
            remover = getattr(self.repository, "delete_gcm_resource_binding", None)
            if callable(remover):
                remover(binding_id)
        self._emit("GCM_RESOURCE_BINDING_REMOVED", {"binding_id": binding_id})

    def get(self, binding_id: str) -> GCMProviderBinding:
        return self._records[binding_id]

    def records(self) -> tuple[GCMProviderBinding, ...]:
        return tuple(self._records[key] for key in sorted(self._records))

    def for_provider(self, provider_id: str) -> tuple[GCMProviderBinding, ...]:
        return tuple(record for record in self.records() if record.provider_id == provider_id)


class GCMIntegrationError(RuntimeError):
    pass


class GCMUnavailableError(GCMIntegrationError):
    pass


class GCMAllocationRejectedError(GCMIntegrationError):
    def __init__(self, message: str, failures: tuple[Mapping[str, Any], ...] = ()) -> None:
        super().__init__(message)
        self.failures = tuple(failures)


class GCMPhaseBAdapter:
    """Optional membrane from MHCR provider candidates to accepted GCM Phase-B allocation APIs."""

    _POLICY_LIMITS = {
        "max_latency_ms": "latency_ms",
        "max_external_cost_usd": "external_cost_usd",
        "max_network_bytes": "network_bytes",
        "max_verification_work": "verification_work",
        "max_risk_score": "risk_score",
    }

    def __init__(
        self,
        binding_store: GCMResourceBindingStore,
        *,
        cost_catalog: ProviderCostCatalog | None = None,
        context: GCMAllocationContext | None = None,
        event_log: EventLog | None = None,
        substrate_catalog: SubstrateProfileStore | None = None,
    ) -> None:
        self.binding_store = binding_store
        self.cost_catalog = cost_catalog or ProviderCostCatalog()
        self.context = context or GCMAllocationContext()
        self.event_log = event_log
        self.substrate_catalog = substrate_catalog
        self.substrate_selector = None if substrate_catalog is None else SubstrateSelector(substrate_catalog)
        self.allocation_count = 0

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self.event_log is not None:
            self.event_log.append(Event(event_type, data))

    @staticmethod
    def _load_gcm_api() -> dict[str, Any]:
        try:
            gcm = importlib.import_module("gcm_runtime")
            model = importlib.import_module("gcm_runtime.model")
            orchestration = importlib.import_module("gcm_runtime.orchestration")
        except ModuleNotFoundError as exc:
            raise GCMUnavailableError(
                "gcm-reference-runtime is required when GCMPhaseBAdapter is configured"
            ) from exc

        required_root = (
            "ResourceAvailability", "ResourceInventory", "ResourceKind", "ResourceRecord",
            "StaticResourceProvider", "AllocationSearchLimits", "Allocator0", "CapacityDimension",
            "DemandEstimate", "EstimateKind", "ResourceDemand", "build_allocation_candidates",
            "build_allocation_request",
        )
        missing = [name for name in required_root if not hasattr(gcm, name)]
        for name in ("OperationType", "WorldRef", "FoundationRef", "OperationRequest"):
            if not hasattr(model, name):
                missing.append(f"model.{name}")
        for name in ("ComputationIntent", "PlanningContext", "CandidateSpec", "evaluate_and_select"):
            if not hasattr(orchestration, name):
                missing.append(f"orchestration.{name}")
        if missing:
            raise GCMUnavailableError("incompatible GCM Phase-B public API: " + ", ".join(missing))
        return {"root": gcm, "model": model, "orchestration": orchestration}

    @staticmethod
    def _gcm_version() -> str:
        try:
            return importlib.metadata.version("gcm-reference-runtime")
        except importlib.metadata.PackageNotFoundError:
            return "0.4.0-source"

    @staticmethod
    def _effective_dimensions(binding: GCMProviderBinding) -> tuple[GCMCapacityBinding, ...]:
        if binding.dimensions:
            return binding.dimensions
        return (GCMCapacityBinding("mhcr.slot", "logical-unit", 1, 1),)

    def _ordered_bindings(self, ordered_provider_ids: tuple[str, ...]) -> tuple[GCMProviderBinding, ...]:
        rank = {provider_id: index for index, provider_id in enumerate(ordered_provider_ids)}
        rows: list[GCMProviderBinding] = []
        for provider_id in ordered_provider_ids:
            rows.extend(self.binding_store.for_provider(provider_id))
        rows.sort(key=lambda item: (rank[item.provider_id], item.priority, item.binding_id))
        return tuple(rows)

    @staticmethod
    def _metric_value(metric: Any) -> float | None:
        if getattr(metric, "known", False):
            return float(metric.value)
        return None

    def _candidate_estimates(
        self,
        binding: GCMProviderBinding,
        *,
        provider_rank: int,
    ) -> dict[str, float]:
        estimates = {str(key): float(value) for key, value in binding.estimates.items()}
        profile = self.cost_catalog.get(binding.provider_id)
        measured = {
            "latency_ms": self._metric_value(profile.latency_ms),
            "monetary_cost": self._metric_value(profile.monetary_cost_usd),
            "network_bytes": self._metric_value(profile.network_bytes),
            "verification_work": self._metric_value(profile.verification_work),
            "risk_score": self._metric_value(profile.risk_score),
        }
        for key, value in measured.items():
            if value is not None:
                estimates[key] = value

        is_local = binding.locality.lower() == "local"
        if is_local:
            estimates["external_cost_usd"] = 0.0
            estimates["network_bytes"] = 0.0
        else:
            if "external_cost_usd" not in estimates:
                monetary = estimates.get("monetary_cost")
                if monetary is not None:
                    estimates["external_cost_usd"] = float(monetary)
        if binding.substrate_profile_id is not None and self.substrate_catalog is not None:
            try:
                substrate_profile = self.substrate_catalog.get(binding.substrate_profile_id)
            except KeyError as exc:
                raise GCMIntegrationError(
                    f"unknown substrate profile: {binding.substrate_profile_id}"
                ) from exc
            if substrate_profile.energy_units.known:
                assert substrate_profile.energy_units.value is not None
                estimates["energy_units"] = float(substrate_profile.energy_units.value)
            if substrate_profile.switching_cost_units.known:
                assert substrate_profile.switching_cost_units.value is not None
                estimates["switching_cost_units"] = float(substrate_profile.switching_cost_units.value)
        estimates["mhcr_priority"] = float(provider_rank * 100000 + binding.priority)
        return estimates

    @classmethod
    def _hard_limits(cls, policy: TaskPolicy) -> dict[str, float]:
        result: dict[str, float] = {}
        for attribute, dimension in cls._POLICY_LIMITS.items():
            value = getattr(policy, attribute)
            if value is not None:
                result[dimension] = float(value)
        return result

    @staticmethod
    def _substrate_hard_limits(policy: Any) -> dict[str, float]:
        result: dict[str, float] = {}
        if policy.max_energy_units is not None:
            result["energy_units"] = float(policy.max_energy_units)
        if policy.max_switching_cost_units is not None:
            result["switching_cost_units"] = float(policy.max_switching_cost_units)
        return result

    @staticmethod
    def _failure_data(failure: Any) -> Mapping[str, Any]:
        return {
            "failure_code": getattr(failure.failure_code, "value", str(failure.failure_code)),
            "task_ids": list(failure.task_ids),
            "candidate_ids": list(failure.candidate_ids),
            "resource_ids": list(failure.resource_ids),
            "dimensions": list(failure.dimensions),
            "observed": _plain(failure.observed),
            "required": _plain(failure.required),
            "evidence": _plain(failure.evidence),
        }

    def allocate(
        self,
        task: TaskContract,
        capability: Capability,
        ordered_provider_ids: tuple[str, ...],
    ) -> GCMAllocationDecision:
        api = self._load_gcm_api()
        gcm = api["root"]
        model = api["model"]
        orchestration = api["orchestration"]
        bindings = self._ordered_bindings(tuple(ordered_provider_ids))
        substrate_selection = None
        if self.substrate_selector is not None:
            substrate_selection = self.substrate_selector.select(
                task, capability.capability_id, bindings
            )
            bindings = tuple(substrate_selection.bindings)
            self._emit("SUBSTRATE_SELECTION_MADE", substrate_selection.certificate.as_dict())
        elif not task.substrate_policy.is_default:
            failures = ({
                "failure_code": "SUBSTRATE_CATALOG_UNAVAILABLE",
                "provider_ids": list(ordered_provider_ids),
            },)
            self._emit(
                "GCM_ALLOCATION_REJECTED",
                {"task_id": task.task_id, "capability_id": capability.capability_id, "failures": list(failures)},
            )
            raise GCMAllocationRejectedError("substrate policy requires a substrate catalog", failures)
        binding_rank = {binding.binding_id: index for index, binding in enumerate(bindings)}
        self.allocation_count += 1
        self._emit(
            "GCM_ALLOCATION_REQUESTED",
            {
                "task_id": task.task_id,
                "capability_id": capability.capability_id,
                "ordered_provider_ids": list(ordered_provider_ids),
                "binding_ids": [item.binding_id for item in bindings],
            },
        )
        if not bindings:
            failures = ({
                "failure_code": "NO_GCM_BINDING",
                "provider_ids": list(ordered_provider_ids),
                "substrate_rejected": (
                    [] if substrate_selection is None else list(substrate_selection.certificate.rejected)
                ),
            },)
            self._emit(
                "GCM_ALLOCATION_REJECTED",
                {"task_id": task.task_id, "capability_id": capability.capability_id, "failures": list(failures)},
            )
            raise GCMAllocationRejectedError("no GCM resource binding for eligible providers", failures)

        # Build one deterministic B2 snapshot, merging multiple configurations on the same resource.
        grouped: dict[tuple[str, str], list[GCMProviderBinding]] = {}
        for binding in bindings:
            grouped.setdefault((binding.provider_id, binding.resource_id), []).append(binding)

        provider_records: dict[str, list[Any]] = {}
        resource_binding_ids: dict[str, set[str]] = {}
        for (provider_id, resource_id), group in sorted(grouped.items()):
            first = group[0]
            for item in group:
                if item.substrate_profile_id is not None and self.substrate_catalog is not None:
                    profile = self.substrate_catalog.get(item.substrate_profile_id)
                    if profile.gcm_resource_kind != item.resource_kind:
                        raise GCMIntegrationError(
                            f"substrate profile/resource kind mismatch for {item.binding_id}: "
                            f"{profile.gcm_resource_kind} != {item.resource_kind}"
                        )
            if any(
                (item.resource_kind, item.availability, item.locality) !=
                (first.resource_kind, first.availability, first.locality)
                for item in group
            ):
                raise GCMIntegrationError(f"inconsistent resource metadata for {resource_id}")
            dimension_capacities: dict[str, float] = {}
            capabilities: set[str] = set()
            configuration_estimates: dict[str, dict[str, float]] = {}
            configuration_quality: dict[str, float] = {}
            for item in group:
                capabilities.update(item.capabilities)
                for dimension in self._effective_dimensions(item):
                    existing = dimension_capacities.get(dimension.dimension_id)
                    if existing is not None and existing != float(dimension.capacity):
                        raise GCMIntegrationError(
                            f"inconsistent capacity for {resource_id}:{dimension.dimension_id}"
                        )
                    dimension_capacities[dimension.dimension_id] = float(dimension.capacity)
                provider_rank = binding_rank[item.binding_id]
                configuration_estimates[item.configuration_id] = self._candidate_estimates(
                    item, provider_rank=provider_rank
                )
                configuration_quality[item.configuration_id] = item.quality
                resource_binding_ids.setdefault(resource_id, set()).add(item.binding_id)
            try:
                resource_kind = gcm.ResourceKind(first.resource_kind)
                availability = gcm.ResourceAvailability(first.availability)
            except ValueError as exc:
                raise GCMIntegrationError(f"invalid GCM resource enum for {resource_id}") from exc
            record = gcm.ResourceRecord(
                resource_id=resource_id,
                provider_id=provider_id,
                kind=resource_kind,
                availability=availability,
                capabilities=frozenset(capabilities),
                capacities=dimension_capacities,
                configuration_estimates=configuration_estimates,
                configuration_quality=configuration_quality,
                locality=first.locality,
                metadata={
                    "mhcr_binding_ids": sorted(resource_binding_ids[resource_id]),
                    "mhcr_substrate_profile_ids": sorted(
                        {item.substrate_profile_id for item in group if item.substrate_profile_id is not None}
                    ),
                },
            )
            provider_records.setdefault(provider_id, []).append(record)

        resource_providers = tuple(
            gcm.StaticResourceProvider(provider_id, tuple(sorted(records, key=lambda item: item.resource_id)))
            for provider_id, records in sorted(provider_records.items())
        )
        snapshot = gcm.ResourceInventory(resource_providers).capture(tick=self.context.resource_tick)
        resource_capabilities = {
            record.resource_id: record.capabilities for record in snapshot.resources
        }
        resource_availability = {
            record.resource_id: record.availability for record in snapshot.resources
        }
        executor_capabilities: dict[str, frozenset[str]] = {}
        for binding in bindings:
            executor_capabilities[binding.executor_id] = frozenset(
                set(executor_capabilities.get(binding.executor_id, frozenset())) | set(binding.capabilities)
            )

        world_ref = model.WorldRef(self.context.world_boundary, self.context.world_revision)
        foundation_ref = model.FoundationRef(self.context.foundation_id, self.context.foundation_version)
        intent = orchestration.ComputationIntent(
            intent_id=f"intent:mhcr:{task.task_id}:{capability.capability_id}",
            operation_type=model.OperationType.COMPUTE,
            target=capability.address,
            payload={"task_id": task.task_id, "family": task.family},
            principal=self.context.principal,
            required_permissions=frozenset({"compute"}),
            hard_limits={
                **self._hard_limits(task.policy),
                **self._substrate_hard_limits(task.substrate_policy),
            },
            objective_weights={"mhcr_priority": 1.0},
            allow_approximation=task.exactness != "exact",
        )
        request = model.OperationRequest(
            operation_id=f"op:mhcr:{task.task_id}",
            operation_type=model.OperationType.COMPUTE,
            target=capability.address,
            payload={"task_id": task.task_id},
            principal=self.context.principal,
            required_permissions=frozenset({"compute"}),
        )
        planning_context = orchestration.PlanningContext(
            world_ref=world_ref,
            foundation_ref=foundation_ref,
            principal=self.context.principal,
            effective_permissions=frozenset(self.context.effective_permissions),
            resource_snapshot={"cpu": 1.0},
            configuration_schema_version="mhcr-gcm-bridge-v0.8",
        )

        binding_by_route: dict[str, GCMProviderBinding] = {}
        candidate_specs: list[Any] = []
        for binding in bindings:
            provider_rank = binding_rank[binding.binding_id]
            estimates = self._candidate_estimates(binding, provider_rank=provider_rank)
            route_id = f"route:mhcr:{binding.binding_id}"
            binding_by_route[route_id] = binding
            candidate_specs.append(
                orchestration.CandidateSpec(
                    route_id=route_id,
                    executor_id=binding.executor_id,
                    configuration_id=binding.configuration_id,
                    required_capabilities=frozenset({task.family}),
                    estimates=estimates,
                    quality=binding.quality,
                    approximate=capability.exactness != "exact",
                    metadata={
                        "mhcr_binding_id": binding.binding_id,
                        "mhcr_substrate_profile_id": binding.substrate_profile_id,
                    },
                    resource_id=binding.resource_id,
                    resource_snapshot_id=snapshot.snapshot_id,
                )
            )

        b1_plan = orchestration.evaluate_and_select(
            intent,
            request,
            planning_context,
            candidate_specs,
            foundation_rules={"allow_operations": ["compute"]},
            executor_capabilities=executor_capabilities,
            resource_capabilities=resource_capabilities,
            resource_availability=resource_availability,
        )
        safe_evaluations = [evaluation for evaluation in b1_plan.alternatives if evaluation.safe]
        if not safe_evaluations:
            failures = tuple(
                {
                    "failure_code": "B1_NO_SAFE_CANDIDATE",
                    "route_id": evaluation.candidate.route_id,
                    "reasons": list(evaluation.rejection_reasons),
                }
                for evaluation in b1_plan.alternatives
            )
            self._emit(
                "GCM_ALLOCATION_REJECTED",
                {"task_id": task.task_id, "capability_id": capability.capability_id, "failures": list(failures)},
            )
            raise GCMAllocationRejectedError("GCM B1 found no safe compute realization", failures)

        demands: dict[tuple[str, str], Any] = {}
        rank_by_route = {
            evaluation.candidate.route_id: rank for rank, evaluation in enumerate(safe_evaluations)
        }
        candidate_id_to_binding: dict[str, GCMProviderBinding] = {}
        dimensions: dict[str, Any] = {}
        for evaluation in safe_evaluations:
            binding = binding_by_route[evaluation.candidate.route_id]
            candidate_id = (
                f"{task.task_id}|{rank_by_route[evaluation.candidate.route_id]:06d}|{binding.binding_id}"
            )
            dimension_estimates: dict[str, Any] = {}
            for dimension in self._effective_dimensions(binding):
                existing = dimensions.get(dimension.dimension_id)
                if existing is not None and existing.unit != dimension.unit:
                    raise GCMIntegrationError(
                        f"inconsistent unit for dimension {dimension.dimension_id}"
                    )
                dimensions[dimension.dimension_id] = gcm.CapacityDimension(
                    dimension.dimension_id, dimension.unit
                )
                kind = gcm.EstimateKind(dimension.estimate_kind)
                if kind is gcm.EstimateKind.KNOWN:
                    estimate = gcm.DemandEstimate(kind, dimension.unit, value=dimension.required)
                elif kind is gcm.EstimateKind.BOUNDED:
                    estimate = gcm.DemandEstimate(
                        kind, dimension.unit, lower=dimension.required, upper=dimension.required
                    )
                elif kind is gcm.EstimateKind.ESTIMATED:
                    estimate = gcm.DemandEstimate(
                        kind,
                        dimension.unit,
                        value=dimension.required,
                        estimator_id="mhcr:gcm-binding",
                        hard_safe=dimension.hard_safe,
                    )
                else:
                    estimate = gcm.DemandEstimate(kind, dimension.unit)
                dimension_estimates[dimension.dimension_id] = estimate
            demand = gcm.ResourceDemand(
                task_id=task.task_id,
                candidate_id=candidate_id,
                dimensions=dimension_estimates,
                estimate_provenance={
                    "source": "mhcr-gcm-binding",
                    "binding_id": binding.binding_id,
                },
            )
            demands[(task.task_id, evaluation.candidate.route_id)] = demand
            candidate_id_to_binding[candidate_id] = binding

        execution_plans = {task.task_id: b1_plan}
        allocation_candidates = gcm.build_allocation_candidates(execution_plans, demands, snapshot)
        allocation_request = gcm.build_allocation_request(
            f"alloc:mhcr:{task.task_id}:{capability.capability_id}",
            execution_plans,
            allocation_candidates,
            snapshot,
            budget_ref=self.context.budget_ref,
            search_limits=gcm.AllocationSearchLimits(
                self.context.max_states, self.context.max_backtracks
            ),
        )
        result = gcm.Allocator0(dimensions).allocate(
            allocation_request, allocation_candidates, snapshot
        )
        if isinstance(result, gcm.AllocationRejected):
            failures = tuple(self._failure_data(item) for item in result.failures)
            self._emit(
                "GCM_ALLOCATION_REJECTED",
                {
                    "task_id": task.task_id,
                    "capability_id": capability.capability_id,
                    "resource_snapshot_id": snapshot.snapshot_id,
                    "failures": list(failures),
                },
            )
            raise GCMAllocationRejectedError("GCM B3 allocation rejected", failures)

        if len(result.plan.assignments) != 1:
            raise GCMIntegrationError("v0.8 expects exactly one assignment per capability execution")
        assignment = result.plan.assignments[0]
        binding = candidate_id_to_binding.get(assignment.candidate_id)
        if binding is None:
            raise GCMIntegrationError("GCM assignment cannot be mapped back to MHCR binding")
        raw_id = "|".join(
            (
                task.task_id,
                capability.capability_id,
                assignment.candidate_id,
                result.plan.plan_digest,
            )
        )
        decision_id = "gcm-decision:" + hashlib.sha256(raw_id.encode("utf-8")).hexdigest()[:24]
        selected_profile = None
        if binding.substrate_profile_id is not None and self.substrate_catalog is not None:
            selected_profile = self.substrate_catalog.get(binding.substrate_profile_id)
        fallback_used = False
        substrate_policy = task.substrate_policy
        if selected_profile is not None:
            if substrate_policy.preferred_profile_ids:
                fallback_used = selected_profile.profile_id != substrate_policy.preferred_profile_ids[0]
            elif substrate_policy.preferred_kinds:
                fallback_used = selected_profile.kind.value != substrate_policy.preferred_kinds[0]
        decision = GCMAllocationDecision(
            decision_id=decision_id,
            task_id=task.task_id,
            capability_id=capability.capability_id,
            provider_id=binding.provider_id,
            binding_id=binding.binding_id,
            resource_id=binding.resource_id,
            configuration_id=binding.configuration_id,
            executor_id=binding.executor_id,
            resource_snapshot_id=snapshot.snapshot_id,
            b1_plan_id=b1_plan.plan_id,
            allocation_plan_id=result.plan.allocation_plan_id,
            allocation_plan_digest=result.plan.plan_digest,
            gcm_package_version=self._gcm_version(),
            reason="GCM Phase-B logical allocation selected a resource/configuration binding",
            evidence={
                "b1_decision": b1_plan.decision.value,
                "b1_selected_route_id": (
                    None if b1_plan.selected is None else b1_plan.selected.candidate.route_id
                ),
                "b3_states_explored": result.evidence.states_explored,
                "b3_backtracks": result.evidence.backtracks,
                "b3_assignment_trace": list(result.evidence.assignment_trace),
                "resource_kind": binding.resource_kind,
                "locality": binding.locality,
                "substrate_rejected": (
                    [] if substrate_selection is None else list(substrate_selection.certificate.rejected)
                ),
                "substrate_energy_units": (
                    None if selected_profile is None or not selected_profile.energy_units.known
                    else selected_profile.energy_units.value
                ),
                "substrate_switching_cost_units": (
                    None if selected_profile is None or not selected_profile.switching_cost_units.known
                    else selected_profile.switching_cost_units.value
                ),
            },
            substrate_profile_id=(None if selected_profile is None else selected_profile.profile_id),
            substrate_kind=(None if selected_profile is None else selected_profile.kind.value),
            substrate_realization=(None if selected_profile is None else selected_profile.realization.value),
            substrate_selection_id=(
                None if substrate_selection is None else substrate_selection.certificate.selection_id
            ),
            substrate_fallback_used=fallback_used,
        )
        self._emit("GCM_ALLOCATION_SELECTED", decision.as_event_data())
        return decision
