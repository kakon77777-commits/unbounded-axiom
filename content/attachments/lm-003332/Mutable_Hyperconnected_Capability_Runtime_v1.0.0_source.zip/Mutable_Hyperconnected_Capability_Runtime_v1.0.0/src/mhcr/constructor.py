from __future__ import annotations

from dataclasses import dataclass
import hashlib
import re
from typing import Any, Callable

from .accounting import CostRecord, CostVector
from .models import (
    Capability,
    Provider,
    ProviderBoundary,
    ProviderKind,
    TaskContract,
    TrustState,
)
from .sandbox import (
    CandidateArtifactStatus,
    CandidatePolicyViolation,
    GeneratedArtifactStore,
    GeneratedCandidateArtifact,
    PythonSandboxRunner,
    SandboxError,
)


@dataclass(frozen=True, slots=True)
class TemplateSpec:
    task_family: str
    input_type: str
    output_type: str
    execute: Callable[[Any], Any]
    verifier_id: str
    exactness: str = "exact"
    provider_local_work: float = 1.0
    formation_work: float = 0.0


@dataclass(frozen=True, slots=True)
class ConstructedCapability:
    capability: Capability
    provider: Provider
    cost_record: CostRecord


class TemplateConstructor:
    """Safe MVP constructor: instantiates only explicitly registered templates."""

    def __init__(self, templates: list[TemplateSpec] | tuple[TemplateSpec, ...]) -> None:
        self._templates = {template.task_family: template for template in templates}
        self.construct_count = 0

    @staticmethod
    def candidate_identity(task: TaskContract) -> tuple[str, str]:
        slug = re.sub(r"[^a-zA-Z0-9_.-]+", "_", task.family).strip("_").lower()
        return f"cap.generated.{slug}", f"provider.generated.{slug}"

    def construct(self, task: TaskContract) -> ConstructedCapability:
        template = self._templates.get(task.family)
        if template is None:
            raise LookupError(f"no safe constructor template for task family: {task.family}")
        if (
            template.input_type != task.input_type
            or template.output_type != task.output_type
            or template.exactness != task.exactness
        ):
            raise LookupError("template contract does not match task contract")

        self.construct_count += 1
        capability_id, provider_id = self.candidate_identity(task)
        capability = Capability(
            capability_id=capability_id,
            version="1.0.0",
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
            provider_ids=(provider_id,),
            verifier_id=template.verifier_id,
            trust_state=TrustState.CANDIDATE,
        )
        provider = Provider(provider_id, capability_id, template.execute)
        cost = CostRecord(
            provider_id,
            CostVector(
                local_work=template.provider_local_work,
                offline_work=template.formation_work,
            ),
        )
        return ConstructedCapability(capability, provider, cost)


@dataclass(frozen=True, slots=True)
class GeneratedSourceSpec:
    source: str
    entrypoint: str = "solve"
    provider_local_work: float = 1.0
    formation_work: float = 5.0


class CandidateConstructionError(RuntimeError):
    def __init__(self, message: str, *, capability_id: str, provider_id: str, artifact_id: str | None = None) -> None:
        super().__init__(message)
        self.capability_id = capability_id
        self.provider_id = provider_id
        self.artifact_id = artifact_id


class SandboxedSourceConstructor:
    """Generate source as an untrusted proposal and realize it only through a sandbox runner."""

    def __init__(
        self,
        generator: Callable[[TaskContract], GeneratedSourceSpec],
        *,
        artifact_store: GeneratedArtifactStore,
        runner: PythonSandboxRunner,
        verifier_id: str,
    ) -> None:
        self.generator = generator
        self.artifact_store = artifact_store
        self.runner = runner
        self.verifier_id = verifier_id
        self.construct_count = 0
        self._artifact_by_capability: dict[str, str] = {}

    @staticmethod
    def candidate_identity(task: TaskContract) -> tuple[str, str]:
        return TemplateConstructor.candidate_identity(task)

    @staticmethod
    def _slug(task: TaskContract) -> str:
        return re.sub(r"[^a-zA-Z0-9_.-]+", "_", task.family).strip("_").lower()

    def _artifact_for(self, capability_id: str) -> GeneratedCandidateArtifact | None:
        artifact_id = self._artifact_by_capability.get(capability_id)
        if artifact_id is not None:
            try:
                return self.artifact_store.get(artifact_id)
            except KeyError:
                pass
        candidates = self.artifact_store.find_by_capability(capability_id, active_only=False)
        if not candidates:
            return None
        return candidates[-1]

    def construct(self, task: TaskContract) -> ConstructedCapability:
        self.construct_count += 1
        capability_id, provider_id = self.candidate_identity(task)
        try:
            spec = self.generator(task)
        except Exception as exc:
            raise CandidateConstructionError(
                f"generator failed: {type(exc).__name__}: {exc}",
                capability_id=capability_id,
                provider_id=provider_id,
            ) from exc
        if not isinstance(spec, GeneratedSourceSpec):
            raise CandidateConstructionError(
                "generator must return GeneratedSourceSpec",
                capability_id=capability_id,
                provider_id=provider_id,
            )

        source_hash = hashlib.sha256(spec.source.encode("utf-8")).hexdigest()
        artifact_id = f"artifact.generated.{self._slug(task)}.{source_hash[:16]}"
        artifact = GeneratedCandidateArtifact.create(
            artifact_id=artifact_id,
            capability_id=capability_id,
            provider_id=provider_id,
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
            source=spec.source,
            entrypoint=spec.entrypoint,
            policy_id=self.runner.policy.policy_id,
            metadata={"source_kind": "generated_python", "generator": "runtime"},
        )
        self.artifact_store.upsert(artifact)
        self._artifact_by_capability[capability_id] = artifact_id

        try:
            self.runner.inspector.inspect(artifact.source, artifact.entrypoint)
        except CandidatePolicyViolation as exc:
            self.artifact_store.upsert(artifact.rejected(f"inspection failed: {exc}"))
            raise CandidateConstructionError(
                f"candidate inspection failed: {exc}",
                capability_id=capability_id,
                provider_id=provider_id,
                artifact_id=artifact_id,
            ) from exc

        artifact = artifact.with_status(CandidateArtifactStatus.INSPECTED)
        self.artifact_store.upsert(artifact)
        try:
            self.runner.run(artifact, task.payload)
        except (SandboxError, CandidatePolicyViolation) as exc:
            self.artifact_store.upsert(artifact.rejected(f"sandbox failed: {exc}"))
            raise CandidateConstructionError(
                f"candidate sandbox failed: {exc}",
                capability_id=capability_id,
                provider_id=provider_id,
                artifact_id=artifact_id,
            ) from exc

        artifact = artifact.with_status(CandidateArtifactStatus.SANDBOX_TESTED)
        self.artifact_store.upsert(artifact)
        self._artifact_by_capability[capability_id] = artifact.artifact_id

        capability = Capability(
            capability_id=capability_id,
            version="1.0.0",
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
            provider_ids=(provider_id,),
            verifier_id=self.verifier_id,
            trust_state=TrustState.CANDIDATE,
            scope="sandbox-generated",
        )

        def execute(payload: Any, *, _artifact_id: str = artifact.artifact_id) -> Any:
            current = self.artifact_store.get(_artifact_id)
            if not current.active:
                raise RuntimeError(f"generated artifact inactive: {_artifact_id}")
            return self.runner.run(current, payload)

        provider = Provider(
            provider_id,
            capability_id,
            execute,
            kind=ProviderKind.SUBPROCESS,
            boundary=ProviderBoundary.PROCESS,
            endpoint=f"artifact:{artifact.artifact_id}",
        )
        cost = CostRecord(
            provider_id,
            CostVector(
                local_work=spec.provider_local_work,
                offline_work=spec.formation_work,
            ),
        )
        return ConstructedCapability(capability, provider, cost)

    def on_promoted(self, task: TaskContract, capability: Capability) -> None:
        artifact = self._artifact_for(capability.capability_id)
        if artifact is None:
            return
        self.artifact_store.upsert(artifact.promoted(task.task_id))

    def on_rejected(self, task: TaskContract, capability_id: str, reason: str) -> None:
        artifact = self._artifact_for(capability_id)
        if artifact is None or not artifact.active:
            return
        self.artifact_store.upsert(artifact.rejected(reason))

    def on_capability_invalidated(self, capability_id: str, reason: str) -> None:
        artifact = self._artifact_for(capability_id)
        if artifact is None or not artifact.active:
            return
        self.artifact_store.upsert(artifact.revoked(reason))
