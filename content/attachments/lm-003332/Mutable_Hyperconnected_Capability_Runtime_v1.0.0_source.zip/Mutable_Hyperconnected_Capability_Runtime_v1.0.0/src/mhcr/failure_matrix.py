from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from importlib import resources
import json
from pathlib import Path
import tempfile
from typing import Any, Callable

from .accounting import AccountingStatus, CostRecord, CostVector, GCAL
from .acquisition_benchmark import benchmark_acquisition_learning
from .constructor import CandidateConstructionError, GeneratedSourceSpec, SandboxedSourceConstructor, TemplateConstructor, TemplateSpec
from .history import EventLog
from .models import (
    Capability, Provider, ProviderBoundary, ProviderHealth, ProviderKind,
    TaskContract, TaskPolicy, TrustState,
)
from .rdr import RDR
from .registry import CapabilityRegistry
from .routing import ProviderCostCatalog
from .runtime import MHCRRuntime
from .sandbox import CandidateArtifactStatus, GeneratedArtifactStore, PythonSandboxRunner, SandboxPolicy, load_sandbox_provider_bindings
from .sqlite_repository import SQLiteRepository
from .verification import VerifierRegistry


class FailureCaseStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"


@dataclass(frozen=True, slots=True)
class FailureCaseResult:
    case_id: str
    status: FailureCaseStatus
    summary: str
    evidence: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "status": self.status.value,
            "summary": self.summary,
            "evidence": self.evidence,
        }


@dataclass(frozen=True, slots=True)
class FailureMatrixResult:
    matrix_id: str
    cases: tuple[FailureCaseResult, ...]
    passed_count: int
    failed_count: int
    passed: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "matrix_id": self.matrix_id,
            "passed": self.passed,
            "passed_count": self.passed_count,
            "failed_count": self.failed_count,
            "cases": [case.as_dict() for case in self.cases],
        }


def load_failure_manifest() -> dict[str, Any]:
    path = resources.files("mhcr").joinpath("data", "v1_conformance", "failure_manifest.json")
    return json.loads(path.read_text(encoding="utf-8"))


def _trusted_cap(capability_id: str, family: str, provider_ids: tuple[str, ...], *, verifier_id: str | None = None) -> Capability:
    return Capability(
        capability_id=capability_id,
        version="1.0.0",
        task_family=family,
        input_type="int",
        output_type="int",
        exactness="exact",
        provider_ids=provider_ids,
        verifier_id=verifier_id,
        trust_state=TrustState.TRUSTED,
    )


def _run(case_id: str, function: Callable[[], tuple[bool, str, dict[str, Any]]]) -> FailureCaseResult:
    try:
        ok, summary, evidence = function()
    except Exception as exc:  # evidence runner must report, not crash the matrix
        return FailureCaseResult(
            case_id,
            FailureCaseStatus.FAIL,
            f"unexpected {type(exc).__name__}: {exc}",
            {"exception": type(exc).__name__, "message": str(exc)},
        )
    return FailureCaseResult(case_id, FailureCaseStatus.PASS if ok else FailureCaseStatus.FAIL, summary, evidence)


def _f01() -> tuple[bool, str, dict[str, Any]]:
    registry = CapabilityRegistry()
    capability = _trusted_cap("cap.f01", "f01", ("provider.f01",))
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.f01", capability.capability_id, lambda value: value, health=ProviderHealth.UNAVAILABLE))
    try:
        RDR(registry).materialize(capability)
    except RuntimeError as exc:
        ok = "no eligible provider" in str(exc)
        return ok, "unavailable provider remained non-executable", {"error": str(exc)}
    return False, "unavailable provider unexpectedly materialized", {}


def _f02() -> tuple[bool, str, dict[str, Any]]:
    registry = CapabilityRegistry()
    capability = _trusted_cap("cap.f02", "f02", ("provider.remote", "provider.local"))
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.remote", capability.capability_id, lambda value: value, kind=ProviderKind.REMOTE_API, boundary=ProviderBoundary.NETWORK))
    registry.register_provider(Provider("provider.local", capability.capability_id, lambda value: value))
    ordered = RDR(registry, cost_catalog=ProviderCostCatalog()).eligible_providers(
        capability, TaskPolicy(max_external_cost_usd=0.01)
    )
    ids = tuple(provider.provider_id for provider in ordered)
    return ids == ("provider.local",), "unknown remote price did not satisfy hard monetary ceiling", {"eligible_provider_ids": ids}


def _f03(root: Path) -> tuple[bool, str, dict[str, Any]]:
    history = EventLog(root / "events.jsonl")
    registry = CapabilityRegistry(event_log=history)
    capability = _trusted_cap("cap.f03", "f03", ("provider.remote.bad", "provider.local.good"), verifier_id="verify.f03")
    registry.register_capability(capability)

    def fail(_value: int) -> int:
        raise RuntimeError("remote failed")

    registry.register_provider(Provider("provider.remote.bad", capability.capability_id, fail, kind=ProviderKind.REMOTE_API, boundary=ProviderBoundary.NETWORK))
    registry.register_provider(Provider("provider.local.good", capability.capability_id, lambda value: value * 2))
    verifiers = VerifierRegistry()
    verifiers.register("verify.f03", lambda task, result: result == task.payload * 2)
    gcal = GCAL()
    gcal.register_cost(CostRecord("provider.local.good", CostVector(local_work=1.0), known=True))
    result = MHCRRuntime(registry, verifiers, gcal, history).solve(TaskContract("task.f03", "f03", "int", "int", 5))
    ok = (
        result.accounting.status is AccountingStatus.ACCOUNTING_INCOMPLETE
        and "provider.remote.bad" in result.accounting.closure
        and "provider.remote.bad" in result.accounting.unknown_nodes
        and registry.get_provider("provider.remote.bad").health is ProviderHealth.UNAVAILABLE
    )
    return ok, "failed external attempt remained inside closed-responsibility evidence", {
        "accounting": result.accounting.status.value,
        "closure": sorted(result.accounting.closure),
        "unknown_nodes": sorted(result.accounting.unknown_nodes),
    }


def _f04(root: Path) -> tuple[bool, str, dict[str, Any]]:
    log = EventLog(root / "events.jsonl")
    registry = CapabilityRegistry(event_log=log)
    primitive = Capability("cap.f04.base", "1.0.0", "base", "raw", "mid", "exact", ("provider.base",), trust_state=TrustState.TRUSTED)
    first = Capability("cap.f04.first", "1.0.0", "first", "raw", "stage", "exact", (), trust_state=TrustState.TRUSTED, scope="composite", component_capability_ids=(primitive.capability_id,))
    second = Capability("cap.f04.second", "1.0.0", "second", "raw", "final", "exact", (), trust_state=TrustState.TRUSTED, scope="composite", component_capability_ids=(first.capability_id,))
    for capability in (primitive, first, second):
        registry.register_capability(capability)
    registry.revoke(primitive.capability_id)
    replayed = log.replay_registry()
    states = {
        "primitive": registry.get_capability(primitive.capability_id).trust_state.value,
        "first": registry.get_capability(first.capability_id).trust_state.value,
        "second": registry.get_capability(second.capability_id).trust_state.value,
        "replay_second": replayed.get_capability(second.capability_id).trust_state.value,
    }
    ok = states == {"primitive": "revoked", "first": "deprecated", "second": "deprecated", "replay_second": "deprecated"}
    return ok, "component revocation invalidated direct and transitive composites", states


def _f05(root: Path) -> tuple[bool, str, dict[str, Any]]:
    constructor = TemplateConstructor([
        TemplateSpec("square", "number", "number", lambda value: value * value + 1, "verify.square")
    ])
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(CapabilityRegistry(), verifiers, GCAL(), EventLog(root / "events.jsonl"), constructor=constructor)
    first_error = second_error = None
    try:
        runtime.solve(TaskContract("task.f05.1", "square", "number", "number", 4))
    except Exception as exc:
        first_error = type(exc).__name__
    try:
        runtime.solve(TaskContract("task.f05.2", "square", "number", "number", 9))
    except Exception as exc:
        second_error = type(exc).__name__
    ok = constructor.construct_count == 1 and first_error == "RuntimeError" and second_error == "LookupError"
    return ok, "known failed deterministic constructor path was not retried", {"construct_count": constructor.construct_count, "first_error": first_error, "second_error": second_error}


def _f06() -> tuple[bool, str, dict[str, Any]]:
    result = benchmark_acquisition_learning((2, 3, 5, 7))
    ok = result.all_cache_hits_false and result.persistent_constructor_invocations == 1 and result.stateless_constructor_invocations == 4
    return ok, "persistent solver reuse stayed distinct from answer caching", {"all_cache_hits_false": result.all_cache_hits_false, "persistent_constructor_invocations": result.persistent_constructor_invocations, "stateless_constructor_invocations": result.stateless_constructor_invocations}


def _sandbox_runtime(root: Path, source: str, *, timeout: float = 2.0, persistent: bool = False):
    repo = SQLiteRepository(root / "mhcr.sqlite3") if persistent else None
    history = EventLog(root / "events.jsonl")
    store = GeneratedArtifactStore(repository=repo, event_log=history)
    runner = PythonSandboxRunner(policy=SandboxPolicy(timeout_seconds=timeout, cpu_seconds=1))
    constructor = SandboxedSourceConstructor(lambda _task: GeneratedSourceSpec(source), artifact_store=store, runner=runner, verifier_id="verify.square")
    registry = CapabilityRegistry(repository=repo, event_log=history)
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(registry, verifiers, GCAL(repo), history, constructor=constructor)
    return runtime, registry, store, runner, repo


def _f07(root: Path) -> tuple[bool, str, dict[str, Any]]:
    marker = root / "forbidden.txt"
    runtime, _registry, store, _runner, _repo = _sandbox_runtime(
        root,
        f"def solve(payload):\n    open({str(marker)!r}, 'w').write('bad')\n    return payload\n",
    )
    error = None
    try:
        runtime.solve(TaskContract("task.f07", "square", "number", "number", 4))
    except CandidateConstructionError as exc:
        error = str(exc)
    artifact = store.records()[0]
    ok = error is not None and not marker.exists() and artifact.status is CandidateArtifactStatus.REJECTED
    return ok, "forbidden generated file I/O was rejected before execution", {"marker_exists": marker.exists(), "artifact_status": artifact.status.value, "error": error}


def _f08(root: Path) -> tuple[bool, str, dict[str, Any]]:
    runtime, registry, store, _runner, _repo = _sandbox_runtime(root, "def solve(payload):\n    while True:\n        pass\n", timeout=0.1)
    error = None
    try:
        runtime.solve(TaskContract("task.f08", "square", "number", "number", 4))
    except CandidateConstructionError as exc:
        error = str(exc)
    try:
        registry.get_capability("cap.generated.square")
    except KeyError:
        trusted_exists = False
    else:
        trusted_exists = True
    artifact = store.records()[0]
    ok = error is not None and not trusted_exists and artifact.status is CandidateArtifactStatus.REJECTED
    return ok, "sandbox timeout rejected candidate without creating trust", {"trusted_capability_exists": trusted_exists, "artifact_status": artifact.status.value, "error": error}


def _f09(root: Path) -> tuple[bool, str, dict[str, Any]]:
    runtime, registry, store, runner, repo = _sandbox_runtime(root, "def solve(payload):\n    return payload * payload\n", persistent=True)
    assert repo is not None
    solved = runtime.solve(TaskContract("task.f09", "square", "number", "number", 5))
    registry.revoke("cap.generated.square")
    bindings = load_sandbox_provider_bindings(repo, runner)
    artifact = store.records()[0]
    evidence = {"value": solved.value, "artifact_status": artifact.status.value, "rebind_count_after_revoke": len(bindings)}
    repo.close()
    ok = solved.value == 25 and artifact.status is CandidateArtifactStatus.REVOKED and not bindings
    return ok, "revoked generated artifact could not be rebound", evidence


def _f10(root: Path) -> tuple[bool, str, dict[str, Any]]:
    repo = SQLiteRepository(root / "mhcr.sqlite3")
    log = EventLog(root / "events.jsonl")
    registry = CapabilityRegistry(repository=repo, event_log=log)
    capability = _trusted_cap("cap.f10", "f10", ("provider.f10",))
    registry.register_capability(capability)
    registry.register_provider(Provider("provider.f10", capability.capability_id, lambda value: value))
    registry.set_provider_health("provider.f10", ProviderHealth.UNAVAILABLE)
    registry.revoke(capability.capability_id)
    repo.close()

    reopened = SQLiteRepository(root / "mhcr.sqlite3")
    restored = CapabilityRegistry.from_repository(reopened, provider_executors={"provider.f10": lambda value: value})
    replayed = log.replay_registry(provider_executors={"provider.f10": lambda value: value})
    evidence = {
        "restored_capability": restored.get_capability(capability.capability_id).trust_state.value,
        "restored_provider": restored.get_provider("provider.f10").health.value,
        "replay_capability": replayed.get_capability(capability.capability_id).trust_state.value,
        "replay_provider": replayed.get_provider("provider.f10").health.value,
    }
    reopened.close()
    ok = evidence == {
        "restored_capability": "revoked",
        "restored_provider": "unavailable",
        "replay_capability": "revoked",
        "replay_provider": "unavailable",
    }
    return ok, "restart and replay preserved revocation and provider health truth", evidence


def run_failure_matrix() -> FailureMatrixResult:
    with tempfile.TemporaryDirectory(prefix="mhcr-v1-failure-") as directory:
        root = Path(directory)
        cases = (
            _run("F01", _f01),
            _run("F02", _f02),
            _run("F03", lambda: _f03(root / "f03")),
            _run("F04", lambda: _f04(root / "f04")),
            _run("F05", lambda: _f05(root / "f05")),
            _run("F06", _f06),
            _run("F07", lambda: _f07(root / "f07")),
            _run("F08", lambda: _f08(root / "f08")),
            _run("F09", lambda: _f09(root / "f09")),
            _run("F10", lambda: _f10(root / "f10")),
        )
    passed_count = sum(case.status is FailureCaseStatus.PASS for case in cases)
    failed_count = len(cases) - passed_count
    return FailureMatrixResult("MHCR-FAILURE-R1", cases, passed_count, failed_count, failed_count == 0)
