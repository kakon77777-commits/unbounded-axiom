from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tempfile

from .accounting import GCAL
from .acquisition import AcquisitionMemoryKind
from .constructor import TemplateConstructor, TemplateSpec
from .history import EventLog
from .models import TaskContract
from .registry import CapabilityRegistry
from .runtime import MHCRRuntime
from .verification import VerifierRegistry


@dataclass(frozen=True, slots=True)
class AcquisitionSample:
    payload: int
    source: str
    execution_path: str
    acquisition_work: float
    cache_hit: bool
    memory_hits: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class AcquisitionBenchmarkResult:
    payloads: tuple[int, ...]
    stateless_samples: tuple[AcquisitionSample, ...]
    persistent_samples: tuple[AcquisitionSample, ...]
    stateless_total_work: float
    persistent_total_work: float
    stateless_post_first_mean_work: float
    persistent_post_first_mean_work: float
    work_reduction_ratio: float
    stateless_constructor_invocations: int
    persistent_constructor_invocations: int
    persistent_memory_hits: dict[str, int]
    all_cache_hits_false: bool


def _square(value: int) -> int:
    return value * value


def _build_runtime(event_path: Path) -> tuple[MHCRRuntime, TemplateConstructor]:
    constructor = TemplateConstructor(
        [
            TemplateSpec(
                task_family="square",
                input_type="number",
                output_type="number",
                execute=_square,
                verifier_id="verify.square",
            )
        ]
    )
    verifiers = VerifierRegistry()
    verifiers.register("verify.square", lambda task, result: result == task.payload * task.payload)
    runtime = MHCRRuntime(
        CapabilityRegistry(),
        verifiers,
        GCAL(),
        EventLog(event_path),
        constructor=constructor,
    )
    return runtime, constructor


def _sample(payload: int, solved) -> AcquisitionSample:
    trace = solved.acquisition_trace
    if trace is None:
        raise RuntimeError("acquisition trace missing")
    return AcquisitionSample(
        payload=payload,
        source=solved.source,
        execution_path=solved.execution_path,
        acquisition_work=trace.acquisition_work,
        cache_hit=solved.cache_hit,
        memory_hits=tuple(kind.value for kind in trace.memory_hits),
    )


def _post_first_mean(samples: tuple[AcquisitionSample, ...]) -> float:
    tail = samples[1:]
    if not tail:
        return 0.0
    return sum(item.acquisition_work for item in tail) / len(tail)


def benchmark_acquisition_learning(
    payloads: tuple[int, ...] = (2, 3, 5, 7),
) -> AcquisitionBenchmarkResult:
    if not payloads:
        raise ValueError("payloads must not be empty")
    if len(set(payloads)) != len(payloads):
        raise ValueError("benchmark payloads must be unseen/distinct")

    with tempfile.TemporaryDirectory(prefix="mhcr-acquisition-benchmark-") as directory:
        root = Path(directory)

        stateless_samples: list[AcquisitionSample] = []
        stateless_constructor_invocations = 0
        for index, payload in enumerate(payloads):
            runtime, constructor = _build_runtime(root / f"stateless-{index}.jsonl")
            solved = runtime.solve(
                TaskContract(f"stateless-{index}", "square", "number", "number", payload)
            )
            stateless_samples.append(_sample(payload, solved))
            stateless_constructor_invocations += constructor.construct_count

        persistent_runtime, persistent_constructor = _build_runtime(root / "persistent.jsonl")
        persistent_samples: list[AcquisitionSample] = []
        for index, payload in enumerate(payloads):
            solved = persistent_runtime.solve(
                TaskContract(f"persistent-{index}", "square", "number", "number", payload)
            )
            persistent_samples.append(_sample(payload, solved))

        stateless_tuple = tuple(stateless_samples)
        persistent_tuple = tuple(persistent_samples)
        stateless_total = sum(item.acquisition_work for item in stateless_tuple)
        persistent_total = sum(item.acquisition_work for item in persistent_tuple)
        memory_hits = {kind.value: 0 for kind in AcquisitionMemoryKind}
        for sample in persistent_tuple:
            for kind in sample.memory_hits:
                memory_hits[kind] = memory_hits.get(kind, 0) + 1

        return AcquisitionBenchmarkResult(
            payloads=payloads,
            stateless_samples=stateless_tuple,
            persistent_samples=persistent_tuple,
            stateless_total_work=stateless_total,
            persistent_total_work=persistent_total,
            stateless_post_first_mean_work=_post_first_mean(stateless_tuple),
            persistent_post_first_mean_work=_post_first_mean(persistent_tuple),
            work_reduction_ratio=(
                stateless_total / persistent_total if persistent_total > 0 else float("inf")
            ),
            stateless_constructor_invocations=stateless_constructor_invocations,
            persistent_constructor_invocations=persistent_constructor.construct_count,
            persistent_memory_hits=memory_hits,
            all_cache_hits_false=all(
                not item.cache_hit for item in stateless_tuple + persistent_tuple
            ),
        )
