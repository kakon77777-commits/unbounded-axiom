from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, TYPE_CHECKING

from .accounting import CostRecord
from .acquisition import AcquisitionMemoryRecord
from .models import Capability, ProviderBoundary, ProviderHealth, ProviderKind
from .routing import ProviderCostProfile
from .sandbox import GeneratedCandidateArtifact

if TYPE_CHECKING:
    from .gcm_integration import GCMProviderBinding
    from .substrate import SubstrateProfile


@dataclass(frozen=True, slots=True)
class ProviderRecord:
    provider_id: str
    capability_id: str
    active: bool = True
    kind: ProviderKind = ProviderKind.LOCAL_PYTHON
    health: ProviderHealth = ProviderHealth.HEALTHY
    boundary: ProviderBoundary = ProviderBoundary.LOCAL
    endpoint: str | None = None


class RegistryRepository(Protocol):
    def save_capability(self, capability: Capability) -> None: ...

    def save_provider(self, provider: ProviderRecord) -> None: ...

    def load_capabilities(self) -> tuple[Capability, ...]: ...

    def load_provider_records(self) -> tuple[ProviderRecord, ...]: ...

    def save_cost(self, record: CostRecord) -> None: ...

    def load_costs(self) -> tuple[CostRecord, ...]: ...

    def save_provider_cost_profile(self, profile: ProviderCostProfile) -> None: ...

    def load_provider_cost_profiles(self) -> tuple[ProviderCostProfile, ...]: ...

    def save_acquisition_memory(self, record: AcquisitionMemoryRecord) -> None: ...

    def load_acquisition_memories(self) -> tuple[AcquisitionMemoryRecord, ...]: ...

    def save_generated_artifact(self, artifact: GeneratedCandidateArtifact) -> None: ...

    def load_generated_artifacts(self) -> tuple[GeneratedCandidateArtifact, ...]: ...

    def save_gcm_resource_binding(self, binding: "GCMProviderBinding") -> None: ...

    def load_gcm_resource_bindings(self) -> tuple["GCMProviderBinding", ...]: ...

    def delete_gcm_resource_binding(self, binding_id: str) -> None: ...

    def save_substrate_profile(self, profile: "SubstrateProfile") -> None: ...

    def load_substrate_profiles(self) -> tuple["SubstrateProfile", ...]: ...

    def delete_substrate_profile(self, profile_id: str) -> None: ...
