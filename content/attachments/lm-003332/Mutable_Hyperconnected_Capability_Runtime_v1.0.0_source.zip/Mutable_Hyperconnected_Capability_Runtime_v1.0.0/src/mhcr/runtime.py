from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable
from typing import Any
import hashlib

from .accounting import AccountingReport, CostRecord, CostVector, Dependency, GCAL
from .acquisition import AcquisitionMemoryKind, AcquisitionMemoryRecord, AcquisitionMemoryStore, AcquisitionTrace
from .constructor import CandidateConstructionError, TemplateConstructor
from .history import Event, EventLog
from .gcm_integration import GCMAllocationDecision
from .models import Capability, TaskContract, TrustState
from .rdr import RDR
from .routing import ProviderCostCatalog
from .sandbox import GeneratedArtifactStore
from .registry import CapabilityRegistry
from .resolver import Resolver
from .verification import VerificationResult, VerifierRegistry


@dataclass(frozen=True, slots=True)
class SolveResult:
    value: Any
    source: str
    capability_ids: tuple[str, ...]
    verification: VerificationResult
    accounting: AccountingReport
    acquisition_events: int
    cache_hit: bool = False
    execution_path: str = "full"
    provider_ids: tuple[str, ...] = ()
    acquisition_trace: AcquisitionTrace | None = None
    compute_allocations: tuple[GCMAllocationDecision, ...] = ()


class MHCRRuntime:
    def __init__(
        self,
        registry: CapabilityRegistry,
        verifiers: VerifierRegistry,
        gcal: GCAL,
        history: EventLog,
        *,
        constructor: Any | None = None,
        cost_catalog: ProviderCostCatalog | None = None,
        acquisition_memory: AcquisitionMemoryStore | None = None,
        generated_artifacts: GeneratedArtifactStore | None = None,
        compute_allocator: Any | None = None,
        clock: Callable[[], float] | None = None,
    ) -> None:
        self.registry = registry
        self.verifiers = verifiers
        self.gcal = gcal
        self.history = history
        self.constructor = constructor
        self.cost_catalog = cost_catalog or ProviderCostCatalog()
        self.acquisition_memory = acquisition_memory or AcquisitionMemoryStore(
            repository=registry.repository, event_log=history
        )
        self.compute_allocator = compute_allocator
        self.generated_artifacts = (
            generated_artifacts
            or getattr(constructor, "artifact_store", None)
            or GeneratedArtifactStore(repository=registry.repository, event_log=history)
        )
        self._active_memory_hits: list[AcquisitionMemoryKind] = []
        self.registry.add_invalidation_listener(self._on_capability_invalidated)
        self._reconcile_acquisition_memory()
        self.rdr = RDR(
            registry, event_log=history, cost_catalog=self.cost_catalog, clock=clock
        )
        self.resolver = Resolver(registry, rdr=self.rdr)

    @staticmethod
    def _memory_id(
        kind: AcquisitionMemoryKind,
        task: TaskContract,
        subject_id: str,
    ) -> str:
        raw = "|".join(
            (kind.value, task.family, task.input_type, task.output_type, task.exactness, subject_id)
        )
        return "mem." + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]

    def _remember(
        self,
        kind: AcquisitionMemoryKind,
        task: TaskContract,
        subject_id: str,
        *,
        metadata: dict[str, Any] | None = None,
        source: str = "runtime",
    ) -> AcquisitionMemoryRecord:
        memory_id = self._memory_id(kind, task, subject_id)
        try:
            existing = self.acquisition_memory.get(memory_id)
        except KeyError:
            existing = None
        if existing is not None and existing.active:
            return existing
        record = AcquisitionMemoryRecord(
            memory_id=memory_id,
            kind=kind,
            task_family=task.family,
            input_type=task.input_type,
            output_type=task.output_type,
            exactness=task.exactness,
            subject_id=subject_id,
            metadata=dict(metadata or {}),
            source=source,
        )
        return self.acquisition_memory.upsert(record)

    def _reuse_memory(self, record: AcquisitionMemoryRecord) -> AcquisitionMemoryRecord:
        reused = self.acquisition_memory.mark_reused(record.memory_id)
        self._active_memory_hits.append(record.kind)
        return reused

    def _on_capability_invalidated(self, capability_id: str, reason: str) -> None:
        self.acquisition_memory.invalidate_by_subject(capability_id, reason)
        self.generated_artifacts.invalidate_by_capability(capability_id, reason)
        hook = getattr(self.constructor, "on_capability_invalidated", None)
        if callable(hook):
            hook(capability_id, reason)

    def _reconcile_acquisition_memory(self) -> None:
        for record in self.acquisition_memory.records():
            if not record.active or record.kind not in {
                AcquisitionMemoryKind.SOLVER,
                AcquisitionMemoryKind.COMPOSITION,
                AcquisitionMemoryKind.VERIFICATION,
            }:
                continue
            try:
                capability = self.registry.get_capability(record.subject_id)
            except KeyError:
                continue
            if capability.trust_state is not TrustState.TRUSTED:
                self.acquisition_memory.invalidate_by_subject(
                    record.subject_id, f"capability not trusted: {capability.trust_state.value}"
                )

    def _remember_solver_evidence(
        self, task: TaskContract, capability: Capability, *, reuse_existing: bool
    ) -> None:
        entries = [
            (
                AcquisitionMemoryKind.SOLVER,
                {
                    "capability_version": capability.version,
                    "is_composite": capability.is_composite,
                },
                "solver",
            )
        ]
        if capability.is_composite:
            entries.append(
                (
                    AcquisitionMemoryKind.COMPOSITION,
                    {
                        "component_capability_ids": list(capability.component_capability_ids),
                    },
                    "composition",
                )
            )
        if capability.verifier_id is not None:
            entries.append(
                (
                    AcquisitionMemoryKind.VERIFICATION,
                    {"verifier_id": capability.verifier_id},
                    "verification",
                )
            )

        for kind, metadata, source in entries:
            memory_id = self._memory_id(kind, task, capability.capability_id)
            try:
                existing = self.acquisition_memory.get(memory_id)
            except KeyError:
                existing = None
            if existing is not None and existing.active:
                if reuse_existing:
                    self._reuse_memory(existing)
                continue
            self._remember(
                kind, task, capability.capability_id, metadata=metadata, source=source
            )

    def _reuse_representation_for(self, task: TaskContract, capability: Capability) -> None:
        if not capability.is_composite:
            return
        for record in self.acquisition_memory.find(AcquisitionMemoryKind.REPRESENTATION, task):
            if record.metadata.get("composite_id") == capability.capability_id:
                self._reuse_memory(record)
                return

    def _execute_capabilities(
        self,
        capabilities: tuple[Capability, ...],
        payload: Any,
        *,
        task: TaskContract,
    ) -> tuple[Any, tuple[str, ...], tuple[GCMAllocationDecision, ...]]:
        value = payload
        provider_ids: list[str] = []
        allocations: list[GCMAllocationDecision] = []
        for capability in capabilities:
            allowed_provider_ids: tuple[str, ...] | None = None
            if self.compute_allocator is not None:
                routing = self.rdr.routing_decision(capability, task.policy)
                ordered_provider_ids = tuple(provider.provider_id for provider in routing.providers)
                allocation = self.compute_allocator.allocate(
                    task, capability, ordered_provider_ids
                )
                if allocation.provider_id not in ordered_provider_ids:
                    raise RuntimeError(
                        f"compute allocator selected ineligible provider: {allocation.provider_id}"
                    )
                allowed_provider_ids = (allocation.provider_id,)
                allocations.append(allocation)
                self.history.append(
                    Event(
                        "COMPUTE_ALLOCATION_APPLIED",
                        {
                            "task_id": task.task_id,
                            "capability_id": capability.capability_id,
                            "decision_id": allocation.decision_id,
                            "provider_id": allocation.provider_id,
                            "resource_id": allocation.resource_id,
                            "configuration_id": allocation.configuration_id,
                            "substrate_profile_id": allocation.substrate_profile_id,
                            "substrate_kind": allocation.substrate_kind,
                            "substrate_realization": allocation.substrate_realization,
                            "substrate_selection_id": allocation.substrate_selection_id,
                            "substrate_fallback_used": allocation.substrate_fallback_used,
                        },
                    )
                )
            outcome = self.rdr.execute_capability(
                capability,
                value,
                task_id=task.task_id,
                policy=task.policy,
                allowed_provider_ids=allowed_provider_ids,
            )
            provider_ids.extend(outcome.failed_provider_ids)
            provider_ids.append(outcome.provider.provider_id)
            value = outcome.value
        return value, tuple(provider_ids), tuple(allocations)

    def _account(self, task: TaskContract, provider_ids: tuple[str, ...]) -> AccountingReport:
        root = f"task:{task.task_id}"
        self.gcal.register_cost(CostRecord(root, CostVector(local_work=1.0)), persist=False)
        for provider_id in provider_ids:
            self.gcal.register_dependency(Dependency(root, provider_id, required=True))
        return self.gcal.account(root)

    def _verify(self, task: TaskContract, capability: Capability, value: Any) -> VerificationResult:
        verification = self.verifiers.verify(capability.verifier_id, task, value)
        if not verification.passed:
            self.history.append(
                Event(
                    "SOLVER_FAILED",
                    {
                        "task_id": task.task_id,
                        "capability_id": capability.capability_id,
                        "details": verification.details,
                    },
                )
            )
            raise RuntimeError(f"verification failed: {verification.details}")
        return verification

    def _record_completion(
        self,
        task: TaskContract,
        *,
        source: str,
        execution_path: str,
        capabilities: tuple[Capability, ...],
        accounting: AccountingReport,
    ) -> None:
        self.history.append(
            Event(
                "TASK_COMPLETED",
                {
                    "task_id": task.task_id,
                    "source": source,
                    "execution_path": execution_path,
                    "capability_ids": [capability.capability_id for capability in capabilities],
                    "accounting_status": accounting.status.value,
                },
            )
        )

    def _expanded_components(self, capability: Capability) -> tuple[Capability, ...]:
        if not capability.is_composite:
            return (capability,)
        expanded: list[Capability] = []
        for component_id in capability.component_capability_ids:
            component = self.registry.get_capability(component_id)
            expanded.extend(self._expanded_components(component))
        return tuple(expanded)

    def _capability_executable(self, capability: Capability, task: TaskContract) -> bool:
        try:
            components = self._expanded_components(capability)
        except KeyError:
            return False
        for component in components:
            if component.trust_state is not TrustState.TRUSTED:
                return False
            if not self.rdr.has_eligible_provider(component, task.policy):
                return False
        return True

    def _solve_fast(self, task: TaskContract, capability: Capability) -> SolveResult:
        execution_capabilities = self._expanded_components(capability)
        value, provider_ids, compute_allocations = self._execute_capabilities(
            execution_capabilities, task.payload, task=task
        )
        verification = self._verify(task, capability, value)
        self._remember_solver_evidence(task, capability, reuse_existing=True)
        self._reuse_representation_for(task, capability)
        accounting = self._account(task, provider_ids)
        capabilities = (capability,)
        self._record_completion(
            task,
            source="resolved",
            execution_path="fast",
            capabilities=capabilities,
            accounting=accounting,
        )
        return SolveResult(
            value=value,
            source="resolved",
            capability_ids=(capability.capability_id,),
            verification=verification,
            accounting=accounting,
            acquisition_events=0,
            cache_hit=False,
            execution_path="fast",
            provider_ids=provider_ids,
            compute_allocations=compute_allocations,
        )

    def _solve_full(self, task: TaskContract) -> SolveResult:
        plan = self.resolver.plan(task)
        source = "composed"
        acquisition_events = 0
        newly_constructed = False

        if plan is not None:
            capabilities = plan.capabilities
            self.history.append(
                Event(
                    "COMPOSITION_PLAN_SELECTED",
                    {
                        "task_id": task.task_id,
                        "capability_ids": list(plan.capability_ids),
                        "provider_ids": list(plan.provider_ids),
                        "score": plan.score,
                        "graph_expansions": plan.graph_expansions,
                    },
                )
            )
        else:
            if self.constructor is None:
                self.history.append(Event("NO_SOLVER_FOUND", {"task_id": task.task_id, "family": task.family}))
                raise LookupError(f"no solver found for task family: {task.family}")
            candidate_identity = getattr(self.constructor, "candidate_identity", None)
            if callable(candidate_identity):
                candidate_capability_id, _candidate_provider_id = candidate_identity(task)
                prior_failures = self.acquisition_memory.find(
                    AcquisitionMemoryKind.FAILURE, task, subject_id=candidate_capability_id
                )
                if prior_failures:
                    self._reuse_memory(prior_failures[0])
                    raise LookupError(
                        f"known failed acquisition path: {candidate_capability_id}"
                    )
            try:
                bundle = self.constructor.construct(task)
            except CandidateConstructionError as exc:
                self._remember(
                    AcquisitionMemoryKind.FAILURE,
                    task,
                    exc.capability_id,
                    metadata={
                        "reason": "construction_rejected",
                        "details": str(exc),
                        "source_task_id": task.task_id,
                    },
                    source="constructor",
                )
                self.history.append(
                    Event(
                        "GENERATED_CANDIDATE_REJECTED",
                        {
                            "task_id": task.task_id,
                            "capability_id": exc.capability_id,
                            "artifact_id": exc.artifact_id,
                            "reason": str(exc),
                        },
                    )
                )
                raise
            self.registry.register_capability(bundle.capability)
            self.registry.register_provider(bundle.provider)
            self.gcal.register_cost(bundle.cost_record)
            capabilities = (bundle.capability,)
            source = "constructed"
            acquisition_events = 1
            newly_constructed = True
            self.history.append(
                Event(
                    "CAPABILITY_CANDIDATE_CREATED",
                    {"task_id": task.task_id, "capability_id": bundle.capability.capability_id},
                )
            )

        try:
            value, provider_ids, compute_allocations = self._execute_capabilities(
                capabilities, task.payload, task=task
            )
        except Exception as exc:
            if newly_constructed:
                self._remember(
                    AcquisitionMemoryKind.FAILURE,
                    task,
                    capabilities[-1].capability_id,
                    metadata={
                        "reason": "execution_failed",
                        "details": f"{type(exc).__name__}: {exc}",
                        "source_task_id": task.task_id,
                    },
                    source="constructor",
                )
                hook = getattr(self.constructor, "on_rejected", None)
                if callable(hook):
                    hook(task, capabilities[-1].capability_id, f"execution failed: {exc}")
            raise
        try:
            verification = self._verify(task, capabilities[-1], value)
        except RuntimeError:
            if newly_constructed:
                self._remember(
                    AcquisitionMemoryKind.FAILURE,
                    task,
                    capabilities[-1].capability_id,
                    metadata={
                        "reason": "verification_failed",
                        "source_task_id": task.task_id,
                    },
                    source="constructor",
                )
                hook = getattr(self.constructor, "on_rejected", None)
                if callable(hook):
                    hook(
                        task,
                        capabilities[-1].capability_id,
                        f"verification failed: {verification.details if 'verification' in locals() else 'failed'}",
                    )
            raise

        if newly_constructed:
            promoted = self.registry.promote(capabilities[-1].capability_id, verification)
            hook = getattr(self.constructor, "on_promoted", None)
            if callable(hook):
                hook(task, promoted)
            capabilities = (promoted,)
            self.history.append(
                Event(
                    "CAPABILITY_PROMOTED",
                    {"task_id": task.task_id, "capability_id": promoted.capability_id},
                )
            )
            self._remember_solver_evidence(task, promoted, reuse_existing=False)
        elif plan is not None:
            composite = self.resolver.canonicalize_plan(task, plan, verification)
            self.history.append(
                Event(
                    "COMPOSITE_CAPABILITY_PROMOTED",
                    {
                        "task_id": task.task_id,
                        "capability_id": composite.capability_id,
                        "component_capability_ids": list(composite.component_capability_ids),
                    },
                )
            )
            type_path = [task.input_type] + [item.output_type for item in plan.capabilities]
            self._remember(
                AcquisitionMemoryKind.REPRESENTATION,
                task,
                "types:" + "->".join(type_path),
                metadata={
                    "type_path": type_path,
                    "composite_id": composite.capability_id,
                    "component_capability_ids": list(composite.component_capability_ids),
                },
                source="composition",
            )
            self._remember_solver_evidence(task, composite, reuse_existing=False)

        accounting = self._account(task, provider_ids)
        self._record_completion(
            task,
            source=source,
            execution_path="full",
            capabilities=capabilities,
            accounting=accounting,
        )
        return SolveResult(
            value=value,
            source=source,
            capability_ids=tuple(capability.capability_id for capability in capabilities),
            verification=verification,
            accounting=accounting,
            acquisition_events=acquisition_events,
            cache_hit=False,
            execution_path="full",
            provider_ids=provider_ids,
            compute_allocations=compute_allocations,
        )

    def _acquisition_snapshot(self) -> tuple[int, int, int, int, int]:
        return (
            self.registry.indexed_lookup_count,
            self.resolver.planner.search_invocations,
            self.resolver.planner.graph_expansions_total,
            0 if self.constructor is None else int(getattr(self.constructor, "construct_count", 0)),
            self.verifiers.invocation_count,
        )

    @staticmethod
    def _trace_from_snapshots(
        before: tuple[int, int, int, int, int],
        after: tuple[int, int, int, int, int],
        *,
        source: str,
        memory_hits: tuple[AcquisitionMemoryKind, ...] = (),
    ) -> AcquisitionTrace:
        return AcquisitionTrace(
            resolver_lookups=after[0] - before[0],
            graph_searches=after[1] - before[1],
            graph_expansions=after[2] - before[2],
            constructor_invocations=after[3] - before[3],
            candidate_creations=1 if source == "constructed" else 0,
            verifier_invocations=after[4] - before[4],
            memory_hits=memory_hits,
        )

    def solve(self, task: TaskContract) -> SolveResult:
        self._active_memory_hits = []
        before = self._acquisition_snapshot()
        capability = self.resolver.resolve_one(task)
        if capability is not None and self._capability_executable(capability, task):
            result = self._solve_fast(task, capability)
        else:
            result = self._solve_full(task)
        after = self._acquisition_snapshot()
        return replace(
            result,
            acquisition_trace=self._trace_from_snapshots(
                before, after, source=result.source,
                memory_hits=tuple(self._active_memory_hits),
            ),
        )
