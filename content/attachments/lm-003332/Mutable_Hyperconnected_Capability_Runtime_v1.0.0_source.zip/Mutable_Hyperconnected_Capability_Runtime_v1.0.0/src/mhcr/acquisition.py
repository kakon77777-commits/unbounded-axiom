from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .history import EventLog
    from .models import TaskContract
    from .repository import RegistryRepository


class AcquisitionMemoryKind(str, Enum):
    FAILURE = "failure"
    REPRESENTATION = "representation"
    SOLVER = "solver"
    COMPOSITION = "composition"
    VERIFICATION = "verification"


_FORBIDDEN_INSTANCE_KEYS = {
    "answer",
    "result",
    "output",
    "payload",
    "instance_answer",
    "instance_result",
}


@dataclass(frozen=True, slots=True)
class AcquisitionMemoryRecord:
    memory_id: str
    kind: AcquisitionMemoryKind
    task_family: str
    input_type: str
    output_type: str
    exactness: str
    subject_id: str
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = "runtime"
    reuse_count: int = 0
    active: bool = True
    invalidation_reason: str | None = None

    def __post_init__(self) -> None:
        forbidden = _FORBIDDEN_INSTANCE_KEYS.intersection(self.metadata)
        if forbidden:
            raise ValueError(
                "acquisition memory cannot store instance answer/result payload: "
                + ", ".join(sorted(forbidden))
            )
        if self.reuse_count < 0:
            raise ValueError("reuse_count cannot be negative")

    def matches(self, task: "TaskContract") -> bool:
        return (
            self.task_family == task.family
            and self.input_type == task.input_type
            and self.output_type == task.output_type
            and self.exactness == task.exactness
        )

    def with_reuse(self) -> "AcquisitionMemoryRecord":
        return replace(self, reuse_count=self.reuse_count + 1)

    def invalidated(self, reason: str) -> "AcquisitionMemoryRecord":
        return replace(self, active=False, invalidation_reason=reason)

    def as_event_data(self) -> dict[str, Any]:
        return {
            "memory_id": self.memory_id,
            "kind": self.kind.value,
            "task_family": self.task_family,
            "input_type": self.input_type,
            "output_type": self.output_type,
            "exactness": self.exactness,
            "subject_id": self.subject_id,
            "metadata": self.metadata,
            "source": self.source,
            "reuse_count": self.reuse_count,
            "active": self.active,
            "invalidation_reason": self.invalidation_reason,
        }

    @classmethod
    def from_event_data(cls, data: dict[str, Any]) -> "AcquisitionMemoryRecord":
        return cls(
            memory_id=data["memory_id"],
            kind=AcquisitionMemoryKind(data["kind"]),
            task_family=data["task_family"],
            input_type=data["input_type"],
            output_type=data["output_type"],
            exactness=data["exactness"],
            subject_id=data["subject_id"],
            metadata=dict(data.get("metadata", {})),
            source=data.get("source", "runtime"),
            reuse_count=int(data.get("reuse_count", 0)),
            active=bool(data.get("active", True)),
            invalidation_reason=data.get("invalidation_reason"),
        )


@dataclass(frozen=True, slots=True)
class AcquisitionTrace:
    resolver_lookups: int = 0
    graph_searches: int = 0
    graph_expansions: int = 0
    constructor_invocations: int = 0
    candidate_creations: int = 0
    verifier_invocations: int = 0
    memory_hits: tuple[AcquisitionMemoryKind, ...] = ()

    @property
    def acquisition_work(self) -> float:
        return float(
            self.resolver_lookups
            + self.graph_expansions
            + 5 * self.constructor_invocations
            + self.verifier_invocations
        )

    def memory_hit_count(self, kind: AcquisitionMemoryKind) -> int:
        return sum(1 for item in self.memory_hits if item is kind)


class AcquisitionMemoryStore:
    def __init__(
        self,
        *,
        repository: "RegistryRepository | None" = None,
        event_log: "EventLog | None" = None,
    ) -> None:
        self.repository = repository
        self.event_log = event_log
        self._records: dict[str, AcquisitionMemoryRecord] = {}
        if repository is not None:
            self._records = {
                item.memory_id: item for item in repository.load_acquisition_memories()
            }

    def _persist(self, record: AcquisitionMemoryRecord) -> None:
        if self.repository is not None:
            self.repository.save_acquisition_memory(record)

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self.event_log is None:
            return
        from .history import Event

        self.event_log.append(Event(event_type, data))

    def upsert(self, record: AcquisitionMemoryRecord) -> AcquisitionMemoryRecord:
        self._records[record.memory_id] = record
        self._persist(record)
        self._emit("ACQUISITION_MEMORY_UPSERTED", record.as_event_data())
        return record

    def get(self, memory_id: str) -> AcquisitionMemoryRecord:
        return self._records[memory_id]

    def find(
        self,
        kind: AcquisitionMemoryKind,
        task: "TaskContract",
        *,
        subject_id: str | None = None,
        active_only: bool = True,
    ) -> tuple[AcquisitionMemoryRecord, ...]:
        items = [
            item
            for item in self._records.values()
            if item.kind is kind
            and item.matches(task)
            and (subject_id is None or item.subject_id == subject_id)
            and (item.active or not active_only)
        ]
        return tuple(sorted(items, key=lambda item: item.memory_id))

    def mark_reused(self, memory_id: str) -> AcquisitionMemoryRecord:
        updated = self._records[memory_id].with_reuse()
        self._records[memory_id] = updated
        self._persist(updated)
        self._emit(
            "ACQUISITION_MEMORY_REUSED",
            {"memory_id": memory_id, "reuse_count": updated.reuse_count},
        )
        return updated

    def invalidate_by_subject(self, subject_id: str, reason: str) -> tuple[AcquisitionMemoryRecord, ...]:
        changed: list[AcquisitionMemoryRecord] = []
        for memory_id, item in tuple(self._records.items()):
            if item.subject_id != subject_id or not item.active:
                continue
            updated = item.invalidated(reason)
            self._records[memory_id] = updated
            self._persist(updated)
            self._emit(
                "ACQUISITION_MEMORY_INVALIDATED",
                {
                    "memory_id": memory_id,
                    "subject_id": subject_id,
                    "reason": reason,
                },
            )
            changed.append(updated)
        return tuple(changed)

    def records(self) -> tuple[AcquisitionMemoryRecord, ...]:
        return tuple(sorted(self._records.values(), key=lambda item: item.memory_id))
