from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
import hashlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .history import EventLog
    from .repository import RegistryRepository


class CandidateArtifactStatus(str, Enum):
    PROPOSED = "proposed"
    INSPECTED = "inspected"
    SANDBOX_TESTED = "sandbox_tested"
    PROMOTED = "promoted"
    REJECTED = "rejected"
    REVOKED = "revoked"


@dataclass(frozen=True, slots=True)
class SandboxPolicy:
    policy_id: str = "sandbox.default.v1"
    allow_imports: bool = False
    allow_file_io: bool = False
    allow_network: bool = False
    allow_shell: bool = False
    allow_secret_environment: bool = False
    max_source_bytes: int = 16_384
    max_ast_nodes: int = 400
    timeout_seconds: float = 2.0
    cpu_seconds: int = 2
    memory_bytes: int = 128 * 1024 * 1024

    def __post_init__(self) -> None:
        if self.max_source_bytes < 1 or self.max_ast_nodes < 1:
            raise ValueError("sandbox source/AST limits must be positive")
        if self.timeout_seconds <= 0 or self.cpu_seconds < 1 or self.memory_bytes < 1:
            raise ValueError("sandbox resource limits must be positive")


@dataclass(frozen=True, slots=True)
class GeneratedCandidateArtifact:
    artifact_id: str
    capability_id: str
    provider_id: str
    task_family: str
    input_type: str
    output_type: str
    exactness: str
    source: str
    entrypoint: str
    source_sha256: str
    policy_id: str
    status: CandidateArtifactStatus = CandidateArtifactStatus.PROPOSED
    active: bool = True
    promotion_task_id: str | None = None
    rejection_reason: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        expected = hashlib.sha256(self.source.encode("utf-8")).hexdigest()
        if self.source_sha256 != expected:
            raise ValueError("source_sha256 does not match source")
        if not self.artifact_id or not self.capability_id or not self.provider_id:
            raise ValueError("artifact/capability/provider identity cannot be empty")
        if not self.entrypoint.isidentifier():
            raise ValueError("entrypoint must be a valid identifier")

    @classmethod
    def create(
        cls,
        *,
        artifact_id: str,
        capability_id: str,
        provider_id: str,
        task_family: str,
        input_type: str,
        output_type: str,
        exactness: str,
        source: str,
        entrypoint: str,
        policy_id: str,
        metadata: dict[str, Any] | None = None,
    ) -> "GeneratedCandidateArtifact":
        return cls(
            artifact_id=artifact_id,
            capability_id=capability_id,
            provider_id=provider_id,
            task_family=task_family,
            input_type=input_type,
            output_type=output_type,
            exactness=exactness,
            source=source,
            entrypoint=entrypoint,
            source_sha256=hashlib.sha256(source.encode("utf-8")).hexdigest(),
            policy_id=policy_id,
            metadata=dict(metadata or {}),
        )

    def with_status(self, status: CandidateArtifactStatus) -> "GeneratedCandidateArtifact":
        active = status not in {CandidateArtifactStatus.REJECTED, CandidateArtifactStatus.REVOKED}
        return replace(self, status=status, active=active)

    def promoted(self, task_id: str) -> "GeneratedCandidateArtifact":
        return replace(
            self,
            status=CandidateArtifactStatus.PROMOTED,
            active=True,
            promotion_task_id=task_id,
            rejection_reason=None,
        )

    def rejected(self, reason: str) -> "GeneratedCandidateArtifact":
        return replace(
            self,
            status=CandidateArtifactStatus.REJECTED,
            active=False,
            rejection_reason=reason,
        )

    def revoked(self, reason: str = "revoked") -> "GeneratedCandidateArtifact":
        return replace(
            self,
            status=CandidateArtifactStatus.REVOKED,
            active=False,
            rejection_reason=reason,
        )

    def as_event_data(self) -> dict[str, Any]:
        return {
            "artifact_id": self.artifact_id,
            "capability_id": self.capability_id,
            "provider_id": self.provider_id,
            "task_family": self.task_family,
            "input_type": self.input_type,
            "output_type": self.output_type,
            "exactness": self.exactness,
            "source": self.source,
            "entrypoint": self.entrypoint,
            "source_sha256": self.source_sha256,
            "policy_id": self.policy_id,
            "status": self.status.value,
            "active": self.active,
            "promotion_task_id": self.promotion_task_id,
            "rejection_reason": self.rejection_reason,
            "metadata": self.metadata,
        }

    @classmethod
    def from_event_data(cls, data: dict[str, Any]) -> "GeneratedCandidateArtifact":
        return cls(
            artifact_id=data["artifact_id"],
            capability_id=data["capability_id"],
            provider_id=data["provider_id"],
            task_family=data["task_family"],
            input_type=data["input_type"],
            output_type=data["output_type"],
            exactness=data["exactness"],
            source=data["source"],
            entrypoint=data["entrypoint"],
            source_sha256=data["source_sha256"],
            policy_id=data["policy_id"],
            status=CandidateArtifactStatus(data.get("status", "proposed")),
            active=bool(data.get("active", True)),
            promotion_task_id=data.get("promotion_task_id"),
            rejection_reason=data.get("rejection_reason"),
            metadata=dict(data.get("metadata", {})),
        )


class GeneratedArtifactStore:
    def __init__(
        self,
        *,
        repository: "RegistryRepository | None" = None,
        event_log: "EventLog | None" = None,
    ) -> None:
        self.repository = repository
        self.event_log = event_log
        self._records: dict[str, GeneratedCandidateArtifact] = {}
        if repository is not None:
            self._records = {
                item.artifact_id: item for item in repository.load_generated_artifacts()
            }

    def _emit(self, event_type: str, data: dict[str, Any]) -> None:
        if self.event_log is None:
            return
        from .history import Event
        self.event_log.append(Event(event_type, data))

    def upsert(self, artifact: GeneratedCandidateArtifact) -> GeneratedCandidateArtifact:
        self._records[artifact.artifact_id] = artifact
        if self.repository is not None:
            self.repository.save_generated_artifact(artifact)
        self._emit("GENERATED_ARTIFACT_UPSERTED", artifact.as_event_data())
        return artifact

    def get(self, artifact_id: str) -> GeneratedCandidateArtifact:
        return self._records[artifact_id]

    def find_by_capability(
        self, capability_id: str, *, active_only: bool = True
    ) -> tuple[GeneratedCandidateArtifact, ...]:
        items = [
            item for item in self._records.values()
            if item.capability_id == capability_id and (item.active or not active_only)
        ]
        return tuple(sorted(items, key=lambda item: item.artifact_id))

    def invalidate_by_capability(
        self, capability_id: str, reason: str
    ) -> tuple[GeneratedCandidateArtifact, ...]:
        changed: list[GeneratedCandidateArtifact] = []
        for artifact_id, item in tuple(self._records.items()):
            if item.capability_id != capability_id or not item.active:
                continue
            updated = item.revoked(reason)
            self._records[artifact_id] = updated
            if self.repository is not None:
                self.repository.save_generated_artifact(updated)
            self._emit("GENERATED_ARTIFACT_UPSERTED", updated.as_event_data())
            changed.append(updated)
        return tuple(changed)

    def records(self) -> tuple[GeneratedCandidateArtifact, ...]:
        return tuple(sorted(self._records.values(), key=lambda item: item.artifact_id))

import ast


class CandidatePolicyViolation(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class InspectionReport:
    entrypoint: str
    function_names: tuple[str, ...]
    ast_nodes: int
    source_bytes: int


class _PolicyVisitor(ast.NodeVisitor):
    _FORBIDDEN_NODE_TYPES = (
        ast.Import,
        ast.ImportFrom,
        ast.Global,
        ast.Nonlocal,
        ast.ClassDef,
        ast.AsyncFunctionDef,
        ast.Await,
        ast.Yield,
        ast.YieldFrom,
        ast.Lambda,
        ast.With,
        ast.AsyncWith,
    )
    _FORBIDDEN_NAMES = {
        "open",
        "eval",
        "exec",
        "compile",
        "__import__",
        "globals",
        "locals",
        "vars",
        "dir",
        "getattr",
        "setattr",
        "delattr",
        "input",
        "breakpoint",
        "help",
    }
    _FORBIDDEN_ATTRS = {
        "system",
        "popen",
        "spawn",
        "fork",
        "socket",
        "connect",
        "bind",
        "listen",
        "accept",
        "open",
        "write",
        "writelines",
        "unlink",
        "remove",
        "rmdir",
        "rename",
        "replace",
        "chmod",
        "chown",
        "exec",
        "eval",
    }

    def __init__(self, policy: SandboxPolicy) -> None:
        self.policy = policy

    def generic_visit(self, node: ast.AST) -> None:
        if isinstance(node, self._FORBIDDEN_NODE_TYPES):
            raise CandidatePolicyViolation(f"forbidden AST node: {type(node).__name__}")
        super().generic_visit(node)

    def visit_Name(self, node: ast.Name) -> None:
        if node.id in self._FORBIDDEN_NAMES:
            raise CandidatePolicyViolation(f"forbidden name: {node.id}")
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr.startswith("_"):
            raise CandidatePolicyViolation(f"private attribute access forbidden: {node.attr}")
        if node.attr in self._FORBIDDEN_ATTRS:
            raise CandidatePolicyViolation(f"forbidden attribute: {node.attr}")
        self.generic_visit(node)


class CandidateInspector:
    def __init__(self, policy: SandboxPolicy | None = None) -> None:
        self.policy = policy or SandboxPolicy()

    def inspect(self, source: str, entrypoint: str) -> InspectionReport:
        source_bytes = len(source.encode("utf-8"))
        if source_bytes > self.policy.max_source_bytes:
            raise CandidatePolicyViolation(
                f"source size exceeds sandbox limit: {source_bytes} > {self.policy.max_source_bytes}"
            )
        try:
            tree = ast.parse(source, mode="exec")
        except SyntaxError as exc:
            raise CandidatePolicyViolation(f"syntax error: {exc.msg}") from exc

        nodes = tuple(ast.walk(tree))
        if len(nodes) > self.policy.max_ast_nodes:
            raise CandidatePolicyViolation(
                f"AST node count exceeds sandbox limit: {len(nodes)} > {self.policy.max_ast_nodes}"
            )

        for node in tree.body:
            if not isinstance(node, ast.FunctionDef):
                raise CandidatePolicyViolation(
                    f"top-level executable statement forbidden: {type(node).__name__}"
                )
            if node.decorator_list:
                raise CandidatePolicyViolation("function decorators are forbidden")

        functions = tuple(node for node in tree.body if isinstance(node, ast.FunctionDef))
        entrypoints = [node for node in functions if node.name == entrypoint]
        if len(entrypoints) != 1:
            raise CandidatePolicyViolation(f"entrypoint {entrypoint!r} must be defined exactly once")
        fn = entrypoints[0]
        args = fn.args
        if (
            len(args.posonlyargs) != 0
            or len(args.args) != 1
            or args.vararg is not None
            or args.kwarg is not None
            or args.kwonlyargs
            or args.defaults
            or args.kw_defaults
        ):
            raise CandidatePolicyViolation("entrypoint must accept exactly one plain positional parameter")

        _PolicyVisitor(self.policy).visit(tree)
        return InspectionReport(
            entrypoint=entrypoint,
            function_names=tuple(sorted(node.name for node in functions)),
            ast_nodes=len(nodes),
            source_bytes=source_bytes,
        )

from pathlib import Path
import json
import os
import subprocess
import sys
import tempfile


class SandboxError(RuntimeError):
    pass


class SandboxTimeoutError(SandboxError):
    pass


class SandboxExecutionError(SandboxError):
    pass


class SandboxSerializationError(SandboxError):
    pass


@dataclass(frozen=True, slots=True)
class SandboxRunReport:
    value: Any
    environment_keys: tuple[str, ...]
    cwd: str
    resource_limits_applied: bool
    generated_global_names: tuple[str, ...]
    worker_pid: int


class PythonSandboxRunner:
    def __init__(
        self,
        *,
        policy: SandboxPolicy | None = None,
        inspector: CandidateInspector | None = None,
        python_executable: str | None = None,
    ) -> None:
        self.policy = policy or SandboxPolicy()
        self.inspector = inspector or CandidateInspector(self.policy)
        self.python_executable = python_executable or sys.executable
        self.worker_path = Path(__file__).with_name("sandbox_worker.py")

    def _request_json(self, artifact: GeneratedCandidateArtifact, payload: Any) -> str:
        try:
            return json.dumps(
                {
                    "source": artifact.source,
                    "entrypoint": artifact.entrypoint,
                    "payload": payload,
                },
                ensure_ascii=False,
            )
        except (TypeError, ValueError) as exc:
            raise SandboxSerializationError(f"sandbox payload is not JSON serializable: {exc}") from exc

    def run_detailed(self, artifact: GeneratedCandidateArtifact, payload: Any) -> SandboxRunReport:
        if artifact.policy_id != self.policy.policy_id:
            raise CandidatePolicyViolation(
                f"artifact policy {artifact.policy_id!r} does not match runner policy {self.policy.policy_id!r}"
            )
        self.inspector.inspect(artifact.source, artifact.entrypoint)
        request = self._request_json(artifact, payload)
        env = {
            "PYTHONIOENCODING": "utf-8",
            "PYTHONUTF8": "1",
            "MHCR_SANDBOX_CPU_SECONDS": str(self.policy.cpu_seconds),
            "MHCR_SANDBOX_MEMORY_BYTES": str(self.policy.memory_bytes),
        }
        with tempfile.TemporaryDirectory(prefix="mhcr-sandbox-") as tmpdir:
            try:
                completed = subprocess.run(
                    [self.python_executable, "-I", str(self.worker_path)],
                    input=request,
                    text=True,
                    capture_output=True,
                    cwd=tmpdir,
                    env=env,
                    timeout=self.policy.timeout_seconds,
                    check=False,
                    start_new_session=True,
                )
            except subprocess.TimeoutExpired as exc:
                raise SandboxTimeoutError(
                    f"sandbox execution timed out after {self.policy.timeout_seconds}s"
                ) from exc

            raw = completed.stdout.strip()
            if not raw:
                detail = completed.stderr.strip()
                raise SandboxExecutionError(
                    f"sandbox worker exited {completed.returncode} without result"
                    + (f": {detail}" if detail else "")
                )
            try:
                response = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise SandboxExecutionError("sandbox worker returned invalid JSON") from exc

            if not response.get("ok", False):
                error_class = response.get("error_class", "SandboxError")
                message = response.get("message", "sandbox execution failed")
                if response.get("error_type") == "serialization":
                    raise SandboxSerializationError(f"JSON serialization failure ({error_class}): {message}")
                raise SandboxExecutionError(f"{error_class}: {message}")

            diagnostics = response.get("diagnostics", {})
            return SandboxRunReport(
                value=response.get("value"),
                environment_keys=tuple(diagnostics.get("environment_keys", ())),
                cwd=str(diagnostics.get("cwd", tmpdir)),
                resource_limits_applied=bool(diagnostics.get("resource_limits_applied", False)),
                generated_global_names=tuple(diagnostics.get("generated_global_names", ())),
                worker_pid=int(diagnostics.get("worker_pid", -1)),
            )

    def run(self, artifact: GeneratedCandidateArtifact, payload: Any) -> Any:
        return self.run_detailed(artifact, payload).value


def load_sandbox_provider_bindings(
    repository: "RegistryRepository",
    runner: PythonSandboxRunner,
) -> dict[str, Any]:
    bindings: dict[str, Any] = {}
    trusted_capability_ids = {
        capability.capability_id
        for capability in repository.load_capabilities()
        if capability.trust_state.value == "trusted"
    }
    for artifact in repository.load_generated_artifacts():
        if (
            not artifact.active
            or artifact.status is not CandidateArtifactStatus.PROMOTED
            or artifact.policy_id != runner.policy.policy_id
            or artifact.capability_id not in trusted_capability_ids
        ):
            continue

        def execute(payload: Any, *, _artifact: GeneratedCandidateArtifact = artifact) -> Any:
            return runner.run(_artifact, payload)

        bindings[artifact.provider_id] = execute
    return bindings
