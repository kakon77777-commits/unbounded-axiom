from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any

from .history import Event, EventLog
from .routing import CostEvidence, CostMetric


class SubstrateKind(str, Enum):
    CPU = "cpu"
    GPU = "gpu"
    FPGA = "fpga"
    EVENT_DRIVEN = "event_driven"
    NEUROMORPHIC = "neuromorphic"
    PHASE = "phase"
    QUANTUM = "quantum"
    SPECIAL_ACCELERATOR = "special_accelerator"


class SubstrateRealization(str, Enum):
    NATIVE = "native"
    SIMULATED = "simulated"
    EMULATED = "emulated"
    REMOTE_SERVICE = "remote_service"
    HYBRID = "hybrid"


class TransitionLawClass(str, Enum):
    DETERMINISTIC = "deterministic"
    STOCHASTIC = "stochastic"
    COHERENT = "coherent"


def _text(value: Any, name: str) -> str:
    result = str(value)
    if not result:
        raise ValueError(f"{name} is required")
    return result


def _ordered_unique(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(str(value) for value in values if str(value)))


def _sorted_unique(values: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(sorted(set(str(value) for value in values if str(value))))


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(item) for key, item in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, tuple):
        return tuple(_freeze(item) for item in value)
    if isinstance(value, set):
        return frozenset(_freeze(item) for item in value)
    return value


def _plain(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _plain(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_plain(item) for item in value]
    if isinstance(value, (set, frozenset)):
        return [_plain(item) for item in sorted(value, key=repr)]
    if isinstance(value, Enum):
        return value.value
    return value


def _metric_dict(metric: CostMetric) -> dict[str, Any]:
    return {
        "value": metric.value,
        "evidence": metric.evidence.value,
        "sample_count": metric.sample_count,
    }


def _metric_from_dict(data: Mapping[str, Any] | None) -> CostMetric:
    if not data:
        return CostMetric()
    return CostMetric(
        value=None if data.get("value") is None else float(data["value"]),
        evidence=CostEvidence(str(data.get("evidence", "unknown"))),
        sample_count=int(data.get("sample_count", 0)),
    )


@dataclass(frozen=True, slots=True)
class PCMTProfile:
    phase_ontology: str
    phase_representation: str
    architecture: str
    dynamics: str
    coupling: str
    memory: str
    output: str

    def __post_init__(self) -> None:
        for name in (
            "phase_ontology", "phase_representation", "architecture", "dynamics",
            "coupling", "memory", "output",
        ):
            object.__setattr__(self, name, _text(getattr(self, name), name))

    def as_dict(self) -> dict[str, str]:
        return {
            "phase_ontology": self.phase_ontology,
            "phase_representation": self.phase_representation,
            "architecture": self.architecture,
            "dynamics": self.dynamics,
            "coupling": self.coupling,
            "memory": self.memory,
            "output": self.output,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PCMTProfile":
        return cls(**{name: str(data[name]) for name in cls.__dataclass_fields__})


@dataclass(frozen=True, slots=True)
class ComputationalMorphologyProfile:
    bottom_space: str
    update_organization: str
    observation_mode: str
    transition_law: TransitionLawClass = TransitionLawClass.DETERMINISTIC

    def __post_init__(self) -> None:
        for name in ("bottom_space", "update_organization", "observation_mode"):
            object.__setattr__(self, name, _text(getattr(self, name), name))
        if not isinstance(self.transition_law, TransitionLawClass):
            object.__setattr__(self, "transition_law", TransitionLawClass(str(self.transition_law)))

    def as_dict(self) -> dict[str, str]:
        return {
            "bottom_space": self.bottom_space,
            "update_organization": self.update_organization,
            "observation_mode": self.observation_mode,
            "transition_law": self.transition_law.value,
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "ComputationalMorphologyProfile":
        return cls(
            bottom_space=str(data["bottom_space"]),
            update_organization=str(data["update_organization"]),
            observation_mode=str(data["observation_mode"]),
            transition_law=TransitionLawClass(str(data.get("transition_law", "deterministic"))),
        )


@dataclass(frozen=True, slots=True)
class SubstrateProfile:
    profile_id: str
    kind: SubstrateKind
    realization: SubstrateRealization
    gcm_resource_kind: str = "other"
    features: tuple[str, ...] = ()
    transition_laws: tuple[TransitionLawClass, ...] = (TransitionLawClass.DETERMINISTIC,)
    supports_exact: bool = True
    energy_units: CostMetric = field(default_factory=CostMetric)
    switching_cost_units: CostMetric = field(default_factory=CostMetric)
    pcmt: PCMTProfile | None = None
    morphology: ComputationalMorphologyProfile | None = None
    fallback_profile_ids: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    _GCM_RESOURCE_KINDS = frozenset({"cpu", "gpu", "model", "solver", "search", "remote_api", "other"})

    def __post_init__(self) -> None:
        object.__setattr__(self, "profile_id", _text(self.profile_id, "profile_id"))
        if not isinstance(self.kind, SubstrateKind):
            object.__setattr__(self, "kind", SubstrateKind(str(self.kind)))
        if not isinstance(self.realization, SubstrateRealization):
            object.__setattr__(self, "realization", SubstrateRealization(str(self.realization)))
        resource_kind = _text(self.gcm_resource_kind, "gcm_resource_kind")
        if resource_kind not in self._GCM_RESOURCE_KINDS:
            raise ValueError("gcm_resource_kind must match accepted GCM Phase-B ResourceKind")
        object.__setattr__(self, "gcm_resource_kind", resource_kind)
        object.__setattr__(self, "features", _sorted_unique(self.features))
        laws = tuple(
            item if isinstance(item, TransitionLawClass) else TransitionLawClass(str(item))
            for item in self.transition_laws
        )
        if not laws:
            raise ValueError("transition_laws cannot be empty")
        object.__setattr__(self, "transition_laws", tuple(dict.fromkeys(laws)))
        object.__setattr__(self, "fallback_profile_ids", _ordered_unique(self.fallback_profile_ids))
        object.__setattr__(self, "metadata", _freeze(self.metadata))

    def as_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "kind": self.kind.value,
            "realization": self.realization.value,
            "gcm_resource_kind": self.gcm_resource_kind,
            "features": list(self.features),
            "transition_laws": [item.value for item in self.transition_laws],
            "supports_exact": self.supports_exact,
            "energy_units": _metric_dict(self.energy_units),
            "switching_cost_units": _metric_dict(self.switching_cost_units),
            "pcmt": None if self.pcmt is None else self.pcmt.as_dict(),
            "morphology": None if self.morphology is None else self.morphology.as_dict(),
            "fallback_profile_ids": list(self.fallback_profile_ids),
            "metadata": _plain(self.metadata),
        }

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "SubstrateProfile":
        return cls(
            profile_id=str(data["profile_id"]),
            kind=SubstrateKind(str(data["kind"])),
            realization=SubstrateRealization(str(data["realization"])),
            gcm_resource_kind=str(data.get("gcm_resource_kind", "other")),
            features=tuple(data.get("features", ())),
            transition_laws=tuple(TransitionLawClass(str(item)) for item in data.get("transition_laws", ("deterministic",))),
            supports_exact=bool(data.get("supports_exact", True)),
            energy_units=_metric_from_dict(data.get("energy_units")),
            switching_cost_units=_metric_from_dict(data.get("switching_cost_units")),
            pcmt=None if data.get("pcmt") is None else PCMTProfile.from_dict(data["pcmt"]),
            morphology=None if data.get("morphology") is None else ComputationalMorphologyProfile.from_dict(data["morphology"]),
            fallback_profile_ids=tuple(data.get("fallback_profile_ids", ())),
            metadata=dict(data.get("metadata", {})),
        )


class SubstrateProfileStore:
    def __init__(self, repository: Any | None = None, event_log: EventLog | None = None) -> None:
        self.repository = repository
        self.event_log = event_log
        self._records: dict[str, SubstrateProfile] = {}
        if repository is not None:
            loader = getattr(repository, "load_substrate_profiles", None)
            if callable(loader):
                self._records = {item.profile_id: item for item in loader()}

    def upsert(self, profile: SubstrateProfile) -> SubstrateProfile:
        self._records[profile.profile_id] = profile
        if self.repository is not None:
            saver = getattr(self.repository, "save_substrate_profile", None)
            if callable(saver):
                saver(profile)
        if self.event_log is not None:
            self.event_log.append(Event("SUBSTRATE_PROFILE_UPSERTED", profile.as_dict()))
        return profile

    def remove(self, profile_id: str) -> None:
        if profile_id not in self._records:
            raise KeyError(profile_id)
        del self._records[profile_id]
        if self.repository is not None:
            remover = getattr(self.repository, "delete_substrate_profile", None)
            if callable(remover):
                remover(profile_id)
        if self.event_log is not None:
            self.event_log.append(Event("SUBSTRATE_PROFILE_REMOVED", {"profile_id": profile_id}))

    def get(self, profile_id: str) -> SubstrateProfile:
        return self._records[profile_id]

    def records(self) -> tuple[SubstrateProfile, ...]:
        return tuple(self._records[key] for key in sorted(self._records))


@dataclass(frozen=True, slots=True)
class SubstrateSelectionCertificate:
    selection_id: str
    task_id: str
    capability_id: str
    candidate_binding_ids: tuple[str, ...]
    ordered_binding_ids: tuple[str, ...]
    rejected: tuple[tuple[str, str], ...]
    policy_digest: str
    preferred_profile_ids: tuple[str, ...] = ()
    preferred_kinds: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        return {
            "selection_id": self.selection_id,
            "task_id": self.task_id,
            "capability_id": self.capability_id,
            "candidate_binding_ids": list(self.candidate_binding_ids),
            "ordered_binding_ids": list(self.ordered_binding_ids),
            "rejected": [[binding_id, reason] for binding_id, reason in self.rejected],
            "policy_digest": self.policy_digest,
            "preferred_profile_ids": list(self.preferred_profile_ids),
            "preferred_kinds": list(self.preferred_kinds),
        }


@dataclass(frozen=True, slots=True)
class SubstrateSelection:
    bindings: tuple[Any, ...]
    certificate: SubstrateSelectionCertificate


class SubstrateSelector:
    def __init__(self, catalog: SubstrateProfileStore) -> None:
        self.catalog = catalog

    @staticmethod
    def _policy_dict(policy: Any) -> dict[str, Any]:
        return {
            "allowed_profile_ids": list(policy.allowed_profile_ids),
            "allowed_kinds": list(policy.allowed_kinds),
            "preferred_profile_ids": list(policy.preferred_profile_ids),
            "preferred_kinds": list(policy.preferred_kinds),
            "required_features": list(policy.required_features),
            "required_transition_laws": list(policy.required_transition_laws),
            "require_native": policy.require_native,
            "allow_simulated": policy.allow_simulated,
            "allow_emulated": policy.allow_emulated,
            "allow_remote_service": policy.allow_remote_service,
            "allow_hybrid": policy.allow_hybrid,
            "max_energy_units": policy.max_energy_units,
            "max_switching_cost_units": policy.max_switching_cost_units,
        }

    @classmethod
    def _policy_digest(cls, policy: Any) -> str:
        import hashlib
        import json

        payload = json.dumps(cls._policy_dict(policy), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    @staticmethod
    def _metric_rejection(metric: CostMetric, ceiling: float, label: str) -> str | None:
        if not metric.known:
            return f"{label}_unknown"
        assert metric.value is not None
        if metric.value > ceiling:
            return f"{label}_exceeds_ceiling"
        return None

    @staticmethod
    def _realization_rejection(profile: SubstrateProfile, policy: Any) -> str | None:
        if policy.require_native and profile.realization is not SubstrateRealization.NATIVE:
            return "native_required"
        if profile.realization is SubstrateRealization.SIMULATED and not policy.allow_simulated:
            return "simulated_disallowed"
        if profile.realization is SubstrateRealization.EMULATED and not policy.allow_emulated:
            return "emulated_disallowed"
        if profile.realization is SubstrateRealization.REMOTE_SERVICE and not policy.allow_remote_service:
            return "remote_service_disallowed"
        if profile.realization is SubstrateRealization.HYBRID and not policy.allow_hybrid:
            return "hybrid_disallowed"
        return None

    def _hard_rejection(self, task: Any, profile: SubstrateProfile) -> str | None:
        policy = task.substrate_policy
        if policy.allowed_profile_ids and profile.profile_id not in policy.allowed_profile_ids:
            return "profile_not_allowed"
        if policy.allowed_kinds and profile.kind.value not in policy.allowed_kinds:
            return "substrate_kind_not_allowed"
        reason = self._realization_rejection(profile, policy)
        if reason is not None:
            return reason
        if task.exactness == "exact" and not profile.supports_exact:
            return "exact_not_supported"
        if policy.required_features and not set(policy.required_features).issubset(profile.features):
            return "required_features_missing"
        supported_laws = {item.value for item in profile.transition_laws}
        if policy.required_transition_laws and not set(policy.required_transition_laws).issubset(supported_laws):
            return "required_transition_law_missing"
        if policy.max_energy_units is not None:
            reason = self._metric_rejection(profile.energy_units, float(policy.max_energy_units), "energy")
            if reason is not None:
                return reason
        if policy.max_switching_cost_units is not None:
            reason = self._metric_rejection(
                profile.switching_cost_units,
                float(policy.max_switching_cost_units),
                "switching_cost",
            )
            if reason is not None:
                return reason
        return None

    @staticmethod
    def _preference_key(profile: SubstrateProfile, policy: Any) -> tuple[int, int, int, int]:
        if profile.profile_id in policy.preferred_profile_ids:
            return (0, policy.preferred_profile_ids.index(profile.profile_id), 0, 0)
        kind_index = (
            policy.preferred_kinds.index(profile.kind.value)
            if profile.kind.value in policy.preferred_kinds
            else len(policy.preferred_kinds)
        )
        return (1, kind_index, 0, 0)

    def select(self, task: Any, capability_id: str, bindings: tuple[Any, ...]) -> SubstrateSelection:
        policy = task.substrate_policy
        accepted: list[tuple[int, Any, SubstrateProfile | None]] = []
        rejected: list[tuple[str, str]] = []
        candidate_ids = tuple(str(binding.binding_id) for binding in bindings)

        for index, binding in enumerate(bindings):
            profile_id = getattr(binding, "substrate_profile_id", None)
            if profile_id is None:
                if policy.is_default:
                    accepted.append((index, binding, None))
                else:
                    rejected.append((binding.binding_id, "substrate_profile_missing"))
                continue
            try:
                profile = self.catalog.get(profile_id)
            except KeyError:
                rejected.append((binding.binding_id, "substrate_profile_unknown"))
                continue
            reason = self._hard_rejection(task, profile)
            if reason is not None:
                rejected.append((binding.binding_id, reason))
                continue
            accepted.append((index, binding, profile))

        if not policy.is_default:
            accepted.sort(
                key=lambda item: (
                    (2, 0, 0, 0) if item[2] is None else self._preference_key(item[2], policy),
                    item[0],
                    getattr(item[1], "priority", 0),
                    str(item[1].binding_id),
                )
            )

        ordered = tuple(item[1] for item in accepted)
        policy_digest = self._policy_digest(policy)
        import hashlib
        import json

        semantic = {
            "task_id": task.task_id,
            "capability_id": capability_id,
            "candidate_binding_ids": list(candidate_ids),
            "ordered_binding_ids": [item.binding_id for item in ordered],
            "rejected": [[binding_id, reason] for binding_id, reason in rejected],
            "policy_digest": policy_digest,
        }
        selection_id = "substrate-selection:" + hashlib.sha256(
            json.dumps(semantic, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()[:24]
        certificate = SubstrateSelectionCertificate(
            selection_id=selection_id,
            task_id=task.task_id,
            capability_id=capability_id,
            candidate_binding_ids=candidate_ids,
            ordered_binding_ids=tuple(item.binding_id for item in ordered),
            rejected=tuple(rejected),
            policy_digest=policy_digest,
            preferred_profile_ids=policy.preferred_profile_ids,
            preferred_kinds=policy.preferred_kinds,
        )
        return SubstrateSelection(ordered, certificate)
