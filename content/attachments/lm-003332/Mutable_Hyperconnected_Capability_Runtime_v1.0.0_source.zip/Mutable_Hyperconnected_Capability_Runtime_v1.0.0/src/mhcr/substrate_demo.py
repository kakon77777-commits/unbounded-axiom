from __future__ import annotations

import json
from pathlib import Path
import tempfile

from .accounting import CostRecord, CostVector, GCAL
from .gcm_integration import (
    GCMCapacityBinding,
    GCMPhaseBAdapter,
    GCMProviderBinding,
    GCMResourceBindingStore,
)
from .history import EventLog
from .models import Capability, Provider, SubstratePolicy, TaskContract, TrustState
from .registry import CapabilityRegistry
from .routing import CostEvidence, CostMetric
from .runtime import MHCRRuntime
from .sqlite_repository import SQLiteRepository
from .substrate import (
    PCMTProfile,
    SubstrateKind,
    SubstrateProfile,
    SubstrateProfileStore,
    SubstrateRealization,
    TransitionLawClass,
)
from .verification import VerifierRegistry


def _profiles(store: SubstrateProfileStore) -> None:
    store.upsert(
        SubstrateProfile(
            "substrate.cpu.native.v1",
            SubstrateKind.CPU,
            SubstrateRealization.NATIVE,
            gcm_resource_kind="cpu",
            features=("scalar",),
            energy_units=CostMetric(3, CostEvidence.MEASURED),
        )
    )
    store.upsert(
        SubstrateProfile(
            "substrate.event.sim.v1",
            SubstrateKind.EVENT_DRIVEN,
            SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            features=("event", "stream"),
            transition_laws=(TransitionLawClass.DETERMINISTIC,),
            energy_units=CostMetric(4, CostEvidence.ESTIMATED),
        )
    )
    store.upsert(
        SubstrateProfile(
            "substrate.phase.sim.v1",
            SubstrateKind.PHASE,
            SubstrateRealization.SIMULATED,
            gcm_resource_kind="other",
            features=("phase",),
            transition_laws=(TransitionLawClass.DETERMINISTIC,),
            energy_units=CostMetric(8, CostEvidence.ESTIMATED),
            pcmt=PCMTProfile(
                "relational",
                "complex-state",
                "von-neumann-simulated",
                "coupled-update",
                "explicit",
                "persistent-state",
                "typed-result",
            ),
        )
    )


def _binding(provider_id: str, resource_id: str, kind: str, profile_id: str) -> GCMProviderBinding:
    return GCMProviderBinding(
        binding_id=f"binding:{provider_id}",
        provider_id=provider_id,
        resource_id=resource_id,
        configuration_id=f"cfg:{provider_id}",
        executor_id=provider_id,
        resource_kind=kind,
        capabilities=("transform",),
        dimensions=(GCMCapacityBinding("work.units", "unit", 16, 8),),
        substrate_profile_id=profile_id,
    )


def _bindings(store: GCMResourceBindingStore) -> None:
    store.upsert(_binding("provider.phase", "resource.phase", "other", "substrate.phase.sim.v1"))
    store.upsert(_binding("provider.event", "resource.event", "other", "substrate.event.sim.v1"))
    store.upsert(_binding("provider.cpu", "resource.cpu", "cpu", "substrate.cpu.native.v1"))


def _verifiers() -> VerifierRegistry:
    registry = VerifierRegistry()
    registry.register("verify.transform", lambda task, result: result == task.payload * 2)
    return registry


def _decision(decision) -> dict[str, object]:
    return {
        "provider_id": decision.provider_id,
        "resource_id": decision.resource_id,
        "configuration_id": decision.configuration_id,
        "substrate_profile_id": decision.substrate_profile_id,
        "substrate_kind": decision.substrate_kind,
        "substrate_realization": decision.substrate_realization,
        "substrate_selection_id": decision.substrate_selection_id,
        "substrate_fallback_used": decision.substrate_fallback_used,
    }


def run_demo() -> dict[str, object]:
    executed: list[str] = []
    with tempfile.TemporaryDirectory(prefix="mhcr-v09-substrate-") as td:
        root = Path(td)
        db = root / "mhcr.sqlite3"
        history_path = root / "events.jsonl"
        history = EventLog(history_path)
        repo = SQLiteRepository(db)
        registry = CapabilityRegistry(repository=repo, event_log=history)
        capability = Capability(
            "cap.transform",
            "1.0.0",
            "transform",
            "number",
            "number",
            "exact",
            ("provider.phase", "provider.event", "provider.cpu"),
            verifier_id="verify.transform",
            trust_state=TrustState.TRUSTED,
        )
        registry.register_capability(capability)
        registry.register_provider(
            Provider("provider.phase", capability.capability_id, lambda x: executed.append("phase") or x * 2)
        )
        registry.register_provider(
            Provider("provider.event", capability.capability_id, lambda x: executed.append("event") or x * 2)
        )
        registry.register_provider(
            Provider("provider.cpu", capability.capability_id, lambda x: executed.append("cpu") or x * 2)
        )
        profiles = SubstrateProfileStore(repository=repo, event_log=history)
        _profiles(profiles)
        bindings = GCMResourceBindingStore(repository=repo, event_log=history)
        _bindings(bindings)
        gcal = GCAL(repository=repo)
        for provider_id in capability.provider_ids:
            gcal.register_cost(CostRecord(provider_id, CostVector(local_work=1.0)))
        adapter = GCMPhaseBAdapter(bindings, substrate_catalog=profiles, event_log=history)
        runtime = MHCRRuntime(
            registry,
            _verifiers(),
            gcal,
            history,
            compute_allocator=adapter,
        )

        phase = runtime.solve(
            TaskContract(
                "task.phase",
                "transform",
                "number",
                "number",
                4,
                substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
            )
        )
        native = runtime.solve(
            TaskContract(
                "task.native",
                "transform",
                "number",
                "number",
                5,
                substrate_policy=SubstratePolicy(
                    preferred_kinds=("phase", "event_driven"),
                    allow_simulated=False,
                ),
            )
        )
        event = runtime.solve(
            TaskContract(
                "task.event",
                "transform",
                "number",
                "number",
                6,
                substrate_policy=SubstratePolicy(preferred_kinds=("event_driven",)),
            )
        )
        energy = runtime.solve(
            TaskContract(
                "task.energy",
                "transform",
                "number",
                "number",
                7,
                substrate_policy=SubstratePolicy(
                    allowed_kinds=("phase", "cpu"),
                    preferred_kinds=("phase",),
                    max_energy_units=5,
                ),
            )
        )
        repo.close()

        reopened = SQLiteRepository(db)
        history2 = EventLog(history_path)
        restored_registry = CapabilityRegistry.from_repository(
            reopened,
            provider_executors={
                "provider.phase": lambda x: executed.append("phase-restart") or x * 2,
                "provider.event": lambda x: executed.append("event-restart") or x * 2,
                "provider.cpu": lambda x: executed.append("cpu-restart") or x * 2,
            },
            event_log=history2,
        )
        restored_profiles = SubstrateProfileStore(repository=reopened, event_log=history2)
        restored_bindings = GCMResourceBindingStore(repository=reopened, event_log=history2)
        restored = MHCRRuntime(
            restored_registry,
            _verifiers(),
            GCAL(repository=reopened),
            history2,
            compute_allocator=GCMPhaseBAdapter(
                restored_bindings,
                substrate_catalog=restored_profiles,
                event_log=history2,
            ),
        )
        restart = restored.solve(
            TaskContract(
                "task.restart",
                "transform",
                "number",
                "number",
                8,
                substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
            )
        )
        profile_count = len(restored_profiles.records())
        binding_count = len(restored_bindings.records())
        reopened.close()

        all_events = EventLog(history_path).read_all()
        world_commit_events = sum(
            "WORLD" in event.event_type and "COMMIT" in event.event_type
            for event in all_events
        )
        return {
            "phase_preference": _decision(phase.compute_allocations[0]),
            "native_fallback": _decision(native.compute_allocations[0]),
            "event_preference": _decision(event.compute_allocations[0]),
            "energy_fallback": _decision(energy.compute_allocations[0]),
            "restart": {
                **_decision(restart.compute_allocations[0]),
                "profile_count": profile_count,
                "binding_count": binding_count,
            },
            "executed": executed,
            "world_commit_events": world_commit_events,
        }


def main() -> None:
    print(json.dumps(run_demo(), sort_keys=True))


if __name__ == "__main__":
    main()
