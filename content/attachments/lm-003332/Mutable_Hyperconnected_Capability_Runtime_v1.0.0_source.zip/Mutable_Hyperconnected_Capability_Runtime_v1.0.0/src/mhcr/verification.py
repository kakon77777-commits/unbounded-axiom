from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .models import TaskContract


@dataclass(frozen=True, slots=True)
class VerificationResult:
    passed: bool
    details: str = ""


class VerifierRegistry:
    def __init__(self) -> None:
        self._verifiers: dict[str, Callable[[TaskContract, Any], bool | VerificationResult]] = {}
        self.invocation_count = 0

    def register(self, verifier_id: str, verifier: Callable[[TaskContract, Any], bool | VerificationResult]) -> None:
        self._verifiers[verifier_id] = verifier

    def verify(self, verifier_id: str | None, task: TaskContract, result: Any) -> VerificationResult:
        self.invocation_count += 1
        if verifier_id is None or verifier_id not in self._verifiers:
            return VerificationResult(False, f"missing verifier: {verifier_id}")
        verdict = self._verifiers[verifier_id](task, result)
        if isinstance(verdict, VerificationResult):
            return verdict
        return VerificationResult(bool(verdict), "passed" if verdict else "failed")
