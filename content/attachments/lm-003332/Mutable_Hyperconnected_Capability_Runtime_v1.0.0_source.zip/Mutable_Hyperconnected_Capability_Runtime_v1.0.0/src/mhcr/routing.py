from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import TYPE_CHECKING

from .models import Provider, ProviderBoundary, ProviderHealth, RoutingPreference, TaskPolicy

if TYPE_CHECKING:
    from .history import EventLog
    from .repository import RegistryRepository


class CostEvidence(str, Enum):
    MEASURED = "measured"
    ESTIMATED = "estimated"
    DECLARED = "declared"
    FORMALLY_BOUNDED = "formally_bounded"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class CostMetric:
    value: float | None = None
    evidence: CostEvidence = CostEvidence.UNKNOWN
    sample_count: int = 0

    def __post_init__(self) -> None:
        if self.evidence is CostEvidence.UNKNOWN and self.value is not None:
            raise ValueError("UNKNOWN metric cannot carry a value")
        if self.evidence is not CostEvidence.UNKNOWN and self.value is None:
            raise ValueError("known metric requires a value")
        if self.sample_count < 0:
            raise ValueError("sample_count cannot be negative")

    @property
    def known(self) -> bool:
        return self.value is not None and self.evidence is not CostEvidence.UNKNOWN


@dataclass(frozen=True, slots=True)
class ProviderCostProfile:
    provider_id: str
    latency_ms: CostMetric = field(default_factory=CostMetric)
    monetary_cost_usd: CostMetric = field(default_factory=CostMetric)
    network_bytes: CostMetric = field(default_factory=CostMetric)
    verification_work: CostMetric = field(default_factory=CostMetric)
    risk_score: CostMetric = field(default_factory=CostMetric)

    def with_latency(self, metric: CostMetric) -> "ProviderCostProfile":
        return replace(self, latency_ms=metric)


@dataclass(frozen=True, slots=True)
class LatencyObservation:
    profile: ProviderCostProfile
    previous_value: float | None
    observed_value: float
    drifted: bool
    drift_ratio: float | None


class ProviderCostCatalog:
    def __init__(
        self,
        repository: "RegistryRepository | None" = None,
        event_log: "EventLog | None" = None,
        *,
        drift_ratio: float = 0.5,
    ) -> None:
        self._repository = repository
        self._event_log = event_log
        self._drift_ratio = drift_ratio
        self._profiles: dict[str, ProviderCostProfile] = {}
        if repository is not None and hasattr(repository, "load_provider_cost_profiles"):
            self._profiles = {
                profile.provider_id: profile
                for profile in repository.load_provider_cost_profiles()
            }

    def get(self, provider_id: str) -> ProviderCostProfile:
        return self._profiles.get(provider_id, ProviderCostProfile(provider_id))

    def upsert(self, profile: ProviderCostProfile, *, persist: bool = True) -> ProviderCostProfile:
        self._profiles[profile.provider_id] = profile
        if persist and self._repository is not None:
            self._repository.save_provider_cost_profile(profile)
        return profile

    def profiles(self) -> tuple[ProviderCostProfile, ...]:
        return tuple(self._profiles[key] for key in sorted(self._profiles))

    def observe_latency(
        self, provider_id: str, observed_ms: float, *, persist: bool = True
    ) -> LatencyObservation:
        if observed_ms < 0:
            raise ValueError("observed latency cannot be negative")
        profile = self.get(provider_id)
        previous = profile.latency_ms
        previous_value = previous.value if previous.known else None
        drift_ratio: float | None = None
        drifted = False
        if previous_value is not None and previous_value > 0:
            drift_ratio = abs(observed_ms - previous_value) / previous_value
            drifted = drift_ratio >= self._drift_ratio

        if previous.evidence is CostEvidence.MEASURED and previous.sample_count > 0:
            sample_count = previous.sample_count + 1
            assert previous.value is not None
            calibrated = ((previous.value * previous.sample_count) + observed_ms) / sample_count
        else:
            sample_count = 1
            calibrated = observed_ms

        updated = profile.with_latency(
            CostMetric(calibrated, CostEvidence.MEASURED, sample_count=sample_count)
        )
        self.upsert(updated, persist=persist)
        return LatencyObservation(
            profile=updated,
            previous_value=previous_value,
            observed_value=observed_ms,
            drifted=drifted,
            drift_ratio=drift_ratio,
        )


@dataclass(frozen=True, slots=True)
class ProviderRoutingDecision:
    providers: tuple[Provider, ...]
    rejected: tuple[tuple[str, str], ...] = ()


class CostAwareRouter:
    _HEALTH_PRIORITY = {
        ProviderHealth.HEALTHY: 0,
        ProviderHealth.DEGRADED: 1,
    }
    _LOCALITY_PRIORITY = {
        ProviderBoundary.LOCAL: 0,
        ProviderBoundary.PROCESS: 1,
        ProviderBoundary.CONTAINER: 2,
        ProviderBoundary.NETWORK: 3,
    }

    def __init__(self, catalog: ProviderCostCatalog) -> None:
        self.catalog = catalog

    @staticmethod
    def _metric_rejection(metric: CostMetric, ceiling: float, label: str) -> str | None:
        if not metric.known:
            return f"{label}_unknown"
        assert metric.value is not None
        if metric.value > ceiling:
            return f"{label}_exceeds_ceiling"
        return None

    def _hard_rejection(self, provider: Provider, policy: TaskPolicy) -> str | None:
        profile = self.catalog.get(provider.provider_id)
        if policy.local_only and provider.boundary is ProviderBoundary.NETWORK:
            return "network_provider_disallowed"
        if policy.max_latency_ms is not None:
            reason = self._metric_rejection(profile.latency_ms, policy.max_latency_ms, "latency")
            if reason:
                return reason
        if policy.max_external_cost_usd is not None and provider.boundary is ProviderBoundary.NETWORK:
            reason = self._metric_rejection(
                profile.monetary_cost_usd, policy.max_external_cost_usd, "external_cost"
            )
            if reason:
                return reason
        if policy.max_network_bytes is not None and provider.boundary is ProviderBoundary.NETWORK:
            reason = self._metric_rejection(
                profile.network_bytes, policy.max_network_bytes, "network_bytes"
            )
            if reason:
                return reason
        if policy.max_verification_work is not None:
            reason = self._metric_rejection(
                profile.verification_work, policy.max_verification_work, "verification_work"
            )
            if reason:
                return reason
        if policy.max_risk_score is not None:
            reason = self._metric_rejection(profile.risk_score, policy.max_risk_score, "risk")
            if reason:
                return reason
        return None

    @staticmethod
    def _metric_key(metric: CostMetric) -> tuple[int, float]:
        if not metric.known:
            return (1, float("inf"))
        assert metric.value is not None
        return (0, metric.value)

    def _preference_key(self, provider: Provider, policy: TaskPolicy) -> tuple[object, ...]:
        profile = self.catalog.get(provider.provider_id)
        key: list[object] = []
        for preference in policy.prefer:
            if preference is RoutingPreference.LATENCY:
                key.extend(self._metric_key(profile.latency_ms))
            elif preference is RoutingPreference.MONETARY_COST:
                key.extend(self._metric_key(profile.monetary_cost_usd))
            elif preference is RoutingPreference.NETWORK_BYTES:
                key.extend(self._metric_key(profile.network_bytes))
            elif preference is RoutingPreference.VERIFICATION_WORK:
                key.extend(self._metric_key(profile.verification_work))
            elif preference is RoutingPreference.RISK:
                key.extend(self._metric_key(profile.risk_score))
            elif preference is RoutingPreference.LOCALITY:
                key.append(self._LOCALITY_PRIORITY[provider.boundary])
            elif preference is RoutingPreference.KNOWN_COST:
                unknown_count = sum(
                    not metric.known
                    for metric in (
                        profile.latency_ms,
                        profile.monetary_cost_usd,
                        profile.network_bytes,
                        profile.verification_work,
                        profile.risk_score,
                    )
                )
                key.append(unknown_count)
        return tuple(key)

    def route(self, providers: list[Provider], policy: TaskPolicy) -> ProviderRoutingDecision:
        if policy.is_default:
            return ProviderRoutingDecision(tuple(providers))

        accepted: list[tuple[int, Provider]] = []
        rejected: list[tuple[str, str]] = []
        for original_index, provider in enumerate(providers):
            reason = self._hard_rejection(provider, policy)
            if reason is not None:
                rejected.append((provider.provider_id, reason))
                continue
            accepted.append((original_index, provider))

        accepted.sort(
            key=lambda item: (
                self._HEALTH_PRIORITY[item[1].health],
                self._preference_key(item[1], policy),
                item[0],
            )
        )
        return ProviderRoutingDecision(
            tuple(provider for _, provider in accepted),
            tuple(rejected),
        )
