from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .repository import RegistryRepository


class AccountingStatus(str, Enum):
    CLOSED_ACCOUNTED = "closed_accounted"
    ACCOUNTING_INCOMPLETE = "accounting_incomplete"


@dataclass(frozen=True, slots=True)
class CostVector:
    local_work: float = 0.0
    external_work: float = 0.0
    offline_work: float = 0.0
    verification_work: float = 0.0
    monetary_cost: float = 0.0

    def __add__(self, other: "CostVector") -> "CostVector":
        return CostVector(
            local_work=self.local_work + other.local_work,
            external_work=self.external_work + other.external_work,
            offline_work=self.offline_work + other.offline_work,
            verification_work=self.verification_work + other.verification_work,
            monetary_cost=self.monetary_cost + other.monetary_cost,
        )


@dataclass(frozen=True, slots=True)
class CostRecord:
    node_id: str
    cost: CostVector
    known: bool = True
    shared_cost_id: str | None = None


@dataclass(frozen=True, slots=True)
class Dependency:
    parent: str
    child: str
    required: bool = True


@dataclass(frozen=True, slots=True)
class AccountingReport:
    root: str
    status: AccountingStatus
    local: CostVector
    closed: CostVector
    closure: tuple[str, ...]
    unknown_nodes: tuple[str, ...]

    @property
    def is_closed_complete(self) -> bool:
        return self.status is AccountingStatus.CLOSED_ACCOUNTED


class GCAL:
    def __init__(self, repository: "RegistryRepository | None" = None) -> None:
        self._repository = repository
        self._costs: dict[str, CostRecord] = {}
        self._dependencies: list[Dependency] = []
        if repository is not None:
            self._costs = {record.node_id: record for record in repository.load_costs()}

    def register_cost(self, record: CostRecord, *, persist: bool = True) -> None:
        self._costs[record.node_id] = record
        if persist and self._repository is not None:
            self._repository.save_cost(record)

    def register_dependency(self, dependency: Dependency) -> None:
        self._dependencies.append(dependency)

    def responsibility_closure(self, root: str) -> tuple[str, ...]:
        seen: set[str] = set()
        stack = [root]
        adjacency: dict[str, list[str]] = {}
        for dep in self._dependencies:
            if dep.required:
                adjacency.setdefault(dep.parent, []).append(dep.child)

        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            stack.extend(adjacency.get(node, ()))
        return tuple(sorted(seen))

    def account(self, root: str) -> AccountingReport:
        closure = self.responsibility_closure(root)
        root_record = self._costs.get(root)
        local = root_record.cost if root_record is not None and root_record.known else CostVector()

        total = CostVector()
        unknown: list[str] = []
        charged_shared: set[str] = set()
        for node in closure:
            record = self._costs.get(node)
            if record is None or not record.known:
                unknown.append(node)
                continue
            if record.shared_cost_id is not None:
                if record.shared_cost_id in charged_shared:
                    continue
                charged_shared.add(record.shared_cost_id)
            total = total + record.cost

        status = (
            AccountingStatus.CLOSED_ACCOUNTED
            if not unknown
            else AccountingStatus.ACCOUNTING_INCOMPLETE
        )
        return AccountingReport(
            root=root,
            status=status,
            local=local,
            closed=total,
            closure=closure,
            unknown_nodes=tuple(sorted(unknown)),
        )
