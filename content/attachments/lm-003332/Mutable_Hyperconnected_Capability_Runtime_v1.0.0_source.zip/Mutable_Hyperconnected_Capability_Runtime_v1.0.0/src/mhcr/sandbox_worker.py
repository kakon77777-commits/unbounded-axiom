"""Trusted worker for the MHCR reference sandbox.

This module is executed as a standalone isolated Python process. Generated source is
never imported into the parent MHCR interpreter.
"""
from __future__ import annotations

import json
import os
import sys


SAFE_BUILTINS = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "float": float,
    "int": int,
    "len": len,
    "list": list,
    "max": max,
    "min": min,
    "pow": pow,
    "range": range,
    "reversed": reversed,
    "round": round,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
}


def _apply_limits() -> bool:
    try:
        import resource
    except Exception:
        return False
    applied = False
    try:
        cpu = int(os.environ.get("MHCR_SANDBOX_CPU_SECONDS", "1"))
        resource.setrlimit(resource.RLIMIT_CPU, (cpu, cpu + 1))
        applied = True
    except Exception:
        pass
    try:
        memory = int(os.environ.get("MHCR_SANDBOX_MEMORY_BYTES", "134217728"))
        resource.setrlimit(resource.RLIMIT_AS, (memory, memory))
        applied = True
    except Exception:
        pass
    return applied


def _write(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    sys.stdout.flush()


def main() -> int:
    limits_applied = _apply_limits()
    try:
        request = json.loads(sys.stdin.read())
        source = request["source"]
        entrypoint = request["entrypoint"]
        payload = request["payload"]
        namespace = {"__builtins__": SAFE_BUILTINS}
        code = compile(source, "<mhcr-generated-candidate>", "exec")
        exec(code, namespace, namespace)
        fn = namespace[entrypoint]
        value = fn(payload)
        try:
            json.dumps(value, ensure_ascii=False)
        except (TypeError, ValueError) as exc:
            _write(
                {
                    "ok": False,
                    "error_type": "serialization",
                    "error_class": type(exc).__name__,
                    "message": f"generated result is not JSON serializable: {exc}",
                }
            )
            return 4
        _write(
            {
                "ok": True,
                "value": value,
                "diagnostics": {
                    "environment_keys": sorted(os.environ.keys()),
                    "cwd": os.getcwd(),
                    "resource_limits_applied": limits_applied,
                    "generated_global_names": sorted(
                        key for key in namespace.keys() if key != "__builtins__"
                    ),
                    "worker_pid": os.getpid(),
                },
            }
        )
        return 0
    except BaseException as exc:
        _write(
            {
                "ok": False,
                "error_type": "execution",
                "error_class": type(exc).__name__,
                "message": str(exc),
            }
        )
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
