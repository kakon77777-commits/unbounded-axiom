from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from importlib import resources
import json
from typing import Any


class ConformanceCaseStatus(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    INDETERMINATE = "indeterminate"
    NOT_APPLICABLE = "not_applicable"


class ConformanceClaim(str, Enum):
    CONFORMANT = "conformant"
    NONCONFORMANT = "nonconformant"
    INDETERMINATE = "indeterminate"
    NOT_AVAILABLE = "not_available"


@dataclass(frozen=True, slots=True)
class ConformanceCaseResult:
    case_id: str
    status: ConformanceCaseStatus
    summary: str
    evidence: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "status": self.status.value,
            "summary": self.summary,
            "evidence": self.evidence,
        }


@dataclass(frozen=True, slots=True)
class ConformanceProfileResult:
    profile_id: str
    claim: ConformanceClaim
    cases: tuple[ConformanceCaseResult, ...]
    required_passed: int
    required_failed: int
    required_indeterminate: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "profile_id": self.profile_id,
            "claim": self.claim.value,
            "required_passed": self.required_passed,
            "required_failed": self.required_failed,
            "required_indeterminate": self.required_indeterminate,
            "cases": [case.as_dict() for case in self.cases],
        }


def _manifest_filename(profile_id: str) -> str:
    filenames = {
        "MHCR-CORE-R1": "core_manifest.json",
        "MHCR-GCM-R1": "gcm_manifest.json",
    }
    try:
        return filenames[profile_id]
    except KeyError as exc:
        raise ValueError(f"unknown conformance profile: {profile_id}") from exc


def load_conformance_manifest(profile_id: str) -> dict[str, Any]:
    filename = _manifest_filename(profile_id)
    path = resources.files("mhcr").joinpath("data", "v1_conformance", filename)
    return json.loads(path.read_text(encoding="utf-8"))


def _gcm_available() -> bool:
    try:
        import gcm_runtime  # noqa: F401
    except ImportError:
        return False
    return True


def _result_from_cases(profile_id: str, cases: tuple[ConformanceCaseResult, ...]) -> ConformanceProfileResult:
    manifest = load_conformance_manifest(profile_id)
    required = {case["case_id"] for case in manifest["cases"] if case.get("required", False)}
    relevant = [case for case in cases if case.case_id in required]
    passed = sum(case.status is ConformanceCaseStatus.PASS for case in relevant)
    failed = sum(case.status is ConformanceCaseStatus.FAIL for case in relevant)
    indeterminate = sum(case.status is ConformanceCaseStatus.INDETERMINATE for case in relevant)
    if failed:
        claim = ConformanceClaim.NONCONFORMANT
    elif indeterminate or len(relevant) != len(required):
        claim = ConformanceClaim.INDETERMINATE
    else:
        claim = ConformanceClaim.CONFORMANT
    return ConformanceProfileResult(profile_id, claim, cases, passed, failed, indeterminate)



def _case(case_id: str, ok: bool, summary: str, evidence: dict[str, Any]) -> ConformanceCaseResult:
    return ConformanceCaseResult(
        case_id,
        ConformanceCaseStatus.PASS if ok else ConformanceCaseStatus.FAIL,
        summary,
        evidence,
    )


def _run_core_profile() -> ConformanceProfileResult:
    from tempfile import TemporaryDirectory
    from pathlib import Path

    from .demo import build_demo
    from .sqlite_repository import SQLiteRepository
    from .substrate import SubstrateKind, SubstrateProfile, SubstrateRealization

    demo = build_demo()
    first = demo["first"]
    second = demo["second"]
    provider = demo["provider_fabric"]
    routing = demo["cost_routing"]
    composition = demo["composition"]
    acquisition = demo["acquisition_learning"]
    sandbox = demo["generated_sandbox"]
    history = demo["history"]
    benchmark = demo["benchmark"]

    with TemporaryDirectory(prefix="mhcr-v1-schema-") as directory:
        repo = SQLiteRepository(Path(directory) / "mhcr.sqlite3")
        schema_version = repo.schema_version
        repo.close()

    kinds = tuple(item.value for item in SubstrateKind)
    realizations = tuple(item.value for item in SubstrateRealization)
    minimal_profile = SubstrateProfile(
        profile_id="profile.v1.core",
        kind=SubstrateKind.CPU,
        realization=SubstrateRealization.NATIVE,
        gcm_resource_kind="cpu",
    )
    world_commit_events = sum(
        count for event_type, count in history.items()
        if "WORLD" in event_type.upper() and "COMMIT" in event_type.upper()
    )

    checks = [
        _case("C01", first["source"] == "constructed" and first["execution_path"] == "full", "candidate was acquired through full path", dict(first)),
        _case("C02", second["source"] == "resolved" and second["value"] == 49, "unseen payload reused promoted solver", dict(second)),
        _case("C03", demo["restart_count"] == 1, "persistent restart witness exists", {"restart_count": demo["restart_count"]}),
        _case("C04", second["execution_path"] == "fast" and second["acquisition_events"] == 0, "known trusted solver used indexed fast path", dict(second)),
        _case("C05", provider["failed_provider_health"] == "unavailable" and provider["restart_failed_provider_health"] == "unavailable", "provider health downgrade survived restart", dict(provider)),
        _case("C06", provider["boundary_events"] >= 1, "boundary crossing evidence recorded", {"boundary_events": provider["boundary_events"]}),
        _case("C07", provider["first_accounting"] == "accounting_incomplete", "failed external attempt remained in responsibility accounting", {"accounting": provider["first_accounting"]}),
        _case("C08", routing["latency_provider"] == "provider.route.fast", "latency policy selected fast provider", {"provider_id": routing["latency_provider"]}),
        _case("C09", routing["money_provider"] == "provider.route.cheap", "money policy selected cheap provider", {"provider_id": routing["money_provider"]}),
        _case("C10", routing["local_only_provider"] == "provider.route.local", "local-only policy stayed local", {"provider_id": routing["local_only_provider"]}),
        _case("C11", routing["restored_unknown_price_evidence"] == "unknown", "unknown monetary evidence remained unknown", {"evidence": routing["restored_unknown_price_evidence"]}),
        _case("C12", len(composition["component_ids"]) == 3 and composition["first_source"] == "composed", "three-step typed composition executed", {"component_ids": composition["component_ids"]}),
        _case("C13", composition["composite_id"].startswith("cap.composite.") and composition["composite_trust_before_restart"] == "trusted", "composition canonicalized into trusted composite", {"composite_id": composition["composite_id"]}),
        _case("C14", composition["restart_graph_searches"] == 0 and composition["restart_execution_path"] == "fast", "composite reused without graph search after restart", {"restart_graph_searches": composition["restart_graph_searches"], "execution_path": composition["restart_execution_path"]}),
        _case("C15", composition["trust_after_component_revoke"] == "deprecated", "component revocation invalidated composite", {"trust": composition["trust_after_component_revoke"]}),
        _case("C16", composition["replay_trust_after_revoke"] == "deprecated", "replay preserved composite invalidation", {"replay_trust": composition["replay_trust_after_revoke"]}),
        _case("C17", acquisition["persistent_total_work"] < acquisition["stateless_total_work"] and acquisition["persistent_post_first_mean_work"] < acquisition["stateless_post_first_mean_work"], "persistent acquisition reduced acquisition work", dict(acquisition)),
        _case("C18", acquisition["all_cache_hits_false"] is True and sandbox["restart_cache_hit"] is False, "solver reuse did not use answer cache", {"all_cache_hits_false": acquisition["all_cache_hits_false"], "sandbox_restart_cache_hit": sandbox["restart_cache_hit"]}),
        _case("C19", acquisition["persistent_solver_memory_hits"] > 0, "solver memory reused", {"solver_memory_hits": acquisition["persistent_solver_memory_hits"]}),
        _case("C20", acquisition["persistent_verification_memory_hits"] > 0, "verification memory reused", {"verification_memory_hits": acquisition["persistent_verification_memory_hits"]}),
        _case("C21", sandbox["first_artifact_status"] == "promoted" and sandbox["first_capability_trust"] == "trusted", "sandbox candidate required verifier-gated promotion", dict(sandbox)),
        _case("C22", sandbox["sandbox_provider_boundary"] == "process", "generated solver executed through process boundary", {"boundary": sandbox["sandbox_provider_boundary"]}),
        _case("C23", sandbox["restart_execution_path"] == "fast" and sandbox["restart_source"] == "resolved", "sandboxed solver survived restart and fast reuse", {"source": sandbox["restart_source"], "execution_path": sandbox["restart_execution_path"]}),
        _case("C24", sandbox["artifact_source_hash_matches"] is True, "generated artifact source hash provenance matched", {"source_hash_matches": sandbox["artifact_source_hash_matches"]}),
        _case("C25", True, "core profile remains executable independent of optional GCM allocation", {"gcm_available_in_environment": _gcm_available(), "core_requires_gcm": False}),
        _case("C26", kinds == ("cpu", "gpu", "fpga", "event_driven", "neuromorphic", "phase", "quantum", "special_accelerator"), "heterogeneous substrate vocabulary is stable", {"kinds": kinds}),
        _case("C27", "native" in realizations and "simulated" in realizations and "emulated" in realizations, "substrate realization distinguishes native from simulated/emulated", {"realizations": realizations}),
        _case("C28", minimal_profile.pcmt is None and minimal_profile.morphology is None, "PCMT/morphology remain optional extension metadata", {"pcmt": None, "morphology": None}),
        _case("C29", history.get("TASK_COMPLETED", 0) >= 4 and history.get("REGISTRY_CAPABILITY_UPSERTED", 0) >= 1, "append-only history recorded runtime and registry events", {"task_completed": history.get("TASK_COMPLETED", 0), "capability_upserts": history.get("REGISTRY_CAPABILITY_UPSERTED", 0)}),
        _case("C30", schema_version == 8, "v1 convergence preserves SQLite schema 8", {"schema_version": schema_version}),
        _case("C31", benchmark["speedup_ratio"] > 1.0, "indexed resolver beat linear scan in current environment", {"speedup_ratio": benchmark["speedup_ratio"], "registry_size": benchmark["registry_size"], "iterations": benchmark["iterations"]}),
        _case("C32", world_commit_events == 0, "standalone MHCR emitted no World commit event", {"world_commit_events": world_commit_events}),
    ]
    return _result_from_cases("MHCR-CORE-R1", tuple(checks))



def _gcm_hard_safe_evidence() -> tuple[bool, dict[str, Any]]:
    from .gcm_integration import (
        GCMAllocationRejectedError,
        GCMCapacityBinding,
        GCMPhaseBAdapter,
        GCMProviderBinding,
        GCMResourceBindingStore,
    )
    from .models import Capability, TaskContract, TaskPolicy, TrustState
    from .routing import ProviderCostCatalog

    store = GCMResourceBindingStore()
    store.upsert(
        GCMProviderBinding(
            binding_id="binding:v1.unknown",
            provider_id="provider.v1.unknown",
            resource_id="resource.v1.unknown",
            configuration_id="cfg:v1.unknown",
            executor_id="provider.v1.unknown",
            resource_kind="cpu",
            capabilities=("square",),
            locality="local",
            dimensions=(GCMCapacityBinding("slots", "logical-unit", 16, 8),),
        )
    )
    adapter = GCMPhaseBAdapter(store, cost_catalog=ProviderCostCatalog())
    capability = Capability(
        "cap.v1.gcm.hard-safe", "1.0.0", "square", "number", "number", "exact",
        ("provider.v1.unknown",), trust_state=TrustState.TRUSTED,
    )
    task = TaskContract(
        "task.v1.gcm.hard-safe", "square", "number", "number", 8,
        policy=TaskPolicy(max_latency_ms=5.0),
    )
    try:
        adapter.allocate(task, capability, ("provider.v1.unknown",))
    except GCMAllocationRejectedError as exc:
        reasons = [
            reason
            for failure in exc.failures
            for reason in failure.get("reasons", [])
        ]
        ok = any("missing estimate: latency_ms" in reason for reason in reasons)
        return ok, {"reasons": reasons}
    return False, {"reasons": []}


def _gcm_no_cross_failover_evidence() -> tuple[bool, dict[str, Any]]:
    from tempfile import TemporaryDirectory
    from pathlib import Path

    from .accounting import CostRecord, CostVector, GCAL
    from .gcm_integration import (
        GCMCapacityBinding,
        GCMPhaseBAdapter,
        GCMProviderBinding,
        GCMResourceBindingStore,
    )
    from .history import EventLog
    from .models import Capability, Provider, SubstratePolicy, TaskContract, TrustState
    from .registry import CapabilityRegistry
    from .routing import CostEvidence, CostMetric
    from .runtime import MHCRRuntime
    from .substrate import SubstrateKind, SubstrateProfile, SubstrateProfileStore, SubstrateRealization
    from .verification import VerifierRegistry

    with TemporaryDirectory(prefix="mhcr-v1-gcm-failover-") as directory:
        calls: list[str] = []
        history = EventLog(Path(directory) / "events.jsonl")
        registry = CapabilityRegistry(event_log=history)
        capability = Capability(
            "cap.v1.cross", "1.0.0", "transform", "number", "number", "exact",
            ("provider.phase", "provider.cpu"), verifier_id="verify.transform",
            trust_state=TrustState.TRUSTED,
        )
        registry.register_capability(capability)

        def broken_phase(_value):
            calls.append("phase")
            raise RuntimeError("phase execution failed")

        registry.register_provider(Provider("provider.phase", capability.capability_id, broken_phase))
        registry.register_provider(Provider("provider.cpu", capability.capability_id, lambda value: calls.append("cpu") or value * 2))
        verifiers = VerifierRegistry()
        verifiers.register("verify.transform", lambda task, result: result == task.payload * 2)
        gcal = GCAL()
        gcal.register_cost(CostRecord("provider.phase", CostVector(local_work=1.0)))
        gcal.register_cost(CostRecord("provider.cpu", CostVector(local_work=1.0)))

        profiles = SubstrateProfileStore()
        profiles.upsert(SubstrateProfile(
            "substrate.phase.sim.v1", SubstrateKind.PHASE, SubstrateRealization.SIMULATED,
            gcm_resource_kind="other", energy_units=CostMetric(8, CostEvidence.ESTIMATED),
        ))
        profiles.upsert(SubstrateProfile(
            "substrate.cpu.native.v1", SubstrateKind.CPU, SubstrateRealization.NATIVE,
            gcm_resource_kind="cpu", energy_units=CostMetric(3, CostEvidence.MEASURED),
        ))
        bindings = GCMResourceBindingStore()
        for provider_id, resource_id, resource_kind, profile_id in (
            ("provider.phase", "resource.phase", "other", "substrate.phase.sim.v1"),
            ("provider.cpu", "resource.cpu", "cpu", "substrate.cpu.native.v1"),
        ):
            bindings.upsert(GCMProviderBinding(
                binding_id=f"binding:{provider_id}",
                provider_id=provider_id,
                resource_id=resource_id,
                configuration_id=f"cfg:{provider_id}",
                executor_id=provider_id,
                resource_kind=resource_kind,
                capabilities=("transform",),
                dimensions=(GCMCapacityBinding("work.units", "unit", 16, 8),),
                substrate_profile_id=profile_id,
            ))
        runtime = MHCRRuntime(
            registry, verifiers, gcal, history,
            compute_allocator=GCMPhaseBAdapter(bindings, substrate_catalog=profiles, event_log=history),
        )
        error = None
        try:
            runtime.solve(TaskContract(
                "task.v1.cross", "transform", "number", "number", 9,
                substrate_policy=SubstratePolicy(preferred_kinds=("phase",)),
            ))
        except RuntimeError as exc:
            error = str(exc)
        return calls == ["phase"] and error is not None, {"calls": calls, "error": error}


def _run_gcm_profile() -> ConformanceProfileResult:
    import gcm_runtime
    from .gcm_demo import run_demo as run_gcm_demo
    from .substrate_demo import run_demo as run_substrate_demo

    gcm = run_gcm_demo()
    substrate = run_substrate_demo()
    hard_safe_ok, hard_safe = _gcm_hard_safe_evidence()
    no_cross_ok, no_cross = _gcm_no_cross_failover_evidence()
    required_api = ("ComputationIntent", "PlanningContext", "CandidateSpec", "ResourceInventory", "Allocator0")
    api_missing = tuple(name for name in required_api if not hasattr(gcm_runtime, name))
    executed = tuple(substrate["executed"])

    cases = (
        _case("G01", not api_missing, "accepted GCM deterministic allocation API is available", {"missing_symbols": api_missing}),
        _case("G02", hard_safe_ok, "GCM B1 hard-limit evidence fails closed when required estimate is missing", hard_safe),
        _case("G03", gcm["gpu_capacity_fallback"]["provider_id"] == "provider.cpu", "GCM B3 capacity can override GPU preference", dict(gcm["gpu_capacity_fallback"])),
        _case("G04", executed[:4] == ("phase", "cpu", "event", "cpu"), "MHCR execution follows the provider selected by each allocation", {"executed": executed}),
        _case("G05", no_cross_ok, "selected provider failure does not trigger unauthorized cross-substrate failover", no_cross),
        _case("G06", substrate["phase_preference"]["substrate_kind"] == "phase" and substrate["phase_preference"]["substrate_realization"] == "simulated" and substrate["event_preference"]["substrate_kind"] == "event_driven", "substrate allocation evidence preserves kind and realization", {"phase": substrate["phase_preference"], "event": substrate["event_preference"]}),
        _case("G07", gcm["world_commit_events"] == 0 and substrate["world_commit_events"] == 0, "GCM allocation emitted no World commit evidence", {"gcm_world_commit_events": gcm["world_commit_events"], "substrate_world_commit_events": substrate["world_commit_events"]}),
        _case("G08", gcm["restart"]["binding_count"] == 2 and substrate["restart"]["binding_count"] == 3 and substrate["restart"]["profile_count"] == 3 and substrate["restart"]["provider_id"] == "provider.phase", "GCM/substrate allocation semantics survived restart", {"gcm_restart": gcm["restart"], "substrate_restart": substrate["restart"]}),
    )
    return _result_from_cases("MHCR-GCM-R1", cases)


def run_conformance(profile_id: str = "MHCR-CORE-R1") -> ConformanceProfileResult:
    manifest = load_conformance_manifest(profile_id)
    if profile_id == "MHCR-CORE-R1":
        return _run_core_profile()
    if profile_id == "MHCR-GCM-R1" and not _gcm_available():
        return ConformanceProfileResult(
            profile_id=profile_id,
            claim=ConformanceClaim.NOT_AVAILABLE,
            cases=(),
            required_passed=0,
            required_failed=0,
            required_indeterminate=0,
        )
    if profile_id == "MHCR-GCM-R1":
        return _run_gcm_profile()
    cases = tuple(
        ConformanceCaseResult(case["case_id"], ConformanceCaseStatus.INDETERMINATE, "unknown evaluator", {})
        for case in manifest["cases"]
    )
    return _result_from_cases(profile_id, cases)
