# Mutable Hyperconnected Capability Runtime (MHCR) v1.0

MHCR v1.0 is the **Final Convergence** release of the v0.1–v0.9 reference-runtime program.

It does not introduce another large computational feature. Instead, it seals the existing lines into one machine-verifiable developer surface:

```text
Persistent Registry / Fast Path
+ Provider Fabric
+ Cost-Aware Routing
+ Capability Composition
+ Acquisition Memory / Solver Learning
+ Sandboxed Candidate Construction
+ Optional GCM Compute Allocation
+ Heterogeneous Substrate Profiles
+ Conformance / Failure / Long-Run Acceptance
```

The central identity remains:

```text
Capability != Provider != Substrate
Candidate != Trusted
Memory != Authority
GCM Allocation != Provider Execution != World Commit
Unknown != 0
Answer Cache != Solver Learning
```

## v1.0 release surfaces

Installed CLI:

```text
mhcr --help
mhcr conformance
mhcr failure-matrix
mhcr longrun
mhcr acceptance
mhcr demo
```

Optional accepted-GCM environment:

```text
mhcr conformance --profile MHCR-GCM-R1
mhcr substrate-demo
mhcr acceptance --with-gcm
```

See `docs/v1/QUICKSTART.md` for literal POSIX and Windows virtual-environment commands.

## Core conformance

`MHCR-CORE-R1` contains exactly **32 required cases** spanning the v0.1–v0.9 lineage. A conformant result requires all 32 to PASS; no percentage shortcut is used.

The core profile validates candidate promotion, unseen solver reuse, persistence, indexed fast path, provider health/boundary/accounting, cost routing, typed composition, composite invalidation, acquisition learning, no-answer-cache, sandbox promotion/restart, optional-GCM separation, substrate vocabulary/hardware honesty, append-only history, SQLite schema-8 continuity, indexed resolver evidence and World-commit isolation.

## Failure matrix

`MHCR-FAILURE-R1` contains **F01–F10** executable scenarios. They cover unavailable providers, unknown hard costs, failed external responsibility, transitive composite invalidation, failed-acquisition memory, no-answer-cache, static sandbox rejection, timeout rejection, generated-artifact revocation and restart/replay truth.

## Long-run convergence

`mhcr longrun` executes 32 distinct unseen square tasks.

- stateless control reacquires the solver for every task;
- durable treatment constructs once;
- the durable runtime is closed and reopened three times;
- provider executors are explicitly rebound after restart and are never serialized into SQLite;
- all post-first persistent tasks must use fast path;
- every sample must keep `cache_hit=false`;
- solver and verification memory reuse must survive restart;
- SQLite remains schema **8**.

Resolver timing is environment-relative evidence only; v1.0 does not claim a universal constant speedup factor.

## Optional GCM extension

GCM remains optional. The core wheel has no hard `gcm_runtime` dependency.

When the accepted `gcm-reference-runtime 0.4.0` is installed, `MHCR-GCM-R1` runs eight required extension cases covering B1 hard-safe planning, B3 capacity override, provider allowlist enforcement, no unauthorized cross-substrate fallback, substrate evidence, World-commit isolation and restart semantics.

The GCM bridge consumes deterministic allocation APIs. It does not grant MHCR direct World/Foundation mutation authority.

## Heterogeneous substrate honesty

The substrate vocabulary includes CPU, GPU, FPGA, event-driven, neuromorphic, phase, quantum and specialized accelerators, but every profile separately declares `NATIVE`, `SIMULATED`, `EMULATED`, `REMOTE_SERVICE` or `HYBRID` realization.

The bundled reference substrate demo uses native CPU plus simulated event-driven and phase profiles. It does **not** certify physical phase, quantum, neuromorphic or FPGA hardware.

## Sandbox boundary

Generated Python candidates are statically inspected and run in a separate restricted subprocess before verifier-gated promotion. This is defense-in-depth reference isolation, not a claim of production hostile-code containment equivalent to a hardened microVM/seccomp deployment.

## Persistence

v1.0 deliberately keeps SQLite schema **8**. Final convergence adds release verification surfaces, not a new persistent semantic plane.

## Package layout

```text
src/mhcr/
  conformance.py       v1 core/GCM machine-verifiable profiles
  failure_matrix.py    F01-F10 executable failure matrix
  longrun.py           durable 32-task convergence benchmark
  acceptance.py        final conjunction gate
  cli.py               installed developer CLI
  data/v1_conformance/ packaged manifests
```

All v0.1–v0.9 runtime modules remain present and are exercised by the final validation program.

## Correct release claim

MHCR v1.0 is intended to support the statement:

> A validated developer-usable reference implementation of a persistent, typed, multi-provider, cost-aware, composable, acquisition-learning, sandbox-generative, optionally GCM-integrated and substrate-aware computational capability fabric.

It is not a production-readiness, physical-scheduler, universal-AI, or P/NP theorem claim.
