# MHCR v0.6.0 Validation Report

**Date:** 2026-08-30  
**Branch:** `workbench/mhcr-v0.6-acquisition-memory`

## Scope validated

- All accepted v0.1-v0.5 behavior retained.
- `AcquisitionMemoryKind`: failure, representation, solver, composition, verification.
- `AcquisitionMemoryRecord` task-contract scoping, provenance, reuse count, active/invalidation state.
- Instance answer/result/output/payload fields are explicitly rejected from acquisition-memory metadata.
- `AcquisitionMemoryStore` persists through SQLite and records append-only JSONL events.
- SQLite schema v5 and sequential v1/v2/v3/v4 -> v5 migration.
- Explicit v4 -> v5 migration preserves existing capability state and starts with an empty acquisition-memory table.
- `EventLog.replay_acquisition_memories()` reconstructs upsert, reuse-count, and invalidation state.
- `AcquisitionTrace` records resolver lookups, graph searches/expansions, constructor invocations, candidate creation, verifier invocations, and memory hits.
- Acquisition-work surrogate is deterministic and separate from provider execution cost / GCAL closed cost.
- Fast, composed, and constructed paths expose acquisition traces.
- Deterministic constructor candidate verification failure creates scoped FAILURE memory.
- A repeated unseen payload with the same contract does not reconstruct the same known-failed deterministic candidate path.
- Successful composition records reusable typed representation-path evidence.
- Successful constructor/composite promotion records SOLVER / COMPOSITION / VERIFICATION evidence.
- Reuse counters increase only on later successful task reuse.
- Solver/composition/verification memory survives SQLite restart.
- Capability revocation and composite deprecation invalidate capability-dependent acquisition memory.
- Registry trust remains canonical; acquisition memory cannot promote or authorize a capability.
- Stateless-vs-persistent benchmark uses distinct payloads and no answer cache.
- v0.2-v0.5 demo evidence remains present alongside isolated v0.6 acquisition-learning evidence.

## Automated tests

Command:

```bash
PYTHONPATH=src pytest -q
```

Result:

```text
122 passed
```

Collection evidence:

```text
122 tests collected in 0.06s
```

## Acquisition-learning benchmark

Benchmark payloads are four distinct unseen instances:

```text
2, 3, 5, 7
```

Stateless control creates a new runtime/constructor state for every payload:

```text
sources: constructed, constructed, constructed, constructed
constructor invocations: 4
acquisition work per task: 8, 8, 8, 8
stateless total acquisition work: 32
stateless post-first mean work: 8
```

Persistent treatment keeps the trusted solver and acquisition evidence:

```text
sources: constructed, resolved, resolved, resolved
constructor invocations: 1
acquisition work per task: 8, 2, 2, 2
persistent total acquisition work: 14
persistent post-first mean work: 2
solver memory hits: 3
verification memory hits: 3
all cache_hit values: false
```

Derived reference ratio:

```text
32 / 14 = 2.2857142857142856
```

This ratio is **not** presented as a wall-clock speedup or complexity theorem. It is the observed reduction under the declared deterministic acquisition-work surrogate:

```text
resolver_lookups
+ graph_expansions
+ 5 * constructor_invocations
+ verifier_invocations
```

The validated claim is narrower:

> Persistent trusted solver state and acquisition evidence reduce repeated solver-acquisition work on unseen structurally related instances inside the reference runtime, without answer-cache reuse.

## Failure-memory evidence

A deterministic generated square candidate that fails verification:

1. is constructed once;
2. remains non-trusted;
3. writes scoped FAILURE evidence;
4. is not reconstructed for a later different payload with the same semantic contract;
5. increments failure-memory reuse instead.

This behavior is intentionally limited to known failed acquisition paths. It does not infer that no solver exists.

## Representation / composition evidence

A successful typed composition records a representation path such as:

```text
text -> numbers -> number
```

The verified plan is canonicalized as a trusted composite. On a later unseen payload the composite resolves directly through the fast path and representation memory is recorded as reused.

The v0.5 composition guarantees remain intact:

```text
first graph searches: 1
first graph expansions: 4
restart graph searches: 0
component revocation -> composite deprecated
JSONL replay -> composite deprecated
```

## Solver / verification restart evidence

A trusted solver/composite and its acquisition memories are stored in SQLite. After restart:

- provider executors are explicitly rebound;
- Registry trust is restored from canonical state;
- acquisition memories are reloaded from schema v5;
- later unseen tasks reuse active solver/composition/verification evidence;
- no memory record can override current trust/availability.

## Invalidation evidence

When a capability is revoked:

```text
Registry REVOKED
-> acquisition invalidation listener
-> SOLVER / COMPOSITION / VERIFICATION memories inactive
```

When a primitive component invalidates a trusted composite, the existing v0.5 composite-deprecation mechanism also notifies acquisition memory. Representation evidence remains non-executable advisory evidence and does not itself restore the composite.

## Compile validation

```bash
python -m compileall -q src
```

Result: exit 0.

## SQLite migration validation

A manually created schema-v4 database containing an existing trusted capability was opened by the v0.6 repository.

Observed:

```text
schema_version 5
capability cap.keep
acquisition memories: empty
```

The existing capability row survived migration.

## Resolver microbenchmark continuity

The v0.6 source demo retained the existing exact-resolver microbenchmark. In this container run:

```text
registry size: 1000
iterations: 500
indexed: 255.176 ns / lookup
v0.1-style full scan: 46,384.032 ns / lookup
relative ratio: 181.7727058971063x
```

This is an environment-specific relative sample, not a cross-hardware guarantee.

## Wheel build and clean-install validation

Build command:

```bash
python -m pip wheel . --no-deps --no-build-isolation -w dist
```

Result:

```text
mhcr-0.6.0-py3-none-any.whl
```

The wheel was installed into a new virtual environment using `--no-deps`.

Installed package version:

```text
0.6.0
```

`python -m mhcr.demo` from the clean venv produced the same `acquisition_learning` result as the source-tree demo.

The environment emitted only pip cache-directory ownership warnings; these did not affect build, install, import, tests, or demo execution.

## Deliberate v0.6 limits

- Acquisition memory is structured runtime evidence, not neural/vector semantic memory.
- Failure memory does not prove solver nonexistence.
- Representation memory is advisory and non-executable.
- The acquisition-work score is a reference-runtime surrogate, not a classical asymptotic complexity measure.
- No result/answer cache is introduced.
- Constructor remains the safe deterministic template constructor from earlier versions.
- No unrestricted generated-code execution.
- No sandboxed generated constructor yet; that is v0.7 scope.
- No GCM allocator integration.
- No PCMT / heterogeneous substrate routing.

## Verdict

MHCR v0.6.0 satisfies its stated milestone: the reference runtime now carries persistent, replayable acquisition evidence and exposes explicit acquisition-work telemetry. A controlled stateless-vs-persistent experiment demonstrates lower solver-acquisition work on later unseen related inputs after a trusted solver has been acquired, while every result is recomputed and `cache_hit=False`.

The v0.6 milestone is therefore ready to close, with **v0.7 — Sandboxed Constructor** as the next planned engineering stage.
