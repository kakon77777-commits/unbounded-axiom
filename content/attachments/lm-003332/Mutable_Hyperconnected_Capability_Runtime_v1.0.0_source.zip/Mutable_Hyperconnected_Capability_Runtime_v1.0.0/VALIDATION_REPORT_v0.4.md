# MHCR v0.4.0 Validation Report

**Date:** 2026-08-30  
**Milestone:** Cost-Aware Routing  
**Branch:** `workbench/mhcr-v0.4-cost-aware-routing`

## Scope validated

- Backward-compatible `TaskPolicy` carried by `TaskContract`.
- Ordered routing preferences for latency, monetary cost, network bytes, verification work, risk, locality, and known-cost completeness.
- Hard local-only / latency / external-price / network / verification / risk ceilings.
- Per-metric evidence states: `MEASURED`, `ESTIMATED`, `DECLARED`, `FORMALLY_BOUNDED`, `UNKNOWN`.
- `UNKNOWN` metrics use `None`, never implicit zero.
- Persistent `ProviderCostProfile` / `ProviderCostCatalog`.
- SQLite schema v3 and sequential v1 -> v2 -> v3 / v2 -> v3 migration without semantic-state loss.
- v0.3 default provider ordering preserved under `TaskPolicy()`.
- Provider health remains above cost preference: `HEALTHY` outranks `DEGRADED`; unavailable/quarantined remain ineligible.
- Policy-dependent provider selection for the same semantic capability.
- Non-default routing evidence with ordered provider ids and explicit rejection reasons.
- Real attempt latency observation through an injectable monotonic clock.
- Persistent measured-latency calibration and drift evidence.
- Failed attempts remain part of existing provider-fabric accounting semantics.
- Routing cost knowledge remains separate from GCAL closed-responsibility accounting.
- `SolveResult.provider_ids` exposes the realized/attempted provider route.
- v0.1-v0.3 regression behavior remains covered.

## Automated tests

Command:

```bash
PYTHONPATH=src pytest -q
```

Result:

```text
89 passed
```

Collection check:

```bash
PYTHONPATH=src pytest --collect-only -o addopts='' -q
```

Result:

```text
89 tests collected
```

## Routing model evidence

The test suite explicitly validates:

- default-policy declared order compatibility;
- `local_only` excludes `NETWORK` while retaining process-local boundaries;
- unknown latency is rejected by a hard latency ceiling;
- unknown remote price is rejected by an external monetary ceiling;
- latency and monetary preferences can select different providers;
- known metrics rank before unknown metrics under the corresponding preference;
- health tier remains above cost preference;
- network / verification / risk ceilings independently reject non-compliant providers;
- network and verification preferences can reorder same-health providers.

## Persistence / migration evidence

SQLite v3 adds `provider_cost_profiles` while preserving existing capability, provider, and GCAL cost records.

Validated paths:

```text
fresh -> v3
v2 -> v3
v1 -> v2 -> v3
```

Routing profiles round-trip all metric values, evidence states, and measured sample counts.

## Routing decision evidence

A non-default policy emits:

```text
PROVIDER_ROUTING_DECISION
```

with:

- task id;
- capability id;
- normalized policy;
- ordered eligible provider ids;
- rejected provider ids and reasons.

Example rejection reason validated by test:

```text
latency_unknown
```

This makes policy filtering auditable rather than implicit.

## Observed-cost calibration evidence

Provider execution measures elapsed wall-clock time through an injectable monotonic clock. A deterministic test declares 5 ms, observes 12 ms, then verifies:

```text
latency evidence = MEASURED
latency value ~= 12 ms
sample_count = 1
```

The measured profile survives SQLite restart. Material deviation produces:

```text
PROVIDER_COST_DRIFTED
```

alongside:

```text
PROVIDER_COST_OBSERVED
```

Only latency is automatically observed in v0.4. Other routing metrics retain the evidence supplied by the caller/runtime integration.

## GCAL separation evidence

A remote provider can have routing knowledge for:

- latency;
- monetary cost;
- network bytes;
- verification work;
- risk;

and still produce:

```text
ACCOUNTING_INCOMPLETE
```

when GCAL lacks the independent closed-responsibility cost record.

Therefore v0.4 preserves:

```text
Routing Profile != Closed Accounting Certificate
Unknown Closed Cost != Zero
```

## Demo validation

Command:

```bash
PYTHONPATH=src python -m mhcr.demo
```

The demo retains the v0.2/v0.3 evidence and adds a separate cost-routing history.

Observed v0.4 route results:

```json
{
  "latency_provider": "provider.route.fast",
  "money_provider": "provider.route.cheap",
  "local_only_provider": "provider.route.local",
  "ceiling_provider": "provider.route.cheap",
  "latency_accounting": "accounting_incomplete",
  "restored_fast_latency_evidence": "measured",
  "restored_fast_price": 0.08,
  "restored_unknown_price_evidence": "unknown",
  "routing_decision_events": 4
}
```

The legacy demo evidence remains isolated:

- first square task constructs/promotes;
- restart square task uses fast path;
- failing subprocess provider becomes unavailable;
- local failover succeeds;
- restart preserves unavailable provider health;
- legacy provider-fabric boundary/failure counts are unchanged by the new routing demo.

## Resolver microbenchmark

The existing resolver benchmark remains a regression signal rather than a v0.4 routing claim.

One final-source demo run in this environment observed approximately:

```text
indexed/full-scan speedup ~= 172.85x
```

A clean installed-wheel demo observed approximately:

```text
indexed/full-scan speedup ~= 176.59x
```

These are environment-local samples, not cross-hardware performance guarantees.

## Compile validation

```bash
python -m compileall -q src
```

Result: exit 0.

## Wheel build / clean-install validation

Because the environment is offline, the wheel was built using the locally installed build backend without isolated dependency download:

```bash
python -m pip wheel . --no-deps --no-build-isolation -w <wheel-dir>
```

Result:

```text
mhcr-0.4.0-py3-none-any.whl built successfully
```

The wheel was installed into a clean virtual environment with `--no-deps`. Validation confirmed:

```text
installed_version = 0.4.0
TaskPolicy public API available
python -m mhcr.demo succeeds from outside the source tree
```

The installed demo reproduced the policy selections and persisted routing evidence above.

## Deliberate v0.4 limits

- No v0.5 weighted capability-graph planner.
- No global scalar utility function.
- No distributed scheduler or service discovery.
- No automatic inference of provider monetary cost, energy use, or hidden compute.
- Only latency is automatically observed/calibrated.
- No unrestricted generated-code execution.
- No GCM allocator integration.
- No PCMT / heterogeneous substrate routing.
- Routing profiles inform provider selection but do not replace GCAL.

## Verdict

MHCR v0.4 satisfies the planned Cost-Aware Routing milestone: multiple eligible providers for the same trusted capability can be filtered by hard task constraints and ranked by explicit ordered preferences while preserving health priority, unknown-cost honesty, persistent evidence, routing auditability, and independent GCAL accounting.

The next planned milestone is **v0.5 — Capability Composition Planner**.
