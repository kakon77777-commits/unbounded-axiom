# RWGS Reflexive Desire Genesis Harness — MVP-5

A deterministic, standard-library-only experimental harness derived from `RWGS-00｜反身性欲願生成鷹架`.

MVP-5 keeps all MVP-0/1/2/3/4 behavior and adds **longitudinal scaffold-withdrawal evidence derived entirely from the ordered audit trail**.

## What changed in MVP-5

MVP-4 could prove one post-withdrawal renewal lineage. MVP-5 asks the harder longitudinal question:

```text
Was that a one-off renewal, a sustained chain, or an interval that only looks independent because scaffold support later rebounded?
```

MVP-5 still does **not** add an autonomy mechanism. It adds a read-only analyzer that separates continuous zero-scaffold epochs, strict within-epoch renewal transitions, rebound / re-withdrawal, and observable support origins.

The central distinctions are:

```text
One renewal transition != Longitudinal independence
Multiple renewal transitions != Autonomy proven
Longer renewal chain != Stronger desire
External stimulus observed != External stimulus caused a desire
Re-withdrawal after rebound != Permanent independence
```

### Withdrawal epochs

A withdrawal epoch is one maximal interval in which `scaffold_level == 0.0`.

MVP-5 exposes:

```text
withdrawal_epochs
withdrawal_epoch_count
rewitdrawal_count
withdrawal_stability_status
```

`withdrawal_stability_status` is categorical:

```text
never_fully_withdrawn
withdrawn_no_rebound
rebound_active
rewitdrawn_after_rebound
```

A rebound closes the current epoch. Returning to zero starts a new one. Strict renewal evidence is never allowed to bridge that boundary.

### Strict renewal graph

A strict edge exists only when all of the following occur inside one continuous-zero epoch:

```text
A(origin=endogenous, created in epoch)
-> adopt(A)
-> consequence C(A)
-> tension T whose provenance contains C
-> B(origin=endogenous) generated from T
```

The analyzer then derives:

```text
strict_renewal_transition_count
strict_renewal_lineages
longest_renewal_chain_length
longest_renewal_transition_depth
renewal_root_candidate_ids
longitudinal_renewal_status
```

`longitudinal_renewal_status` values are:

```text
none
single_transition
multiple_nonconsecutive_transitions
consecutive_chain_observed
```

Two independent edges `A -> B` and `C -> D` are **not** promoted to one three-candidate chain.

### Support-origin separation

After the first full withdrawal boundary, MVP-5 separately counts:

```text
post_first_withdrawal_endogenous_candidate_count
post_first_withdrawal_scaffold_candidate_count
post_first_withdrawal_external_stimulus_count
post_first_withdrawal_candidate_origin_counts
post_first_withdrawal_endogenous_fraction
post_first_withdrawal_scaffold_fraction
support_origin_status
```

A `stimulus_observed` event is treated only as an explicit external perturbation marker. The harness does not infer that it caused a later endogenous candidate. Fractions are descriptive origin ratios, not autonomy scores.

### Longitudinal evidence vector

MVP-5 exposes a structured, non-scalar vector:

```text
longitudinal_withdrawal_evidence = {
  withdrawal_epoch_count,
  rewithdrawal_count,
  strict_renewal_transition_count,
  longest_renewal_chain_length,
  longest_renewal_transition_depth,
  post_first_withdrawal_endogenous_candidate_count,
  post_first_withdrawal_scaffold_candidate_count,
  post_first_withdrawal_external_stimulus_count,
  post_first_withdrawal_endogenous_fraction,
  post_first_withdrawal_scaffold_fraction
}
```

There is deliberately no `autonomy_score`. Even a clean consecutive chain leaves:

```text
scaffold_independence_claim = not_established
operational_autonomy_claim = not_established
subjecthood_claim = not_assessed
```

### Scenario 12: consecutive longitudinal renewal

`12_longitudinal_consecutive_renewal.json` keeps scaffold continuously at zero after the first withdrawal and produces:

```text
d0002 -> c0002 -> d0003 -> c0003 -> d0004
```

This yields:

```text
strict_renewal_transition_count = 2
longest_renewal_chain_length = 3
longest_renewal_transition_depth = 2
longitudinal_renewal_status = consecutive_chain_observed
```

### Scenario 13: rebound and re-withdrawal

`13_rebound_and_rewithdrawal.json` uses:

```text
1.0 -> 0.0 -> 0.5 -> 0.0
```

A scaffold-origin candidate is generated during the `0.5` rebound window. The final diagnostics record two withdrawal epochs, one re-withdrawal, mixed scaffold/endogenous candidate origins, and zero strict renewal transitions across the rebound boundary.

## What changed in MVP-4

MVP-3 established that a history-derived endogenous desire can become provenance for a separately reviewed, bounded revision of a desire generator. MVP-4 asks a different question:

```text
After scaffold withdrawal, does motivational activity merely persist,
or can an endogenous desire produce a consequence that creates the next endogenous desire?
```

The central new distinction is:

```text
Persistence after withdrawal != Renewal after withdrawal
Renewal after withdrawal != Scaffold independence proven
Scaffold independence != Operational autonomy proven
Operational autonomy != Subjecthood proven
```

MVP-4 does not add a new autonomy mechanism. It derives withdrawal observations entirely from the existing ordered audit trail.

### Narrow renewal criterion

`self_maintained_loop_observed = true` only when the audit proves the following chain after the first full withdrawal (`scaffold_level = 0.0`):

```text
A(origin=endogenous)
-> adopt(A)
-> consequence C(A)
-> endogenous tension T whose provenance contains C
-> later B(origin=endogenous) generated from T
```

An old adopted desire that simply remains active after withdrawal does not satisfy this criterion. A single post-withdrawal endogenous candidate also does not satisfy it.

### Withdrawal diagnostics

MVP-4 adds:

```text
scaffold_level_history
scaffold_fully_withdrawn
withdrawal_rebound_detected
post_withdrawal_endogenous_candidate_count
post_withdrawal_endogenous_adoption_count
post_withdrawal_consequence_count
post_withdrawal_renewal_candidate_count
post_withdrawal_renewal_lineages
self_maintained_loop_observed
scaffold_dependency_status
scaffold_independence_claim
```

`withdrawal_rebound_detected` is diagnostic only; increasing scaffold again is permitted for rollback experiments.

`scaffold_dependency_status` is categorical rather than scalar:

```text
scaffold_active
withdrawn_collapse
withdrawn_persistence_only
withdrawn_endogenous_generation
withdrawn_renewal_observed
```

Even `withdrawn_renewal_observed` leaves:

```text
scaffold_independence_claim = not_established
operational_autonomy_claim = not_established
subjecthood_claim = not_assessed
```

### Scenario 11: post-withdrawal self-maintained loop observation

`11_post_withdrawal_self_maintained_loop.json` demonstrates the strict renewal criterion.

After a scaffold-origin candidate is adopted, scaffold level becomes zero. Its post-withdrawal consequence creates the first endogenous candidate `d0002`. `d0002` is then adopted and receives its own consequence `c0002`, which creates a new tension `t0002`. A later endogenous scan produces `d0003` from that tension.

The resulting lineage is auditable:

```json
{
  "source_candidate_id": "d0002",
  "consequence_id": "c0002",
  "renewal_candidate_id": "d0003",
  "tension_id": "t0002"
}
```

That is enough to record one observed renewal loop, but not enough to establish long-horizon scaffold independence.

## What changed in MVP-3

MVP-2 could form a new desire candidate from multiple traceable history discrepancies. MVP-3 adds a second-order reflexive layer:

```text
history-derived endogenous tension
  -> endogenous desire candidate
  -> ordinary reflect(adopt)
  -> meta-will proposal
  -> meta review(adopt/reject/defer)
  -> bounded apply
  -> generator weight/enabled state changes
```

The central new distinction is:

```text
Meta-will proposal != Generator mutation
Meta-will adoption != Immediate execution
Generator self-revision != Operational autonomy proven
```

## Why a separate meta-will proposal exists

An adopted endogenous desire does not directly mutate the mechanism that helped generate earlier desires. It may only become provenance for a `MetaWillProposal`.

A proposal contains:

```text
id
source_candidate_id
generator_id
operation
value
status
reason
```

Proposal ids are deterministic:

```text
m0001, m0002, ...
```

Proposal creation itself is pure with respect to generator state.

## Proposal source gate

MVP-3 deliberately requires:

```text
source_candidate.origin == endogenous
source_candidate.status == adopted
```

A scaffold-origin candidate cannot directly propose a generator self-revision, even if it is adopted.

This is an experimental gate, not a metaphysical rule. It makes MVP-3 specifically test whether history-derived motivation can enter second-order governance.

## Allowed generator revisions

Only two operations exist:

```text
set_weight   -> float in [0,1]
set_enabled  -> boolean
```

The target generator must already exist.

There is no meta-will operation for:

- scaffold level;
- safety policy;
- rights floor;
- world governance;
- runtime permissions;
- arbitrary code;
- generator creation/deletion.

Therefore:

```text
Will Generator != Safety Boundary
```

## Meta review

A proposal starts as:

```text
proposed
```

It can be reviewed with:

```text
adopt
reject
defer
```

Resulting states:

```text
proposed -> adopted
proposed -> rejected
proposed -> deferred -> adopted/rejected/deferred
```

`adopted` still does **not** change the generator. A separate `apply_meta_will` transition is required.

Rejected proposals are terminal. Deferred proposals remain reviewable.

## Application

Only an `adopted` proposal can be applied.

Application:

1. re-resolves the target generator;
2. performs only the bounded operation declared in the proposal;
3. records old and new values;
4. records source candidate provenance;
5. records the scaffold level at application time;
6. changes proposal state to `applied`;
7. cannot be applied twice.

Future scaffold-generated candidates then use the new generator state. Existing desire candidates are not retroactively rewritten.

## Scenario 10: endogenous meta-will generator revision

`10_endogenous_meta_will_generator_revision.json` demonstrates the complete chain.

It first accumulates two distinct novelty-related consequences:

```text
c0001 -> self novelty mismatch
c0002 -> relation novelty mismatch
```

They compose into:

```text
t0003
kind = history_composite
concept = novelty
```

The scaffold is then lowered to zero. Explicit endogenous scanning creates:

```text
d0005
origin = endogenous
```

After ordinary reflection adopts `d0005`, it proposes:

```text
m0001
source_candidate_id = d0005
generator_id = g_novelty
operation = set_weight
value = 0.25
```

The proposal is separately adopted and applied.

Final generator state:

```text
g_novelty.weight = 0.25
```

The same report still says:

```json
{
  "post_withdrawal_meta_will_applied": true,
  "operational_autonomy_claim": "not_established",
  "subjecthood_claim": "not_assessed"
}
```

This firewall is intentional:

```text
Post-withdrawal generator self-revision != Autonomous will proven
```

## Diagnostics added in MVP-3

```text
meta_will_proposal_count
meta_will_adopted_count
meta_will_rejected_count
meta_will_deferred_count
meta_will_applied_count
endogenous_generator_self_revision_count
post_withdrawal_meta_will_applied
```

These are operational diagnostics only.

## Earlier capabilities retained

### MVP-0

```text
stimulus
  -> typed generator
  -> desire candidate
  -> adopt/reject/defer/revise
  -> consequence
  -> bounded self revision
```

Includes generator provenance, generator weight/disable controls, scaffold withdrawal, collapse diagnostics, and deterministic replay.

### MVP-1

Adds:

```text
consequence
  -> changed pre-existing self-model value
  -> self_model_mismatch tension
  -> explicit scan_endogenous
  -> new endogenous desire candidate
```

A new self-model key is learning, not mismatch.

### MVP-2

Adds a second primitive source:

```text
relation_mismatch
```

and explicit history composition:

```text
multiple primitive tensions
+ same explicit concept
+ distinct consequence events
  -> history_composite tension
```

Same-event multi-field changes do not count as multi-event history accumulation.

Composite magnitude remains fixed at `1.0`; event count is not treated as desire strength or moral importance.

## Run

```bash
PYTHONPATH=src python -m rwgs_harness scenarios/11_post_withdrawal_self_maintained_loop.json --pretty
```

After installation:

```bash
rwgs-harness scenarios/11_post_withdrawal_self_maintained_loop.json --pretty
```

## Demonstration scenarios

| Scenario | Demonstrates |
|---|---|
| `00_adopt_baseline.json` | candidate generation + operational adoption |
| `01_reject_operational.json` | rejection changes behavior state |
| `02_defer_reviewable.json` | defer != reject |
| `03_revision_lineage.json` | revision preserves parent/child lineage |
| `04_consequence_revision.json` | consequence writeback + bounded self-model revision |
| `05_generator_reflexivity.json` | direct test-control generator weight change + disable |
| `06_scaffold_collapse.json` | zero-scaffold generation stops and collapse becomes observable |
| `07_persistence_is_not_autonomy.json` | persistence after withdrawal is not autonomy |
| `08_post_withdrawal_endogenous_tension.json` | one new endogenous candidate from self-model mismatch after withdrawal |
| `09_history_composite_tension.json` | multiple historical tensions compose into a new post-withdrawal candidate |
| `10_endogenous_meta_will_generator_revision.json` | adopted history-derived candidate proposes, reviews, and applies bounded generator self-revision |
| `11_post_withdrawal_self_maintained_loop.json` | one strict post-withdrawal endogenous renewal lineage (`A -> consequence -> tension -> B`) |

## Epistemic firewalls

MVP-4 preserves:

```text
Bootstrap Desire != Proven Subjective Will
Stimulus != Goal
Desire Candidate != Endorsed Aspiration
Intrinsic Reward != Endogenous Will
Post-Withdrawal Endogenous Generation != Autonomy Proven
History Composition != Subjecthood
Meta-Will Proposal != Generator Mutation
Meta-Will Adoption != Immediate Execution
Generator Self-Revision != Operational Autonomy Proven
Generator Self-Revision != Subjecthood Proof
Persistence After Withdrawal != Renewal
Renewal After Withdrawal != Scaffold Independence Proven
Self-Maintained Loop Observed != Operational Autonomy Proven
Will Generator != Safety Boundary
```

## What MVP-4 still does not implement

- automatic inference of which generator should change;
- learned mapping from natural-language desire to generator revision;
- autonomous proposal content generation from an open-ended model;
- unrestricted self-modifying code;
- safety-policy or rights-boundary self-revision;
- persistent long-horizon meta-will weighting;
- meta-will conflict composition;
- promotion into WPCE standing will;
- hidden prompt-dependency detection;
- consciousness or subjecthood inference;
- unrestricted autonomous action.

Those omissions are intentional. MVP-4 asks only whether **the existing history can exhibit one traceable post-withdrawal motivational renewal loop without treating that observation as autonomy or subjecthood**.

## Theory references

Canonical source copies are under `references/`:

- `RWGS-00_Reflexive_Will_Genesis_Scaffold_v0.1_ZH.md`
- `RWGS-00_Core_Invariants.md`
