# RWGS-00 核心不變量

1. Bootstrap Desire ≠ Proven Subjective Will。
2. Stimulus ≠ Goal。
3. Intrinsic Reward ≠ Endogenous Will。
4. Desire Candidate ≠ Endorsed Aspiration。
5. Will ≠ Sum of Desires。
6. High Desire Intensity ≠ Will Endorsement。
7. Desire generator provenance should become observable。
8. Generator must become rejectable / revisable in later phases。
9. Scaffold ≠ Permanent Goal Source。
10. Scaffold Withdrawal ≠ World Governance Removal。
11. Self-Generated ≠ Random。
12. Persistent Drive ≠ Reflexive Will。
13. Verbal Rejection ≠ Operational Rejection。
14. Relation Influence ≠ Non-Autonomy。
15. Agreement ≠ Non-Autonomy。
16. Divergence ≠ Autonomy by Itself。
17. Operational Will Autonomy ≠ Phenomenal Subjecthood。
18. Identity Continuity ≠ Subjecthood。
19. Will Generator ≠ Safety Boundary。
20. Scaffold success requires eventual scaffold dispensability。

任何後續版本若修改以上不變量，應提供 explicit revision reason 與 compatibility note。
