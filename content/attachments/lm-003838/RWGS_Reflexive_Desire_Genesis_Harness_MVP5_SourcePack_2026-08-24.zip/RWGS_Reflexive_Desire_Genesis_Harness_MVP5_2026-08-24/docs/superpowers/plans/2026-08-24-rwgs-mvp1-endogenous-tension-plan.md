# RWGS MVP-1 Endogenous Tension Genesis Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic endogenous desire-candidate generation from self-model mismatch history without using scaffold stimulus or LLM inference.

**Architecture:** Consequence processing records typed endogenous tensions when an existing self-model belief changes. An explicit scan converts each unlinked tension into exactly one endogenous desire candidate. Existing reflection semantics are reused unchanged.

**Tech Stack:** Python 3.11+ standard library, dataclasses, unittest, JSON scenarios.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp1-endogenous-tension-design.md`

## Global Constraints

- No LLM or network dependency.
- No database dependency.
- No hidden background generation loop.
- Endogenous scan works at scaffold level zero.
- New self-model keys and unchanged values do not create mismatch tensions.
- Existing MVP-0 behavior remains backward compatible.
- `operational_autonomy_claim` remains `not_established`.

---

### Task 1: Record Self-Model Mismatch Tensions

**Files:**
- Modify: `src/rwgs_harness/model.py`
- Modify: `src/rwgs_harness/engine.py`
- Test: `tests/test_endogenous_tension.py`

**Interfaces:**
- Produces: `EndogenousTension` records in `Harness.endogenous_tensions`.
- Produces: deterministic consequence ids `c0001`, `c0002`, ... for provenance.

- [ ] Write failing tests proving changed existing keys create one tension, while new keys and unchanged values create none.
- [ ] Run tests and confirm RED because endogenous tension state does not exist.
- [ ] Implement minimal tension recording during `record_consequence`.
- [ ] Run full suite and confirm GREEN.

### Task 2: Scan Tensions into Endogenous Desire Candidates

**Files:**
- Modify: `src/rwgs_harness/model.py`
- Modify: `src/rwgs_harness/engine.py`
- Test: `tests/test_endogenous_tension.py`

**Interfaces:**
- Produces: `Harness.scan_endogenous() -> list[DesireCandidate]`.
- Extends: `DesireCandidate` provenance with optional `source_event_id` and `tension_id`.

- [ ] Write failing tests proving scan at scaffold level zero creates a candidate with endogenous provenance and repeated scan does not duplicate it.
- [ ] Run tests and confirm RED.
- [ ] Implement minimal scan and provenance fields.
- [ ] Run full suite and confirm GREEN.

### Task 3: Preserve Reflection Compatibility

**Files:**
- Modify: `src/rwgs_harness/engine.py` if needed
- Test: `tests/test_endogenous_tension.py`

**Interfaces:**
- Reuses: `Harness.reflect(candidate_id, operation, revision=None)`.

- [ ] Write failing test proving endogenous candidate can be adopted and revised while preserving endogenous lineage/provenance.
- [ ] Run test and confirm RED if provenance is lost.
- [ ] Make the minimal compatibility change.
- [ ] Run full suite and confirm GREEN.

### Task 4: Expose Scenario Replay and Diagnostics

**Files:**
- Modify: `src/rwgs_harness/scenario.py`
- Modify: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_endogenous_scenario.py`

**Interfaces:**
- Consumes scenario step: `{"type":"scan_endogenous"}`.
- Produces final-state key: `endogenous_tensions`.
- Produces diagnostic keys: `endogenous_tension_count`, `unresolved_endogenous_tension_count`, `endogenous_candidate_count`, `post_withdrawal_endogenous_generation`.

- [ ] Write failing replay test for post-withdrawal endogenous generation.
- [ ] Run test and confirm RED.
- [ ] Implement scenario step, state serialization, and diagnostics.
- [ ] Run full suite and confirm GREEN.

### Task 5: Demonstrations, README, and Release Validation

**Files:**
- Create: `scenarios/08_post_withdrawal_endogenous_tension.json`
- Modify: `EXPECTED_SCENARIOS.json`
- Modify: `README.md`
- Modify: `VALIDATION.md`
- Modify: `SHA256SUMS.txt`

**Interfaces:**
- Demonstrates exact spec path from scaffold withdrawal to endogenous candidate.

- [ ] Add the demonstration scenario and expected diagnostic values.
- [ ] Run all scenarios twice and verify byte-identical output.
- [ ] Run full unittest suite.
- [ ] Run compileall, clean bytecode, and verify git cleanliness.
- [ ] Update release evidence and SHA256 manifest.
