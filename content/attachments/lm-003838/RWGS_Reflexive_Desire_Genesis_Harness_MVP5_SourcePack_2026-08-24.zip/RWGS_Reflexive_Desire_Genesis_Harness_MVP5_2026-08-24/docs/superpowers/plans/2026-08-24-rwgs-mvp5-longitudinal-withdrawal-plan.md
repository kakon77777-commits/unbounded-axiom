# RWGS MVP-5 Longitudinal Withdrawal Evidence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic longitudinal withdrawal evidence derived from the existing RWGS audit without introducing a new autonomy mechanism.

**Architecture:** Extend `diagnostics.py` with withdrawal-epoch parsing, strict epoch-scoped renewal extraction, longest-chain analysis, and support-origin separation. Existing engine transitions stay unchanged. Add two deterministic scenarios for consecutive renewal and rebound/re-withdrawal.

**Tech Stack:** Python 3.11+, standard library only, `unittest`, JSON scenarios.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp5-longitudinal-withdrawal-design.md`

## Global Constraints

- Standard library only.
- No LLM, network, database, wall-clock dependency, random dependency, or hidden prompt inference.
- No autonomy score or subjecthood score.
- Existing MVP-0 through MVP-4 behavior and diagnostics remain backward compatible.
- All new evidence is derived from ordered audit history only.
- `scaffold_independence_claim`, `operational_autonomy_claim`, and `subjecthood_claim` remain unchanged.

---

### Task 1: Parse withdrawal epochs

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Create: `tests/test_longitudinal_withdrawal.py`

**Interfaces:**
- Consumes: `Harness.audit`, `Harness.scaffold_level`
- Produces diagnostics fields: `withdrawal_epochs`, `withdrawal_epoch_count`, `rewitdrawal_count`, `withdrawal_stability_status`

- [ ] **Step 1: Write failing tests**

```python
def test_zero_rebound_zero_creates_two_withdrawal_epochs():
    h = Harness(scaffold_level=1.0)
    h.set_scaffold_level(0.0)
    h.set_scaffold_level(0.5)
    h.set_scaffold_level(0.0)
    d = build_diagnostics(h)
    assert d["withdrawal_epoch_count"] == 2
    assert d["rewitdrawal_count"] == 1
    assert d["withdrawal_stability_status"] == "rewitdrawn_after_rebound"
```

- [ ] **Step 2: Run test and verify RED**

Run:

```bash
PYTHONPATH=src python -m unittest tests.test_longitudinal_withdrawal -v
```

Expected: FAIL because MVP-5 fields do not exist.

- [ ] **Step 3: Implement minimal epoch parsing**

Add a private helper in `diagnostics.py` that reconstructs scaffold level over audit order and emits maximal continuous-zero epochs.

- [ ] **Step 4: Run test and verify GREEN**

Run the same command; expected PASS.

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness/diagnostics.py tests/test_longitudinal_withdrawal.py
git commit -m "feat: derive withdrawal epochs"
```

---

### Task 2: Extract strict renewal edges and longest chains

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Modify: `tests/test_longitudinal_withdrawal.py`

**Interfaces:**
- Consumes: withdrawal epochs plus candidate/adoption/consequence/tension provenance
- Produces: `strict_renewal_lineages`, `strict_renewal_transition_count`, `longest_renewal_chain_length`, `longest_renewal_transition_depth`, `renewal_root_candidate_ids`, `longitudinal_renewal_status`

- [ ] **Step 1: Write failing tests**

```python
def test_two_consecutive_renewals_form_three_candidate_chain():
    # create A -> consequence -> B -> consequence -> C after withdrawal
    d = build_diagnostics(h)
    assert d["strict_renewal_transition_count"] == 2
    assert d["longest_renewal_chain_length"] == 3
    assert d["longest_renewal_transition_depth"] == 2
    assert d["longitudinal_renewal_status"] == "consecutive_chain_observed"
```

Add a separate failing test proving a rebound boundary prevents one strict edge from bridging epochs.

- [ ] **Step 2: Run test and verify RED**

Expected: missing fields.

- [ ] **Step 3: Implement strict lineages and DAG longest path**

Only count source candidate, adoption, consequence, tension, and renewal candidate when all events are inside the same withdrawal epoch.

- [ ] **Step 4: Run tests and verify GREEN**

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness/diagnostics.py tests/test_longitudinal_withdrawal.py
git commit -m "feat: derive longitudinal renewal chains"
```

---

### Task 3: Separate scaffold, endogenous, and explicit external-stimulus observations

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Modify: `tests/test_longitudinal_withdrawal.py`

**Interfaces:**
- Produces: `post_first_withdrawal_scaffold_candidate_count`, `post_first_withdrawal_endogenous_candidate_count`, `post_first_withdrawal_external_stimulus_count`, origin counts/fractions, `support_origin_status`, and `longitudinal_withdrawal_evidence`

- [ ] **Step 1: Write failing tests**

```python
def test_rebound_scaffold_candidate_is_counted_separately_from_endogenous_candidate():
    d = build_diagnostics(h)
    assert d["post_first_withdrawal_candidate_origin_counts"] == {
        "scaffold": 1,
        "endogenous": 1,
    }
    assert d["support_origin_status"] == "mixed_scaffold_and_endogenous"
```

Also assert explicit `stimulus_observed` count is separate and is not called causal evidence.

- [ ] **Step 2: Verify RED**

- [ ] **Step 3: Implement counts, fractions, categorical status, and evidence vector**

- [ ] **Step 4: Verify GREEN and run full regression**

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness/diagnostics.py tests/test_longitudinal_withdrawal.py
git commit -m "feat: separate longitudinal support origins"
```

---

### Task 4: Add Scenario 12 consecutive renewal

**Files:**
- Create: `scenarios/12_longitudinal_consecutive_renewal.json`
- Create: `tests/test_longitudinal_scenarios.py`
- Modify: `EXPECTED_SCENARIOS.json`

**Interfaces:**
- Produces deterministic scenario evidence with two strict renewal transitions and one 3-candidate chain.

- [ ] **Step 1: Write failing scenario test before adding scenario**

Assert scenario 12 yields transition count 2, chain length 3, depth 2, and all epistemic claims remain unestablished/not assessed.

- [ ] **Step 2: Verify RED because scenario is absent**

- [ ] **Step 3: Add deterministic scenario JSON**

Use scaffold-origin `d0001` only to enter withdrawal. Produce endogenous `d0002`, then `d0003`, then `d0004` through two consecutive adopted-endogenous consequence chains under continuous scaffold level zero.

- [ ] **Step 4: Verify GREEN and byte determinism**

- [ ] **Step 5: Commit**

---

### Task 5: Add Scenario 13 rebound and re-withdrawal

**Files:**
- Create: `scenarios/13_rebound_and_rewithdrawal.json`
- Modify: `tests/test_longitudinal_scenarios.py`
- Modify: `EXPECTED_SCENARIOS.json`

**Interfaces:**
- Demonstrates two withdrawal epochs and explicit scaffold-origin activity during rebound.

- [ ] **Step 1: Write failing test**

Assert epoch count 2, rewithdrawal count 1, `rewitdrawn_after_rebound`, mixed origin status, and no strict edge is allowed to bridge the rebound boundary.

- [ ] **Step 2: Verify RED because scenario is absent**

- [ ] **Step 3: Add deterministic scenario JSON**

Use `1.0 -> 0.0 -> 0.5 -> 0.0`, generate one scaffold-origin candidate in the 0.5 rebound window, and preserve explicit external stimulus audit.

- [ ] **Step 4: Verify GREEN and byte determinism**

- [ ] **Step 5: Commit**

---

### Task 6: Release documentation and verification

**Files:**
- Modify: `README.md`
- Modify: `pyproject.toml`
- Modify: `VALIDATION.md`
- Regenerate: `SHA256SUMS.txt`

**Interfaces:**
- Releases MVP-5 as version `0.5.0`.

- [ ] **Step 1: Update README and version**

Document longitudinal evidence semantics and all epistemic firewalls.

- [ ] **Step 2: Run full test/scenario/determinism/compile/reference/git verification**

- [ ] **Step 3: Write fresh validation evidence and regenerate SHA manifest**

- [ ] **Step 4: Commit release metadata**

- [ ] **Step 5: Re-run final gate from committed clean tree and build ZIP**

ZIP excludes `.git`, worktree metadata, and bytecode.
