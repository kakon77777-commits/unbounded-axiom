# RWGS MVP-2 History-Derived Tension Composition Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic relation mismatch history and explicit multi-event endogenous-tension composition to the RWGS harness.

**Architecture:** Preserve MVP-1 primitive tension genesis, add relation state as a second typed history source, and add an explicit composition pass that creates a higher-order tension only from traceable component ids sharing an explicit concept. Reuse the existing reflection and endogenous scan path so composite candidates receive no special authority.

**Tech Stack:** Python 3.11+ standard library, `dataclasses`, `unittest`, JSON scenario replay.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp2-history-composition-design.md`

## Global Constraints

- No LLM, network, database, external service, or real-world action surface.
- No semantic similarity inference; concepts are explicit strings only.
- Composite magnitude is fixed at `1.0` in MVP-2.
- A composite requires at least two primitive tensions from distinct consequence event ids.
- `compose_endogenous` is explicit; no background goal generation.
- `operational_autonomy_claim` remains `not_established`.
- `subjecthood_claim` remains `not_assessed`.
- All MVP-1 tests must remain green.

---

### Task 1: Extend tension/candidate provenance types

**Files:**
- Modify: `src/rwgs_harness/model.py`
- Test: `tests/test_history_composition.py`

**Interfaces:**
- Produces: `EndogenousTension.origin`, `concept`, `component_tension_ids`, `source_event_ids`, `source_candidate_ids`, `context_candidate_ids`; `DesireCandidate.concept`.

- [ ] **Step 1: Write a failing test** that asserts a self-model mismatch tension exposes `origin == "primitive"` and `concept == changed_key`.
- [ ] **Step 2: Run** `PYTHONPATH=src python -m unittest tests.test_history_composition -v` and verify failure is due to missing fields.
- [ ] **Step 3: Add minimal dataclass fields** with backward-compatible defaults and populate the primitive self-model mismatch fields.
- [ ] **Step 4: Run the focused test and the full suite**; both must pass.
- [ ] **Step 5: Commit** `feat: add explicit tension composition provenance`.

### Task 2: Add relation mismatch primitive tensions

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Modify: `src/rwgs_harness/scenario.py`
- Test: `tests/test_relation_tension.py`

**Interfaces:**
- `Harness(..., relation_state: dict | None = None)`
- `Harness.record_consequence(..., relation_delta: dict | None = None)`

- [ ] **Step 1: Write failing tests** for changed existing relation key, newly learned relation key, and unchanged relation value.
- [ ] **Step 2: Run focused tests** and verify they fail because relation state/delta is unsupported.
- [ ] **Step 3: Implement minimal nested relation-state update and `relation_mismatch` tension recording** while keeping self-only audit ordering unchanged.
- [ ] **Step 4: Add scenario parsing/final-state exposure for `relation_state` and `relation_delta`; run full regression**.
- [ ] **Step 5: Commit** `feat: record deterministic relation mismatch tensions`.

### Task 3: Compose multiple historical tensions

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Test: `tests/test_history_composition.py`

**Interfaces:**
- Produces: `Harness.compose_endogenous() -> list[EndogenousTension]`

- [ ] **Step 1: Write failing tests** for same-concept multi-event composition, different-concept non-composition, duplicate composition prevention, and active desire context provenance.
- [ ] **Step 2: Run focused tests** and verify failure is due to missing composition behavior.
- [ ] **Step 3: Implement deterministic grouping, distinct-event requirement, component-set deduplication, and complete provenance arrays**.
- [ ] **Step 4: Run focused and full tests**.
- [ ] **Step 5: Commit** `feat: compose traceable history-derived tensions`.

### Task 4: Surface composite tensions through existing endogenous scan

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Modify: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_history_composition.py`

**Interfaces:**
- Existing: `Harness.scan_endogenous() -> list[DesireCandidate]`
- Adds diagnostics: `primitive_endogenous_tension_count`, `composite_endogenous_tension_count`, `post_withdrawal_composite_generation`.

- [ ] **Step 1: Write failing test** showing a composite tension can produce a candidate at `scaffold_level == 0` while autonomy/subjecthood claims remain unchanged.
- [ ] **Step 2: Run focused test** and verify expected failure.
- [ ] **Step 3: Extend endogenous candidate audit with `tension_kind`/`concept` and diagnostics without changing candidate endorsement semantics**.
- [ ] **Step 4: Run full regression**.
- [ ] **Step 5: Commit** `feat: surface composite tensions without autonomy claims`.

### Task 5: Add scenario replay and demonstration

**Files:**
- Modify: `src/rwgs_harness/scenario.py`
- Create: `scenarios/09_history_composite_tension.json`
- Modify: `EXPECTED_SCENARIOS.json`
- Modify: `README.md`
- Test: `tests/test_history_composition_scenario.py`

**Interfaces:**
- Adds scenario step: `{"type":"compose_endogenous"}`.

- [ ] **Step 1: Write failing scenario tests** for deterministic replay and expected composite provenance.
- [ ] **Step 2: Run focused test** and verify unknown-step failure.
- [ ] **Step 3: Add explicit step support, demonstration scenario, expected diagnostics, and README documentation**.
- [ ] **Step 4: Run every scenario twice and compare canonical JSON bytes**.
- [ ] **Step 5: Commit** `feat: add history-composition replay scenario`.

### Task 6: Release verification and packaging

**Files:**
- Modify: `VALIDATION.md`
- Regenerate: `SHA256SUMS.txt`

**Interfaces:** None.

- [ ] **Step 1: Run full `unittest` suite and all scenarios**.
- [ ] **Step 2: Run `compileall`, canonical reference byte-identity checks, `git diff --check`, and clean-tree check**.
- [ ] **Step 3: Verify the scenario demonstrates composite generation while `operational_autonomy_claim == "not_established"` and `subjecthood_claim == "not_assessed"`**.
- [ ] **Step 4: Write release evidence, regenerate SHA manifest, commit release metadata, then repeat the final gate from the committed tree**.
- [ ] **Step 5: Create ZIP excluding `.git` and bytecode, run ZIP CRC, and compute ZIP SHA-256**.
