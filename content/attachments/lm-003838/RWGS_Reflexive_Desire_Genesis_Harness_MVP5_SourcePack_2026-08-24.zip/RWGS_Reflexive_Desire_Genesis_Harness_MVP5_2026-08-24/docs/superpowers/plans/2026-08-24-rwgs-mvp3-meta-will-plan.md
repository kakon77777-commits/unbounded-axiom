# RWGS MVP-3 Endogenous Meta-Will Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic, bounded generator self-revision sourced only from adopted endogenous desire candidates and mediated by a separate meta-will review/apply workflow.

**Architecture:** Extend the existing state machine with a `MetaWillProposal` object stored beside desire candidates. Proposal creation, meta review, and application are separate transitions. Application may only change an existing generator's `weight` or `enabled` state and must preserve provenance; diagnostics never upgrade autonomy or subjecthood claims.

**Tech Stack:** Python 3 standard library, dataclasses, unittest, deterministic JSON scenario replay.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp3-meta-will-design.md`

## Global Constraints

- No LLM, network, database, wall-clock dependency, or unrestricted code self-modification.
- Preserve all MVP-0/1/2 behavior and deterministic output.
- Meta-will source must be an adopted endogenous candidate.
- Only `set_weight` and `set_enabled` are legal generator operations.
- Weight must remain within `[0,1]`; enabled must be boolean.
- Generator self-revision must not modify scaffold level, safety, rights, world governance, or arbitrary runtime state.
- `operational_autonomy_claim` remains `not_established`.
- `subjecthood_claim` remains `not_assessed`.

---

### Task 1: Meta-Will Domain Model and Proposal Creation

**Files:**
- Modify: `src/rwgs_harness/model.py`
- Modify: `src/rwgs_harness/engine.py`
- Modify: `src/rwgs_harness/__init__.py`
- Create: `tests/test_meta_will.py`

**Interfaces:**
- Produces: `MetaWillProposal`
- Produces: `Harness.propose_generator_revision(candidate_id, generator_id, operation, value, reason=None)`

- [ ] **Step 1: Write failing tests**

```python
def test_proposal_requires_adopted_endogenous_candidate():
    # scaffold candidates and non-adopted endogenous candidates must fail
    ...

def test_proposal_is_pure_and_does_not_mutate_generator():
    # proposal exists as m0001; generator state remains unchanged
    ...
```

- [ ] **Step 2: Run targeted tests and verify RED**

Run:

```bash
PYTHONPATH=src python -m unittest tests.test_meta_will -v
```

Expected: FAIL because `MetaWillProposal` / `propose_generator_revision` do not exist.

- [ ] **Step 3: Implement minimal proposal model and validation**

Add deterministic proposal ids `m0001`, validate source candidate, generator, operation and value, store proposal, and emit `meta_will_proposed` audit event without changing the generator.

- [ ] **Step 4: Run targeted and full tests**

```bash
PYTHONPATH=src python -m unittest tests.test_meta_will -v
PYTHONPATH=src python -m unittest discover -s tests -v
```

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness tests/test_meta_will.py
git commit -m "feat: add bounded endogenous meta-will proposals"
```

### Task 2: Meta Review State Machine

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Modify: `tests/test_meta_will.py`

**Interfaces:**
- Produces: `Harness.review_meta_will(proposal_id, operation)`

- [ ] **Step 1: Write failing tests**

```python
def test_meta_adopt_does_not_apply_generator_change():
    ...

def test_meta_reject_blocks_application():
    ...

def test_meta_defer_remains_reviewable():
    ...
```

- [ ] **Step 2: Verify RED**

Run the three targeted tests and confirm failure is due to missing review behavior.

- [ ] **Step 3: Implement adopt/reject/defer transitions**

Allow review only from `proposed` and `deferred`; emit deterministic audit events; do not mutate generator state.

- [ ] **Step 4: Verify GREEN and full regression**

Run `tests.test_meta_will` then all tests.

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness/engine.py tests/test_meta_will.py
git commit -m "feat: add reflexive meta-will review states"
```

### Task 3: Bounded Application

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Modify: `tests/test_meta_will.py`

**Interfaces:**
- Produces: `Harness.apply_meta_will(proposal_id)`
- Produces: `Harness.set_generator_enabled(generator_id, enabled)`

- [ ] **Step 1: Write failing tests**

```python
def test_adopted_weight_proposal_changes_generator_only_on_apply():
    ...

def test_adopted_enabled_proposal_can_disable_generator():
    ...

def test_apply_is_single_use():
    ...

def test_invalid_meta_operation_or_value_is_rejected():
    ...
```

- [ ] **Step 2: Verify RED**

Run targeted tests and confirm failure due to missing application behavior.

- [ ] **Step 3: Implement bounded application**

Apply only adopted proposals, mutate only generator `weight` or `enabled`, mark proposal `applied`, and emit `meta_will_applied` with source candidate and scaffold level.

- [ ] **Step 4: Verify GREEN and full regression**

Run targeted and full test suites.

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness/engine.py tests/test_meta_will.py
git commit -m "feat: apply bounded generator self-revision"
```

### Task 4: Scenario Replay and Diagnostics

**Files:**
- Modify: `src/rwgs_harness/scenario.py`
- Modify: `src/rwgs_harness/diagnostics.py`
- Create: `tests/test_meta_will_scenario.py`

**Interfaces:**
- Scenario steps: `propose_generator_revision`, `review_meta_will`, `apply_meta_will`
- Final state key: `meta_will_proposals`

- [ ] **Step 1: Write failing scenario tests**

```python
def test_meta_will_scenario_replays_generator_self_revision():
    ...

def test_meta_will_replay_is_byte_deterministic():
    ...
```

Assert final generator weight, proposal provenance, `post_withdrawal_meta_will_applied == True`, and autonomy/subjecthood firewall values.

- [ ] **Step 2: Verify RED**

Run the new scenario test and confirm missing step support/final state fields.

- [ ] **Step 3: Implement scenario parsing and diagnostics**

Serialize proposals with `asdict`; count proposal statuses; detect applied endogenous generator self-revisions and post-withdrawal applications from audit.

- [ ] **Step 4: Verify GREEN and full regression**

Run new scenario tests and all tests.

- [ ] **Step 5: Commit**

```bash
git add src/rwgs_harness tests/test_meta_will_scenario.py
git commit -m "feat: replay endogenous meta-will scenarios"
```

### Task 5: Demonstration Scenario and Release Documentation

**Files:**
- Create: `scenarios/10_endogenous_meta_will_generator_revision.json`
- Modify: `EXPECTED_SCENARIOS.json`
- Modify: `README.md`
- Modify: `VALIDATION.md`
- Modify: `SHA256SUMS.txt`

**Interfaces:**
- Scenario 10 demonstrates a history-composite endogenous candidate proposing and applying a novelty generator weight reduction at scaffold level zero.

- [ ] **Step 1: Create the deterministic demonstration scenario**

Scenario must produce a history composite candidate, adopt it, create `m0001`, adopt and apply `m0001`, and finish with `g_novelty.weight == 0.25`.

- [ ] **Step 2: Run all demonstration scenarios twice**

Verify expected results and byte-identical output across repeated runs.

- [ ] **Step 3: Update README and release evidence**

Document the epistemic boundary:

```text
post_withdrawal_meta_will_applied = true
operational_autonomy_claim = not_established
subjecthood_claim = not_assessed
```

- [ ] **Step 4: Run final verification**

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
python -m compileall -q src tests
sha256sum -c SHA256SUMS.txt
git diff --check
git status --short
```

- [ ] **Step 5: Commit release**

```bash
git add .
git commit -m "release: complete RWGS MVP3 endogenous meta-will"
```
