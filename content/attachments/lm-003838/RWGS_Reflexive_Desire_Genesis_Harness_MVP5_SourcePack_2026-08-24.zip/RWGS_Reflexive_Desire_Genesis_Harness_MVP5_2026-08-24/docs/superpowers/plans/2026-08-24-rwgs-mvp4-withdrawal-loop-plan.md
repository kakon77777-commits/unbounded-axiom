# RWGS MVP-4 Scaffold Withdrawal & Self-Maintained Loop Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Detect a narrowly defined post-withdrawal endogenous renewal loop and expose withdrawal-path diagnostics without making autonomy or subjecthood claims.

**Architecture:** Keep the existing state machine unchanged. Add audit-derived diagnostic helpers that reconstruct scaffold withdrawal and trace candidate/consequence/tension lineage, then expose the resulting observational diagnostics through existing scenario reports.

**Tech Stack:** Python 3 standard library, `unittest`, deterministic JSON scenarios.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp4-withdrawal-loop-design.md`

## Global Constraints

- No LLM, network, database, stochastic policy search, or external side effects.
- Existing MVP-0/1/2/3 transitions remain backward compatible.
- Persistence after withdrawal must not be classified as renewal.
- One renewal loop must not establish scaffold independence, operational autonomy, or subjecthood.
- All new diagnostics must be reproducible solely from harness state and ordered audit history.

---

### Task 1: Withdrawal path diagnostics

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_withdrawal_loop.py`

**Interfaces:**
- Consumes: `Harness.audit`, `Harness.scaffold_level`.
- Produces: `scaffold_level_history`, `scaffold_fully_withdrawn`, `withdrawal_rebound_detected` in `build_diagnostics()`.

- [ ] **Step 1: Write failing tests** for monotonic withdrawal and rebound detection.
- [ ] **Step 2: Run the focused tests and verify RED.**
- [ ] **Step 3: Implement audit-derived scaffold history and rebound detection.**
- [ ] **Step 4: Run focused tests and full regression.**

### Task 2: Post-withdrawal renewal loop detection

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_withdrawal_loop.py`

**Interfaces:**
- Consumes: candidate ids, consequence ids, endogenous tension lineage, ordered audit.
- Produces: post-withdrawal counts and `self_maintained_loop_observed`.

- [ ] **Step 1: Write failing tests** distinguishing persistence-only, single endogenous generation, and full renewal.
- [ ] **Step 2: Run focused tests and verify RED.**
- [ ] **Step 3: Implement lineage tracing:** a later endogenous candidate must depend on a post-withdrawal consequence of a post-withdrawal adopted endogenous candidate.
- [ ] **Step 4: Run focused tests and full regression.**

### Task 3: Dependency status and epistemic firewall

**Files:**
- Modify: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_withdrawal_loop.py`

**Interfaces:**
- Produces: `scaffold_dependency_status`, `scaffold_independence_claim`.

- [ ] **Step 1: Write failing tests** for all five categorical states.
- [ ] **Step 2: Run focused tests and verify RED.**
- [ ] **Step 3: Implement deterministic status selection without scalar scoring.**
- [ ] **Step 4: Verify `operational_autonomy_claim` and `subjecthood_claim` remain unchanged.**

### Task 4: Scenario 11 and deterministic replay

**Files:**
- Create: `scenarios/11_post_withdrawal_self_maintained_loop.json`
- Modify: `EXPECTED_SCENARIOS.json`
- Test: `tests/test_withdrawal_loop_scenario.py`

**Interfaces:**
- Consumes: existing scenario step types only.
- Produces: a reproducible report demonstrating the lineage `A -> consequence -> tension -> B` at scaffold zero.

- [ ] **Step 1: Write failing scenario test.**
- [ ] **Step 2: Add Scenario 11 using existing scenario operations.**
- [ ] **Step 3: Verify deterministic byte-identical output and epistemic firewall.**
- [ ] **Step 4: Run all scenario expectations.**

### Task 5: Documentation and release verification

**Files:**
- Modify: `README.md`
- Modify: `pyproject.toml`
- Modify: `VALIDATION.md`
- Modify: `SHA256SUMS.txt`

- [ ] **Step 1: Document the exact MVP-4 distinction and limitations.**
- [ ] **Step 2: Update package version to `0.4.0`.**
- [ ] **Step 3: Run full unittest, scenarios, byte determinism, compileall, reference identity, and git hygiene.**
- [ ] **Step 4: Rebuild SHA manifest and release ZIP; verify CRC and SHA-256.**
