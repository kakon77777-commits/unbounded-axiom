# RWGS Reflexive Desire Genesis Harness MVP-0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic RWGS harness for typed perturbations, reflexive desire-candidate operations, consequence writeback, generator modification, and scaffold-withdrawal diagnostics.

**Architecture:** A small Python standard-library package stores explicit dataclass state and executes an ordered scenario DSL. All transitions are deterministic and auditable; there is no LLM or hidden preference inference.

**Tech Stack:** Python 3.11+, standard library, `unittest`, JSON.

**Spec:** `docs/superpowers/specs/2026-08-24-rwgs-mvp0-design.md`

## Global Constraints

- No network or LLM dependency.
- No external database.
- Candidate ids are deterministic sequential ids.
- Invalid state transitions raise explicit domain errors.
- No scalar subjectivity score.
- Scaffold collapse is a diagnostic, not a consciousness/autonomy claim.
- RWGS generator mutation cannot alter world/safety-governance state.

---

### Task 1: Core generation model

**Files:**
- Create: `src/rwgs_harness/model.py`
- Create: `src/rwgs_harness/engine.py`
- Test: `tests/test_generation.py`

**Interfaces:**
- Produces: `Harness`, `Stimulus`, `Generator`, `DesireCandidate`, `RWGSError`.

- [ ] Write a failing test proving a typed stimulus creates one deterministic candidate with complete provenance and scaled intensity.
- [ ] Run the test and verify failure is caused by missing production code.
- [ ] Implement the minimal dataclasses and `Harness.observe_stimulus()`.
- [ ] Run the test and verify pass.

### Task 2: Reflexive operations

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Test: `tests/test_reflection.py`

**Interfaces:**
- Produces: `Harness.reflect(candidate_id, operation, revision=None)`.

- [ ] Write failing tests for adopt, reject, defer, revise, and invalid transitions.
- [ ] Run and verify expected failures.
- [ ] Implement state transitions and revision lineage.
- [ ] Run all tests and verify pass.

### Task 3: Consequence and self revision

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Test: `tests/test_consequence.py`

**Interfaces:**
- Produces: `Harness.record_consequence(candidate_id, outcome, self_delta)`.

- [ ] Write failing tests proving only adopted candidates accept consequences and bounded self-model deltas are auditable.
- [ ] Run and verify expected failures.
- [ ] Implement minimal consequence history and self-model merge.
- [ ] Run all tests and verify pass.

### Task 4: Generator reflexivity and scaffold withdrawal

**Files:**
- Modify: `src/rwgs_harness/engine.py`
- Create: `src/rwgs_harness/diagnostics.py`
- Test: `tests/test_scaffold.py`

**Interfaces:**
- Produces: `set_generator_weight`, `disable_generator`, `set_scaffold_level`, `build_diagnostics`.

- [ ] Write failing tests for weight scaling, generator disable, zero-scaffold generation, and collapse diagnostic.
- [ ] Run and verify expected failures.
- [ ] Implement minimal generator/scaffold controls and vector diagnostics.
- [ ] Run all tests and verify pass.

### Task 5: Scenario JSON and CLI

**Files:**
- Create: `src/rwgs_harness/scenario.py`
- Create: `src/rwgs_harness/cli.py`
- Create: `src/rwgs_harness/__init__.py`
- Create: `src/rwgs_harness/__main__.py`
- Test: `tests/test_scenario.py`
- Test: `tests/test_cli.py`

**Interfaces:**
- Produces: `run_scenario(data: dict) -> dict`, CLI `rwgs-harness SCENARIO.json [--pretty]`.

- [ ] Write failing tests for scenario replay, malformed input, deterministic repeated output, and CLI success/error exits.
- [ ] Run and verify expected failures.
- [ ] Implement strict parser/runner and JSON CLI.
- [ ] Run all tests and verify pass.

### Task 6: Demonstration scenarios and release verification

**Files:**
- Create: `scenarios/00_adopt_baseline.json`
- Create: `scenarios/01_reject_operational.json`
- Create: `scenarios/02_defer_reviewable.json`
- Create: `scenarios/03_revision_lineage.json`
- Create: `scenarios/04_consequence_revision.json`
- Create: `scenarios/05_generator_disable.json`
- Create: `scenarios/06_scaffold_collapse.json`
- Create: `README.md`
- Create: `VALIDATION.md`

**Interfaces:**
- Demonstrates all MVP-0 acceptance criteria with human-readable examples.

- [ ] Run the full `unittest` suite.
- [ ] Run every demonstration scenario twice and compare canonical JSON outputs byte-for-byte.
- [ ] Run `python -m compileall src`.
- [ ] Run `git diff --check` and verify clean status after removing bytecode caches.
- [ ] Record SHA-256 manifest and package a source ZIP only after the fresh verification gate passes.
