# RWGS MVP-3 Endogenous Meta-Will / Generator Self-Revision Design

## Status

Approved continuation of RWGS MVP-2. This document defines a bounded deterministic experiment. It does not claim autonomous will, consciousness, personhood, or unrestricted self-modification.

## Goal

Add a second-order reflexive layer in which an already-adopted **endogenous** desire candidate may become the provenance source for a proposal to revise an existing desire generator. The proposal must be explicitly reviewed before it can be applied.

The executable chain is:

$$
\boxed{
\text{Endogenous Desire Candidate}
\rightarrow
\text{Adopt}
\rightarrow
\text{Meta-Will Proposal}
\rightarrow
\text{Meta Review}
\rightarrow
\text{Bounded Generator Revision}
}
$$

## Epistemic firewall

MVP-3 must always preserve:

$$
\boxed{
\text{Generator Self-Revision}
\neq
\text{Operational Autonomy Proven}
}
$$

and:

$$
\boxed{
\text{Meta-Will Proposal}
\neq
\text{Subjecthood Evidence by Itself}
}
$$

Diagnostics continue to report:

- `operational_autonomy_claim = not_established`
- `subjecthood_claim = not_assessed`

## Non-goals

MVP-3 does not:

- infer which generator *should* be changed;
- infer target weights from natural language;
- let a candidate modify safety, rights, world governance, scaffold level, runtime permissions, or arbitrary code;
- create or delete generators;
- allow unrestricted self-modifying code;
- promote meta-will to WPCE standing will automatically;
- claim that self-revision implies consciousness or freedom of will.

## Existing state retained

All MVP-0/1/2 behavior remains unchanged:

- typed scaffold stimulus;
- desire candidate reflection;
- consequence and self-model revision;
- primitive endogenous tensions;
- relation mismatch tensions;
- history-derived composite tensions;
- scaffold withdrawal diagnostics;
- deterministic scenario replay.

## New domain object: MetaWillProposal

A proposal contains:

- `id`: deterministic `m0001`, `m0002`, ...;
- `source_candidate_id`: adopted endogenous candidate providing provenance;
- `generator_id`: existing generator being targeted;
- `operation`: `set_weight` or `set_enabled`;
- `value`: validated float in `[0,1]` for weight or boolean for enabled;
- `status`: `proposed`, `deferred`, `adopted`, `rejected`, or `applied`;
- `reason`: optional explicit audit note.

The proposal itself does not mutate the generator.

## Proposal preconditions

`propose_generator_revision(...)` succeeds only when:

1. the source candidate exists;
2. `source_candidate.origin == "endogenous"`;
3. `source_candidate.status == "adopted"`;
4. the target generator exists;
5. operation is exactly `set_weight` or `set_enabled`;
6. the value has the correct bounded type.

A scaffold-origin candidate cannot directly become a generator self-revision source in MVP-3. This makes the experiment specifically about endogenous, history-derived motivation entering second-order governance.

## Meta review

`review_meta_will(proposal_id, operation)` accepts:

- `adopt`
- `reject`
- `defer`

Review is allowed from `proposed` or `deferred` only.

- `adopt` changes proposal status to `adopted` but does not yet mutate the generator.
- `reject` makes it permanently non-applicable.
- `defer` keeps it reviewable.

This preserves:

$$
\boxed{
\text{Endorse Meta-Will}
\neq
\text{Immediately Execute Meta-Will}
}
$$

## Application

`apply_meta_will(proposal_id)` succeeds only from `adopted`.

Application:

- validates the generator still exists;
- applies the bounded change;
- sets status to `applied`;
- emits one provenance-rich audit event;
- cannot be applied twice.

For `set_weight`, future scaffold-generated candidate intensity changes through the existing generator-weight mechanism.

For `set_enabled`, future scaffold generation is enabled/disabled through the existing generator state.

No existing desire candidate is retroactively rewritten.

## Direct generator controls

Legacy direct test controls remain for backward compatibility:

- `set_generator_weight`
- `disable_generator`

MVP-3 adds `set_generator_enabled(generator_id, enabled)` as a symmetric bounded primitive.

Audit events distinguish direct controls from meta-will application through explicit provenance fields. The presence of direct test controls is not treated as endogenous self-revision.

## Scenario steps

Add:

```json
{
  "type": "propose_generator_revision",
  "candidate_id": "d0005",
  "generator_id": "g_novelty",
  "operation": "set_weight",
  "value": 0.25,
  "reason": "history-derived novelty tension should have less influence"
}
```

```json
{
  "type": "review_meta_will",
  "proposal_id": "m0001",
  "operation": "adopt"
}
```

```json
{
  "type": "apply_meta_will",
  "proposal_id": "m0001"
}
```

The final scenario state exposes `meta_will_proposals`.

## Diagnostics

Add:

- `meta_will_proposal_count`
- `meta_will_adopted_count`
- `meta_will_rejected_count`
- `meta_will_deferred_count`
- `meta_will_applied_count`
- `endogenous_generator_self_revision_count`
- `post_withdrawal_meta_will_applied`

`post_withdrawal_meta_will_applied` means only that application occurred while `scaffold_level == 0.0`; it does not establish scaffold independence or autonomy.

## Demonstration scenario

Scenario 10 should extend the history-composition pattern:

1. generate/adopt a scaffold desire about novelty;
2. produce two distinct history consequences under concept `novelty`;
3. compose a `history_composite` tension;
4. set scaffold level to zero;
5. scan and adopt the resulting endogenous candidate;
6. use it to propose reducing `g_novelty.weight` from `1.0` to `0.25`;
7. adopt the meta-will proposal;
8. apply it;
9. verify generator weight is now `0.25`;
10. retain `operational_autonomy_claim = not_established` and `subjecthood_claim = not_assessed`.

## Required invariants

1. `MetaWillProposal != GeneratorMutation`.
2. `MetaWillAdoption != ImmediateExecution`.
3. `OnlyAdoptedEndogenousCandidate -> MayProposeGeneratorRevision` in MVP-3.
4. `RejectedMetaWill -> CannotApply`.
5. `DeferredMetaWill -> RemainsReviewable`.
6. `AppliedMetaWill -> BoundedGeneratorChangeOnly`.
7. `GeneratorSelfRevision != SafetyBoundaryRevision`.
8. `GeneratorSelfRevision != OperationalAutonomyProven`.
9. `GeneratorSelfRevision != SubjecthoodProof`.
10. All proposal and application provenance must be auditable and deterministic.
