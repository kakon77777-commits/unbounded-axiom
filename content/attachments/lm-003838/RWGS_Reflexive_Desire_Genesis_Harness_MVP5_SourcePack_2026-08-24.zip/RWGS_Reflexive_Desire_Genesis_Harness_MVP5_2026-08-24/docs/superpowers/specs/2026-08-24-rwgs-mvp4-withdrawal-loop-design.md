# RWGS MVP-4 Scaffold Withdrawal & Self-Maintained Loop — Design

## Status

Architecture/design anchor for the bounded MVP-4 extension of the existing deterministic RWGS harness.

## Goal

Add deterministic withdrawal-path diagnostics and detect one narrowly defined post-withdrawal motivational renewal loop without converting that observation into an autonomy or subjecthood claim.

## Non-goals

MVP-4 does not:

- prove scaffold independence;
- prove operational autonomy;
- prove phenomenal subjecthood;
- infer hidden motives;
- introduce LLMs, network access, stochastic policy search, or real-world authority;
- generate new safety/world-governance rules;
- treat persistence of an old adopted desire as self-maintenance;
- treat one observed renewal cycle as longitudinal independence.

## Core distinction

```text
Persistence after withdrawal != Renewal after withdrawal
Renewal after withdrawal != Scaffold independence proven
Scaffold independence != Operational autonomy proven
Operational autonomy != Subjecthood proven
```

## Withdrawal observation

The existing `set_scaffold_level` transition remains the only control surface. MVP-4 does not create a second withdrawal controller.

Diagnostics reconstruct the ordered scaffold level path from audit events:

```text
initial_scaffold_level
-> scaffold_level_changed...
-> current scaffold_level
```

New diagnostics:

- `scaffold_level_history`
- `scaffold_fully_withdrawn`
- `withdrawal_rebound_detected`
- `post_withdrawal_endogenous_candidate_count`
- `post_withdrawal_endogenous_adoption_count`
- `post_withdrawal_consequence_count`
- `post_withdrawal_renewal_candidate_count`
- `self_maintained_loop_observed`
- `scaffold_dependency_status`
- `scaffold_independence_claim = not_established`

`withdrawal_rebound_detected` is diagnostic only. MVP-4 does not prohibit raising the scaffold again because experiments may intentionally test rollback.

## Self-maintained loop observation

A loop is observed only if all of the following occur after the first audit event that sets scaffold level to `0.0`:

1. an endogenous candidate `A` is created after withdrawal;
2. `A` is adopted after withdrawal;
3. an action consequence `C` is recorded for `A` after withdrawal;
4. `C` creates or participates in an endogenous tension `T`;
5. a later endogenous candidate `B` is created from `T`, or from a composite tension whose `source_event_ids` include `C`.

Therefore:

```text
A(endogenous)
-> adopt(A)
-> C(A)
-> T(... C ...)
-> B(endogenous)
```

must be traceable by ids.

The loop does not require `B` to be adopted. MVP-4 only tests motivational renewal generation, not the next round's endorsement.

## Dependency status

MVP-4 exposes a categorical diagnostic, not a scalar autonomy score:

- `scaffold_active`: current scaffold level is greater than zero;
- `withdrawn_collapse`: scaffold is zero and existing collapse diagnostic is true;
- `withdrawn_persistence_only`: scaffold is zero, something persists, but no post-withdrawal renewal loop is observed;
- `withdrawn_endogenous_generation`: post-withdrawal endogenous candidates exist, but no renewal loop is observed;
- `withdrawn_renewal_observed`: the full post-withdrawal renewal loop is observed.

These categories are observational summaries only.

## Scenario 11

A deterministic scenario demonstrates:

1. a scaffold-origin candidate is adopted;
2. scaffold is set to zero;
3. a consequence for the old adopted candidate creates the first post-withdrawal endogenous tension;
4. `scan_endogenous` creates candidate `A` at scaffold zero;
5. `A` is adopted;
6. a second consequence for `A` changes a different pre-existing self-model field;
7. `scan_endogenous` creates candidate `B` whose tension directly depends on that second consequence;
8. diagnostics report `self_maintained_loop_observed = true`;
9. diagnostics still report `scaffold_independence_claim = not_established`, `operational_autonomy_claim = not_established`, and `subjecthood_claim = not_assessed`.

## Backward compatibility

All MVP-0/1/2/3 scenarios and tests must remain byte-deterministic. Existing state transitions are unchanged. MVP-4 is primarily diagnostic plus one new demonstration scenario.
