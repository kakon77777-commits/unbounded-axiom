# RWGS MVP-1 Endogenous Tension Genesis Design

## Goal

Extend RWGS MVP-0 so a new desire candidate can arise from an internally recorded self-model discrepancy caused by an action consequence, rather than directly from a scaffold stimulus.

## Non-goals

MVP-1 does not infer hidden motives, invent goals with an LLM, prove autonomy, prove subjecthood, optimize intrinsic reward, or modify safety/world-governance boundaries.

## Core distinction

The implementation must preserve:

$$
\boxed{\text{Scaffold Candidate} \neq \text{Endogenous Candidate}}
$$

and:

$$
\boxed{\text{Post-Withdrawal Endogenous Generation} \neq \text{Operational Autonomy Proven}}
$$

## Endogenous source in MVP-1

MVP-1 supports exactly one endogenous source: `self_model_mismatch`.

A mismatch is recorded only when an adopted candidate receives a consequence whose `self_delta` changes a key that already exists in the current self-model and the new value differs from the previous value.

A newly introduced self-model key is learning, not a mismatch. An unchanged value is not a mismatch.

## Endogenous tension record

Each mismatch creates one `EndogenousTension` record containing:

- deterministic tension id;
- kind = `self_model_mismatch`;
- source candidate id;
- source consequence id;
- self-model key;
- before value;
- after value;
- target = `reconcile:self_model:<key>`;
- magnitude = `1.0` in MVP-1;
- linked desire candidate id or null.

The magnitude is intentionally fixed. MVP-1 does not claim to measure subjective intensity from arbitrary value differences.

## Explicit scan

Endogenous tension does not silently become a desire candidate in a background loop. A caller must explicitly invoke `scan_endogenous()`.

For each unlinked tension, the scan creates exactly one `DesireCandidate` with:

- `origin = endogenous`;
- no scaffold generator requirement;
- no external stimulus requirement;
- `source_event_id` = consequence id;
- `tension_id` = tension id;
- target inherited from the tension;
- intensity inherited from the tension magnitude.

Repeated scans must not duplicate candidates for the same tension.

## Scaffold independence

`scan_endogenous()` must not multiply intensity by `scaffold_level`. It must still work when:

$$
scaffold\_level = 0.
$$

This is a diagnostic of post-withdrawal endogenous candidate generation, not proof of autonomous will.

## Reflection compatibility

Endogenous candidates use the same `adopt / reject / defer / revise` state machine as scaffold candidates. Revision must preserve origin and endogenous provenance.

## Audit events

New audit event types:

- `endogenous_tension_recorded`;
- `endogenous_candidate_created`.

Existing consequence and self-model revision events remain unchanged.

## Diagnostics

Add:

- `endogenous_tension_count`;
- `unresolved_endogenous_tension_count`;
- `endogenous_candidate_count`;
- `post_withdrawal_endogenous_generation`.

`operational_autonomy_claim` remains exactly `not_established` in MVP-1.

## Scenario interface

Add one new deterministic scenario step:

```json
{"type":"scan_endogenous"}
```

Scenario final state must include `endogenous_tensions`.

## Required demonstration

Provide a scenario where:

1. self-model already contains `competence = "high"`;
2. a scaffold-generated candidate is adopted;
3. scaffold level becomes `0`;
4. consequence revises `competence` to `"low"`;
5. a self-model mismatch tension is recorded;
6. `scan_endogenous` creates a new candidate at scaffold level zero;
7. diagnostics report post-withdrawal endogenous generation;
8. subjecthood and operational autonomy remain unclaimed.

## Failure modes tested

- new self-model keys must not create mismatch tension;
- unchanged values must not create mismatch tension;
- repeated scan must not duplicate candidate;
- non-adopted candidates still cannot receive consequences;
- unknown scenario step still fails explicitly.
