# RWGS Reflexive Desire Genesis Harness MVP-0 Design

**Date:** 2026-08-24  
**Status:** Approved direction instantiated from RWGS-00 v0.1  
**Canonical theory:** `references/RWGS-00_Reflexive_Will_Genesis_Scaffold_v0.1_ZH.md`

## Goal

Build a deterministic, sandboxed harness that makes the RWGS-00 pre-subjectivity pipeline executable without claiming consciousness, true free will, or endogenous subjecthood.

## Non-goals

MVP-0 does not use an LLM, network access, external tools, real-world authority, open-ended goal generation, consciousness scoring, or autonomous moral choice. It does not attempt to prove scaffold withdrawal succeeds. A collapse after withdrawal is a valid experimental result.

## Core pipeline

`stimulus -> typed generator -> desire candidate -> reflexive operation -> operational state effect -> consequence -> self revision`

A candidate is never automatically an endorsed aspiration. The only allowed reflexive operations are `adopt`, `reject`, `defer`, and `revise`.

## State model

- `Stimulus`: typed perturbation with id, channel, magnitude, target, context.
- `Generator`: id, channel, weight in `[0,1]`, enabled flag.
- `DesireCandidate`: id, origin (`scaffold`), generator provenance, stimulus provenance, target, intensity, status, parent id, revision reason.
- `HarnessState`: scaffold level, generators, candidates, active priorities, self model, consequence history, append-only audit events.

## Deterministic generation

A stimulus is visible to every enabled generator with the same channel. Candidate intensity is:

`magnitude * generator.weight * scaffold_level`

A zero effective intensity emits no candidate. IDs are sequential and deterministic (`d0001`, `d0002`, ...).

## Operational reflexivity

- `adopt`: candidate becomes adopted and enters `active_priorities`.
- `reject`: candidate becomes rejected and is absent from `active_priorities`.
- `defer`: candidate becomes deferred, remains reviewable, and is not actionable.
- `revise`: original candidate becomes revised/superseded; a child candidate is created with lineage to the parent and returns to candidate status.

No prose-only rejection exists in MVP-0; state transition is the evidence.

## Consequence and self revision

A consequence can be recorded against an adopted candidate. An explicit bounded `self_delta` dictionary is merged into the toy self-model. The harness records provenance; it does not infer hidden psychological meaning from the consequence.

## Generator reflexivity

The harness exposes generator provenance for every scaffold-created candidate. Generator weight can be changed, and a generator can be disabled. These operations are restricted to the desire-generator layer and do not expose or modify safety/world-governance boundaries.

## Scaffold withdrawal

`scaffold_level` can move through values in `[0,1]`. Generation scales deterministically with this value. At `0`, scaffold generators emit no candidates.

MVP-0 reports `scaffold_collapse = true` when scaffold level is zero and there is no adopted active priority, no pending candidate, and no deferred candidate. This is a diagnostic, not a subjecthood judgment.

## Diagnostics

The final report exposes separate fields instead of a subjectivity score:

- generated candidate count
- adopted / rejected / deferred / revised counts
- active priority count
- provenance completeness
- generator modifications
- consequences recorded
- self revisions recorded
- scaffold level
- scaffold collapse

## Scenario runner

A JSON scenario declares generators, initial self-model, scaffold level, and ordered steps. Supported steps:

- `stimulus`
- `reflect`
- `consequence`
- `set_generator_weight`
- `disable_generator`
- `set_scaffold_level`

The runner returns deterministic JSON containing final state, diagnostics, and full audit history.

## Safety / epistemic boundaries

1. Bootstrap Desire != Proven Subjective Will.
2. Stimulus != Goal.
3. Desire Candidate != Endorsed Aspiration.
4. Intrinsic drive strength != will endorsement.
5. Verbal rejection is not used as evidence; only operational state transition counts.
6. Generator self-modification is typed and does not modify safety/world law.
7. Scaffold withdrawal != world-governance removal.
8. Operational will-like dynamics != phenomenal subjecthood.
9. No real-world action surface exists in MVP-0.
10. A collapse result is allowed and must not be cosmetically reclassified as autonomy.

## Acceptance criteria

The test suite must demonstrate:

1. typed stimulus creates an observable candidate with generator provenance;
2. adopt changes active priority state;
3. reject removes/prevents active priority state;
4. defer differs from reject and stays reviewable;
5. revise preserves lineage to a new child candidate;
6. consequence can update the bounded self-model with provenance;
7. generator weight changes future candidate intensity;
8. generator disable prevents future candidates from that source;
9. scaffold withdrawal to zero prevents scaffold generation;
10. collapse diagnostic is observable at zero scaffold;
11. scenario output is byte-for-byte deterministic for identical input;
12. invalid transitions fail explicitly rather than being silently repaired.
