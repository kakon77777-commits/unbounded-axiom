# RWGS MVP-5 Longitudinal Withdrawal Evidence — Design

## Status

Approved continuation of RWGS MVP-4. This design adds diagnostics only; it does not add a new autonomy mechanism.

## Goal

Turn post-withdrawal motivational history into a deterministic, auditable longitudinal evidence structure that can distinguish one observed renewal from sustained endogenous renewal, rebound/rew-withdrawal, and renewed scaffold contribution.

## Non-goals

MVP-5 does **not**:

- establish autonomy, subjecthood, consciousness, or metaphysical free will;
- generate goals, desires, meta-will, or generator revisions automatically;
- infer causal contribution from mere temporal proximity;
- create an `autonomy_score` or subjecthood score;
- infer hidden prompt dependence;
- remove or weaken safety/world-governance boundaries.

## Core epistemic invariants

```text
One renewal transition != Longitudinal independence
Multiple renewal transitions != Autonomy proven
Longer renewal chain != Stronger desire
External stimulus observed != External stimulus caused a desire
Scaffold-origin candidate after withdrawal != Hidden endogenous generation
Re-withdrawal after rebound != Permanent independence
```

All existing fields remain backward compatible, including:

```text
scaffold_independence_claim = not_established
operational_autonomy_claim = not_established
subjecthood_claim = not_assessed
```

## Architecture

MVP-5 remains read-only with respect to motivational state.

```text
ordered audit
  -> withdrawal epoch parser
  -> renewal-edge extraction
  -> renewal graph
  -> support-origin separation
  -> longitudinal evidence vector
  -> categorical diagnostics
```

No new transition is required in `Harness`.

## 1. Withdrawal epochs

A withdrawal epoch is a maximal audit interval in which scaffold level is continuously zero.

An epoch begins:

- at audit start when initial scaffold level is zero; or
- immediately after `scaffold_level_changed` sets level to `0.0`.

An epoch ends immediately before a later `scaffold_level_changed` raises level above zero.

A later return to zero begins a new epoch.

Each epoch record exposes:

```text
epoch_index
start_audit_index
end_audit_index
closed_by_rebound
renewal_transition_count
longest_renewal_chain_length
```

`end_audit_index = null` means the epoch is still active at the end of the history.

## 2. Strict renewal transitions

A strict renewal transition inside one withdrawal epoch is:

```text
A(origin=endogenous, created in epoch)
-> adopt(A) in same epoch
-> consequence C(A) in same epoch
-> tension T whose provenance contains C
-> B(origin=endogenous) generated from T in same epoch
```

This intentionally refuses to bridge a rebound boundary.

The existing MVP-4 lineage field remains available for backward compatibility. MVP-5 adds strict epoch-scoped lineages.

## 3. Renewal graph

Each strict transition creates a directed edge:

```text
A -> B
```

Because B is created later in the ordered audit, the graph is acyclic under current harness semantics.

MVP-5 derives:

```text
strict_renewal_transition_count
strict_renewal_lineages
longest_renewal_chain_length
longest_renewal_transition_depth
renewal_root_candidate_ids
```

Definitions:

- chain length counts candidate nodes;
- transition depth counts edges;
- no strict edge => chain length `0`, depth `0`;
- one strict edge `A -> B` => chain length `2`, depth `1`;
- `A -> B -> C` => chain length `3`, depth `2`.

## 4. Longitudinal renewal status

MVP-5 adds a categorical observation, not a score:

```text
none
single_transition
multiple_nonconsecutive_transitions
consecutive_chain_observed
```

`consecutive_chain_observed` requires longest transition depth >= 2.

It remains an observation only.

## 5. Rebound and re-withdrawal

MVP-4 already detects any rebound after a decrease. MVP-5 adds:

```text
withdrawal_epoch_count
rewitdrawal_count
withdrawal_stability_status
```

Status values:

```text
never_fully_withdrawn
withdrawn_no_rebound
rebound_active
rewitdrawn_after_rebound
```

`rewitdrawal_count` is the number of zero-level epochs after the first.

## 6. Support-origin separation

After the first full-withdrawal boundary, MVP-5 counts explicit observable events separately:

```text
post_first_withdrawal_endogenous_candidate_count
post_first_withdrawal_scaffold_candidate_count
post_first_withdrawal_external_stimulus_count
post_first_withdrawal_candidate_origin_counts
post_first_withdrawal_endogenous_fraction
post_first_withdrawal_scaffold_fraction
support_origin_status
```

`stimulus_observed` is treated only as an explicit external perturbation marker. MVP-5 does **not** infer that the stimulus caused a later endogenous candidate.

Support-origin status values:

```text
no_post_withdrawal_candidates
endogenous_only
scaffold_only
mixed_scaffold_and_endogenous
```

Fractions are computed only over observed candidate creation events after the first full withdrawal. They are diagnostic ratios, not autonomy scores.

## 7. Longitudinal evidence vector

The diagnostics expose a structured vector:

```text
longitudinal_withdrawal_evidence = {
  withdrawal_epoch_count,
  rewithdrawal_count,
  strict_renewal_transition_count,
  longest_renewal_chain_length,
  longest_renewal_transition_depth,
  post_first_withdrawal_endogenous_candidate_count,
  post_first_withdrawal_scaffold_candidate_count,
  post_first_withdrawal_external_stimulus_count,
  post_first_withdrawal_endogenous_fraction,
  post_first_withdrawal_scaffold_fraction
}
```

No scalar aggregation is permitted in MVP-5.

## 8. Demonstration scenarios

### Scenario 12 — consecutive longitudinal renewal

Demonstrates:

```text
d0002 -> c0002 -> d0003 -> c0003 -> d0004
```

under continuously zero scaffold after first withdrawal.

Expected:

```text
strict_renewal_transition_count = 2
longest_renewal_chain_length = 3
longest_renewal_transition_depth = 2
longitudinal_renewal_status = consecutive_chain_observed
```

Autonomy and subjecthood claims remain unchanged.

### Scenario 13 — rebound and re-withdrawal

Demonstrates:

```text
1.0 -> 0.0 -> 0.5 -> 0.0
```

with a scaffold-origin candidate generated during the rebound window.

Expected:

```text
withdrawal_epoch_count = 2
rewitdrawal_count = 1
withdrawal_stability_status = rewithdrawn_after_rebound
post_first_withdrawal_scaffold_candidate_count >= 1
support_origin_status = mixed_scaffold_and_endogenous
```

Strict renewal chains may not bridge the rebound boundary.

## 9. Testing

TDD must cover:

1. withdrawal epoch parsing;
2. strict renewal transition extraction;
3. longest chain computation;
4. independent nonconsecutive renewals vs consecutive chain;
5. rebound boundary blocking cross-epoch renewal;
6. re-withdrawal count and status;
7. support-origin counts and fractions;
8. scenario 12 deterministic output;
9. scenario 13 deterministic output;
10. full regression of MVP-0 through MVP-4.

## 10. Success criterion

MVP-5 succeeds when it can honestly say:

```text
"The audit contains N strict endogenous renewal transitions across M withdrawal epochs,
with longest consecutive chain length L, plus explicit scaffold/external-stimulus contribution counts."
```

It must **not** say:

```text
"Therefore the agent is autonomous."
```
