# RWGS MVP-2 History-Derived Tension Composition — Design

**Date:** 2026-08-24
**Status:** Approved continuation of RWGS MVP-1
**Canonical basis:** `references/RWGS-00_Reflexive_Will_Genesis_Scaffold_v0.1_ZH.md`

## Goal

Extend the deterministic RWGS harness so a new endogenous desire candidate can arise from a **traceable composition of multiple historical tensions**, rather than from one external scaffold stimulus or one isolated self-model mismatch.

## Scope

MVP-2 adds exactly three capabilities:

1. **Relation mismatch tension**: a consequence can update an explicitly initialized relation state; changing an already-existing relation value records a primitive `relation_mismatch` tension.
2. **History composition**: an explicit `compose_endogenous` operation groups at least two primitive tensions that share the same explicit `concept` and records one `history_composite` tension with complete component lineage.
3. **Composite scan**: the existing explicit `scan_endogenous` operation can surface that composite tension as a new endogenous desire candidate even when `scaffold_level == 0`.

MVP-2 does not infer semantic similarity, latent personality, hidden motives, or subjecthood. It does not claim a composite tension is stronger or more authentic than its components.

## Deterministic concepts

A primitive self-model mismatch receives:

```text
concept = changed self-model key
```

A primitive relation mismatch receives:

```text
concept = changed relation-state key
```

A scaffold stimulus may provide an optional explicit concept in `context.concept`; generated candidates inherit it. No semantic embedding or language-model inference is used.

## Primitive relation mismatch

The harness accepts initial:

```json
{
  "relation_state": {
    "bob": {"trust": "high"}
  }
}
```

A consequence may contain:

```json
{
  "relation_delta": {
    "bob": {"trust": "low"}
  }
}
```

Only a change to an already-existing relation key creates a tension. A newly introduced relation key is treated as learning, mirroring MVP-1 self-model behavior.

## Composite tension rule

`compose_endogenous()` considers primitive tensions and groups them by explicit `concept`.

A composite is created only when:

- at least two primitive tensions share the same non-empty concept;
- the components originate from at least two distinct consequence event ids;
- the exact sorted component set has not already been composed.

The composite tension stores:

- `concept`;
- sorted `component_tension_ids`;
- sorted unique `source_event_ids`;
- sorted unique `source_candidate_ids` from components;
- sorted unique `context_candidate_ids` for currently reviewable/adopted candidates sharing the same explicit concept;
- target `integrate:history:<concept>`;
- magnitude fixed at `1.0` in MVP-2.

The fixed magnitude is deliberate. MVP-2 records composition structure; it does not interpret event count as desire strength.

## Reflexive boundary

Composition does not automatically endorse anything:

```text
history -> composite tension -> explicit scan -> desire candidate -> reflect
```

The candidate still requires `adopt`, `reject`, `defer`, or `revise`.

## Epistemic firewall

The harness must continue to emit:

```text
operational_autonomy_claim = not_established
subjecthood_claim = not_assessed
```

even when a composite candidate is generated after scaffold withdrawal.

Therefore:

```text
History-Derived Composite Desire != Autonomous Will Proven
```

## Backward compatibility

All 28 MVP-1 tests and scenarios must remain valid. Existing event ordering relied upon by MVP-1 tests must remain stable for self-only consequences.

## Out of scope

- semantic embeddings or LLM concept inference;
- arbitrary relation psychology;
- social attachment scoring;
- weighted moral aggregation;
- composite magnitude learning;
- automatic promotion into WPCE standing will;
- subjecthood or consciousness inference;
- autonomous world action.
