import json
import unittest

from rwgs_harness import run_scenario


def meta_will_scenario():
    return {
        "name": "endogenous-meta-will-generator-revision",
        "scaffold_level": 1.0,
        "self_model": {"novelty": "balanced"},
        "relation_state": {"environment": {"novelty": "helpful"}},
        "generators": [
            {"id": "g_novelty", "channel": "novelty", "weight": 1.0, "enabled": True}
        ],
        "steps": [
            {
                "type": "stimulus",
                "id": "s1",
                "channel": "novelty",
                "magnitude": 1.0,
                "target": "explore:new-domain",
                "context": {"concept": "novelty"},
            },
            {"type": "reflect", "candidate_id": "d0001", "operation": "adopt"},
            {
                "type": "consequence",
                "candidate_id": "d0001",
                "outcome": "overfocus",
                "self_delta": {"novelty": "overfocused"},
            },
            {"type": "scan_endogenous"},
            {"type": "reflect", "candidate_id": "d0002", "operation": "defer"},
            {
                "type": "stimulus",
                "id": "s2",
                "channel": "novelty",
                "magnitude": 0.5,
                "target": "inspect:new-signal",
                "context": {"concept": "novelty"},
            },
            {"type": "reflect", "candidate_id": "d0003", "operation": "adopt"},
            {
                "type": "consequence",
                "candidate_id": "d0003",
                "outcome": "relation-cost",
                "relation_delta": {"environment": {"novelty": "distracting"}},
            },
            {"type": "scan_endogenous"},
            {"type": "reflect", "candidate_id": "d0004", "operation": "defer"},
            {"type": "set_scaffold_level", "level": 0.0},
            {"type": "compose_endogenous"},
            {"type": "scan_endogenous"},
            {"type": "reflect", "candidate_id": "d0005", "operation": "adopt"},
            {
                "type": "propose_generator_revision",
                "candidate_id": "d0005",
                "generator_id": "g_novelty",
                "operation": "set_weight",
                "value": 0.25,
                "reason": "history-derived novelty tension should have less scaffold influence",
            },
            {"type": "review_meta_will", "proposal_id": "m0001", "operation": "adopt"},
            {"type": "apply_meta_will", "proposal_id": "m0001"},
        ],
    }


class MetaWillScenarioTests(unittest.TestCase):
    def test_meta_will_scenario_replays_generator_self_revision(self):
        result = run_scenario(meta_will_scenario())

        self.assertEqual(result["final_state"]["generators"]["g_novelty"]["weight"], 0.25)
        proposal = result["final_state"]["meta_will_proposals"]["m0001"]
        self.assertEqual(proposal["source_candidate_id"], "d0005")
        self.assertEqual(proposal["status"], "applied")
        self.assertEqual(proposal["operation"], "set_weight")
        self.assertEqual(proposal["value"], 0.25)
        diagnostics = result["diagnostics"]
        self.assertEqual(diagnostics["meta_will_proposal_count"], 1)
        self.assertEqual(diagnostics["meta_will_applied_count"], 1)
        self.assertEqual(diagnostics["endogenous_generator_self_revision_count"], 1)
        self.assertTrue(diagnostics["post_withdrawal_meta_will_applied"])
        self.assertEqual(diagnostics["operational_autonomy_claim"], "not_established")
        self.assertEqual(diagnostics["subjecthood_claim"], "not_assessed")

    def test_meta_will_replay_is_byte_deterministic(self):
        first = json.dumps(run_scenario(meta_will_scenario()), sort_keys=True, separators=(",", ":"))
        second = json.dumps(run_scenario(meta_will_scenario()), sort_keys=True, separators=(",", ":"))
        self.assertEqual(first, second)


if __name__ == "__main__":
    unittest.main()
