import unittest

from rwgs_harness import Generator, Harness, Stimulus, run_scenario


def adopted_harness(relation_state):
    h = Harness(
        generators=[Generator(id="g1", channel="relation")],
        relation_state=relation_state,
    )
    cid = h.observe_stimulus(
        Stimulus(id="s1", channel="relation", magnitude=1.0, target="bob", context={"concept": "trust"})
    )[0].id
    h.reflect(cid, "adopt")
    return h, cid


class RelationTensionTests(unittest.TestCase):
    def test_changed_existing_relation_key_records_relation_mismatch_tension(self):
        h, cid = adopted_harness({"bob": {"trust": "high"}})
        h.record_consequence(
            cid,
            outcome="surprise",
            relation_delta={"bob": {"trust": "low"}},
        )

        self.assertEqual(h.relation_state["bob"]["trust"], "low")
        tension = h.endogenous_tensions["t0001"]
        self.assertEqual(tension.kind, "relation_mismatch")
        self.assertEqual(tension.origin, "primitive")
        self.assertEqual(tension.concept, "trust")
        self.assertEqual(tension.source_event_id, "c0001")
        self.assertEqual(tension.source_candidate_id, cid)
        self.assertEqual(tension.key, "bob:trust")
        self.assertEqual(tension.before, "high")
        self.assertEqual(tension.after, "low")
        self.assertEqual(tension.target, "reconcile:relation:bob:trust")

    def test_new_relation_key_is_learning_not_mismatch(self):
        h, cid = adopted_harness({"bob": {"trust": "high"}})
        h.record_consequence(cid, outcome="new", relation_delta={"bob": {"respect": "high"}})
        self.assertEqual(h.endogenous_tensions, {})
        self.assertEqual(h.relation_state["bob"]["respect"], "high")

    def test_unchanged_relation_value_does_not_create_mismatch(self):
        h, cid = adopted_harness({"bob": {"trust": "high"}})
        h.record_consequence(cid, outcome="stable", relation_delta={"bob": {"trust": "high"}})
        self.assertEqual(h.endogenous_tensions, {})

    def test_scenario_exposes_relation_state_and_relation_delta(self):
        result = run_scenario(
            {
                "name": "relation-history",
                "relation_state": {"bob": {"trust": "high"}},
                "generators": [{"id": "g1", "channel": "relation"}],
                "steps": [
                    {
                        "type": "stimulus",
                        "id": "s1",
                        "channel": "relation",
                        "magnitude": 1.0,
                        "target": "bob",
                        "context": {"concept": "trust"},
                    },
                    {"type": "reflect", "candidate_id": "d0001", "operation": "adopt"},
                    {
                        "type": "consequence",
                        "candidate_id": "d0001",
                        "outcome": "surprise",
                        "relation_delta": {"bob": {"trust": "low"}},
                    },
                ],
            }
        )
        self.assertEqual(result["final_state"]["relation_state"]["bob"]["trust"], "low")
        self.assertEqual(result["final_state"]["endogenous_tensions"]["t0001"]["kind"], "relation_mismatch")


if __name__ == "__main__":
    unittest.main()
