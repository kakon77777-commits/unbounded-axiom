import unittest

from rwgs_harness import Generator, Harness, Stimulus


def adopted_harness(self_model):
    h = Harness(generators=[Generator(id="g1", channel="competence")], self_model=self_model)
    cid = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="task"))[0].id
    h.reflect(cid, "adopt")
    return h, cid


class EndogenousTensionTests(unittest.TestCase):
    def test_changed_existing_self_model_key_records_one_mismatch_tension(self):
        h, cid = adopted_harness({"competence": "high"})
        record = h.record_consequence(cid, outcome="failure", self_delta={"competence": "low"})

        self.assertEqual(record["id"], "c0001")
        self.assertEqual(len(h.endogenous_tensions), 1)
        tension = h.endogenous_tensions["t0001"]
        self.assertEqual(tension.kind, "self_model_mismatch")
        self.assertEqual(tension.source_candidate_id, cid)
        self.assertEqual(tension.source_event_id, "c0001")
        self.assertEqual(tension.key, "competence")
        self.assertEqual(tension.before, "high")
        self.assertEqual(tension.after, "low")
        self.assertEqual(tension.target, "reconcile:self_model:competence")
        self.assertEqual(tension.magnitude, 1.0)
        self.assertIsNone(tension.candidate_id)
        self.assertIn("endogenous_tension_recorded", [event["event"] for event in h.audit])

    def test_new_self_model_key_is_learning_not_mismatch(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="failure", self_delta={"new_fact": "observed"})
        self.assertEqual(h.endogenous_tensions, {})

    def test_unchanged_self_model_value_does_not_create_mismatch(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="neutral", self_delta={"competence": "high"})
        self.assertEqual(h.endogenous_tensions, {})


if __name__ == "__main__":
    unittest.main()

class EndogenousScanTests(unittest.TestCase):
    def test_scan_at_zero_scaffold_creates_endogenous_candidate_with_provenance(self):
        h, cid = adopted_harness({"competence": "high"})
        h.set_scaffold_level(0.0)
        h.record_consequence(cid, outcome="failure", self_delta={"competence": "low"})

        created = h.scan_endogenous()

        self.assertEqual([candidate.id for candidate in created], ["d0002"])
        candidate = created[0]
        self.assertEqual(candidate.origin, "endogenous")
        self.assertIsNone(candidate.generator_id)
        self.assertIsNone(candidate.stimulus_id)
        self.assertEqual(candidate.source_event_id, "c0001")
        self.assertEqual(candidate.tension_id, "t0001")
        self.assertEqual(candidate.target, "reconcile:self_model:competence")
        self.assertEqual(candidate.intensity, 1.0)
        self.assertEqual(h.endogenous_tensions["t0001"].candidate_id, "d0002")
        self.assertEqual(h.audit[-1]["event"], "endogenous_candidate_created")

    def test_repeated_scan_does_not_duplicate_candidate_for_same_tension(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="failure", self_delta={"competence": "low"})
        first = h.scan_endogenous()
        second = h.scan_endogenous()

        self.assertEqual(len(first), 1)
        self.assertEqual(second, [])
        self.assertEqual(len(h.candidates), 2)


class EndogenousReflectionCompatibilityTests(unittest.TestCase):
    def test_revision_preserves_endogenous_provenance_and_lineage(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="failure", self_delta={"competence": "low"})
        endogenous = h.scan_endogenous()[0]

        child = h.reflect(
            endogenous.id,
            "revise",
            revision={"target": "reconcile:self_model:competence:carefully", "intensity": 0.6, "reason": "meta-review"},
        )

        self.assertEqual(child.origin, "endogenous")
        self.assertEqual(child.parent_id, endogenous.id)
        self.assertEqual(child.source_event_id, "c0001")
        self.assertEqual(child.tension_id, "t0001")
        self.assertIsNone(child.generator_id)
        self.assertIsNone(child.stimulus_id)
