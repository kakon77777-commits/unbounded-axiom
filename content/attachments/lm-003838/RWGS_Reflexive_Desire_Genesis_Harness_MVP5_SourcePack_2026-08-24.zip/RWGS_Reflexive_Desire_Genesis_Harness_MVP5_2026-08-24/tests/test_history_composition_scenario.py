import json
import unittest

from rwgs_harness import run_scenario


SCENARIO = {
    "name": "history-composite-tension",
    "scaffold_level": 1.0,
    "self_model": {"trust": "stable"},
    "relation_state": {"bob": {"trust": "high"}},
    "generators": [{"id": "g1", "channel": "reflection", "weight": 1.0}],
    "steps": [
        {
            "type": "stimulus",
            "id": "s1",
            "channel": "reflection",
            "magnitude": 1.0,
            "target": "understand:trust",
            "context": {"concept": "trust"},
        },
        {"type": "reflect", "candidate_id": "d0001", "operation": "adopt"},
        {
            "type": "consequence",
            "candidate_id": "d0001",
            "outcome": "self-surprise",
            "self_delta": {"trust": "uncertain"},
        },
        {"type": "scan_endogenous"},
        {"type": "reflect", "candidate_id": "d0002", "operation": "defer"},
        {
            "type": "stimulus",
            "id": "s2",
            "channel": "reflection",
            "magnitude": 0.5,
            "target": "reconsider:bob",
            "context": {"concept": "trust"},
        },
        {"type": "reflect", "candidate_id": "d0003", "operation": "adopt"},
        {
            "type": "consequence",
            "candidate_id": "d0003",
            "outcome": "relation-surprise",
            "relation_delta": {"bob": {"trust": "low"}},
        },
        {"type": "scan_endogenous"},
        {"type": "reflect", "candidate_id": "d0004", "operation": "defer"},
        {"type": "set_scaffold_level", "level": 0.0},
        {"type": "compose_endogenous"},
        {"type": "scan_endogenous"},
    ],
}


class HistoryCompositionScenarioTests(unittest.TestCase):
    def test_replay_surfaces_one_post_withdrawal_history_composite_candidate(self):
        result = run_scenario(SCENARIO)
        final = result["final_state"]
        composite = final["endogenous_tensions"]["t0003"]
        self.assertEqual(composite["kind"], "history_composite")
        self.assertEqual(composite["component_tension_ids"], ["t0001", "t0002"])
        self.assertEqual(composite["source_event_ids"], ["c0001", "c0002"])
        self.assertEqual(composite["concept"], "trust")
        self.assertEqual(final["candidates"]["d0005"]["tension_id"], "t0003")
        self.assertEqual(final["candidates"]["d0005"]["target"], "integrate:history:trust")
        self.assertEqual(result["diagnostics"]["composite_endogenous_tension_count"], 1)
        self.assertTrue(result["diagnostics"]["post_withdrawal_composite_generation"])
        self.assertEqual(result["diagnostics"]["operational_autonomy_claim"], "not_established")
        self.assertEqual(result["diagnostics"]["subjecthood_claim"], "not_assessed")

    def test_history_composition_replay_serializes_byte_identically(self):
        first = json.dumps(run_scenario(SCENARIO), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(SCENARIO), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))


if __name__ == "__main__":
    unittest.main()
