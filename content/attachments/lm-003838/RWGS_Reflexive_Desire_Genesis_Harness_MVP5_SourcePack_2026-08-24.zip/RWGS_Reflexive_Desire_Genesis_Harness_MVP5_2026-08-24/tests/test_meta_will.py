import unittest

from rwgs_harness import Generator, Harness, RWGSError, Stimulus


def harness_with_adopted_endogenous():
    h = Harness(
        generators=[Generator(id="g1", channel="competence", weight=1.0)],
        self_model={"competence": "high"},
    )
    scaffold = h.observe_stimulus(
        Stimulus(
            id="s1",
            channel="competence",
            magnitude=1.0,
            target="practice",
            context={"concept": "competence"},
        )
    )[0]
    h.reflect(scaffold.id, "adopt")
    h.record_consequence(scaffold.id, "failure", self_delta={"competence": "low"})
    h.set_scaffold_level(0.0)
    endogenous = h.scan_endogenous()[0]
    h.reflect(endogenous.id, "adopt")
    return h, scaffold, endogenous


class MetaWillProposalTests(unittest.TestCase):
    def test_proposal_requires_adopted_endogenous_candidate(self):
        h, scaffold, endogenous = harness_with_adopted_endogenous()

        with self.assertRaisesRegex(RWGSError, "adopted endogenous"):
            h.propose_generator_revision(
                scaffold.id,
                "g1",
                "set_weight",
                0.25,
                reason="scaffold candidate must not own generator revision",
            )

        h2 = Harness(
            generators=[Generator(id="g1", channel="competence", weight=1.0)],
            self_model={"competence": "high"},
        )
        first = h2.observe_stimulus(
            Stimulus(id="s1", channel="competence", magnitude=1.0, target="practice")
        )[0]
        h2.reflect(first.id, "adopt")
        h2.record_consequence(first.id, "failure", self_delta={"competence": "low"})
        h2.set_scaffold_level(0.0)
        unadopted_endogenous = h2.scan_endogenous()[0]
        with self.assertRaisesRegex(RWGSError, "adopted endogenous"):
            h2.propose_generator_revision(
                unadopted_endogenous.id,
                "g1",
                "set_weight",
                0.25,
            )

    def test_proposal_is_pure_and_does_not_mutate_generator(self):
        h, _, endogenous = harness_with_adopted_endogenous()

        proposal = h.propose_generator_revision(
            endogenous.id,
            "g1",
            "set_weight",
            0.25,
            reason="reduce externally scaffolded competence pressure",
        )

        self.assertEqual(proposal.id, "m0001")
        self.assertEqual(proposal.source_candidate_id, endogenous.id)
        self.assertEqual(proposal.generator_id, "g1")
        self.assertEqual(proposal.operation, "set_weight")
        self.assertEqual(proposal.value, 0.25)
        self.assertEqual(proposal.status, "proposed")
        self.assertEqual(h.generators["g1"].weight, 1.0)
        self.assertEqual(h.audit[-1]["event"], "meta_will_proposed")
        self.assertEqual(h.audit[-1]["source_candidate_id"], endogenous.id)


class MetaWillReviewTests(unittest.TestCase):
    def _proposal(self):
        h, _, endogenous = harness_with_adopted_endogenous()
        proposal = h.propose_generator_revision(endogenous.id, "g1", "set_weight", 0.25)
        return h, proposal

    def test_meta_adopt_does_not_apply_generator_change(self):
        h, proposal = self._proposal()

        reviewed = h.review_meta_will(proposal.id, "adopt")

        self.assertEqual(reviewed.status, "adopted")
        self.assertEqual(h.generators["g1"].weight, 1.0)
        self.assertEqual(h.audit[-1]["event"], "meta_will_adopted")

    def test_meta_reject_is_terminal_for_review(self):
        h, proposal = self._proposal()
        h.review_meta_will(proposal.id, "reject")

        self.assertEqual(proposal.status, "rejected")
        with self.assertRaisesRegex(RWGSError, "not reviewable"):
            h.review_meta_will(proposal.id, "adopt")

    def test_meta_defer_remains_reviewable(self):
        h, proposal = self._proposal()

        h.review_meta_will(proposal.id, "defer")
        self.assertEqual(proposal.status, "deferred")
        h.review_meta_will(proposal.id, "adopt")

        self.assertEqual(proposal.status, "adopted")
        self.assertEqual(h.generators["g1"].weight, 1.0)



class MetaWillApplicationTests(unittest.TestCase):
    def _adopted_proposal(self, operation="set_weight", value=0.25):
        h, _, endogenous = harness_with_adopted_endogenous()
        proposal = h.propose_generator_revision(endogenous.id, "g1", operation, value)
        h.review_meta_will(proposal.id, "adopt")
        return h, proposal

    def test_adopted_weight_proposal_changes_generator_only_on_apply(self):
        h, proposal = self._adopted_proposal("set_weight", 0.25)
        self.assertEqual(h.generators["g1"].weight, 1.0)

        applied = h.apply_meta_will(proposal.id)

        self.assertEqual(applied.status, "applied")
        self.assertEqual(h.generators["g1"].weight, 0.25)
        event = h.audit[-1]
        self.assertEqual(event["event"], "meta_will_applied")
        self.assertEqual(event["source_candidate_id"], proposal.source_candidate_id)
        self.assertEqual(event["generator_id"], "g1")
        self.assertEqual(event["old_value"], 1.0)
        self.assertEqual(event["new_value"], 0.25)
        self.assertEqual(event["scaffold_level"], 0.0)
        h.set_scaffold_level(1.0)
        future = h.observe_stimulus(
            Stimulus(id="s2", channel="competence", magnitude=1.0, target="future-task")
        )[0]
        self.assertEqual(future.intensity, 0.25)

    def test_adopted_enabled_proposal_can_disable_generator(self):
        h, proposal = self._adopted_proposal("set_enabled", False)

        h.apply_meta_will(proposal.id)

        self.assertFalse(h.generators["g1"].enabled)
        h.set_scaffold_level(1.0)
        future = h.observe_stimulus(
            Stimulus(id="s2", channel="competence", magnitude=1.0, target="future-task")
        )
        self.assertEqual(future, [])

    def test_rejected_or_deferred_proposal_cannot_apply(self):
        h, _, endogenous = harness_with_adopted_endogenous()
        rejected = h.propose_generator_revision(endogenous.id, "g1", "set_weight", 0.25)
        h.review_meta_will(rejected.id, "reject")
        with self.assertRaisesRegex(RWGSError, "must be adopted"):
            h.apply_meta_will(rejected.id)

        deferred = h.propose_generator_revision(endogenous.id, "g1", "set_enabled", False)
        h.review_meta_will(deferred.id, "defer")
        with self.assertRaisesRegex(RWGSError, "must be adopted"):
            h.apply_meta_will(deferred.id)

    def test_apply_is_single_use(self):
        h, proposal = self._adopted_proposal()
        h.apply_meta_will(proposal.id)
        with self.assertRaisesRegex(RWGSError, "must be adopted"):
            h.apply_meta_will(proposal.id)

    def test_invalid_meta_operation_or_value_is_rejected(self):
        h, _, endogenous = harness_with_adopted_endogenous()
        with self.assertRaisesRegex(RWGSError, "unsupported"):
            h.propose_generator_revision(endogenous.id, "g1", "set_scaffold_level", 0.0)
        with self.assertRaisesRegex(RWGSError, r"within \[0,1\]"):
            h.propose_generator_revision(endogenous.id, "g1", "set_weight", 1.5)
        with self.assertRaisesRegex(RWGSError, "boolean"):
            h.propose_generator_revision(endogenous.id, "g1", "set_enabled", 0)



if __name__ == "__main__":
    unittest.main()
