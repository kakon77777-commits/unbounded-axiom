import json
from pathlib import Path
import unittest

from rwgs_harness import run_scenario


ROOT = Path(__file__).resolve().parents[1]
SCENARIO_12 = ROOT / "scenarios" / "12_longitudinal_consecutive_renewal.json"
SCENARIO_13 = ROOT / "scenarios" / "13_rebound_and_rewithdrawal.json"


class LongitudinalScenarioTests(unittest.TestCase):
    def test_scenario_12_observes_two_consecutive_renewal_transitions(self):
        data = json.loads(SCENARIO_12.read_text(encoding="utf-8"))
        result = run_scenario(data)
        d = result["diagnostics"]

        self.assertEqual(d["withdrawal_epoch_count"], 1)
        self.assertEqual(d["strict_renewal_transition_count"], 2)
        self.assertEqual(d["longest_renewal_chain_length"], 3)
        self.assertEqual(d["longest_renewal_transition_depth"], 2)
        self.assertEqual(d["longitudinal_renewal_status"], "consecutive_chain_observed")
        self.assertEqual(d["renewal_root_candidate_ids"], ["d0002"])
        self.assertEqual(d["scaffold_independence_claim"], "not_established")
        self.assertEqual(d["operational_autonomy_claim"], "not_established")
        self.assertEqual(d["subjecthood_claim"], "not_assessed")

    def test_scenario_12_is_byte_deterministic(self):
        data = json.loads(SCENARIO_12.read_text(encoding="utf-8"))
        first = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))

    def test_scenario_13_separates_rebound_support_and_rewithdrawal(self):
        data = json.loads(SCENARIO_13.read_text(encoding="utf-8"))
        result = run_scenario(data)
        d = result["diagnostics"]

        self.assertEqual(d["withdrawal_epoch_count"], 2)
        self.assertEqual(d["rewitdrawal_count"], 1)
        self.assertTrue(d["withdrawal_rebound_detected"])
        self.assertEqual(d["withdrawal_stability_status"], "rewitdrawn_after_rebound")
        self.assertEqual(d["strict_renewal_transition_count"], 0)
        self.assertEqual(d["longest_renewal_chain_length"], 0)
        self.assertEqual(
            d["post_first_withdrawal_candidate_origin_counts"],
            {"scaffold": 1, "endogenous": 2},
        )
        self.assertEqual(d["post_first_withdrawal_external_stimulus_count"], 1)
        self.assertEqual(d["support_origin_status"], "mixed_scaffold_and_endogenous")
        self.assertEqual(d["scaffold_independence_claim"], "not_established")
        self.assertEqual(d["operational_autonomy_claim"], "not_established")
        self.assertEqual(d["subjecthood_claim"], "not_assessed")

    def test_scenario_13_is_byte_deterministic(self):
        data = json.loads(SCENARIO_13.read_text(encoding="utf-8"))
        first = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))


if __name__ == "__main__":
    unittest.main()
