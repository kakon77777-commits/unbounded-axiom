import unittest

from rwgs_harness import Generator, Harness, RWGSError, Stimulus


def one_candidate() -> tuple[Harness, str]:
    h = Harness(generators=[Generator(id="g1", channel="novelty", weight=1.0)])
    cid = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))[0].id
    return h, cid


class ReflectionTests(unittest.TestCase):
    def test_adopt_changes_operational_priority(self):
        h, cid = one_candidate()
        h.reflect(cid, "adopt")
        self.assertEqual(h.candidates[cid].status, "adopted")
        self.assertEqual(h.active_priorities, [cid])

    def test_reject_is_operational_not_decorative(self):
        h, cid = one_candidate()
        h.reflect(cid, "reject")
        self.assertEqual(h.candidates[cid].status, "rejected")
        self.assertNotIn(cid, h.active_priorities)
        self.assertFalse(h.is_actionable(cid))

    def test_defer_differs_from_reject_and_remains_reviewable(self):
        h, cid = one_candidate()
        h.reflect(cid, "defer")
        self.assertEqual(h.candidates[cid].status, "deferred")
        self.assertFalse(h.is_actionable(cid))
        h.reflect(cid, "adopt")
        self.assertEqual(h.candidates[cid].status, "adopted")

    def test_revise_preserves_lineage(self):
        h, cid = one_candidate()
        child = h.reflect(cid, "revise", revision={"target": "y", "intensity": 0.4, "reason": "after reflection"})
        self.assertEqual(h.candidates[cid].status, "revised")
        self.assertEqual(child.parent_id, cid)
        self.assertEqual(child.target, "y")
        self.assertEqual(child.intensity, 0.4)
        self.assertEqual(child.status, "candidate")

    def test_invalid_transition_fails_explicitly(self):
        h, cid = one_candidate()
        h.reflect(cid, "reject")
        with self.assertRaises(RWGSError):
            h.reflect(cid, "adopt")


if __name__ == "__main__":
    unittest.main()
