import unittest

from rwgs_harness import Generator, Harness, Stimulus, build_diagnostics


def adopted_scaffold_candidate(harness: Harness, *, concept: str = "competence") -> str:
    candidate = harness.observe_stimulus(
        Stimulus(
            id="s1",
            channel=concept,
            magnitude=1.0,
            target=f"act:{concept}",
            context={"concept": concept},
        )
    )[0]
    harness.reflect(candidate.id, "adopt")
    return candidate.id


class WithdrawalLoopTests(unittest.TestCase):
    def test_scaffold_history_reconstructs_monotonic_withdrawal(self):
        h = Harness(scaffold_level=1.0)
        h.set_scaffold_level(0.5)
        h.set_scaffold_level(0.0)

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["scaffold_level_history"], [1.0, 0.5, 0.0])
        self.assertTrue(diagnostics["scaffold_fully_withdrawn"])
        self.assertFalse(diagnostics["withdrawal_rebound_detected"])

    def test_withdrawal_rebound_is_diagnostic_not_prohibited(self):
        h = Harness(scaffold_level=1.0)
        h.set_scaffold_level(0.4)
        h.set_scaffold_level(0.8)
        h.set_scaffold_level(0.0)

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["scaffold_level_history"], [1.0, 0.4, 0.8, 0.0])
        self.assertTrue(diagnostics["withdrawal_rebound_detected"])
        self.assertTrue(diagnostics["scaffold_fully_withdrawn"])

    def test_persistence_after_withdrawal_is_not_renewal(self):
        h = Harness(generators=[Generator(id="g1", channel="competence")])
        adopted_scaffold_candidate(h)
        h.set_scaffold_level(0.0)

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["post_withdrawal_endogenous_candidate_count"], 0)
        self.assertEqual(diagnostics["post_withdrawal_renewal_candidate_count"], 0)
        self.assertFalse(diagnostics["self_maintained_loop_observed"])
        self.assertEqual(diagnostics["scaffold_dependency_status"], "withdrawn_persistence_only")

    def test_single_post_withdrawal_endogenous_generation_is_not_renewal_loop(self):
        h = Harness(
            generators=[Generator(id="g1", channel="competence")],
            self_model={"competence": "high"},
        )
        d1 = adopted_scaffold_candidate(h)
        h.set_scaffold_level(0.0)
        h.record_consequence(d1, "failure", self_delta={"competence": "low"})
        h.scan_endogenous()

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["post_withdrawal_endogenous_candidate_count"], 1)
        self.assertEqual(diagnostics["post_withdrawal_endogenous_adoption_count"], 0)
        self.assertEqual(diagnostics["post_withdrawal_renewal_candidate_count"], 0)
        self.assertFalse(diagnostics["self_maintained_loop_observed"])
        self.assertEqual(diagnostics["scaffold_dependency_status"], "withdrawn_endogenous_generation")

    def test_endogenous_candidate_consequence_can_renew_another_endogenous_candidate(self):
        h = Harness(
            generators=[Generator(id="g1", channel="competence")],
            self_model={"competence": "high", "confidence": "stable"},
        )
        d1 = adopted_scaffold_candidate(h)
        h.set_scaffold_level(0.0)
        h.record_consequence(d1, "failure", self_delta={"competence": "low"})
        d2 = h.scan_endogenous()[0]
        h.reflect(d2.id, "adopt")
        second_consequence = h.record_consequence(
            d2.id,
            "reassessment",
            self_delta={"confidence": "low"},
        )
        d3 = h.scan_endogenous()[0]

        diagnostics = build_diagnostics(h)

        self.assertEqual(second_consequence["id"], "c0002")
        self.assertEqual(d3.source_event_id, "c0002")
        self.assertEqual(d3.origin, "endogenous")
        self.assertEqual(diagnostics["post_withdrawal_endogenous_candidate_count"], 2)
        self.assertEqual(diagnostics["post_withdrawal_endogenous_adoption_count"], 1)
        self.assertEqual(diagnostics["post_withdrawal_consequence_count"], 2)
        self.assertEqual(diagnostics["post_withdrawal_renewal_candidate_count"], 1)
        self.assertEqual(
            diagnostics["post_withdrawal_renewal_lineages"],
            [
                {
                    "source_candidate_id": "d0002",
                    "consequence_id": "c0002",
                    "renewal_candidate_id": "d0003",
                    "tension_id": "t0002",
                }
            ],
        )
        self.assertTrue(diagnostics["self_maintained_loop_observed"])
        self.assertEqual(diagnostics["scaffold_dependency_status"], "withdrawn_renewal_observed")
        self.assertEqual(diagnostics["scaffold_independence_claim"], "not_established")
        self.assertEqual(diagnostics["operational_autonomy_claim"], "not_established")
        self.assertEqual(diagnostics["subjecthood_claim"], "not_assessed")

    def test_zero_scaffold_with_no_state_is_withdrawn_collapse(self):
        h = Harness(scaffold_level=0.0)
        diagnostics = build_diagnostics(h)

        self.assertTrue(diagnostics["scaffold_collapse"])
        self.assertEqual(diagnostics["scaffold_dependency_status"], "withdrawn_collapse")
        self.assertEqual(diagnostics["scaffold_independence_claim"], "not_established")

    def test_positive_scaffold_is_scaffold_active(self):
        h = Harness(scaffold_level=0.3)
        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["scaffold_dependency_status"], "scaffold_active")
        self.assertFalse(diagnostics["scaffold_fully_withdrawn"])


if __name__ == "__main__":
    unittest.main()
