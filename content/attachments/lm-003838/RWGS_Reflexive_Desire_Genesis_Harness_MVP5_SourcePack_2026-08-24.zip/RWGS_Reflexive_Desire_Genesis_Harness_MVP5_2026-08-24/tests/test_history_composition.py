import unittest

from rwgs_harness import Generator, Harness, Stimulus, build_diagnostics


def adopted_harness(self_model=None, relation_state=None):
    kwargs = {"generators": [Generator(id="g1", channel="competence")], "self_model": self_model or {}}
    if relation_state is not None:
        kwargs["relation_state"] = relation_state
    h = Harness(**kwargs)
    cid = h.observe_stimulus(
        Stimulus(
            id="s1",
            channel="competence",
            magnitude=1.0,
            target="task",
            context={"concept": "competence"},
        )
    )[0].id
    h.reflect(cid, "adopt")
    return h, cid


class TensionProvenanceTypeTests(unittest.TestCase):
    def test_self_model_mismatch_exposes_primitive_origin_and_explicit_concept(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="failure", self_delta={"competence": "low"})

        tension = h.endogenous_tensions["t0001"]
        self.assertEqual(tension.origin, "primitive")
        self.assertEqual(tension.concept, "competence")
        self.assertEqual(tension.component_tension_ids, [])
        self.assertEqual(tension.source_event_ids, ["c0001"])
        self.assertEqual(tension.source_candidate_ids, [cid])
        self.assertEqual(tension.context_candidate_ids, [])


class HistoryCompositionTests(unittest.TestCase):
    def test_same_concept_across_distinct_consequences_creates_one_composite_tension(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="failure-1", self_delta={"competence": "low"})
        h.record_consequence(cid, outcome="failure-2", self_delta={"competence": "medium"})

        created = h.compose_endogenous()

        self.assertEqual([t.id for t in created], ["t0003"])
        composite = created[0]
        self.assertEqual(composite.kind, "history_composite")
        self.assertEqual(composite.origin, "composite")
        self.assertEqual(composite.concept, "competence")
        self.assertEqual(composite.component_tension_ids, ["t0001", "t0002"])
        self.assertEqual(composite.source_event_ids, ["c0001", "c0002"])
        self.assertEqual(composite.source_candidate_ids, [cid])
        self.assertEqual(composite.target, "integrate:history:competence")
        self.assertEqual(composite.magnitude, 1.0)

    def test_different_concepts_do_not_compose(self):
        h, cid = adopted_harness({"competence": "high", "confidence": "high"})
        h.record_consequence(cid, outcome="one", self_delta={"competence": "low"})
        h.record_consequence(cid, outcome="two", self_delta={"confidence": "low"})
        self.assertEqual(h.compose_endogenous(), [])

    def test_same_component_set_is_not_composed_twice(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="one", self_delta={"competence": "low"})
        h.record_consequence(cid, outcome="two", self_delta={"competence": "medium"})
        self.assertEqual(len(h.compose_endogenous()), 1)
        self.assertEqual(h.compose_endogenous(), [])
        self.assertEqual(len([t for t in h.endogenous_tensions.values() if t.origin == "composite"]), 1)

    def test_active_desire_with_matching_explicit_concept_is_recorded_as_context(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="one", self_delta={"competence": "low"})
        h.record_consequence(cid, outcome="two", self_delta={"competence": "medium"})
        second = h.observe_stimulus(
            Stimulus(
                id="s2",
                channel="competence",
                magnitude=0.5,
                target="practice",
                context={"concept": "competence"},
            )
        )[0]
        h.reflect(second.id, "adopt")

        composite = h.compose_endogenous()[0]
        self.assertIn(second.id, composite.context_candidate_ids)

    def test_two_primitive_tensions_from_same_consequence_do_not_compose(self):
        h, cid = adopted_harness(
            {"trust": "high"},
            relation_state={"bob": {"trust": "high"}},
        )
        h.record_consequence(
            cid,
            outcome="one-event",
            self_delta={"trust": "low"},
            relation_delta={"bob": {"trust": "low"}},
        )
        self.assertEqual(len(h.endogenous_tensions), 2)
        self.assertEqual(h.compose_endogenous(), [])


class CompositeScanTests(unittest.TestCase):
    def test_composite_tension_surfaces_at_zero_scaffold_without_autonomy_claim(self):
        h, cid = adopted_harness({"competence": "high"})
        h.record_consequence(cid, outcome="one", self_delta={"competence": "low"})
        h.record_consequence(cid, outcome="two", self_delta={"competence": "medium"})
        composite = h.compose_endogenous()[0]
        h.set_scaffold_level(0.0)

        created = h.scan_endogenous()
        composite_candidate = next(candidate for candidate in created if candidate.tension_id == composite.id)
        self.assertEqual(composite_candidate.origin, "endogenous")
        self.assertEqual(composite_candidate.source_event_id, "h0001")
        self.assertEqual(composite_candidate.concept, "competence")
        self.assertEqual(composite_candidate.target, "integrate:history:competence")

        diagnostics = build_diagnostics(h)
        self.assertEqual(diagnostics["primitive_endogenous_tension_count"], 2)
        self.assertEqual(diagnostics["composite_endogenous_tension_count"], 1)
        self.assertTrue(diagnostics["post_withdrawal_composite_generation"])
        self.assertEqual(diagnostics["operational_autonomy_claim"], "not_established")
        self.assertEqual(diagnostics["subjecthood_claim"], "not_assessed")


if __name__ == "__main__":
    unittest.main()
