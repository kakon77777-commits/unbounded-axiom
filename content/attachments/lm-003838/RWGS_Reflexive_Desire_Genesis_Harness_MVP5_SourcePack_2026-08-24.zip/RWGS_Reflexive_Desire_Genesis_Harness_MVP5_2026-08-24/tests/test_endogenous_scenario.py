import json
import unittest

from rwgs_harness import run_scenario


POST_WITHDRAWAL = {
    "name": "post-withdrawal-endogenous-tension",
    "scaffold_level": 1.0,
    "self_model": {"competence": "high"},
    "generators": [{"id": "g1", "channel": "competence", "weight": 1.0, "enabled": True}],
    "steps": [
        {"type": "stimulus", "id": "s1", "channel": "competence", "magnitude": 1.0, "target": "task"},
        {"type": "reflect", "candidate_id": "d0001", "operation": "adopt"},
        {"type": "set_scaffold_level", "level": 0.0},
        {"type": "consequence", "candidate_id": "d0001", "outcome": "failure", "self_delta": {"competence": "low"}},
        {"type": "scan_endogenous"},
    ],
}


class EndogenousScenarioTests(unittest.TestCase):
    def test_replay_exposes_post_withdrawal_endogenous_generation_without_autonomy_claim(self):
        result = run_scenario(POST_WITHDRAWAL)

        self.assertEqual(result["final_state"]["endogenous_tensions"]["t0001"]["candidate_id"], "d0002")
        self.assertEqual(result["final_state"]["candidates"]["d0002"]["origin"], "endogenous")
        self.assertEqual(result["final_state"]["candidates"]["d0002"]["source_event_id"], "c0001")
        self.assertEqual(result["diagnostics"]["endogenous_tension_count"], 1)
        self.assertEqual(result["diagnostics"]["unresolved_endogenous_tension_count"], 0)
        self.assertEqual(result["diagnostics"]["endogenous_candidate_count"], 1)
        self.assertTrue(result["diagnostics"]["post_withdrawal_endogenous_generation"])
        self.assertTrue(result["diagnostics"]["provenance_complete"])
        self.assertEqual(result["diagnostics"]["operational_autonomy_claim"], "not_established")
        self.assertEqual(result["diagnostics"]["subjecthood_claim"], "not_assessed")

    def test_post_withdrawal_replay_is_byte_deterministic(self):
        first = json.dumps(run_scenario(POST_WITHDRAWAL), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(POST_WITHDRAWAL), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))


if __name__ == "__main__":
    unittest.main()
