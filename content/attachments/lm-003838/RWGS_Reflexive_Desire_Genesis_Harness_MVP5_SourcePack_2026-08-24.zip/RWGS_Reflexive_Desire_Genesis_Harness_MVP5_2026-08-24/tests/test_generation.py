import unittest

from rwgs_harness import Generator, Harness, Stimulus


class GenerationTests(unittest.TestCase):
    def test_typed_stimulus_creates_observable_candidate_with_provenance(self):
        h = Harness(
            generators=[Generator(id="g-novelty", channel="novelty", weight=0.5)],
            scaffold_level=0.8,
        )
        created = h.observe_stimulus(
            Stimulus(id="s1", channel="novelty", magnitude=0.75, target="object-x", context={"zone": "toy"})
        )

        self.assertEqual([c.id for c in created], ["d0001"])
        candidate = created[0]
        self.assertEqual(candidate.status, "candidate")
        self.assertEqual(candidate.generator_id, "g-novelty")
        self.assertEqual(candidate.stimulus_id, "s1")
        self.assertEqual(candidate.target, "object-x")
        self.assertAlmostEqual(candidate.intensity, 0.3)
        self.assertEqual(candidate.origin, "scaffold")
        self.assertEqual(h.audit[-1]["event"], "desire_candidate_created")

    def test_stimulus_is_audited_even_when_it_generates_no_candidate(self):
        h = Harness(
            generators=[Generator(id="g-novelty", channel="novelty", weight=1.0)],
            scaffold_level=0.0,
        )
        created = h.observe_stimulus(
            Stimulus(id="s-zero", channel="novelty", magnitude=1.0, target="object-x", context={"phase": "withdrawn"})
        )
        self.assertEqual(created, [])
        self.assertEqual(h.audit[-1]["event"], "stimulus_observed")
        self.assertEqual(h.audit[-1]["stimulus_id"], "s-zero")
        self.assertEqual(h.audit[-1]["context"], {"phase": "withdrawn"})


if __name__ == "__main__":
    unittest.main()
