import json
from pathlib import Path
import unittest

from rwgs_harness import run_scenario


ROOT = Path(__file__).resolve().parents[1]
SCENARIO = ROOT / "scenarios" / "11_post_withdrawal_self_maintained_loop.json"


class WithdrawalLoopScenarioTests(unittest.TestCase):
    def test_scenario_11_demonstrates_traceable_post_withdrawal_renewal(self):
        data = json.loads(SCENARIO.read_text(encoding="utf-8"))
        result = run_scenario(data)

        diagnostics = result["diagnostics"]
        self.assertEqual(diagnostics["scaffold_level_history"], [1.0, 0.0])
        self.assertTrue(diagnostics["scaffold_fully_withdrawn"])
        self.assertEqual(diagnostics["post_withdrawal_endogenous_candidate_count"], 2)
        self.assertEqual(diagnostics["post_withdrawal_endogenous_adoption_count"], 1)
        self.assertEqual(diagnostics["post_withdrawal_consequence_count"], 2)
        self.assertEqual(diagnostics["post_withdrawal_renewal_candidate_count"], 1)
        self.assertTrue(diagnostics["self_maintained_loop_observed"])
        self.assertEqual(diagnostics["scaffold_dependency_status"], "withdrawn_renewal_observed")
        self.assertEqual(diagnostics["scaffold_independence_claim"], "not_established")
        self.assertEqual(diagnostics["operational_autonomy_claim"], "not_established")
        self.assertEqual(diagnostics["subjecthood_claim"], "not_assessed")

        d2 = result["final_state"]["candidates"]["d0002"]
        d3 = result["final_state"]["candidates"]["d0003"]
        self.assertEqual(d2["origin"], "endogenous")
        self.assertEqual(d3["origin"], "endogenous")
        self.assertEqual(d3["source_event_id"], "c0002")
        self.assertEqual(result["final_state"]["endogenous_tensions"]["t0002"]["source_event_ids"], ["c0002"])

    def test_scenario_11_is_byte_deterministic(self):
        data = json.loads(SCENARIO.read_text(encoding="utf-8"))
        first = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(data), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))


if __name__ == "__main__":
    unittest.main()
