import unittest

from rwgs_harness import Generator, Harness, RWGSError, Stimulus


def adopted_harness():
    h = Harness(generators=[Generator(id="g1", channel="competence")], self_model={"confidence": 0.2})
    cid = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="task"))[0].id
    h.reflect(cid, "adopt")
    return h, cid


class ConsequenceTests(unittest.TestCase):
    def test_consequence_updates_bounded_self_model_and_preserves_provenance(self):
        h, cid = adopted_harness()
        record = h.record_consequence(cid, outcome="success", self_delta={"confidence": 0.6, "last_outcome": "success"})
        self.assertEqual(h.self_model["confidence"], 0.6)
        self.assertEqual(h.self_model["last_outcome"], "success")
        self.assertEqual(record["candidate_id"], cid)
        self.assertEqual(record["outcome"], "success")
        self.assertEqual(h.audit[-2]["event"], "consequence_observed")
        self.assertEqual(h.audit[-1]["event"], "self_model_revised")

    def test_non_adopted_candidate_cannot_receive_action_consequence(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty")])
        cid = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))[0].id
        with self.assertRaises(RWGSError):
            h.record_consequence(cid, outcome="success", self_delta={"x": 1})


if __name__ == "__main__":
    unittest.main()
