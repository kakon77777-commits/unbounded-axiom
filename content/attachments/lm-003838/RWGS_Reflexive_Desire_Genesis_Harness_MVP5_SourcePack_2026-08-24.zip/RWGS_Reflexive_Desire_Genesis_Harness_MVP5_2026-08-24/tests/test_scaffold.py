import unittest

from rwgs_harness import Generator, Harness, Stimulus, build_diagnostics


class ScaffoldTests(unittest.TestCase):
    def test_generator_weight_changes_future_candidate_intensity(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty", weight=1.0)])
        first = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))[0]
        h.set_generator_weight("g1", 0.25)
        second = h.observe_stimulus(Stimulus(id="s2", channel="novelty", magnitude=1.0, target="y"))[0]
        self.assertEqual(first.intensity, 1.0)
        self.assertEqual(second.intensity, 0.25)

    def test_disabled_generator_cannot_emit_future_candidate(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty")])
        h.disable_generator("g1")
        created = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))
        self.assertEqual(created, [])

    def test_zero_scaffold_prevents_scaffold_generation(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty")])
        h.set_scaffold_level(0.0)
        created = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))
        self.assertEqual(created, [])

    def test_scaffold_collapse_is_diagnostic_not_autonomy_claim(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty")])
        h.set_scaffold_level(0.0)
        diagnostics = build_diagnostics(h)
        self.assertTrue(diagnostics["scaffold_collapse"])
        self.assertEqual(diagnostics["subjecthood_claim"], "not_assessed")
        self.assertEqual(diagnostics["operational_autonomy_claim"], "not_established")

    def test_adopted_priority_prevents_collapse_flag_even_at_zero_scaffold(self):
        h = Harness(generators=[Generator(id="g1", channel="novelty")])
        cid = h.observe_stimulus(Stimulus(id="s1", channel="novelty", magnitude=1.0, target="x"))[0].id
        h.reflect(cid, "adopt")
        h.set_scaffold_level(0.0)
        diagnostics = build_diagnostics(h)
        self.assertFalse(diagnostics["scaffold_collapse"])


if __name__ == "__main__":
    unittest.main()
