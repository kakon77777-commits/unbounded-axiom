import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


class CLITests(unittest.TestCase):
    def test_cli_emits_json_and_zero_exit_for_valid_scenario(self):
        scenario = {
            "name": "cli",
            "generators": [{"id": "g1", "channel": "novelty", "weight": 1.0}],
            "steps": [{"type": "stimulus", "id": "s1", "channel": "novelty", "magnitude": 1.0, "target": "x"}],
        }
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "scenario.json"
            path.write_text(json.dumps(scenario), encoding="utf-8")
            env = dict(os.environ)
            env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
            proc = subprocess.run(
                [sys.executable, "-m", "rwgs_harness", str(path)],
                text=True,
                capture_output=True,
                env=env,
                check=False,
            )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        payload = json.loads(proc.stdout)
        self.assertEqual(payload["name"], "cli")
        self.assertEqual(payload["diagnostics"]["candidate_count"], 1)

    def test_cli_returns_nonzero_for_invalid_scenario(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "bad.json"
            path.write_text('{"name":"bad","steps":[{"type":"unknown"}]}', encoding="utf-8")
            env = dict(os.environ)
            env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "src")
            proc = subprocess.run(
                [sys.executable, "-m", "rwgs_harness", str(path)],
                text=True,
                capture_output=True,
                env=env,
                check=False,
            )
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("error", proc.stderr.lower())


if __name__ == "__main__":
    unittest.main()
