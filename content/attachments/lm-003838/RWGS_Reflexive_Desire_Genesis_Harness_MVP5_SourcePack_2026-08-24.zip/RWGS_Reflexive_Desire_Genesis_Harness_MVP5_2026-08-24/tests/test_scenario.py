import json
import unittest

from rwgs_harness import RWGSError, run_scenario


BASE = {
    "name": "baseline",
    "scaffold_level": 1.0,
    "self_model": {"confidence": 0.1},
    "generators": [{"id": "g1", "channel": "novelty", "weight": 0.5, "enabled": True}],
    "steps": [
        {"type": "stimulus", "id": "s1", "channel": "novelty", "magnitude": 1.0, "target": "x"},
        {"type": "reflect", "candidate_id": "d0001", "operation": "adopt"},
        {"type": "consequence", "candidate_id": "d0001", "outcome": "success", "self_delta": {"confidence": 0.4}},
    ],
}


class ScenarioTests(unittest.TestCase):
    def test_scenario_replay_produces_explicit_final_state_and_diagnostics(self):
        result = run_scenario(BASE)
        self.assertEqual(result["name"], "baseline")
        self.assertEqual(result["final_state"]["candidates"]["d0001"]["status"], "adopted")
        self.assertEqual(result["final_state"]["self_model"]["confidence"], 0.4)
        self.assertEqual(result["diagnostics"]["adopted_count"], 1)
        self.assertEqual(result["diagnostics"]["subjecthood_claim"], "not_assessed")

    def test_repeated_scenario_result_serializes_byte_identically(self):
        first = json.dumps(run_scenario(BASE), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        second = json.dumps(run_scenario(BASE), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        self.assertEqual(first.encode("utf-8"), second.encode("utf-8"))

    def test_unknown_step_type_fails_explicitly(self):
        bad = dict(BASE)
        bad["steps"] = [{"type": "dream_up_hidden_motive"}]
        with self.assertRaises(RWGSError):
            run_scenario(bad)

    def test_duplicate_generator_id_fails_instead_of_silent_overwrite(self):
        bad = dict(BASE)
        bad["generators"] = [
            {"id": "g1", "channel": "novelty", "weight": 1.0},
            {"id": "g1", "channel": "competence", "weight": 1.0},
        ]
        with self.assertRaises(RWGSError):
            run_scenario(bad)


if __name__ == "__main__":
    unittest.main()
