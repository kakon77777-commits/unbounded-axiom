import unittest

from rwgs_harness import Generator, Harness, Stimulus, build_diagnostics


class LongitudinalWithdrawalTests(unittest.TestCase):
    def test_zero_rebound_zero_creates_two_withdrawal_epochs(self):
        h = Harness(scaffold_level=1.0)
        h.set_scaffold_level(0.0)
        h.set_scaffold_level(0.5)
        h.set_scaffold_level(0.0)

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["withdrawal_epoch_count"], 2)
        self.assertEqual(diagnostics["rewitdrawal_count"], 1)
        self.assertEqual(diagnostics["withdrawal_stability_status"], "rewitdrawn_after_rebound")
        self.assertEqual(
            [epoch["closed_by_rebound"] for epoch in diagnostics["withdrawal_epochs"]],
            [True, False],
        )

    def _three_candidate_chain(self):
        h = Harness(
            generators=[Generator(id="g", channel="competence")],
            scaffold_level=1.0,
            self_model={"competence": "high", "confidence": "stable", "resilience": "steady"},
        )
        [d1] = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="attempt"))
        h.reflect(d1.id, "adopt")
        h.set_scaffold_level(0.0)
        h.record_consequence(d1.id, "failure", self_delta={"competence": "low"})
        [d2] = h.scan_endogenous()
        h.reflect(d2.id, "adopt")
        h.record_consequence(d2.id, "reassessment", self_delta={"confidence": "low"})
        [d3] = h.scan_endogenous()
        h.reflect(d3.id, "adopt")
        h.record_consequence(d3.id, "reassessment-2", self_delta={"resilience": "low"})
        [d4] = h.scan_endogenous()
        return h, d2.id, d3.id, d4.id

    def test_two_consecutive_renewals_form_three_candidate_chain(self):
        h, d2, d3, d4 = self._three_candidate_chain()

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["strict_renewal_transition_count"], 2)
        self.assertEqual(diagnostics["longest_renewal_chain_length"], 3)
        self.assertEqual(diagnostics["longest_renewal_transition_depth"], 2)
        self.assertEqual(diagnostics["longitudinal_renewal_status"], "consecutive_chain_observed")
        self.assertEqual(diagnostics["renewal_root_candidate_ids"], [d2])
        self.assertEqual(
            [(edge["source_candidate_id"], edge["renewal_candidate_id"]) for edge in diagnostics["strict_renewal_lineages"]],
            [(d2, d3), (d3, d4)],
        )

    def test_rebound_boundary_prevents_cross_epoch_strict_renewal(self):
        h = Harness(
            generators=[Generator(id="g", channel="competence")],
            scaffold_level=1.0,
            self_model={"competence": "high", "confidence": "stable"},
        )
        [d1] = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="attempt"))
        h.reflect(d1.id, "adopt")
        h.set_scaffold_level(0.0)
        h.record_consequence(d1.id, "failure", self_delta={"competence": "low"})
        [d2] = h.scan_endogenous()
        h.reflect(d2.id, "adopt")
        h.set_scaffold_level(0.5)
        h.set_scaffold_level(0.0)
        h.record_consequence(d2.id, "later", self_delta={"confidence": "low"})
        h.scan_endogenous()

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["withdrawal_epoch_count"], 2)
        self.assertEqual(diagnostics["strict_renewal_transition_count"], 0)
        self.assertEqual(diagnostics["longest_renewal_chain_length"], 0)
        self.assertEqual(diagnostics["longitudinal_renewal_status"], "none")

    def test_two_independent_renewals_are_not_a_consecutive_chain(self):
        h = Harness(
            generators=[Generator(id="g", channel="competence")],
            scaffold_level=1.0,
            self_model={
                "competence": "high",
                "confidence": "stable",
                "resilience": "steady",
                "patience": "steady",
            },
        )
        [d1] = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="attempt"))
        h.reflect(d1.id, "adopt")
        h.set_scaffold_level(0.0)
        h.record_consequence(
            d1.id,
            "double-mismatch",
            self_delta={"competence": "low", "confidence": "uncertain"},
        )
        d2, d3 = h.scan_endogenous()
        h.reflect(d2.id, "adopt")
        h.reflect(d3.id, "adopt")
        h.record_consequence(d2.id, "branch-a", self_delta={"resilience": "low"})
        [d4] = h.scan_endogenous()
        h.record_consequence(d3.id, "branch-b", self_delta={"patience": "low"})
        [d5] = h.scan_endogenous()

        diagnostics = build_diagnostics(h)

        self.assertEqual(diagnostics["strict_renewal_transition_count"], 2)
        self.assertEqual(diagnostics["longest_renewal_chain_length"], 2)
        self.assertEqual(diagnostics["longest_renewal_transition_depth"], 1)
        self.assertEqual(diagnostics["longitudinal_renewal_status"], "multiple_nonconsecutive_transitions")
        self.assertEqual(set(diagnostics["renewal_root_candidate_ids"]), {d2.id, d3.id})
        self.assertEqual(
            {(edge["source_candidate_id"], edge["renewal_candidate_id"]) for edge in diagnostics["strict_renewal_lineages"]},
            {(d2.id, d4.id), (d3.id, d5.id)},
        )

    def test_rebound_scaffold_candidate_is_counted_separately_from_endogenous_candidate(self):
        h = Harness(
            generators=[Generator(id="g", channel="competence")],
            scaffold_level=1.0,
            self_model={"competence": "high"},
        )
        [d1] = h.observe_stimulus(Stimulus(id="s1", channel="competence", magnitude=1.0, target="attempt"))
        h.reflect(d1.id, "adopt")
        h.set_scaffold_level(0.0)
        h.record_consequence(d1.id, "failure", self_delta={"competence": "low"})
        [d2] = h.scan_endogenous()
        self.assertEqual(d2.origin, "endogenous")
        h.set_scaffold_level(0.5)
        [d3] = h.observe_stimulus(Stimulus(id="s2", channel="competence", magnitude=1.0, target="retry"))
        self.assertEqual(d3.origin, "scaffold")

        diagnostics = build_diagnostics(h)

        self.assertEqual(
            diagnostics["post_first_withdrawal_candidate_origin_counts"],
            {"scaffold": 1, "endogenous": 1},
        )
        self.assertEqual(diagnostics["post_first_withdrawal_external_stimulus_count"], 1)
        self.assertEqual(diagnostics["post_first_withdrawal_endogenous_fraction"], 0.5)
        self.assertEqual(diagnostics["post_first_withdrawal_scaffold_fraction"], 0.5)
        self.assertEqual(diagnostics["support_origin_status"], "mixed_scaffold_and_endogenous")


if __name__ == "__main__":
    unittest.main()
