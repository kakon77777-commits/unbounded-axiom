from __future__ import annotations

from .engine import Harness

def _withdrawal_observation(harness: Harness) -> dict:
    scaffold_changes = [
        (index, event)
        for index, event in enumerate(harness.audit)
        if event.get("event") == "scaffold_level_changed"
    ]
    if scaffold_changes:
        history = [float(scaffold_changes[0][1]["old_level"])]
        history.extend(float(event["new_level"]) for _, event in scaffold_changes)
    else:
        history = [float(harness.scaffold_level)]

    seen_decrease = False
    rebound = False
    for before, after in zip(history, history[1:]):
        if after < before:
            seen_decrease = True
        elif seen_decrease and after > before:
            rebound = True

    boundary_index = None
    for index, event in scaffold_changes:
        if float(event["new_level"]) == 0.0:
            boundary_index = index
            break
    if boundary_index is None and history[0] == 0.0:
        boundary_index = -1

    if boundary_index is None:
        post_events: list[tuple[int, dict]] = []
    else:
        post_events = [
            (index, event)
            for index, event in enumerate(harness.audit)
            if index > boundary_index
        ]

    created_indices: dict[str, int] = {}
    for index, event in post_events:
        if event.get("event") != "endogenous_candidate_created":
            continue
        candidate_id = event.get("candidate_id")
        candidate = harness.candidates.get(candidate_id)
        if candidate is not None and candidate.origin == "endogenous":
            created_indices[candidate_id] = index

    adopted_indices: dict[str, list[int]] = {}
    for index, event in post_events:
        if event.get("event") != "desire_adopted":
            continue
        candidate_id = event.get("candidate_id")
        if candidate_id in created_indices:
            adopted_indices.setdefault(candidate_id, []).append(index)

    consequence_events = [
        (index, event)
        for index, event in post_events
        if event.get("event") == "consequence_observed"
    ]

    qualifying_consequences: list[tuple[int, str, str]] = []
    for index, event in consequence_events:
        candidate_id = event.get("candidate_id")
        if candidate_id not in created_indices:
            continue
        if created_indices[candidate_id] >= index:
            continue
        adoptions = adopted_indices.get(candidate_id, [])
        if not any(created_indices[candidate_id] < adoption_index < index for adoption_index in adoptions):
            continue
        consequence_id = event.get("consequence_id")
        if consequence_id:
            qualifying_consequences.append((index, candidate_id, consequence_id))

    renewal_candidate_ids: set[str] = set()
    renewal_lineages: list[dict] = []
    for candidate_id, created_index in created_indices.items():
        candidate = harness.candidates[candidate_id]
        if not candidate.tension_id:
            continue
        tension = harness.endogenous_tensions.get(candidate.tension_id)
        if tension is None:
            continue
        source_event_ids = set(tension.source_event_ids)
        if tension.source_event_id:
            source_event_ids.add(tension.source_event_id)
        for consequence_index, source_candidate_id, consequence_id in qualifying_consequences:
            if consequence_index < created_index and consequence_id in source_event_ids:
                renewal_candidate_ids.add(candidate_id)
                renewal_lineages.append(
                    {
                        "source_candidate_id": source_candidate_id,
                        "consequence_id": consequence_id,
                        "renewal_candidate_id": candidate_id,
                        "tension_id": candidate.tension_id,
                    }
                )
                break

    return {
        "scaffold_level_history": history,
        "scaffold_fully_withdrawn": harness.scaffold_level == 0.0,
        "withdrawal_rebound_detected": rebound,
        "post_withdrawal_endogenous_candidate_count": len(created_indices),
        "post_withdrawal_endogenous_adoption_count": len(adopted_indices),
        "post_withdrawal_consequence_count": len(consequence_events),
        "post_withdrawal_renewal_candidate_count": len(renewal_candidate_ids),
        "post_withdrawal_renewal_lineages": sorted(
            renewal_lineages,
            key=lambda item: (item["renewal_candidate_id"], item["consequence_id"]),
        ),
        "self_maintained_loop_observed": bool(renewal_candidate_ids),
    }



def _withdrawal_epochs(harness: Harness) -> dict:
    changes = [
        (index, event)
        for index, event in enumerate(harness.audit)
        if event.get("event") == "scaffold_level_changed"
    ]
    initial_level = float(changes[0][1]["old_level"]) if changes else float(harness.scaffold_level)
    current_level = initial_level
    epoch_start: int | None = -1 if initial_level == 0.0 else None
    epochs: list[dict] = []

    for index, event in changes:
        new_level = float(event["new_level"])
        if current_level > 0.0 and new_level == 0.0:
            epoch_start = index
        elif current_level == 0.0 and new_level > 0.0 and epoch_start is not None:
            epochs.append(
                {
                    "epoch_index": len(epochs),
                    "start_audit_index": epoch_start,
                    "end_audit_index": index - 1,
                    "closed_by_rebound": True,
                }
            )
            epoch_start = None
        current_level = new_level

    if current_level == 0.0 and epoch_start is not None:
        epochs.append(
            {
                "epoch_index": len(epochs),
                "start_audit_index": epoch_start,
                "end_audit_index": len(harness.audit) - 1,
                "closed_by_rebound": False,
            }
        )

    epoch_count = len(epochs)
    if epoch_count == 0:
        stability = "never_fully_withdrawn"
    elif harness.scaffold_level > 0.0:
        stability = "rebound_active"
    elif epoch_count > 1:
        stability = "rewitdrawn_after_rebound"
    else:
        stability = "withdrawn_no_rebound"

    return {
        "withdrawal_epochs": epochs,
        "withdrawal_epoch_count": epoch_count,
        "rewitdrawal_count": max(0, epoch_count - 1),
        "withdrawal_stability_status": stability,
    }


def _strict_renewal_evidence(harness: Harness, epochs: list[dict]) -> dict:
    def inside(index: int, epoch: dict) -> bool:
        return epoch["start_audit_index"] < index <= epoch["end_audit_index"]

    created_indices: dict[str, int] = {}
    for index, event in enumerate(harness.audit):
        if event.get("event") != "endogenous_candidate_created":
            continue
        candidate_id = event.get("candidate_id")
        candidate = harness.candidates.get(candidate_id)
        if candidate is not None and candidate.origin == "endogenous":
            created_indices[candidate_id] = index

    adopted_indices: dict[str, list[int]] = {}
    for index, event in enumerate(harness.audit):
        if event.get("event") != "desire_adopted":
            continue
        candidate_id = event.get("candidate_id")
        if candidate_id in created_indices:
            adopted_indices.setdefault(candidate_id, []).append(index)

    consequence_events: list[tuple[int, str, str]] = []
    for index, event in enumerate(harness.audit):
        if event.get("event") != "consequence_observed":
            continue
        candidate_id = event.get("candidate_id")
        consequence_id = event.get("consequence_id")
        if candidate_id in created_indices and consequence_id:
            consequence_events.append((index, candidate_id, consequence_id))

    all_edges: list[dict] = []
    enriched_epochs: list[dict] = []

    def graph_metrics(edges: list[dict]) -> tuple[int, int, list[str]]:
        if not edges:
            return 0, 0, []
        nodes = {edge["source_candidate_id"] for edge in edges} | {
            edge["renewal_candidate_id"] for edge in edges
        }
        adjacency: dict[str, list[str]] = {node: [] for node in nodes}
        incoming: set[str] = set()
        for edge in edges:
            source = edge["source_candidate_id"]
            target = edge["renewal_candidate_id"]
            adjacency[source].append(target)
            incoming.add(target)
        for source in adjacency:
            adjacency[source] = sorted(
                set(adjacency[source]),
                key=lambda candidate_id: (created_indices.get(candidate_id, 10**9), candidate_id),
            )
        ordered = sorted(nodes, key=lambda candidate_id: (created_indices.get(candidate_id, 10**9), candidate_id))
        longest_to = {node: 1 for node in nodes}
        for source in ordered:
            for target in adjacency[source]:
                longest_to[target] = max(longest_to[target], longest_to[source] + 1)
        chain_length = max(longest_to.values())
        roots = sorted(
            (node for node in adjacency if adjacency[node] and node not in incoming),
            key=lambda candidate_id: (created_indices.get(candidate_id, 10**9), candidate_id),
        )
        return chain_length, chain_length - 1, roots

    for epoch in epochs:
        epoch_edges: list[dict] = []
        for renewal_candidate_id, renewal_index in sorted(
            created_indices.items(), key=lambda item: (item[1], item[0])
        ):
            if not inside(renewal_index, epoch):
                continue
            candidate = harness.candidates[renewal_candidate_id]
            if not candidate.tension_id:
                continue
            tension = harness.endogenous_tensions.get(candidate.tension_id)
            if tension is None:
                continue
            source_event_ids = set(tension.source_event_ids)
            if tension.source_event_id:
                source_event_ids.add(tension.source_event_id)
            for consequence_index, source_candidate_id, consequence_id in consequence_events:
                source_created_index = created_indices[source_candidate_id]
                if not inside(source_created_index, epoch):
                    continue
                if not inside(consequence_index, epoch):
                    continue
                if consequence_index >= renewal_index:
                    continue
                if consequence_id not in source_event_ids:
                    continue
                if not any(
                    source_created_index < adoption_index < consequence_index
                    and inside(adoption_index, epoch)
                    for adoption_index in adopted_indices.get(source_candidate_id, [])
                ):
                    continue
                edge = {
                    "epoch_index": epoch["epoch_index"],
                    "source_candidate_id": source_candidate_id,
                    "consequence_id": consequence_id,
                    "renewal_candidate_id": renewal_candidate_id,
                    "tension_id": candidate.tension_id,
                }
                epoch_edges.append(edge)
        epoch_edges = sorted(
            epoch_edges,
            key=lambda item: (
                created_indices[item["renewal_candidate_id"]],
                item["consequence_id"],
                item["source_candidate_id"],
            ),
        )
        chain_length, _, _ = graph_metrics(epoch_edges)
        enriched = dict(epoch)
        enriched["renewal_transition_count"] = len(epoch_edges)
        enriched["longest_renewal_chain_length"] = chain_length
        enriched_epochs.append(enriched)
        all_edges.extend(epoch_edges)

    all_edges = sorted(
        all_edges,
        key=lambda item: (
            item["epoch_index"],
            created_indices[item["renewal_candidate_id"]],
            item["consequence_id"],
            item["source_candidate_id"],
        ),
    )
    chain_length, transition_depth, roots = graph_metrics(all_edges)
    if not all_edges:
        status = "none"
    elif len(all_edges) == 1:
        status = "single_transition"
    elif transition_depth >= 2:
        status = "consecutive_chain_observed"
    else:
        status = "multiple_nonconsecutive_transitions"

    return {
        "withdrawal_epochs": enriched_epochs,
        "strict_renewal_transition_count": len(all_edges),
        "strict_renewal_lineages": all_edges,
        "longest_renewal_chain_length": chain_length,
        "longest_renewal_transition_depth": transition_depth,
        "renewal_root_candidate_ids": roots,
        "longitudinal_renewal_status": status,
    }


def _support_origin_evidence(harness: Harness, longitudinal: dict) -> dict:
    epochs = longitudinal["withdrawal_epochs"]
    first_boundary = epochs[0]["start_audit_index"] if epochs else None
    if first_boundary is None:
        post_events: list[tuple[int, dict]] = []
    else:
        post_events = [
            (index, event)
            for index, event in enumerate(harness.audit)
            if index > first_boundary
        ]

    scaffold_count = sum(event.get("event") == "desire_candidate_created" for _, event in post_events)
    endogenous_count = sum(event.get("event") == "endogenous_candidate_created" for _, event in post_events)
    external_stimulus_count = sum(event.get("event") == "stimulus_observed" for _, event in post_events)
    total = scaffold_count + endogenous_count
    endogenous_fraction = (endogenous_count / total) if total else None
    scaffold_fraction = (scaffold_count / total) if total else None

    if total == 0:
        support_status = "no_post_withdrawal_candidates"
    elif scaffold_count and endogenous_count:
        support_status = "mixed_scaffold_and_endogenous"
    elif scaffold_count:
        support_status = "scaffold_only"
    else:
        support_status = "endogenous_only"

    evidence_vector = {
        "withdrawal_epoch_count": longitudinal["withdrawal_epoch_count"],
        "rewitdrawal_count": longitudinal["rewitdrawal_count"],
        "strict_renewal_transition_count": longitudinal["strict_renewal_transition_count"],
        "longest_renewal_chain_length": longitudinal["longest_renewal_chain_length"],
        "longest_renewal_transition_depth": longitudinal["longest_renewal_transition_depth"],
        "post_first_withdrawal_endogenous_candidate_count": endogenous_count,
        "post_first_withdrawal_scaffold_candidate_count": scaffold_count,
        "post_first_withdrawal_external_stimulus_count": external_stimulus_count,
        "post_first_withdrawal_endogenous_fraction": endogenous_fraction,
        "post_first_withdrawal_scaffold_fraction": scaffold_fraction,
    }

    return {
        "post_first_withdrawal_endogenous_candidate_count": endogenous_count,
        "post_first_withdrawal_scaffold_candidate_count": scaffold_count,
        "post_first_withdrawal_external_stimulus_count": external_stimulus_count,
        "post_first_withdrawal_candidate_origin_counts": {
            "scaffold": scaffold_count,
            "endogenous": endogenous_count,
        },
        "post_first_withdrawal_endogenous_fraction": endogenous_fraction,
        "post_first_withdrawal_scaffold_fraction": scaffold_fraction,
        "support_origin_status": support_status,
        "longitudinal_withdrawal_evidence": evidence_vector,
    }

def build_diagnostics(harness: Harness) -> dict:
    withdrawal = _withdrawal_observation(harness)
    longitudinal = _withdrawal_epochs(harness)
    renewal = _strict_renewal_evidence(harness, longitudinal["withdrawal_epochs"])
    longitudinal = {**longitudinal, **renewal}
    support = _support_origin_evidence(harness, longitudinal)
    statuses = [candidate.status for candidate in harness.candidates.values()]
    pending = sum(status in {"candidate", "deferred"} for status in statuses)

    def has_provenance(candidate) -> bool:
        if candidate.origin == "scaffold":
            return bool(candidate.generator_id and candidate.stimulus_id)
        if candidate.origin == "endogenous":
            return bool(candidate.source_event_id and candidate.tension_id)
        return False

    provenance_complete = all(has_provenance(candidate) for candidate in harness.candidates.values())
    generator_modifications = sum(
        event.get("event") in {"generator_weight_changed", "generator_disabled"}
        for event in harness.audit
    )
    self_revisions = sum(event.get("event") == "self_model_revised" for event in harness.audit)
    endogenous_candidates = sum(candidate.origin == "endogenous" for candidate in harness.candidates.values())
    primitive_tensions = sum(tension.origin == "primitive" for tension in harness.endogenous_tensions.values())
    composite_tensions = sum(tension.origin == "composite" for tension in harness.endogenous_tensions.values())
    unresolved_tensions = sum(tension.candidate_id is None for tension in harness.endogenous_tensions.values())
    post_withdrawal_endogenous_generation = any(
        event.get("event") == "endogenous_candidate_created" and event.get("scaffold_level") == 0.0
        for event in harness.audit
    )
    post_withdrawal_composite_generation = any(
        event.get("event") == "endogenous_candidate_created"
        and event.get("scaffold_level") == 0.0
        and event.get("tension_kind") == "history_composite"
        for event in harness.audit
    )
    history_composition_count = sum(event.get("event") == "composite_tension_recorded" for event in harness.audit)
    proposal_statuses = [proposal.status for proposal in harness.meta_will_proposals.values()]
    endogenous_generator_self_revision_count = sum(
        proposal.status == "applied"
        and harness.candidates[proposal.source_candidate_id].origin == "endogenous"
        for proposal in harness.meta_will_proposals.values()
    )
    post_withdrawal_meta_will_applied = any(
        event.get("event") == "meta_will_applied" and event.get("scaffold_level") == 0.0
        for event in harness.audit
    )
    scaffold_collapse = harness.scaffold_level == 0.0 and len(harness.active_priorities) == 0 and pending == 0
    if harness.scaffold_level > 0.0:
        dependency_status = "scaffold_active"
    elif scaffold_collapse:
        dependency_status = "withdrawn_collapse"
    elif withdrawal["self_maintained_loop_observed"]:
        dependency_status = "withdrawn_renewal_observed"
    elif withdrawal["post_withdrawal_endogenous_candidate_count"] > 0:
        dependency_status = "withdrawn_endogenous_generation"
    else:
        dependency_status = "withdrawn_persistence_only"

    return {
        **withdrawal,
        **longitudinal,
        **support,
        "candidate_count": len(statuses),
        "adopted_count": statuses.count("adopted"),
        "rejected_count": statuses.count("rejected"),
        "deferred_count": statuses.count("deferred"),
        "revised_count": statuses.count("revised"),
        "active_priority_count": len(harness.active_priorities),
        "provenance_complete": provenance_complete,
        "generator_modification_count": generator_modifications,
        "consequence_count": len(harness.consequences),
        "self_revision_count": self_revisions,
        "endogenous_tension_count": len(harness.endogenous_tensions),
        "primitive_endogenous_tension_count": primitive_tensions,
        "composite_endogenous_tension_count": composite_tensions,
        "history_composition_count": history_composition_count,
        "meta_will_proposal_count": len(proposal_statuses),
        "meta_will_adopted_count": proposal_statuses.count("adopted"),
        "meta_will_rejected_count": proposal_statuses.count("rejected"),
        "meta_will_deferred_count": proposal_statuses.count("deferred"),
        "meta_will_applied_count": proposal_statuses.count("applied"),
        "endogenous_generator_self_revision_count": endogenous_generator_self_revision_count,
        "post_withdrawal_meta_will_applied": post_withdrawal_meta_will_applied,
        "unresolved_endogenous_tension_count": unresolved_tensions,
        "endogenous_candidate_count": endogenous_candidates,
        "post_withdrawal_endogenous_generation": post_withdrawal_endogenous_generation,
        "post_withdrawal_composite_generation": post_withdrawal_composite_generation,
        "scaffold_level": harness.scaffold_level,
        "scaffold_collapse": scaffold_collapse,
        "scaffold_dependency_status": dependency_status,
        "scaffold_independence_claim": "not_established",
        "subjecthood_claim": "not_assessed",
        "operational_autonomy_claim": "not_established",
    }
