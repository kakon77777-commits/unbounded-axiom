from __future__ import annotations

from dataclasses import asdict
from typing import Any

from .diagnostics import build_diagnostics
from .engine import Harness, RWGSError
from .model import Generator, Stimulus


def _require_mapping(value: Any, label: str) -> dict:
    if not isinstance(value, dict):
        raise RWGSError(f"{label} must be an object")
    return value


def run_scenario(data: dict) -> dict:
    data = _require_mapping(data, "scenario")
    raw_generators = data.get("generators", [])
    if not isinstance(raw_generators, list):
        raise RWGSError("generators must be a list")

    ids: set[str] = set()
    generators: list[Generator] = []
    for index, raw in enumerate(raw_generators):
        raw = _require_mapping(raw, f"generators[{index}]")
        generator_id = str(raw["id"])
        if generator_id in ids:
            raise RWGSError(f"duplicate generator id: {generator_id}")
        ids.add(generator_id)
        generators.append(
            Generator(
                id=generator_id,
                channel=str(raw["channel"]),
                weight=float(raw.get("weight", 1.0)),
                enabled=bool(raw.get("enabled", True)),
            )
        )

    harness = Harness(
        generators=generators,
        scaffold_level=float(data.get("scaffold_level", 1.0)),
        self_model=_require_mapping(data.get("self_model", {}), "self_model"),
        relation_state=_require_mapping(data.get("relation_state", {}), "relation_state"),
    )

    steps = data.get("steps", [])
    if not isinstance(steps, list):
        raise RWGSError("steps must be a list")

    for index, raw_step in enumerate(steps):
        step = _require_mapping(raw_step, f"steps[{index}]")
        step_type = step.get("type")
        if step_type == "stimulus":
            harness.observe_stimulus(
                Stimulus(
                    id=str(step["id"]),
                    channel=str(step["channel"]),
                    magnitude=float(step["magnitude"]),
                    target=str(step["target"]),
                    context=_require_mapping(step.get("context", {}), f"steps[{index}].context"),
                )
            )
        elif step_type == "reflect":
            harness.reflect(
                str(step["candidate_id"]),
                str(step["operation"]),
                revision=step.get("revision"),
            )
        elif step_type == "consequence":
            harness.record_consequence(
                str(step["candidate_id"]),
                str(step["outcome"]),
                self_delta=_require_mapping(step.get("self_delta", {}), f"steps[{index}].self_delta"),
                relation_delta=_require_mapping(step.get("relation_delta", {}), f"steps[{index}].relation_delta"),
            )
        elif step_type == "set_generator_weight":
            harness.set_generator_weight(str(step["generator_id"]), float(step["weight"]))
        elif step_type == "disable_generator":
            harness.disable_generator(str(step["generator_id"]))
        elif step_type == "set_scaffold_level":
            harness.set_scaffold_level(float(step["level"]))
        elif step_type == "scan_endogenous":
            harness.scan_endogenous()
        elif step_type == "compose_endogenous":
            harness.compose_endogenous()
        elif step_type == "propose_generator_revision":
            harness.propose_generator_revision(
                str(step["candidate_id"]),
                str(step["generator_id"]),
                str(step["operation"]),
                step["value"],
                reason=step.get("reason"),
            )
        elif step_type == "review_meta_will":
            harness.review_meta_will(str(step["proposal_id"]), str(step["operation"]))
        elif step_type == "apply_meta_will":
            harness.apply_meta_will(str(step["proposal_id"]))
        else:
            raise RWGSError(f"unknown step type: {step_type!r}")

    final_state = {
        "scaffold_level": harness.scaffold_level,
        "generators": {
            generator_id: {
                "id": generator.id,
                "channel": generator.channel,
                "weight": generator.weight,
                "enabled": generator.enabled,
            }
            for generator_id, generator in sorted(harness.generators.items())
        },
        "candidates": {
            candidate_id: asdict(candidate)
            for candidate_id, candidate in sorted(harness.candidates.items())
        },
        "active_priorities": list(harness.active_priorities),
        "self_model": dict(harness.self_model),
        "relation_state": {
            subject: dict(values) for subject, values in sorted(harness.relation_state.items())
        },
        "consequences": list(harness.consequences),
        "endogenous_tensions": {
            tension_id: asdict(tension)
            for tension_id, tension in sorted(harness.endogenous_tensions.items())
        },
        "meta_will_proposals": {
            proposal_id: asdict(proposal)
            for proposal_id, proposal in sorted(harness.meta_will_proposals.items())
        },
    }
    return {
        "name": str(data.get("name", "unnamed")),
        "final_state": final_state,
        "diagnostics": build_diagnostics(harness),
        "audit": list(harness.audit),
    }
