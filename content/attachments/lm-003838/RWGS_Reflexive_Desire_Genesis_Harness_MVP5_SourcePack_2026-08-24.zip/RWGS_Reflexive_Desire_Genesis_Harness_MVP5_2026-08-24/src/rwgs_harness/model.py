from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Stimulus:
    id: str
    channel: str
    magnitude: float
    target: str
    context: dict[str, Any] = field(default_factory=dict)


@dataclass
class Generator:
    id: str
    channel: str
    weight: float = 1.0
    enabled: bool = True

    def __post_init__(self) -> None:
        if not 0.0 <= self.weight <= 1.0:
            raise ValueError("generator weight must be within [0,1]")


@dataclass
class EndogenousTension:
    id: str
    kind: str
    source_candidate_id: str | None
    source_event_id: str | None
    key: str
    before: Any
    after: Any
    target: str
    magnitude: float = 1.0
    candidate_id: str | None = None
    origin: str = "primitive"
    concept: str | None = None
    component_tension_ids: list[str] = field(default_factory=list)
    source_event_ids: list[str] = field(default_factory=list)
    source_candidate_ids: list[str] = field(default_factory=list)
    context_candidate_ids: list[str] = field(default_factory=list)


@dataclass
class MetaWillProposal:
    id: str
    source_candidate_id: str
    generator_id: str
    operation: str
    value: Any
    status: str = "proposed"
    reason: str | None = None


@dataclass
class DesireCandidate:
    id: str
    origin: str
    generator_id: str | None
    stimulus_id: str | None
    target: str
    intensity: float
    status: str = "candidate"
    parent_id: str | None = None
    revision_reason: str | None = None
    revision_note: str | None = None
    source_event_id: str | None = None
    tension_id: str | None = None
    concept: str | None = None
