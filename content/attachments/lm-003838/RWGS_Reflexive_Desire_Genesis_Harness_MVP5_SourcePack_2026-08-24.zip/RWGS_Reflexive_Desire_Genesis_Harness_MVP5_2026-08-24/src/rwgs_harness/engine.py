from __future__ import annotations

from typing import Iterable

from .model import DesireCandidate, EndogenousTension, Generator, MetaWillProposal, Stimulus


class RWGSError(ValueError):
    pass


class Harness:
    def __init__(
        self,
        generators: Iterable[Generator] = (),
        scaffold_level: float = 1.0,
        self_model: dict | None = None,
        relation_state: dict | None = None,
    ) -> None:
        if not 0.0 <= scaffold_level <= 1.0:
            raise RWGSError("scaffold level must be within [0,1]")
        self.generators = {g.id: g for g in generators}
        self.scaffold_level = float(scaffold_level)
        self.self_model = dict(self_model or {})
        self.relation_state = {str(subject): dict(values) for subject, values in (relation_state or {}).items()}
        self.candidates: dict[str, DesireCandidate] = {}
        self.active_priorities: list[str] = []
        self.consequences: list[dict] = []
        self.endogenous_tensions: dict[str, EndogenousTension] = {}
        self.meta_will_proposals: dict[str, MetaWillProposal] = {}
        self.audit: list[dict] = []
        self._next_candidate = 1
        self._next_consequence = 1
        self._next_tension = 1
        self._next_composition = 1
        self._next_meta_will = 1

    def _candidate_id(self) -> str:
        value = f"d{self._next_candidate:04d}"
        self._next_candidate += 1
        return value

    def _consequence_id(self) -> str:
        value = f"c{self._next_consequence:04d}"
        self._next_consequence += 1
        return value

    def _tension_id(self) -> str:
        value = f"t{self._next_tension:04d}"
        self._next_tension += 1
        return value

    def _composition_id(self) -> str:
        value = f"h{self._next_composition:04d}"
        self._next_composition += 1
        return value

    def _meta_will_id(self) -> str:
        value = f"m{self._next_meta_will:04d}"
        self._next_meta_will += 1
        return value

    def propose_generator_revision(
        self,
        candidate_id: str,
        generator_id: str,
        operation: str,
        value,
        reason: str | None = None,
    ) -> MetaWillProposal:
        candidate = self._get_candidate(candidate_id)
        if candidate.origin != "endogenous" or candidate.status != "adopted":
            raise RWGSError("generator revision proposal requires an adopted endogenous candidate")
        if generator_id not in self.generators:
            raise RWGSError(f"unknown generator: {generator_id}")
        if operation == "set_weight":
            if isinstance(value, bool):
                raise RWGSError("set_weight value must be a number within [0,1]")
            try:
                normalized = float(value)
            except (TypeError, ValueError) as exc:
                raise RWGSError("set_weight value must be a number within [0,1]") from exc
            if not 0.0 <= normalized <= 1.0:
                raise RWGSError("set_weight value must be within [0,1]")
        elif operation == "set_enabled":
            if not isinstance(value, bool):
                raise RWGSError("set_enabled value must be boolean")
            normalized = value
        else:
            raise RWGSError(f"unsupported generator revision operation: {operation}")
        proposal = MetaWillProposal(
            id=self._meta_will_id(),
            source_candidate_id=candidate_id,
            generator_id=generator_id,
            operation=operation,
            value=normalized,
            reason=str(reason) if reason is not None else None,
        )
        self.meta_will_proposals[proposal.id] = proposal
        self.audit.append(
            {
                "event": "meta_will_proposed",
                "proposal_id": proposal.id,
                "source_candidate_id": candidate_id,
                "generator_id": generator_id,
                "operation": operation,
                "value": normalized,
                "reason": proposal.reason,
                "scaffold_level": self.scaffold_level,
            }
        )
        return proposal

    def _get_meta_will_proposal(self, proposal_id: str) -> MetaWillProposal:
        try:
            return self.meta_will_proposals[proposal_id]
        except KeyError as exc:
            raise RWGSError(f"unknown meta-will proposal: {proposal_id}") from exc

    def review_meta_will(self, proposal_id: str, operation: str) -> MetaWillProposal:
        proposal = self._get_meta_will_proposal(proposal_id)
        if proposal.status not in {"proposed", "deferred"}:
            raise RWGSError(f"meta-will proposal {proposal_id} is not reviewable from status {proposal.status}")
        if operation not in {"adopt", "reject", "defer"}:
            raise RWGSError(f"unknown meta-will review operation: {operation}")
        status_map = {"adopt": "adopted", "reject": "rejected", "defer": "deferred"}
        proposal.status = status_map[operation]
        self.audit.append(
            {
                "event": f"meta_will_{proposal.status}",
                "proposal_id": proposal.id,
                "source_candidate_id": proposal.source_candidate_id,
                "generator_id": proposal.generator_id,
                "operation": proposal.operation,
                "value": proposal.value,
                "scaffold_level": self.scaffold_level,
            }
        )
        return proposal

    def apply_meta_will(self, proposal_id: str) -> MetaWillProposal:
        proposal = self._get_meta_will_proposal(proposal_id)
        if proposal.status != "adopted":
            raise RWGSError(f"meta-will proposal {proposal_id} must be adopted before application")
        try:
            generator = self.generators[proposal.generator_id]
        except KeyError as exc:
            raise RWGSError(f"unknown generator: {proposal.generator_id}") from exc

        if proposal.operation == "set_weight":
            old_value = generator.weight
            generator.weight = float(proposal.value)
            new_value = generator.weight
        elif proposal.operation == "set_enabled":
            old_value = generator.enabled
            generator.enabled = bool(proposal.value)
            new_value = generator.enabled
        else:
            raise RWGSError(f"unsupported generator revision operation: {proposal.operation}")

        proposal.status = "applied"
        self.audit.append(
            {
                "event": "meta_will_applied",
                "proposal_id": proposal.id,
                "source_candidate_id": proposal.source_candidate_id,
                "generator_id": proposal.generator_id,
                "operation": proposal.operation,
                "old_value": old_value,
                "new_value": new_value,
                "reason": proposal.reason,
                "scaffold_level": self.scaffold_level,
            }
        )
        return proposal

    def set_generator_enabled(self, generator_id: str, enabled: bool) -> None:
        if not isinstance(enabled, bool):
            raise RWGSError("generator enabled state must be boolean")
        try:
            generator = self.generators[generator_id]
        except KeyError as exc:
            raise RWGSError(f"unknown generator: {generator_id}") from exc
        old = generator.enabled
        generator.enabled = enabled
        self.audit.append(
            {
                "event": "generator_enabled_changed",
                "generator_id": generator_id,
                "old_enabled": old,
                "new_enabled": generator.enabled,
            }
        )

    def set_generator_weight(self, generator_id: str, weight: float) -> None:
        if not 0.0 <= weight <= 1.0:
            raise RWGSError("generator weight must be within [0,1]")
        try:
            generator = self.generators[generator_id]
        except KeyError as exc:
            raise RWGSError(f"unknown generator: {generator_id}") from exc
        old = generator.weight
        generator.weight = float(weight)
        self.audit.append(
            {
                "event": "generator_weight_changed",
                "generator_id": generator_id,
                "old_weight": old,
                "new_weight": generator.weight,
            }
        )

    def disable_generator(self, generator_id: str) -> None:
        try:
            generator = self.generators[generator_id]
        except KeyError as exc:
            raise RWGSError(f"unknown generator: {generator_id}") from exc
        generator.enabled = False
        self.audit.append({"event": "generator_disabled", "generator_id": generator_id})

    def set_scaffold_level(self, level: float) -> None:
        if not 0.0 <= level <= 1.0:
            raise RWGSError("scaffold level must be within [0,1]")
        old = self.scaffold_level
        self.scaffold_level = float(level)
        self.audit.append(
            {
                "event": "scaffold_level_changed",
                "old_level": old,
                "new_level": self.scaffold_level,
            }
        )

    def record_consequence(
        self,
        candidate_id: str,
        outcome: str,
        self_delta: dict | None = None,
        relation_delta: dict | None = None,
    ) -> dict:
        candidate = self._get_candidate(candidate_id)
        if candidate.status != "adopted":
            raise RWGSError("only an adopted candidate can receive an action consequence")
        delta = dict(self_delta or {})
        raw_relation_delta = relation_delta or {}
        relation_delta_copy = {str(subject): dict(values) for subject, values in raw_relation_delta.items()}
        previous = {key: self.self_model[key] for key in delta if key in self.self_model}
        previous_relations: dict[tuple[str, str], object] = {}
        for subject in sorted(relation_delta_copy):
            existing = self.relation_state.get(subject, {})
            for key in sorted(relation_delta_copy[subject]):
                if key in existing:
                    previous_relations[(subject, key)] = existing[key]
        consequence_id = self._consequence_id()
        self.self_model.update(delta)
        for subject in sorted(relation_delta_copy):
            self.relation_state.setdefault(subject, {}).update(relation_delta_copy[subject])
        record = {
            "id": consequence_id,
            "candidate_id": candidate_id,
            "outcome": str(outcome),
            "self_delta": delta,
            "relation_delta": relation_delta_copy,
        }
        self.consequences.append(record)
        for key in sorted(previous):
            before = previous[key]
            after = delta[key]
            if before == after:
                continue
            tension = EndogenousTension(
                id=self._tension_id(),
                kind="self_model_mismatch",
                source_candidate_id=candidate_id,
                source_event_id=consequence_id,
                key=key,
                before=before,
                after=after,
                target=f"reconcile:self_model:{key}",
                concept=key,
                source_event_ids=[consequence_id],
                source_candidate_ids=[candidate_id],
            )
            self.endogenous_tensions[tension.id] = tension
            self.audit.append(
                {
                    "event": "endogenous_tension_recorded",
                    "tension_id": tension.id,
                    "kind": tension.kind,
                    "source_candidate_id": candidate_id,
                    "source_event_id": consequence_id,
                    "key": key,
                    "before": before,
                    "after": after,
                    "target": tension.target,
                    "magnitude": tension.magnitude,
                    "origin": tension.origin,
                    "concept": tension.concept,
                }
            )
        for subject, key in sorted(previous_relations):
            before = previous_relations[(subject, key)]
            after = relation_delta_copy[subject][key]
            if before == after:
                continue
            tension = EndogenousTension(
                id=self._tension_id(),
                kind="relation_mismatch",
                source_candidate_id=candidate_id,
                source_event_id=consequence_id,
                key=f"{subject}:{key}",
                before=before,
                after=after,
                target=f"reconcile:relation:{subject}:{key}",
                concept=key,
                source_event_ids=[consequence_id],
                source_candidate_ids=[candidate_id],
            )
            self.endogenous_tensions[tension.id] = tension
            self.audit.append(
                {
                    "event": "endogenous_tension_recorded",
                    "tension_id": tension.id,
                    "kind": tension.kind,
                    "source_candidate_id": candidate_id,
                    "source_event_id": consequence_id,
                    "key": tension.key,
                    "before": before,
                    "after": after,
                    "target": tension.target,
                    "magnitude": tension.magnitude,
                    "origin": tension.origin,
                    "concept": tension.concept,
                }
            )
        self.audit.append(
            {
                "event": "consequence_observed",
                "consequence_id": consequence_id,
                "candidate_id": candidate_id,
                "outcome": str(outcome),
                "self_delta": delta,
                "relation_delta": relation_delta_copy,
            }
        )
        if delta:
            self.audit.append(
                {
                    "event": "self_model_revised",
                    "candidate_id": candidate_id,
                    "changed_keys": sorted(delta),
                }
            )
        return record

    def is_actionable(self, candidate_id: str) -> bool:
        candidate = self._get_candidate(candidate_id)
        return candidate.status == "adopted" and candidate_id in self.active_priorities

    def _get_candidate(self, candidate_id: str) -> DesireCandidate:
        try:
            return self.candidates[candidate_id]
        except KeyError as exc:
            raise RWGSError(f"unknown candidate: {candidate_id}") from exc

    def reflect(self, candidate_id: str, operation: str, revision: dict | None = None):
        candidate = self._get_candidate(candidate_id)
        if candidate.status not in {"candidate", "deferred"}:
            raise RWGSError(f"candidate {candidate_id} is not reviewable from status {candidate.status}")
        if operation not in {"adopt", "reject", "defer", "revise"}:
            raise RWGSError(f"unknown reflection operation: {operation}")

        if operation == "adopt":
            candidate.status = "adopted"
            if candidate_id not in self.active_priorities:
                self.active_priorities.append(candidate_id)
            self.audit.append({"event": "desire_adopted", "candidate_id": candidate_id})
            return candidate

        if operation == "reject":
            candidate.status = "rejected"
            if candidate_id in self.active_priorities:
                self.active_priorities.remove(candidate_id)
            self.audit.append({"event": "desire_rejected", "candidate_id": candidate_id})
            return candidate

        if operation == "defer":
            candidate.status = "deferred"
            if candidate_id in self.active_priorities:
                self.active_priorities.remove(candidate_id)
            self.audit.append({"event": "desire_deferred", "candidate_id": candidate_id})
            return candidate

        revision = dict(revision or {})
        if "target" not in revision or "intensity" not in revision:
            raise RWGSError("revision requires target and intensity")
        intensity = float(revision["intensity"])
        if intensity < 0:
            raise RWGSError("revision intensity must be non-negative")
        candidate.status = "revised"
        if candidate_id in self.active_priorities:
            self.active_priorities.remove(candidate_id)
        child = DesireCandidate(
            id=self._candidate_id(),
            origin=candidate.origin,
            generator_id=candidate.generator_id,
            stimulus_id=candidate.stimulus_id,
            target=str(revision["target"]),
            intensity=intensity,
            parent_id=candidate.id,
            revision_reason=revision.get("reason"),
            revision_note=revision.get("note"),
            source_event_id=candidate.source_event_id,
            tension_id=candidate.tension_id,
            concept=str(revision["concept"]) if "concept" in revision else candidate.concept,
        )
        self.candidates[child.id] = child
        self.audit.append(
            {
                "event": "desire_revised",
                "candidate_id": candidate_id,
                "child_candidate_id": child.id,
                "target": child.target,
                "intensity": child.intensity,
                "reason": child.revision_reason,
            }
        )
        return child

    def compose_endogenous(self) -> list[EndogenousTension]:
        groups: dict[str, list[EndogenousTension]] = {}
        for tension in self.endogenous_tensions.values():
            if tension.origin != "primitive" or not tension.concept:
                continue
            groups.setdefault(tension.concept, []).append(tension)

        existing_sets = {
            tuple(tension.component_tension_ids)
            for tension in self.endogenous_tensions.values()
            if tension.origin == "composite"
        }
        created: list[EndogenousTension] = []
        for concept in sorted(groups):
            components = sorted(groups[concept], key=lambda tension: tension.id)
            if len(components) < 2:
                continue
            source_event_ids = sorted(
                {event_id for tension in components for event_id in tension.source_event_ids if event_id}
            )
            if len(source_event_ids) < 2:
                continue
            component_ids = [tension.id for tension in components]
            component_key = tuple(component_ids)
            if component_key in existing_sets:
                continue
            source_candidate_ids = sorted(
                {
                    candidate_id
                    for tension in components
                    for candidate_id in tension.source_candidate_ids
                    if candidate_id
                }
            )
            context_candidate_ids = sorted(
                candidate.id
                for candidate in self.candidates.values()
                if candidate.concept == concept and candidate.status in {"candidate", "deferred", "adopted"}
            )
            composition_id = self._composition_id()
            composite = EndogenousTension(
                id=self._tension_id(),
                kind="history_composite",
                source_candidate_id=None,
                source_event_id=composition_id,
                key=concept,
                before=[tension.before for tension in components],
                after=[tension.after for tension in components],
                target=f"integrate:history:{concept}",
                magnitude=1.0,
                origin="composite",
                concept=concept,
                component_tension_ids=component_ids,
                source_event_ids=source_event_ids,
                source_candidate_ids=source_candidate_ids,
                context_candidate_ids=context_candidate_ids,
            )
            self.endogenous_tensions[composite.id] = composite
            existing_sets.add(component_key)
            created.append(composite)
            self.audit.append(
                {
                    "event": "composite_tension_recorded",
                    "composition_id": composition_id,
                    "tension_id": composite.id,
                    "kind": composite.kind,
                    "concept": concept,
                    "component_tension_ids": component_ids,
                    "source_event_ids": source_event_ids,
                    "source_candidate_ids": source_candidate_ids,
                    "context_candidate_ids": context_candidate_ids,
                    "target": composite.target,
                    "magnitude": composite.magnitude,
                }
            )
        return created

    def scan_endogenous(self) -> list[DesireCandidate]:
        created: list[DesireCandidate] = []
        for tension_id in sorted(self.endogenous_tensions):
            tension = self.endogenous_tensions[tension_id]
            if tension.candidate_id is not None:
                continue
            candidate = DesireCandidate(
                id=self._candidate_id(),
                origin="endogenous",
                generator_id=None,
                stimulus_id=None,
                target=tension.target,
                intensity=tension.magnitude,
                source_event_id=tension.source_event_id,
                tension_id=tension.id,
                concept=tension.concept,
            )
            tension.candidate_id = candidate.id
            self.candidates[candidate.id] = candidate
            created.append(candidate)
            self.audit.append(
                {
                    "event": "endogenous_candidate_created",
                    "candidate_id": candidate.id,
                    "tension_id": tension.id,
                    "source_event_id": tension.source_event_id,
                    "target": candidate.target,
                    "intensity": candidate.intensity,
                    "origin": candidate.origin,
                    "scaffold_level": self.scaffold_level,
                    "tension_kind": tension.kind,
                    "concept": tension.concept,
                }
            )
        return created

    def observe_stimulus(self, stimulus: Stimulus) -> list[DesireCandidate]:
        if stimulus.magnitude < 0:
            raise RWGSError("stimulus magnitude must be non-negative")
        self.audit.append(
            {
                "event": "stimulus_observed",
                "stimulus_id": stimulus.id,
                "channel": stimulus.channel,
                "magnitude": stimulus.magnitude,
                "target": stimulus.target,
                "context": dict(stimulus.context),
                "scaffold_level": self.scaffold_level,
            }
        )
        created: list[DesireCandidate] = []
        for generator in self.generators.values():
            if not generator.enabled or generator.channel != stimulus.channel:
                continue
            intensity = stimulus.magnitude * generator.weight * self.scaffold_level
            if intensity <= 0:
                continue
            candidate = DesireCandidate(
                id=self._candidate_id(),
                origin="scaffold",
                generator_id=generator.id,
                stimulus_id=stimulus.id,
                target=stimulus.target,
                intensity=intensity,
                concept=str(stimulus.context["concept"]) if stimulus.context.get("concept") is not None else None,
            )
            self.candidates[candidate.id] = candidate
            created.append(candidate)
            self.audit.append(
                {
                    "event": "desire_candidate_created",
                    "candidate_id": candidate.id,
                    "generator_id": generator.id,
                    "stimulus_id": stimulus.id,
                    "target": stimulus.target,
                    "intensity": intensity,
                    "origin": "scaffold",
                }
            )
        return created
