from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from .engine import RWGSError
from .scenario import run_scenario


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run a deterministic RWGS MVP-3 scenario")
    parser.add_argument("scenario", type=Path)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args(argv)

    try:
        data = json.loads(args.scenario.read_text(encoding="utf-8"))
        result = run_scenario(data)
    except (OSError, json.JSONDecodeError, RWGSError, KeyError, TypeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    if args.pretty:
        text = json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2)
    else:
        text = json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    print(text)
    return 0
