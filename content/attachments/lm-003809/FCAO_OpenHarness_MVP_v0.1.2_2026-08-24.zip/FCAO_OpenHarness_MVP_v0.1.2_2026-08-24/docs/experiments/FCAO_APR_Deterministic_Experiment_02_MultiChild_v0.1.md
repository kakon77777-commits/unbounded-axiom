# FCAO + APR Deterministic Experiment 02
## Primary–Twin–APR 在三個直接子 Agent 的 Fan-Out / Fan-In 條件下之可重現基線

**Document ID:** EML-FCAO-EXP-02-v0.1  
**Runtime:** FCAO-OpenHarness MVP v0.1.2  
**Date:** 2026-08-24  
**Evidence Class:** Deterministic reconstruction / pre-operational benchmark  
**Not a claim of:** live OpenHarness child execution, recursive child delegation, local Twin, production multi-agent speedup

---

## 1. 實驗目的

Experiment 01 已將變因固定在：

$$
Primary + Twin + APR + SingleTopology + 0\ Child.
$$

Experiment 02 只增加一個核心變因：

$$
N_{child}=3.
$$

因此本輪測試：

$$
\boxed{
Primary + Twin + APR + DirectChildren(3)
}
$$

並刻意保持：

$$
RecursiveChildren=0,
$$

$$
LocalTwins=0.
$$

本輪的問題不是「多子 AI 是否已經比單 AI 更快」，而是先驗證：

1. 多個 child 是否能保存獨立 machine ID、ephemeral name、task 與 parent lineage；
2. fan-out / fan-in 是否成為 canonical state，而不是只存在 prompt；
3. 每個 child 是否能透過 LCC 向上閉合自己的局部責任；
4. APR 是否能對不同 child evidence 做不同 observation decision；
5. 跨 child 的 contradiction / conflict 是否能阻止 merge 與 global closure；
6. Twin 是否能在 conflict 存在時 `CHALLENGE`，解決後才 `CONCUR`；
7. 所有治理狀態是否能由 SQLite event stream deterministic replay。

---

## 2. 實驗拓樸

Primary：

- `primary-1`

Twin：

- `twin-1`

Direct children：

| FCAO Agent ID | Ephemeral Name | Task | Parent |
|---|---|---|---|
| `child-atlas` | Atlas | `task-atlas` / Structure Extraction | `primary-1` |
| `child-kepler` | Kepler | `task-kepler` / Constraint Analysis | `primary-1` |
| `child-curie` | Curie | `task-curie` / Evidence Synthesis | `primary-1` |

因此：

$$
Primary
\rightarrow
\{Atlas,Kepler,Curie\}.
$$

但不存在：

$$
Atlas\rightarrow A_{1,1}
$$

之類的 recursive spawn。

---

## 3. Single control 仍然保留

E2 沒有把 multi-agent 設為硬編碼答案。

同一個 deterministic scheduler 先跑一個 tiny-task control：

$$
Single
\prec
Split3.
$$

結果：

```text
single_control = single
```

再跑主要 E2 task：

```text
topology = split-3
```

這保留 FCAO 的核心不變量：

$$
\boxed{
Decomposable\not\Rightarrow WorthDecomposing.
}
$$

---

## 4. APR 在不同 child 上的四種觀測決策序列

本輪故意讓不同 child evidence 處於不同 epistemic state。

### Atlas

已有高信心、已驗證 evidence：

$$
APR(Atlas)=NO\_OBSERVATION.
$$

表示 APR 不要求重讀已被充分驗證的 child artifact。

### Kepler

只有低信心 observed evidence：

$$
APR(Kepler)=STRUCTURED\_INSPECTION.
$$

### Curie

沒有 evidence：

$$
APR(Curie)=TARGETED\_OBSERVATION.
$$

### Merge schema compatibility

跨 child conflict 出現後，schema compatibility 尚無證據：

$$
APR(SchemaCompatibility)=TARGETED\_OBSERVATION.
$$

因此本次 observation action sequence 為：

```text
NO_OBSERVATION
STRUCTURED_INSPECTION
TARGETED_OBSERVATION
TARGETED_OBSERVATION
```

這顯示 APR 在多子 Agent 環境中不是「每個 child 都重查一次」，而是：

$$
\boxed{
ObserveOnlyWhatNeedsObserving.
}
$$

---

## 5. Cross-child conflict

Atlas 與 Kepler 的局部 LCC 都可以是 complete，但兩個結果之間仍可能存在 integration conflict。

本輪建立：

```text
conflict-schema
reason = schema-version-mismatch
tasks = task-atlas, task-kepler
```

因此：

$$
LCC_{Atlas}=1
$$

且：

$$
LCC_{Kepler}=1
$$

仍不推出：

$$
MergeReady=1.
$$

形式上：

$$
\boxed{
LocalClosure_1+LocalClosure_2
\not\Rightarrow
IntegrationClosure.
}
$$

---

## 6. Twin merge governance

Conflict 尚未解決時，merge assessment：

```text
ready = false
unresolved_conflicts = [conflict-schema]
```

Twin：

```text
CHALLENGE
reason = cross-child-conflict
```

在 APR 觸發 targeted schema observation、建立 `schema-compatibility` verified evidence，並追加 `COLLAB_CONFLICT_RESOLVED` 後：

```text
ready = true
```

Twin 才：

```text
CONCUR
reason = merge-ready
```

因此 Twin sequence：

$$
\boxed{
CHALLENGE\rightarrow CONCUR.
}
$$

這裡 Twin 驗證的不是單一 child 答案，而是：

$$
ChildResults
+
CrossChildConsistency
+
MergeReadiness.
$$

---

## 7. Global Closure 的新 invariant

E2 暴露並修正了一個重要問題：若 `evaluate_closure()` 只看 task + LCC，而忽略 collaboration conflict，可能出現：

$$
Twin=CHALLENGE
$$

但：

$$
GCC=Eligible
$$

的矛盾。

v0.1.2 因此正式加入：

$$
UnresolvedConflict
\Rightarrow
GlobalClosureNotEligible.
$$

只有：

$$
AllMandatoryLCCComplete
$$

且：

$$
UnresolvedConflicts=\varnothing
$$

才可：

$$
GCC.eligible=1.
$$

---

## 8. Deterministic run result

本包內建 `multichild-demo` 的驗證結果：

```text
world_id                         = fcao-apr-deterministic-exp-02
topology                         = split-3
single_control                   = single
logical_child_count              = 3
child_names                      = Atlas, Curie, Kepler
all_children_direct              = true
recursive_children               = 0
local_twins                      = 0
apr_actions                      = NO_OBSERVATION,
                                   STRUCTURED_INSPECTION,
                                   TARGETED_OBSERVATION,
                                   TARGETED_OBSERVATION
twin_sequence                    = CHALLENGE, CONCUR
merge_blocked_before_resolution  = true
merge_ready_after_resolution     = true
active_closure_id                = gcc-e2-1
final_closure_eligible            = true
final_coverage                    = 1.0
replay_matches                    = true
event_count                       = 34
```

---

## 9. 本輪能證明什麼

在 v0.1.2 deterministic semantics 下，已能證明：

1. 三個 direct child 可以在 canonical state 中獨立存在；
2. child naming 與 machine ID 分離；
3. logical parent lineage 可以保存；
4. fan-out membership 可以 replay；
5. task assignment 可以 replay；
6. child LCC 可以獨立聚合；
7. APR 可對不同 child evidence 做不同 observation decision；
8. unresolved cross-child conflict 可阻止 merge；
9. unresolved cross-child conflict 可阻止 global closure；
10. Twin 可 challenge integration layer，而不是只驗 leaf artifact；
11. conflict resolution 後 Twin 可以 concurrence；
12. final GCC 與 event replay 一致。

---

## 10. 本輪不能證明什麼

本輪不能宣稱：

- OpenHarness 已真的同時啟動三個 child process / model session；
- 三個 child 真正 wall-clock parallel；
- 多子 AI 比 Single 更省 token / money / time；
- native OpenHarness parent propagation 已完成；
- child 可以 spawn child；
- child 擁有 local Twin；
- dynamic repartition 在 live carrier 已被驗證；
- three-child topology 是任何 task 的最佳 fan-out。

因此這是一個：

$$
\boxed{
DeterministicMultiChildSemanticBaseline
}
$$

而不是 production benchmark 結論。

---

## 11. 下一個實驗：E2-Live

使用者的本地 AI 可以拿 v0.1.2 包真正接 carrier，填寫：

`docs/experiments/FCAO_APR_E2_LIVE_RUN_REPORT_TEMPLATE.md`

E2-Live 最重要的不是讓 child 數越多越好，而是核對：

- 三個真實 child 的 ID / name / task / parent 是否一致；
- OpenHarness runtime handle 與 FCAO identity 是否可穩定映射；
- child LCC 是否真的由不同 worker 產生；
- APR 是否避免無意義重觀測；
- conflict / verifier failure 是否能被 Twin 捕捉；
- merge 前是否真的發生 fan-in governance；
- 重啟後 replay 是否仍可重建相同 canonical state。

---

## 12. E3 邊界

E2-Live 完成以前，不將以下能力算入本輪：

$$
RecursiveChildDelegation,
$$

$$
LocalTwin,
$$

$$
NativeRecursiveParentLineage,
$$

$$
DynamicRepartitionAcrossRecursiveDomains.
$$

這些屬於 E3。

---

## 13. 結論

Experiment 01 的核心是：

$$
Primary+Twin+APR+0Child.
$$

Experiment 02 將其推進為：

$$
Primary+Twin+APR+3DirectChildren.
$$

但仍維持單層 fan-out，以便隔離多子 Agent 本身帶來的新問題。

本輪最重要的新增不是「三個 Agent 同時做事」，而是正式建立：

$$
\boxed{
ChildLocalClosure
+
CrossChildConflict
+
MergeGovernance
+
GlobalClosure.
}
$$

APR 則控制：

$$
\boxed{
ObservationCost.
}
$$

Twin 控制：

$$
\boxed{
IntegrationRisk.
}
$$

Primary 控制：

$$
\boxed{
TaskTopology+FinalIntegration.
}
$$

因此 E2 的結構可壓縮為：

$$
\boxed{
FanOut
\rightarrow
LocalLCC
\rightarrow
APR
\rightarrow
CrossChildCheck
\rightarrow
TwinGate
\rightarrow
FanIn
\rightarrow
GCC.
}
$$

下一步應先做真實 carrier E2-Live，再進 E3，而不是再擴張理論文件。
