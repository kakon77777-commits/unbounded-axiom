# FCAO + APR E2 Live Multi-Child Run Report Template

**Purpose:** Record a real carrier-backed E2 run without mixing in E3 recursive behavior.

## Environment

- Date/time:
- Machine / OS:
- FCAO version: `0.1.2`
- OpenHarness repository / version / pinned commit:
- Model/provider used by Primary:
- Model/provider used by Twin:
- Child provider/model(s):
- APR version/config:
- Runtime command:

## Hard E2 Boundary

Confirm before run:

- [ ] Exactly one Primary.
- [ ] Exactly one root Twin.
- [ ] Two or more direct child Agents.
- [ ] Every child has `parent_fcao_agent_id = Primary`.
- [ ] No child spawns another child.
- [ ] No child has a local Twin.
- [ ] No OpenHarness core fork is required before test.

## Child Identity Table

| FCAO ID | Ephemeral Name | Task | FCAO Parent | OpenHarness Runtime Handle | Start | Stop | Result |
|---|---|---|---|---|---|---|---|

## Fan-Out Decision

- Single candidate estimate:
- Split candidate estimate:
- Chosen topology:
- Why:
- Expected gain / risk:

## APR Decisions

| Evidence Key | Pre-state | Confidence | APR Action | Observation Cost | Resulting Evidence |
|---|---|---:|---|---:|---|

## Child LCCs

For each child record:

```yaml
task_id:
agent_id:
satisfied:
mandatory:
open_gaps: []
verified_artifacts: []
```

## Cross-Child Conflict / Compatibility

- Conflict ID:
- Tasks involved:
- Discovery method:
- Was it a real artifact conflict, verifier false positive, or schema mismatch?
- Evidence used to resolve:
- Resolution receipt:

## Twin Decisions

| Sequence | State / Trigger | Action | Reason | Cost / Tokens | Outcome |
|---:|---|---|---|---:|---|

Expected E2 pattern is not hard-coded, but at least record whether Twin legally `IDLE`, `AUDIT`, `CHALLENGE`, or `CONCUR`.

## Merge / Fan-In

- Merge ready before conflict resolution?:
- Blocking tasks:
- Blocking conflicts:
- Merge ready after resolution?:
- Merge LCC:
- Integration artifact:

## Closure

- GCC ID:
- Coverage:
- Blocking tasks:
- Blocking conflicts:
- Twin final decision:
- Eligible?:
- Superseded closure(s), if any:

## Replay / Recovery

- Event count:
- Restart performed?:
- Replayed state matches?:
- Orphan runtime handles?:
- Lost execution handles?:

## Cost / Time

- Wall-clock makespan:
- Primary active time:
- Twin active time:
- Child wall times:
- Total tokens:
- APR observations skipped:
- Fresh verifications:
- Rework avoided / incurred:

## Raw Evidence

Attach:

- [ ] CLI output
- [ ] SQLite DB or exported event JSON
- [ ] child outputs
- [ ] LCC files
- [ ] Twin decision receipts
- [ ] APR observation receipts
- [ ] OpenHarness logs
- [ ] git diff if any source modification was required

## Classification of Required Changes

For every carrier problem, classify:

- `EXTEND`
- `PATCH_CANDIDATE`
- `FORK_REQUIRED`

Do not label `FORK_REQUIRED` without exact source path and reason why plugin/adapter/upstream patch cannot represent the required semantics.

## Result

- E2-Live status: `PASS / PARTIAL / FAIL`
- Strongest evidence:
- Main blocker:
- Recommendation before E3:
