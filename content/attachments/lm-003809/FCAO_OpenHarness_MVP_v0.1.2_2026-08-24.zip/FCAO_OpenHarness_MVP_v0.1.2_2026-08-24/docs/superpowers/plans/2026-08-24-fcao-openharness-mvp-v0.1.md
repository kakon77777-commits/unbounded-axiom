# FCAO-OpenHarness MVP v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a local-first, deterministic FCAO runtime that proves canonical state, Primary/Twin governance, named ephemeral agents, temporal envelopes, LCC-based closure, versioned repartition, event replay, and an OpenHarness adapter boundary without modifying OpenHarness core.

**Architecture:** The MVP is a standalone Python package. `fcao.core` owns canonical state and semantics; `fcao.adapters.openharness` translates between FCAO execution requests and OpenHarness-style runtime handles without importing OpenHarness internals. SQLite persists events/snapshots; deterministic fake execution drives tests and demo scenarios. The OpenHarness adapter is contract-tested against a small fake bridge so the core remains runnable without OpenHarness installed.

**Tech Stack:** Python 3.11+, stdlib `sqlite3`, `dataclasses`, `enum`, `json`, `argparse`; pytest for tests; no production dependencies.

**Spec:** `docs/specs/fcao-twin-core-reference-architecture-v0.1.md` and `docs/specs/fcao-openharness-integration-v0.1.md`

## Global Constraints

- Canonical state MUST exist outside any Agent context.
- Primary and Twin MUST be separate roles; Twin MUST NOT be modeled as an ordinary child.
- `AgentType`, ephemeral name, task name, and machine ID MUST remain distinct.
- `Single` MUST always be a valid topology candidate.
- Verification MUST be represented in topology/state, not only in prose.
- Repartition MUST create a new topology version and an event receipt.
- LCC MUST NOT imply global closure by itself.
- Closure MUST produce a Global Closure Certificate before commit eligibility.
- OpenHarness-specific imports MUST be confined to `fcao/adapters/openharness/`; v0.1 adapter must work through a protocol/bridge.
- MVP MUST run without network access and without OpenHarness installed.
- TDD is mandatory: each behavior gets a failing test before production code.

---

## File Structure

```text
fcao-openharness-mvp/
├── pyproject.toml
├── README.md
├── src/fcao/
│   ├── __init__.py
│   ├── model.py          # canonical enums/dataclasses
│   ├── event_store.py    # SQLite append/read/replay input
│   ├── reducer.py        # pure event -> state reducer
│   ├── topology.py       # graph/version/decomposition/repartition
│   ├── temporal.py       # envelopes and breach detection
│   ├── closure.py        # LCC + GCC evaluation
│   ├── runtime.py        # Primary/Twin deterministic orchestration
│   ├── cli.py            # demo/verify/replay commands
│   └── adapters/
│       ├── __init__.py
│       └── openharness/
│           ├── __init__.py
│           └── adapter.py
├── tests/
│   ├── test_event_replay.py
│   ├── test_identity_topology.py
│   ├── test_temporal_repartition.py
│   ├── test_closure_twin.py
│   ├── test_openharness_adapter.py
│   └── test_cli_demo.py
└── docs/
    ├── specs/
    └── superpowers/plans/
```

---

### Task 1: Canonical Event Store and Replayable State

**Files:**
- Create: `pyproject.toml`
- Create: `src/fcao/__init__.py`
- Create: `src/fcao/model.py`
- Create: `src/fcao/event_store.py`
- Create: `src/fcao/reducer.py`
- Test: `tests/test_event_replay.py`

**Interfaces:**
- Produces: `Event`, `ProjectState`, `SQLiteEventStore.append(event)`, `SQLiteEventStore.read_all(world_id)`, `reduce_events(events) -> ProjectState`.
- Later tasks depend on deterministic replay of topology version, task status, agent registry, and event sequence.

- [x] **Step 1: Write the failing replay test**

```python
from fcao.event_store import SQLiteEventStore
from fcao.model import Event
from fcao.reducer import reduce_events


def test_event_log_replays_same_world_state(tmp_path):
    store = SQLiteEventStore(tmp_path / "fcao.db")
    store.append(Event.make("WORLD_OPEN", "world-1", {"closure_target": 1.0}))
    store.append(Event.make("AGENT_REGISTERED", "world-1", {
        "agent_id": "primary-1", "name": "Polaris", "role": "primary"
    }))
    events = store.read_all("world-1")
    state = reduce_events(events)
    assert state.world_id == "world-1"
    assert state.agents["primary-1"].name == "Polaris"
    assert state.revision == 2
```

- [x] **Step 2: Run the test and confirm RED**

Run: `pytest tests/test_event_replay.py -q`
Expected: import failure because `fcao.event_store` does not exist.

- [x] **Step 3: Implement minimal immutable event and state models**

Create `Event.make()` with UUID event IDs and UTC ISO timestamp, `AgentIdentity`, and mutable `ProjectState` dataclasses sufficient for the test.

- [x] **Step 4: Implement SQLite append/read**

Schema: `events(seq INTEGER PRIMARY KEY AUTOINCREMENT, event_id TEXT UNIQUE, world_id TEXT, event_type TEXT, occurred_at TEXT, payload_json TEXT)`.

- [x] **Step 5: Implement reducer for `WORLD_OPEN` and `AGENT_REGISTERED`**

Reducer increments `revision` for every accepted event and rejects mismatched world IDs.

- [x] **Step 6: Run test and confirm GREEN**

Run: `pytest tests/test_event_replay.py -q`
Expected: `1 passed`.

- [x] **Step 7: Commit**

```bash
git add pyproject.toml src/fcao tests/test_event_replay.py
git commit -m "feat: add replayable FCAO canonical event state"
```

---

### Task 2: Named Ephemeral Identity and Versioned Task Topology

**Files:**
- Modify: `src/fcao/model.py`
- Modify: `src/fcao/reducer.py`
- Create: `src/fcao/topology.py`
- Test: `tests/test_identity_topology.py`

**Interfaces:**
- Consumes: `ProjectState`, `Event`.
- Produces: `TaskNode`, `TopologyEdge`, `TopologyCandidate`, `register_agent_event()`, `create_task_event()`, `repartition_events()`.

- [x] **Step 1: Write failing tests for distinct identity fields and topology versioning**

```python
from fcao.model import AgentIdentity, TaskNode
from fcao.topology import repartition_events


def test_ephemeral_agent_keeps_type_name_task_and_parent_distinct():
    agent = AgentIdentity(
        agent_id="ag-17", name="Atlas", role="worker",
        agent_type="implementation", task_id="task-17",
        task_name="Storage Topology", parent_agent_id="primary-1",
        world_id="world-1"
    )
    assert agent.agent_type == "implementation"
    assert agent.name == "Atlas"
    assert agent.task_name == "Storage Topology"
    assert agent.parent_agent_id == "primary-1"


def test_repartition_increments_topology_version_and_emits_receipt():
    events = repartition_events(
        world_id="world-1", old_version=1,
        split_task_id="task-17", new_task_ids=("task-17a", "task-17b"),
        actor_id="twin-1", reason="temporal_upper_breach"
    )
    assert events[0].event_type == "TOPOLOGY_REPARTITIONED"
    assert events[0].payload["old_version"] == 1
    assert events[0].payload["new_version"] == 2
    assert events[0].payload["new_task_ids"] == ["task-17a", "task-17b"]
```

- [x] **Step 2: Run and confirm RED**

Run: `pytest tests/test_identity_topology.py -q`
Expected: missing model fields and topology module.

- [x] **Step 3: Implement `TaskNode`, `TopologyEdge`, identity fields, and reducer support**

Task states: `PENDING`, `READY`, `RUNNING`, `BLOCKED`, `VERIFYING`, `COMPLETED`, `FAILED`, `CANCELLED`, `REOPENED`.

- [x] **Step 4: Implement `repartition_events()`**

It MUST emit one `TOPOLOGY_REPARTITIONED` event containing old/new version, split target, children, actor, reason, and MUST NOT mutate state directly.

- [x] **Step 5: Run focused tests and full suite**

Run: `pytest tests/test_identity_topology.py -q && pytest -q`
Expected: all pass.

- [x] **Step 6: Commit**

```bash
git add src/fcao tests/test_identity_topology.py
git commit -m "feat: add named agents and versioned task topology"
```

---

### Task 3: Temporal Envelope, NO_SPLIT/SPLIT Choice, and Breach-Driven Repartition

**Files:**
- Create: `src/fcao/temporal.py`
- Modify: `src/fcao/topology.py`
- Test: `tests/test_temporal_repartition.py`

**Interfaces:**
- Produces: `TemporalEnvelope`, `TopologyEstimate`, `choose_candidate(candidates, policy)`, `detect_breach(envelope, elapsed_ms)`.

- [x] **Step 1: Write failing tests for `NO_SPLIT` and `SPLIT`**

```python
from fcao.temporal import TemporalEnvelope
from fcao.topology import TopologyEstimate, choose_candidate


def test_single_is_chosen_when_split_overhead_is_worse():
    choices = [
        TopologyEstimate("single", 100, 180, cost=1.0, risk=0.1),
        TopologyEstimate("split-2", 120, 240, cost=1.6, risk=0.1),
    ]
    assert choose_candidate(choices, policy="balanced").candidate_id == "single"


def test_split_is_chosen_when_upper_bound_and_cost_improve():
    choices = [
        TopologyEstimate("single", 500, 900, cost=3.0, risk=0.2),
        TopologyEstimate("split-2", 260, 480, cost=2.7, risk=0.2),
    ]
    assert choose_candidate(choices, policy="balanced").candidate_id == "split-2"


def test_temporal_upper_breach_is_detected():
    env = TemporalEnvelope(lower_ms=100, upper_ms=200, confidence=0.7)
    assert env.is_breached(201)
    assert not env.is_breached(200)
```

- [x] **Step 2: Run and confirm RED**

Run: `pytest tests/test_temporal_repartition.py -q`
Expected: missing temporal module / estimates.

- [x] **Step 3: Implement minimal deterministic candidate scoring**

Balanced score MUST prefer lower normalized upper bound, then cost, then risk. Do not implement stochastic optimization.

- [x] **Step 4: Implement envelope validation**

Reject negative bounds, `lower_ms > upper_ms`, or confidence outside `[0, 1]`.

- [x] **Step 5: Run tests and confirm GREEN**

Run: `pytest tests/test_temporal_repartition.py -q && pytest -q`
Expected: all pass.

- [x] **Step 6: Commit**

```bash
git add src/fcao/temporal.py src/fcao/topology.py tests/test_temporal_repartition.py
git commit -m "feat: add temporal envelope and decomposition choice"
```

---

### Task 4: LCC, Persistent Twin Decisions, and Global Closure Certificate

**Files:**
- Create: `src/fcao/closure.py`
- Create: `src/fcao/runtime.py`
- Modify: `src/fcao/model.py`
- Modify: `src/fcao/reducer.py`
- Test: `tests/test_closure_twin.py`

**Interfaces:**
- Produces: `LocalClosureCertificate`, `GlobalClosureCertificate`, `TwinDecision`, `TwinGovernor.inspect()`, `evaluate_closure(state)`.

- [x] **Step 1: Write failing test that an incomplete LCC blocks global closure**

```python
from fcao.closure import LocalClosureCertificate, evaluate_closure
from fcao.model import ProjectState


def test_local_certificate_with_open_gap_cannot_create_global_closure():
    state = ProjectState.open("world-1", closure_target=1.0)
    state.lccs["task-1"] = LocalClosureCertificate(
        task_id="task-1", agent_id="ag-1", satisfied=1, mandatory=2,
        open_gaps=("missing crash recovery proof",), verified_artifacts=()
    )
    gcc = evaluate_closure(state)
    assert not gcc.eligible
    assert "task-1" in gcc.blocking_tasks
```

- [x] **Step 2: Write failing tests for Twin `IDLE` and `CHALLENGE`**

```python
from fcao.runtime import TwinGovernor


def test_twin_idles_when_no_risk_signal_exists():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    assert twin.inspect(risk=0.2, closure_candidate=False, open_gaps=()).action == "IDLE"


def test_twin_challenges_candidate_closure_with_open_gap():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect(risk=0.2, closure_candidate=True, open_gaps=("task-9",))
    assert decision.action == "CHALLENGE"
```

- [x] **Step 3: Run and confirm RED**

Run: `pytest tests/test_closure_twin.py -q`
Expected: missing closure/runtime modules.

- [x] **Step 4: Implement LCC/GCC and Twin decision model**

Twin actions in v0.1: `IDLE`, `AUDIT`, `CHALLENGE`, `REOPEN`, `ESCALATE`.

- [x] **Step 5: Add reducer events for `LCC_SUBMITTED`, `TWIN_DECISION`, `GLOBAL_CLOSURE_ISSUED`**

- [x] **Step 6: Run tests and confirm GREEN**

Run: `pytest tests/test_closure_twin.py -q && pytest -q`
Expected: all pass.

- [x] **Step 7: Commit**

```bash
git add src/fcao tests/test_closure_twin.py
git commit -m "feat: add LCC twin governance and global closure"
```

---

### Task 5: OpenHarness Adapter Contract Without Core Coupling

**Files:**
- Create: `src/fcao/adapters/__init__.py`
- Create: `src/fcao/adapters/openharness/__init__.py`
- Create: `src/fcao/adapters/openharness/adapter.py`
- Test: `tests/test_openharness_adapter.py`

**Interfaces:**
- Produces: `OpenHarnessBridge` Protocol, `OpenHarnessAdapter.spawn/send/status/collect/stop/capabilities`.
- Core code MUST NOT import OpenHarness.

- [x] **Step 1: Write failing adapter contract test with fake bridge**

```python
from fcao.adapters.openharness.adapter import OpenHarnessAdapter


class FakeBridge:
    def __init__(self):
        self.calls = []
    def capabilities(self): return {"agent_spawn": True, "mcp": True}
    def spawn(self, payload): self.calls.append(("spawn", payload)); return "task-42"
    def send(self, handle, message): self.calls.append(("send", handle, message)); return {"ok": True}
    def status(self, handle): return "running"
    def collect(self, handle): return {"status": "completed", "result": "ok"}
    def stop(self, handle, reason): self.calls.append(("stop", handle, reason)); return {"ok": True}


def test_openharness_adapter_preserves_fcao_identity_outside_runtime_handle():
    bridge = FakeBridge()
    adapter = OpenHarnessAdapter(bridge)
    handle = adapter.spawn({"fcao_agent_id": "ag-17", "ephemeral_name": "Atlas", "prompt": "work"})
    assert handle.runtime_id == "task-42"
    assert handle.fcao_agent_id == "ag-17"
    assert handle.ephemeral_name == "Atlas"
```

- [x] **Step 2: Run and confirm RED**

Run: `pytest tests/test_openharness_adapter.py -q`
Expected: missing adapter.

- [x] **Step 3: Implement protocol-based adapter**

No import from `openharness.*`; bridge injection owns version-specific integration.

- [x] **Step 4: Add path guard test**

Test scans `src/fcao` excluding `src/fcao/adapters/openharness` and asserts no `openharness` import token occurs.

- [x] **Step 5: Run and confirm GREEN**

Run: `pytest tests/test_openharness_adapter.py -q && pytest -q`
Expected: all pass.

- [x] **Step 6: Commit**

```bash
git add src/fcao/adapters tests/test_openharness_adapter.py
git commit -m "feat: add decoupled OpenHarness execution adapter"
```

---

### Task 6: Executable Demo, Replay Verification, and Package Documentation

**Files:**
- Create: `src/fcao/cli.py`
- Create: `tests/test_cli_demo.py`
- Create: `README.md`
- Create: `examples/demo_scenario.json`
- Create: `THIRD_PARTY_NOTICES.md`

**Interfaces:**
- Produces CLI: `python -m fcao.cli demo --db PATH`, `python -m fcao.cli replay --db PATH --world WORLD_ID`, `python -m fcao.cli verify --db PATH --world WORLD_ID`.

- [x] **Step 1: Write failing CLI demo test**

```python
import json, subprocess, sys


def test_demo_exercises_split_twin_repartition_and_closure(tmp_path):
    db = tmp_path / "demo.db"
    proc = subprocess.run(
        [sys.executable, "-m", "fcao.cli", "demo", "--db", str(db)],
        text=True, capture_output=True, check=True
    )
    result = json.loads(proc.stdout)
    assert result["single_case"] == "single"
    assert result["split_case"] == "split-2"
    assert result["twin_idle"] == "IDLE"
    assert result["repartitioned"] is True
    assert result["closure_eligible"] is True
    assert result["replay_matches"] is True
```

- [x] **Step 2: Run and confirm RED**

Run: `pytest tests/test_cli_demo.py -q`
Expected: missing `fcao.cli`.

- [x] **Step 3: Implement deterministic demo**

The demo MUST create a world, register Primary/Twin/Atlas, demonstrate one `single` choice, one `split-2` choice, submit a complete LCC, make Twin idle in low risk, create a temporal breach and repartition event, issue a GCC, replay all events, and compare serialized canonical states.

- [x] **Step 4: Implement replay and verify commands**

`replay` prints canonical state JSON. `verify` exits non-zero if replay fails or closure event is inconsistent.

- [x] **Step 5: Add README run instructions and third-party notice**

Document that OpenHarness is not vendored; its name is used for adapter compatibility and the user-provided source snapshot was reviewed separately. Include the upstream project name and instruct distributors to honor its license if they later vendor or copy code.

- [x] **Step 6: Run all tests**

Run: `pytest -q`
Expected: all tests pass.

- [x] **Step 7: Run the demo manually**

Run: `python -m fcao.cli demo --db /tmp/fcao-demo.db`
Expected JSON contains all six acceptance signals from Step 1.

- [x] **Step 8: Commit**

```bash
git add src/fcao/cli.py tests/test_cli_demo.py README.md examples THIRD_PARTY_NOTICES.md
git commit -m "feat: add executable FCAO deterministic MVP demo"
```

---

## Plan Self-Review

- **Spec coverage:** Covers canonical state, Primary/Twin separation, named ephemeral identity, logical lineage, topology, temporal envelope, LCC/GCC, repartition, event replay, OpenHarness adapter boundary, and deterministic benchmark signals. Native recursive OpenHarness spawn and SEDB/CTCL production adapters are intentionally deferred because the approved integration whitepaper places them after the deterministic MVP.
- **Placeholder scan:** No implementation task contains TODO/TBD placeholders. Runtime OpenHarness commit pin is intentionally not part of Phase 0 because this plan does not vendor or execute OpenHarness itself.
- **Type consistency:** `Event`, `ProjectState`, `AgentIdentity`, `TemporalEnvelope`, `TopologyEstimate`, `LocalClosureCertificate`, `GlobalClosureCertificate`, `TwinGovernor`, and adapter handle names are used consistently across tasks.
