# FCAO E2 Multi-Child v0.1.2 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Extend FCAO MVP v0.1.1 with a deterministic E2 multi-child fan-out/fan-in experiment while preserving APR, Twin governance, canonical replay, and the no-recursion boundary.

**Architecture:** Keep OpenHarness behind the existing adapter boundary. Add an FCAO-native collaboration layer that records fan-out groups, child assignments, cross-child conflicts, merge readiness, and merge assessments in canonical events/state. The E2 CLI scenario uses three direct children of Primary, APR evidence decisions, one cross-child conflict, Twin challenge/concurrence, a merge LCC, GCC, and deterministic replay; it intentionally starts no recursive child and no local Twin.

**Tech Stack:** Python 3.11+, dataclasses, SQLite event store, argparse CLI, pytest; zero new runtime dependencies.

**Spec:** `docs/specs/fcao-twin-core-reference-architecture-v0.1.md` and `docs/specs/fcao-openharness-integration-v0.1.md`

## Global Constraints

- Do not import OpenHarness internals from FCAO core.
- Preserve all 28 v0.1.1 tests.
- All production behavior is introduced test-first.
- E2 uses exactly three logical direct child Agents with `parent_agent_id=primary-1`.
- E2 contains zero recursive child spawn and zero local Twin.
- APR remains an evidence/observation controller, not a worker scheduler.
- Cross-child conflict history is append-only and replayable.
- Global closure is not eligible until all child LCCs, the merge LCC, and all recorded conflicts are resolved.
- Keep `Single` as a valid control topology candidate.
- Do not patch or fork OpenHarness.

---

### Task 1: Canonical Multi-Child Collaboration State

**Files:**
- Create: `src/fcao/collaboration.py`
- Modify: `src/fcao/model.py`
- Modify: `src/fcao/reducer.py`
- Test: `tests/test_multichild_collaboration.py`

**Interfaces:**
- Produces `FanoutGroup`, `CollaborationConflict`, `MergeAssessment` dataclasses.
- Produces `assess_merge(state, child_task_ids, merge_task_id) -> MergeAssessment`.
- Reducer consumes `FANOUT_DECLARED`, `TASK_ASSIGNED`, `COLLAB_CONFLICT_RECORDED`, `COLLAB_CONFLICT_RESOLVED`, and `MERGE_ASSESSED` events.

- [ ] **Step 1: Write failing tests** asserting three direct child assignments replay, fan-out membership is preserved, unresolved conflict blocks merge, resolved conflict plus complete child/merge LCCs makes merge ready.
- [ ] **Step 2: Run** `PYTHONPATH=src python -m pytest tests/test_multichild_collaboration.py -q` and verify RED because `fcao.collaboration` does not exist.
- [ ] **Step 3: Implement minimal collaboration dataclasses, ProjectState fields, reducer events, and `assess_merge`.**
- [ ] **Step 4: Run** `PYTHONPATH=src python -m pytest tests/test_multichild_collaboration.py -q` and verify GREEN.
- [ ] **Step 5: Run** `PYTHONPATH=src python -m pytest -q` and verify existing tests remain green.
- [ ] **Step 6: Commit** `feat: add replayable multi-child collaboration state`.

### Task 2: Twin Merge Governance

**Files:**
- Modify: `src/fcao/runtime.py`
- Test: `tests/test_twin_merge_governance.py`

**Interfaces:**
- Consumes `MergeAssessment`-compatible inputs: `blocking_tasks`, `unresolved_conflicts`, and `risk`.
- Produces `TwinGovernor.inspect_merge(...) -> TwinDecision` with `CHALLENGE`, `AUDIT`, or `CONCUR`.

- [ ] **Step 1: Write failing tests** for conflict challenge, incomplete child challenge, high-risk audit, and clean merge concurrence.
- [ ] **Step 2: Run** `PYTHONPATH=src python -m pytest tests/test_twin_merge_governance.py -q` and verify RED because `inspect_merge` is missing.
- [ ] **Step 3: Implement the minimal deterministic `inspect_merge` method.**
- [ ] **Step 4: Run** the focused test and then full suite.
- [ ] **Step 5: Commit** `feat: add twin merge governance decisions`.

### Task 3: Deterministic E2 CLI Scenario

**Files:**
- Modify: `src/fcao/cli.py`
- Test: `tests/test_multichild_cli_demo.py`
- Create: `examples/e2_multichild_scenario.json`

**Interfaces:**
- Adds CLI command `multichild-demo --db <path>`.
- Produces JSON fields: `world_id`, `topology`, `single_control`, `logical_child_count`, `child_names`, `all_children_direct`, `recursive_children`, `local_twins`, `apr_actions`, `twin_sequence`, `merge_blocked_before_resolution`, `merge_ready_after_resolution`, `active_closure_id`, `final_closure_eligible`, `replay_matches`, `event_count`.

- [ ] **Step 1: Write failing CLI tests** for parser/command output, three named direct children, APR decision diversity, Twin `CHALLENGE -> CONCUR`, final GCC, and replay equivalence.
- [ ] **Step 2: Run** focused tests and verify RED because `multichild-demo` is absent.
- [ ] **Step 3: Implement `_multichild_demo` using existing event store, APR, topology choice, LCC, collaboration, Twin merge governance, and closure APIs.**
- [ ] **Step 4: Run focused and full suites; verify GREEN.**
- [ ] **Step 5: Commit** `feat: add deterministic E2 multi-child scenario`.

### Task 4: Experiment 02 Documentation and Release Metadata

**Files:**
- Create: `docs/experiments/FCAO_APR_Deterministic_Experiment_02_MultiChild_v0.1.md`
- Create: `docs/experiments/FCAO_APR_E2_LIVE_RUN_REPORT_TEMPLATE.md`
- Modify: `README.md`
- Modify: `pyproject.toml`
- Create: `VALIDATION_REPORT_v0.1.2.md`

**Interfaces:**
- Documents deterministic evidence only; does not claim a live OpenHarness multi-child run.
- Live-run template captures carrier version, child identities, parent lineage, APR decisions, Twin decisions, LCCs, conflicts, closure, replay, and raw logs.

- [ ] **Step 1: Write the Experiment 02 note** with explicit E1/E2/E3 boundary and falsifiable observations.
- [ ] **Step 2: Write the live-run report template** for the user's local AI.
- [ ] **Step 3: Update README and version to `0.1.2`.**
- [ ] **Step 4: Run full tests, CLI demo, replay/verify, compileall, and import-boundary scan.**
- [ ] **Step 5: Record exact outputs in `VALIDATION_REPORT_v0.1.2.md`.**
- [ ] **Step 6: Commit** `docs: document FCAO E2 multi-child experiment`.

### Task 5: Release Packaging

**Files:**
- Create at release time: `SOURCE_COMMIT_v0.1.2.txt`, `SHA256SUMS_v0.1.2.txt`

**Interfaces:**
- Produces `FCAO_OpenHarness_MVP_v0.1.2_2026-08-24.zip` from the verified commit.
- Produces `FCAO_APR_Deterministic_Experiment_02_v0.1_2026-08-24.zip` with the note, live-run template, example scenario, validation report, and hashes.

- [ ] **Step 1: Run fresh full verification on final tree.**
- [ ] **Step 2: Commit source commit/hash metadata.**
- [ ] **Step 3: Build ZIPs from tracked files, excluding caches/worktree internals.**
- [ ] **Step 4: Run ZIP integrity and UTF-8 validation.**
