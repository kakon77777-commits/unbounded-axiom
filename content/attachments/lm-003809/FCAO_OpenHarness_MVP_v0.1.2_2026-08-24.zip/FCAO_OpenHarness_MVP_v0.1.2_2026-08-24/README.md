# FCAO-OpenHarness MVP v0.1.2

A local-first deterministic reference implementation of the FCAO Twin-Core architecture.

## What this MVP proves

- `Single` is a valid topology candidate and can beat a split.
- A split can also win when its temporal/cost envelope is better.
- Agent machine ID, ephemeral name, role, task name, and logical parent remain distinct.
- Repartition creates a new topology version and a receipt event.
- Local Closure Certificates (LCCs) do not imply global closure by themselves.
- A persistent Twin can legally `IDLE`, `AUDIT`, or `CHALLENGE`.
- Canonical state is persisted as SQLite events and deterministically replayed.
- APR stores evidence sufficiency and explicit observation decisions (`NO_OBSERVATION`, `TARGETED_OBSERVATION`, `STRUCTURED_INSPECTION`).
- Closure history is append-only: a closure may be superseded without deleting the earlier record.

- Direct multi-child fan-out is canonical state rather than prompt-only structure.
- Cross-child conflicts are append-only, replayable, and block both merge readiness and global closure until resolved.
- Twin merge governance can `CHALLENGE`, `AUDIT`, or `CONCUR` independently of leaf LCC completion.
- OpenHarness is behind an injected adapter bridge; the FCAO core imports no OpenHarness internals.

## Run tests

No network or third-party runtime dependency is needed:

```bash
PYTHONPATH=src python -m pytest -q
```

## Run the deterministic demo

```bash
PYTHONPATH=src python -m fcao.cli demo --db fcao-demo.db
```

The JSON output includes `single_case`, `split_case`, `twin_idle`, `repartitioned`, `closure_eligible`, and `replay_matches`.

Replay a world:

```bash
PYTHONPATH=src python -m fcao.cli replay --db fcao-demo.db --world <WORLD_ID>
```

Verify the recorded closure against replayed canonical state:

```bash
PYTHONPATH=src python -m fcao.cli verify --db fcao-demo.db --world <WORLD_ID>
```


## Run the APR Single + Twin experiment reconstruction

```bash
PYTHONPATH=src python -m fcao.cli apr-demo --db fcao-apr.db
```

This deterministic reconstruction intentionally starts **zero child Agents**. It demonstrates APR observation decisions, Twin `IDLE / CHALLENGE / CONCUR`, closure supersession, active-closure verification, and replay equivalence. The original local operational record is preserved under `docs/experiments/evidence/`; the reconstruction is not presented as the original 32-event database.

Read `docs/experiments/FCAO_APR_Operational_Experiment_01_v0.1.md` for scope, findings, limitations, and the E2/E3 follow-up plan.

## Run the E2 deterministic direct multi-child experiment

```bash
PYTHONPATH=src python -m fcao.cli multichild-demo --db fcao-e2.db
```

The E2 scenario creates exactly three **logical direct child Agents** (`Atlas`, `Kepler`, `Curie`) under Primary, zero recursive children, and zero local Twins. It demonstrates APR evidence-dependent observation, a cross-child conflict, Twin `CHALLENGE -> CONCUR`, merge gating, GCC eligibility, and deterministic replay. This is a semantic/deterministic baseline, **not** a claim that OpenHarness has already executed three live child model sessions.

Read `docs/experiments/FCAO_APR_Deterministic_Experiment_02_MultiChild_v0.1.md`. For a real local carrier run, fill `docs/experiments/FCAO_APR_E2_LIVE_RUN_REPORT_TEMPLATE.md`.

## OpenHarness integration boundary

This repository does **not** vendor or fork OpenHarness. `fcao.adapters.openharness` defines a bridge protocol that preserves FCAO canonical identity outside provider/runtime handles. A future carrier-specific bridge can call the pinned OpenHarness APIs while keeping `fcao.core` independent.

## Scope intentionally deferred

- Native recursive OpenHarness spawn with true runtime parent propagation (E3).
- Production SEDB adapter.
- Production CTCL-ITR adapter.
- Stochastic scheduler / learned duration model.
- UI / dashboard.
- Direct OpenHarness core patches.
