from fcao.closure import LocalClosureCertificate, evaluate_closure
from fcao.model import ProjectState, TaskNode
from fcao.runtime import TwinGovernor


def test_local_certificate_with_open_gap_cannot_create_global_closure():
    state = ProjectState.open("world-1", closure_target=1.0)
    state.tasks["task-1"] = TaskNode("task-1", "Crash recovery", state="COMPLETED")
    state.lccs["task-1"] = LocalClosureCertificate(
        task_id="task-1", agent_id="ag-1", satisfied=1, mandatory=2,
        open_gaps=("missing crash recovery proof",), verified_artifacts=()
    )
    gcc = evaluate_closure(state)
    assert not gcc.eligible
    assert "task-1" in gcc.blocking_tasks


def test_complete_lcc_for_all_mandatory_tasks_can_close():
    state = ProjectState.open("world-1", closure_target=1.0)
    state.tasks["task-1"] = TaskNode("task-1", "Storage", state="COMPLETED")
    state.lccs["task-1"] = LocalClosureCertificate(
        task_id="task-1", agent_id="Atlas", satisfied=2, mandatory=2,
        open_gaps=(), verified_artifacts=("artifact://storage",)
    )
    gcc = evaluate_closure(state)
    assert gcc.eligible
    assert gcc.coverage == 1.0
    assert gcc.blocking_tasks == ()


def test_twin_idles_when_no_risk_signal_exists():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    assert twin.inspect(risk=0.2, closure_candidate=False, open_gaps=()).action == "IDLE"


def test_twin_challenges_candidate_closure_with_open_gap():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect(risk=0.2, closure_candidate=True, open_gaps=("task-9",))
    assert decision.action == "CHALLENGE"


def test_twin_audits_high_risk_before_closure():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect(risk=0.8, closure_candidate=False, open_gaps=())
    assert decision.action == "AUDIT"

from fcao.model import Event
from fcao.reducer import reduce_events


def test_reducer_replays_lcc_twin_decision_and_global_closure():
    events = [
        Event.make("WORLD_OPEN", "world-1", {"closure_target": 1.0}),
        Event.make("TASK_CREATED", "world-1", {"task_id": "task-1", "name": "Storage", "state": "COMPLETED"}),
        Event.make("LCC_SUBMITTED", "world-1", {
            "task_id": "task-1", "agent_id": "Atlas", "satisfied": 1,
            "mandatory": 1, "open_gaps": [], "verified_artifacts": ["artifact://storage"]
        }),
        Event.make("TWIN_DECISION", "world-1", {"agent_id": "twin-1", "action": "IDLE", "reason": "no-risk-signal"}),
        Event.make("GLOBAL_CLOSURE_ISSUED", "world-1", {"eligible": True, "coverage": 1.0, "blocking_tasks": []}),
    ]
    state = reduce_events(events)
    assert state.lccs["task-1"].satisfied == 1
    assert state.twin_decisions[-1]["action"] == "IDLE"
    assert state.closures[-1]["eligible"] is True
