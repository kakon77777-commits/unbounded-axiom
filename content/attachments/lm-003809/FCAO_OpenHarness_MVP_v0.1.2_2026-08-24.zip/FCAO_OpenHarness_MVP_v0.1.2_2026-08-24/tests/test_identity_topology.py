from fcao.model import AgentIdentity
from fcao.topology import repartition_events


def test_ephemeral_agent_keeps_type_name_task_and_parent_distinct():
    agent = AgentIdentity(
        agent_id="ag-17", name="Atlas", role="worker",
        agent_type="implementation", task_id="task-17",
        task_name="Storage Topology", parent_agent_id="primary-1",
        world_id="world-1"
    )
    assert agent.agent_type == "implementation"
    assert agent.name == "Atlas"
    assert agent.task_name == "Storage Topology"
    assert agent.parent_agent_id == "primary-1"


def test_repartition_increments_topology_version_and_emits_receipt():
    events = repartition_events(
        world_id="world-1", old_version=1,
        split_task_id="task-17", new_task_ids=("task-17a", "task-17b"),
        actor_id="twin-1", reason="temporal_upper_breach"
    )
    assert events[0].event_type == "TOPOLOGY_REPARTITIONED"
    assert events[0].payload["old_version"] == 1
    assert events[0].payload["new_version"] == 2
    assert events[0].payload["new_task_ids"] == ["task-17a", "task-17b"]

from fcao.model import Event
from fcao.reducer import reduce_events


def test_reducer_applies_repartition_as_a_new_topology_version():
    events = [
        Event.make("WORLD_OPEN", "world-1", {"closure_target": 1.0}),
        Event.make("TASK_CREATED", "world-1", {"task_id": "task-17", "name": "Storage", "state": "RUNNING"}),
        *repartition_events(
            world_id="world-1", old_version=1,
            split_task_id="task-17", new_task_ids=("task-17a", "task-17b"),
            actor_id="twin-1", reason="temporal_upper_breach"
        ),
    ]
    state = reduce_events(events)
    assert state.topology_version == 2
    assert state.tasks["task-17"].state == "REOPENED"
    assert set(state.tasks) >= {"task-17", "task-17a", "task-17b"}
