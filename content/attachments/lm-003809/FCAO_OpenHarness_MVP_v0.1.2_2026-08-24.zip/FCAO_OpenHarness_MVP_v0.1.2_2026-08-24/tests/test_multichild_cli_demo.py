import json
import os
from pathlib import Path
import subprocess
import sys


def _env():
    env = os.environ.copy()
    src = str(Path.cwd() / "src")
    env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def _run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "fcao.cli", *args],
        text=True,
        capture_output=True,
        check=check,
        env=_env(),
    )


def test_multichild_demo_exposes_clean_e2_boundary_and_merge_governance(tmp_path):
    db = tmp_path / "e2.db"
    proc = _run("multichild-demo", "--db", str(db))
    result = json.loads(proc.stdout)

    assert result["world_id"] == "fcao-apr-deterministic-exp-02"
    assert result["topology"] == "split-3"
    assert result["single_control"] == "single"
    assert result["logical_child_count"] == 3
    assert result["child_names"] == ["Atlas", "Curie", "Kepler"]
    assert result["all_children_direct"] is True
    assert result["recursive_children"] == 0
    assert result["local_twins"] == 0
    assert result["apr_actions"] == [
        "NO_OBSERVATION",
        "STRUCTURED_INSPECTION",
        "TARGETED_OBSERVATION",
        "TARGETED_OBSERVATION",
    ]
    assert result["twin_sequence"] == ["CHALLENGE", "CONCUR"]
    assert result["merge_blocked_before_resolution"] is True
    assert result["merge_ready_after_resolution"] is True
    assert result["final_closure_eligible"] is True
    assert result["active_closure_id"] == "gcc-e2-1"
    assert result["replay_matches"] is True


def test_multichild_demo_replay_preserves_fanout_assignments_conflict_resolution_and_no_recursion(tmp_path):
    db = tmp_path / "e2.db"
    _run("multichild-demo", "--db", str(db))
    replay = _run("replay", "--db", str(db), "--world", "fcao-apr-deterministic-exp-02")
    state = json.loads(replay.stdout)

    assert state["fanouts"]["fanout-e2"]["child_task_ids"] == ["task-atlas", "task-kepler", "task-curie"]
    assert state["tasks"]["task-atlas"]["assigned_agent_id"] == "child-atlas"
    assert state["tasks"]["task-kepler"]["assigned_agent_id"] == "child-kepler"
    assert state["tasks"]["task-curie"]["assigned_agent_id"] == "child-curie"
    assert state["collaboration_conflicts"]["conflict-schema"]["status"] == "RESOLVED"
    assert state["collaboration_conflicts"]["conflict-schema"]["resolution_ref"] == "evidence://schema-compatibility"
    assert [item["ready"] for item in state["merge_assessments"]] == [False, True]
    child_agents = [agent for agent in state["agents"].values() if agent["role"] == "child"]
    assert {agent["parent_agent_id"] for agent in child_agents} == {"primary-1"}


def test_multichild_demo_final_closure_verifies_against_replay(tmp_path):
    db = tmp_path / "e2.db"
    _run("multichild-demo", "--db", str(db))
    verify = _run("verify", "--db", str(db), "--world", "fcao-apr-deterministic-exp-02")
    result = json.loads(verify.stdout)
    assert result["valid"] is True
    assert result["active_closure_id"] == "gcc-e2-1"
    assert result["computed_eligible"] is True
