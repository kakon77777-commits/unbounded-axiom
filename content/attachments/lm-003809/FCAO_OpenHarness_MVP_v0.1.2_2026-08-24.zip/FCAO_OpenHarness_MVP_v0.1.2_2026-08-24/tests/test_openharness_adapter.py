from pathlib import Path

from fcao.adapters.openharness.adapter import OpenHarnessAdapter


class FakeBridge:
    def __init__(self):
        self.calls = []

    def capabilities(self):
        return {"agent_spawn": True, "mcp": True}

    def spawn(self, payload):
        self.calls.append(("spawn", payload))
        return "task-42"

    def send(self, handle, message):
        self.calls.append(("send", handle, message))
        return {"ok": True}

    def status(self, handle):
        return "running"

    def collect(self, handle):
        return {"status": "completed", "result": "ok"}

    def stop(self, handle, reason):
        self.calls.append(("stop", handle, reason))
        return {"ok": True}


def test_openharness_adapter_preserves_fcao_identity_outside_runtime_handle():
    bridge = FakeBridge()
    adapter = OpenHarnessAdapter(bridge)
    handle = adapter.spawn({"fcao_agent_id": "ag-17", "ephemeral_name": "Atlas", "prompt": "work"})
    assert handle.runtime_id == "task-42"
    assert handle.fcao_agent_id == "ag-17"
    assert handle.ephemeral_name == "Atlas"
    assert bridge.calls[0][0] == "spawn"


def test_adapter_forwards_runtime_operations_without_changing_canonical_identity():
    bridge = FakeBridge()
    adapter = OpenHarnessAdapter(bridge)
    handle = adapter.spawn({"fcao_agent_id": "ag-17", "ephemeral_name": "Atlas", "prompt": "work"})
    assert adapter.status(handle) == "running"
    assert adapter.send(handle, "follow up")["ok"]
    assert adapter.collect(handle)["result"] == "ok"
    assert adapter.stop(handle, "done")["ok"]
    assert adapter.capabilities()["mcp"] is True


def test_fcao_core_has_no_openharness_imports_outside_adapter():
    root = Path("src/fcao")
    violations = []
    for path in root.rglob("*.py"):
        if "adapters/openharness" in path.as_posix():
            continue
        text = path.read_text(encoding="utf-8")
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("import openharness") or stripped.startswith("from openharness"):
                violations.append(path.as_posix())
    assert violations == []
