import json
import os
from pathlib import Path
import subprocess
import sys


def _env():
    env = os.environ.copy()
    src = str(Path.cwd() / "src")
    env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def _run(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-m", "fcao.cli", *args],
        text=True,
        capture_output=True,
        check=check,
        env=_env(),
    )


def test_apr_demo_keeps_zero_child_boundary_and_supersedes_first_closure(tmp_path):
    db = tmp_path / "apr.db"
    proc = _run("apr-demo", "--db", str(db))
    result = json.loads(proc.stdout)
    assert result["world_id"] == "fcao-apr-operational-exp-01"
    assert result["topology"] == "single"
    assert result["subagents_started"] == 0
    assert result["runtime_observation"] == "NO_OBSERVATION"
    assert result["authorization_observation_before"] == "TARGETED_OBSERVATION"
    assert result["authorization_observation_after"] == "NO_OBSERVATION"
    assert result["twin_sequence"] == ["IDLE", "CHALLENGE", "CONCUR", "CHALLENGE", "CONCUR"]
    assert result["first_closure_superseded"] is True
    assert result["active_closure_id"] == "gcc-2"
    assert result["final_closure_eligible"] is True
    assert result["replay_matches"] is True


def test_apr_demo_registers_no_child_agents(tmp_path):
    db = tmp_path / "apr.db"
    _run("apr-demo", "--db", str(db))
    replay = _run("replay", "--db", str(db), "--world", "fcao-apr-operational-exp-01")
    state = json.loads(replay.stdout)
    assert all(agent["role"] != "child" for agent in state["agents"].values())
    assert len(state["evidence"]) == 2
    assert [item["action"] for item in state["observation_decisions"]] == [
        "NO_OBSERVATION", "TARGETED_OBSERVATION", "NO_OBSERVATION"
    ]
    assert state["closure_supersessions"] == {"gcc-1": "gcc-2"}


def test_verify_uses_active_non_superseded_closure(tmp_path):
    db = tmp_path / "apr.db"
    _run("apr-demo", "--db", str(db))
    verify = _run("verify", "--db", str(db), "--world", "fcao-apr-operational-exp-01")
    result = json.loads(verify.stdout)
    assert result["valid"] is True
    assert result["active_closure_id"] == "gcc-2"
