import json
import os
from pathlib import Path
import subprocess
import sys


def _env():
    env = os.environ.copy()
    src = str(Path.cwd() / "src")
    env["PYTHONPATH"] = src + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def test_demo_exercises_split_twin_repartition_and_closure(tmp_path):
    db = tmp_path / "demo.db"
    proc = subprocess.run(
        [sys.executable, "-m", "fcao.cli", "demo", "--db", str(db)],
        text=True, capture_output=True, check=True, env=_env()
    )
    result = json.loads(proc.stdout)
    assert result["single_case"] == "single"
    assert result["split_case"] == "split-2"
    assert result["twin_idle"] == "IDLE"
    assert result["repartitioned"] is True
    assert result["closure_eligible"] is True
    assert result["replay_matches"] is True


def test_replay_and_verify_commands_read_the_persisted_world(tmp_path):
    db = tmp_path / "demo.db"
    demo = subprocess.run(
        [sys.executable, "-m", "fcao.cli", "demo", "--db", str(db)],
        text=True, capture_output=True, check=True, env=_env()
    )
    world_id = json.loads(demo.stdout)["world_id"]

    replay = subprocess.run(
        [sys.executable, "-m", "fcao.cli", "replay", "--db", str(db), "--world", world_id],
        text=True, capture_output=True, check=True, env=_env()
    )
    replay_state = json.loads(replay.stdout)
    assert replay_state["world_id"] == world_id
    assert replay_state["topology_version"] == 2

    verify = subprocess.run(
        [sys.executable, "-m", "fcao.cli", "verify", "--db", str(db), "--world", world_id],
        text=True, capture_output=True, check=True, env=_env()
    )
    verify_result = json.loads(verify.stdout)
    assert verify_result["valid"] is True
