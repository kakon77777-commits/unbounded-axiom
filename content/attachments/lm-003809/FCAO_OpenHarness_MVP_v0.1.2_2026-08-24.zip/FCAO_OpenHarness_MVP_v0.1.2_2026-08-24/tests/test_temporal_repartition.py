import pytest

from fcao.temporal import TemporalEnvelope
from fcao.topology import TopologyEstimate, choose_candidate


def test_single_is_chosen_when_split_overhead_is_worse():
    choices = [
        TopologyEstimate("single", 100, 180, cost=1.0, risk=0.1),
        TopologyEstimate("split-2", 120, 240, cost=1.6, risk=0.1),
    ]
    assert choose_candidate(choices, policy="balanced").candidate_id == "single"


def test_split_is_chosen_when_upper_bound_and_cost_improve():
    choices = [
        TopologyEstimate("single", 500, 900, cost=3.0, risk=0.2),
        TopologyEstimate("split-2", 260, 480, cost=2.7, risk=0.2),
    ]
    assert choose_candidate(choices, policy="balanced").candidate_id == "split-2"


def test_temporal_upper_breach_is_detected():
    env = TemporalEnvelope(lower_ms=100, upper_ms=200, confidence=0.7)
    assert env.is_breached(201)
    assert not env.is_breached(200)


def test_invalid_temporal_envelope_is_rejected():
    with pytest.raises(ValueError):
        TemporalEnvelope(lower_ms=300, upper_ms=200, confidence=0.7)
    with pytest.raises(ValueError):
        TemporalEnvelope(lower_ms=0, upper_ms=200, confidence=1.2)
