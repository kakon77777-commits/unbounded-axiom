from fcao.apr import APRController
from fcao.model import Event
from fcao.reducer import reduce_events


def test_verified_evidence_returns_no_observation():
    events = [
        Event.make("WORLD_OPEN", "w", {"closure_target": 1.0}),
        Event.make("EVIDENCE_RECORDED", "w", {
            "evidence_id": "ev-1",
            "key": "runtime-integrity",
            "status": "VERIFIED",
            "confidence": 0.95,
            "source_ref": "receipt://runtime",
        }),
    ]
    state = reduce_events(events)
    decision = APRController().decide("runtime-integrity", state)
    assert decision.action == "NO_OBSERVATION"


def test_unknown_evidence_requires_targeted_observation():
    state = reduce_events([Event.make("WORLD_OPEN", "w", {"closure_target": 1.0})])
    decision = APRController().decide("cleanup-authorization", state)
    assert decision.action == "TARGETED_OBSERVATION"


def test_low_confidence_evidence_requires_structured_inspection():
    events = [
        Event.make("WORLD_OPEN", "w", {"closure_target": 1.0}),
        Event.make("EVIDENCE_RECORDED", "w", {
            "evidence_id": "ev-2",
            "key": "cleanup-authorization",
            "status": "OBSERVED",
            "confidence": 0.4,
            "source_ref": "user://ambiguous",
        }),
    ]
    state = reduce_events(events)
    decision = APRController().decide("cleanup-authorization", state)
    assert decision.action == "STRUCTURED_INSPECTION"


def test_observation_decision_replays_into_state():
    events = [
        Event.make("WORLD_OPEN", "w", {"closure_target": 1.0}),
        Event.make("OBSERVATION_DECIDED", "w", {
            "evidence_key": "runtime-integrity",
            "action": "NO_OBSERVATION",
            "reason": "verified-evidence-sufficient",
        }),
    ]
    state = reduce_events(events)
    assert state.observation_decisions[-1]["action"] == "NO_OBSERVATION"
