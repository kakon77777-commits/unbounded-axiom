from fcao.runtime import TwinGovernor


def test_twin_challenges_unresolved_cross_child_conflict():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect_merge(
        blocking_tasks=(),
        unresolved_conflicts=("conflict-1",),
        risk=0.2,
    )
    assert decision.action == "CHALLENGE"
    assert decision.reason == "cross-child-conflict"


def test_twin_challenges_merge_with_blocking_child_tasks():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect_merge(
        blocking_tasks=("task-c",),
        unresolved_conflicts=(),
        risk=0.2,
    )
    assert decision.action == "CHALLENGE"
    assert decision.reason == "merge-not-ready"


def test_twin_audits_high_risk_merge_even_when_structurally_ready():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect_merge(
        blocking_tasks=(),
        unresolved_conflicts=(),
        risk=0.8,
    )
    assert decision.action == "AUDIT"
    assert decision.reason == "risk-threshold-exceeded"


def test_twin_concurs_with_clean_low_risk_merge():
    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    decision = twin.inspect_merge(
        blocking_tasks=(),
        unresolved_conflicts=(),
        risk=0.2,
    )
    assert decision.action == "CONCUR"
    assert decision.reason == "merge-ready"
