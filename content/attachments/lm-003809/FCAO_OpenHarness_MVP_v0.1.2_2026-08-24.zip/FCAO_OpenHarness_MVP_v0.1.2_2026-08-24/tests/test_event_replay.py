from fcao.event_store import SQLiteEventStore
from fcao.model import Event
from fcao.reducer import reduce_events


def test_event_log_replays_same_world_state(tmp_path):
    store = SQLiteEventStore(tmp_path / "fcao.db")
    store.append(Event.make("WORLD_OPEN", "world-1", {"closure_target": 1.0}))
    store.append(Event.make("AGENT_REGISTERED", "world-1", {
        "agent_id": "primary-1", "name": "Polaris", "role": "primary"
    }))
    events = store.read_all("world-1")
    state = reduce_events(events)
    assert state.world_id == "world-1"
    assert state.agents["primary-1"].name == "Polaris"
    assert state.revision == 2
