from fcao.closure import active_closure
from fcao.model import Event
from fcao.reducer import reduce_events


def test_superseded_closure_is_preserved_but_not_active():
    events = [
        Event.make("WORLD_OPEN", "w", {"closure_target": 1.0}),
        Event.make("GLOBAL_CLOSURE_ISSUED", "w", {
            "closure_id": "gcc-1", "eligible": True, "coverage": 1.0,
            "blocking_tasks": [], "topology_version": 1,
        }),
        Event.make("CLOSURE_SUPERSEDED", "w", {
            "old_closure_id": "gcc-1", "new_closure_id": "gcc-2",
            "reason": "missing-mandatory-node",
        }),
        Event.make("GLOBAL_CLOSURE_ISSUED", "w", {
            "closure_id": "gcc-2", "eligible": True, "coverage": 1.0,
            "blocking_tasks": [], "topology_version": 1,
        }),
    ]
    state = reduce_events(events)
    assert [c["closure_id"] for c in state.closures] == ["gcc-1", "gcc-2"]
    assert state.closure_supersessions["gcc-1"] == "gcc-2"
    assert active_closure(state)["closure_id"] == "gcc-2"


def test_active_closure_returns_none_when_only_closure_is_superseded():
    events = [
        Event.make("WORLD_OPEN", "w", {"closure_target": 1.0}),
        Event.make("GLOBAL_CLOSURE_ISSUED", "w", {
            "closure_id": "gcc-1", "eligible": True, "coverage": 1.0,
            "blocking_tasks": [], "topology_version": 1,
        }),
        Event.make("CLOSURE_SUPERSEDED", "w", {
            "old_closure_id": "gcc-1", "new_closure_id": "gcc-2",
            "reason": "replacement-pending",
        }),
    ]
    state = reduce_events(events)
    assert active_closure(state) is None
