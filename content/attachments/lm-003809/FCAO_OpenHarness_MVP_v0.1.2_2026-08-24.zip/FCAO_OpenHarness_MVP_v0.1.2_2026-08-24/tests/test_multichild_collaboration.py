from fcao.closure import LocalClosureCertificate
from fcao.collaboration import assess_merge
from fcao.model import Event
from fcao.reducer import reduce_events


def _base_events():
    world = "e2-world"
    events = [
        Event.make("WORLD_OPEN", world, {"closure_target": 1.0}),
        Event.make("AGENT_REGISTERED", world, {
            "agent_id": "primary-1", "name": "Primary", "role": "primary", "agent_type": "controller"
        }),
    ]
    for agent_id, name, task_id in [
        ("child-atlas", "Atlas", "task-a"),
        ("child-kepler", "Kepler", "task-b"),
        ("child-curie", "Curie", "task-c"),
    ]:
        events.append(Event.make("AGENT_REGISTERED", world, {
            "agent_id": agent_id,
            "name": name,
            "role": "child",
            "agent_type": "worker",
            "task_id": task_id,
            "task_name": task_id,
            "parent_agent_id": "primary-1",
        }))
    events.append(Event.make("FANOUT_DECLARED", world, {
        "group_id": "fanout-1",
        "root_task_id": "project-root",
        "child_task_ids": ["task-a", "task-b", "task-c"],
    }))
    for task_id, agent_id in [
        ("task-a", "child-atlas"),
        ("task-b", "child-kepler"),
        ("task-c", "child-curie"),
    ]:
        events.extend([
            Event.make("TASK_CREATED", world, {"task_id": task_id, "name": task_id, "state": "COMPLETED"}),
            Event.make("TASK_ASSIGNED", world, {"task_id": task_id, "agent_id": agent_id}),
            Event.make("LCC_SUBMITTED", world, {
                "task_id": task_id,
                "agent_id": agent_id,
                "satisfied": 1,
                "mandatory": 1,
                "open_gaps": [],
                "verified_artifacts": [f"artifact://{task_id}"],
            }),
        ])
    events.extend([
        Event.make("TASK_CREATED", world, {"task_id": "task-merge", "name": "Merge", "state": "COMPLETED"}),
        Event.make("TASK_ASSIGNED", world, {"task_id": "task-merge", "agent_id": "primary-1"}),
        Event.make("LCC_SUBMITTED", world, {
            "task_id": "task-merge",
            "agent_id": "primary-1",
            "satisfied": 1,
            "mandatory": 1,
            "open_gaps": [],
            "verified_artifacts": ["artifact://merge"],
        }),
    ])
    return events


def test_replay_preserves_three_named_direct_children_and_fanout_group():
    state = reduce_events(_base_events())
    assert state.fanouts["fanout-1"].child_task_ids == ("task-a", "task-b", "task-c")
    child_agents = [agent for agent in state.agents.values() if agent.role == "child"]
    assert sorted(agent.name for agent in child_agents) == ["Atlas", "Curie", "Kepler"]
    assert {agent.parent_agent_id for agent in child_agents} == {"primary-1"}
    assert state.tasks["task-a"].assigned_agent_id == "child-atlas"
    assert state.tasks["task-b"].assigned_agent_id == "child-kepler"
    assert state.tasks["task-c"].assigned_agent_id == "child-curie"


def test_unresolved_cross_child_conflict_blocks_merge_even_when_lccs_are_complete():
    events = _base_events() + [
        Event.make("COLLAB_CONFLICT_RECORDED", "e2-world", {
            "conflict_id": "conflict-1",
            "task_ids": ["task-a", "task-b"],
            "reason": "schema-version-mismatch",
        })
    ]
    state = reduce_events(events)
    result = assess_merge(state, ("task-a", "task-b", "task-c"), "task-merge")
    assert result.ready is False
    assert result.blocking_tasks == ()
    assert result.unresolved_conflicts == ("conflict-1",)


def test_resolved_conflict_allows_merge_when_all_child_and_merge_lccs_are_complete():
    events = _base_events() + [
        Event.make("COLLAB_CONFLICT_RECORDED", "e2-world", {
            "conflict_id": "conflict-1",
            "task_ids": ["task-a", "task-b"],
            "reason": "schema-version-mismatch",
        }),
        Event.make("COLLAB_CONFLICT_RESOLVED", "e2-world", {
            "conflict_id": "conflict-1",
            "resolution_ref": "evidence://schema-compatibility",
        }),
    ]
    state = reduce_events(events)
    result = assess_merge(state, ("task-a", "task-b", "task-c"), "task-merge")
    assert result.ready is True
    assert result.blocking_tasks == ()
    assert result.unresolved_conflicts == ()


def test_missing_child_lcc_blocks_merge_by_task_id():
    events = [event for event in _base_events() if not (
        event.event_type == "LCC_SUBMITTED" and event.payload.get("task_id") == "task-c"
    )]
    state = reduce_events(events)
    result = assess_merge(state, ("task-a", "task-b", "task-c"), "task-merge")
    assert result.ready is False
    assert result.blocking_tasks == ("task-c",)


def test_unresolved_collaboration_conflict_blocks_global_closure():
    from fcao.closure import evaluate_closure

    events = _base_events() + [
        Event.make("COLLAB_CONFLICT_RECORDED", "e2-world", {
            "conflict_id": "conflict-1",
            "task_ids": ["task-a", "task-b"],
            "reason": "schema-version-mismatch",
        })
    ]
    state = reduce_events(events)
    gcc = evaluate_closure(state)
    assert gcc.eligible is False
    assert gcc.blocking_conflicts == ("conflict-1",)
