from __future__ import annotations

from dataclasses import dataclass

from .model import ProjectState


@dataclass(frozen=True, slots=True)
class EvidenceRecord:
    evidence_id: str
    key: str
    status: str
    confidence: float
    source_ref: str

    def __post_init__(self) -> None:
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be in [0, 1]")


@dataclass(frozen=True, slots=True)
class ObservationDecision:
    evidence_key: str
    action: str
    reason: str


class APRController:
    def decide(
        self,
        evidence_key: str,
        state: ProjectState,
        required_confidence: float = 0.8,
    ) -> ObservationDecision:
        if not 0 <= required_confidence <= 1:
            raise ValueError("required_confidence must be in [0, 1]")
        record = state.evidence.get(evidence_key)
        if record is None:
            return ObservationDecision(
                evidence_key=evidence_key,
                action="TARGETED_OBSERVATION",
                reason="evidence-missing",
            )
        if record.status == "VERIFIED" and record.confidence >= required_confidence:
            return ObservationDecision(
                evidence_key=evidence_key,
                action="NO_OBSERVATION",
                reason="verified-evidence-sufficient",
            )
        return ObservationDecision(
            evidence_key=evidence_key,
            action="STRUCTURED_INSPECTION",
            reason="evidence-insufficient",
        )
