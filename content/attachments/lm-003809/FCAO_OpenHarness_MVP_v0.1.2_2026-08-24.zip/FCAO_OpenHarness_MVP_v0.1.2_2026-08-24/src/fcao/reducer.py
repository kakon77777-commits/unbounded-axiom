from __future__ import annotations

from .model import AgentIdentity, Event, ProjectState, TaskNode


def reduce_events(events: list[Event]) -> ProjectState:
    if not events:
        raise ValueError("cannot reduce an empty event stream")

    state: ProjectState | None = None
    for event in events:
        if state is None:
            if event.event_type != "WORLD_OPEN":
                raise ValueError("first event must be WORLD_OPEN")
            state = ProjectState(
                world_id=event.world_id,
                closure_target=float(event.payload.get("closure_target", 1.0)),
            )
        elif event.world_id != state.world_id:
            raise ValueError("event world_id does not match current state")

        if event.event_type == "AGENT_REGISTERED":
            identity = AgentIdentity(
                agent_id=event.payload["agent_id"],
                name=event.payload["name"],
                role=event.payload["role"],
                agent_type=event.payload.get("agent_type"),
                task_id=event.payload.get("task_id"),
                task_name=event.payload.get("task_name"),
                parent_agent_id=event.payload.get("parent_agent_id"),
                world_id=event.world_id,
                team_id=event.payload.get("team_id"),
            )
            state.agents[identity.agent_id] = identity
        elif event.event_type == "TASK_CREATED":
            task = TaskNode(
                task_id=event.payload["task_id"],
                name=event.payload["name"],
                state=event.payload.get("state", "PENDING"),
                parent_task_id=event.payload.get("parent_task_id"),
            )
            state.tasks[task.task_id] = task
        elif event.event_type == "TASK_ASSIGNED":
            task = state.tasks.get(event.payload["task_id"])
            if task is None:
                raise ValueError("cannot assign an unknown task")
            task.assigned_agent_id = event.payload["agent_id"]
        elif event.event_type == "FANOUT_DECLARED":
            from .collaboration import FanoutGroup
            group = FanoutGroup(
                group_id=event.payload["group_id"],
                root_task_id=event.payload["root_task_id"],
                child_task_ids=tuple(event.payload["child_task_ids"]),
            )
            state.fanouts[group.group_id] = group
        elif event.event_type == "COLLAB_CONFLICT_RECORDED":
            from .collaboration import CollaborationConflict
            conflict = CollaborationConflict(
                conflict_id=event.payload["conflict_id"],
                task_ids=tuple(event.payload["task_ids"]),
                reason=event.payload["reason"],
            )
            state.collaboration_conflicts[conflict.conflict_id] = conflict
        elif event.event_type == "COLLAB_CONFLICT_RESOLVED":
            from .collaboration import CollaborationConflict
            conflict_id = event.payload["conflict_id"]
            current = state.collaboration_conflicts.get(conflict_id)
            if current is None:
                raise ValueError("cannot resolve an unknown collaboration conflict")
            state.collaboration_conflicts[conflict_id] = CollaborationConflict(
                conflict_id=current.conflict_id,
                task_ids=current.task_ids,
                reason=current.reason,
                status="RESOLVED",
                resolution_ref=event.payload["resolution_ref"],
            )
        elif event.event_type == "MERGE_ASSESSED":
            state.merge_assessments.append(dict(event.payload))
        elif event.event_type == "TOPOLOGY_REPARTITIONED":
            old_version = int(event.payload["old_version"])
            if old_version != state.topology_version:
                raise ValueError("topology version mismatch")
            split_task_id = event.payload["split_task_id"]
            if split_task_id in state.tasks:
                state.tasks[split_task_id].state = "REOPENED"
            for task_id in event.payload["new_task_ids"]:
                state.tasks[task_id] = TaskNode(
                    task_id=task_id,
                    name=task_id,
                    state="PENDING",
                    parent_task_id=split_task_id,
                )
            state.topology_version = int(event.payload["new_version"])
        elif event.event_type == "LCC_SUBMITTED":
            from .closure import LocalClosureCertificate
            state.lccs[event.payload["task_id"]] = LocalClosureCertificate(
                task_id=event.payload["task_id"],
                agent_id=event.payload["agent_id"],
                satisfied=int(event.payload["satisfied"]),
                mandatory=int(event.payload["mandatory"]),
                open_gaps=tuple(event.payload.get("open_gaps", [])),
                verified_artifacts=tuple(event.payload.get("verified_artifacts", [])),
            )
        elif event.event_type == "EVIDENCE_RECORDED":
            from .apr import EvidenceRecord
            record = EvidenceRecord(
                evidence_id=event.payload["evidence_id"],
                key=event.payload["key"],
                status=event.payload["status"],
                confidence=float(event.payload["confidence"]),
                source_ref=event.payload["source_ref"],
            )
            state.evidence[record.key] = record
        elif event.event_type == "OBSERVATION_DECIDED":
            state.observation_decisions.append(dict(event.payload))
        elif event.event_type == "TWIN_DECISION":
            state.twin_decisions.append(dict(event.payload))
        elif event.event_type == "CLOSURE_SUPERSEDED":
            state.closure_supersessions[event.payload["old_closure_id"]] = event.payload["new_closure_id"]
        elif event.event_type == "GLOBAL_CLOSURE_ISSUED":
            state.closures.append(dict(event.payload))

        state.revision += 1

    assert state is not None
    return state
