from __future__ import annotations

from dataclasses import dataclass

from .model import Event


@dataclass(frozen=True, slots=True)
class TopologyEdge:
    source: str
    target: str
    edge_type: str


@dataclass(frozen=True, slots=True)
class TopologyCandidate:
    candidate_id: str


def repartition_events(
    *,
    world_id: str,
    old_version: int,
    split_task_id: str,
    new_task_ids: tuple[str, ...],
    actor_id: str,
    reason: str,
) -> list[Event]:
    if not new_task_ids:
        raise ValueError("repartition requires at least one new task")
    return [
        Event.make(
            "TOPOLOGY_REPARTITIONED",
            world_id,
            {
                "old_version": old_version,
                "new_version": old_version + 1,
                "split_task_id": split_task_id,
                "new_task_ids": list(new_task_ids),
                "actor_id": actor_id,
                "reason": reason,
            },
        )
    ]


@dataclass(frozen=True, slots=True)
class TopologyEstimate:
    candidate_id: str
    lower_ms: float
    upper_ms: float
    cost: float
    risk: float

    def __post_init__(self) -> None:
        if self.lower_ms < 0 or self.upper_ms < self.lower_ms:
            raise ValueError("invalid topology temporal bounds")
        if self.cost < 0 or self.risk < 0:
            raise ValueError("cost and risk must be non-negative")


def choose_candidate(candidates: list[TopologyEstimate], policy: str = "balanced") -> TopologyEstimate:
    if not candidates:
        raise ValueError("at least one topology candidate is required")
    if policy != "balanced":
        raise ValueError(f"unsupported policy: {policy}")
    return min(candidates, key=lambda item: (item.upper_ms, item.cost, item.risk, item.candidate_id))
