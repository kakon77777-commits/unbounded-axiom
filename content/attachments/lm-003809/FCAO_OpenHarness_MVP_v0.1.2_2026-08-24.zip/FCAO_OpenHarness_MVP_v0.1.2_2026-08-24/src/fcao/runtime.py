from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TwinDecision:
    agent_id: str
    action: str
    reason: str


class TwinGovernor:
    def __init__(self, agent_id: str, risk_threshold: float = 0.7):
        if not 0 <= risk_threshold <= 1:
            raise ValueError("risk_threshold must be in [0, 1]")
        self.agent_id = agent_id
        self.risk_threshold = risk_threshold

    def inspect(
        self,
        *,
        risk: float,
        closure_candidate: bool,
        open_gaps: tuple[str, ...],
    ) -> TwinDecision:
        if closure_candidate and open_gaps:
            return TwinDecision(self.agent_id, "CHALLENGE", "closure-has-open-gaps")
        if risk >= self.risk_threshold:
            return TwinDecision(self.agent_id, "AUDIT", "risk-threshold-exceeded")
        return TwinDecision(self.agent_id, "IDLE", "no-actionable-risk")
    def inspect_merge(
        self,
        *,
        blocking_tasks: tuple[str, ...],
        unresolved_conflicts: tuple[str, ...],
        risk: float,
    ) -> TwinDecision:
        if unresolved_conflicts:
            return TwinDecision(self.agent_id, "CHALLENGE", "cross-child-conflict")
        if blocking_tasks:
            return TwinDecision(self.agent_id, "CHALLENGE", "merge-not-ready")
        if risk >= self.risk_threshold:
            return TwinDecision(self.agent_id, "AUDIT", "risk-threshold-exceeded")
        return TwinDecision(self.agent_id, "CONCUR", "merge-ready")

