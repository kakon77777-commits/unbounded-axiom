"""OpenHarness adapter boundary for FCAO."""
