from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol


class OpenHarnessBridge(Protocol):
    def capabilities(self) -> dict[str, Any]: ...
    def spawn(self, payload: dict[str, Any]) -> str: ...
    def send(self, handle: str, message: str) -> dict[str, Any]: ...
    def status(self, handle: str) -> str: ...
    def collect(self, handle: str) -> dict[str, Any]: ...
    def stop(self, handle: str, reason: str) -> dict[str, Any]: ...


@dataclass(frozen=True, slots=True)
class ExecutionHandle:
    runtime_id: str
    fcao_agent_id: str
    ephemeral_name: str


class OpenHarnessAdapter:
    def __init__(self, bridge: OpenHarnessBridge):
        self._bridge = bridge

    def capabilities(self) -> dict[str, Any]:
        return dict(self._bridge.capabilities())

    def spawn(self, request: dict[str, Any]) -> ExecutionHandle:
        fcao_agent_id = str(request["fcao_agent_id"])
        ephemeral_name = str(request["ephemeral_name"])
        runtime_id = str(self._bridge.spawn(dict(request)))
        return ExecutionHandle(runtime_id, fcao_agent_id, ephemeral_name)

    def send(self, handle: ExecutionHandle, message: str) -> dict[str, Any]:
        return dict(self._bridge.send(handle.runtime_id, message))

    def status(self, handle: ExecutionHandle) -> str:
        return str(self._bridge.status(handle.runtime_id))

    def collect(self, handle: ExecutionHandle) -> dict[str, Any]:
        return dict(self._bridge.collect(handle.runtime_id))

    def stop(self, handle: ExecutionHandle, reason: str) -> dict[str, Any]:
        return dict(self._bridge.stop(handle.runtime_id, reason))
