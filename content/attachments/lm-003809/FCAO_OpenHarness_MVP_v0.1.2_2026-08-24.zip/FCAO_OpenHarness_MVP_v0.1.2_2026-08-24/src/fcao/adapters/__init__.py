"""Execution adapters for FCAO runtimes."""
