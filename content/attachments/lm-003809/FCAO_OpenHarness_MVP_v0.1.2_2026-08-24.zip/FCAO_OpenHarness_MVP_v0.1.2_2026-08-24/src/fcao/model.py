from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4


@dataclass(frozen=True, slots=True)
class Event:
    event_id: str
    event_type: str
    world_id: str
    occurred_at: str
    payload: dict[str, Any]

    @classmethod
    def make(cls, event_type: str, world_id: str, payload: dict[str, Any]) -> "Event":
        return cls(
            event_id=str(uuid4()),
            event_type=event_type,
            world_id=world_id,
            occurred_at=datetime.now(timezone.utc).isoformat(),
            payload=dict(payload),
        )


@dataclass(frozen=True, slots=True)
class AgentIdentity:
    agent_id: str
    name: str
    role: str
    agent_type: str | None = None
    task_id: str | None = None
    task_name: str | None = None
    parent_agent_id: str | None = None
    world_id: str | None = None
    team_id: str | None = None


@dataclass(slots=True)
class TaskNode:
    task_id: str
    name: str
    state: str = "PENDING"
    parent_task_id: str | None = None
    assigned_agent_id: str | None = None


@dataclass(slots=True)
class ProjectState:
    world_id: str
    closure_target: float = 1.0
    revision: int = 0
    topology_version: int = 1
    agents: dict[str, AgentIdentity] = field(default_factory=dict)
    tasks: dict[str, TaskNode] = field(default_factory=dict)
    lccs: dict[str, Any] = field(default_factory=dict)
    evidence: dict[str, Any] = field(default_factory=dict)
    observation_decisions: list[dict[str, Any]] = field(default_factory=list)
    twin_decisions: list[dict[str, Any]] = field(default_factory=list)
    closures: list[dict[str, Any]] = field(default_factory=list)
    closure_supersessions: dict[str, str] = field(default_factory=dict)
    fanouts: dict[str, Any] = field(default_factory=dict)
    collaboration_conflicts: dict[str, Any] = field(default_factory=dict)
    merge_assessments: list[dict[str, Any]] = field(default_factory=list)

    @classmethod
    def open(cls, world_id: str, closure_target: float = 1.0) -> "ProjectState":
        return cls(world_id=world_id, closure_target=closure_target)
