from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from .model import Event


class SQLiteEventStore:
    def __init__(self, path: str | Path):
        self.path = str(path)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self.path)

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS events (
                    seq INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT NOT NULL UNIQUE,
                    world_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    occurred_at TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                )
                """
            )

    def append(self, event: Event) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO events(event_id, world_id, event_type, occurred_at, payload_json) VALUES (?, ?, ?, ?, ?)",
                (
                    event.event_id,
                    event.world_id,
                    event.event_type,
                    event.occurred_at,
                    json.dumps(event.payload, ensure_ascii=False, sort_keys=True),
                ),
            )

    def read_all(self, world_id: str) -> list[Event]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT event_id, event_type, world_id, occurred_at, payload_json FROM events WHERE world_id = ? ORDER BY seq",
                (world_id,),
            ).fetchall()
        return [
            Event(
                event_id=row[0],
                event_type=row[1],
                world_id=row[2],
                occurred_at=row[3],
                payload=json.loads(row[4]),
            )
            for row in rows
        ]
