from __future__ import annotations

from dataclasses import dataclass

from .model import ProjectState


@dataclass(frozen=True, slots=True)
class FanoutGroup:
    group_id: str
    root_task_id: str
    child_task_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CollaborationConflict:
    conflict_id: str
    task_ids: tuple[str, ...]
    reason: str
    status: str = "OPEN"
    resolution_ref: str | None = None


@dataclass(frozen=True, slots=True)
class MergeAssessment:
    ready: bool
    blocking_tasks: tuple[str, ...]
    unresolved_conflicts: tuple[str, ...]


def assess_merge(
    state: ProjectState,
    child_task_ids: tuple[str, ...],
    merge_task_id: str,
) -> MergeAssessment:
    blocking: list[str] = []
    for task_id in (*child_task_ids, merge_task_id):
        task = state.tasks.get(task_id)
        cert = state.lccs.get(task_id)
        if task is None or task.state != "COMPLETED" or cert is None or not cert.complete:
            blocking.append(task_id)

    child_set = set(child_task_ids)
    unresolved = sorted(
        conflict.conflict_id
        for conflict in state.collaboration_conflicts.values()
        if conflict.status != "RESOLVED" and child_set.intersection(conflict.task_ids)
    )
    return MergeAssessment(
        ready=not blocking and not unresolved,
        blocking_tasks=tuple(sorted(set(blocking))),
        unresolved_conflicts=tuple(unresolved),
    )
