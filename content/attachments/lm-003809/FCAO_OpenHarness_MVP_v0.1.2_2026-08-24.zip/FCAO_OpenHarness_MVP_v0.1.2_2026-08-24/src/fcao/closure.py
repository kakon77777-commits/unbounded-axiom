from __future__ import annotations

from dataclasses import dataclass

from .model import ProjectState


@dataclass(frozen=True, slots=True)
class LocalClosureCertificate:
    task_id: str
    agent_id: str
    satisfied: int
    mandatory: int
    open_gaps: tuple[str, ...] = ()
    verified_artifacts: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.mandatory < 0 or self.satisfied < 0 or self.satisfied > self.mandatory:
            raise ValueError("invalid LCC obligation counts")

    @property
    def complete(self) -> bool:
        return self.mandatory > 0 and self.satisfied == self.mandatory and not self.open_gaps


@dataclass(frozen=True, slots=True)
class GlobalClosureCertificate:
    world_id: str
    eligible: bool
    coverage: float
    blocking_tasks: tuple[str, ...]
    blocking_conflicts: tuple[str, ...]
    topology_version: int


def evaluate_closure(state: ProjectState) -> GlobalClosureCertificate:
    if not state.tasks:
        return GlobalClosureCertificate(
            world_id=state.world_id,
            eligible=False,
            coverage=0.0,
            blocking_tasks=(),
            blocking_conflicts=(),
            topology_version=state.topology_version,
        )

    blocking: list[str] = []
    total_mandatory = 0
    total_satisfied = 0

    for task_id, task in state.tasks.items():
        cert = state.lccs.get(task_id)
        if cert is None:
            blocking.append(task_id)
            continue
        total_mandatory += cert.mandatory
        total_satisfied += cert.satisfied
        if task.state != "COMPLETED" or not cert.complete:
            blocking.append(task_id)

    coverage = total_satisfied / total_mandatory if total_mandatory else 0.0
    unresolved_conflicts = tuple(sorted(
        conflict.conflict_id
        for conflict in state.collaboration_conflicts.values()
        if conflict.status != "RESOLVED"
    ))
    eligible = coverage >= state.closure_target and not blocking and not unresolved_conflicts
    return GlobalClosureCertificate(
        world_id=state.world_id,
        eligible=eligible,
        coverage=coverage,
        blocking_tasks=tuple(sorted(set(blocking))),
        blocking_conflicts=unresolved_conflicts,
        topology_version=state.topology_version,
    )


def active_closure(state: ProjectState) -> dict | None:
    if not state.closures:
        return None
    superseded = set(state.closure_supersessions)
    for closure in reversed(state.closures):
        closure_id = closure.get("closure_id")
        if closure_id and closure_id not in superseded:
            return closure
    return None
