"""FCAO deterministic MVP core."""
