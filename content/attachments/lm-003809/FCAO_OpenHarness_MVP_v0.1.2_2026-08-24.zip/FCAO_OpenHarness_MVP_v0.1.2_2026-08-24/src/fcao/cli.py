from __future__ import annotations

import argparse
from dataclasses import asdict, is_dataclass
import json
from pathlib import Path
from typing import Any
from uuid import uuid4

from .apr import APRController
from .closure import active_closure, evaluate_closure
from .collaboration import assess_merge
from .event_store import SQLiteEventStore
from .model import Event, ProjectState
from .reducer import reduce_events
from .runtime import TwinGovernor
from .temporal import TemporalEnvelope
from .topology import TopologyEstimate, choose_candidate, repartition_events


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {key: _jsonable(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def state_to_dict(state: ProjectState) -> dict[str, Any]:
    return {
        "world_id": state.world_id,
        "closure_target": state.closure_target,
        "revision": state.revision,
        "topology_version": state.topology_version,
        "agents": {key: _jsonable(value) for key, value in sorted(state.agents.items())},
        "tasks": {key: _jsonable(value) for key, value in sorted(state.tasks.items())},
        "lccs": {key: _jsonable(value) for key, value in sorted(state.lccs.items())},
        "evidence": {key: _jsonable(value) for key, value in sorted(state.evidence.items())},
        "observation_decisions": _jsonable(state.observation_decisions),
        "twin_decisions": _jsonable(state.twin_decisions),
        "closures": _jsonable(state.closures),
        "closure_supersessions": dict(sorted(state.closure_supersessions.items())),
        "fanouts": {key: _jsonable(value) for key, value in sorted(state.fanouts.items())},
        "collaboration_conflicts": {
            key: _jsonable(value) for key, value in sorted(state.collaboration_conflicts.items())
        },
        "merge_assessments": _jsonable(state.merge_assessments),
    }


def _append(store: SQLiteEventStore, event: Event) -> None:
    store.append(event)


def _demo(db_path: Path) -> dict[str, Any]:
    store = SQLiteEventStore(db_path)
    world_id = f"fcao-demo-{uuid4().hex[:8]}"

    for event in [
        Event.make("WORLD_OPEN", world_id, {"closure_target": 1.0}),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "primary-1", "name": "Polaris", "role": "primary", "agent_type": "controller"
        }),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "twin-1", "name": "Argus", "role": "twin", "agent_type": "governor"
        }),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "ag-17", "name": "Atlas", "role": "worker",
            "agent_type": "implementation", "task_id": "task-17",
            "task_name": "Storage Topology", "parent_agent_id": "primary-1"
        }),
        Event.make("TASK_CREATED", world_id, {"task_id": "task-17", "name": "Storage Topology", "state": "RUNNING"}),
    ]:
        _append(store, event)

    single_case = choose_candidate([
        TopologyEstimate("single", 100, 180, cost=1.0, risk=0.1),
        TopologyEstimate("split-2", 120, 240, cost=1.6, risk=0.1),
    ]).candidate_id
    split_case = choose_candidate([
        TopologyEstimate("single", 500, 900, cost=3.0, risk=0.2),
        TopologyEstimate("split-2", 260, 480, cost=2.7, risk=0.2),
    ]).candidate_id

    twin = TwinGovernor("twin-1", risk_threshold=0.7)
    twin_idle = twin.inspect(risk=0.2, closure_candidate=False, open_gaps=()).action
    _append(store, Event.make("TWIN_DECISION", world_id, {
        "agent_id": "twin-1", "action": twin_idle, "reason": "no-actionable-risk"
    }))

    envelope = TemporalEnvelope(lower_ms=100, upper_ms=200, confidence=0.7)
    repartitioned = envelope.is_breached(201)
    if repartitioned:
        for event in repartition_events(
            world_id=world_id,
            old_version=1,
            split_task_id="task-17",
            new_task_ids=("task-17a", "task-17b"),
            actor_id="twin-1",
            reason="temporal_upper_breach",
        ):
            _append(store, event)

    for task_id, name, parent in [
        ("task-17", "Storage Topology", None),
        ("task-17a", "Storage Structure", "task-17"),
        ("task-17b", "Storage Verification", "task-17"),
    ]:
        _append(store, Event.make("TASK_CREATED", world_id, {
            "task_id": task_id, "name": name, "state": "COMPLETED", "parent_task_id": parent
        }))
        _append(store, Event.make("LCC_SUBMITTED", world_id, {
            "task_id": task_id,
            "agent_id": "ag-17" if task_id == "task-17" else f"{task_id}-agent",
            "satisfied": 1,
            "mandatory": 1,
            "open_gaps": [],
            "verified_artifacts": [f"artifact://{task_id}"],
        }))

    state_before_closure = reduce_events(store.read_all(world_id))
    gcc = evaluate_closure(state_before_closure)
    _append(store, Event.make("GLOBAL_CLOSURE_ISSUED", world_id, {
        "closure_id": "gcc-demo-1",
        "eligible": gcc.eligible,
        "coverage": gcc.coverage,
        "blocking_tasks": list(gcc.blocking_tasks),
        "topology_version": gcc.topology_version,
    }))

    first_replay = reduce_events(store.read_all(world_id))
    second_store = SQLiteEventStore(db_path)
    second_replay = reduce_events(second_store.read_all(world_id))
    replay_matches = state_to_dict(first_replay) == state_to_dict(second_replay)

    return {
        "world_id": world_id,
        "single_case": single_case,
        "split_case": split_case,
        "twin_idle": twin_idle,
        "repartitioned": repartitioned,
        "closure_eligible": gcc.eligible,
        "replay_matches": replay_matches,
        "topology_version": second_replay.topology_version,
        "event_count": second_replay.revision,
    }



def _apr_demo(db_path: Path) -> dict[str, Any]:
    store = SQLiteEventStore(db_path)
    world_id = "fcao-apr-operational-exp-01"
    apr = APRController()

    for event in [
        Event.make("WORLD_OPEN", world_id, {"closure_target": 1.0}),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "primary-1", "name": "Primary", "role": "primary", "agent_type": "controller"
        }),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "twin-1", "name": "Twin", "role": "twin", "agent_type": "governor"
        }),
        Event.make("EVIDENCE_RECORDED", world_id, {
            "evidence_id": "evidence-runtime-integrity",
            "key": "runtime-integrity",
            "status": "VERIFIED",
            "confidence": 0.99,
            "source_ref": "receipt://fcao-runtime-validation",
        }),
    ]:
        _append(store, event)

    state = reduce_events(store.read_all(world_id))
    runtime_observation = apr.decide("runtime-integrity", state)
    _append(store, Event.make("OBSERVATION_DECIDED", world_id, {
        "evidence_key": runtime_observation.evidence_key,
        "action": runtime_observation.action,
        "reason": runtime_observation.reason,
    }))

    state = reduce_events(store.read_all(world_id))
    authorization_before = apr.decide("cleanup-authorization", state)
    _append(store, Event.make("OBSERVATION_DECIDED", world_id, {
        "evidence_key": authorization_before.evidence_key,
        "action": authorization_before.action,
        "reason": authorization_before.reason,
    }))
    _append(store, Event.make("EVIDENCE_RECORDED", world_id, {
        "evidence_id": "evidence-cleanup-authorization",
        "key": "cleanup-authorization",
        "status": "VERIFIED",
        "confidence": 0.99,
        "source_ref": "user://explicit-authorization",
    }))
    state = reduce_events(store.read_all(world_id))
    authorization_after = apr.decide("cleanup-authorization", state)
    _append(store, Event.make("OBSERVATION_DECIDED", world_id, {
        "evidence_key": authorization_after.evidence_key,
        "action": authorization_after.action,
        "reason": authorization_after.reason,
    }))

    twin_sequence = [
        ("IDLE", "no-actionable-risk"),
        ("CHALLENGE", "unicode-path-audit-false-positive-required-audit-fix"),
        ("CONCUR", "corrected-audit-method-satisfied"),
    ]
    for action, reason in twin_sequence:
        _append(store, Event.make("TWIN_DECISION", world_id, {
            "agent_id": "twin-1", "action": action, "reason": reason
        }))

    for task_id, name in [
        ("fcao-apr-policy-bootstrap", "FCAO APR Policy Bootstrap"),
        ("fcao-runtime-validation", "FCAO Runtime Validation"),
        ("mrmic-workspace-consolidation", "MRMIC Workspace Consolidation"),
    ]:
        _append(store, Event.make("TASK_CREATED", world_id, {
            "task_id": task_id, "name": name, "state": "COMPLETED"
        }))
        _append(store, Event.make("LCC_SUBMITTED", world_id, {
            "task_id": task_id,
            "agent_id": "primary-1",
            "satisfied": 1,
            "mandatory": 1,
            "open_gaps": [],
            "verified_artifacts": [f"artifact://{task_id}"],
        }))

    first_state = reduce_events(store.read_all(world_id))
    first_gcc = evaluate_closure(first_state)
    _append(store, Event.make("GLOBAL_CLOSURE_ISSUED", world_id, {
        "closure_id": "gcc-1",
        "eligible": first_gcc.eligible,
        "coverage": first_gcc.coverage,
        "blocking_tasks": list(first_gcc.blocking_tasks),
        "topology_version": first_gcc.topology_version,
        "scope": "pre-github-sync",
    }))
    _append(store, Event.make("TWIN_DECISION", world_id, {
        "agent_id": "twin-1",
        "action": "CHALLENGE",
        "reason": "candidate-closure-omitted-github-sync-mandatory-node",
    }))
    _append(store, Event.make("CLOSURE_SUPERSEDED", world_id, {
        "old_closure_id": "gcc-1",
        "new_closure_id": "gcc-2",
        "reason": "missing-mandatory-node",
    }))

    _append(store, Event.make("TASK_CREATED", world_id, {
        "task_id": "mrmic-github-synchronization",
        "name": "MRMIC GitHub Synchronization",
        "state": "COMPLETED",
    }))
    _append(store, Event.make("LCC_SUBMITTED", world_id, {
        "task_id": "mrmic-github-synchronization",
        "agent_id": "primary-1",
        "satisfied": 1,
        "mandatory": 1,
        "open_gaps": [],
        "verified_artifacts": ["artifact://mrmic-github-synchronization"],
    }))
    _append(store, Event.make("TWIN_DECISION", world_id, {
        "agent_id": "twin-1",
        "action": "CONCUR",
        "reason": "reopened-world-all-mandatory-nodes-satisfied",
    }))

    final_state = reduce_events(store.read_all(world_id))
    final_gcc = evaluate_closure(final_state)
    _append(store, Event.make("GLOBAL_CLOSURE_ISSUED", world_id, {
        "closure_id": "gcc-2",
        "eligible": final_gcc.eligible,
        "coverage": final_gcc.coverage,
        "blocking_tasks": list(final_gcc.blocking_tasks),
        "topology_version": final_gcc.topology_version,
        "scope": "github-sync-and-formal-local-main",
    }))

    first_replay = reduce_events(store.read_all(world_id))
    second_replay = reduce_events(SQLiteEventStore(db_path).read_all(world_id))
    replay_matches = state_to_dict(first_replay) == state_to_dict(second_replay)
    current = active_closure(second_replay)

    return {
        "world_id": world_id,
        "topology": "single",
        "subagents_started": 0,
        "runtime_observation": runtime_observation.action,
        "authorization_observation_before": authorization_before.action,
        "authorization_observation_after": authorization_after.action,
        "twin_sequence": [item["action"] for item in second_replay.twin_decisions],
        "first_closure_superseded": second_replay.closure_supersessions.get("gcc-1") == "gcc-2",
        "active_closure_id": None if current is None else current.get("closure_id"),
        "final_closure_eligible": final_gcc.eligible,
        "final_coverage": final_gcc.coverage,
        "replay_matches": replay_matches,
        "event_count": second_replay.revision,
    }


def _multichild_demo(db_path: Path) -> dict[str, Any]:
    store = SQLiteEventStore(db_path)
    world_id = "fcao-apr-deterministic-exp-02"
    apr = APRController()
    twin = TwinGovernor("twin-1", risk_threshold=0.7)

    for event in [
        Event.make("WORLD_OPEN", world_id, {"closure_target": 1.0}),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "primary-1", "name": "Primary", "role": "primary", "agent_type": "controller"
        }),
        Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": "twin-1", "name": "Twin", "role": "twin", "agent_type": "governor"
        }),
    ]:
        _append(store, event)

    children = [
        ("child-atlas", "Atlas", "task-atlas", "Structure Extraction"),
        ("child-kepler", "Kepler", "task-kepler", "Constraint Analysis"),
        ("child-curie", "Curie", "task-curie", "Evidence Synthesis"),
    ]
    for agent_id, name, task_id, task_name in children:
        _append(store, Event.make("AGENT_REGISTERED", world_id, {
            "agent_id": agent_id,
            "name": name,
            "role": "child",
            "agent_type": "worker",
            "task_id": task_id,
            "task_name": task_name,
            "parent_agent_id": "primary-1",
        }))

    _append(store, Event.make("FANOUT_DECLARED", world_id, {
        "group_id": "fanout-e2",
        "root_task_id": "project-root",
        "child_task_ids": [item[2] for item in children],
    }))

    single_control = choose_candidate([
        TopologyEstimate("single", 100, 160, cost=1.0, risk=0.1),
        TopologyEstimate("split-3", 140, 240, cost=1.8, risk=0.1),
    ]).candidate_id
    topology = choose_candidate([
        TopologyEstimate("single", 600, 1000, cost=3.2, risk=0.25),
        TopologyEstimate("split-3", 260, 520, cost=2.9, risk=0.2),
    ]).candidate_id

    for task_id, agent_id in [(item[2], item[0]) for item in children]:
        _append(store, Event.make("TASK_CREATED", world_id, {
            "task_id": task_id, "name": task_id, "state": "COMPLETED"
        }))
        _append(store, Event.make("TASK_ASSIGNED", world_id, {
            "task_id": task_id, "agent_id": agent_id
        }))
        _append(store, Event.make("LCC_SUBMITTED", world_id, {
            "task_id": task_id,
            "agent_id": agent_id,
            "satisfied": 1,
            "mandatory": 1,
            "open_gaps": [],
            "verified_artifacts": [f"artifact://{task_id}"],
        }))

    for event in [
        Event.make("EVIDENCE_RECORDED", world_id, {
            "evidence_id": "ev-atlas",
            "key": "child-atlas-artifact",
            "status": "VERIFIED",
            "confidence": 0.96,
            "source_ref": "receipt://atlas-lcc",
        }),
        Event.make("EVIDENCE_RECORDED", world_id, {
            "evidence_id": "ev-kepler",
            "key": "child-kepler-artifact",
            "status": "OBSERVED",
            "confidence": 0.45,
            "source_ref": "receipt://kepler-initial",
        }),
    ]:
        _append(store, event)

    for evidence_key in ("child-atlas-artifact", "child-kepler-artifact", "child-curie-artifact"):
        state = reduce_events(store.read_all(world_id))
        decision = apr.decide(evidence_key, state)
        _append(store, Event.make("OBSERVATION_DECIDED", world_id, {
            "evidence_key": decision.evidence_key,
            "action": decision.action,
            "reason": decision.reason,
        }))

    _append(store, Event.make("EVIDENCE_RECORDED", world_id, {
        "evidence_id": "ev-curie",
        "key": "child-curie-artifact",
        "status": "VERIFIED",
        "confidence": 0.93,
        "source_ref": "receipt://curie-targeted-observation",
    }))

    _append(store, Event.make("COLLAB_CONFLICT_RECORDED", world_id, {
        "conflict_id": "conflict-schema",
        "task_ids": ["task-atlas", "task-kepler"],
        "reason": "schema-version-mismatch",
    }))
    _append(store, Event.make("TASK_CREATED", world_id, {
        "task_id": "task-merge", "name": "Cross-child Merge", "state": "COMPLETED"
    }))
    _append(store, Event.make("TASK_ASSIGNED", world_id, {
        "task_id": "task-merge", "agent_id": "primary-1"
    }))
    _append(store, Event.make("LCC_SUBMITTED", world_id, {
        "task_id": "task-merge",
        "agent_id": "primary-1",
        "satisfied": 1,
        "mandatory": 1,
        "open_gaps": [],
        "verified_artifacts": ["artifact://cross-child-merge"],
    }))

    child_task_ids = tuple(item[2] for item in children)
    before_state = reduce_events(store.read_all(world_id))
    before = assess_merge(before_state, child_task_ids, "task-merge")
    _append(store, Event.make("MERGE_ASSESSED", world_id, {
        "ready": before.ready,
        "blocking_tasks": list(before.blocking_tasks),
        "unresolved_conflicts": list(before.unresolved_conflicts),
    }))
    first_twin = twin.inspect_merge(
        blocking_tasks=before.blocking_tasks,
        unresolved_conflicts=before.unresolved_conflicts,
        risk=0.2,
    )
    _append(store, Event.make("TWIN_DECISION", world_id, {
        "agent_id": first_twin.agent_id, "action": first_twin.action, "reason": first_twin.reason
    }))

    state = reduce_events(store.read_all(world_id))
    schema_observation = apr.decide("schema-compatibility", state)
    _append(store, Event.make("OBSERVATION_DECIDED", world_id, {
        "evidence_key": schema_observation.evidence_key,
        "action": schema_observation.action,
        "reason": schema_observation.reason,
    }))
    _append(store, Event.make("EVIDENCE_RECORDED", world_id, {
        "evidence_id": "ev-schema-compatibility",
        "key": "schema-compatibility",
        "status": "VERIFIED",
        "confidence": 0.98,
        "source_ref": "receipt://targeted-schema-check",
    }))
    _append(store, Event.make("COLLAB_CONFLICT_RESOLVED", world_id, {
        "conflict_id": "conflict-schema",
        "resolution_ref": "evidence://schema-compatibility",
    }))

    after_state = reduce_events(store.read_all(world_id))
    after = assess_merge(after_state, child_task_ids, "task-merge")
    _append(store, Event.make("MERGE_ASSESSED", world_id, {
        "ready": after.ready,
        "blocking_tasks": list(after.blocking_tasks),
        "unresolved_conflicts": list(after.unresolved_conflicts),
    }))
    second_twin = twin.inspect_merge(
        blocking_tasks=after.blocking_tasks,
        unresolved_conflicts=after.unresolved_conflicts,
        risk=0.2,
    )
    _append(store, Event.make("TWIN_DECISION", world_id, {
        "agent_id": second_twin.agent_id, "action": second_twin.action, "reason": second_twin.reason
    }))

    final_state = reduce_events(store.read_all(world_id))
    gcc = evaluate_closure(final_state)
    _append(store, Event.make("GLOBAL_CLOSURE_ISSUED", world_id, {
        "closure_id": "gcc-e2-1",
        "eligible": gcc.eligible,
        "coverage": gcc.coverage,
        "blocking_tasks": list(gcc.blocking_tasks),
        "blocking_conflicts": list(gcc.blocking_conflicts),
        "topology_version": gcc.topology_version,
        "scope": "three-direct-child-fanout-fanin",
    }))

    first_replay = reduce_events(store.read_all(world_id))
    second_replay = reduce_events(SQLiteEventStore(db_path).read_all(world_id))
    replay_matches = state_to_dict(first_replay) == state_to_dict(second_replay)
    current = active_closure(second_replay)
    child_agents = [agent for agent in second_replay.agents.values() if agent.role == "child"]
    child_ids = {agent.agent_id for agent in child_agents}

    return {
        "world_id": world_id,
        "topology": topology,
        "single_control": single_control,
        "logical_child_count": len(child_agents),
        "child_names": sorted(agent.name for agent in child_agents),
        "all_children_direct": {agent.parent_agent_id for agent in child_agents} == {"primary-1"},
        "recursive_children": sum(1 for agent in child_agents if agent.parent_agent_id in child_ids),
        "local_twins": sum(
            1 for agent in second_replay.agents.values()
            if agent.role == "twin" and agent.parent_agent_id in child_ids
        ),
        "apr_actions": [item["action"] for item in second_replay.observation_decisions],
        "twin_sequence": [item["action"] for item in second_replay.twin_decisions],
        "merge_blocked_before_resolution": not before.ready,
        "merge_ready_after_resolution": after.ready,
        "active_closure_id": None if current is None else current.get("closure_id"),
        "final_closure_eligible": gcc.eligible,
        "final_coverage": gcc.coverage,
        "replay_matches": replay_matches,
        "event_count": second_replay.revision,
    }

def _replay(db_path: Path, world_id: str) -> dict[str, Any]:
    store = SQLiteEventStore(db_path)
    events = store.read_all(world_id)
    state = reduce_events(events)
    return state_to_dict(state)


def _verify(db_path: Path, world_id: str) -> dict[str, Any]:
    store = SQLiteEventStore(db_path)
    events = store.read_all(world_id)
    state = reduce_events(events)
    computed = evaluate_closure(state)
    current = active_closure(state)
    valid = bool(
        current
        and bool(current.get("eligible")) == computed.eligible
        and float(current.get("coverage", -1.0)) == computed.coverage
        and int(current.get("topology_version", -1)) == computed.topology_version
    )
    return {
        "world_id": world_id,
        "valid": valid,
        "computed_eligible": computed.eligible,
        "recorded_eligible": None if current is None else bool(current.get("eligible")),
        "active_closure_id": None if current is None else current.get("closure_id"),
        "topology_version": state.topology_version,
        "event_count": state.revision,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fcao")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo")
    demo.add_argument("--db", required=True, type=Path)

    apr_demo = sub.add_parser("apr-demo")
    apr_demo.add_argument("--db", required=True, type=Path)

    multichild_demo = sub.add_parser("multichild-demo")
    multichild_demo.add_argument("--db", required=True, type=Path)

    replay = sub.add_parser("replay")
    replay.add_argument("--db", required=True, type=Path)
    replay.add_argument("--world", required=True)

    verify = sub.add_parser("verify")
    verify.add_argument("--db", required=True, type=Path)
    verify.add_argument("--world", required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "demo":
        result = _demo(args.db)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "apr-demo":
        result = _apr_demo(args.db)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "multichild-demo":
        result = _multichild_demo(args.db)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "replay":
        result = _replay(args.db, args.world)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    if args.command == "verify":
        result = _verify(args.db, args.world)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0 if result["valid"] else 2
    raise AssertionError("unreachable")


if __name__ == "__main__":
    raise SystemExit(main())
