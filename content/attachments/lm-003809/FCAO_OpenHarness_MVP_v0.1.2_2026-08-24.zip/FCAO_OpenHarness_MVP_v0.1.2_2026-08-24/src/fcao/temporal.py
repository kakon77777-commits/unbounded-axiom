from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TemporalEnvelope:
    lower_ms: float
    upper_ms: float
    confidence: float

    def __post_init__(self) -> None:
        if self.lower_ms < 0 or self.upper_ms < 0:
            raise ValueError("temporal bounds must be non-negative")
        if self.lower_ms > self.upper_ms:
            raise ValueError("lower_ms cannot exceed upper_ms")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be in [0, 1]")

    def is_breached(self, elapsed_ms: float) -> bool:
        return elapsed_ms > self.upper_ms
