# Third-Party Notices

This MVP does not vendor third-party source code.

The OpenHarness integration adapter is designed for compatibility with the separately distributed project `HKUDS/OpenHarness`, whose source snapshot was reviewed when defining the adapter boundary. If a future distribution copies, modifies, or vendors OpenHarness code, that distribution must include the notices and license terms required by the exact upstream version used.
