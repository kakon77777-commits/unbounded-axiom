# AMRR M2 Validation — Problem / Theory Stores

**Release:** `ACR-AMRR-MVP-v0.1-M2`  
**Phase:** `AMRR M2 - Problem / Theory Stores`  
**Date:** 2026-08-23

## Implemented boundary

M2 implements immutable file-backed runtime stores for the frozen M0 canonical objects:

- `ProblemRecord`;
- `TheoryRecord`;
- `AssumptionEnvelope`.

M2 does **not** implement M3–M11 capabilities.

## Store invariants verified

- `(id, version)` is immutable.
- Identical replay is idempotent.
- Same `(id, version)` with different canonical content is rejected as `silent_overwrite`.
- A new object identity begins at version 1.
- Same-ID versions are sequential.
- Version `vN` for `N > 1` must explicitly name exact parent `vN-1`.
- Same-ID derivation may only start from the latest stored version.
- New-ID branching records exact parent version under `extensions.amrr_m2_store.parent_versions`.
- Every write and every read passes the frozen M0 schema plus canonical fingerprint validation.
- Tampered persisted objects are rejected as `corrupt_record`.
- Problem, Theory, and AssumptionEnvelope graphs are reconstructed from canonical stored lineage rather than filesystem order.

## Frozen-boundary evidence

- ACR Phase-0 schemas: 10, unchanged.
- AMRR M0 mathematical schemas: 19, unchanged.
- Phase-1 SPRC/CIO registry: 64 objects, historical fingerprint preserved.
- AMRR M1 manifest SHA-256 preserved: `ce3681c8e680f1d2bf737d4d431161d8b781ef40a60701c5cf8a83b599e57f05`.
- AMRR M1 checksums SHA-256 preserved: `572a63a448b3e15fe0e62b531e77ef0b9a3f2b96718ac40b15da621c828911e8`.
- M1 reference SemanticState and MathematicalState fingerprints remain unchanged.

## Reference runtime fixture

The deterministic M2 reference fixture contains:

- Problem versions: 3;
- Theory versions: 2;
- AssumptionEnvelope versions: 2.

It exercises:

```text
problem:p1#v1
  -> problem:p1#v2
      -> problem:p1-restricted#v1

theory:t1#v1
  -> theory:t2#v1

assumption-envelope:ae1#v1
  -> assumption-envelope:ae1#v2
```

The complete graph and canonical fingerprints are stored in `examples/math-store/m2-demo.json` and mirrored in `AMRR_M2_MANIFEST.json`.

## Test evidence

Final M2 collection:

```text
130 tests collected
```

Executed in bounded groups because subprocess-heavy release/CLI tests can exceed the execution harness limit when run as one process:

```text
100 core tests passed
11 AMRR M0/M1/M2 release tests passed
12 CLI + Phase1/Phase2/base release tests passed
7 targeted SPRC/state CLI tests passed
-----------------------------------------------
130 / 130 passed
0 failed
```

This grouping covers the complete 130-test collection.

## Static / release validation

Required final gates:

```text
python -m compileall -q src
PYTHONPATH=src python scripts/validate_release.py --root . --compatibility-only
PYTHONPATH=src python scripts/validate_amrr_m0.py --root . --compatibility-only
PYTHONPATH=src python scripts/validate_amrr_m1.py --root .
PYTHONPATH=src python scripts/validate_amrr_m2.py --root .
```

The M2 validator additionally re-creates the deterministic reference stores in a temporary directory and tests no-silent-overwrite behavior independently of the static JSON fixture.

## Release semantics

Historical manifests/checksums are not rewritten:

```text
MANIFEST.json / CHECKSUMS.sha256          = ACR Phase 2 historical release
AMRR_M0_MANIFEST / AMRR_M0_CHECKSUMS      = AMRR M0 historical release
AMRR_M1_MANIFEST / AMRR_M1_CHECKSUMS      = AMRR M1 historical release
AMRR_M2_MANIFEST / AMRR_M2_CHECKSUMS      = current M2 release
```

Therefore:

```text
HistoricalSnapshotIntegrity != ForwardPhaseEvolution
```

M2 adds new files and runtime capability while retaining prior canonical schema/state/registry anchors.
