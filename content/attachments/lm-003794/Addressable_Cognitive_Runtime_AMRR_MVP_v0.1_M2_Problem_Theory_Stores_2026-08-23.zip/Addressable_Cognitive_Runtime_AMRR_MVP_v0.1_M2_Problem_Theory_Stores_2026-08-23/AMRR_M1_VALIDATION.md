# AMRR M1 Validation — Mathematical State Adapter

**Release:** `ACR-AMRR-MVP-v0.1-M1`  
**Phase:** M1 — Mathematical State Adapter  
**Date:** 2026-08-23

## Scope

M1 validates one new runtime capability only:

```text
Public Observation
+ explicit extensions.math
-> strict math observation normalization
-> canonical MathematicalStateExtension
-> SemanticState.extensions.math
-> math-aware SemanticState identity/fingerprint
```

M2–M11 are not implemented by this release.

## Frozen compatibility anchors

The M1 tree preserves the historical M0 anchor artifacts byte-for-byte:

```text
AMRR_M0_MANIFEST.json
SHA-256 eb8461cc9b0f9ee78315a55657e7a1adcccbe70e8417226c407b8113010ac081

AMRR_M0_CHECKSUMS.sha256
SHA-256 01e1633b6b9ef13ca012c1868c3cd28610ba211dbd1b31602f3c315836b9af34
```

M1 compatibility validation additionally confirms:

- Phase-0 canonical schema count: `10`.
- AMRR M0 canonical math schema count: `19`.
- Phase-1 SPRC/CIO object count: `64`.
- Phase-1 registry fingerprint: `sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd`.
- Original Phase-2 no-math state fingerprints remain unchanged.

Historical strict snapshot checksums are intentionally not reinterpreted as forward-compatible whole-tree checksums. The Phase-2 and M0 validators therefore expose `--compatibility-only` for descendant release trees: frozen contracts are revalidated, while obsolete whole-snapshot checksum comparison is skipped.

## M1 adapter contract

Profile:

```text
amrr.math-state-adapter/v0.1
```

Public math observation fields:

```text
problem_refs
active_problem_ref
theory_refs
active_theory_ref
definition_refs
assumption_refs
method_refs
claim_refs
gap_map_ref
open_obligation_refs
verification_refs
bridge_refs
novelty_state
research_phase
```

Rules verified:

1. Unknown math observation fields fail closed.
2. Set-like ref arrays are sorted and deduplicated.
3. Reference prefixes are validated by field.
4. `active_problem_ref` must appear in `problem_refs`.
5. `active_theory_ref` must appear in `theory_refs`.
6. Omitted values normalize to explicit deterministic defaults.
7. The nested math state validates as `amrr.mathematical-state-extension/v0.1`.
8. The nested math state has a content-addressed `math-state:sha256:*` ID and canonical fingerprint.
9. Equivalent math observations are byte-identical after encoding.
10. Explicit math state participates in the outer SemanticState identity/fingerprint.
11. Non-math input extension metadata remains non-semantic and ignored by the canonical output.
12. Observations without `extensions.math` retain the original Phase-2 identity/fingerprint behavior.

## Fixture evidence

Valid M1 math observations:

```text
4 / 4 accepted
```

Invalid M1 math observations:

```text
5 / 5 rejected with typed ObservationError codes
```

The two ordering-equivalent fixtures encode to identical outer SemanticState bytes and identical nested MathematicalStateExtension bytes.

## Test evidence

Complete collection:

```text
107 tests collected
```

The environment-wide single `pytest -q` process exceeded the execution wall-time after emitting only passing progress dots, so the exact same 107 collected cases were executed in two explicit groups:

```text
Core / schema / state / SPRC / M1 functional group:
88 passed

CLI / release / subprocess group:
19 passed
```

Total:

```text
107 / 107 passed
0 failed
```

## Compiler evidence

```text
python -m compileall -q src
PASS
```

## Validator evidence

Phase-2 descendant compatibility validator:

```json
{
  "ok": true,
  "compatibility_only": true,
  "schema_count": 10,
  "sprc_object_count": 64,
  "state_valid_observations": 3,
  "state_invalid_observations": 4,
  "checksum_failures": 0
}
```

AMRR M0 descendant compatibility validator:

```json
{
  "ok": true,
  "compatibility_only": true,
  "phase0_schema_count": 10,
  "math_schema_count": 19,
  "math_valid_fixtures": 19,
  "math_invalid_fixtures": 9,
  "checksum_failures": 0
}
```

AMRR M1 validator:

```json
{
  "ok": true,
  "phase0_schema_count": 10,
  "math_schema_count": 19,
  "math_state_adapter_profile": "amrr.math-state-adapter/v0.1",
  "math_state_valid_observations": 4,
  "math_state_invalid_observations": 5,
  "m0_anchor_failures": 0,
  "checksum_failures": 0
}
```

## Completion boundary

Implemented through this release:

```text
ACR Phase 0
ACR Phase 1
ACR Phase 2
AMRR M0
AMRR M1
```

Not implemented:

```text
AMRR M2–M11
```

Therefore the valid completion statement is:

```text
M1 Mathematical State Adapter = implemented and validated.
Persistent autonomous mathematical research = not yet implemented.
```
