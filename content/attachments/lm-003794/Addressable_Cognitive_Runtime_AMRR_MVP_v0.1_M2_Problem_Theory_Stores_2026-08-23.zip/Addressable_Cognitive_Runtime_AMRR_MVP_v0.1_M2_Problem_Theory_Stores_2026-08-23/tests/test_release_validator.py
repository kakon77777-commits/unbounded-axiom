import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_release_validator_proves_phase0_release_contract():
    script = ROOT / "scripts" / "validate_release.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT), "--compatibility-only"],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["schema_count"] == 10
    assert payload["valid_fixtures"] == 10
    assert payload["invalid_fixtures"] >= 5
    assert payload["checksum_failures"] == 0
