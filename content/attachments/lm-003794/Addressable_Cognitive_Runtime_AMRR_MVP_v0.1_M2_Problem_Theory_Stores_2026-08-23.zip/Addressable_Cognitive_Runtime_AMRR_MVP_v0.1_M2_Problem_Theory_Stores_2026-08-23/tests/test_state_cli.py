from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args: str):
    return subprocess.run(
        [sys.executable, "-m", "addressable_cognitive_runtime", *args],
        cwd=ROOT,
        env=ENV,
        text=True,
        capture_output=True,
        check=False,
    )


def test_state_encode_prints_encoded_semantic_state():
    source = ROOT / "examples" / "state-observations" / "valid" / "repo-failing.json"
    result = run_cli("state-encode", str(source))
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["schema"] == "acr.semantic-state/v0.1"
    assert payload["progress"] == "stalled"
    assert payload["uncertainty"] == "high"
    assert payload["fingerprint"].startswith("sha256:")


def test_state_encode_output_writes_deterministic_json(tmp_path):
    source = ROOT / "examples" / "state-observations" / "valid" / "repo-clean.json"
    target = tmp_path / "state.json"
    result = run_cli("state-encode", str(source), "--output", str(target))
    assert result.returncode == 0, result.stderr
    summary = json.loads(result.stdout)
    saved = json.loads(target.read_text(encoding="utf-8"))
    assert summary["file"] == str(target)
    assert summary["id"] == saved["id"]
    assert summary["fingerprint"] == saved["fingerprint"]
    second = run_cli("state-encode", str(source))
    assert json.loads(second.stdout) == saved


def test_state_encode_invalid_observation_returns_structured_error():
    source = ROOT / "examples" / "state-observations" / "invalid" / "private-reasoning.json"
    result = run_cli("state-encode", str(source))
    assert result.returncode == 2
    payload = json.loads(result.stdout)
    assert payload["valid"] is False
    assert payload["error_code"] == "private_reasoning_forbidden"


def test_state_encode_math_observation_prints_canonical_math_extension():
    source = ROOT / "examples" / "math-state-observations" / "valid" / "research-active.json"
    result = run_cli("state-encode", str(source))
    assert result.returncode == 0, result.stderr + result.stdout
    payload = json.loads(result.stdout)
    assert payload["extensions"]["math"]["schema"] == "amrr.mathematical-state-extension/v0.1"
    assert payload["extensions"]["math"]["active_problem_ref"] == "problem:riemann-demo"
