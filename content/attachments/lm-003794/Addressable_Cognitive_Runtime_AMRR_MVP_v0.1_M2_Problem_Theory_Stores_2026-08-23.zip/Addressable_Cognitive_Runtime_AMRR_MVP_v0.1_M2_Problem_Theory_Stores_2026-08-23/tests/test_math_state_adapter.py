from __future__ import annotations

import addressable_cognitive_runtime.state as state_api
from addressable_cognitive_runtime.canonical import canonical_bytes, fingerprint_object
from addressable_cognitive_runtime.validation import validate_object


def _api(name: str):
    value = getattr(state_api, name, None)
    assert callable(value), f"state API {name} must exist"
    return value


def _error_type():
    value = getattr(state_api, "ObservationError", None)
    assert isinstance(value, type)
    return value


def test_m1_exports_math_adapter_api_and_profile():
    _api("normalize_math_observation")
    _api("encode_mathematical_state_extension")
    assert getattr(state_api, "MATH_ADAPTER_PROFILE", None) == "amrr.math-state-adapter/v0.1"


def test_minimal_math_observation_normalizes_to_explicit_defaults():
    normalize = _api("normalize_math_observation")
    assert normalize({}) == {
        "problem_refs": [],
        "active_problem_ref": None,
        "theory_refs": [],
        "active_theory_ref": None,
        "definition_refs": [],
        "assumption_refs": [],
        "method_refs": [],
        "claim_refs": [],
        "gap_map_ref": None,
        "open_obligation_refs": [],
        "verification_refs": [],
        "bridge_refs": [],
        "novelty_state": "unknown",
        "research_phase": "diagnosis",
    }


def test_math_reference_lists_sort_deduplicate_and_active_refs_are_members():
    normalize = _api("normalize_math_observation")
    value = normalize({
        "problem_refs": ["problem:z", "problem:a", "problem:z"],
        "active_problem_ref": "problem:a",
        "theory_refs": ["theory:2", "theory:1", "theory:2"],
        "active_theory_ref": "theory:1",
        "definition_refs": ["definition:b", "definition:a", "definition:b"],
        "assumption_refs": ["assumption:2", "assumption:1"],
        "method_refs": ["method:z", "method:a"],
        "claim_refs": ["claim:2", "claim:1"],
        "gap_map_ref": "gap-map:current",
        "open_obligation_refs": ["obligation:2", "obligation:1"],
        "verification_refs": ["verification:2", "verification:1"],
        "bridge_refs": ["theory-bridge:2", "theory-bridge:1"],
        "novelty_state": "search_incomplete",
        "research_phase": "verification",
    })
    assert value["problem_refs"] == ["problem:a", "problem:z"]
    assert value["theory_refs"] == ["theory:1", "theory:2"]
    assert value["definition_refs"] == ["definition:a", "definition:b"]
    assert value["assumption_refs"] == ["assumption:1", "assumption:2"]
    assert value["method_refs"] == ["method:a", "method:z"]
    assert value["claim_refs"] == ["claim:1", "claim:2"]
    assert value["open_obligation_refs"] == ["obligation:1", "obligation:2"]
    assert value["verification_refs"] == ["verification:1", "verification:2"]
    assert value["bridge_refs"] == ["theory-bridge:1", "theory-bridge:2"]
    assert value["active_problem_ref"] == "problem:a"
    assert value["active_theory_ref"] == "theory:1"


def test_math_observation_rejects_unknown_fields_bad_refs_and_unlisted_active_refs():
    normalize = _api("normalize_math_observation")
    ObservationError = _error_type()
    cases = [
        ({"mystery": True}, "unknown_math_observation_field"),
        ({"problem_refs": ["theory:not-a-problem"]}, "invalid_math_reference"),
        ({"problem_refs": ["problem:a"], "active_problem_ref": "problem:b"}, "active_problem_not_listed"),
        ({"theory_refs": ["theory:a"], "active_theory_ref": "theory:b"}, "active_theory_not_listed"),
        ({"gap_map_ref": "gap:not-map"}, "invalid_math_reference"),
    ]
    for payload, code in cases:
        try:
            normalize(payload)
        except ObservationError as exc:
            assert exc.code == code
        else:
            raise AssertionError(f"payload must fail with {code}: {payload}")


def test_math_observation_rejects_bad_novelty_and_research_phase():
    normalize = _api("normalize_math_observation")
    ObservationError = _error_type()
    for payload, code in [
        ({"novelty_state": "definitely_new"}, "invalid_novelty_state"),
        ({"research_phase": "wandering"}, "invalid_research_phase"),
    ]:
        try:
            normalize(payload)
        except ObservationError as exc:
            assert exc.code == code
        else:
            raise AssertionError(f"payload must fail with {code}")


def test_encoded_math_state_is_content_addressed_valid_and_deterministic():
    encode = _api("encode_mathematical_state_extension")
    a = encode({
        "problem_refs": ["problem:b", "problem:a", "problem:b"],
        "active_problem_ref": "problem:a",
        "theory_refs": ["theory:main"],
        "active_theory_ref": "theory:main",
        "open_obligation_refs": ["obligation:z", "obligation:a"],
        "novelty_state": "unknown",
        "research_phase": "diagnosis",
    })
    b = encode({
        "problem_refs": ["problem:a", "problem:b"],
        "active_problem_ref": "problem:a",
        "theory_refs": ["theory:main"],
        "active_theory_ref": "theory:main",
        "open_obligation_refs": ["obligation:a", "obligation:z"],
    })
    assert a == b
    assert canonical_bytes(a) == canonical_bytes(b)
    assert a["schema"] == "amrr.mathematical-state-extension/v0.1"
    assert a["version"] == 1
    assert a["id"].startswith("math-state:sha256:")
    assert len(a["id"].split(":")[-1]) == 64
    assert a["extensions"] == {
        "state_adapter": {"profile": "amrr.math-state-adapter/v0.1"}
    }
    assert a["fingerprint"] == fingerprint_object(a)
    assert validate_object(a, schema_name="mathematical-state-extension").valid
