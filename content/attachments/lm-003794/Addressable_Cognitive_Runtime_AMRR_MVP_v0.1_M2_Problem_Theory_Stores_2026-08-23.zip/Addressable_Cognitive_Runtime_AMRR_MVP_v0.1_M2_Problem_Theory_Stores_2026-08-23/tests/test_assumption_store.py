from __future__ import annotations

from pathlib import Path

import pytest


def test_assumption_envelope_store_create_and_derive(tmp_path: Path):
    from addressable_cognitive_runtime.math import AssumptionEnvelopeStore, store_parent_versions

    store = AssumptionEnvelopeStore(tmp_path)
    v1 = store.create(
        envelope_id="assumption-envelope:ae1",
        subject_ref="claim:c1",
        direct_assumption_refs=["assumption:a1"],
    )
    v2 = store.derive(
        "assumption-envelope:ae1",
        updates={
            "inherited_assumption_refs": ["assumption:a0"],
            "dependency_refs": ["claim:lemma1"],
            "closed": True,
        },
    )

    assert v1["version"] == 1
    assert v2["version"] == 2
    assert v2["closed"] is True
    assert store_parent_versions(v2)[0].token == "assumption-envelope:ae1#v1"
    assert store.graph()["edges"] == [
        {"from": "assumption-envelope:ae1#v1", "to": "assumption-envelope:ae1#v2"}
    ]


def test_assumption_envelope_store_rejects_silent_overwrite(tmp_path: Path):
    from addressable_cognitive_runtime.math import AssumptionEnvelopeStore, MathStoreError

    store = AssumptionEnvelopeStore(tmp_path)
    v1 = store.create(envelope_id="assumption-envelope:ae1", subject_ref="claim:c1")
    changed = dict(v1)
    changed["closed"] = True

    with pytest.raises(MathStoreError) as exc:
        store.put(changed)

    assert exc.value.code in {"invalid_record", "silent_overwrite"}
