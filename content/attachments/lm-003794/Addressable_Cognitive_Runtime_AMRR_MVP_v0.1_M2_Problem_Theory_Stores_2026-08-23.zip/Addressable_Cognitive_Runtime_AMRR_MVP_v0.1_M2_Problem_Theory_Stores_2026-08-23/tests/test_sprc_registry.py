import json
import os
import subprocess
import sys
from pathlib import Path

from addressable_cognitive_runtime.adapters.sprc import (
    EXPECTED_DECK_HASH,
    EXPECTED_REGISTRY_HASH,
    build_sprc_registry,
    export_sprc_registry,
)
from addressable_cognitive_runtime.canonical import fingerprint_object
from addressable_cognitive_runtime.validation import validate_object

ROOT = Path(__file__).resolve().parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "addressable_cognitive_runtime", *args],
        cwd=ROOT,
        env=ENV,
        text=True,
        capture_output=True,
        check=False,
    )


def test_registry_contains_64_valid_objects_and_frozen_source_provenance():
    registry = build_sprc_registry()
    assert registry["schema"] == "acr.sprc-cio-registry/v0.1"
    assert registry["registry_id"] == "ACR1-SPRC-CIO-v1"
    assert registry["version"] == 1
    assert registry["object_count"] == 64
    assert registry["source"]["deck_hash"] == EXPECTED_DECK_HASH
    assert registry["source"]["registry_hash"] == EXPECTED_REGISTRY_HASH
    assert registry["source"]["source_package"] == "Semantic_Persona_Runtime_v2.2.0"
    assert registry["source"]["semantic_compatibility"] == ["2.1.0", "2.2.0"]
    assert registry["renderer_tokens"]["P"]["wire_profile"] == "provocative"
    assert registry["renderer_tokens"]["P"]["corpus_clause_profile"] == "skeptical"
    assert [obj["extensions"]["sprc"]["source_operator_id"] for obj in registry["objects"]][:2] == ["R01", "R02"]
    assert registry["objects"][-1]["extensions"]["sprc"]["source_operator_id"] == "M08"
    assert all(validate_object(obj).valid for obj in registry["objects"])
    assert registry["fingerprint"] == fingerprint_object(registry)


def test_registry_build_and_export_are_byte_deterministic(tmp_path):
    left = tmp_path / "left.json"
    right = tmp_path / "right.json"
    export_sprc_registry(left)
    export_sprc_registry(right)
    assert left.read_bytes() == right.read_bytes()
    assert json.loads(left.read_text(encoding="utf-8")) == build_sprc_registry()


def test_cli_sprc_export_writes_registry(tmp_path):
    target = tmp_path / "registry.json"
    result = run_cli("sprc-export", str(target))
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["file"] == str(target)
    assert payload["object_count"] == 64
    assert payload["registry_id"] == "ACR1-SPRC-CIO-v1"
    exported = json.loads(target.read_text(encoding="utf-8"))
    assert exported["fingerprint"] == payload["fingerprint"]
