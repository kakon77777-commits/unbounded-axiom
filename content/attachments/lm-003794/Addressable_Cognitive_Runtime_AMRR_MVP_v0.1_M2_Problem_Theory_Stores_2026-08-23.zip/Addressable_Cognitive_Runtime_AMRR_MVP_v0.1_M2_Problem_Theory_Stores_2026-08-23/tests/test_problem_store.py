from __future__ import annotations

from pathlib import Path

import pytest


def test_problem_store_create_and_query_root(tmp_path: Path):
    from addressable_cognitive_runtime.math import ProblemStore

    store = ProblemStore(tmp_path)
    root = store.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
        domain_refs=["number_theory"],
        success_criteria=["formal_proof_or_counterexample"],
    )

    assert root["id"] == "problem:p1"
    assert root["version"] == 1
    assert root["parent_refs"] == []
    assert store.get("problem:p1") == root
    assert store.versions("problem:p1") == (1,)


def test_problem_store_same_id_derivation_creates_exact_version_edge(tmp_path: Path):
    from addressable_cognitive_runtime.math import ProblemStore

    store = ProblemStore(tmp_path)
    v1 = store.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
    )
    v2 = store.derive(
        "problem:p1",
        relation_to_parent="clarification",
        updates={"canonical_statement_ref": "artifact:q1-clarified"},
    )

    assert v2["id"] == "problem:p1"
    assert v2["version"] == 2
    assert v2["relation_to_parent"] == "clarification"
    assert store.versions("problem:p1") == (1, 2)
    assert store.get("problem:p1", 1) == v1
    assert store.get("problem:p1") == v2
    assert store.graph()["edges"] == [
        {"from": "problem:p1#v1", "to": "problem:p1#v2"}
    ]


def test_problem_store_branch_creates_new_identity_and_parent_edge(tmp_path: Path):
    from addressable_cognitive_runtime.math import ProblemStore

    store = ProblemStore(tmp_path)
    store.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
    )
    child = store.branch(
        "problem:p1",
        new_problem_id="problem:p1-restricted",
        relation_to_parent="restriction",
        updates={"canonical_statement_ref": "artifact:q1-restricted"},
    )

    assert child["version"] == 1
    assert child["parent_refs"] == ["problem:p1"]
    assert child["relation_to_parent"] == "restriction"
    assert {tuple(sorted(edge.items())) for edge in store.graph()["edges"]} == {
        tuple(sorted({"from": "problem:p1#v1", "to": "problem:p1-restricted#v1"}.items()))
    }


def test_problem_store_rejects_same_id_derivation_from_non_latest_version(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, ProblemStore

    store = ProblemStore(tmp_path)
    store.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
    )
    store.derive("problem:p1", relation_to_parent="clarification")

    with pytest.raises(MathStoreError) as exc:
        store.derive("problem:p1", from_version=1, relation_to_parent="clarification")

    assert exc.value.code == "non_latest_parent"


def test_problem_store_rejects_branch_to_existing_problem_id(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, ProblemStore

    store = ProblemStore(tmp_path)
    for pid in ("problem:p1", "problem:p2"):
        store.create(
            problem_id=pid,
            canonical_statement_ref=f"artifact:{pid[-2:]}",
            assumption_envelope_ref="assumption-envelope:ae1",
        )

    with pytest.raises(MathStoreError) as exc:
        store.branch(
            "problem:p1",
            new_problem_id="problem:p2",
            relation_to_parent="new_problem",
        )

    assert exc.value.code == "object_exists"


def test_problem_store_rejects_invalid_relation_without_persisting(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, ProblemStore

    store = ProblemStore(tmp_path)
    store.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
    )

    with pytest.raises(MathStoreError) as exc:
        store.derive("problem:p1", relation_to_parent="totally_not_a_relation")

    assert exc.value.code == "invalid_record"
    assert store.versions("problem:p1") == (1,)
