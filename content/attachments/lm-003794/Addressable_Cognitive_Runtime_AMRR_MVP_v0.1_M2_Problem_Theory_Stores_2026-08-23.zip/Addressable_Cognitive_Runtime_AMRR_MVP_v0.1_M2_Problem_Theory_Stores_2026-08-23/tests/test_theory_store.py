from __future__ import annotations

from pathlib import Path

import pytest


def test_theory_store_create_derive_and_graph(tmp_path: Path):
    from addressable_cognitive_runtime.math import TheoryStore

    store = TheoryStore(tmp_path)
    v1 = store.create(theory_id="theory:t1", axiom_refs=["axiom:a0"])
    v2 = store.derive(
        "theory:t1",
        updates={"definition_refs": ["definition:d1"], "extension_profile_ref": "theory-extension:e1"},
    )

    assert v1["version"] == 1
    assert v2["version"] == 2
    assert v2["definition_refs"] == ["definition:d1"]
    assert store.graph()["edges"] == [
        {"from": "theory:t1#v1", "to": "theory:t1#v2"}
    ]


def test_theory_store_branch_creates_new_theory_identity(tmp_path: Path):
    from addressable_cognitive_runtime.math import TheoryStore

    store = TheoryStore(tmp_path)
    store.create(theory_id="theory:t1")
    child = store.branch(
        "theory:t1",
        new_theory_id="theory:t2",
        updates={"axiom_refs": ["axiom:new"]},
    )

    assert child["version"] == 1
    assert child["parent_refs"] == ["theory:t1"]
    assert child["axiom_refs"] == ["axiom:new"]
    assert store.graph()["edges"] == [
        {"from": "theory:t1#v1", "to": "theory:t2#v1"}
    ]


def test_theory_store_rejects_non_latest_same_id_derivation(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, TheoryStore

    store = TheoryStore(tmp_path)
    store.create(theory_id="theory:t1")
    store.derive("theory:t1")

    with pytest.raises(MathStoreError) as exc:
        store.derive("theory:t1", from_version=1)

    assert exc.value.code == "non_latest_parent"
