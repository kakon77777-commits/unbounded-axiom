from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
M1_MANIFEST_SHA256 = "ce3681c8e680f1d2bf737d4d431161d8b781ef40a60701c5cf8a83b599e57f05"
M1_CHECKSUMS_SHA256 = "572a63a448b3e15fe0e62b531e77ef0b9a3f2b96718ac40b15da621c828911e8"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def test_m2_preserves_historical_m1_anchor_files():
    assert digest(ROOT / "AMRR_M1_MANIFEST.json") == M1_MANIFEST_SHA256
    assert digest(ROOT / "AMRR_M1_CHECKSUMS.sha256") == M1_CHECKSUMS_SHA256


def test_m2_manifest_declares_store_boundary():
    manifest = json.loads((ROOT / "AMRR_M2_MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["release"] == "ACR-AMRR-MVP-v0.1-M2"
    assert manifest["version"] == "0.1.2"
    assert manifest["phase"] == "AMRR M2 - Problem / Theory Stores"
    assert manifest["base_amrr_release"] == "ACR-AMRR-MVP-v0.1-M1"
    assert manifest["m1_manifest_sha256"] == M1_MANIFEST_SHA256
    assert manifest["m1_checksums_sha256"] == M1_CHECKSUMS_SHA256
    assert manifest["store_profile"] == "amrr.versioned-math-store/v0.1"
    assert manifest["implementation_boundary"]["implemented"][-1] == "AMRR M2 Problem / Theory / AssumptionEnvelope Stores"
    assert manifest["implementation_boundary"]["not_implemented"] == ["AMRR M3-M11 runtime capabilities"]


def test_m2_demo_fixture_matches_manifest():
    manifest = json.loads((ROOT / "AMRR_M2_MANIFEST.json").read_text(encoding="utf-8"))
    demo = json.loads((ROOT / "examples" / "math-store" / "m2-demo.json").read_text(encoding="utf-8"))
    assert manifest["reference_demo"] == demo


def test_m2_release_validator_reports_ok():
    script = ROOT / "scripts" / "validate_amrr_m2.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT)],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["m1_anchor_failures"] == 0
    assert payload["checksum_failures"] == 0
    assert payload["problem_versions"] == 3
    assert payload["theory_versions"] == 2
    assert payload["assumption_envelope_versions"] == 2
