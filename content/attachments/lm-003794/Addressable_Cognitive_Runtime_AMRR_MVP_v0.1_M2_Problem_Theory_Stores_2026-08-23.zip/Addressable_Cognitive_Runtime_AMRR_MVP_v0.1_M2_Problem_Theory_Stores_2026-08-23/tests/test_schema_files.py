import json

from jsonschema import Draft202012Validator

from addressable_cognitive_runtime.schema_catalog import SCHEMA_SPECS, schema_path


def load(name):
    return json.loads(schema_path(name).read_text(encoding="utf-8"))


def test_all_ten_schemas_are_draft_2020_12_and_well_formed():
    for name in SCHEMA_SPECS:
        schema = load(name)
        assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
        Draft202012Validator.check_schema(schema)


def test_identity_boundary_is_explicit_and_top_level_is_closed():
    required_identity = {"schema", "id", "version", "fingerprint"}
    for name in SCHEMA_SPECS:
        schema = load(name)
        assert required_identity <= set(schema["required"]), name
        assert schema["additionalProperties"] is False, name
        assert "extensions" in schema["properties"], name
        assert schema["properties"]["extensions"]["type"] == "object", name


def test_schema_tokens_are_frozen_in_schema_field():
    for name, spec in SCHEMA_SPECS.items():
        schema = load(name)
        assert schema["properties"]["schema"]["const"] == spec.token
