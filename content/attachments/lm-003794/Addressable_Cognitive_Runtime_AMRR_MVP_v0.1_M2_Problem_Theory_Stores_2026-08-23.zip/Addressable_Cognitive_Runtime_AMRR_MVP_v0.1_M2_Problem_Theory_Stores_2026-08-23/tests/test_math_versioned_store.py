from __future__ import annotations

import json
from pathlib import Path

import pytest

from addressable_cognitive_runtime.canonical import fingerprint_object


def _problem_record(*, problem_id: str = "problem:p1", version: int = 1, statement: str = "artifact:s1") -> dict:
    obj = {
        "schema": "amrr.problem-record/v0.1",
        "id": problem_id,
        "version": version,
        "fingerprint": "sha256:" + "0" * 64,
        "extensions": {},
        "parent_refs": [],
        "canonical_statement_ref": statement,
        "informal_statement_ref": None,
        "formal_statement_refs": [],
        "domain_refs": [],
        "success_criteria": [],
        "status": "active",
        "created_from_gap_ref": None,
        "relation_to_parent": None,
        "assumption_envelope_ref": "assumption-envelope:ae1",
    }
    obj["fingerprint"] = fingerprint_object(obj)
    return obj


def test_version_ref_token_is_exact_and_stable():
    from addressable_cognitive_runtime.math import VersionRef

    assert VersionRef("problem:p1", 3).token == "problem:p1#v3"


def test_store_put_get_versions_and_idempotent_replay(tmp_path: Path):
    from addressable_cognitive_runtime.math import VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    record = _problem_record()

    first = store.put(record)
    second = store.put(record)

    assert first == record
    assert second == record
    assert store.get("problem:p1", 1) == record
    assert store.get("problem:p1") == record
    assert store.versions("problem:p1") == (1,)
    assert store.records() == (record,)


def test_store_rejects_silent_overwrite(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    store.put(_problem_record(statement="artifact:s1"))

    with pytest.raises(MathStoreError) as exc:
        store.put(_problem_record(statement="artifact:s2"))

    assert exc.value.code == "silent_overwrite"


def test_store_rejects_invalid_fingerprint(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    bad = _problem_record()
    bad["fingerprint"] = "sha256:" + "f" * 64

    with pytest.raises(MathStoreError) as exc:
        store.put(bad)

    assert exc.value.code == "invalid_record"


def test_store_detects_corrupt_persisted_object(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    store.put(_problem_record())
    path = next((tmp_path / "problems").rglob("v000001.json"))
    data = json.loads(path.read_text(encoding="utf-8"))
    data["canonical_statement_ref"] = "artifact:tampered"
    path.write_text(json.dumps(data), encoding="utf-8")

    with pytest.raises(MathStoreError) as exc:
        store.get("problem:p1", 1)

    assert exc.value.code == "corrupt_record"


def test_store_rejects_orphan_version_two(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    orphan = _problem_record(version=2)
    with pytest.raises(MathStoreError) as exc:
        store.put(orphan)
    assert exc.value.code == "non_sequential_version"


def test_store_requires_exact_previous_version_parent_for_version_increment(tmp_path: Path):
    from addressable_cognitive_runtime.math import MathStoreError, VersionedObjectStore

    store = VersionedObjectStore(
        tmp_path, namespace="problems", schema_name="problem-record", id_prefix="problem:"
    )
    store.put(_problem_record(version=1))
    v2 = _problem_record(version=2)
    with pytest.raises(MathStoreError) as exc:
        store.put(v2)
    assert exc.value.code == "missing_version_parent"
