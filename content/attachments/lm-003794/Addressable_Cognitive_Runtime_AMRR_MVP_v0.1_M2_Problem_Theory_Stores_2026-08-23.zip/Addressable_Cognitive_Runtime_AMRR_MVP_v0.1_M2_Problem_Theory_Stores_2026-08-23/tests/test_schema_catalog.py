from pathlib import Path

from addressable_cognitive_runtime.schema_catalog import (
    SCHEMA_SPECS,
    schema_name_for_token,
    schema_path,
)

EXPECTED = {
    "cognitive-object": "acr.cognitive-object/v0.1",
    "semantic-state": "acr.semantic-state/v0.1",
    "cognitive-program": "acr.cognitive-program/v0.1",
    "agenda-candidate": "acr.agenda-candidate/v0.1",
    "contract": "acr.contract/v0.1",
    "governance-decision": "acr.governance-decision/v0.1",
    "decision-receipt": "acr.decision-receipt/v0.1",
    "knowledge-boundary": "acr.knowledge-boundary/v0.1",
    "commitment": "acr.commitment/v0.1",
    "context-compression-event": "acr.context-compression-event/v0.1",
}


def test_catalog_is_exactly_the_phase0_ten():
    assert {name: spec.token for name, spec in SCHEMA_SPECS.items()} == EXPECTED
    assert len({spec.token for spec in SCHEMA_SPECS.values()}) == 10


def test_schema_paths_are_stable_and_exist():
    for name, spec in SCHEMA_SPECS.items():
        path = schema_path(name)
        assert isinstance(path, Path)
        assert path.name == spec.filename
        assert path.exists(), name


def test_reverse_lookup_by_schema_token():
    for name, token in EXPECTED.items():
        assert schema_name_for_token(token) == name
    assert schema_name_for_token("acr.unknown/v0.1") is None
