import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "addressable_cognitive_runtime", *args],
        cwd=ROOT,
        env=ENV,
        text=True,
        capture_output=True,
        check=False,
    )


def test_cli_list_prints_the_ten_frozen_schemas():
    result = run_cli("list")
    assert result.returncode == 0, result.stderr
    lines = [line for line in result.stdout.splitlines() if line.strip()]
    assert len(lines) == 10
    assert any("cognitive-object\tacr.cognitive-object/v0.1" in line for line in lines)


def test_cli_validate_and_fingerprint_valid_fixture():
    fixture = ROOT / "examples" / "valid" / "cognitive-object.json"
    result = run_cli("validate", str(fixture))
    assert result.returncode == 0, result.stderr
    payload = json.loads(result.stdout)
    assert payload["valid"] is True
    fp = run_cli("fingerprint", str(fixture))
    assert fp.returncode == 0
    assert fp.stdout.strip().startswith("sha256:")


def test_cli_invalid_fixture_returns_nonzero_and_machine_readable_issues():
    fixture = ROOT / "examples" / "invalid" / "bad-fingerprint.json"
    result = run_cli("validate", str(fixture))
    assert result.returncode == 1
    payload = json.loads(result.stdout)
    assert payload["valid"] is False
    assert any(issue["code"] == "fingerprint_mismatch" for issue in payload["issues"])


def test_cli_validate_fixtures_summarizes_directory():
    valid = run_cli("validate-fixtures", str(ROOT / "examples" / "valid"))
    assert valid.returncode == 0, valid.stdout + valid.stderr
    valid_payload = json.loads(valid.stdout)
    assert valid_payload == {"files": 10, "invalid": 0, "valid": 10}

    invalid = run_cli("validate-fixtures", str(ROOT / "examples" / "invalid"))
    assert invalid.returncode == 1
    invalid_payload = json.loads(invalid.stdout)
    assert invalid_payload["invalid"] >= 5
