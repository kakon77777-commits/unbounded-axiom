import json
from pathlib import Path

from addressable_cognitive_runtime.schema_catalog import SCHEMA_SPECS
from addressable_cognitive_runtime.validation import validate_object

VALID_DIR = Path("examples/valid")
INVALID_DIR = Path("examples/invalid")


def test_one_valid_reference_fixture_per_frozen_schema():
    files = sorted(VALID_DIR.glob("*.json"))
    assert len(files) == 10
    seen = set()
    for path in files:
        obj = json.loads(path.read_text(encoding="utf-8"))
        result = validate_object(obj)
        assert result.valid, (path.name, result.issues)
        seen.add(result.schema_name)
    assert seen == set(SCHEMA_SPECS)


def test_invalid_reference_fixtures_are_actually_invalid():
    files = sorted(INVALID_DIR.glob("*.json"))
    assert len(files) >= 5
    for path in files:
        obj = json.loads(path.read_text(encoding="utf-8"))
        result = validate_object(obj)
        assert not result.valid, path.name
