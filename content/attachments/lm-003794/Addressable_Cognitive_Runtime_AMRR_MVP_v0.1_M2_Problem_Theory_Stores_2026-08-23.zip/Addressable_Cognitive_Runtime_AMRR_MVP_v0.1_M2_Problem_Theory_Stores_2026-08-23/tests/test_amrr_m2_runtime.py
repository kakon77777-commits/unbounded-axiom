from __future__ import annotations

from pathlib import Path


def test_m2_problem_theory_assumption_stores_form_independent_version_graphs(tmp_path: Path):
    from addressable_cognitive_runtime.math import AssumptionEnvelopeStore, ProblemStore, TheoryStore

    ae = AssumptionEnvelopeStore(tmp_path)
    problems = ProblemStore(tmp_path)
    theories = TheoryStore(tmp_path)

    ae.create(envelope_id="assumption-envelope:ae1", subject_ref="problem:p1")
    problems.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
    )
    problems.derive("problem:p1", relation_to_parent="clarification")
    theories.create(theory_id="theory:t1", axiom_refs=["axiom:a0"])
    theories.branch("theory:t1", new_theory_id="theory:t2", updates={"axiom_refs": ["axiom:a0", "axiom:a1"]})

    assert problems.graph()["edges"] == [{"from": "problem:p1#v1", "to": "problem:p1#v2"}]
    assert theories.graph()["edges"] == [{"from": "theory:t1#v1", "to": "theory:t2#v1"}]
    assert ae.graph()["edges"] == []
