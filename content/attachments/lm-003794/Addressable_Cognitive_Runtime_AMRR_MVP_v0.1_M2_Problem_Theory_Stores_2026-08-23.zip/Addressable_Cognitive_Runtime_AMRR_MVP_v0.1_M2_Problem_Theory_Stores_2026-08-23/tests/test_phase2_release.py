from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

from addressable_cognitive_runtime import __version__
from addressable_cognitive_runtime.state.encoder import encode_semantic_state_file

ROOT = Path(__file__).resolve().parents[1]

PHASE0_SCHEMA_HASHES = {
    "cognitive-object": "2d38d9be37bb6425f4fde6ee2a40d593f95ad52ef94ef3bfd698b8b485541d29",
    "semantic-state": "e406aa9206f187c5b97ff5ac4e60db74f277a67b719b14123c1c1f6918f4d5a6",
    "cognitive-program": "62b40fac768028cd4a986604c90771b45a2a40183eef12c89bd95a59fe717932",
    "agenda-candidate": "acac33cb02e5deb65f663d37270b94a081d9000419b43bbaf2318c28557dd8df",
    "contract": "5f804c70e87d89bace3107815fd5b94c320393dcbb3b8b4623433b5f6b9c9e96",
    "governance-decision": "b4e3727b4813abb6b2e3a0e7b70b081a6968678f62c3e0cf7e315401c3ce50df",
    "decision-receipt": "ca24d7e73b8245796d8254e4e6530278cb125312409ab88b70dc14fcd40d0a61",
    "knowledge-boundary": "816702db685779a3e2f17b4cffd0a00e605c3883f184c8b57caec651f9295ee6",
    "commitment": "7922eec5a5a97c5c83184e06404f597875228801c8ba47dd7f390e38576813fc",
    "context-compression-event": "53d732bffa00a7690aba415b09fc57ddc77e6bae29b8707fa774561ad843d467",
}
PHASE1_REGISTRY_FINGERPRINT = "sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd"


def expected_state_fingerprints() -> dict[str, str]:
    root = ROOT / "examples" / "state-observations" / "valid"
    return {
        path.name: encode_semantic_state_file(path)["fingerprint"]
        for path in sorted(root.glob("*.json"))
    }


def test_phase2_package_version_matches_release():
    assert __version__ == "0.1.2"


def test_phase2_manifest_preserves_phase0_and_phase1_freezes():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["release"] == "ACR-MVP-v0.1-Phase2"
    assert manifest["version"] == "0.1.2"
    assert manifest["phase"] == "Phase 2 - Semantic State Encoder"
    assert manifest["schema_sha256"] == PHASE0_SCHEMA_HASHES
    assert manifest["sprc"]["registry_fingerprint"] == PHASE1_REGISTRY_FINGERPRINT


def test_phase2_manifest_records_encoder_profile_and_reference_fingerprints():
    manifest = json.loads((ROOT / "MANIFEST.json").read_text(encoding="utf-8"))
    state = manifest["state_encoder"]
    assert state["profile"] == "acr.semantic-state-encoder/v0.1"
    assert state["valid_observation_count"] == 3
    assert state["invalid_observation_count"] == 4
    assert state["reference_state_fingerprints"] == expected_state_fingerprints()


def test_phase2_release_validator_rebuilds_reference_states_deterministically():
    script = ROOT / "scripts" / "validate_release.py"
    result = subprocess.run(
        [sys.executable, str(script), "--root", str(ROOT), "--compatibility-only"],
        cwd=ROOT,
        env=dict(os.environ, PYTHONPATH=str(ROOT / "src")),
        text=True,
        capture_output=True,
        check=False,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    payload = json.loads(result.stdout)
    assert payload["ok"] is True
    assert payload["state_encoder_profile"] == "acr.semantic-state-encoder/v0.1"
    assert payload["state_valid_observations"] == 3
    assert payload["state_invalid_observations"] == 4
    assert payload["state_deterministic_rebuild"] is True
    assert payload["state_reference_fingerprints"] == expected_state_fingerprints()
