import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from addressable_cognitive_runtime.adapters.sprc import (
    address_to_source_id,
    renderer_compatibility,
    resolve_sprc_cognitive_object,
)

ROOT = Path(__file__).resolve().parents[1]
ENV = dict(os.environ, PYTHONPATH=str(ROOT / "src"))


def run_cli(*args):
    return subprocess.run(
        [sys.executable, "-m", "addressable_cognitive_runtime", *args],
        cwd=ROOT,
        env=ENV,
        text=True,
        capture_output=True,
        check=False,
    )


def test_address_to_source_id_round_trip_and_rejects_wrong_namespace():
    assert address_to_source_id("cog://sprc/cio/r01@1") == "R01"
    assert address_to_source_id("cog://sprc/cio/m08@1") == "M08"
    with pytest.raises(ValueError, match="invalid SPRC CIO address"):
        address_to_source_id("cog://epistemic/verify@1")
    with pytest.raises(ValueError, match="unsupported SPRC CIO address version"):
        address_to_source_id("cog://sprc/cio/r01@2")


def test_resolve_accepts_source_id_or_address_and_returns_same_object():
    by_id = resolve_sprc_cognitive_object("R01")
    by_address = resolve_sprc_cognitive_object("cog://sprc/cio/r01@1")
    assert by_id == by_address
    assert by_id["name"] == "Reverse"


def test_renderer_compatibility_preserves_wire_profiles_and_explicit_alias():
    profiles = renderer_compatibility()
    assert profiles["Q"]["wire_profile"] == "questioning"
    assert profiles["P"]["wire_profile"] == "provocative"
    assert profiles["P"]["corpus_clause_profile"] == "skeptical"
    assert profiles["H"]["wire_profile"] == "methodical"
    assert profiles["U"]["wire_profile"] == "conversational"
    assert profiles["Z"]["wire_profile"] == "reflective"
    assert all("conflicts" in profiles[token] for token in "QPHUZ")


def test_cli_sprc_info_list_and_resolve_are_machine_readable():
    info = run_cli("sprc-info")
    assert info.returncode == 0, info.stderr
    payload = json.loads(info.stdout)
    assert payload["source_package"] == "Semantic_Persona_Runtime_v2.2.0"
    assert payload["operator_count"] == 64
    assert payload["renderer_tokens"]["P"]["corpus_clause_profile"] == "skeptical"

    listing = run_cli("sprc-list")
    assert listing.returncode == 0, listing.stderr
    rows = json.loads(listing.stdout)
    assert len(rows) == 64
    assert rows[0] == {"address": "cog://sprc/cio/r01@1", "name": "Reverse", "source_id": "R01"}
    assert rows[-1]["source_id"] == "M08"

    resolved = run_cli("sprc-resolve", "R01")
    assert resolved.returncode == 0, resolved.stderr
    obj = json.loads(resolved.stdout)
    assert obj["id"] == "cog://sprc/cio/r01@1"
    assert obj["extensions"]["sprc"]["source_operator_id"] == "R01"


def test_cli_sprc_resolve_unknown_returns_nonzero_json_error():
    result = run_cli("sprc-resolve", "Z99")
    assert result.returncode == 2
    payload = json.loads(result.stdout)
    assert payload["valid"] is False
    assert "unknown SPRC operator ID" in payload["error"]
