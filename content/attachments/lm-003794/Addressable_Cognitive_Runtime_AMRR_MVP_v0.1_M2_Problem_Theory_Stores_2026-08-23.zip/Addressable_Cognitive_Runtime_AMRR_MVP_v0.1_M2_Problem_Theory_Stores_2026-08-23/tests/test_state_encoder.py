from __future__ import annotations

from addressable_cognitive_runtime.canonical import canonical_bytes, fingerprint_object
from addressable_cognitive_runtime.state.encoder import (
    ObservationError,
    derive_progress,
    derive_uncertainty,
    encode_semantic_state,
    normalize_observation,
)
from addressable_cognitive_runtime.validation import validate_object


def obs(**overrides) -> dict:
    value = {
        "authority_ref": "contract:v12",
        "goal_refs": ["goal:maintain"],
        "environment_refs": ["repo:demo"],
    }
    value.update(overrides)
    return value


def test_progress_explicit_value_wins_over_flags_and_status():
    normalized = normalize_observation(obs(progress="in_progress", completed=True, status="blocked"))
    assert derive_progress(normalized) == "in_progress"


def test_progress_precedence_and_failure_stall_rule():
    assert derive_progress(normalize_observation(obs(completed=True, blocked=True))) == "completed"
    assert derive_progress(normalize_observation(obs(blocked=True, stalled=True))) == "blocked"
    assert derive_progress(normalize_observation(obs(stalled=True, started=True))) == "stalled"
    assert derive_progress(normalize_observation(obs(repeated_failure_count=2, started=True))) == "stalled"
    assert derive_progress(normalize_observation(obs(started=True))) == "in_progress"
    assert derive_progress(normalize_observation(obs(status="pending"))) == "not_started"
    assert derive_progress(normalize_observation(obs())) == "unknown"


def test_normalize_rejects_noncanonical_explicit_progress_and_unknown_status():
    try:
        normalize_observation(obs(progress="mostly_done"))
    except ObservationError as exc:
        assert exc.code == "invalid_progress"
    else:
        raise AssertionError("noncanonical progress must fail")

    try:
        normalize_observation(obs(status="mystery_status"))
    except ObservationError as exc:
        assert exc.code == "invalid_status"
    else:
        raise AssertionError("unknown status must fail")


def test_uncertainty_explicit_value_wins():
    normalized = normalize_observation(
        obs(uncertainty="low", confidence=0.1, verification_status="contradicted")
    )
    assert derive_uncertainty(normalized) == "low"


def test_uncertainty_combines_public_signals_conservatively():
    assert derive_uncertainty(normalize_observation(obs(confidence=0.9, verification_status="verified"))) == "low"
    assert derive_uncertainty(normalize_observation(obs(confidence=0.7, verification_status="verified"))) == "medium"
    assert derive_uncertainty(normalize_observation(obs(confidence=0.95, verification_status="unverified"))) == "high"
    assert derive_uncertainty(normalize_observation(obs(confidence=0.4, verification_status="verified"))) == "high"
    assert derive_uncertainty(normalize_observation(obs(verification_status="unknown", confidence=0.9))) == "low"
    assert derive_uncertainty(normalize_observation(obs(verification_status="unknown"))) == "unknown"
    assert derive_uncertainty(normalize_observation(obs())) == "unknown"


def test_normalize_rejects_bad_uncertainty_and_verification_status():
    for field, value, code in [
        ("uncertainty", "certain", "invalid_uncertainty"),
        ("verification_status", "maybe", "invalid_verification_status"),
    ]:
        try:
            normalize_observation(obs(**{field: value}))
        except ObservationError as exc:
            assert exc.code == code
        else:
            raise AssertionError(f"{field} must fail")


def test_encode_semantic_state_is_phase0_valid_and_content_addressed():
    state = encode_semantic_state(
        obs(
            status="running",
            confidence=0.72,
            verification_status="partial",
            failures=["test_failed"],
            missing=["evidence:coverage"],
            risks=["risk:regression"],
            budget={"tokens_remaining": 800, "calls_remaining": 4},
            memory_refs=["memory:recent"],
        )
    )
    assert state["schema"] == "acr.semantic-state/v0.1"
    assert state["version"] == 1
    assert state["id"].startswith("state:sha256:")
    assert len(state["id"].split(":")[-1]) == 64
    assert state["progress"] == "in_progress"
    assert state["uncertainty"] == "medium"
    assert state["extensions"] == {
        "state_encoder": {"profile": "acr.semantic-state-encoder/v0.1"}
    }
    assert state["fingerprint"] == fingerprint_object(state)
    assert validate_object(state).valid


def test_equivalent_ordering_and_equivalent_progress_expression_are_byte_identical():
    a = encode_semantic_state(
        obs(
            progress="in_progress",
            goal_refs=["goal:b", "goal:a", "goal:b"],
            failures=["z", "a", "z"],
            environment_refs=["repo:z", "repo:a", "repo:z"],
        )
    )
    b = encode_semantic_state(
        obs(
            status="running",
            goal_refs=["goal:a", "goal:b"],
            failures=["a", "z"],
            environment_refs=["repo:a", "repo:z"],
        )
    )
    assert a == b
    assert canonical_bytes(a) == canonical_bytes(b)
    assert a["fingerprint"] == b["fingerprint"]
    assert a["id"] == b["id"]


def test_input_extensions_do_not_change_semantic_state_identity_or_fingerprint():
    a = encode_semantic_state(obs(status="pending", extensions={"source": "A"}))
    b = encode_semantic_state(obs(status="pending", extensions={"source": "B"}))
    assert a == b
