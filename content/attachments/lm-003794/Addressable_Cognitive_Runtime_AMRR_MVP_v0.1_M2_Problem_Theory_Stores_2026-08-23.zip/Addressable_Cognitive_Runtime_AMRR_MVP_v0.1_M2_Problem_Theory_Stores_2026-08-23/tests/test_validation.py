from copy import deepcopy

from addressable_cognitive_runtime.canonical import fingerprint_object
from addressable_cognitive_runtime.validation import validate_object


def with_fp(obj):
    obj = deepcopy(obj)
    obj["fingerprint"] = fingerprint_object(obj)
    return obj


def cognitive_object():
    return with_fp({
        "schema": "acr.cognitive-object/v0.1",
        "id": "cog://epistemic/verify@1",
        "version": 1,
        "fingerprint": "",
        "name": "VERIFY",
        "type": "cognitive_operator",
        "preconditions": ["claim_exists"],
        "inputs": ["current_claim"],
        "outputs": ["verification_result"],
        "effects": ["uncertainty_updated"],
        "cost_class": "low",
        "risk_class": "low",
        "compatible_with": [],
        "conflicts_with": [],
        "authority_class": "cognition_only",
        "termination": ["verified"],
        "renderers": {"en": "Verify the current claim."},
        "vector_ref": None,
        "schema_hash": "sha256:" + "1" * 64,
        "extensions": {}
    })


def governance_decision(authority="ALLOW", decision="EXECUTE"):
    return with_fp({
        "schema": "acr.governance-decision/v0.1",
        "id": "decision:demo:1",
        "version": 1,
        "fingerprint": "",
        "candidate_ref": "agenda:demo:1",
        "can": True,
        "should": True,
        "authority": {"class": authority, "authority_ref": "contract:demo:1"},
        "decision": decision,
        "reason_codes": ["goal_aligned"],
        "goal_refs": ["goal:maintain-repo"],
        "contract_ref": "contract:demo:1",
        "risk": {"class": "low", "reasons": []},
        "cost": {"total_calls": 1},
        "knowledge_boundary_ref": "kb:demo:1",
        "extensions": {}
    })


def test_valid_object_passes_structural_and_semantic_validation():
    result = validate_object(cognitive_object())
    assert result.valid, result.issues
    assert result.schema_name == "cognitive-object"


def test_bad_fingerprint_is_rejected():
    obj = cognitive_object()
    obj["fingerprint"] = "sha256:" + "0" * 64
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "fingerprint_mismatch" for issue in result.issues)


def test_cognitive_address_version_must_match_object_version():
    obj = cognitive_object()
    obj["id"] = "cog://epistemic/verify@2"
    obj["fingerprint"] = fingerprint_object(obj)
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "cognitive_version_mismatch" for issue in result.issues)


def test_unknown_top_level_field_is_rejected_by_schema():
    obj = cognitive_object()
    obj["surprise"] = True
    obj["fingerprint"] = fingerprint_object(obj)
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "schema_violation" for issue in result.issues)


def test_execute_requires_allow_authority():
    result = validate_object(governance_decision(authority="DENY", decision="EXECUTE"))
    assert not result.valid
    assert any(issue.code == "execute_without_allow" for issue in result.issues)


def test_unknown_schema_token_is_rejected_without_guessing():
    obj = {"schema": "acr.unknown/v0.1", "id": "x:1", "version": 1, "fingerprint": "sha256:" + "0" * 64}
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "unknown_schema" for issue in result.issues)


def test_decision_receipt_selected_action_must_be_candidate():
    obj = with_fp({
        "schema": "acr.decision-receipt/v0.1",
        "id": "receipt:decision:demo:1",
        "version": 1,
        "fingerprint": "",
        "decision_ref": "decision:demo:1",
        "ctcl_instant_id": "instant:demo",
        "interaction_round": 1,
        "goal_refs": ["goal:maintain-repo"],
        "contract_ref": "contract:demo:1",
        "authority_ref": "contract:demo:1",
        "public_state_ref": "state:demo:1",
        "knowledge_boundary_ref": "kb:demo:1",
        "candidate_actions": ["EXECUTE", "DEFER"],
        "selected_action": "ESCALATE",
        "cognitive_program_refs": ["cp:demo:1"],
        "reason_codes": ["approval_required"],
        "public_explanation": "Approval is required.",
        "causal_parent_ids": ["evt:1"],
        "outcome_event_ref": None,
        "extensions": {}
    })
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "selected_action_not_candidate" for issue in result.issues)


def test_program_cannot_exceed_declared_max_steps():
    obj = with_fp({
        "schema": "acr.cognitive-program/v0.1",
        "id": "cp:demo:1",
        "version": 1,
        "fingerprint": "",
        "state_ref": "state:demo:1",
        "goal_refs": ["goal:maintain-repo"],
        "steps": [
            {"operator_ref": "cog://epistemic/verify@1", "parameters": {}, "stop_if": []},
            {"operator_ref": "cog://control/stop@1", "parameters": {}, "stop_if": []},
        ],
        "budget": {"max_steps": 1},
        "termination": ["goal_satisfied"],
        "registry_hash": "sha256:" + "2" * 64,
        "extensions": {}
    })
    result = validate_object(obj)
    assert not result.valid
    assert any(issue.code == "program_exceeds_max_steps" for issue in result.issues)
