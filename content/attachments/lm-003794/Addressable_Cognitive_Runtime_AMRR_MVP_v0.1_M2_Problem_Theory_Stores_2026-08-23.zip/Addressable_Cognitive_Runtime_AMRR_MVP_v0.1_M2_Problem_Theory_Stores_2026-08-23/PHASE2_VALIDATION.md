# ACR MVP v0.1 — Phase 2 Validation

**Phase:** Semantic State Encoder  
**Package version:** `0.1.2`  
**Encoder profile:** `acr.semantic-state-encoder/v0.1`

Phase 2 converts strict public runtime observations into deterministic, Phase-0-valid `SemanticState` objects. It does not call a model, use embeddings, perform Phase 3 cognition retrieval, emit CTCL events, or ingest private/hidden chain-of-thought.

## Frozen regression boundaries

- Phase 0 schema count: `10`
- Phase 0 schema hashes: unchanged from the Phase 1 release baseline.
- Phase 1 SPRC/CIO object count: `64`
- Phase 1 registry fingerprint: `sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd`
- Phase 1 registry equals deterministic fresh rebuild: PASS

## Observation contract evidence

- Valid observation fixtures: `3/3`
- Deliberate invalid observation fixtures rejected: `4/4`
- Unknown top-level observation fields: rejected
- `hidden_chain_of_thought`, `private_chain_of_thought`, `reasoning_tokens`: rejected
- Invalid/negative budget values: rejected
- Missing/invalid authority refs: rejected
- Input mappings are not mutated by normalization
- Set-like arrays are sorted and deduplicated deterministically

## Semantic derivation evidence

Progress precedence:

```text
explicit progress
> completed
> blocked
> stalled / repeated_failure_count >= 2
> in_progress
> not_started
> unknown
```

Uncertainty behavior:

- explicit `uncertainty` wins;
- otherwise confidence and verification status are combined by maximum known severity;
- no usable signal yields `unknown`.

Equivalent public observations that differ only by set/list order or by `status=running` versus explicit `progress=in_progress` encode to byte-identical `SemanticState` objects.

## Reference states

| Fixture | Progress | Uncertainty | Fingerprint |
|---|---|---|---|
| `pending.json` | `not_started` | `unknown` | `sha256:37d5d5381c33f0e7a260bffdf196e7426a67aded8984ee2e6d37bf9d5088207e` |
| `repo-clean.json` | `completed` | `low` | `sha256:79e441356ab7dbcacfc873e44ce90e22114214056ff0b9ec559d49e0e0cf4052` |
| `repo-failing.json` | `stalled` | `high` | `sha256:2361bc9309bcfde367a0a34a11c1882150f136afe2e8b29807a45c368ddea7c2` |

Reference `repo-failing.json` state ID:

```text
state:sha256:32ed2492a02c288387586984e5b45dc712534fea6f1970aac560eeb529ac2dc9
```

## CLI

```text
state-encode OBSERVATION.json
state-encode OBSERVATION.json --output STATE.json
```

Invalid observations return a nonzero exit code with machine-readable `error_code`.

## Completion gate

- pytest: `73 passed`
- compileall: PASS
- Phase 0 valid fixtures: `10/10`
- Phase 0 deliberate invalid fixtures rejected: `6/6`
- SPRC source verification: PASS
- SPRC registry deterministic rebuild: PASS
- Phase 2 valid observations: `3/3`
- Phase 2 deliberate invalid observations rejected: `4/4`
- Phase 2 deterministic state rebuild: PASS
- release validator: `ok=true`
- tracked Python bytecode: removed from source/release

The distributable ZIP is additionally extracted into a clean directory and revalidated before delivery.
