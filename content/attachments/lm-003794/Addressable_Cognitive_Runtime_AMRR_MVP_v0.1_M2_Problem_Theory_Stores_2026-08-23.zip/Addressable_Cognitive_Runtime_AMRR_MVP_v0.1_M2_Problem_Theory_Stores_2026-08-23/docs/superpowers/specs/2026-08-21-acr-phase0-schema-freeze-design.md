# ACR Phase 0 Schema Freeze Design

## Goal
Freeze the first interoperable persistence boundary for Addressable Cognitive Runtime (ACR) v0.1 without implementing routing, planning, governance execution, or CTCL transport.

## Source of truth
This phase implements the schema subset of `docs/theory/06_Addressable_Cognitive_Runtime_x_CTCL_統一技術白皮書與實作路線圖_v0.1.md` and preserves the existing architectural invariants:

- `Prompt != Cognition`
- `Cognition != Governance != WorldCommit`
- `CurrentMemory != HistoricalLedger`
- `Can != Should != Authorized`
- `DecisionReceipt != CommitReceipt`
- integrate existing SES/SPRC and CTCL-ITR through adapters rather than rewrite them.

## Scope
Phase 0 freezes exactly ten top-level persisted object schemas:

1. `CognitiveObject`
2. `SemanticState`
3. `CognitiveProgram`
4. `AgendaCandidate`
5. `Contract`
6. `GovernanceDecision`
7. `DecisionReceipt`
8. `KnowledgeBoundary`
9. `Commitment`
10. `ContextCompressionEvent`

`Authority` is intentionally an embedded typed structure in `Contract` and `GovernanceDecision` for Phase 0 rather than an eleventh persisted top-level object. `Goal` remains an external stable reference (`goal_ref`) until the Persistent Goal Store is implemented. Both decisions are reversible in later schema versions.

## Identity and versioning
Every top-level object must contain:

- `schema`: exact schema URI/version token such as `acr.semantic-state/v0.1`;
- `id`: stable object identifier with a type-specific prefix;
- `version`: positive integer object revision;
- `fingerprint`: `sha256:<64 lowercase hex>` over canonical JSON excluding the `fingerprint` field;
- optional `extensions`: explicit open extension bag. Unknown top-level fields are rejected.

`CognitiveObject.id` uses an addressable cognition URI of the form `cog://...@N`. Its `@N` suffix must equal the integer `version`; this semantic constraint is checked by the Python validator.

## Canonicalization
Canonical bytes use UTF-8 JSON with:

- keys sorted;
- separators `(',', ':')`;
- `ensure_ascii=False`;
- no whitespace normalization beyond JSON serialization;
- the top-level `fingerprint` field omitted before hashing.

## References
Cross-object references remain strings in Phase 0. They are syntactically constrained by prefixes where useful (`state:`, `cp:`, `agenda:`, `contract:`, `decision:`, `kb:`, `commitment:`, `ctxc:`). Referential existence is not enforced by a single-object validator because the ledger/store does not yet exist.

## Validation layers
Validation is deliberately two-layered:

1. JSON Schema Draft 2020-12 validates shape, required fields, enums, primitive constraints, and rejects unknown top-level fields.
2. Semantic validation checks canonical fingerprint integrity, cognitive-address/version agreement, duplicate references, governance consistency (`EXECUTE` cannot carry `DENY` authority), and selected high-value invariants that JSON Schema alone cannot express cleanly.

## CLI
`acr-schema` exposes:

- `list` — list frozen schema names and schema tokens;
- `fingerprint FILE` — emit canonical fingerprint for one JSON object;
- `validate FILE` — select schema from the object's `schema` field and validate it;
- `validate --schema NAME FILE` — validate using an explicit schema name;
- `validate-fixtures DIR` — validate every `*.json` fixture recursively.

The CLI returns nonzero on invalid JSON, unknown schema tokens, schema violations, or semantic violations.

## Reference fixtures
The release includes one valid canonical fixture per top-level schema plus invalid fixtures for:

- missing required field;
- unknown top-level field;
- bad fingerprint;
- cognitive address/version mismatch;
- illegal governance authority/decision combination.

## Dependencies
Python 3.11+ and `jsonschema>=4.22,<5`. No model provider, database, CTCL network call, or external service is required for Phase 0.

## Explicit non-goals
Phase 0 does not implement:

- SES/SPRC adapter;
- CTCL-ITR adapter;
- Cognitive Affordance retrieval;
- Program compilation/execution;
- Agenda generation;
- Governance model inference;
- Contract mutation;
- Goal Store;
- Context compression behavior;
- persistent autonomous loop.

These remain later phases against this frozen boundary.

## Success criteria
Phase 0 is complete only when:

- all ten schema files validate under Draft 2020-12;
- valid reference fixtures pass;
- invalid fixtures fail for the intended reason;
- canonical fingerprinting is deterministic;
- semantic invariants are covered by regression tests;
- the CLI works from an editable install and from `PYTHONPATH=src`;
- the release contains schema hashes and a release manifest;
- tests and `compileall` pass from the packaged release.
