# Phase 1 SPRC / CIO Adapter Design

## Goal
Adapt the existing SES1 registry and CIO-Deck-v1.0 into the frozen ACR Phase 0 `CognitiveObject` contract without changing the source operator semantics.

## Source of truth
- Semantic Persona Runtime v2.2.0 source snapshot.
- `CIO-Deck-v1.0` canonical hash: `b436ad318e8fc0d8e8ab98939d275d25b690d1d59031a39c01f81a0af5d0d54e`.
- `SES1` canonical registry hash: `4b33ac3b60407db3641c7ea5f3220c5cb4764578143c1fa15bc5198a2481a33d`.
- v2.1.0 and v2.2.0 deck/registry inputs are byte-identical; v2.2.0 changes multilingual corpus/rendering, not canonical operator meanings.

## Non-goals
- No learned routing.
- No Phase 2 SemanticStateEncoder.
- No reinterpretation of affinity as hard preconditions.
- No inferred cost/risk classes beyond `unknown`.
- No rewriting of SES/SPRC execution semantics.
- No importing all 1024 multilingual rendering rows into the ACR object itself.

## Address strategy
Every source CIO operator ID maps losslessly to:

`cog://sprc/cio/<lowercase-source-id>@1`

Example: `R01 -> cog://sprc/cio/r01@1`.

This source-preserving namespace is deliberate. Phase 1 is an adapter, not a semantic reclassification pass.

## CognitiveObject mapping
- `name`: source English name, falling back to source ID.
- `type`: `cognitive_operator`.
- `preconditions`, `inputs`, `outputs`: empty until a later typed-domain pass establishes them.
- `effects`: exact source `effects` list.
- `cost_class`: `unknown`.
- `risk_class`: `unknown`.
- `compatible_with`, `conflicts_with`: empty unless source data explicitly defines canonical operator-level relations.
- `authority_class`: `cognition_only`.
- `termination`: empty.
- `renderers`: source-preserving direct entries only: `zh-Hant` from deck `trigger`; `en` from SPRC-Corpus reference gloss when available.
- `vector_ref`: null.
- `schema_hash`: frozen Phase 0 cognitive-object schema SHA-256.
- `extensions.sprc`: exact source metadata and source hashes needed for provenance/audit.

## Adapter outputs
- Vendored source snapshots under `vendor/sprc/v2.2.0/`.
- `registry/ACR1-SPRC-CIO-v1.json`: batch-converted 64-object registry.
- Python adapter API for loading, validating, converting, listing, resolving, and verifying source compatibility.
- CLI subcommands for adapter inspection and export.

## Invariants
1. Exactly 64 source operators convert.
2. Source IDs are unique and cover `RSXCDATM × 01..08`.
3. Every converted object passes Phase 0 validation.
4. Converted fingerprints are deterministic.
5. `R01` always resolves to `cog://sprc/cio/r01@1`.
6. No source affinity is promoted to a hard precondition.
7. v2.1.0/v2.2.0 deck and registry compatibility is explicitly recorded, not inferred at runtime.
8. Exported registry records deck/registry/corpus provenance.

## Tests
- Source hash verification.
- 64-card conversion count and family balance.
- Exact representative-field preservation.
- Batch Phase 0 schema validation.
- Deterministic byte-identical registry export.
- Address resolution and reverse source-ID resolution.
- Fail-closed behavior for unknown/malformed operators or source-hash mismatch.
- CLI smoke tests.
