# Phase 2 Semantic State Encoder Design

## Goal
Convert a strict public `Observation` mapping into one deterministic, Phase-0-valid `SemanticState` without model calls, embeddings, operator retrieval, or hidden-reasoning access.

## Source of truth
- Frozen `acr.semantic-state/v0.1` schema from Phase 0.
- Phase 2 roadmap in `docs/theory/06_Addressable_Cognitive_Runtime_x_CTCL_統一技術白皮書與實作路線圖_v0.1.md`.
- Phase 1 remains unchanged and supplies addressable cognition only; Phase 2 does not rank or select those operators.

## Non-goals
- No Phase 3 cognitive-affordance retrieval.
- No model/provider call.
- No embeddings.
- No CTCL event emission yet.
- No mutation of the Phase 0 schemas or Phase 1 SPRC/CIO registry.
- No inference from private or hidden chain-of-thought.

## Public Observation contract
The encoder accepts a plain mapping with these top-level keys only:

- `goal_refs`: list of `goal:` refs; default `[]`.
- `active_commitments`: list of `commitment:` refs; default `[]`.
- `progress`: optional canonical explicit progress string.
- `status`: optional public runtime status used only when `progress` is absent.
- `started`, `completed`, `blocked`, `stalled`: optional booleans.
- `repeated_failure_count`: optional non-negative integer.
- `uncertainty`: optional explicit `low|medium|high|unknown`.
- `confidence`: optional public numeric confidence in `[0,1]`.
- `verification_status`: optional `verified|partial|unverified|failed|contradicted|unknown`.
- `failures`, `missing`, `risks`: lists of non-empty strings; default `[]`.
- `budget`: mapping using only Phase-0 budget keys plus `extensions`; default `{}`.
- `authority_ref`: required `authority:` or `contract:` ref.
- `environment_refs`, `memory_refs`: ref lists; default `[]`.
- `extensions`: open caller-owned input bag that is not promoted into canonical semantic fields in Phase 2.

Unknown top-level keys fail closed. Explicit private-reasoning keys such as `hidden_chain_of_thought`, `private_chain_of_thought`, and `reasoning_tokens` fail with a dedicated boundary error.

## Normalization
Set-like arrays are de-duplicated and sorted lexically so order-only differences produce byte-identical semantic states. Strings are stripped; empty strings fail. Budget numbers are validated, never silently clamped. Booleans are rejected where integers are expected.

## Progress derivation
Explicit `progress` wins if non-empty. Otherwise derive in this order:

1. `completed == true` or status in `completed|succeeded|done` → `completed`.
2. `blocked == true` or status in `blocked|waiting_external|waiting_approval` → `blocked`.
3. `stalled == true`, status `stalled`, or `repeated_failure_count >= 2` → `stalled`.
4. `started == true` or status in `running|in_progress|active` → `in_progress`.
5. status in `not_started|pending|new` → `not_started`.
6. otherwise → `unknown`.

## Uncertainty derivation
Explicit `uncertainty` wins. Otherwise combine available public signals conservatively by taking the highest severity:

- confidence: `[0.85,1] -> low`, `[0.60,0.85) -> medium`, `[0,0.60) -> high`.
- verification: `verified -> low`, `partial -> medium`, `unverified|failed|contradicted -> high`, `unknown -> unknown`.

If neither signal exists, output `unknown`. `unknown` does not override a known severity when another signal exists.

## Stable identity and fingerprint
The encoder emits version `1` and `extensions.state_encoder.profile = "acr.semantic-state-encoder/v0.1"`.

`SemanticState.id` is content-addressed from the normalized semantic payload excluding `schema`, `id`, `version`, `fingerprint`, and `extensions`:

`state:sha256:<64 lowercase hex>`.

The existing Phase 0 `fingerprint_object()` then fingerprints the complete object excluding only `fingerprint`. Equivalent normalized public observations therefore produce byte-identical `SemanticState` objects.

## API
- `normalize_observation(observation) -> dict`
- `derive_progress(normalized_observation) -> str`
- `derive_uncertainty(normalized_observation) -> str`
- `encode_semantic_state(observation) -> dict`
- `encode_semantic_state_file(path) -> dict`
- `ObservationError(ValueError)` with stable `code`.

## CLI
Add:

- `acr-schema state-encode OBSERVATION.json`
- optional `--output FILE` writes canonical pretty JSON; stdout always emits the encoded object when no output is supplied.

Invalid observation input exits nonzero with JSON `{valid:false,error_code,error}`.

## Invariants
1. The output passes the frozen Phase 0 `SemanticState` validator.
2. Equivalent input ordering yields identical output bytes/fingerprint.
3. Unknown/private reasoning fields fail closed.
4. No Phase 0 schema or Phase 1 registry byte changes.
5. Encoder does not import or call the SPRC router/retriever.
6. No external network/model dependency.
