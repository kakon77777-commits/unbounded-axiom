# ACR Phase 0 Schema Freeze Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build and verify the ten frozen ACR v0.1 persistence schemas, deterministic fingerprints, semantic validation, CLI, and release fixtures.

**Architecture:** JSON Schema Draft 2020-12 defines structural contracts under `schemas/`. A small Python package loads schemas, canonicalizes/fingerprints objects, applies JSON Schema plus cross-field semantic checks, and exposes a CLI. Reference fixtures and regression tests prove valid/invalid behavior without requiring any model provider or CTCL service.

**Tech Stack:** Python 3.11+, jsonschema 4.x, pytest, stdlib hashlib/json/pathlib/argparse.

**Spec:** `docs/superpowers/specs/2026-08-21-acr-phase0-schema-freeze-design.md`

## Global Constraints

- Freeze exactly ten top-level persisted schemas in Phase 0.
- Authority remains embedded; Goal remains a stable external reference.
- Unknown top-level fields are rejected; extensibility uses the explicit `extensions` bag.
- Top-level fingerprints are SHA-256 over canonical JSON excluding `fingerprint`.
- No model/provider/database/CTCL network dependency in Phase 0.
- Do not implement Phase 1 adapters in this plan.

---

### Task 1: Package skeleton and schema catalog contract

**Files:**
- Create: `pyproject.toml`
- Create: `src/addressable_cognitive_runtime/__init__.py`
- Create: `src/addressable_cognitive_runtime/schema_catalog.py`
- Test: `tests/test_schema_catalog.py`

**Interfaces:**
- Produces: `SCHEMA_SPECS`, `schema_path(name)`, `schema_name_for_token(token)`.

- [x] Write tests asserting exactly ten canonical names, unique schema tokens, and existing paths.
- [x] Run the targeted test and verify RED because the package/catalog does not exist.
- [x] Implement the minimal package/catalog and pyproject metadata.
- [x] Run the targeted test and verify GREEN.
- [x] Commit.

### Task 2: Frozen JSON Schemas

**Files:**
- Create: `schemas/common.schema.json`
- Create ten schema files under `schemas/` matching the spec names.
- Test: `tests/test_schema_files.py`

**Interfaces:**
- Consumes: schema catalog from Task 1.
- Produces: Draft 2020-12-valid schemas with explicit extension bags and stable schema tokens.

- [x] Write tests that load every schema, check Draft 2020-12 validity, required identity fields, `additionalProperties=false`, and explicit `extensions`.
- [x] Run the targeted test and verify RED because schema files do not exist.
- [x] Implement `common.schema.json` and all ten schemas.
- [x] Run the targeted test and verify GREEN.
- [x] Commit.

### Task 3: Canonical fingerprint and validator

**Files:**
- Create: `src/addressable_cognitive_runtime/canonical.py`
- Create: `src/addressable_cognitive_runtime/validation.py`
- Test: `tests/test_canonical.py`
- Test: `tests/test_validation.py`

**Interfaces:**
- Produces: `canonical_bytes(obj)`, `fingerprint_object(obj)`, `validate_object(obj, schema_name=None)`, `ValidationIssue`, `ValidationResult`.

- [x] Write deterministic hashing tests and semantic-invariant tests.
- [x] Run targeted tests and verify RED because implementation is missing.
- [x] Implement canonical hashing, schema validation, fingerprint validation, cognition address/version check, duplicate-reference detection, and governance consistency checks.
- [x] Run targeted tests and verify GREEN.
- [x] Commit.

### Task 4: Reference fixtures and CLI

**Files:**
- Create: `examples/valid/*.json` (ten fixtures)
- Create: `examples/invalid/*.json` (at least five fixtures)
- Create: `src/addressable_cognitive_runtime/cli.py`
- Create: `src/addressable_cognitive_runtime/__main__.py`
- Test: `tests/test_fixtures.py`
- Test: `tests/test_cli.py`

**Interfaces:**
- Produces: `acr-schema` / `python -m addressable_cognitive_runtime` commands.

- [x] Write fixture/CLI tests including nonzero invalid exit behavior.
- [x] Run targeted tests and verify RED.
- [x] Add fixtures with correct fingerprints and implement CLI commands `list`, `fingerprint`, `validate`, `validate-fixtures`.
- [x] Run targeted tests and verify GREEN.
- [x] Commit.

### Task 5: Documentation and release validation

**Files:**
- Create: `README.md`
- Create: `PHASE0_VALIDATION.md`
- Create: `scripts/validate_release.py`
- Create: `MANIFEST.json`
- Create: `CHECKSUMS.sha256`
- Test: `tests/test_release_validator.py`

**Interfaces:**
- Produces: offline release validator that checks schema set, fixtures, manifest, and checksums.

- [x] Write release-validator test and verify RED.
- [x] Implement README, validation record, validator, manifest/checksum generation.
- [x] Run full `pytest -q` and `python -m compileall -q src`.
- [x] Run CLI validation against valid and invalid fixtures.
- [x] Build a clean release ZIP, extract it separately, verify checksums, tests, compileall, and release validator from extracted bytes.
- [x] Commit final Phase 0 release state.
