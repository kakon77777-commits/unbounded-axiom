# AMRR M0 Math Schema Freeze Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a frozen, machine-validatable AMRR mathematical schema layer without changing the existing ACR Phase 0–2 canonical schema hashes or Semantic State behavior.

**Architecture:** Preserve the existing ten Phase-0 schemas in `SCHEMA_SPECS` as an immutable compatibility boundary. Add a separate `MATH_SCHEMA_SPECS` catalog for 19 AMRR M0 canonical objects, expose `ALL_SCHEMA_SPECS` only to generic validation, and place new JSON Schemas under `schemas/math/`. Validation will register both the existing ACR common schema and an AMRR math common schema, while Phase-0 release validation continues to inspect only the original ten schemas.

**Tech Stack:** Python 3.11+, JSON Schema Draft 2020-12, `jsonschema`, `referencing`, `pytest`, canonical SHA-256 fingerprints.

**Spec:** `/mnt/data/AMRR_Technical_Whitepaper_v0.1/AMRR_Technical_Whitepaper_v0.1.md`

## Global Constraints

- Existing ACR Phase-0 schema count remains exactly `10` in `SCHEMA_SPECS`.
- Existing Phase-0 schema file bytes and SHA-256 hashes must not change.
- Existing Phase-1 SPRC registry fingerprint must not change.
- Existing Phase-2 Semantic State Encoder behavior must not change.
- New AMRR M0 canonical schema count is exactly `19` in `MATH_SCHEMA_SPECS`.
- New schema tokens use the `amrr.* /v0.1` namespace and JSON Schema Draft 2020-12.
- Every canonical AMRR object has explicit `schema`, `id`, `version`, `fingerprint`, and `extensions` fields; top-level `additionalProperties` is `false`.
- Cross-object relationships are stable refs, not implicit nested state.
- Math helper definitions live in `schemas/math/common.schema.json` and are not counted as canonical objects.
- M0 does not implement diagnosis, repair, proof search, theory mutation execution, verifier execution, or persistent autonomy.

---

### Task 1: Add the AMRR schema catalog without breaking the Phase-0 freeze

**Files:**
- Modify: `src/addressable_cognitive_runtime/schema_catalog.py`
- Modify: `src/addressable_cognitive_runtime/validation.py`
- Create: `tests/test_math_schema_catalog.py`

**Interfaces:**
- Consumes: existing `SCHEMA_SPECS`, `schema_path()`, `schema_name_for_token()`.
- Produces: `MATH_SCHEMA_SPECS`, `ALL_SCHEMA_SPECS`, math token reverse lookup, nested `schemas/math/*.schema.json` paths.

- [ ] **Step 1: Write the failing catalog tests**

Create `tests/test_math_schema_catalog.py` asserting:

```python
from addressable_cognitive_runtime.schema_catalog import (
    ALL_SCHEMA_SPECS,
    MATH_SCHEMA_SPECS,
    SCHEMA_SPECS,
    schema_name_for_token,
    schema_path,
)

EXPECTED_MATH = {
    "mathematical-state-extension": "amrr.mathematical-state-extension/v0.1",
    "problem-record": "amrr.problem-record/v0.1",
    "problem-relation": "amrr.problem-relation/v0.1",
    "problem-mutation": "amrr.problem-mutation/v0.1",
    "assumption-envelope": "amrr.assumption-envelope/v0.1",
    "theory-record": "amrr.theory-record/v0.1",
    "theory-extension": "amrr.theory-extension/v0.1",
    "math-change-set": "amrr.math-change-set/v0.1",
    "gap": "amrr.gap/v0.1",
    "gap-map": "amrr.gap-map/v0.1",
    "repair-candidate": "amrr.repair-candidate/v0.1",
    "mathematical-obligation": "amrr.mathematical-obligation/v0.1",
    "obligation-graph": "amrr.obligation-graph/v0.1",
    "verification-request": "amrr.verification-request/v0.1",
    "verification-receipt": "amrr.verification-receipt/v0.1",
    "theory-bridge": "amrr.theory-bridge/v0.1",
    "discovery-receipt": "amrr.discovery-receipt/v0.1",
    "research-receipt": "amrr.research-receipt/v0.1",
    "claim-record": "amrr.claim-record/v0.1",
}


def test_phase0_catalog_stays_frozen_at_ten():
    assert len(SCHEMA_SPECS) == 10


def test_math_catalog_is_exactly_m0_nineteen():
    assert {name: spec.token for name, spec in MATH_SCHEMA_SPECS.items()} == EXPECTED_MATH
    assert len(ALL_SCHEMA_SPECS) == 29


def test_math_paths_live_under_math_subdirectory():
    for name in EXPECTED_MATH:
        assert schema_path(name).parent.name == "math"


def test_math_tokens_reverse_resolve():
    for name, token in EXPECTED_MATH.items():
        assert schema_name_for_token(token) == name
```

- [ ] **Step 2: Run the tests and confirm RED**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_schema_catalog.py -q
```

Expected: collection/import failure because `MATH_SCHEMA_SPECS` and `ALL_SCHEMA_SPECS` do not exist.

- [ ] **Step 3: Implement the minimal catalog split**

In `schema_catalog.py`:

```python
_PHASE0_SCHEMA_ROWS = (...existing ten rows unchanged...)
_MATH_SCHEMA_ROWS = (
    ("mathematical-state-extension", "amrr.mathematical-state-extension/v0.1"),
    ...
)

SCHEMA_SPECS = {...existing ten specs with top-level filenames...}
MATH_SCHEMA_SPECS = {
    name: SchemaSpec(name=name, token=token, filename=f"math/{name}.schema.json")
    for name, token in _MATH_SCHEMA_ROWS
}
ALL_SCHEMA_SPECS = {**SCHEMA_SPECS, **MATH_SCHEMA_SPECS}
_TOKEN_TO_NAME = {spec.token: name for name, spec in ALL_SCHEMA_SPECS.items()}
```

Make `schema_path()` resolve names from `ALL_SCHEMA_SPECS` while leaving `SCHEMA_SPECS` unchanged.

In `validation.py`, use `ALL_SCHEMA_SPECS` only for generic schema-name acceptance; keep the old Phase-0 catalog untouched.

- [ ] **Step 4: Run catalog tests and existing Phase-0 catalog tests**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_schema_catalog.py tests/test_schema_catalog.py -q
```

Expected: math path existence assertions still fail until Task 2; all other catalog assertions pass. Phase-0 catalog tests remain green.

- [ ] **Step 5: Commit**

```bash
git add src/addressable_cognitive_runtime/schema_catalog.py src/addressable_cognitive_runtime/validation.py tests/test_math_schema_catalog.py
git commit -m "feat(amrr): add isolated M0 schema catalog"
```

---

### Task 2: Freeze the 19 canonical AMRR M0 schemas

**Files:**
- Create: `schemas/math/common.schema.json`
- Create: `schemas/math/mathematical-state-extension.schema.json`
- Create: `schemas/math/problem-record.schema.json`
- Create: `schemas/math/problem-relation.schema.json`
- Create: `schemas/math/problem-mutation.schema.json`
- Create: `schemas/math/assumption-envelope.schema.json`
- Create: `schemas/math/theory-record.schema.json`
- Create: `schemas/math/theory-extension.schema.json`
- Create: `schemas/math/math-change-set.schema.json`
- Create: `schemas/math/gap.schema.json`
- Create: `schemas/math/gap-map.schema.json`
- Create: `schemas/math/repair-candidate.schema.json`
- Create: `schemas/math/mathematical-obligation.schema.json`
- Create: `schemas/math/obligation-graph.schema.json`
- Create: `schemas/math/verification-request.schema.json`
- Create: `schemas/math/verification-receipt.schema.json`
- Create: `schemas/math/theory-bridge.schema.json`
- Create: `schemas/math/discovery-receipt.schema.json`
- Create: `schemas/math/research-receipt.schema.json`
- Create: `schemas/math/claim-record.schema.json`
- Create: `tests/test_math_schema_files.py`
- Modify: `src/addressable_cognitive_runtime/validation.py`

**Interfaces:**
- Consumes: `MATH_SCHEMA_SPECS`, ACR common `version`, `fingerprint`, `ref`, `ref_array`, `extensions` definitions.
- Produces: 19 closed Draft-2020-12 canonical schemas plus one helper schema at `urn:amrr:schema:common:v0.1`.

- [ ] **Step 1: Write failing schema-structure tests**

`tests/test_math_schema_files.py` must assert:

```python
required_identity = {"schema", "id", "version", "fingerprint"}
for name, spec in MATH_SCHEMA_SPECS.items():
    schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
    assert schema["properties"]["schema"]["const"] == spec.token
    assert required_identity <= set(schema["required"])
    assert "extensions" in schema["properties"]
    assert schema["additionalProperties"] is False
```

Also assert `schemas/math/common.schema.json` is a valid Draft-2020-12 schema and contains definitions for `problem_relation`, `math_domain`, `theory_extension_class`, `obligation_status`, `verifier_class`, `verification_result`, `bridge_relation`, `bridge_strength`, and `novelty_status`.

- [ ] **Step 2: Run and confirm RED**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_schema_files.py tests/test_math_schema_catalog.py -q
```

Expected: failures because the `schemas/math/` files do not exist.

- [ ] **Step 3: Add `schemas/math/common.schema.json`**

Define the shared enums exactly as used by the whitepaper. The helper schema is not a canonical object and is not added to `MATH_SCHEMA_SPECS`.

- [ ] **Step 4: Add the 19 closed canonical schemas**

Each schema must:

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:amrr:schema:<name>:v0.1",
  "type": "object",
  "required": ["schema", "id", "version", "fingerprint", "...domain fields..."],
  "properties": {
    "schema": {"const": "amrr.<name>/v0.1"},
    "id": {"type": "string", "pattern": "^<object-prefix>:"},
    "version": {"$ref": "urn:acr:schema:common:v0.1#/$defs/version"},
    "fingerprint": {"$ref": "urn:acr:schema:common:v0.1#/$defs/fingerprint"},
    "extensions": {"$ref": "urn:acr:schema:common:v0.1#/$defs/extensions"}
  },
  "additionalProperties": false
}
```

Use stable refs for cross-object links. Do not embed hidden reasoning or implicit theory state.

- [ ] **Step 5: Register the math helper schema in validation**

Update `_registry()` so both:

```text
urn:acr:schema:common:v0.1
urn:amrr:schema:common:v0.1
```

are available to validators.

- [ ] **Step 6: Run schema tests**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_schema_catalog.py tests/test_math_schema_files.py tests/test_schema_catalog.py tests/test_schema_files.py -q
```

Expected: PASS.

- [ ] **Step 7: Commit**

```bash
git add schemas/math src/addressable_cognitive_runtime/validation.py tests/test_math_schema_files.py
git commit -m "feat(amrr): freeze M0 mathematical schemas"
```

---

### Task 3: Add canonical valid/invalid fixtures and generic validation coverage

**Files:**
- Create: `examples/math/valid/*.json` for all 19 canonical objects
- Create: `examples/math/invalid/*.json` for targeted boundary violations
- Create: `tests/test_math_fixtures.py`
- Modify: `src/addressable_cognitive_runtime/validation.py` only if a genuine M0 semantic invariant is required

**Interfaces:**
- Consumes: `validate_object()`, `fingerprint_object()`, all AMRR M0 schemas.
- Produces: deterministic reference objects and deliberately invalid cases for release validation.

- [ ] **Step 1: Write fixture tests before creating fixtures**

Tests must assert:

```python
valid_files = sorted((ROOT / "examples" / "math" / "valid").glob("*.json"))
invalid_files = sorted((ROOT / "examples" / "math" / "invalid").glob("*.json"))
assert len(valid_files) == 19
assert len(invalid_files) >= 8
assert all(validate_object(load(path)).valid for path in valid_files)
assert all(not validate_object(load(path)).valid for path in invalid_files)
```

For every valid fixture also assert:

```python
assert obj["fingerprint"] == fingerprint_object(obj)
assert validate_object(obj).schema_name in MATH_SCHEMA_SPECS
```

- [ ] **Step 2: Run and confirm RED**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_fixtures.py -q
```

Expected: fixture-count failure because the directories are empty/missing.

- [ ] **Step 3: Create one valid fixture per schema**

Use deterministic, minimal objects. Compute each `fingerprint` with `fingerprint_object()` after all other fields are populated.

- [ ] **Step 4: Create targeted invalid fixtures**

At minimum cover:

```text
unknown top-level field
bad fingerprint
bad problem relation enum
invalid confidence > 1
invalid gap domain
invalid obligation status
invalid verification result
invalid bridge strength
```

- [ ] **Step 5: Run fixture and generic validation tests**

Run:

```bash
PYTHONPATH=src pytest tests/test_math_fixtures.py tests/test_validation.py -q
```

Expected: PASS.

- [ ] **Step 6: Commit**

```bash
git add examples/math tests/test_math_fixtures.py src/addressable_cognitive_runtime/validation.py
git commit -m "test(amrr): add M0 canonical fixtures"
```

---

### Task 4: Add M0 release metadata, regression gates, and distributable package

**Files:**
- Create: `AMRR_M0_VALIDATION.md`
- Create: `scripts/validate_amrr_m0.py`
- Create: `tests/test_amrr_m0_release.py`
- Modify: `README.md`
- Modify: `src/addressable_cognitive_runtime/__init__.py`
- Modify: `pyproject.toml`
- Create/Update: `MANIFEST.json`
- Create/Update: `CHECKSUMS.sha256`

**Interfaces:**
- Consumes: Phase-0 frozen hashes, Phase-1 registry fingerprint, Phase-2 encoder baseline, M0 math schema hashes and fixtures.
- Produces: independently verifiable AMRR M0 release evidence and ZIP-ready source tree.

- [ ] **Step 1: Write failing release tests**

`tests/test_amrr_m0_release.py` must assert:

```python
assert __version__ == "0.2.0"
assert len(SCHEMA_SPECS) == 10
assert len(MATH_SCHEMA_SPECS) == 19
assert manifest["release"] == "ACR-AMRR-MVP-v0.1-M0"
assert manifest["phase"] == "AMRR M0 - Math Schema Freeze"
assert manifest["phase0_schema_count"] == 10
assert manifest["math_schema_count"] == 19
assert manifest["phase1_registry_fingerprint"] == PHASE1_REGISTRY_FINGERPRINT
```

The release validator subprocess must return `ok=true`.

- [ ] **Step 2: Run and confirm RED**

Run:

```bash
PYTHONPATH=src pytest tests/test_amrr_m0_release.py -q
```

Expected: FAIL because the release version/manifest/validator do not yet exist.

- [ ] **Step 3: Implement `scripts/validate_amrr_m0.py`**

It must verify:

```text
Phase-0 count = 10 and every original hash unchanged
Phase-1 registry fingerprint unchanged
Phase-2 state-encoder targeted regression passes
Math schema count = 19
All 19 math schemas pass Draft202012Validator.check_schema
All 19 valid math fixtures validate
All deliberate invalid math fixtures are rejected
Every valid fixture fingerprint is canonical
Manifest math schema hashes match files
CHECKSUMS.sha256 matches all packaged payload files
```

Print a single JSON result containing `ok`, counts, hash maps, and failures.

- [ ] **Step 4: Update version and metadata**

Set package version to `0.2.0` in both `pyproject.toml` and `src/addressable_cognitive_runtime/__init__.py`.

Update `README.md` with the explicit status boundary:

```text
Implemented Baseline: ACR Phase 0–2 + AMRR M0 canonical schemas
Not Implemented Yet: AMRR M1–M11 runtime capabilities
```

Write `AMRR_M0_VALIDATION.md` with exact verification evidence.

- [ ] **Step 5: Build MANIFEST and checksums**

`MANIFEST.json` must include both frozen Phase-0 hashes and the new 19 math schema hashes. `CHECKSUMS.sha256` must exclude `.git`, cache files, and itself.

- [ ] **Step 6: Run targeted regression suite**

Run:

```bash
PYTHONPATH=src pytest \
  tests/test_schema_catalog.py \
  tests/test_schema_files.py \
  tests/test_math_schema_catalog.py \
  tests/test_math_schema_files.py \
  tests/test_math_fixtures.py \
  tests/test_canonical.py \
  tests/test_validation.py \
  tests/test_state_observation.py \
  tests/test_state_encoder.py \
  tests/test_sprc_registry.py \
  tests/test_amrr_m0_release.py -q
```

Expected: PASS with zero failures.

- [ ] **Step 7: Run compile and release validation**

Run:

```bash
python -m compileall -q src scripts
PYTHONPATH=src python scripts/validate_amrr_m0.py --root .
```

Expected: `ok=true`.

- [ ] **Step 8: Commit**

```bash
git add README.md AMRR_M0_VALIDATION.md scripts/validate_amrr_m0.py tests/test_amrr_m0_release.py pyproject.toml src/addressable_cognitive_runtime/__init__.py MANIFEST.json CHECKSUMS.sha256
git commit -m "release(amrr): complete M0 math schema freeze"
```

## Execution correction recorded during Task 4

The imported Phase-2 package already has a Phase-2 `MANIFEST.json`, `CHECKSUMS.sha256`, and release tests whose semantic purpose is to describe the base ACR release. M0 therefore uses additive `AMRR_M0_MANIFEST.json` and `AMRR_M0_CHECKSUMS.sha256` rather than laundering the base manifest into a different release. The core Python package version remains `0.1.2`; AMRR M0 has its own metadata version `0.1.0`. Existing Phase-0 schema bytes/hashes and Phase-1 registry fingerprint remain frozen. The ordinary `CHECKSUMS.sha256` is regenerated after source additions so the expanded source tree can still pass the base checksum validator.
