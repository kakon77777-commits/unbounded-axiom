# AMRR M2 Problem / Theory Stores Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement immutable file-backed Problem, Theory, and AssumptionEnvelope stores with exact version lineage, branching, querying, graph reconstruction, and no-silent-overwrite guarantees.

**Architecture:** Preserve all M0 schemas unchanged. Add a math storage package that persists each canonical `(id, version)` as a separate UTF-8 JSON file, records exact parent versions inside `extensions.amrr_m2_store.parent_versions`, validates every write/read through the frozen M0 schemas, and reconstructs version DAGs from those canonical records. M2 is additive over M1 and must preserve all Phase 0–2, M0, and M1 compatibility invariants.

**Tech Stack:** Python 3.11+, stdlib pathlib/json/urllib, existing `jsonschema` validation layer, pytest.

**Spec:** `docs/amrr/04_自主數學研究Runtime_從可定址認知到自主理論建構_v0.1.md`

## Global Constraints

- Do not modify the 10 frozen ACR Phase-0 schemas.
- Do not modify the 19 frozen AMRR M0 mathematical schemas.
- Preserve M0 and M1 manifests/checksum files byte-for-byte as historical anchors.
- No hidden/private chain-of-thought fields enter canonical storage.
- Every persisted object must pass its frozen schema and canonical fingerprint validation.
- Existing `(id, version)` content is immutable: identical replay is allowed; different replay is rejected.
- No M3–M11 capability may be claimed as implemented.

---

### Task 1: Versioned Store Core

**Files:**
- Create: `src/addressable_cognitive_runtime/math/__init__.py`
- Create: `src/addressable_cognitive_runtime/math/errors.py`
- Create: `src/addressable_cognitive_runtime/math/store.py`
- Test: `tests/test_math_versioned_store.py`

**Interfaces:**
- Produces: `MathStoreError(code: str, message: str)`
- Produces: `VersionRef(object_id: str, version: int)` with `.token`
- Produces: `VersionedObjectStore(root: Path, namespace: str, schema_name: str, id_prefix: str)`
- Produces: `put(record)`, `get(object_id, version=None)`, `versions(object_id)`, `records()`, `graph()`

- [ ] Write tests proving missing API and no-silent-overwrite behavior.
- [ ] Run tests and confirm RED because `addressable_cognitive_runtime.math` does not exist.
- [ ] Implement the minimal immutable file-backed store and schema/fingerprint validation.
- [ ] Run tests and confirm GREEN.
- [ ] Commit `feat: add immutable AMRR versioned object store`.

### Task 2: Problem Store and Problem Version DAG

**Files:**
- Create: `src/addressable_cognitive_runtime/math/problem_store.py`
- Modify: `src/addressable_cognitive_runtime/math/__init__.py`
- Test: `tests/test_problem_store.py`

**Interfaces:**
- Produces: `ProblemStore(root: Path)`
- Produces: `create(...) -> dict`
- Produces: `derive(problem_id, *, from_version=None, new_problem_id=None, relation_to_parent, updates=None) -> dict`
- Produces: `branch(...) -> dict`
- Produces: inherited `get`, `versions`, `records`, `graph`

- [ ] Write tests for root creation, same-id version derivation, new-id branch, exact parent-version edges, idempotent replay, missing-parent rejection, and silent-overwrite rejection.
- [ ] Run tests and confirm RED.
- [ ] Implement builder + derive/branch logic using `extensions.amrr_m2_store.parent_versions`.
- [ ] Run tests and confirm GREEN.
- [ ] Commit `feat: add AMRR problem version store`.

### Task 3: Theory Store and Assumption Envelope Store

**Files:**
- Create: `src/addressable_cognitive_runtime/math/theory_store.py`
- Create: `src/addressable_cognitive_runtime/math/assumption_store.py`
- Modify: `src/addressable_cognitive_runtime/math/__init__.py`
- Test: `tests/test_theory_store.py`
- Test: `tests/test_assumption_store.py`

**Interfaces:**
- Produces: `TheoryStore.create(...)`, `TheoryStore.derive(...)`, `TheoryStore.branch(...)`
- Produces: `AssumptionEnvelopeStore.create(...)`, `AssumptionEnvelopeStore.derive(...)`
- Both inherit immutable exact-version storage/query behavior.

- [ ] Write failing tests for theory version graph, theory branch, assumption envelope versioning, and no-silent-overwrite behavior.
- [ ] Run tests and confirm RED.
- [ ] Implement minimal stores.
- [ ] Run tests and confirm GREEN.
- [ ] Commit `feat: add theory and assumption envelope stores`.

### Task 4: M2 Reference Fixtures and Runtime Validation

**Files:**
- Create: `examples/math-store/m2-demo.json`
- Create: `tests/test_amrr_m2_runtime.py`
- Create: `scripts/build_amrr_m2_metadata.py`
- Create: `scripts/validate_amrr_m2.py`
- Create: `AMRR_M2_README.md`
- Create: `AMRR_M2_VALIDATION.md`
- Create: `AMRR_M2_MANIFEST.json`
- Create: `AMRR_M2_CHECKSUMS.sha256`

**Interfaces:**
- `scripts/validate_amrr_m2.py --root .` returns exit 0 and JSON `ok=true` only if historical anchors, frozen schemas, M1 identities, M2 store invariants, fixtures, and checksums all pass.

- [ ] Write failing release tests before metadata scripts exist.
- [ ] Run tests and confirm RED.
- [ ] Implement deterministic reference-store fixture generation and M2 metadata/validator scripts.
- [ ] Build metadata and run validator.
- [ ] Run tests and confirm GREEN.
- [ ] Commit `feat: add AMRR M2 release validation`.

### Task 5: Full Regression and Clean-Package Verification

**Files:**
- Modify: `README.md`
- Finalize: `AMRR_M2_VALIDATION.md`

**Interfaces:**
- Produces a clean M2 ZIP that can be extracted with Python `zipfile` and independently validated.

- [ ] Run all collected pytest cases in batches if one-shot execution exceeds the environment limit; record exact total/pass/fail counts.
- [ ] Run `python -m compileall -q src`.
- [ ] Run Phase-2 and M0 compatibility validators, M1 validator, and M2 validator with correct historical-snapshot vs forward-compatibility semantics.
- [ ] Build a clean UTF-8 ZIP excluding `.git`, caches, and bytecode.
- [ ] Re-extract the ZIP into a clean directory with Python `zipfile` and rerun the M2 validator plus targeted store tests.
- [ ] Record ZIP SHA-256 in final handoff.
