from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from jsonschema import Draft202012Validator

PHASE0_SCHEMA_HASHES = {
    "cognitive-object": "2d38d9be37bb6425f4fde6ee2a40d593f95ad52ef94ef3bfd698b8b485541d29",
    "semantic-state": "e406aa9206f187c5b97ff5ac4e60db74f277a67b719b14123c1c1f6918f4d5a6",
    "cognitive-program": "62b40fac768028cd4a986604c90771b45a2a40183eef12c89bd95a59fe717932",
    "agenda-candidate": "acac33cb02e5deb65f663d37270b94a081d9000419b43bbaf2318c28557dd8df",
    "contract": "5f804c70e87d89bace3107815fd5b94c320393dcbb3b8b4623433b5f6b9c9e96",
    "governance-decision": "b4e3727b4813abb6b2e3a0e7b70b081a6968678f62c3e0cf7e315401c3ce50df",
    "decision-receipt": "ca24d7e73b8245796d8254e4e6530278cb125312409ab88b70dc14fcd40d0a61",
    "knowledge-boundary": "816702db685779a3e2f17b4cffd0a00e605c3883f184c8b57caec651f9295ee6",
    "commitment": "7922eec5a5a97c5c83184e06404f597875228801c8ba47dd7f390e38576813fc",
    "context-compression-event": "53d732bffa00a7690aba415b09fc57ddc77e6bae29b8707fa774561ad843d467",
}
PHASE1_REGISTRY_FINGERPRINT = "sha256:435cdfe0fc962e15ffd83e489274a0da4c6b6fa756c8bc20c0939fe6e395d9bd"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    parser.add_argument("--compatibility-only", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source, verify_sprc_source
    from addressable_cognitive_runtime.schema_catalog import SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state.encoder import ENCODER_PROFILE, ObservationError, encode_semantic_state_file
    from addressable_cognitive_runtime.validation import validate_object

    failures: list[str] = []
    if len(SCHEMA_SPECS) != 10:
        failures.append(f"schema_count={len(SCHEMA_SPECS)}")
    for name in SCHEMA_SPECS:
        try:
            schema = json.loads(schema_path(name).read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            failures.append(f"schema:{name}:{exc}")
        if digest(schema_path(name)) != PHASE0_SCHEMA_HASHES.get(name):
            failures.append(f"phase0_schema_drift:{name}")

    valid_files = sorted((root / "examples" / "valid").glob("*.json"))
    invalid_files = sorted((root / "examples" / "invalid").glob("*.json"))
    valid_ok = sum(validate_object(json.loads(p.read_text(encoding="utf-8"))).valid for p in valid_files)
    invalid_ok = sum(not validate_object(json.loads(p.read_text(encoding="utf-8"))).valid for p in invalid_files)
    if valid_ok != len(valid_files):
        failures.append("valid_fixture_rejected")
    if invalid_ok != len(invalid_files):
        failures.append("invalid_fixture_accepted")

    sprc_source_verified = False
    sprc_object_count = 0
    sprc_registry_matches_builder = False
    rebuilt: dict = {}
    try:
        source = load_sprc_source()
        verify_sprc_source(source)
        sprc_source_verified = True
        rebuilt = build_sprc_registry(source)
        sprc_object_count = int(rebuilt["object_count"])
        if sprc_object_count != 64 or not all(validate_object(obj).valid for obj in rebuilt["objects"]):
            failures.append("sprc_objects_invalid")
        if rebuilt.get("fingerprint") != PHASE1_REGISTRY_FINGERPRINT:
            failures.append("phase1_registry_drift")
        registry_path = root / "registry" / "ACR1-SPRC-CIO-v1.json"
        stored = json.loads(registry_path.read_text(encoding="utf-8"))
        sprc_registry_matches_builder = stored == rebuilt
        if not sprc_registry_matches_builder:
            failures.append("sprc_registry_builder_mismatch")
    except Exception as exc:
        failures.append(f"sprc:{exc}")

    state_valid_files = sorted((root / "examples" / "state-observations" / "valid").glob("*.json"))
    state_invalid_files = sorted((root / "examples" / "state-observations" / "invalid").glob("*.json"))
    state_reference_fingerprints: dict[str, str] = {}
    state_valid_observations = 0
    state_invalid_observations = 0
    state_deterministic_rebuild = True

    for path in state_valid_files:
        try:
            first = encode_semantic_state_file(path)
            second = encode_semantic_state_file(path)
        except Exception as exc:
            failures.append(f"state_valid:{path.name}:{exc}")
            state_deterministic_rebuild = False
            continue
        if first != second:
            failures.append(f"state_nondeterministic:{path.name}")
            state_deterministic_rebuild = False
        if not validate_object(first).valid:
            failures.append(f"state_invalid_output:{path.name}")
            continue
        state_valid_observations += 1
        state_reference_fingerprints[path.name] = first["fingerprint"]

    for path in state_invalid_files:
        try:
            encode_semantic_state_file(path)
        except ObservationError:
            state_invalid_observations += 1
        except Exception as exc:
            failures.append(f"state_invalid_unexpected:{path.name}:{exc}")
        else:
            failures.append(f"state_invalid_accepted:{path.name}")

    if state_valid_observations != len(state_valid_files):
        failures.append("state_valid_observation_count")
    if state_invalid_observations != len(state_invalid_files):
        failures.append("state_invalid_observation_count")

    manifest_path = root / "MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    if not manifest:
        failures.append("missing_manifest")
    if manifest.get("release") != "ACR-MVP-v0.1-Phase2":
        failures.append("manifest_release")
    if manifest.get("version") != "0.1.2":
        failures.append("manifest_version")
    if manifest.get("schema_count") != 10:
        failures.append("manifest_schema_count")
    if manifest.get("theory_doc_count") != 6:
        failures.append("manifest_theory_doc_count")
    schema_hashes = manifest.get("schema_sha256", {})
    if schema_hashes != PHASE0_SCHEMA_HASHES:
        failures.append("manifest_phase0_schema_hashes")
    sprc_manifest = manifest.get("sprc", {})
    if sprc_manifest.get("object_count") != 64:
        failures.append("manifest_sprc_count")
    if sprc_manifest.get("registry_fingerprint") != PHASE1_REGISTRY_FINGERPRINT:
        failures.append("manifest_sprc_fingerprint")
    state_manifest = manifest.get("state_encoder", {})
    if state_manifest.get("profile") != ENCODER_PROFILE:
        failures.append("manifest_state_profile")
    if state_manifest.get("valid_observation_count") != len(state_valid_files):
        failures.append("manifest_state_valid_count")
    if state_manifest.get("invalid_observation_count") != len(state_invalid_files):
        failures.append("manifest_state_invalid_count")
    if state_manifest.get("reference_state_fingerprints") != state_reference_fingerprints:
        failures.append("manifest_state_fingerprints")

    checksum_failures = 0
    if not args.compatibility_only:
        checksums = root / "CHECKSUMS.sha256"
        if not checksums.exists():
            failures.append("missing_checksums")
            checksum_failures += 1
        else:
            for lineno, line in enumerate(checksums.read_text(encoding="utf-8").splitlines(), start=1):
                if not line.strip():
                    continue
                try:
                    expected, rel = line.split("  ", 1)
                except ValueError:
                    failures.append(f"bad_checksum_line:{lineno}")
                    checksum_failures += 1
                    continue
                path = root / rel
                if not path.exists() or digest(path) != expected:
                    failures.append(f"checksum:{rel}")
                    checksum_failures += 1

    payload = {
        "compatibility_only": args.compatibility_only,
        "ok": not failures,
        "schema_count": len(SCHEMA_SPECS),
        "valid_fixtures": valid_ok,
        "invalid_fixtures": invalid_ok,
        "sprc_source_verified": sprc_source_verified,
        "sprc_object_count": sprc_object_count,
        "sprc_registry_matches_builder": sprc_registry_matches_builder,
        "state_encoder_profile": ENCODER_PROFILE,
        "state_valid_observations": state_valid_observations,
        "state_invalid_observations": state_invalid_observations,
        "state_deterministic_rebuild": state_deterministic_rebuild,
        "state_reference_fingerprints": state_reference_fingerprints,
        "checksum_failures": checksum_failures,
        "failures": failures,
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
