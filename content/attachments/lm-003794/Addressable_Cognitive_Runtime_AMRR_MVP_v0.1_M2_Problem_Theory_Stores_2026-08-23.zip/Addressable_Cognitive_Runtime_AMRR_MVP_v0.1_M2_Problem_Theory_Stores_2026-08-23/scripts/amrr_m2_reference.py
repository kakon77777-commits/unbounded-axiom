from __future__ import annotations

from pathlib import Path
from typing import Any

from addressable_cognitive_runtime.math import AssumptionEnvelopeStore, ProblemStore, TheoryStore


def _fingerprints(records: tuple[dict[str, Any], ...]) -> dict[str, str]:
    return {
        f"{record['id']}#v{record['version']}": record["fingerprint"]
        for record in records
    }


def build_reference_snapshot(root: Path) -> dict[str, Any]:
    ae = AssumptionEnvelopeStore(root)
    problems = ProblemStore(root)
    theories = TheoryStore(root)

    ae.create(
        envelope_id="assumption-envelope:ae1",
        subject_ref="problem:p1",
        direct_assumption_refs=["assumption:a0"],
    )
    ae.derive(
        "assumption-envelope:ae1",
        updates={"inherited_assumption_refs": ["assumption:a-base"], "closed": True},
    )

    problems.create(
        problem_id="problem:p1",
        canonical_statement_ref="artifact:q1",
        assumption_envelope_ref="assumption-envelope:ae1",
        domain_refs=["number_theory"],
        success_criteria=["formal_proof_or_counterexample"],
    )
    problems.derive(
        "problem:p1",
        relation_to_parent="clarification",
        updates={"canonical_statement_ref": "artifact:q1-clarified"},
    )
    problems.branch(
        "problem:p1",
        new_problem_id="problem:p1-restricted",
        relation_to_parent="restriction",
        updates={"canonical_statement_ref": "artifact:q1-restricted"},
    )

    theories.create(theory_id="theory:t1", axiom_refs=["axiom:a0"])
    theories.branch(
        "theory:t1",
        new_theory_id="theory:t2",
        updates={"axiom_refs": ["axiom:a0", "axiom:a1"]},
    )

    return {
        "problem_graph": problems.graph(),
        "theory_graph": theories.graph(),
        "assumption_envelope_graph": ae.graph(),
        "problem_fingerprints": _fingerprints(problems.records()),
        "theory_fingerprints": _fingerprints(theories.records()),
        "assumption_envelope_fingerprints": _fingerprints(ae.records()),
        "counts": {
            "problem_versions": len(problems.records()),
            "theory_versions": len(theories.records()),
            "assumption_envelope_versions": len(ae.records()),
        },
    }
