from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from pathlib import Path

from amrr_m2_reference import build_reference_snapshot

M1_MANIFEST_SHA256 = "ce3681c8e680f1d2bf737d4d431161d8b781ef40a60701c5cf8a83b599e57f05"
M1_CHECKSUMS_SHA256 = "572a63a448b3e15fe0e62b531e77ef0b9a3f2b96718ac40b15da621c828911e8"
EXCLUDED_FILES = {"AMRR_M2_CHECKSUMS.sha256"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name in EXCLUDED_FILES:
            continue
        rel = path.relative_to(root)
        if any(part in {".git", ".pytest_cache", "__pycache__", ".worktrees"} for part in rel.parts):
            continue
        if any(part.endswith(".egg-info") for part in rel.parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source
    from addressable_cognitive_runtime.math import VERSIONED_MATH_STORE_PROFILE
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state import encode_semantic_state_file

    m1 = json.loads((root / "AMRR_M1_MANIFEST.json").read_text(encoding="utf-8"))
    if digest(root / "AMRR_M1_MANIFEST.json") != M1_MANIFEST_SHA256:
        raise SystemExit("AMRR_M1_MANIFEST.json anchor drift")
    if digest(root / "AMRR_M1_CHECKSUMS.sha256") != M1_CHECKSUMS_SHA256:
        raise SystemExit("AMRR_M1_CHECKSUMS.sha256 anchor drift")

    with tempfile.TemporaryDirectory() as td:
        demo = build_reference_snapshot(Path(td))
    demo_path = root / "examples" / "math-store" / "m2-demo.json"
    demo_path.parent.mkdir(parents=True, exist_ok=True)
    demo_path.write_text(json.dumps(demo, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    valid_root = root / "examples" / "math-state-observations" / "valid"
    current_state_fps = {}
    current_math_fps = {}
    for path in sorted(valid_root.glob("*.json")):
        state = encode_semantic_state_file(path)
        current_state_fps[path.name] = state["fingerprint"]
        current_math_fps[path.name] = state["extensions"]["math"]["fingerprint"]

    registry = build_sprc_registry(load_sprc_source())
    manifest = {
        "release": "ACR-AMRR-MVP-v0.1-M2",
        "version": "0.1.2",
        "phase": "AMRR M2 - Problem / Theory Stores",
        "base_amrr_release": m1["release"],
        "base_amrr_version": m1["version"],
        "m1_manifest_sha256": M1_MANIFEST_SHA256,
        "m1_checksums_sha256": M1_CHECKSUMS_SHA256,
        "phase0_schema_count": len(SCHEMA_SPECS),
        "phase0_schema_sha256": {name: digest(schema_path(name)) for name in SCHEMA_SPECS},
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_schema_sha256": {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS},
        "phase1_registry_fingerprint": registry["fingerprint"],
        "phase1_registry_object_count": registry["object_count"],
        "m1_reference_state_fingerprints": current_state_fps,
        "m1_reference_math_fingerprints": current_math_fps,
        "store_profile": VERSIONED_MATH_STORE_PROFILE,
        "reference_demo": demo,
        "store_policy": {
            "identity": "(id, version)",
            "write": "append-only immutable; identical replay idempotent",
            "conflict": "same id/version with different canonical content rejected",
            "exact_lineage": "extensions.amrr_m2_store.parent_versions",
            "same_id_derivation": "latest version only",
            "branching": "new id starts at version 1 and records exact parent version",
        },
        "implementation_boundary": {
            "implemented": [
                "ACR Phase 0 canonical schemas",
                "ACR Phase 1 SPRC/CIO adapter",
                "ACR Phase 2 Semantic State Encoder",
                "AMRR M0 canonical mathematical schemas",
                "AMRR M1 deterministic Mathematical State Adapter",
                "AMRR M2 Problem / Theory / AssumptionEnvelope Stores",
            ],
            "not_implemented": ["AMRR M3-M11 runtime capabilities"],
        },
    }
    (root / "AMRR_M2_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    lines = [f"{digest(path)}  {path.relative_to(root).as_posix()}" for path in payload_files(root)]
    (root / "AMRR_M2_CHECKSUMS.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"release": manifest["release"], **demo["counts"], "checksum_files": len(lines)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
