from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

M0_MANIFEST_SHA256 = "eb8461cc9b0f9ee78315a55657e7a1adcccbe70e8417226c407b8113010ac081"
M0_CHECKSUMS_SHA256 = "01e1633b6b9ef13ca012c1868c3cd28610ba211dbd1b31602f3c315836b9af34"
EXPECTED_INVALID = {
    "unknown-math-field.json": "unknown_math_observation_field",
    "bad-active-problem.json": "active_problem_not_listed",
    "bad-problem-ref.json": "invalid_math_reference",
    "bad-novelty-state.json": "invalid_novelty_state",
    "bad-research-phase.json": "invalid_research_phase",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source
    from addressable_cognitive_runtime.canonical import canonical_bytes
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state import (
        MATH_ADAPTER_PROFILE,
        ObservationError,
        encode_semantic_state_file,
    )
    from addressable_cognitive_runtime.validation import validate_object

    failures: list[str] = []
    m0_anchor_failures = 0

    if digest(root / "AMRR_M0_MANIFEST.json") != M0_MANIFEST_SHA256:
        failures.append("m0_manifest_anchor_drift")
        m0_anchor_failures += 1
    if digest(root / "AMRR_M0_CHECKSUMS.sha256") != M0_CHECKSUMS_SHA256:
        failures.append("m0_checksums_anchor_drift")
        m0_anchor_failures += 1

    base_manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    m0_manifest = json.loads((root / "AMRR_M0_MANIFEST.json").read_text(encoding="utf-8"))

    if len(SCHEMA_SPECS) != 10:
        failures.append(f"phase0_schema_count:{len(SCHEMA_SPECS)}")
    expected_phase0 = m0_manifest.get("phase0_schema_sha256", {})
    actual_phase0 = {name: digest(schema_path(name)) for name in SCHEMA_SPECS}
    if actual_phase0 != expected_phase0:
        failures.append("phase0_schema_drift")

    if len(MATH_SCHEMA_SPECS) != 19:
        failures.append(f"math_schema_count:{len(MATH_SCHEMA_SPECS)}")
    expected_math = m0_manifest.get("math_schema_sha256", {})
    actual_math = {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS}
    if actual_math != expected_math:
        failures.append("math_schema_drift")

    try:
        registry = build_sprc_registry(load_sprc_source())
        if registry.get("fingerprint") != m0_manifest.get("phase1_registry_fingerprint"):
            failures.append("phase1_registry_drift")
        if registry.get("object_count") != 64:
            failures.append("phase1_registry_count")
    except Exception as exc:
        failures.append(f"phase1_registry:{exc}")

    if MATH_ADAPTER_PROFILE != "amrr.math-state-adapter/v0.1":
        failures.append("math_adapter_profile")

    # Phase-2 no-math observations must remain byte/fingerprint compatible.
    phase2_refs = base_manifest.get("state_encoder", {}).get("reference_state_fingerprints", {})
    for name, expected_fp in sorted(phase2_refs.items()):
        path = root / "examples" / "state-observations" / "valid" / name
        try:
            state = encode_semantic_state_file(path)
        except Exception as exc:
            failures.append(f"phase2_compat:{name}:{exc}")
            continue
        if state.get("fingerprint") != expected_fp:
            failures.append(f"phase2_fingerprint_drift:{name}")
        if set(state.get("extensions", {})) != {"state_encoder"}:
            failures.append(f"phase2_extension_drift:{name}")

    valid_root = root / "examples" / "math-state-observations" / "valid"
    invalid_root = root / "examples" / "math-state-observations" / "invalid"
    valid_paths = sorted(valid_root.glob("*.json"))
    invalid_paths = sorted(invalid_root.glob("*.json"))
    math_state_valid = 0
    math_state_invalid = 0
    state_fps: dict[str, str] = {}
    math_fps: dict[str, str] = {}

    for path in valid_paths:
        try:
            first = encode_semantic_state_file(path)
            second = encode_semantic_state_file(path)
        except Exception as exc:
            failures.append(f"math_state_valid:{path.name}:{exc}")
            continue
        if first != second or canonical_bytes(first) != canonical_bytes(second):
            failures.append(f"math_state_nondeterministic:{path.name}")
            continue
        math_state = first.get("extensions", {}).get("math")
        if not isinstance(math_state, dict):
            failures.append(f"math_state_missing:{path.name}")
            continue
        if not validate_object(first).valid or not validate_object(math_state).valid:
            failures.append(f"math_state_validation:{path.name}")
            continue
        state_fps[path.name] = first["fingerprint"]
        math_fps[path.name] = math_state["fingerprint"]
        math_state_valid += 1

    if {p.name for p in invalid_paths} != set(EXPECTED_INVALID):
        failures.append("math_invalid_fixture_set")
    for path in invalid_paths:
        try:
            encode_semantic_state_file(path)
        except ObservationError as exc:
            expected_code = EXPECTED_INVALID.get(path.name)
            if exc.code != expected_code:
                failures.append(f"math_invalid_code:{path.name}:{exc.code}")
            else:
                math_state_invalid += 1
        except Exception as exc:
            failures.append(f"math_invalid_unexpected:{path.name}:{exc}")
        else:
            failures.append(f"math_invalid_accepted:{path.name}")

    try:
        a = encode_semantic_state_file(valid_root / "equivalent-order-a.json")
        b = encode_semantic_state_file(valid_root / "equivalent-order-b.json")
        if a != b or canonical_bytes(a) != canonical_bytes(b):
            failures.append("equivalent_math_observations_diverge")
    except Exception as exc:
        failures.append(f"equivalent_math_observations:{exc}")

    manifest_path = root / "AMRR_M1_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    if not manifest:
        failures.append("missing_amrr_m1_manifest")
    else:
        checks = {
            "release": "ACR-AMRR-MVP-v0.1-M1",
            "version": "0.1.1",
            "phase": "AMRR M1 - Mathematical State Adapter",
            "base_amrr_release": "ACR-AMRR-MVP-v0.1-M0",
            "math_state_adapter_profile": MATH_ADAPTER_PROFILE,
            "math_state_valid_observation_count": len(valid_paths),
            "math_state_invalid_observation_count": len(invalid_paths),
            "m0_manifest_sha256": M0_MANIFEST_SHA256,
            "m0_checksums_sha256": M0_CHECKSUMS_SHA256,
        }
        for key, expected in checks.items():
            if manifest.get(key) != expected:
                failures.append(f"manifest_{key}")
        if manifest.get("phase0_schema_sha256") != actual_phase0:
            failures.append("manifest_phase0_hashes")
        if manifest.get("math_schema_sha256") != actual_math:
            failures.append("manifest_math_hashes")
        if manifest.get("reference_state_fingerprints") != state_fps:
            failures.append("manifest_state_fingerprints")
        if manifest.get("reference_math_fingerprints") != math_fps:
            failures.append("manifest_math_fingerprints")

    checksum_failures = 0
    checksum_path = root / "AMRR_M1_CHECKSUMS.sha256"
    if not checksum_path.exists():
        failures.append("missing_amrr_m1_checksums")
        checksum_failures += 1
    else:
        for lineno, line in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                expected, rel = line.split("  ", 1)
            except ValueError:
                failures.append(f"bad_m1_checksum_line:{lineno}")
                checksum_failures += 1
                continue
            path = root / rel
            if not path.exists() or digest(path) != expected:
                failures.append(f"m1_checksum:{rel}")
                checksum_failures += 1

    payload = {
        "ok": not failures,
        "phase0_schema_count": len(SCHEMA_SPECS),
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_state_adapter_profile": MATH_ADAPTER_PROFILE,
        "math_state_valid_observations": math_state_valid,
        "math_state_invalid_observations": math_state_invalid,
        "m0_anchor_failures": m0_anchor_failures,
        "checksum_failures": checksum_failures,
        "failures": failures,
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
