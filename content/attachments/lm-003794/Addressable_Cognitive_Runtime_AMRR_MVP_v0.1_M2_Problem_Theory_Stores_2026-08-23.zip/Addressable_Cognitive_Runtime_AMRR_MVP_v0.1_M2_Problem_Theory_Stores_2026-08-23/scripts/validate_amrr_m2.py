from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from pathlib import Path

from amrr_m2_reference import build_reference_snapshot

M1_MANIFEST_SHA256 = "ce3681c8e680f1d2bf737d4d431161d8b781ef40a60701c5cf8a83b599e57f05"
M1_CHECKSUMS_SHA256 = "572a63a448b3e15fe0e62b531e77ef0b9a3f2b96718ac40b15da621c828911e8"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source
    from addressable_cognitive_runtime.math import MathStoreError, ProblemStore, VERSIONED_MATH_STORE_PROFILE, finalize_record
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state import encode_semantic_state_file

    failures: list[str] = []
    m1_anchor_failures = 0
    if digest(root / "AMRR_M1_MANIFEST.json") != M1_MANIFEST_SHA256:
        failures.append("m1_manifest_anchor_drift")
        m1_anchor_failures += 1
    if digest(root / "AMRR_M1_CHECKSUMS.sha256") != M1_CHECKSUMS_SHA256:
        failures.append("m1_checksums_anchor_drift")
        m1_anchor_failures += 1

    m1 = json.loads((root / "AMRR_M1_MANIFEST.json").read_text(encoding="utf-8"))
    actual_phase0 = {name: digest(schema_path(name)) for name in SCHEMA_SPECS}
    actual_math = {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS}
    if actual_phase0 != m1.get("phase0_schema_sha256"):
        failures.append("phase0_schema_drift")
    if actual_math != m1.get("math_schema_sha256"):
        failures.append("math_schema_drift")

    registry = build_sprc_registry(load_sprc_source())
    if registry.get("fingerprint") != m1.get("phase1_registry_fingerprint") or registry.get("object_count") != 64:
        failures.append("phase1_registry_drift")

    current_state_fps = {}
    current_math_fps = {}
    for path in sorted((root / "examples" / "math-state-observations" / "valid").glob("*.json")):
        state = encode_semantic_state_file(path)
        current_state_fps[path.name] = state["fingerprint"]
        current_math_fps[path.name] = state["extensions"]["math"]["fingerprint"]
    if current_state_fps != m1.get("reference_state_fingerprints"):
        failures.append("m1_state_fingerprint_drift")
    if current_math_fps != m1.get("reference_math_fingerprints"):
        failures.append("m1_math_fingerprint_drift")

    with tempfile.TemporaryDirectory() as td:
        demo = build_reference_snapshot(Path(td))
        # Explicitly verify no-silent-overwrite behavior in the release gate.
        ps = ProblemStore(Path(td) / "conflict-check")
        first = ps.create(
            problem_id="problem:conflict",
            canonical_statement_ref="artifact:a",
            assumption_envelope_ref="assumption-envelope:ae",
        )
        bad = dict(first)
        bad["canonical_statement_ref"] = "artifact:b"
        bad = finalize_record(bad, schema_name="problem-record")
        try:
            ps.put(bad)
        except MathStoreError as exc:
            if exc.code != "silent_overwrite":
                failures.append(f"unexpected_overwrite_error:{exc.code}")
        else:
            failures.append("silent_overwrite_accepted")

    demo_path = root / "examples" / "math-store" / "m2-demo.json"
    expected_demo = json.loads(demo_path.read_text(encoding="utf-8")) if demo_path.exists() else None
    if expected_demo != demo:
        failures.append("reference_demo_drift")

    manifest_path = root / "AMRR_M2_MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8")) if manifest_path.exists() else {}
    if not manifest:
        failures.append("missing_amrr_m2_manifest")
    else:
        for key, expected in {
            "release": "ACR-AMRR-MVP-v0.1-M2",
            "version": "0.1.2",
            "phase": "AMRR M2 - Problem / Theory Stores",
            "base_amrr_release": "ACR-AMRR-MVP-v0.1-M1",
            "m1_manifest_sha256": M1_MANIFEST_SHA256,
            "m1_checksums_sha256": M1_CHECKSUMS_SHA256,
            "store_profile": VERSIONED_MATH_STORE_PROFILE,
        }.items():
            if manifest.get(key) != expected:
                failures.append(f"manifest_{key}")
        if manifest.get("reference_demo") != demo:
            failures.append("manifest_reference_demo")
        if manifest.get("phase0_schema_sha256") != actual_phase0:
            failures.append("manifest_phase0_hashes")
        if manifest.get("math_schema_sha256") != actual_math:
            failures.append("manifest_math_hashes")
        if manifest.get("m1_reference_state_fingerprints") != current_state_fps:
            failures.append("manifest_state_fingerprints")
        if manifest.get("m1_reference_math_fingerprints") != current_math_fps:
            failures.append("manifest_math_fingerprints")

    checksum_failures = 0
    checksums = root / "AMRR_M2_CHECKSUMS.sha256"
    if not checksums.exists():
        failures.append("missing_amrr_m2_checksums")
        checksum_failures += 1
    else:
        for lineno, line in enumerate(checksums.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                expected, rel = line.split("  ", 1)
            except ValueError:
                failures.append(f"bad_m2_checksum_line:{lineno}")
                checksum_failures += 1
                continue
            path = root / rel
            if not path.exists() or digest(path) != expected:
                failures.append(f"m2_checksum:{rel}")
                checksum_failures += 1

    counts = demo["counts"]
    payload = {
        "ok": not failures,
        "store_profile": VERSIONED_MATH_STORE_PROFILE,
        "problem_versions": counts["problem_versions"],
        "theory_versions": counts["theory_versions"],
        "assumption_envelope_versions": counts["assumption_envelope_versions"],
        "m1_anchor_failures": m1_anchor_failures,
        "checksum_failures": checksum_failures,
        "failures": failures,
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
