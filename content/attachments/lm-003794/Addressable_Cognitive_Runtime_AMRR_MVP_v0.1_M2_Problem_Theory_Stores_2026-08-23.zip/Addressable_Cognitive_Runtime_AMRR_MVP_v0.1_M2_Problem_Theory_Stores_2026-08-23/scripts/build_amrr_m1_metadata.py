from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

M0_MANIFEST_SHA256 = "eb8461cc9b0f9ee78315a55657e7a1adcccbe70e8417226c407b8113010ac081"
M0_CHECKSUMS_SHA256 = "01e1633b6b9ef13ca012c1868c3cd28610ba211dbd1b31602f3c315836b9af34"
EXCLUDED_FILES = {"AMRR_M1_CHECKSUMS.sha256"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def payload_files(root: Path):
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if path.name in EXCLUDED_FILES:
            continue
        parts = rel.parts
        if ".git" in parts or ".pytest_cache" in parts or "__pycache__" in parts or ".worktrees" in parts:
            continue
        if any(part.endswith(".egg-info") for part in parts):
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        yield path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()

    from addressable_cognitive_runtime.adapters.sprc import build_sprc_registry, load_sprc_source
    from addressable_cognitive_runtime.schema_catalog import MATH_SCHEMA_SPECS, SCHEMA_SPECS, schema_path
    from addressable_cognitive_runtime.state import MATH_ADAPTER_PROFILE, encode_semantic_state_file

    base_manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    m0_manifest = json.loads((root / "AMRR_M0_MANIFEST.json").read_text(encoding="utf-8"))
    registry = build_sprc_registry(load_sprc_source())

    valid_root = root / "examples" / "math-state-observations" / "valid"
    invalid_root = root / "examples" / "math-state-observations" / "invalid"
    valid_files = sorted(valid_root.glob("*.json"))
    invalid_files = sorted(invalid_root.glob("*.json"))

    state_fingerprints: dict[str, str] = {}
    math_fingerprints: dict[str, str] = {}
    state_ids: dict[str, str] = {}
    math_ids: dict[str, str] = {}
    for path in valid_files:
        state = encode_semantic_state_file(path)
        math_state = state["extensions"]["math"]
        state_fingerprints[path.name] = state["fingerprint"]
        math_fingerprints[path.name] = math_state["fingerprint"]
        state_ids[path.name] = state["id"]
        math_ids[path.name] = math_state["id"]

    manifest = {
        "release": "ACR-AMRR-MVP-v0.1-M1",
        "version": "0.1.1",
        "phase": "AMRR M1 - Mathematical State Adapter",
        "base_acr_release": base_manifest.get("release"),
        "base_acr_version": base_manifest.get("version"),
        "base_amrr_release": m0_manifest.get("release"),
        "base_amrr_version": m0_manifest.get("version"),
        "m0_manifest_sha256": digest(root / "AMRR_M0_MANIFEST.json"),
        "m0_checksums_sha256": digest(root / "AMRR_M0_CHECKSUMS.sha256"),
        "expected_m0_manifest_sha256": M0_MANIFEST_SHA256,
        "expected_m0_checksums_sha256": M0_CHECKSUMS_SHA256,
        "phase0_schema_count": len(SCHEMA_SPECS),
        "phase0_schema_sha256": {name: digest(schema_path(name)) for name in SCHEMA_SPECS},
        "math_schema_count": len(MATH_SCHEMA_SPECS),
        "math_schema_sha256": {name: digest(schema_path(name)) for name in MATH_SCHEMA_SPECS},
        "phase1_registry_fingerprint": registry["fingerprint"],
        "phase1_registry_object_count": registry["object_count"],
        "phase2_state_encoder_profile": base_manifest.get("state_encoder", {}).get("profile"),
        "phase2_reference_state_fingerprints": base_manifest.get("state_encoder", {}).get(
            "reference_state_fingerprints", {}
        ),
        "math_state_adapter_profile": MATH_ADAPTER_PROFILE,
        "math_state_valid_observation_count": len(valid_files),
        "math_state_invalid_observation_count": len(invalid_files),
        "reference_state_ids": state_ids,
        "reference_state_fingerprints": state_fingerprints,
        "reference_math_ids": math_ids,
        "reference_math_fingerprints": math_fingerprints,
        "identity_policy": {
            "no_math_observation": "preserve Phase-2 semantic-state identity algorithm",
            "explicit_math_observation": "include canonical mathematical state extension in SemanticState identity and fingerprint",
            "non_math_input_extensions": "ignored by canonical SemanticState output",
        },
        "implementation_boundary": {
            "implemented": [
                "ACR Phase 0 canonical schemas",
                "ACR Phase 1 SPRC/CIO adapter",
                "ACR Phase 2 Semantic State Encoder",
                "AMRR M0 canonical mathematical schemas",
                "AMRR M1 deterministic Mathematical State Adapter",
            ],
            "not_implemented": ["AMRR M2-M11 runtime capabilities"],
        },
    }
    (root / "AMRR_M1_MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    lines = []
    for path in payload_files(root):
        rel = path.relative_to(root).as_posix()
        lines.append(f"{digest(path)}  {rel}")
    (root / "AMRR_M1_CHECKSUMS.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "release": manifest["release"],
        "valid_math_observations": len(valid_files),
        "invalid_math_observations": len(invalid_files),
        "checksum_files": len(lines),
        "math_state_adapter_profile": MATH_ADAPTER_PROFILE,
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
