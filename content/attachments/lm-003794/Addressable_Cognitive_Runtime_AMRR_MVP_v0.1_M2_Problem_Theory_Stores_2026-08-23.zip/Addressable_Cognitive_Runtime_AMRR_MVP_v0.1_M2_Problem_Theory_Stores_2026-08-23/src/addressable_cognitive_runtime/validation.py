from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from functools import lru_cache
from typing import Any, Mapping

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from .canonical import fingerprint_object
from .schema_catalog import ALL_SCHEMA_SPECS, SCHEMA_SPECS, schema_name_for_token, schema_path, schema_root


@dataclass(frozen=True)
class ValidationIssue:
    code: str
    message: str
    path: tuple[Any, ...] = ()


@dataclass(frozen=True)
class ValidationResult:
    schema_name: str | None
    issues: tuple[ValidationIssue, ...]

    @property
    def valid(self) -> bool:
        return not self.issues


@lru_cache(maxsize=1)
def _common_schema() -> dict[str, Any]:
    return json.loads((schema_root() / "common.schema.json").read_text(encoding="utf-8"))


@lru_cache(maxsize=16)
def _schema(name: str) -> dict[str, Any]:
    return json.loads(schema_path(name).read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def _registry() -> Registry:
    common = _common_schema()
    math_common = json.loads((schema_root() / "math" / "common.schema.json").read_text(encoding="utf-8"))
    return (
        Registry()
        .with_resource(common["$id"], Resource.from_contents(common))
        .with_resource(math_common["$id"], Resource.from_contents(math_common))
    )


def _schema_issues(obj: Mapping[str, Any], name: str) -> list[ValidationIssue]:
    validator = Draft202012Validator(
        _schema(name),
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    issues: list[ValidationIssue] = []
    for error in sorted(validator.iter_errors(obj), key=lambda e: (list(e.absolute_path), e.message)):
        issues.append(
            ValidationIssue(
                code="schema_violation",
                message=error.message,
                path=tuple(error.absolute_path),
            )
        )
    return issues


def _duplicate_ref_issues(value: Any, path: tuple[Any, ...] = ()) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    if isinstance(value, Mapping):
        for key, item in value.items():
            child_path = path + (key,)
            if isinstance(item, list) and (key.endswith("_refs") or key == "causal_parent_ids"):
                normalized = [x for x in item if isinstance(x, str)]
                if len(normalized) != len(set(normalized)):
                    issues.append(
                        ValidationIssue(
                            code="duplicate_reference",
                            message=f"{key} contains duplicate references",
                            path=child_path,
                        )
                    )
            issues.extend(_duplicate_ref_issues(item, child_path))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            issues.extend(_duplicate_ref_issues(item, path + (index,)))
    return issues


def _semantic_issues(obj: Mapping[str, Any], name: str) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []

    expected_fp = fingerprint_object(obj)
    actual_fp = obj.get("fingerprint")
    if actual_fp != expected_fp:
        issues.append(
            ValidationIssue(
                code="fingerprint_mismatch",
                message=f"fingerprint does not match canonical object; expected {expected_fp}",
                path=("fingerprint",),
            )
        )

    issues.extend(_duplicate_ref_issues(obj))

    if name == "cognitive-object":
        address = obj.get("id")
        version = obj.get("version")
        if isinstance(address, str) and isinstance(version, int):
            match = re.search(r"@([1-9][0-9]*)$", address)
            if match and int(match.group(1)) != version:
                issues.append(
                    ValidationIssue(
                        code="cognitive_version_mismatch",
                        message=f"cognitive address version @{match.group(1)} does not match object version {version}",
                        path=("id",),
                    )
                )

    elif name == "governance-decision":
        decision = obj.get("decision")
        authority = obj.get("authority")
        authority_class = authority.get("class") if isinstance(authority, Mapping) else None
        if decision == "EXECUTE" and authority_class != "ALLOW":
            issues.append(
                ValidationIssue(
                    code="execute_without_allow",
                    message="EXECUTE requires authority.class == ALLOW",
                    path=("authority", "class"),
                )
            )

    elif name == "decision-receipt":
        selected = obj.get("selected_action")
        candidates = obj.get("candidate_actions")
        if isinstance(candidates, list) and selected is not None and selected not in candidates:
            issues.append(
                ValidationIssue(
                    code="selected_action_not_candidate",
                    message="selected_action must be present in candidate_actions",
                    path=("selected_action",),
                )
            )

    elif name == "cognitive-program":
        steps = obj.get("steps")
        budget = obj.get("budget")
        max_steps = budget.get("max_steps") if isinstance(budget, Mapping) else None
        if isinstance(steps, list) and isinstance(max_steps, int) and len(steps) > max_steps:
            issues.append(
                ValidationIssue(
                    code="program_exceeds_max_steps",
                    message=f"program has {len(steps)} steps but max_steps is {max_steps}",
                    path=("steps",),
                )
            )

    elif name == "contract":
        start = obj.get("valid_from")
        end = obj.get("valid_until")
        if isinstance(start, str) and isinstance(end, str):
            try:
                start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
                end_dt = datetime.fromisoformat(end.replace("Z", "+00:00"))
            except ValueError:
                pass
            else:
                if end_dt < start_dt:
                    issues.append(
                        ValidationIssue(
                            code="contract_time_reversed",
                            message="valid_until cannot be before valid_from",
                            path=("valid_until",),
                        )
                    )

    elif name == "context-compression-event":
        before = obj.get("before_context_ref")
        after = obj.get("after_context_ref")
        if before is not None and before == after:
            issues.append(
                ValidationIssue(
                    code="compression_no_state_change",
                    message="before_context_ref and after_context_ref must differ",
                    path=("after_context_ref",),
                )
            )

    return issues


def validate_object(obj: Mapping[str, Any], schema_name: str | None = None) -> ValidationResult:
    if not isinstance(obj, Mapping):
        return ValidationResult(None, (ValidationIssue("not_object", "value must be a JSON object"),))

    selected = schema_name
    if selected is None:
        token = obj.get("schema")
        if not isinstance(token, str):
            return ValidationResult(None, (ValidationIssue("missing_schema", "schema token is required", ("schema",)),))
        selected = schema_name_for_token(token)
        if selected is None:
            return ValidationResult(None, (ValidationIssue("unknown_schema", f"unknown schema token: {token}", ("schema",)),))
    elif selected not in ALL_SCHEMA_SPECS:
        return ValidationResult(None, (ValidationIssue("unknown_schema", f"unknown schema name: {selected}"),))

    issues = _schema_issues(obj, selected)
    issues.extend(_semantic_issues(obj, selected))
    return ValidationResult(selected, tuple(issues))
