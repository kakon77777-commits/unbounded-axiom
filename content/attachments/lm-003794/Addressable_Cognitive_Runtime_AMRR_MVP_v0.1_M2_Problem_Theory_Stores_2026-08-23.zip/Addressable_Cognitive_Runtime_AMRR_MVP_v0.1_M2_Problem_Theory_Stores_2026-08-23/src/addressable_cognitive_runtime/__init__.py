"""Addressable Cognitive Runtime (ACR) Phase 2 Semantic State Encoder package."""

__version__ = "0.1.2"
