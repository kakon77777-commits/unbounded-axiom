from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from .canonical import fingerprint_object
from .schema_catalog import SCHEMA_SPECS
from .validation import ValidationIssue, validate_object


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _issue_payload(issue: ValidationIssue) -> dict[str, Any]:
    return {"code": issue.code, "message": issue.message, "path": list(issue.path)}


def _print_json(payload: Any) -> None:
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True))


def _cmd_list(_: argparse.Namespace) -> int:
    for name, spec in SCHEMA_SPECS.items():
        print(f"{name}\t{spec.token}\t{spec.filename}")
    return 0


def _cmd_fingerprint(args: argparse.Namespace) -> int:
    try:
        obj = _read_json(Path(args.file))
        if not isinstance(obj, dict):
            raise ValueError("JSON root must be an object")
        print(fingerprint_object(obj))
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        _print_json({"valid": False, "error": str(exc)})
        return 2


def _validate_file(path: Path, schema_name: str | None = None) -> tuple[int, dict[str, Any]]:
    try:
        obj = _read_json(path)
    except (OSError, json.JSONDecodeError) as exc:
        return 2, {"file": str(path), "valid": False, "issues": [{"code": "invalid_json", "message": str(exc), "path": []}]}
    result = validate_object(obj, schema_name=schema_name)
    payload = {
        "file": str(path),
        "schema_name": result.schema_name,
        "valid": result.valid,
        "issues": [_issue_payload(issue) for issue in result.issues],
    }
    return (0 if result.valid else 1), payload


def _cmd_validate(args: argparse.Namespace) -> int:
    code, payload = _validate_file(Path(args.file), schema_name=args.schema)
    _print_json(payload)
    return code


def _cmd_validate_fixtures(args: argparse.Namespace) -> int:
    root = Path(args.directory)
    files = sorted(root.rglob("*.json")) if root.exists() else []
    valid = 0
    invalid = 0
    for path in files:
        code, _ = _validate_file(path)
        if code == 0:
            valid += 1
        else:
            invalid += 1
    _print_json({"files": len(files), "invalid": invalid, "valid": valid})
    return 0 if invalid == 0 else 1



def _cmd_sprc_info(_: argparse.Namespace) -> int:
    from .adapters.sprc import load_sprc_source, renderer_compatibility, verify_sprc_source

    source = load_sprc_source()
    verified = verify_sprc_source(source)
    _print_json({
        "source_package": source.profile["source_package"],
        "semantic_compatibility": source.profile["semantic_compatibility"],
        "operator_deck": source.profile["operator_deck"],
        "deck_hash": verified.deck_hash,
        "wire_registry": source.profile["wire_registry"],
        "registry_hash": verified.registry_hash,
        "runtime": source.profile["runtime"],
        "corpus_release": source.profile["corpus_release"],
        "operator_count": verified.operator_count,
        "renderer_tokens": renderer_compatibility(source),
    })
    return 0


def _cmd_sprc_list(_: argparse.Namespace) -> int:
    from .adapters.sprc import build_cognitive_objects

    objects = build_cognitive_objects()
    _print_json([
        {
            "address": obj["id"],
            "name": obj["name"],
            "source_id": obj["extensions"]["sprc"]["source_operator_id"],
        }
        for obj in objects
    ])
    return 0


def _cmd_sprc_resolve(args: argparse.Namespace) -> int:
    from .adapters.sprc import resolve_sprc_cognitive_object

    try:
        _print_json(resolve_sprc_cognitive_object(args.identifier))
        return 0
    except ValueError as exc:
        _print_json({"valid": False, "error": str(exc)})
        return 2


def _cmd_sprc_export(args: argparse.Namespace) -> int:
    from .adapters.sprc import export_sprc_registry

    target = Path(args.output)
    try:
        registry = export_sprc_registry(target)
    except (OSError, ValueError) as exc:
        _print_json({"valid": False, "error": str(exc)})
        return 2
    _print_json({
        "file": str(target),
        "registry_id": registry["registry_id"],
        "object_count": registry["object_count"],
        "fingerprint": registry["fingerprint"],
    })
    return 0


def _cmd_state_encode(args: argparse.Namespace) -> int:
    from .state.encoder import ObservationError, encode_semantic_state_file

    try:
        state = encode_semantic_state_file(args.observation)
        if args.output:
            target = Path(args.output)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(
                json.dumps(state, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                encoding="utf-8",
            )
            _print_json({
                "file": str(target),
                "id": state["id"],
                "fingerprint": state["fingerprint"],
            })
        else:
            _print_json(state)
        return 0
    except ObservationError as exc:
        _print_json({"valid": False, "error_code": exc.code, "error": str(exc)})
        return 2
    except OSError as exc:
        _print_json({"valid": False, "error_code": "state_output_error", "error": str(exc)})
        return 2

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="acr-schema", description="Addressable Cognitive Runtime schema and adapter tools")
    sub = parser.add_subparsers(dest="command", required=True)

    p_list = sub.add_parser("list", help="list frozen schemas")
    p_list.set_defaults(func=_cmd_list)

    p_fp = sub.add_parser("fingerprint", help="compute canonical object fingerprint")
    p_fp.add_argument("file")
    p_fp.set_defaults(func=_cmd_fingerprint)

    p_val = sub.add_parser("validate", help="validate one JSON object")
    p_val.add_argument("--schema", choices=sorted(SCHEMA_SPECS), default=None)
    p_val.add_argument("file")
    p_val.set_defaults(func=_cmd_validate)

    p_fixtures = sub.add_parser("validate-fixtures", help="validate every JSON fixture recursively")
    p_fixtures.add_argument("directory")
    p_fixtures.set_defaults(func=_cmd_validate_fixtures)

    p_sprc_info = sub.add_parser("sprc-info", help="show the frozen SPRC/CIO source profile")
    p_sprc_info.set_defaults(func=_cmd_sprc_info)

    p_sprc_list = sub.add_parser("sprc-list", help="list adapted CIO cognitive objects")
    p_sprc_list.set_defaults(func=_cmd_sprc_list)

    p_sprc_resolve = sub.add_parser("sprc-resolve", help="resolve an SPRC source ID or ACR cognitive address")
    p_sprc_resolve.add_argument("identifier")
    p_sprc_resolve.set_defaults(func=_cmd_sprc_resolve)

    p_sprc_export = sub.add_parser("sprc-export", help="export the canonical 64-object SPRC/CIO ACR registry")
    p_sprc_export.add_argument("output")
    p_sprc_export.set_defaults(func=_cmd_sprc_export)

    p_state_encode = sub.add_parser("state-encode", help="encode a public observation into a SemanticState")
    p_state_encode.add_argument("observation")
    p_state_encode.add_argument("--output", default=None)
    p_state_encode.set_defaults(func=_cmd_state_encode)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
