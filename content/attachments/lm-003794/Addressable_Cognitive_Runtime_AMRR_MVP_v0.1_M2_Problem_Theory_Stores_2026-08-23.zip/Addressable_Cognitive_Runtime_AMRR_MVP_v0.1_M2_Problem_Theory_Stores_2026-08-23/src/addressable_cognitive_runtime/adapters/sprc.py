from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any

EXPECTED_DECK_HASH = "b436ad318e8fc0d8e8ab98939d275d25b690d1d59031a39c01f81a0af5d0d54e"
EXPECTED_REGISTRY_HASH = "4b33ac3b60407db3641c7ea5f3220c5cb4764578143c1fa15bc5198a2481a33d"
EXPECTED_IDS = {f"{family}{idx:02d}" for family in "RSXCDATM" for idx in range(1, 9)}


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[3]


def sprc_vendor_root() -> Path:
    return _repo_root() / "vendor" / "sprc" / "v2.2.0"


@dataclass
class SprcSource:
    profile: dict[str, Any]
    deck: dict[str, Any]
    registry: dict[str, Any]
    corpus_operators: dict[str, Any]
    discourse_profiles: dict[str, Any]


@dataclass(frozen=True)
class SprcVerification:
    deck_hash: str
    registry_hash: str
    operator_count: int


def _read_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def load_sprc_source(root: Path | None = None) -> SprcSource:
    base = Path(root) if root is not None else sprc_vendor_root()
    return SprcSource(
        profile=_read_json(base / "source_profile.json"),
        deck=_read_json(base / "operator_deck_v1.0.json"),
        registry=_read_json(base / "ses_registry_SES1.json"),
        corpus_operators=_read_json(base / "corpus_operators.json"),
        discourse_profiles=_read_json(base / "discourse_profiles.json"),
    )


def _normalized_deck_for_hash(deck: dict[str, Any]) -> dict[str, Any]:
    """Mirror SPR-SA Operator.from_dict() + OperatorDeck.to_dict() exactly."""
    cards: list[dict[str, Any]] = []
    for raw in deck.get("cards", []):
        operator_id = str(raw.get("id", ""))
        family = str(raw.get("family", operator_id[:1]))
        risks_value = raw.get("risks", raw.get("primary_risk", []))
        risks = [risks_value] if isinstance(risks_value, str) else list(risks_value or [])
        cards.append({
            "id": operator_id,
            "family": family,
            "name_cn": str(raw.get("name_cn", "")),
            "name_en": str(raw.get("name_en", "")),
            "definition": str(raw.get("definition", raw.get("operator_definition", ""))),
            "trigger": str(raw.get("trigger", raw.get("natural_language_trigger", ""))),
            "affinity": {str(k): float(v) for k, v in (raw.get("affinity") or {}).items()},
            "effects": [str(x) for x in (raw.get("effects") or [])],
            "constraints": dict(raw.get("constraints", {})),
            "risks": [str(x) for x in risks],
            "parameters": dict(raw.get("parameters", {})),
            "global_prior": float(raw.get("global_prior", 0.0)),
        })
    return {
        "version": str(deck.get("version", "")),
        "cards": sorted(cards, key=lambda card: card["id"]),
    }


def verify_sprc_source(source: SprcSource) -> SprcVerification:
    # Mirror SPR-SA canonical semantics rather than hashing the raw source JSON.
    # OperatorDeck.to_dict() normalizes defaults and sorts cards lexically by ID.
    deck_hash = _canonical_hash(_normalized_deck_for_hash(source.deck))
    registry_hash = _canonical_hash(source.registry)
    if deck_hash != EXPECTED_DECK_HASH:
        raise ValueError(f"deck hash mismatch: {deck_hash}")
    if registry_hash != EXPECTED_REGISTRY_HASH:
        raise ValueError(f"registry hash mismatch: {registry_hash}")
    if source.deck.get("version") != "CIO-Deck-v1.0":
        raise ValueError("unexpected deck version")
    ids = [str(card.get("id", "")) for card in source.deck.get("cards", [])]
    if len(ids) != 64 or set(ids) != EXPECTED_IDS or len(set(ids)) != 64:
        raise ValueError("source operator ID set mismatch")
    if source.registry.get("registry_id") != "SES1":
        raise ValueError("unexpected SES registry")
    return SprcVerification(
        deck_hash=deck_hash,
        registry_hash=registry_hash,
        operator_count=len(ids),
    )


def clone_source(source: SprcSource) -> SprcSource:
    return SprcSource(
        profile=deepcopy(source.profile),
        deck=deepcopy(source.deck),
        registry=deepcopy(source.registry),
        corpus_operators=deepcopy(source.corpus_operators),
        discourse_profiles=deepcopy(source.discourse_profiles),
    )

COGNITIVE_OBJECT_SCHEMA_HASH = "sha256:2d38d9be37bb6425f4fde6ee2a40d593f95ad52ef94ef3bfd698b8b485541d29"


def source_id_to_address(source_id: str) -> str:
    normalized = str(source_id).upper()
    if normalized not in EXPECTED_IDS:
        raise ValueError(f"unknown SPRC operator ID: {source_id}")
    return f"cog://sprc/cio/{normalized.lower()}@1"


def _corpus_operator_map(source: SprcSource) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for item in source.corpus_operators.get("operators", []):
        if not isinstance(item, dict):
            continue
        raw_id = str(item.get("id", ""))
        source_id = raw_id.removeprefix("op:")
        if source_id:
            result[source_id] = item
    return result


def _card_map(source: SprcSource) -> dict[str, tuple[int, dict[str, Any]]]:
    result: dict[str, tuple[int, dict[str, Any]]] = {}
    for index, card in enumerate(source.deck.get("cards", [])):
        if isinstance(card, dict):
            result[str(card.get("id", ""))] = (index, card)
    return result


def build_cognitive_object(source_id: str, source: SprcSource | None = None) -> dict[str, Any]:
    from addressable_cognitive_runtime.canonical import fingerprint_object

    current = source or load_sprc_source()
    verification = verify_sprc_source(current)
    normalized_id = str(source_id).upper()
    cards = _card_map(current)
    if normalized_id not in cards:
        raise ValueError(f"unknown SPRC operator ID: {source_id}")
    source_order_index, card = cards[normalized_id]
    corpus_item = _corpus_operator_map(current).get(normalized_id, {})

    renderers: dict[str, str] = {}
    trigger = str(card.get("trigger", ""))
    if trigger:
        renderers["zh-Hant"] = trigger
    reference_gloss = str(corpus_item.get("reference_gloss", ""))
    if reference_gloss:
        renderers[str(corpus_item.get("reference_gloss_locale", "en"))] = reference_gloss

    source_metadata = {
        "source_operator_id": normalized_id,
        "source_order_index": source_order_index,
        "family": str(card.get("family", normalized_id[:1])),
        "name_cn": str(card.get("name_cn", "")),
        "name_en": str(card.get("name_en", "")),
        "definition": str(card.get("definition", "")),
        "trigger": trigger,
        "affinity": deepcopy(dict(card.get("affinity", {}))),
        "constraints": deepcopy(dict(card.get("constraints", {}))),
        "parameters": deepcopy(dict(card.get("parameters", {}))),
        "risks": [str(x) for x in (card.get("risks", []) or [])],
        "global_prior": float(card.get("global_prior", 0.0)),
        "source_deck": str(current.profile["operator_deck"]),
        "source_deck_hash": verification.deck_hash,
        "source_registry": str(current.profile["wire_registry"]),
        "source_registry_hash": verification.registry_hash,
        "source_runtime": str(current.profile["runtime"]),
        "source_corpus": str(current.profile["corpus_release"]),
        "source_package": str(current.profile["source_package"]),
        "semantic_compatibility": list(current.profile["semantic_compatibility"]),
        "corpus_operator_ref": str(corpus_item.get("id", "")),
        "corpus_status": str(corpus_item.get("status", "")),
    }

    obj: dict[str, Any] = {
        "schema": "acr.cognitive-object/v0.1",
        "id": source_id_to_address(normalized_id),
        "version": 1,
        "fingerprint": "",
        "name": str(card.get("name_en") or normalized_id),
        "type": "cognitive_operator",
        "preconditions": [],
        "inputs": [],
        "outputs": [],
        "effects": [str(x) for x in (card.get("effects", []) or [])],
        "cost_class": "unknown",
        "risk_class": "unknown",
        "compatible_with": [],
        "conflicts_with": [],
        "authority_class": "cognition_only",
        "termination": [],
        "renderers": renderers,
        "vector_ref": None,
        "schema_hash": COGNITIVE_OBJECT_SCHEMA_HASH,
        "extensions": {"sprc": source_metadata},
    }
    obj["fingerprint"] = fingerprint_object(obj)
    return obj


def build_cognitive_objects(source: SprcSource | None = None) -> list[dict[str, Any]]:
    current = source or load_sprc_source()
    verify_sprc_source(current)
    return [
        build_cognitive_object(str(card["id"]), source=current)
        for card in current.deck.get("cards", [])
    ]


def address_to_source_id(address: str) -> str:
    import re

    match = re.fullmatch(r"cog://sprc/cio/([rsxcdatm][0-9]{2})@([1-9][0-9]*)", str(address))
    if match is None:
        raise ValueError(f"invalid SPRC CIO address: {address}")
    if int(match.group(2)) != 1:
        raise ValueError(f"unsupported SPRC CIO address version: @{match.group(2)}")
    source_id = match.group(1).upper()
    if source_id not in EXPECTED_IDS:
        raise ValueError(f"unknown SPRC operator ID: {source_id}")
    return source_id


def resolve_sprc_cognitive_object(value: str, source: SprcSource | None = None) -> dict[str, Any]:
    text = str(value)
    source_id = address_to_source_id(text) if text.startswith("cog://") else text.upper()
    return build_cognitive_object(source_id, source=source)


def renderer_compatibility(source: SprcSource | None = None) -> dict[str, dict[str, Any]]:
    current = source or load_sprc_source()
    verify_sprc_source(current)
    discourse_ids = {
        str(row.get("discourse_id", "")).removeprefix("disc:")
        for row in current.discourse_profiles.get("discourse_profiles", [])
        if isinstance(row, dict)
    }
    aliases = dict(current.profile.get("renderer_clause_aliases", {}))
    result: dict[str, dict[str, Any]] = {}
    for token, entry in current.registry.get("tokens", {}).items():
        if not isinstance(entry, dict) or entry.get("class") != "renderer":
            continue
        wire_profile = str(entry.get("renderer_profile", ""))
        clause_profile = str(aliases.get(wire_profile, wire_profile))
        if clause_profile not in discourse_ids:
            raise ValueError(f"renderer corpus profile missing: {clause_profile}")
        result[str(token)] = {
            "wire_profile": wire_profile,
            "corpus_clause_profile": clause_profile,
            "conflicts": [str(x) for x in entry.get("conflicts", [])],
        }
    return result


def build_sprc_registry(source: SprcSource | None = None) -> dict[str, Any]:
    from addressable_cognitive_runtime.canonical import fingerprint_object

    current = source or load_sprc_source()
    verified = verify_sprc_source(current)
    objects = build_cognitive_objects(current)
    registry: dict[str, Any] = {
        "schema": "acr.sprc-cio-registry/v0.1",
        "registry_id": "ACR1-SPRC-CIO-v1",
        "version": 1,
        "fingerprint": "",
        "source": {
            "source_package": str(current.profile["source_package"]),
            "semantic_compatibility": list(current.profile["semantic_compatibility"]),
            "operator_deck": str(current.profile["operator_deck"]),
            "deck_hash": verified.deck_hash,
            "wire_registry": str(current.profile["wire_registry"]),
            "registry_hash": verified.registry_hash,
            "runtime": str(current.profile["runtime"]),
            "corpus_release": str(current.profile["corpus_release"]),
        },
        "object_count": len(objects),
        "source_order": [obj["extensions"]["sprc"]["source_operator_id"] for obj in objects],
        "renderer_tokens": renderer_compatibility(current),
        "objects": objects,
    }
    registry["fingerprint"] = fingerprint_object(registry)
    return registry


def export_sprc_registry(path: str | Path, source: SprcSource | None = None) -> dict[str, Any]:
    target = Path(path)
    registry = build_sprc_registry(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(registry, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return registry
