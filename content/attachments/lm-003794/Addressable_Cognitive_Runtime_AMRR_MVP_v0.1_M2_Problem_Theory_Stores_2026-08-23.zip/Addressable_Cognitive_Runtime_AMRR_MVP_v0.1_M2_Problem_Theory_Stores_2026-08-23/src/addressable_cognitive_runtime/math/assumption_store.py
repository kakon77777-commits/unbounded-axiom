from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Sequence

from .errors import MathStoreError
from .store import VersionRef, VersionedObjectStore, finalize_record, with_store_parents

_PROTECTED = {"schema", "id", "version", "fingerprint"}


class AssumptionEnvelopeStore(VersionedObjectStore):
    def __init__(self, root: Path | str) -> None:
        super().__init__(root, namespace="assumption-envelopes", schema_name="assumption-envelope", id_prefix="assumption-envelope:")

    def create(
        self,
        *,
        envelope_id: str,
        subject_ref: str,
        direct_assumption_refs: Sequence[str] = (),
        inherited_assumption_refs: Sequence[str] = (),
        dependency_refs: Sequence[str] = (),
        closed: bool = False,
        extensions: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self.versions(envelope_id):
            raise MathStoreError("object_exists", f"assumption envelope already exists: {envelope_id}")
        record = {
            "schema": "amrr.assumption-envelope/v0.1",
            "id": envelope_id,
            "version": 1,
            "fingerprint": "sha256:" + "0" * 64,
            "extensions": deepcopy(dict(extensions or {})),
            "subject_ref": subject_ref,
            "direct_assumption_refs": sorted(set(direct_assumption_refs)),
            "inherited_assumption_refs": sorted(set(inherited_assumption_refs)),
            "dependency_refs": sorted(set(dependency_refs)),
            "closed": closed,
        }
        record = with_store_parents(record, ())
        return self.put(finalize_record(record, schema_name="assumption-envelope"))

    def derive(
        self,
        envelope_id: str,
        *,
        from_version: int | None = None,
        new_envelope_id: str | None = None,
        updates: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        parent = self.get(envelope_id, from_version)
        pref = VersionRef(parent["id"], parent["version"])
        target = new_envelope_id or envelope_id
        same = target == envelope_id
        if same:
            latest = self.versions(envelope_id)[-1]
            if parent["version"] != latest:
                raise MathStoreError("non_latest_parent", "same-id envelope derivation must start from latest version")
            version = parent["version"] + 1
        else:
            if self.versions(target):
                raise MathStoreError("object_exists", f"assumption envelope already exists: {target}")
            version = 1
        requested = dict(updates or {})
        protected = sorted(_PROTECTED.intersection(requested))
        if protected:
            raise MathStoreError("protected_update_field", f"derive cannot override protected fields: {', '.join(protected)}")
        child = deepcopy(parent)
        child["id"] = target
        child["version"] = version
        child["fingerprint"] = "sha256:" + "0" * 64
        if "extensions" in requested:
            ext = deepcopy(child.get("extensions") or {})
            ext.update(deepcopy(dict(requested.pop("extensions") or {})))
            child["extensions"] = ext
        for key, value in requested.items():
            child[key] = deepcopy(value)
        child = with_store_parents(child, (pref,))
        return self.put(finalize_record(child, schema_name="assumption-envelope"))
