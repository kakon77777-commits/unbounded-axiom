from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Sequence

from .errors import MathStoreError
from .store import VersionRef, VersionedObjectStore, finalize_record, with_store_parents

_PROTECTED = {"schema", "id", "version", "fingerprint", "parent_refs"}


class TheoryStore(VersionedObjectStore):
    def __init__(self, root: Path | str) -> None:
        super().__init__(root, namespace="theories", schema_name="theory-record", id_prefix="theory:")

    def create(
        self,
        *,
        theory_id: str,
        signature_refs: Sequence[str] = (),
        axiom_refs: Sequence[str] = (),
        definition_refs: Sequence[str] = (),
        theorem_refs: Sequence[str] = (),
        method_refs: Sequence[str] = (),
        bridge_refs: Sequence[str] = (),
        open_obligation_refs: Sequence[str] = (),
        extension_profile_ref: str | None = None,
        status: str = "active",
        extensions: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self.versions(theory_id):
            raise MathStoreError("object_exists", f"theory already exists: {theory_id}")
        record = {
            "schema": "amrr.theory-record/v0.1",
            "id": theory_id,
            "version": 1,
            "fingerprint": "sha256:" + "0" * 64,
            "extensions": deepcopy(dict(extensions or {})),
            "parent_refs": [],
            "signature_refs": sorted(set(signature_refs)),
            "axiom_refs": sorted(set(axiom_refs)),
            "definition_refs": sorted(set(definition_refs)),
            "theorem_refs": sorted(set(theorem_refs)),
            "method_refs": sorted(set(method_refs)),
            "bridge_refs": sorted(set(bridge_refs)),
            "open_obligation_refs": sorted(set(open_obligation_refs)),
            "extension_profile_ref": extension_profile_ref,
            "status": status,
        }
        record = with_store_parents(record, ())
        return self.put(finalize_record(record, schema_name="theory-record"))

    def derive(
        self,
        theory_id: str,
        *,
        from_version: int | None = None,
        new_theory_id: str | None = None,
        updates: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        parent = self.get(theory_id, from_version)
        pref = VersionRef(parent["id"], parent["version"])
        target = new_theory_id or theory_id
        same = target == theory_id
        if same:
            latest = self.versions(theory_id)[-1]
            if parent["version"] != latest:
                raise MathStoreError("non_latest_parent", "same-id theory derivation must start from latest version")
            version = parent["version"] + 1
        else:
            if self.versions(target):
                raise MathStoreError("object_exists", f"theory already exists: {target}")
            version = 1

        requested = dict(updates or {})
        protected = sorted(_PROTECTED.intersection(requested))
        if protected:
            raise MathStoreError("protected_update_field", f"derive cannot override protected fields: {', '.join(protected)}")
        child = deepcopy(parent)
        child["id"] = target
        child["version"] = version
        child["fingerprint"] = "sha256:" + "0" * 64
        if not same:
            child["parent_refs"] = sorted(set(parent.get("parent_refs", [])) | {theory_id})
        if "extensions" in requested:
            ext = deepcopy(child.get("extensions") or {})
            ext.update(deepcopy(dict(requested.pop("extensions") or {})))
            child["extensions"] = ext
        for key, value in requested.items():
            child[key] = deepcopy(value)
        child = with_store_parents(child, (pref,))
        return self.put(finalize_record(child, schema_name="theory-record"))

    def branch(self, theory_id: str, *, new_theory_id: str, from_version: int | None = None, updates: Mapping[str, Any] | None = None) -> dict[str, Any]:
        return self.derive(theory_id, from_version=from_version, new_theory_id=new_theory_id, updates=updates)
