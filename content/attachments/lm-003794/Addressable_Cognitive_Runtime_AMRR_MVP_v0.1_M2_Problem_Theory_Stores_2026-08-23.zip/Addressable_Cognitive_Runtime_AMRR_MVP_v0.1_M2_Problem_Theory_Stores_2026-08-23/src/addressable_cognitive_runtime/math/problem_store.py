from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Sequence

from .errors import MathStoreError
from .store import VersionRef, VersionedObjectStore, finalize_record, with_store_parents

_PROTECTED_UPDATE_FIELDS = {"schema", "id", "version", "fingerprint", "parent_refs"}


class ProblemStore(VersionedObjectStore):
    def __init__(self, root: Path | str) -> None:
        super().__init__(
            root,
            namespace="problems",
            schema_name="problem-record",
            id_prefix="problem:",
        )

    def create(
        self,
        *,
        problem_id: str,
        canonical_statement_ref: str,
        assumption_envelope_ref: str,
        informal_statement_ref: str | None = None,
        formal_statement_refs: Sequence[str] = (),
        domain_refs: Sequence[str] = (),
        success_criteria: Sequence[str] = (),
        status: str = "active",
        created_from_gap_ref: str | None = None,
        extensions: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self.versions(problem_id):
            raise MathStoreError("object_exists", f"problem already exists: {problem_id}")
        record = {
            "schema": "amrr.problem-record/v0.1",
            "id": problem_id,
            "version": 1,
            "fingerprint": "sha256:" + "0" * 64,
            "extensions": deepcopy(dict(extensions or {})),
            "parent_refs": [],
            "canonical_statement_ref": canonical_statement_ref,
            "informal_statement_ref": informal_statement_ref,
            "formal_statement_refs": sorted(set(formal_statement_refs)),
            "domain_refs": sorted(set(domain_refs)),
            "success_criteria": sorted(set(success_criteria)),
            "status": status,
            "created_from_gap_ref": created_from_gap_ref,
            "relation_to_parent": None,
            "assumption_envelope_ref": assumption_envelope_ref,
        }
        record = with_store_parents(record, ())
        return self.put(finalize_record(record, schema_name="problem-record"))

    def derive(
        self,
        problem_id: str,
        *,
        from_version: int | None = None,
        new_problem_id: str | None = None,
        relation_to_parent: str,
        updates: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        parent = self.get(problem_id, from_version)
        parent_ref = VersionRef(parent["id"], parent["version"])
        target_id = new_problem_id or problem_id
        same_identity = target_id == problem_id

        if same_identity:
            latest = self.versions(problem_id)[-1]
            if parent["version"] != latest:
                raise MathStoreError(
                    "non_latest_parent",
                    "same-id derivation must start from the latest stored version",
                )
            target_version = parent["version"] + 1
        else:
            if self.versions(target_id):
                raise MathStoreError("object_exists", f"problem already exists: {target_id}")
            target_version = 1

        requested = dict(updates or {})
        protected = sorted(_PROTECTED_UPDATE_FIELDS.intersection(requested))
        if protected:
            raise MathStoreError(
                "protected_update_field",
                f"derive cannot override protected fields: {', '.join(protected)}",
            )

        child = deepcopy(parent)
        child["id"] = target_id
        child["version"] = target_version
        child["fingerprint"] = "sha256:" + "0" * 64
        if not same_identity:
            child["parent_refs"] = sorted(set(parent.get("parent_refs", [])) | {problem_id})
        child["relation_to_parent"] = relation_to_parent

        if "extensions" in requested:
            merged_extensions = deepcopy(child.get("extensions") or {})
            merged_extensions.update(deepcopy(dict(requested.pop("extensions") or {})))
            child["extensions"] = merged_extensions
        for key, value in requested.items():
            child[key] = deepcopy(value)

        child = with_store_parents(child, (parent_ref,))
        child = finalize_record(child, schema_name="problem-record")
        return self.put(child)

    def branch(
        self,
        problem_id: str,
        *,
        new_problem_id: str,
        relation_to_parent: str = "new_problem",
        from_version: int | None = None,
        updates: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.derive(
            problem_id,
            from_version=from_version,
            new_problem_id=new_problem_id,
            relation_to_parent=relation_to_parent,
            updates=updates,
        )
