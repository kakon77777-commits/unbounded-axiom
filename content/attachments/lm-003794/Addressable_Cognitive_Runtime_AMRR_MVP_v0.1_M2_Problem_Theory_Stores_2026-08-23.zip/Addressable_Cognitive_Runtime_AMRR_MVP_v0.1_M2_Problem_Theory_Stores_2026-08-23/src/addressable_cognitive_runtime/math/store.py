from __future__ import annotations

import json
import os
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping
from urllib.parse import quote

from ..canonical import fingerprint_object
from ..validation import validate_object
from .errors import MathStoreError

VERSIONED_MATH_STORE_PROFILE = "amrr.versioned-math-store/v0.1"
M2_STORE_EXTENSION_KEY = "amrr_m2_store"


@dataclass(frozen=True, order=True)
class VersionRef:
    object_id: str
    version: int

    def __post_init__(self) -> None:
        if not isinstance(self.object_id, str) or not self.object_id:
            raise ValueError("object_id must be non-empty")
        if not isinstance(self.version, int) or self.version < 1:
            raise ValueError("version must be >= 1")

    @property
    def token(self) -> str:
        return f"{self.object_id}#v{self.version}"


def _canonical_record(record: Mapping[str, Any]) -> dict[str, Any]:
    return deepcopy(dict(record))


def finalize_record(record: Mapping[str, Any], *, schema_name: str) -> dict[str, Any]:
    result = _canonical_record(record)
    result["fingerprint"] = "sha256:" + "0" * 64
    result["fingerprint"] = fingerprint_object(result)
    validation = validate_object(result, schema_name=schema_name)
    if not validation.valid:
        message = "; ".join(f"{issue.code}:{issue.message}" for issue in validation.issues)
        raise MathStoreError("invalid_record", message)
    return result


def store_parent_versions(record: Mapping[str, Any]) -> tuple[VersionRef, ...]:
    extensions = record.get("extensions")
    if not isinstance(extensions, Mapping):
        return ()
    store_meta = extensions.get(M2_STORE_EXTENSION_KEY)
    if not isinstance(store_meta, Mapping):
        return ()
    parents = store_meta.get("parent_versions")
    if not isinstance(parents, list):
        return ()
    result: list[VersionRef] = []
    for item in parents:
        if not isinstance(item, Mapping):
            continue
        object_id = item.get("id")
        version = item.get("version")
        if isinstance(object_id, str) and isinstance(version, int) and version >= 1:
            result.append(VersionRef(object_id, version))
    return tuple(result)


def with_store_parents(
    record: Mapping[str, Any], parents: Iterable[VersionRef]
) -> dict[str, Any]:
    result = _canonical_record(record)
    extensions = deepcopy(result.get("extensions") or {})
    extensions[M2_STORE_EXTENSION_KEY] = {
        "parent_versions": [
            {"id": parent.object_id, "version": parent.version}
            for parent in sorted(set(parents))
        ]
    }
    result["extensions"] = extensions
    return result


class VersionedObjectStore:
    def __init__(
        self,
        root: Path | str,
        *,
        namespace: str,
        schema_name: str,
        id_prefix: str,
    ) -> None:
        self.root = Path(root)
        self.namespace = namespace
        self.schema_name = schema_name
        self.id_prefix = id_prefix
        self.base = self.root / namespace
        self.base.mkdir(parents=True, exist_ok=True)

    def _object_dir(self, object_id: str) -> Path:
        if not object_id.startswith(self.id_prefix):
            raise MathStoreError(
                "invalid_object_id",
                f"{object_id!r} must start with {self.id_prefix!r}",
            )
        return self.base / quote(object_id, safe="")

    def _path(self, object_id: str, version: int) -> Path:
        if not isinstance(version, int) or version < 1:
            raise MathStoreError("invalid_version", "version must be an integer >= 1")
        return self._object_dir(object_id) / f"v{version:06d}.json"

    def _validate(self, record: Mapping[str, Any], *, corruption: bool = False) -> dict[str, Any]:
        obj = _canonical_record(record)
        if not isinstance(obj.get("id"), str) or not obj["id"].startswith(self.id_prefix):
            raise MathStoreError("corrupt_record" if corruption else "invalid_record", "record id prefix mismatch")
        validation = validate_object(obj, schema_name=self.schema_name)
        if not validation.valid:
            message = "; ".join(f"{issue.code}:{issue.message}" for issue in validation.issues)
            raise MathStoreError("corrupt_record" if corruption else "invalid_record", message)
        return obj

    def put(self, record: Mapping[str, Any]) -> dict[str, Any]:
        obj = self._validate(record)
        object_id = obj["id"]
        version = obj["version"]
        path = self._path(object_id, version)
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            current = self._read_path(path)
            if current == obj:
                return current
            raise MathStoreError(
                "silent_overwrite",
                f"refusing to overwrite existing {object_id} version {version}",
            )

        existing_versions = self.versions(object_id)
        expected_version = (existing_versions[-1] + 1) if existing_versions else 1
        if version != expected_version:
            raise MathStoreError(
                "non_sequential_version",
                f"expected next version {expected_version} for {object_id}, got {version}",
            )

        parents = store_parent_versions(obj)
        if version > 1 and VersionRef(object_id, version - 1) not in parents:
            raise MathStoreError(
                "missing_version_parent",
                f"version {version} must declare exact parent {object_id}#v{version - 1}",
            )

        for parent in parents:
            if parent.object_id == object_id and parent.version == version:
                raise MathStoreError("self_parent", "object version cannot parent itself")
            if not self._path(parent.object_id, parent.version).exists():
                raise MathStoreError(
                    "missing_parent",
                    f"parent version does not exist: {parent.token}",
                )

        tmp = path.with_suffix(".json.tmp")
        text = json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
        tmp.write_text(text, encoding="utf-8", newline="\n")
        os.replace(tmp, path)
        return deepcopy(obj)

    def _read_path(self, path: Path) -> dict[str, Any]:
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise MathStoreError("corrupt_record", f"cannot read {path}: {exc}") from exc
        return self._validate(raw, corruption=True)

    def get(self, object_id: str, version: int | None = None) -> dict[str, Any]:
        if version is None:
            versions = self.versions(object_id)
            if not versions:
                raise MathStoreError("not_found", f"no stored object: {object_id}")
            version = versions[-1]
        path = self._path(object_id, version)
        if not path.exists():
            raise MathStoreError("not_found", f"object version not found: {object_id}#v{version}")
        return self._read_path(path)

    def versions(self, object_id: str) -> tuple[int, ...]:
        directory = self._object_dir(object_id)
        if not directory.exists():
            return ()
        versions: list[int] = []
        for path in directory.glob("v*.json"):
            stem = path.stem
            try:
                versions.append(int(stem[1:]))
            except ValueError:
                continue
        return tuple(sorted(versions))

    def records(self) -> tuple[dict[str, Any], ...]:
        result: list[dict[str, Any]] = []
        if not self.base.exists():
            return ()
        for object_dir in sorted(p for p in self.base.iterdir() if p.is_dir()):
            for path in sorted(object_dir.glob("v*.json")):
                result.append(self._read_path(path))
        return tuple(result)

    def graph(self) -> dict[str, Any]:
        nodes: list[dict[str, Any]] = []
        edges: list[dict[str, str]] = []
        for record in self.records():
            child = VersionRef(record["id"], record["version"])
            nodes.append({"id": child.object_id, "version": child.version, "ref": child.token})
            for parent in store_parent_versions(record):
                edges.append({"from": parent.token, "to": child.token})
        nodes.sort(key=lambda x: x["ref"])
        edges.sort(key=lambda x: (x["from"], x["to"]))
        return {"nodes": nodes, "edges": edges}
