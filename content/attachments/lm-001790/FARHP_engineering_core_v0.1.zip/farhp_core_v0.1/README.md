# FARHP-Core v0.1

`FARHP-Core` 是「基頻錨定相對諧波相位差」的第一個可執行研究原型。它建立一條最小閉環：

$$
\text{合成}\rightarrow\text{基頻估計}\rightarrow\text{諧波分析}\rightarrow\text{FARHP}\rightarrow\text{量化／碼本}\rightarrow\text{重建}.
$$

## 邊界

這不是完整聲碼器，也不是自然語音品質保證。v0.1 僅針對：

- 理想諧波訊號；
- 穩定、持續的合成母音；
- 單一短時有聲框架；
- `FARHP-Y` 觀測輸出域；
- 諧波部分重建。

未納入噪聲殘差、塞音瞬態、無聲擦音、聲門逆濾波、完整連續句與神經模型。

## 安裝

```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

python -m pip install -e .
```

## 執行閉環示範

```bash
python -m farhp demo --out artifacts/demo
```

將產生：

- `synthetic_vowel.wav`
- `farhp_frame.json`
- `reconstructed_frame.wav`
- `farhp_inspector.png`
- `demo_report.json`

## 驗證 JSON

```bash
python -m farhp validate artifacts/demo/farhp_frame.json \
  --schema spec/FARHP_Spec_v0.1.schema.json
```

## 測試

```bash
python -m unittest discover -s tests -v
```

## 核心定義

對第 $k$ 個諧波複係數：

$$
X_k=A_ke^{i\phi_k},
$$

FARHP 定義為：

$$
\psi_k=\operatorname{wrap}(\phi_k-k\phi_1),\qquad k\ge 2.
$$

重建時：

$$
\widehat\phi_k=k\phi_1+\psi_k\pmod{2\pi}.
$$

## 專案結構

```text
src/farhp/
  analyzer.py       F0 與諧波投影分析
  model.py          FARHPFrame 資料物件
  synth.py          理想諧波與合成母音
  reconstructor.py  諧波重建與框架 OLA
  quantizer.py      圓周標量量化
  codebook.py       加權環面碼本
  schema.py         FARHP-Spec 驗證
  inspector.py      診斷圖
  cli.py            命令列入口
tests/               不變性、往返、量化、碼本、規格測試
spec/                FARHP-Spec-v0.1
```

## 授權與研究狀態

程式碼採 MIT License；論文與規格仍屬研究草案。任何自然語音結論都必須經資料集、客觀指標與盲聽實驗驗證。
