"""FARHP-Core v0.1: a research prototype for fundamental-anchored relative harmonic phase."""

from .analyzer import AnalysisConfig, analyze_frame, analyze_waveform, estimate_f0_yin
from .codebook import TorusCodebook
from .model import FARHPFrame
from .quantizer import CircularScalarQuantizer
from .reconstructor import reconstruct_frame
from .synth import VOWEL_FORMANTS, harmonic_synthesize, synthetic_vowel
from .utils import circular_distance, torus_distance, wrap_phase

__all__ = [
    "AnalysisConfig",
    "CircularScalarQuantizer",
    "FARHPFrame",
    "TorusCodebook",
    "VOWEL_FORMANTS",
    "analyze_frame",
    "analyze_waveform",
    "circular_distance",
    "estimate_f0_yin",
    "harmonic_synthesize",
    "reconstruct_frame",
    "synthetic_vowel",
    "torus_distance",
    "wrap_phase",
]

__version__ = "0.1.0"
