from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .analyzer import AnalysisConfig, analyze_frame
from .inspector import save_frame_plot
from .io import load_frame, load_json, read_wav, save_frame, save_json, write_wav
from .quantizer import CircularScalarQuantizer
from .reconstructor import reconstruct_frame
from .schema import validate_spec_object
from .synth import synthetic_vowel
from .utils import rms, torus_distance


def _center_frame(x: np.ndarray, sample_rate_hz: int, length_sec: float) -> np.ndarray:
    n = int(round(length_sec * sample_rate_hz))
    if x.size < n:
        return np.pad(x, (0, n - x.size))
    start = (x.size - n) // 2
    return x[start : start + n]


def cmd_demo(args: argparse.Namespace) -> int:
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    waveform, true_amplitude, true_psi = synthetic_vowel(
        args.vowel,
        f0_hz=args.f0,
        sample_rate_hz=args.sample_rate,
        duration_sec=args.duration,
        k_max=args.k_max,
    )
    write_wav(out / "synthetic_vowel.wav", args.sample_rate, waveform)
    frame_wave = _center_frame(waveform, args.sample_rate, args.frame_length)
    config = AnalysisConfig(k_max=args.k_max, window="hann")
    frame = analyze_frame(frame_wave, args.sample_rate, frame_time_sec=args.duration / 2, config=config)
    save_frame(out / "farhp_frame.json", frame)
    reconstructed = reconstruct_frame(frame, normalize=True)
    write_wav(out / "reconstructed_frame.wav", args.sample_rate, reconstructed)
    save_frame_plot(frame, frame_wave, out / "farhp_inspector.png")

    quantizer = CircularScalarQuantizer(args.levels)
    q = quantizer.encode(frame.phase_vector())
    q_decoded = quantizer.decode(q)
    quant_error = torus_distance(frame.phase_vector(), q_decoded, mask=frame.phase_mask())
    report = {
        "estimated_f0_hz": frame.f0_hz,
        "target_f0_hz": args.f0,
        "f0_absolute_error_hz": abs(frame.f0_hz - args.f0),
        "f0_confidence": frame.f0_confidence,
        "applicability_grade": frame.applicability_grade,
        "harmonics": frame.k_max,
        "valid_harmonics": int(np.sum(frame.mask)),
        "scalar_quantizer_levels": args.levels,
        "quantization_torus_rmse_rad": quant_error,
        "quantization_bound_rad": quantizer.worst_case_error_rad,
        "frame_rms": rms(frame_wave),
        "reconstruction_rms": rms(reconstructed),
        "note": "Reconstruction is a harmonic-only frame model; it excludes residual/noise components.",
    }
    save_json(out / "demo_report.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def cmd_analyze(args: argparse.Namespace) -> int:
    fs, x = read_wav(args.wav)
    frame_wave = _center_frame(x, fs, args.frame_length)
    frame = analyze_frame(frame_wave, fs, config=AnalysisConfig(k_max=args.k_max))
    save_frame(args.out, frame)
    return 0


def cmd_reconstruct(args: argparse.Namespace) -> int:
    frame = load_frame(args.json)
    waveform = reconstruct_frame(frame, normalize=True)
    write_wav(args.out, frame.sample_rate_hz, waveform)
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    errors = validate_spec_object(load_json(args.json), args.schema)
    if errors:
        print("INVALID")
        for error in errors:
            print(f"- {error}")
        return 1
    print("VALID")
    return 0


def cmd_inspect(args: argparse.Namespace) -> int:
    frame = load_frame(args.json)
    waveform = reconstruct_frame(frame, normalize=False)
    save_frame_plot(frame, waveform, args.out)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="farhp", description="FARHP-Core v0.1 research prototype")
    sub = parser.add_subparsers(dest="command", required=True)

    demo = sub.add_parser("demo", help="run the synthetic-vowel closed-loop demonstration")
    demo.add_argument("--out", default="artifacts/demo")
    demo.add_argument("--vowel", default="a")
    demo.add_argument("--f0", type=float, default=125.0)
    demo.add_argument("--sample-rate", type=int, default=16000)
    demo.add_argument("--duration", type=float, default=0.8)
    demo.add_argument("--frame-length", type=float, default=0.08)
    demo.add_argument("--k-max", type=int, default=24)
    demo.add_argument("--levels", type=int, default=16)
    demo.set_defaults(func=cmd_demo)

    analyze = sub.add_parser("analyze", help="analyze the center frame of a WAV file")
    analyze.add_argument("wav")
    analyze.add_argument("--out", required=True)
    analyze.add_argument("--frame-length", type=float, default=0.08)
    analyze.add_argument("--k-max", type=int, default=24)
    analyze.set_defaults(func=cmd_analyze)

    recon = sub.add_parser("reconstruct", help="reconstruct a harmonic frame from FARHP JSON")
    recon.add_argument("json")
    recon.add_argument("--out", required=True)
    recon.set_defaults(func=cmd_reconstruct)

    validate = sub.add_parser("validate", help="validate FARHP JSON against FARHP-Spec schema")
    validate.add_argument("json")
    validate.add_argument("--schema", required=True)
    validate.set_defaults(func=cmd_validate)

    inspect = sub.add_parser("inspect", help="render a diagnostic PNG from FARHP JSON")
    inspect.add_argument("json")
    inspect.add_argument("--out", required=True)
    inspect.set_defaults(func=cmd_inspect)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
