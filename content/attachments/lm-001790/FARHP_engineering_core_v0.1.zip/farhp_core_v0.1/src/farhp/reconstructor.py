from __future__ import annotations

import numpy as np

from .model import FARHPFrame
from .synth import harmonic_synthesize
from .utils import normalize_audio


def reconstruct_frame(
    frame: FARHPFrame,
    *,
    duration_sec: float | None = None,
    normalize: bool = False,
    use_mask: bool = True,
) -> np.ndarray:
    duration = frame.frame_length_sec if duration_sec is None else float(duration_sec)
    amplitudes = np.asarray(frame.amplitudes, dtype=float)
    if use_mask:
        amplitudes = amplitudes * np.asarray(frame.mask, dtype=float)
    return harmonic_synthesize(
        f0_hz=frame.f0_hz,
        sample_rate_hz=frame.sample_rate_hz,
        duration_sec=duration,
        amplitudes=amplitudes,
        farhp_rad=frame.farhp_rad,
        anchor_phase_rad=frame.anchor_phase_rad,
        normalize=normalize,
    )


def overlap_add_reconstruct(
    frames: list[FARHPFrame],
    *,
    hop_length_sec: float,
    normalize: bool = True,
) -> np.ndarray:
    if not frames:
        return np.zeros(0, dtype=float)
    fs = frames[0].sample_rate_hz
    hop = int(round(hop_length_sec * fs))
    frame_n = int(round(frames[0].frame_length_sec * fs))
    output_n = hop * (len(frames) - 1) + frame_n
    output = np.zeros(output_n, dtype=float)
    weight = np.zeros(output_n, dtype=float)
    window = np.hanning(frame_n)
    for i, model in enumerate(frames):
        if model.sample_rate_hz != fs:
            raise ValueError("all frames must share sample rate")
        y = reconstruct_frame(model, duration_sec=frame_n / fs, normalize=False)
        start = i * hop
        output[start : start + frame_n] += y[:frame_n] * window
        weight[start : start + frame_n] += np.square(window)
    valid = weight > 1e-10
    output[valid] /= np.sqrt(weight[valid])
    return normalize_audio(output) if normalize else output
