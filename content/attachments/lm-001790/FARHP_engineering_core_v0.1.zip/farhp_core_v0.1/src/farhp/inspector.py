from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from .model import FARHPFrame


def save_frame_plot(frame: FARHPFrame, waveform: np.ndarray, path: str | Path) -> None:
    t = np.arange(waveform.size) / frame.sample_rate_hz
    k = np.asarray(frame.harmonic_indices)
    amplitude = np.asarray(frame.amplitudes)
    psi = np.asarray(frame.farhp_rad)

    fig = plt.figure(figsize=(10, 8), constrained_layout=True)
    grid = fig.add_gridspec(3, 1)
    ax1 = fig.add_subplot(grid[0, 0])
    ax1.plot(t, waveform)
    ax1.set_title("Waveform")
    ax1.set_xlabel("Time (s)")
    ax1.set_ylabel("Amplitude")

    ax2 = fig.add_subplot(grid[1, 0])
    ax2.stem(k, amplitude)
    ax2.set_title("Harmonic amplitudes")
    ax2.set_xlabel("Harmonic index")
    ax2.set_ylabel("Amplitude")

    ax3 = fig.add_subplot(grid[2, 0])
    ax3.scatter(k[1:], psi[1:])
    ax3.set_title("FARHP coordinates")
    ax3.set_xlabel("Harmonic index")
    ax3.set_ylabel("Phase (rad)")
    ax3.set_ylim(-np.pi, np.pi)
    ax3.set_yticks([-np.pi, -np.pi / 2, 0, np.pi / 2, np.pi])
    ax3.set_yticklabels(["-π", "-π/2", "0", "π/2", "π"])

    fig.savefig(path, dpi=160)
    plt.close(fig)
