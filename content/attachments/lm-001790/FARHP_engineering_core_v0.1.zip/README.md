# FARHP 系列 v0.5

本封裝包含五篇論文、FARHP-Spec-v0.1、第一個可執行 Python 原型、示範音訊、診斷圖、自動測試與驗證報告。

## 快速入口

- 先讀系列索引：`FARHP_系列索引_v0.5.md`
- 閱讀第五篇：`FARHP_05_分析編碼生成與重建架構_v0.1.md`
- 執行原型：進入 `farhp_core_v0.1/` 後依 `README.md` 操作
- 查看測試：`farhp_core_v0.1/artifacts/test_report.txt`
- 查看示範：`farhp_core_v0.1/artifacts/demo/`

## 目前邊界

這是研究原型，不是完整語音產品。第一版只驗證理想諧波與穩定合成母音的 FARHP 閉環。
