# OCME MVP v0.2 驗證紀錄

**日期：** 2026-07-25  
**分支：** `feature/ocme-v0.2-knowledge-graph`

## 正向檢查

執行：

```bash
npm run check
```

結果：

- MKO 結構驗證通過；
- 3 個數學知識物件成功載入；
- 2 條依賴邊成功解析；
- 懸空依賴：0；
- 依賴循環：0；
- Node 煙霧測試通過；
- 三組 Python 計算伴隨全部通過；
- 畢氏三元組有限列舉 `1..200` 得到 127 組；
- JSONL 與依賴圖匯出成功。

## HTTP 檢查

使用獨立本地埠啟動 `server.js` 後確認：

- 首頁正常回傳；
- `data/index.json` 正常回傳；
- 三個 MKO JSON 正常回傳；
- 編碼後的路徑穿越請求回傳 HTTP 400。

詳見：

```text
artifacts/http-smoke-v0.2.json
```

## 負向檢查

測試時暫時加入：

```text
直角三角形 → 畢達哥拉斯定理
```

原有關係為：

```text
直角三角形 → 畢達哥拉斯定理
```

其中箭頭在知識圖中表示「前者是後者的前置知識」。反向 dependency 注入後形成循環，驗證器正確拒絕：

```text
mko-right-triangle
→ mko-euclid-pythagorean-theorem
→ mko-right-triangle
```

詳見：

```text
artifacts/negative-cycle-test-v0.2.json
```

## 限制

- FELRA 規格存在，但此測試環境沒有安裝 FELRA CLI，因此未重播 FELRA 證據包。
- MCP 伺服器通過 JavaScript 語法檢查；完整工具呼叫需要先安裝官方 MCP SDK 與 Zod。
- Python 與有限網格結果不構成普遍數學證明。
