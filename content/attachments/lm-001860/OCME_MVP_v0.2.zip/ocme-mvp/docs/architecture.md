# MVP v0.2 架構

```text
Canonical MKO JSON
├── Node + 原生 MathML 人類閱讀介面
├── 物件索引、搜尋與 ?id= 導覽
├── 可解析依賴圖
├── MCP Server AI 介面
├── JSONL／Dependency Graph 匯出
├── Python 計算伴隨
└── FELRA 專案規格
```

目前知識圖：

```text
直角三角形 ─┐
             ├→ 畢達哥拉斯定理
歐幾里得長度 ┘
```

核心原則：

$$
\text{數學}\neq\text{程式}\neq\text{有限計算證據}\neq\text{形式證明}
$$

驗證器拒絕懸空依賴、自我依賴與循環依賴。新增條目時，不得把 HTML 當作唯一知識來源。
