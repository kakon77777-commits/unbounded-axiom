## 摘要

將 OCME 從單一畢達哥拉斯定理條目，擴展為第一個可解析的數學知識圖：

```text
直角三角形 ─┐
             ├→ 畢達哥拉斯定理
歐幾里得長度 ┘
```

## 主要變更

- 新增 `mko-right-triangle` 與 `mko-euclidean-length`
- 索引由 1 個物件擴展為 3 個物件
- UI 支援目錄、搜尋、`?id=` 分享網址與依賴跳轉
- MCP 新增 `get_dependencies`、`get_formula_ast`、`get_dependency_graph`
- 驗證器拒絕重複 ID、懸空依賴、自我依賴與循環依賴
- JSONL 匯出同步產生 dependency graph
- 三個 Python 計算伴隨可由 `npm run verify:python` 統一重播
- `npm run check` 串接結構驗證、煙霧測試、Python 證據與資料匯出

## 已完成測試

- Node 語法檢查通過
- 3 個 MKO、2 條 dependency edge 通過
- 依賴解析煙霧測試通過
- 三組 Python 計算伴隨全部通過
- HTTP 首頁、索引與三個 MKO 路由通過
- 路徑穿越請求回傳 HTTP 400
- 負向循環測試正確失敗並輸出循環路徑

有限計算證據仍不等於普遍數學證明。
