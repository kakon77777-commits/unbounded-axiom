# TCFT-BTAP Extension E3 — Heterogeneous Prior-Art Providers

Runtime package: `0.1.3`  
Protocol: sealed TCFT-BTAP v0.1 unchanged  
Branch: `extension/e3-heterogeneous-prior-art`

## Scope

E3 extends the E2 prior-art evidence network beyond scholarly-paper providers. It adds reference adapters for patents, books, and archived-web capture metadata while keeping novelty and structural judgment downstream.

Implemented providers:

- `PatentsViewPriorArtProvider`
- `GoogleBooksPriorArtProvider`
- `WaybackCdxPriorArtProvider`

E3 does **not** change TN / PG / CF / RG / RP / NC formulas or A0–A7 sealed conformance semantics.

## PatentsView semantics

The reference adapter queries PatentsView PatentSearch `/api/v1/publication/` pre-grant publication metadata. Frozen-Time uses `publication_date`, not later patent grant date.

- API key is required.
- Missing credentials raise `PriorArtCapabilityUnavailableError`.
- Capability unavailable is a provider failure, never `no_match_found=True`.
- CPC / WIPO metadata is retained as domain metadata only.
- The provider emits S1 lexical retrieval evidence; it does not judge claim novelty or inventive step.
- Strong identity: normalized `patent:us-pub:*` publication number.

## Google Books semantics

Google Books uses volume search metadata.

- `publishedDate` is converted to a temporal interval according to available precision.
- There is no trusted remote publication-date upper bound in the reference provider; TCFT local Frozen-Time filtering remains authoritative.
- A year-only date that straddles the cutoff is ambiguous, not automatically pre-cutoff.
- ISBN-10 / ISBN-13 identifiers are validated and normalized.
- A valid ISBN-10 also contributes its mathematically equivalent ISBN-13 identity for aggregation.
- Same title without shared strong identity does not auto-merge.

## Wayback CDX semantics

Wayback CDX is a URL/capture-evidence provider, not a semantic document-search provider.

- Query family: `ARCHIVE_URL`.
- Capture `timestamp` is the evidence time.
- The record stores original URL, replay URI, MIME type, status, length, and digest metadata.
- E3 does **not** fetch or interpret archived page content.
- Evidence notes explicitly include `content-not-inspected`.
- URL alone is not a global strong identity because the same URL may change content over time.
- An explicit CDX digest becomes `web-digest:*` and may join equivalent capture evidence across providers.
- Same URL with different digests remains separate unless some other independently strong identity links the records.

## Heterogeneous identity rules

Cross-provider automatic merge keys now include:

1. DOI
2. arXiv base ID
3. ISBN-13
4. ISBN-10 (with validated ISBN-13 bridge)
5. US pre-grant publication number
6. explicit web content digest

Provider-local aliases remain local. Title and URL similarity do not create global identity.

Canonical identity preference is:

```text
DOI > arXiv > ISBN-13 > ISBN-10 > US pre-grant publication > web digest > provider-local
```

E2 conflict-preservation rules remain in force: aggregation does not silently select a provider as truth when strong evidence conflicts.

## Live-query compatibility boundary

A single `live-prior-aggregate` invocation requires providers to share query semantics. Scholarly/book/patent adapters use lexical queries, while Wayback uses URL/capture queries.

Therefore:

```text
Wayback + lexical provider in one live query = REJECT
```

For heterogeneous evidence, run provider-appropriate searches independently and feed the resulting `PriorArtSearchResult` objects to the deterministic aggregation layer.

## Credential routing

CLI supports provider-specific keys:

```text
--openalex-api-key
--patentsview-api-key
--google-books-api-key
```

The legacy `--api-key` remains a single-provider/fallback credential for backward compatibility.

## Deterministic E3 synthetic guards

E3 adds fixtures for:

- ISBN cross-provider deduplication;
- ISBN-10 → ISBN-13 identity bridging;
- US patent publication deduplication;
- web digest cross-provider deduplication;
- same URL / different digest non-merge.

These fixtures contain no network dependency.

## Deliberate limits

E3 does not add:

- patent claim/full-text semantic novelty analysis;
- patent-family equivalence beyond explicit normalized publication identity;
- library catalog providers beyond Google Books metadata;
- archived page replay/content parsing;
- title/embedding based merge heuristics;
- semantic or structural S2–S5 promotion;
- automatic historical novelty judgments from provider metadata.

## Release-gate expectations

Before E3 artifacts are produced, the final HEAD must demonstrate:

- all unit tests PASS;
- all acceptance tests PASS;
- all integration tests PASS (subprocess-heavy files may be executed individually on this host);
- `compileall` PASS;
- `git diff --check` PASS;
- clean Git tree;
- 0.1.3 wheel build PASS;
- clean-target install PASS;
- packaged imports for PatentsView / Google Books / Wayback PASS;
- deterministic E3 aggregation fixtures PASS from the installed package;
- sealed installed-wheel A0–A7 conformance remains `29/29 CONFORMANT`.

E3 provider network availability itself is not a deterministic release gate. HTTP availability/rate limits are runtime-health conditions and remain typed evidence failures rather than audit conclusions.

## Pre-closure release-gate evidence

Candidate tree verification before the closure commit:

- unit: 196/196 PASS
- acceptance: 32/32 PASS
- integration: 20/20 PASS (subprocess-heavy files executed separately on this host)
- total automated tests: 248/248 PASS
- `compileall`: PASS
- `git diff --check`: PASS
- candidate wheel `tcft_btap-0.1.3-py3-none-any.whl`: built successfully
- wheel contains PatentsView / Google Books / Wayback provider modules: PASS
- clean-target wheel install: PASS
- installed provider factory/import smoke: PASS
- installed five deterministic E3 aggregation fixtures: PASS
- installed sealed A0–A7 conformance: `CONFORMANT`, 29 checks, 0 blocking failures, 0 required failures

Final-HEAD verification is repeated after the closure commit. Release artifacts are generated only from that verified HEAD.
