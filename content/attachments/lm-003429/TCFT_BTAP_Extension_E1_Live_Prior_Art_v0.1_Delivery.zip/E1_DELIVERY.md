# TCFT-BTAP Extension E1 — Live Prior-Art Providers

Version: runtime package 0.1.1 / protocol v0.1 unchanged  
Date: 2026-09-01  
Branch: `extension/e1-live-prior-art`

## Scope

E1 is a post-MVP extension on top of the sealed `TCFT-BTAP-v0.1-CONFORMANT` runtime. It adds live scholarly retrieval only. It does not change TN/PG/CF/RG/RP/NC formulas, dynamic-frontier semantics, A0–A7 conformance logic, or Anti-Crown governance.

Implemented providers:

- `CrossrefPriorArtProvider`
- `OpenAlexPriorArtProvider`
- `ArxivPriorArtProvider`
- `make_live_provider(...)`
- `live-prior-search` CLI

The existing `InMemoryPriorArtProvider` remains the deterministic offline reference implementation.

## Engineering invariants

1. Provider retrieval is evidence, not novelty judgment.
2. E1 supports `QueryFamily.LEXICAL` only and emits `S1_LEXICAL_OVERLAP` only.
3. Remote date filters are followed by the local TCFT Frozen-Time classifier.
4. Unknown / ambiguous / post-cutoff returned dates are excluded and counted.
5. Scope filtering happens before temporal exclusion counts are reported.
6. HTTP 429 is a typed `PriorArtRateLimitError` with parsed `Retry-After` seconds when available.
7. Other non-2xx responses are typed provider-response errors.
8. Malformed JSON/XML is a typed payload error.
9. Transport failures are not converted into empty-search success.
10. Tests use dependency-injected fixture transports; deterministic conformance never requires internet access.

## Provider contracts

### Crossref

- endpoint: Crossref Works REST API
- query parameter: `query.bibliographic`
- remote cutoff: `until-pub-date:<YYYY-MM-DD>`
- supports optional `mailto`
- sends explicit User-Agent
- local date precision preserves year/month/day uncertainty

### OpenAlex

- endpoint: OpenAlex Works API
- query parameter: `search`
- remote cutoff: `to_publication_date:<YYYY-MM-DD>`
- supports optional API key
- local gate re-checks `publication_date`

### arXiv

- endpoint: arXiv API query endpoint
- query: `all:"..." AND submittedDate:[199101010000 TO <cutoff>]`
- uses Atom `<published>` as first appearance
- preserves `<updated>` only as provenance note
- category terms become domain metadata
- language filtering is explicitly unsupported because the Atom API does not expose reliable language metadata
- cutoffs before 1991 return an empty scoped result without a network request

## Validation evidence before final closure

Fresh regression on the extension tree:

- unit: 144/144 PASS
- acceptance: 22/22 PASS
- integration: 15/15 PASS (subprocess-heavy files run independently where required by the host teardown behavior)
- total: 181/181 PASS

The final packaging gate additionally requires:

- `compileall` PASS
- `git diff --check` PASS
- clean wheel build/install
- wheel imports for Crossref/OpenAlex/arXiv providers
- installed-wheel `conformance-run` remains 29/29 A0–A7 CONFORMANT

## Deliberate limits

E1 does not add:

- automatic retries or a persistent HTTP cache;
- semantic/vector search;
- structural prior-art classification;
- patent/book/web-archive providers;
- LLM query expansion;
- live network availability as a conformance requirement.

Crossref recommends identification, caching, and backoff for production use; arXiv recommends caching and spacing repeated calls. These operational policies remain deployment-level responsibilities after E1's typed transport boundary.
