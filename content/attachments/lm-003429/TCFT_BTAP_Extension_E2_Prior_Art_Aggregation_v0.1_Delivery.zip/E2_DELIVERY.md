# TCFT-BTAP Extension E2 — Multi-Provider Prior-Art Aggregation

Version: runtime package 0.1.2 / protocol v0.1 unchanged
Date: 2026-09-01
Branch: `extension/e2-prior-art-aggregation`

## Scope

E2 is a post-MVP extension on top of E1. It turns independent Crossref, OpenAlex, arXiv, and compatible `PriorArtProvider` results into a conservative canonical evidence network.

E2 adds:

- additive `PriorArtRecord.identifiers` provenance;
- DOI normalization;
- arXiv base/version normalization;
- deterministic union-find aggregation;
- DOI/arXiv cross-provider deduplication;
- provider-local identity fallback;
- transitive DOI↔arXiv bridging;
- title/date/language disagreement records;
- strong-identity conflict detection;
- conservative aggregation confidence components;
- multi-provider COMPLETE/PARTIAL/FAILED coverage semantics;
- typed provider-failure preservation;
- canonical aggregation-result JSON Schema;
- `prior-aggregate` deterministic CLI;
- `live-prior-aggregate` live orchestration CLI;
- E2 synthetic acceptance fixtures.

## Identity invariants

1. DOI and arXiv base identifiers are the only automatic cross-provider merge keys in E2.
2. Title similarity never automatically merges records.
3. Provider-specific aliases are local to the provider for merge purposes.
4. arXiv `v1`, `v2`, etc. share one arXiv base work while retaining version identities.
5. Identifier links are transitive: a DOI+arXiv bridge record may connect DOI-only and arXiv-only evidence.
6. Multiple conflicting DOI or arXiv identities are preserved as `IDENTITY_CONFLICT`; the runtime does not silently select an arbitrary external identifier as truth.

## Temporal invariants

Provider-level Frozen-Time filtering remains in E1. E2 adds cross-provider temporal comparison:

- overlapping intervals -> `CONSENSUS`, using interval intersection;
- one dated evidence source -> `SINGLE_PROVIDER`;
- disjoint intervals -> `CONFLICT` and no canonical consensus time;
- no usable dates -> `UNKNOWN`.

A date conflict is never resolved by choosing the earliest provider date.

## Metadata disagreement

E2 initially records:

- `IDENTITY_CONFLICT`
- `TITLE_CONFLICT`
- `DATE_CONFLICT`
- `LANGUAGE_CONFLICT`

Provider domain/topic taxonomies remain parallel evidence because their category systems are not directly comparable.

## Confidence semantics

Aggregation confidence is evidence confidence, not novelty:

- DOI identity: 1.00
- arXiv base identity: 0.95
- provider-local identity: 0.60
- conflicting strong identity: 0.50
- multi-provider date consensus: up to 1.00
- single-provider date: 0.85
- date conflict: 0.35
- unknown date: 0.00

`overall` is the conservative minimum of identity, temporal, and metadata confidence.

## Coverage / no-match semantics

`no_match_found=True` is legal only when all requested providers completed successfully and the canonical work set is empty.

- all providers succeeded -> `COMPLETE`
- some succeeded and some typed provider calls failed -> `PARTIAL`
- no providers succeeded -> `FAILED`

`PARTIAL` and `FAILED` never become evidence of prior-art nonexistence.

## Deliberate limits

E2 does not add:

- title/embedding based automatic cross-provider merging;
- semantic or structural novelty judgment;
- automatic S2–S5 promotion;
- patent providers;
- book/library providers;
- web-archive providers;
- citation-graph identity inference;
- LLM entity resolution.

Those remain separate extensions so that entity resolution cannot silently alter the sealed novelty/audit semantics.

## Release-gate evidence before closure commit

- unit: 167/167 PASS
- acceptance: 27/27 PASS
- integration: 17/17 PASS (subprocess-heavy legacy files executed separately on this host)
- total automated tests: 211/211 PASS
- `compileall`: PASS
- `git diff --check`: PASS
- wheel build: PASS
- clean-target wheel install: PASS
- packaged aggregation schema/resource import: PASS
- installed-wheel `prior-aggregate`: PASS
- installed-wheel offline `live-prior-aggregate` (arXiv pre-1991): PASS
- installed-wheel sealed A0–A7 conformance: 29/29 CONFORMANT

Final-HEAD verification is repeated after the closure commit; release artifacts are generated only from that verified HEAD.
