# TCFT-BTAP Extension E4 — Search Planner & Evidence Acquisition Graph v0.1

Date: 2026-09-02  
Runtime package: `tcft-btap 0.1.4`  
Base: E3 Heterogeneous Prior-Art Providers  
Branch: `extension/e4-search-planner-evidence-graph`

## Scope

E4 adds a deterministic AI-facing acquisition layer over the six existing E1–E3 prior-art providers. It does not add a seventh provider, change TCFT metric formulas, or introduce a novelty judge.

Canonical path:

```text
ResearchIntent
  -> SearchPlan
  -> EvidenceAcquisitionExecutor
  -> Aggregation Shards
  -> EvidenceGraph
```

## Implemented

- `ResearchIntent`, `SearchStep`, `SearchPlan`.
- `DeterministicSearchPlanner` with provider-specific scope compatibility.
- Exact aggregation-group derivation from query/cutoff/language/domain/family context.
- Explicit `language-scope-unavailable` / `domain-scope-unavailable` warnings.
- Wayback `ARCHIVE_URL` isolation from lexical provider shards.
- `EvidenceGraph` nodes/edges for intent, plan, search steps, provider results/failures, and canonical works.
- Shard-qualified canonical work node IDs.
- `EvidenceAcquisitionExecutor` with provider/result/record context validation.
- Provider transport/capability failures preserved as graph failures.
- Conservative overall and per-shard `COMPLETE/PARTIAL/FAILED` coverage.
- `no_match_found=True` only for COMPLETE acquisition with zero canonical works.
- Packaged `search_plan_v0.1.schema.json` and `evidence_graph_v0.1.schema.json`.
- `search-plan`, `evidence-acquire`, and `live-evidence-acquire` CLI commands.
- E4 deterministic synthetic fixtures.

## Core invariants

```text
LEXICAL != ARCHIVE_URL
Provider Failure != No Match
Missing Scope Support != Silent Scope Drop
Incompatible Aggregation Shards != Automatic Graph Merge
Result Context != Trusted Without Validation
Record Provider/Family != Trusted Without Validation
Evidence Acquisition != Novelty Judgment
```

## Static planner boundary

E4 v0.1 is deliberately static and deterministic. It does not use search results to rewrite later queries, discover new archive targets, or create adaptive search loops. Adaptive planning belongs to a later extension after the acquisition graph is proven stable.

## Candidate release verification

Source-tree tests on the 0.1.4 release candidate:

```text
Unit        217 / 217 PASS
Acceptance   37 / 37 PASS
Integration  23 / 23 PASS
---------------------------
Total       277 / 277 PASS
```

Candidate packaging:

```text
compileall                         PASS
git diff --check                  PASS
0.1.4 wheel build                 PASS
clean-target install              PASS
search_plan.py packaged           PASS
acquisition.py packaged           PASS
evidence_graph.py packaged        PASS
search_plan_v0.1.schema.json      PASS
evidence_graph_v0.1.schema.json   PASS
installed search-plan smoke       PASS
installed evidence-acquire smoke  PASS
installed A0-A7 conformance       29 / 29 CONFORMANT
blocking failures                 0
required failures                 0
```

Candidate wheel SHA-256:

`3b0543345958f3913693fecb590f9d697d8eb9bea560cb55888b9ff0f7d70cde`

## E4 fixture semantics

- `planner_with_wayback.json`: lexical and archive steps produce separate aggregation groups.
- `language_scope_split.json`: arXiv/PatentsView language-filter limitations are explicit and shard-separated.
- `partial_provider_failure.json`: one provider failure produces PARTIAL and cannot claim no-match.
- `complete_no_match.json`: all successful empty providers may claim no-match.
- `mixed_lexical_archive_graph.json`: DOI-backed lexical work and digest-backed Wayback capture coexist in one graph without force-merging.

## Live acquisition

`live-evidence-acquire` builds only the providers required by the generated plan. Missing PatentsView credentials, 429 responses, malformed provider payloads, or network failures remain typed graph failures. Live network availability is not a deterministic release criterion.

## Next boundary

The next extension should be adaptive only after E4 is sealed. A future planner may consume the E4 evidence graph and propose new queries/targets, but it must preserve explicit action provenance, budgets, stop rules, and query-semantic boundaries instead of mutating the current plan invisibly.
