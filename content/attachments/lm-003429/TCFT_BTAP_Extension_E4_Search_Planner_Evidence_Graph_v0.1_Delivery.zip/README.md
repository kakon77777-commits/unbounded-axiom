# TCFT-BTAP Reference MVP v0.1 — FINAL / SEALED

Reference implementation of the **TCFT Benchmark & Temporal Audit Protocol v0.1**, closed end-to-end through Phase 0–4 plus FINAL MVP conformance.

Phase 0 established the protocol kernel. Phase 1 added deterministic date-bounded prior art and contamination-aware baseline ensembles. Phase 2 added baseline-relative **TN / PG / CF / RG** functional metrics. Phase 3 added experimental **RP / NC** structural metrics. Phase 4 now composes those baseline-relative results into a dynamic, multidimensional frontier with Pareto membership, historical/current separation, agent/artifact persistence, frontier entry/exit events, and append-only frontier revision lineage.

The sealed v0.1 conformance core remains deterministic and does not require live network, LLM providers, historical-person showcases, or UI. Post-MVP extensions E1–E4 add optional live/heterogeneous prior-art adapters plus an auditable search-planning and evidence-acquisition graph layer without changing sealed scoring or A0–A7 conformance semantics.

## Implemented through Phase 4

### Phase 0 — Protocol kernel

- Canonical TCFT audit JSON Schema validation.
- SHA-256 provenance hashing.
- Frozen-Time eligibility.
- Candidate-blind contamination classes `C0`–`C4`.
- Append-only audit ledger.
- Anti-Crown governance checks.
- B0 synthetic protocol fixtures.

### Phase 1 — Prior art + baseline ensemble

- `PriorArtProvider` contract and deterministic in-memory provider.
- Frozen-Time prior-art filtering.
- Query-family and S0–S5 match metadata.
- Contamination-aware heterogeneous baseline ensemble.
- Explicit candidate-blind primary eligibility.

### Phase 2 — Functional metrics

- Common `MetricPlugin` / `MetricResult` contract.
- Complete primary-baseline coverage and common-cutoff gate.
- `TN`, `PG`, `CF`, `RG` reference metrics.
- `metric-score` CLI.

### Phase 3 — Structural metrics

- Native Operator Recovery.
- Program Topology Recovery.
- Operational Equivalence Audit.
- Guarded Domain-Seed Recovery (`SEED` / `CANDIDATE` only).
- Experimental `RP` / `NC` metrics.

### Phase 4 — Dynamic frontier

- `FrontierProfile` / `FrontierPolicy`.
- Stable default frontier dimensions: `TN`, `PG`, `CF`, `RG`.
- Explicit RP/NC experimental opt-in.
- Missing/unresolved required dimensions => ineligible, never zero.
- Pareto frontier with no mandatory scalar champion/rank.
- Cohort guards: common time, baseline, track, and one profile per subject.
- Historical/current absorption and expansion comparison.
- Separate artifact persistence and agent persistence.
- Frontier `ENTRY` / `EXIT` / `STAY_IN` / `STAY_OUT` events.
- Append-only `DynamicFrontierLedger`.
- Canonical frontier-result JSON Schema.
- `frontier-run` CLI and Phase 4 synthetic fixtures.


## Extension E1 — Live prior-art providers

Runtime package `0.1.1` adds optional live retrieval adapters for:

- Crossref REST Works
- OpenAlex Works API
- arXiv API

The providers implement the existing `PriorArtProvider` contract. They perform remote date-bounded queries and then re-apply the local Frozen-Time gate. E1 retrieval evidence is deliberately limited to `QueryFamily.LEXICAL` / `S1_LEXICAL_OVERLAP`; semantic, structural, operational, and novelty judgments remain downstream audit responsibilities.

Example:

```bash
PYTHONPATH=src python -m tcft_btap.cli live-prior-search crossref \
  "feedback control" \
  --cutoff 1950-01-01T00:00:00+00:00 \
  --limit 10 \
  --mailto audit@example.org

PYTHONPATH=src python -m tcft_btap.cli live-prior-search openalex \
  "counterfactual reasoning" \
  --cutoff 2020-01-01T00:00:00+00:00 \
  --limit 10

PYTHONPATH=src python -m tcft_btap.cli live-prior-search arxiv \
  "emergent communication" \
  --cutoff 2024-01-01T00:00:00+00:00 \
  --limit 10
```

Network, provider, malformed-payload, and rate-limit failures are typed errors. They are never converted into `no_match_found=True`. Live provider availability is a runtime-health concern, not a condition of deterministic TCFT-BTAP conformance.

## Extension E2 — Multi-provider prior-art aggregation

Runtime package `0.1.2` adds a conservative aggregation layer above E1 providers. Cross-provider automatic deduplication is restricted to strong DOI/arXiv identity evidence; title-only similarity never merges works. The aggregation layer preserves per-provider evidence, identity/title/date/language conflicts, evidence-confidence components, and COMPLETE/PARTIAL/FAILED provider coverage.

Examples:

```bash
PYTHONPATH=src python -m tcft_btap.cli prior-aggregate \
  benchmarks/b0_synthetic/e2/fixtures/doi_cross_provider_dedup.json

PYTHONPATH=src python -m tcft_btap.cli live-prior-aggregate \
  "feedback control" \
  --provider crossref --provider openalex --provider arxiv \
  --cutoff 2024-01-01T00:00:00+00:00
```

Important semantics:

```text
Strong Identifier Merge != Title Similarity Merge
Provider Disagreement != Automatic Provider Selection
PARTIAL/FAILED Coverage != No Prior Art Found
Aggregation Confidence != Novelty Score
```

See `E2_DELIVERY.md`.

## Extension E3 — Heterogeneous prior-art providers

Runtime package `0.1.3` expands the E2 evidence network beyond scholarly papers with conservative adapters for:

- PatentsView pre-grant US publication metadata (`publication_date`)
- Google Books volume metadata (`publishedDate`)
- Internet Archive Wayback CDX capture metadata (`timestamp`)

All E3 adapters continue to emit `S1_LEXICAL_OVERLAP`-level retrieval evidence only. PatentsView requires an API key and missing credentials are reported as capability unavailable, never as no prior art. Google Books has no remote publication-date cutoff in the reference adapter, so local Frozen-Time validation is mandatory. Wayback uses `QueryFamily.ARCHIVE_URL` and records capture existence/digest metadata without claiming that archived page content was inspected.

Heterogeneous strong identities now include normalized ISBN-10/13, US pre-grant publication numbers, and explicit web content digests. URL/title similarity alone never merges records. Wayback URL queries are intentionally incompatible with lexical scholarly/book/patent queries in one `live-prior-aggregate`; issue provider-appropriate searches separately and aggregate their `PriorArtSearchResult` evidence.

Examples:

```bash
PYTHONPATH=src python -m tcft_btap.cli live-prior-search patentsview \
  "feedback control" \
  --cutoff 2005-01-01T00:00:00+00:00 \
  --patentsview-api-key "$PATENTSVIEW_API_KEY"

PYTHONPATH=src python -m tcft_btap.cli live-prior-search googlebooks \
  "cybernetics" \
  --cutoff 1960-01-01T00:00:00+00:00

PYTHONPATH=src python -m tcft_btap.cli live-prior-search wayback \
  "https://example.org/page" \
  --cutoff 2010-01-01T00:00:00+00:00

PYTHONPATH=src python -m tcft_btap.cli prior-aggregate \
  benchmarks/b0_synthetic/e3/fixtures/isbn_cross_provider_dedup.json
```

See `E3_DELIVERY.md`.

## Extension E4 — Heterogeneous search planner + evidence acquisition graph

Runtime package `0.1.4` adds a deterministic AI-facing acquisition layer over the six existing prior-art providers. A structured `ResearchIntent` is compiled into provider-compatible `SearchStep` objects, exact aggregation shards, and then an `EvidenceGraph` that preserves provider successes/failures and canonical E2/E3 works.

Core semantics:

```text
ResearchIntent -> SearchPlan -> AcquisitionExecution -> EvidenceGraph
LEXICAL != ARCHIVE_URL
Provider Failure != No Match
Missing Provider Scope Support != Silent Scope Drop
Same Identifier Across Incompatible Shards != Automatic Graph Merge
```

Planner defaults target Crossref, OpenAlex, arXiv, PatentsView, and Google Books. Wayback steps are created only for explicit archive targets. arXiv/PatentsView language-filter limitations are represented as plan warnings and separate aggregation shards rather than silently discarding the requested scope.

Examples:

```bash
PYTHONPATH=src python -m tcft_btap.cli search-plan \
  benchmarks/e4_search_planner/fixtures/planner_with_wayback.json

PYTHONPATH=src python -m tcft_btap.cli evidence-acquire \
  benchmarks/e4_search_planner/fixtures/mixed_lexical_archive_graph.json
```

`live-evidence-acquire` executes the same plan through live provider adapters. Network/capability failures remain typed failure nodes in the graph and do not become `no_match_found=True`.

See `E4_DELIVERY.md`.

## FINAL MVP closure

The reference now includes deterministic end-to-end orchestration and machine-readable A0–A7 conformance:

```bash
PYTHONPATH=src python -m tcft_btap.cli closure-run \
  benchmarks/closure/fixtures/canonical_initial_revision.json \
  --workdir /tmp/tcft-closure

PYTHONPATH=src python -m tcft_btap.cli conformance-run
```

Canonical packaged result: `TCFT-BTAP-v0.1-CONFORMANT` when the installed wheel reports all 29 A0–A7 checks passing. See `FINAL_MVP_DELIVERY.md` and `docs/FINAL_CONFORMANCE_REPORT.md`.

## Run tests

Use the current source tree explicitly:

```bash
PYTHONPATH=src PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest tests/unit -q
```

For this host, subprocess-heavy acceptance/integration files are safest when run per file because unrelated third-party pytest/ddtrace teardown may keep a long combined shell process alive after tests have already completed.

## CLI

### Validate audit record

```bash
PYTHONPATH=src python -m tcft_btap.cli validate audit.json
```

### Run protocol B0 fixture

```bash
PYTHONPATH=src python -m tcft_btap.cli b0 \
  benchmarks/b0_synthetic/fixtures/clean_case.json
```

### Prior-art search

```bash
PYTHONPATH=src python -m tcft_btap.cli prior-search \
  benchmarks/b0_synthetic/phase1/fixtures/prior_art_pre_cutoff.json \
  "feedback control" \
  --cutoff 1950-01-01T00:00:00+00:00 \
  --language en \
  --domain systems \
  --family lexical
```

### Baseline validation

```bash
PYTHONPATH=src python -m tcft_btap.cli baseline-check \
  benchmarks/b0_synthetic/phase1/fixtures/baseline_clean_ensemble.json
```

### Metric scoring

```bash
PYTHONPATH=src python -m tcft_btap.cli metric-score \
  benchmarks/b0_synthetic/phase2/fixtures/tn_substantive_prior_art.json

PYTHONPATH=src python -m tcft_btap.cli metric-score \
  benchmarks/b0_synthetic/phase3/fixtures/rp_program_ahead.json
```

### Dynamic frontier

```bash
PYTHONPATH=src python -m tcft_btap.cli frontier-run \
  benchmarks/b0_synthetic/phase4/fixtures/pareto_multi_frontier.json

PYTHONPATH=src python -m tcft_btap.cli frontier-run \
  benchmarks/b0_synthetic/phase4/fixtures/historical_current_absorption.json

PYTHONPATH=src python -m tcft_btap.cli frontier-run \
  benchmarks/b0_synthetic/phase4/fixtures/agent_persistence.json

PYTHONPATH=src python -m tcft_btap.cli frontier-run \
  benchmarks/b0_synthetic/phase4/fixtures/frontier_entry_exit.json
```

## Phase 4 core rule

The frontier engine consumes already-audited, baseline-relative metric results:

```text
MetricResult.normalized_score
```

It does not bypass prior-art, Frozen-Time, contamination, or primary-baseline checks.

Default Pareto dimensions:

```text
TN / PG / CF / RG
```

`RP / NC` participate only through explicit experimental opt-in.

## No champion rule

The canonical frontier result contains no `rank` or `champion` field.

Multiple non-dominated subjects are expected:

```text
Frontier != Leaderboard
```

## Missing data rule

```text
Missing != Zero
```

If a required dimension is missing, unresolved, or below the configured confidence threshold, the profile is reported as ineligible rather than zero-filled.

## Historical / current / persistent separation

```text
Historical Anomaly != Current Anomaly != Persistent Frontier
Artifact Persistence != Agent Persistence
```

A current baseline may absorb a historical gap without retroactively rewriting the historical profile.

## Deliberately not implemented

- Additional provider classes beyond the E3 reference set (for example library catalogs, patent families outside the PatentsView reference adapter, archived-content replay/parsing, or code indexes).
- Semantic/title-similarity automatic entity merging across providers.
- LLM/API baseline providers.
- Historical celebrity/person cases.
- UI or person leaderboard.
- Production-calibrated metric weights.
- Automatic promoted cognitive domains.
- Production-calibrated model-assisted RP/NC recovery.
- Mandatory global scalar ranking.

## Canonical specs and plans

See `docs/spec/` and:

- `docs/superpowers/plans/2026-08-31-tcft-btap-phase0-protocol-kernel.md`
- `docs/superpowers/plans/2026-08-31-tcft-btap-phase1-prior-art-baseline.md`
- `docs/superpowers/plans/2026-08-31-phase2-functional-metrics.md`
- `docs/superpowers/plans/2026-08-31-phase3-structural-metrics.md`
- `docs/superpowers/plans/2026-08-31-phase4-dynamic-frontier.md`

## Next boundary

The Reference MVP is closed. Extensions E1–E3 now supply live scholarly retrieval, conservative multi-provider aggregation, and patent/book/web-archive evidence adapters. Future work should continue as post-MVP extensions (historical case packs, stable BS/RR metrics, RP/NC calibration, archived-content inspection, additional catalog/patent sources, visualization, or TCO/ACO adapters), not as an automatic Phase 5.
