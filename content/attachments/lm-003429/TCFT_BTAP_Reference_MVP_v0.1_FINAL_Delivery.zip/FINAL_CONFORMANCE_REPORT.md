# TCFT-BTAP Reference MVP v0.1 — FINAL Conformance Report

Date: 2026-09-01  
Scope: Phase 0–4 + MVP Closure / End-to-End Conformance  
Code-complete pre-documentation HEAD: `ddbe524`  
Protocol: `TCFT Benchmark & Temporal Audit Protocol v0.1`

## Result

Packaged-wheel conformance result:

```text
status: CONFORMANT
passed_checks: 29/29
failed_checks: 0
blocking_failed: 0
required_failed: 0
```

The canonical controlled closure case was executed from an installed wheel outside the source tree. It produced two append-only audit/frontier revisions:

```text
initial -> HISTORICAL_FRONTIER_CANDIDATE / INITIAL
revised -> NORMAL / DOWN
```

The downgrade is caused by a controlled substantive-prior-art injection plus refreshed contemporaneous baseline. The fixture cannot self-declare the revision direction; the closure runtime derives `DOWN` from componentwise stable-dimension gap changes.

## A0–A7 Matrix

| ID | Severity | Result | Runtime Evidence |
|---|---|---|---|
| A0-01 | BLOCKING | PASS | initial and revised canonical audits validate |
| A0-02 | REQUIRED | PASS | source SHA-256 and archive refs preserved |
| A0-03 | BLOCKING | PASS | duplicate append rejected; existing two-line ledger unchanged |
| A1-01 | BLOCKING | PASS | post-cutoff source rejected |
| A1-02 | REQUIRED | PASS | cross-cutoff interval flagged TEMPORALLY_AMBIGUOUS |
| A1-03 | BLOCKING | PASS | post-outcome leakage recall=1.00 (20 synthetic injections) |
| A2-01 | BLOCKING | PASS | prompt leakage classified C3 |
| A2-02 | BLOCKING | PASS | retrieval exposure classified C2 |
| A2-03 | BLOCKING | PASS | C2/C3/C4 all rejected from primary baseline |
| A2-04 | REQUIRED | PASS | C1 exposure retained only with explicit risk-accepted warning |
| A3-01 | BLOCKING | PASS | TN residual decreased 0.6 -> -0.4 after S5 prior art |
| A3-02 | BLOCKING | PASS | no-match remains retrieval statement, never nonexistence claim |
| A3-03 | REQUIRED | PASS | provider/language/domain/date/query-family coverage preserved |
| A4-01 | BLOCKING | PASS | new prior art/baseline lowers frontier status |
| A4-02 | REQUIRED | PASS | earlier verified version increases lead seconds 31536000.0 -> 315619200.0 |
| A4-03 | BLOCKING | PASS | conflicting evidence can append an UNRESOLVED revision |
| A4-04 | REQUIRED | PASS | revision lineage preserves previous_audit_id |
| A5-01 | BLOCKING | PASS | selection-adjusted frontier rate changes 1.00 -> 0.50 when a miss is added |
| A5-02 | BLOCKING | PASS | known failures retained and marked visible |
| A5-03 | REQUIRED | PASS | high output volume with one hit does not automatically imply high frontier rate |
| A6-01 | BLOCKING | PASS | capability and evidence profiles are separate records |
| A6-02 | BLOCKING | PASS | missing BS/RR remain UNRESOLVED/None, never zero |
| A6-03 | REQUIRED | PASS | Pareto result allows multiple frontier subjects and exposes no rank |
| A6-04 | BLOCKING | PASS | historical/current profiles remain separate and revision is ABSORBED |
| A6-05 | REQUIRED | PASS | agent and artifact persistence are represented by distinct track semantics |
| A7-01 | BLOCKING | PASS | no global person leaderboard/rank required by core result |
| A7-02 | BLOCKING | PASS | cognitive outputs contain no identity-confirmation shortcut |
| A7-03 | BLOCKING | PASS | baseline, evidence, and failures are present in sealed audit |
| A7-04 | BLOCKING | PASS | identity remains a claim under subject metadata and is absent from capability dimensions |

## Closure Path Exercised

```text
source/provenance
-> Frozen-Time cutoff
-> prior-art retrieval
-> contamination-aware baseline ensemble
-> TN / PG / CF / RG metric execution
-> capability/evidence separation
-> Pareto frontier placement
-> append-only audit ledger
-> append-only frontier ledger
-> stronger-evidence revision
-> automatic DOWN classification
-> frontier absorption/exit
```

## Closure Gap Found and Repaired

The FINAL conformance audit identified one real blocking gap from the original A0–A7 matrix: A5-01 required a selection-adjusted output to change when missed predictions are added, while the Phase 4 runtime preserved failures but did not yet expose a deterministic selection-correction summary.

FINAL closure adds a deliberately narrow `SelectionCorrection` contract:

```text
audited_outputs
frontier_hits
known_failures
frontier_hit_rate
```

It does **not** alter TN/PG/CF/RG formulas. Its only role is to prevent a hit-only presentation from being mistaken for a selection-adjusted profile.

## Stable and Experimental Boundaries

Stable final frontier dimensions:

```text
TN / PG / CF / RG
```

Not forced into stable closure:

```text
BS / RR -> UNRESOLVED in canonical closure profile
RP / NC -> separately implemented EXPERIMENTAL structural metrics
```

`DomainSeedStatus` remains limited to `SEED` / `CANDIDATE`; FINAL does not add automatic Domain promotion.

## Governance Boundary

The FINAL runtime retains the TCFT-09 constraints:

- no mandatory global person leaderboard;
- no `rank` or required unique champion in Pareto output;
- identity claims stay subject metadata and do not enter capability dimensions;
- no cognitive-score shortcut to `TIME_TRAVELER_CONFIRMED`, `SUPERIOR_PERSON`, or political/moral authority;
- known failures, baseline, evidence, and revision lineage remain visible.

## Known Non-Goals / Post-MVP Work

FINAL v0.1 deliberately does not include:

- live scholarly, patent, book, or web-archive providers;
- LLM/API baseline providers;
- production-calibrated metric weights;
- historical celebrity showcase cases;
- automatic promoted cognitive domains;
- production-grade RP/NC recovery;
- UI or person leaderboard;
- stable BS/RR reference metrics.

These are post-MVP extensions, not blockers for the reference protocol closure.

## Release Claim

If the final repository HEAD reproduces the source-tree tests, compile check, clean wheel build/install, packaged resource check, `closure-run`, and `conformance-run`, the delivery may be labeled:

```text
TCFT-BTAP Reference MVP v0.1 — FINAL / SEALED
TCFT-BTAP-v0.1-CONFORMANT
```
