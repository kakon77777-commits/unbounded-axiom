# TCFT-BTAP Reference MVP v0.1 — FINAL / SEALED Handoff

Date: 2026-09-01  
Series: Temporal Cognitive Frontier Theory (TCFT)  
Protocol: TCFT Benchmark & Temporal Audit Protocol v0.1

## Closure Status

The original Phase 0–4 roadmap is implemented and the separate MVP Closure layer now composes it end-to-end.

Implemented lineage:

```text
Phase 0  Protocol Kernel
Phase 1  Prior Art + Baseline Ensemble
Phase 2  Functional Metrics (TN / PG / CF / RG)
Phase 3  Structural Metrics (RP / NC, experimental)
Phase 4  Dynamic Frontier Engine
FINAL    End-to-End Closure + A0–A7 Conformance
```

## FINAL Runtime Additions

- `tcft_btap.closure`
  - composes existing Phase 0–4 public contracts;
  - produces canonical audit records;
  - writes append-only audit and frontier ledgers;
  - derives revision direction from stable metric gaps;
  - does not implement new cognitive scoring logic.
- `tcft_btap.conformance`
  - executes 29 named A0–A7 checks without shelling out to pytest;
  - validates its own machine-readable conformance result schema.
- `tcft_btap.correction.SelectionCorrection`
  - closes A5-01 selection-bias accounting;
  - does not modify metric formulas.
- CLI:
  - `tcft-btap closure-run ...`
  - `tcft-btap conformance-run`

## Canonical End-to-End Fixture

`benchmarks/closure/fixtures/canonical_initial_revision.json`

The controlled fixture deliberately demonstrates revision sensitivity:

```text
1950 initial:
  candidate remains Pareto-frontier candidate

1960 revised:
  substantive S5 prior art + refreshed baseline
  TN gap falls
  peer dominates stable dimensions
  candidate leaves frontier
  revision_direction = DOWN (derived by runtime)
```

The fixture retains a synthetic identity claim only as `CLAIM_ONLY`; it does not affect capability dimensions.

## Required FINAL Verification

From the sealed source tree:

```bash
PYTHONPATH=src PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest tests/unit -q
PYTHONPATH=src PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest tests/acceptance -q
```

Integration files should be executed independently on this host because long chains of subprocess-heavy pytest files can trigger an unrelated container teardown timeout.

Build/install:

```bash
python -m compileall -q src
python -m pip wheel . --no-build-isolation --no-deps -w <wheel-dir>
python -m pip install --no-deps --target <clean-target> <wheel>
```

Installed-wheel closure:

```bash
PYTHONPATH=<clean-target> python -m tcft_btap.cli closure-run \
  benchmarks/closure/fixtures/canonical_initial_revision.json \
  --workdir <closure-workdir>

PYTHONPATH=<clean-target> python -m tcft_btap.cli conformance-run
```

Expected packaged conformance:

```text
CONFORMANT
29/29 A0–A7 checks PASS
0 blocking failures
0 required failures
```

## Canonical FINAL Boundaries

- stable frontier: `TN / PG / CF / RG`;
- `RP / NC`: experimental only unless explicitly opted in;
- `BS / RR`: not falsely zero-filled when unmeasured;
- `Missing != Zero`;
- `Frontier != Leaderboard`;
- `Artifact Persistence != Agent Persistence`;
- `Historical != Current != Persistent`;
- `Capability != Identity != Authority`;
- revision is append-only and can move a result down or unresolved;
- automatic promoted cognitive domains remain prohibited.

## Post-MVP Boundary

Do not call the next work “Phase 5” by default. Future work should be scoped as a separate extension track, for example:

- provider integrations;
- historical evaluation packs;
- stable BS/RR metrics;
- RP/NC calibration;
- visualization / case explorer;
- TCO / ACO integration adapters.

The Reference MVP is intentionally closed before those extensions.
