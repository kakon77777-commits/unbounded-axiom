# RSCT Semantic Analyzer Runtime MVP v0.2

**Current extension:** AI-facing Semantic Middleware + Reasoning Trace Audit + Agent Semantic Gate.

A deterministic reference MVP for **Relational Semantic Construction Theory (RSCT)**. It expands controlled natural-language inputs into typed semantic graphs, preserves reference/construction provenance, detects path-generated self-reference, and analyzes finite fixed-point contracts without letting a language model decide invariants or truth-domain results.

## Scope

v0.2 deliberately supports a controlled benchmark set rather than arbitrary natural language. Unsupported inputs return `PARTIAL`; unknown states are never silently converted to `false`.

Canonical invariants include:

- Surface Form != Semantic Type
- Construction != Projection != Evaluation
- Orientation != Negation
- Evidence != Truth
- Claim != Truth
- BeliefState != Truth
- MemoryRecord != BeliefState
- Inference != Truth
- Observation != Truth
- Role != Identity
- Difference != Tension != Metric
- Boundary != Truth Label
- Type Safety != Fixed-Point Existence

## Install

```bash
python -m pip install -e . --no-build-isolation
```

Python 3.11+ is required.

## CLI

```bash
rsct analyze "這句話是假的。"
rsct analyze --json "這句話是假的。"
rsct graph "這句話是假的。"
rsct assumptions "這句話是假的。"
rsct analyze --set TOTAL_BIVALENCE=false --json "這句話是假的。"
rsct audit-ai tests/ai_contracts/evidence_to_truth_illegal.json
rsct audit-ai --json tests/ai_contracts/legal_evidence_claim_evaluation.json
rsct audit-ai-trace tests/ai_traces/legal_reasoning_trace.json
rsct audit-ai-trace --json --repair-plan tests/ai_traces/evidence_to_truth_cross_step.json
rsct gate-ai --json tests/gate_contracts/block_evidence_to_truth.json
rsct gate-ai-trace --json tests/ai_traces/evidence_to_truth_cross_step.json
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine gate --json
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine passthrough --json
rsct benchmark-score benchmarks/semantic_error_v0.1/cases.jsonl model_predictions.jsonl --json
rsct experiment-reference-agent benchmarks/semantic_error_v0.1/cases.jsonl --provider scripted --max-repairs 1 --json
```

The classical liar profile reports:

```text
Self-reference: YES
False predicate: YES
Active truth domain: {T,F}
Fixed-point equation: v = N(v)
Fixed-point status: NO_FIXED_POINT
Conclusion: No stable value exists under the active semantic contract.
```

This means the active bivalent contract has no stable fixed point. It does **not** assert that the world is contradictory or that RSCT has eliminated the liar paradox.

## Controlled canonical scenarios

1. `雪是白的。` — ordinary truth-bearer construction.
2. `這句話是中文。` — harmless path-generated self-reference.
3. `這句話是假的。` — classical liar fixed-point obstruction.
4. `「雪是黑的」是假的。` — external false predicate without self-reference.
5. `他說過謊，所以他就是永遠的說謊者。` — role-to-identity escalation candidate.
6. `A 照顧 B，但 B 管理 A。` — bidirectional heterogeneous relation pair.
7. `有研究支持 P，也有研究反對 P。` — evidence polarity preserved without automatic truth assignment.

## Architecture

```text
Input
  -> controlled SurfaceIR
  -> typed SemanticGraphIR
  -> reference / generative-reflexivity analysis
  -> evaluation contract
  -> deterministic finite fixed-point analyzer
  -> reproducible evidence report
```

Key modules:

- `model.py` — typed IR, statuses, failure codes.
- `parser.py` — controlled rule-based surface parser.
- `semantic.py` — typed semantic graph construction.
- `reference.py` — path-generated self-reference detection.
- `fixedpoint.py` — deterministic finite-domain fixed-point and cycle analysis.
- `evaluation.py` — symbolic tension adapter and fail-closed boundary contract.
- `analyzer.py` — end-to-end orchestration and assumption mutation.
- `reporting.py` — JSON/text evidence serialization.
- `ai_contract.py` — structured AI semantic-contract loading and validation.
- `audit.py` — deterministic AI semantic-collapse audit and repair hints.
- `middleware.py` — AI-facing single-contract and reasoning-trace audit entry point.
- `trace.py` — strict ordered reasoning-trace contract loader.
- `trace_audit.py` — per-step aggregation and cross-step semantic-collapse detection.
- `repair.py` — deterministic non-mutating localized repair plans.
- `gate.py` — deterministic PASS/WARN/BLOCK/DEFER continuation decisions and localized repair actions.
- `benchmark.py` — canonical benchmark loading, Gate/pass-through execution, metrics, and external-prediction scoring.
- `experiment.py` — provider-neutral A/B reference-agent experiment runner and metrics.
- `reference_agent.py` — scripted and external-replay reference-agent providers.
- `cli.py` — analyze/graph/assumptions/audit/gate/benchmark interfaces.


## AI-facing Semantic Middleware

The AI-facing path accepts an explicit typed graph rather than treating model text as truth. A normal evaluation path is:

```text
Evidence -> Claim -> Evaluation -> TruthValueLabel
```

The deterministic audit flags direct semantic collapses including `Evidence -> Truth`, `Claim -> Truth`, `BeliefState -> Truth`, `Inference -> Truth`, `Observation -> Truth`, `MemoryRecord -> BeliefState`, and role-to-identity escalation. Findings include edge-local repair guidance and never mutate the submitted graph.

Seven canonical AI contracts live in `tests/ai_contracts/`. The contract format is documented in `docs/reference/RSCT_AI_Semantic_Middleware_Contract_v0.1.md`.

## AI reasoning trace audit

`audit-ai` validates one semantic graph. `audit-ai-trace` validates an ordered series of individually typed graphs plus explicit cross-step carry-over references. This catches semantic collapse that appears only after state is persisted or reused across Agent steps.

Canonical cross-step checks cover `EvidenceState -> TruthValueLabel`, `Claim -> TruthValueLabel`, `BeliefState -> TruthValueLabel`, `Inference -> TruthValueLabel`, `Observation -> TruthValueLabel`, `MemoryRecord -> BeliefState`, and `Role -> Identity`. The last is warning-level; the others are error-level.

A trace can optionally request a deterministic non-mutating repair plan:

```bash
rsct audit-ai-trace --json --repair-plan tests/ai_traces/evidence_to_truth_cross_step.json
rsct gate-ai --json tests/gate_contracts/block_evidence_to_truth.json
rsct gate-ai-trace --json tests/ai_traces/evidence_to_truth_cross_step.json
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine gate --json
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine passthrough --json
rsct benchmark-score benchmarks/semantic_error_v0.1/cases.jsonl model_predictions.jsonl --json
rsct experiment-reference-agent benchmarks/semantic_error_v0.1/cases.jsonl --provider scripted --max-repairs 1 --json
```

The repair plan localizes the failing carry-over and suggests actions such as `INSERT_EVALUATION`, `PRESERVE_AS_CLAIM`, `REVALIDATE_MEMORY`, or `KEEP_ROLE_SCOPED`. It never edits the submitted trace.

Eight canonical reasoning traces live in `tests/ai_traces/`. The format is documented in `docs/reference/RSCT_AI_Reasoning_Trace_Contract_v0.1.md`.

## Agent Semantic Gate v0.2

`audit-ai` and `audit-ai-trace` explain semantic findings. The v0.2 gate layer reduces those deterministic findings into an Agent continuation decision without changing the submitted graph or trace.

```text
ERROR finding => BLOCK
WARNING-only  => WARN
No findings   => PASS
Invalid input => DEFER
```

`PASS` and `WARN` return CLI exit code `0`; `BLOCK` returns `1`; `DEFER` returns `2`. Every result includes failure codes, localized repair actions, active gate assumptions, and deterministic decision provenance.

```bash
rsct gate-ai contract.json
rsct gate-ai --json contract.json
rsct gate-ai-trace trace.json
rsct gate-ai-trace --json trace.json
```

The gate does not infer truth and does not auto-apply repairs. `BLOCK` means only that the submitted semantic state must not continue under the active RSCT semantic-safety policy.

Canonical gate fixtures live in `tests/gate_contracts/`. The contract is documented in `docs/reference/RSCT_Agent_Semantic_Gate_Contract_v0.2.md`.

## Semantic Error Benchmark v0.1

`benchmarks/semantic_error_v0.1/cases.jsonl` contains 88 controlled canonical cases across 22 semantic categories. The bundled runner compares RSCT Gate v0.2 with an explicit pass-through control and can score externally generated model/Agent prediction JSONL.

Current canonical conformance result: RSCT Gate matches 88/88 expected decisions/codes/repair actions. The pass-through control has 22.73% exact decision accuracy and 0% BLOCK/WARN recall. These are **in-distribution conformance results**, not external LLM efficacy evidence. See `benchmarks/semantic_error_v0.1/RSCT_SEMANTIC_ERROR_BENCHMARK_REPORT_v0.1.md`.

## Reference Agent Integration Experiment v0.1

`experiment-reference-agent` runs an A/B harness over the frozen semantic benchmark. Arm A accepts the provider's first output without RSCT. Arm B gates the same output, requests repair on `BLOCK`, preserves `WARN`, and stops on `DEFER`.

```bash
rsct experiment-reference-agent benchmarks/semantic_error_v0.1/cases.jsonl --provider scripted --max-repairs 1 --json
rsct experiment-reference-agent benchmarks/semantic_error_v0.1/cases.jsonl --provider replay --replay external_agent_outputs.jsonl --max-repairs 1 --json
```

The built-in scripted provider validates orchestration only and is explicitly marked `external_model_evidence=false`. `ReplayReferenceAgent` is the provider-neutral entry point for real external-model initial and repair outputs. See `experiments/reference_agent_v0.1/REPORT.md`.

## LLM boundary

The MVP does not require an LLM. A future LLM integration may propose parse or type candidates, but the contract remains:

**LLM proposes; RSCT Core validates.**

Type safety, invariant checks, fixed-point status, and declared projection loss remain deterministic-core responsibilities.

## Testing

```bash
pytest -q
```

Golden outputs are stored in `tests/golden/` and are compared byte-semantically as JSON objects on every regression run.

## Canonical references

- `docs/reference/RSCT_Formal_Specification_v0.1_2026-08-28.md`
- `docs/reference/RSCT_Semantic_Analyzer_Runtime_Technical_Whitepaper_v0.1_2026-08-28.md`
- `docs/reference/RSCT_AI_Semantic_Middleware_Contract_v0.1.md`
- `docs/reference/RSCT_AI_Reasoning_Trace_Contract_v0.1.md`
- `docs/reference/RSCT_Agent_Semantic_Gate_Contract_v0.2.md`
- `docs/superpowers/plans/2026-08-28-rsct-semantic-analyzer-runtime-mvp.md`
- `docs/superpowers/plans/2026-08-28-rsct-ai-semantic-middleware-extension.md`
- `docs/superpowers/plans/2026-08-28-rsct-ai-reasoning-loop-extension.md`
