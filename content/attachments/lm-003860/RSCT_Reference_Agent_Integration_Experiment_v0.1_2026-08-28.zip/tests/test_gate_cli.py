import json

from rsct.cli import main


def _contract(source_type="EvidenceState", target_type="TruthValueLabel"):
    return {
        "version": "0.1",
        "nodes": [
            {"id": "s", "type": source_type, "provenance": "agent:s1"},
            {"id": "t", "type": target_type, "provenance": "agent:s1"},
        ],
        "edges": [{"id": "e", "source": "s", "target": "t", "type": "TYPE_COERCION"}],
    }


def _trace(source_type="EvidenceState", target_type="TruthValueLabel"):
    return {
        "version": "0.1",
        "trace_id": "trace-gate-cli",
        "steps": [
            {"id": "s1", "contract": {"version": "0.1", "nodes": [{"id": "a", "type": source_type, "provenance": "agent:s1"}], "edges": []}},
            {"id": "s2", "contract": {"version": "0.1", "nodes": [{"id": "b", "type": target_type, "provenance": "agent:s2"}], "edges": []}},
        ],
        "carry_over": [{"id": "co1", "source_step": "s1", "source_node": "a", "target_step": "s2", "target_node": "b", "relation": "PROMOTE"}],
    }


def test_gate_ai_cli_blocks_with_exit_one_and_json_provenance(tmp_path, capsys):
    path = tmp_path / "contract.json"
    path.write_text(json.dumps(_contract()), encoding="utf-8")
    code = main(["gate-ai", "--json", str(path)])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "BLOCK"
    assert payload["may_continue"] is False
    assert payload["failure_codes"] == ["F-AI-02"]
    assert payload["repair_actions"][0]["action"] == "INSERT_EVALUATION"
    assert payload["decision_provenance"]["policy_version"] == "0.2"


def test_gate_ai_cli_warn_exit_zero(tmp_path, capsys):
    path = tmp_path / "contract.json"
    path.write_text(json.dumps(_contract("Role", "Identity")), encoding="utf-8")
    code = main(["gate-ai", str(path)])
    assert code == 0
    out = capsys.readouterr().out
    assert "Agent semantic gate: WARN" in out
    assert "May continue: YES" in out
    assert "KEEP_ROLE_SCOPED" in out


def test_gate_ai_cli_defer_exit_two_on_invalid_contract(tmp_path, capsys):
    path = tmp_path / "contract.json"
    path.write_text(json.dumps({"version": "0.1", "nodes": []}), encoding="utf-8")
    code = main(["gate-ai", "--json", str(path)])
    assert code == 2
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "DEFER"
    assert payload["failure_codes"] == ["F-AI-16"]


def test_gate_ai_trace_cli_blocks_cross_step_collapse(tmp_path, capsys):
    path = tmp_path / "trace.json"
    path.write_text(json.dumps(_trace()), encoding="utf-8")
    code = main(["gate-ai-trace", "--json", str(path)])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "BLOCK"
    assert payload["failure_codes"] == ["F-AI-09"]
    assert payload["repair_actions"][0]["target_id"] == "co1"


def test_gate_ai_trace_cli_pass_exit_zero(tmp_path, capsys):
    path = tmp_path / "trace.json"
    path.write_text(json.dumps(_trace("EvidenceState", "Claim")), encoding="utf-8")
    code = main(["gate-ai-trace", str(path)])
    assert code == 0
    out = capsys.readouterr().out
    assert "Agent semantic gate: PASS" in out
    assert "May continue: YES" in out


def test_gate_ai_cli_reads_stdin(monkeypatch, capsys):
    import io
    import sys

    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(_contract())))
    code = main(["gate-ai", "--json", "-"])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "BLOCK"


def test_gate_ai_trace_cli_reads_stdin(monkeypatch, capsys):
    import io
    import sys

    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(_trace("EvidenceState", "Claim"))))
    code = main(["gate-ai-trace", "--json", "-"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["decision"] == "PASS"
