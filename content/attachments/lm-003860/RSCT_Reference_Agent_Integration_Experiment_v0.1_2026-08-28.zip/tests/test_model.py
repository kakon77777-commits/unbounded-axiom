from rsct.model import (
    AnalysisResult,
    AnalysisStatus,
    EvaluationIR,
    FailureCode,
    FixedPointResult,
    SemanticEdge,
    SemanticGraphIR,
    SemanticNode,
    SemanticType,
    SourceSpan,
    SurfaceIR,
    SurfaceToken,
)
from rsct.registry import DEFAULT_ASSUMPTIONS, RUNTIME_INVARIANTS


def test_unknown_is_not_false():
    assert AnalysisStatus.UNKNOWN is not AnalysisStatus.FAIL


def test_truth_bearer_is_distinct_from_sentence_token():
    assert SemanticType.TRUTH_BEARER != SemanticType.SENTENCE_TOKEN


def test_invariants_include_role_identity_separation():
    assert "Role != Identity" in RUNTIME_INVARIANTS


def test_default_assumptions_match_classical_liar_contract():
    assert DEFAULT_ASSUMPTIONS["TOTAL_BIVALENCE"] is True
    assert DEFAULT_ASSUMPTIONS["IMMEDIATE_REENTRY"] is True


def test_source_span_is_half_open():
    span = SourceSpan(start=2, end=5)
    assert span.length == 3


def test_surface_ir_preserves_token_span():
    token = SurfaceToken("t1", "這句話", SourceSpan(0, 3))
    ir = SurfaceIR(text="這句話是假的。", language="zh-TW", tokens=(token,), pattern="LIAR")
    assert ir.tokens[0].span == SourceSpan(0, 3)


def test_semantic_graph_is_immutable_tuple_based():
    node = SemanticNode("n1", SemanticType.SENTENCE_TOKEN, "這句話", SourceSpan(0, 3))
    edge = SemanticEdge("e1", "n1", "n1", "REFERENCE")
    graph = SemanticGraphIR(nodes=(node,), edges=(edge,))
    assert graph.nodes == (node,)
    assert graph.edges == (edge,)


def test_analysis_result_holds_evaluation_and_failures():
    fixed = FixedPointResult(status=AnalysisStatus.NOT_APPLICABLE)
    evaluation = EvaluationIR(fixed_point=fixed)
    result = AnalysisResult(
        text="雪是白的。",
        parse_status=AnalysisStatus.PASS,
        graph=SemanticGraphIR(),
        evaluation=evaluation,
        failures=(FailureCode.FIX_NO_FIXED_POINT,),
        assumptions={},
        self_reference={"detected": False},
        summary="ok",
    )
    assert result.evaluation.fixed_point.status is AnalysisStatus.NOT_APPLICABLE
    assert result.failures[0].value == "F-FIX-01"
