from rsct.registry import RUNTIME_INVARIANTS


def test_ai_semantic_runtime_invariants_are_canonical():
    assert "Claim != Truth" in RUNTIME_INVARIANTS
    assert "BeliefState != Truth" in RUNTIME_INVARIANTS
    assert "MemoryRecord != BeliefState" in RUNTIME_INVARIANTS
    assert "Inference != Truth" in RUNTIME_INVARIANTS
    assert "Observation != Truth" in RUNTIME_INVARIANTS
