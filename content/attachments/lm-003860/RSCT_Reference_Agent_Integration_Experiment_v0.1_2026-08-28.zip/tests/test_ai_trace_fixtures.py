from pathlib import Path

import pytest

from rsct.middleware import RSCTSemanticMiddleware


CASES = [
    ("legal_reasoning_trace.json", True, ()),
    ("evidence_to_truth_cross_step.json", False, ("F-AI-09",)),
    ("memory_to_belief_cross_step.json", False, ("F-AI-10",)),
    ("inference_to_truth_cross_step.json", False, ("F-AI-11",)),
    ("role_to_identity_cross_step.json", True, ("F-AI-12",)),
    ("claim_to_truth_cross_step.json", False, ("F-AI-13",)),
    ("belief_to_truth_cross_step.json", False, ("F-AI-14",)),
    ("observation_to_truth_cross_step.json", False, ("F-AI-15",)),
]


@pytest.mark.parametrize("filename,passed,codes", CASES)
def test_canonical_reasoning_trace_fixture(filename, passed, codes):
    path = Path(__file__).parent / "ai_traces" / filename
    result = RSCTSemanticMiddleware().audit_trace_json(path.read_text(encoding="utf-8"))
    assert result.passed is passed
    assert tuple(code.value for code in result.failure_codes) == codes
