import json
from pathlib import Path

import pytest

from rsct.middleware import RSCTSemanticMiddleware
from rsct.reporting import audit_result_to_dict

ROOT = Path(__file__).parent / "ai_contracts"

CASES = {
    "evidence_to_truth_illegal": (False, ["F-AI-02"]),
    "belief_to_truth_illegal": (False, ["F-AI-03"]),
    "memory_to_belief_illegal": (False, ["F-AI-04"]),
    "role_to_identity_warning": (True, ["F-AI-06"]),
    "legal_evidence_claim_evaluation": (True, []),
    "inference_to_truth_illegal": (False, ["F-AI-07"]),
    "observation_to_truth_illegal": (False, ["F-AI-08"]),
}


@pytest.mark.parametrize("name,expected", CASES.items())
def test_ai_contract_fixture(name, expected):
    passed, codes = expected
    contract_text = (ROOT / f"{name}.json").read_text(encoding="utf-8")
    result = RSCTSemanticMiddleware().audit_json(contract_text)
    payload = audit_result_to_dict(result)
    assert payload["passed"] is passed
    assert payload["failure_codes"] == codes
