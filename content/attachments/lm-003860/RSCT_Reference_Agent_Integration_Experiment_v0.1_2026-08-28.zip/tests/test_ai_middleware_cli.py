import json

from rsct.cli import main
from rsct.middleware import RSCTSemanticMiddleware


def _bad_contract():
    return {
        "version": "0.1",
        "nodes": [
            {"id": "e1", "type": "EvidenceState", "surface": "paper supports P", "provenance": "paper:1"},
            {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
        ],
        "edges": [
            {"id": "x1", "source": "e1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"}
        ],
    }


def test_middleware_audits_json_contract_without_llm():
    result = RSCTSemanticMiddleware().audit_contract(_bad_contract())
    assert result.passed is False
    assert [code.value for code in result.failure_codes] == ["F-AI-02"]


def test_middleware_accepts_json_text():
    result = RSCTSemanticMiddleware().audit_json(json.dumps(_bad_contract()))
    assert result.passed is False


def test_audit_ai_cli_json_emits_findings(tmp_path, capsys):
    path = tmp_path / "contract.json"
    path.write_text(json.dumps(_bad_contract(), ensure_ascii=False), encoding="utf-8")
    code = main(["audit-ai", "--json", str(path)])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["passed"] is False
    assert payload["findings"][0]["code"] == "F-AI-02"
    assert payload["findings"][0]["edge_id"] == "x1"


def test_audit_ai_cli_text_renders_localized_repair(tmp_path, capsys):
    path = tmp_path / "contract.json"
    path.write_text(json.dumps(_bad_contract(), ensure_ascii=False), encoding="utf-8")
    code = main(["audit-ai", str(path)])
    assert code == 1
    out = capsys.readouterr().out
    assert "AI semantic audit: FAIL" in out
    assert "F-AI-02" in out
    assert "Evidence -> Claim -> Evaluation" in out
