import copy

from rsct.gate import GateDecision
from rsct.middleware import RSCTSemanticMiddleware
from rsct.model import FailureCode


def _contract(source_type="EvidenceState", target_type="TruthValueLabel"):
    return {
        "version": "0.1",
        "nodes": [
            {"id": "s", "type": source_type, "provenance": "agent:step1"},
            {"id": "t", "type": target_type, "provenance": "agent:step1"},
        ],
        "edges": [
            {"id": "e", "source": "s", "target": "t", "type": "TYPE_COERCION"}
        ],
    }


def _trace(source_type="EvidenceState", target_type="TruthValueLabel"):
    return {
        "version": "0.1",
        "trace_id": "trace-gate",
        "steps": [
            {
                "id": "s1",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "a", "type": source_type, "provenance": "agent:s1"}],
                    "edges": [],
                },
            },
            {
                "id": "s2",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "b", "type": target_type, "provenance": "agent:s2"}],
                    "edges": [],
                },
            },
        ],
        "carry_over": [
            {
                "id": "co1",
                "source_step": "s1",
                "source_node": "a",
                "target_step": "s2",
                "target_node": "b",
                "relation": "PROMOTE",
            }
        ],
    }


def test_gate_blocks_error_and_returns_localized_repair():
    result = RSCTSemanticMiddleware().gate_contract(_contract())
    assert result.decision is GateDecision.BLOCK
    assert result.may_continue is False
    assert result.failure_codes == (FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE,)
    assert result.repair_actions[0].action == "INSERT_EVALUATION"
    assert result.repair_actions[0].target_id == "e"


def test_gate_warns_role_identity_but_allows_continue():
    result = RSCTSemanticMiddleware().gate_contract(_contract("Role", "Identity"))
    assert result.decision is GateDecision.WARN
    assert result.may_continue is True
    assert result.failure_codes == (FailureCode.AI_ROLE_IDENTITY_ESCALATION,)
    assert result.repair_actions[0].action == "KEEP_ROLE_SCOPED"


def test_gate_passes_legal_contract():
    result = RSCTSemanticMiddleware().gate_contract(_contract("EvidenceState", "Claim"))
    assert result.decision is GateDecision.PASS
    assert result.may_continue is True
    assert result.failure_codes == ()
    assert result.repair_actions == ()


def test_gate_defers_invalid_contract_instead_of_guessing():
    result = RSCTSemanticMiddleware().gate_contract({"version": "0.1", "nodes": []})
    assert result.decision is GateDecision.DEFER
    assert result.may_continue is False
    assert result.failure_codes == (FailureCode.AI_GATE_INPUT_INVALID,)
    assert "contract nodes and edges" in result.reason


def test_gate_result_records_assumptions_and_decision_provenance():
    result = RSCTSemanticMiddleware().gate_contract(_contract("EvidenceState", "Claim"))
    assert result.active_assumptions["AUTO_APPLY_REPAIRS"] is False
    assert result.active_assumptions["DEFER_ON_INVALID_INPUT"] is True
    assert result.provenance.policy_id == "rsct-agent-semantic-gate"
    assert result.provenance.policy_version == "0.2"
    assert result.provenance.input_kind == "contract"
    assert result.provenance.rule == "NO_FINDINGS=>PASS"


def test_gate_does_not_mutate_contract():
    payload = _contract()
    original = copy.deepcopy(payload)
    RSCTSemanticMiddleware().gate_contract(payload)
    assert payload == original


def test_trace_gate_blocks_cross_step_truth_collapse():
    result = RSCTSemanticMiddleware().gate_trace_contract(_trace())
    assert result.decision is GateDecision.BLOCK
    assert result.failure_codes == (FailureCode.AI_TRACE_EVIDENCE_TRUTH_COLLAPSE,)
    assert result.repair_actions[0].action == "INSERT_EVALUATION"
    assert result.repair_actions[0].target_id == "co1"
    assert result.provenance.input_kind == "reasoning_trace"


def test_trace_gate_warns_role_identity():
    result = RSCTSemanticMiddleware().gate_trace_contract(_trace("Role", "Identity"))
    assert result.decision is GateDecision.WARN
    assert result.may_continue is True
    assert result.failure_codes == (FailureCode.AI_TRACE_ROLE_IDENTITY_ESCALATION,)


def test_gate_auto_detects_reasoning_trace_payload():
    result = RSCTSemanticMiddleware().gate(_trace("EvidenceState", "Claim"))
    assert result.decision is GateDecision.PASS
    assert result.provenance.input_kind == "reasoning_trace"


def test_trace_gate_includes_step_local_repair_actions():
    trace = _trace("EvidenceState", "Claim")
    trace["steps"][0]["contract"] = _contract("EvidenceState", "TruthValueLabel")
    trace["carry_over"] = []
    result = RSCTSemanticMiddleware().gate_trace_contract(trace)
    assert result.decision is GateDecision.BLOCK
    assert FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE in result.failure_codes
    action = next(a for a in result.repair_actions if a.finding_code is FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE)
    assert action.action == "INSERT_EVALUATION"
    assert action.target_id == "e"
    assert action.source_step == "s1"
    assert action.target_step == "s1"


def test_projection_warning_yields_warn_and_declare_loss_repair():
    payload = _contract("Claim", "Evaluation")
    payload["edges"][0]["type"] = "PROJECTION"
    result = RSCTSemanticMiddleware().gate_contract(payload)
    assert result.decision is GateDecision.WARN
    assert result.failure_codes == (FailureCode.PROJECTION_UNDECLARED_LOSS,)
    assert result.repair_actions[0].action == "DECLARE_PROJECTION_LOSS"
