import json

from rsct.analyzer import RSCTAnalyzer
from rsct.cli import main
from rsct.reporting import result_to_dict, render_text


def test_result_to_dict_is_json_serializable_and_preserves_fixed_point_evidence():
    result = RSCTAnalyzer().analyze("這句話是假的。")
    payload = result_to_dict(result)
    assert payload["fixed_point"]["status"] == "NO_FIXED_POINT"
    assert payload["fixed_point"]["equation"] == "v = N(v)"
    assert payload["self_reference"]["detected"] is True
    assert "F-FIX-01" in payload["failures"]
    json.dumps(payload, ensure_ascii=False)


def test_text_report_uses_safe_non_overclaiming_conclusion():
    text = render_text(RSCTAnalyzer().analyze("這句話是假的。"))
    assert "Self-reference: YES" in text
    assert "False predicate: YES" in text
    assert "Fixed-point status: NO_FIXED_POINT" in text
    assert "No stable value exists under the active semantic contract." in text
    assert "世界矛盾" not in text


def test_cli_analyze_text_mode(capsys):
    code = main(["analyze", "這句話是假的。"])
    out = capsys.readouterr().out
    assert code == 0
    assert "Fixed-point equation: v = N(v)" in out


def test_cli_analyze_json_mode(capsys):
    code = main(["analyze", "--json", "這句話是假的。"])
    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert payload["fixed_point"]["status"] == "NO_FIXED_POINT"


def test_cli_graph_mode(capsys):
    code = main(["graph", "這句話是假的。"])
    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert any(node["semantic_type"] == "TruthBearer" for node in payload["nodes"])
    assert any(edge["edge_type"] == "REFERENCE" for edge in payload["edges"])


def test_cli_assumptions_mode(capsys):
    code = main(["assumptions", "這句話是假的。"])
    out = capsys.readouterr().out
    assert code == 0
    assert "TOTAL_BIVALENCE=true" in out


def test_cli_assumption_mutation_recomputes_analysis(capsys):
    code = main(["analyze", "--set", "TOTAL_BIVALENCE=false", "--json", "這句話是假的。"])
    payload = json.loads(capsys.readouterr().out)
    assert code == 0
    assert payload["assumptions"]["TOTAL_BIVALENCE"] is False
    assert payload["fixed_point"]["status"] == "UNKNOWN"
