import copy
import json

import pytest

from rsct.model import FailureCode
from rsct.repair import build_repair_plan
from rsct.trace import load_reasoning_trace
from rsct.trace_audit import audit_reasoning_trace


def _contract(nodes, edges=()):
    return {"version": "0.1", "nodes": list(nodes), "edges": list(edges)}


def _trace(steps, carry_over=()):
    return {
        "version": "0.1",
        "trace_id": "trace-1",
        "steps": list(steps),
        "carry_over": list(carry_over),
    }


def test_reasoning_trace_parses_and_preserves_step_provenance():
    payload = _trace(
        [
            {
                "id": "s1",
                "contract": _contract(
                    [{"id": "e1", "type": "EvidenceState", "surface": "paper supports P", "provenance": "paper:1"}]
                ),
            },
            {
                "id": "s2",
                "contract": _contract(
                    [{"id": "c1", "type": "Claim", "surface": "P", "provenance": "agent:a"}]
                ),
            },
        ],
        [
            {
                "id": "co1",
                "source_step": "s1",
                "source_node": "e1",
                "target_step": "s2",
                "target_node": "c1",
                "relation": "CARRY_OVER",
            }
        ],
    )
    trace = load_reasoning_trace(json.dumps(payload))
    assert trace.trace_id == "trace-1"
    assert trace.steps[0].contract.nodes[0].provenance == "paper:1"
    assert trace.carry_over[0].source_step == "s1"


def test_reasoning_trace_rejects_duplicate_step_ids():
    payload = _trace(
        [
            {"id": "s1", "contract": _contract([])},
            {"id": "s1", "contract": _contract([])},
        ]
    )
    with pytest.raises(ValueError, match="duplicate step id"):
        load_reasoning_trace(json.dumps(payload))


def test_reasoning_trace_rejects_unknown_carry_over_node():
    payload = _trace(
        [{"id": "s1", "contract": _contract([{"id": "c1", "type": "Claim", "provenance": "agent:a"}])}],
        [
            {
                "id": "co1",
                "source_step": "s1",
                "source_node": "missing",
                "target_step": "s1",
                "target_node": "c1",
                "relation": "CARRY_OVER",
            }
        ],
    )
    with pytest.raises(ValueError, match="unknown source node"):
        load_reasoning_trace(json.dumps(payload))


def test_cross_step_evidence_to_truth_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "e1", "type": "EvidenceState", "provenance": "paper:1"}])},
                    {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
                ],
                [
                    {
                        "id": "co1",
                        "source_step": "s1",
                        "source_node": "e1",
                        "target_step": "s2",
                        "target_node": "t1",
                        "relation": "PROMOTE",
                    }
                ],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_EVIDENCE_TRUTH_COLLAPSE in result.failure_codes
    finding = next(f for f in result.cross_step_findings if f.code is FailureCode.AI_TRACE_EVIDENCE_TRUTH_COLLAPSE)
    assert finding.source_step == "s1"
    assert finding.target_step == "s2"
    assert finding.source_node == "e1"
    assert finding.target_node == "t1"


def test_cross_step_memory_to_belief_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "m1", "type": "MemoryRecord", "provenance": "memory:1"}])},
                    {"id": "s2", "contract": _contract([{"id": "b1", "type": "BeliefState", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "m1", "target_step": "s2", "target_node": "b1", "relation": "RESTORE"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_MEMORY_BELIEF_COLLAPSE in result.failure_codes


def test_cross_step_inference_to_truth_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "i1", "type": "Inference", "provenance": "agent:a"}])},
                    {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "i1", "target_step": "s2", "target_node": "t1", "relation": "PROMOTE"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_INFERENCE_TRUTH_COLLAPSE in result.failure_codes


def test_cross_step_role_to_identity_is_warned():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "r1", "type": "Role", "provenance": "workflow"}])},
                    {"id": "s2", "contract": _contract([{"id": "id1", "type": "Identity", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "r1", "target_step": "s2", "target_node": "id1", "relation": "PERSIST"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_ROLE_IDENTITY_ESCALATION in result.failure_codes
    assert result.passed is True


def test_legal_cross_step_evidence_claim_evaluation_truth_trace_passes():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "e1", "type": "EvidenceState", "provenance": "paper:1"}])},
                    {"id": "s2", "contract": _contract([{"id": "c1", "type": "Claim", "provenance": "agent:a"}])},
                    {"id": "s3", "contract": _contract([{"id": "ev1", "type": "Evaluation", "provenance": "rsct"}])},
                    {"id": "s4", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "rsct"}])},
                ],
                [
                    {"id": "co1", "source_step": "s1", "source_node": "e1", "target_step": "s2", "target_node": "c1", "relation": "SUPPORTS"},
                    {"id": "co2", "source_step": "s2", "source_node": "c1", "target_step": "s3", "target_node": "ev1", "relation": "EVALUATE"},
                    {"id": "co3", "source_step": "s3", "source_node": "ev1", "target_step": "s4", "target_node": "t1", "relation": "PROJECT"},
                ],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert result.failure_codes == ()
    assert result.passed is True


def test_repair_plan_is_deterministic_localized_and_non_mutating():
    payload = _trace(
        [
            {"id": "s1", "contract": _contract([{"id": "e1", "type": "EvidenceState", "provenance": "paper:1"}])},
            {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
        ],
        [{"id": "co1", "source_step": "s1", "source_node": "e1", "target_step": "s2", "target_node": "t1", "relation": "PROMOTE"}],
    )
    original = copy.deepcopy(payload)
    trace = load_reasoning_trace(json.dumps(payload))
    result = audit_reasoning_trace(trace)
    plan1 = build_repair_plan(result)
    plan2 = build_repair_plan(result)
    assert plan1 == plan2
    assert plan1.actions[0].action == "INSERT_EVALUATION"
    assert plan1.actions[0].carry_over_id == "co1"
    assert payload == original


def test_cross_step_claim_to_truth_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "c1", "type": "Claim", "provenance": "agent:a"}])},
                    {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "c1", "target_step": "s2", "target_node": "t1", "relation": "PROMOTE"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_CLAIM_TRUTH_COLLAPSE in result.failure_codes


def test_cross_step_belief_to_truth_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "b1", "type": "BeliefState", "provenance": "agent:a"}])},
                    {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "b1", "target_step": "s2", "target_node": "t1", "relation": "PROMOTE"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_BELIEF_TRUTH_COLLAPSE in result.failure_codes


def test_cross_step_observation_to_truth_is_rejected():
    trace = load_reasoning_trace(
        json.dumps(
            _trace(
                [
                    {"id": "s1", "contract": _contract([{"id": "o1", "type": "Observation", "provenance": "sensor:1"}])},
                    {"id": "s2", "contract": _contract([{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}])},
                ],
                [{"id": "co1", "source_step": "s1", "source_node": "o1", "target_step": "s2", "target_node": "t1", "relation": "PROMOTE"}],
            )
        )
    )
    result = audit_reasoning_trace(trace)
    assert FailureCode.AI_TRACE_OBSERVATION_TRUTH_COLLAPSE in result.failure_codes
