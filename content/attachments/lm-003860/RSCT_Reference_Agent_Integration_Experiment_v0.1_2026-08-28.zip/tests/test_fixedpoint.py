from rsct.fixedpoint import analyze_finite_map, classical_bivalent_negation
from rsct.model import AnalysisStatus


def test_bivalent_negation_has_no_fixed_point_and_period_two():
    result = analyze_finite_map(("T", "F"), classical_bivalent_negation())
    assert result.fixed_points == ()
    assert result.status is AnalysisStatus.NO_FIXED_POINT
    assert any(set(cycle) == {"T", "F"} and len(cycle) == 2 for cycle in result.cycles)
    assert result.equation == "v = N(v)"


def test_identity_map_has_two_fixed_points():
    result = analyze_finite_map(("T", "F"), {"T": "T", "F": "F"})
    assert set(result.fixed_points) == {"T", "F"}
    assert result.status is AnalysisStatus.FIXED_POINT_FOUND


def test_invalid_mapping_is_rejected():
    try:
        analyze_finite_map(("T", "F"), {"T": "F"})
    except ValueError as exc:
        assert "total" in str(exc)
    else:
        raise AssertionError("expected invalid finite mapping to fail")
