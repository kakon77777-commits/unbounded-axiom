from rsct.analyzer import RSCTAnalyzer
from rsct.model import AnalysisStatus, FailureCode


def test_classical_liar_reports_no_fixed_point():
    result = RSCTAnalyzer().analyze("這句話是假的。")
    assert result.self_reference["detected"] is True
    assert result.evaluation.false_predicate is True
    assert result.evaluation.truth_domain == ("T", "F")
    assert result.evaluation.fixed_point_equation == "v = N(v)"
    assert result.evaluation.fixed_point.status is AnalysisStatus.NO_FIXED_POINT
    assert FailureCode.FIX_NO_FIXED_POINT in result.failures
    assert result.summary == "No stable value exists under the active semantic contract."


def test_harmless_self_reference_is_not_liar():
    result = RSCTAnalyzer().analyze("這句話是中文。")
    assert result.self_reference["detected"] is True
    assert result.evaluation.false_predicate is False
    assert result.evaluation.fixed_point.status is AnalysisStatus.NOT_APPLICABLE


def test_disabling_total_bivalence_changes_liar_analysis():
    analyzer = RSCTAnalyzer(assumptions={"TOTAL_BIVALENCE": False})
    result = analyzer.analyze("這句話是假的。")
    assert result.assumptions["TOTAL_BIVALENCE"] is False
    assert result.assumptions["IMMEDIATE_REENTRY"] is True
    assert result.evaluation.fixed_point.status is AnalysisStatus.UNKNOWN
    assert FailureCode.FIX_NO_FIXED_POINT not in result.failures


def test_disabling_immediate_reentry_prevents_classical_obstruction():
    analyzer = RSCTAnalyzer(assumptions={"IMMEDIATE_REENTRY": False})
    result = analyzer.analyze("這句話是假的。")
    assert result.evaluation.fixed_point.status is AnalysisStatus.UNKNOWN


def test_external_false_predicate_has_no_fixed_point_requirement():
    result = RSCTAnalyzer().analyze("「雪是黑的」是假的。")
    assert result.evaluation.false_predicate is True
    assert result.self_reference["detected"] is False
    assert result.evaluation.fixed_point.status is AnalysisStatus.NOT_APPLICABLE


def test_unsupported_input_stays_partial():
    result = RSCTAnalyzer().analyze("這是一個目前沒有規則的輸入。")
    assert result.parse_status is AnalysisStatus.PARTIAL
    assert result.summary == "Controlled v0.1 parser did not match this input."
