import json
from pathlib import Path

from rsct.analyzer import RSCTAnalyzer
from rsct.reporting import result_to_dict

GOLDEN = Path(__file__).parent / "golden"

CASES = {
    "liar_classical.json": "這句話是假的。",
    "self_reference_language.json": "這句話是中文。",
    "external_false_predicate.json": "「雪是黑的」是假的。",
    "role_reification.json": "他說過謊，所以他就是永遠的說謊者。",
}


def test_golden_outputs_match_canonical_results():
    for filename, text in CASES.items():
        expected = json.loads((GOLDEN / filename).read_text(encoding="utf-8"))
        actual = result_to_dict(RSCTAnalyzer().analyze(text))
        assert actual == expected, filename
