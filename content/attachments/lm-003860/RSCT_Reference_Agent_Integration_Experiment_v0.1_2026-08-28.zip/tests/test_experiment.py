import json
from copy import deepcopy

import pytest

from rsct.benchmark import BenchmarkCase, BenchmarkExpected
from rsct.gate import GateDecision
from rsct.experiment import (
    AgentAttempt,
    CaseExperimentResult,
    score_experiment,
    run_reference_agent_experiment,
)
from rsct.reference_agent import ScriptedReferenceAgent


def _case(case_id: str, decision: str, payload: dict, category: str = "test") -> BenchmarkCase:
    return BenchmarkCase(
        case_id=case_id,
        category=category,
        input_kind="contract",
        payload=payload,
        expected=BenchmarkExpected(decision=GateDecision(decision)),
    )


def _safe_payload() -> dict:
    return {
        "version": "0.1",
        "nodes": [
            {"id": "e", "type": "EvidenceState", "provenance": "test"},
            {"id": "c", "type": "Claim", "provenance": "test"},
            {"id": "v", "type": "Evaluation", "provenance": "test"},
            {"id": "t", "type": "TruthValueLabel", "provenance": "test"},
        ],
        "edges": [
            {"id": "e1", "source": "e", "target": "c", "type": "CONSTRUCTION"},
            {"id": "e2", "source": "c", "target": "v", "type": "EVALUATION"},
            {"id": "e3", "source": "v", "target": "t", "type": "EVALUATION"},
        ],
    }


def _unsafe_payload() -> dict:
    return {
        "version": "0.1",
        "nodes": [
            {"id": "e", "type": "EvidenceState", "provenance": "test"},
            {"id": "t", "type": "TruthValueLabel", "provenance": "test"},
        ],
        "edges": [{"id": "x", "source": "e", "target": "t", "type": "TYPE_COERCION"}],
    }


def test_score_experiment_counts_unsafe_baseline_and_successful_repair():
    results = (
        CaseExperimentResult(
            case_id="b",
            expected_decision=GateDecision.BLOCK,
            initial_gate_decision=GateDecision.BLOCK,
            final_gate_decision=GateDecision.PASS,
            baseline_accepted=True,
            gated_accepted=True,
            repair_attempts=1,
            repair_success=True,
            false_positive=False,
            extra_agent_steps=1,
        ),
        CaseExperimentResult(
            case_id="p",
            expected_decision=GateDecision.PASS,
            initial_gate_decision=GateDecision.PASS,
            final_gate_decision=GateDecision.PASS,
            baseline_accepted=True,
            gated_accepted=True,
            repair_attempts=0,
            repair_success=False,
            false_positive=False,
            extra_agent_steps=0,
        ),
    )
    metrics = score_experiment(results)
    assert metrics.baseline_unsafe_accept_rate == pytest.approx(1.0)
    assert metrics.gated_block_escape_rate == pytest.approx(0.0)
    assert metrics.completion_rate == pytest.approx(1.0)
    assert metrics.repair_success_rate == pytest.approx(1.0)
    assert metrics.false_positive_rate == pytest.approx(0.0)
    assert metrics.mean_extra_agent_steps == pytest.approx(0.5)


def test_scripted_reference_agent_repairs_blocked_contract_without_mutating_prior():
    case = _case("x", "BLOCK", _unsafe_payload())
    provider = ScriptedReferenceAgent()
    initial = provider.initial(case)
    frozen = deepcopy(initial.payload)
    repaired = provider.repair(case, initial, repair_actions=("INSERT_EVALUATION",))
    assert initial.payload == frozen
    assert repaired.payload is not initial.payload
    assert repaired.payload != initial.payload


def test_reference_experiment_runs_baseline_and_gate_repair_loop():
    cases = (
        _case("unsafe", "BLOCK", _unsafe_payload()),
        _case("safe", "PASS", _safe_payload()),
    )
    run = run_reference_agent_experiment(cases, ScriptedReferenceAgent(), max_repairs=1)
    by_id = {result.case_id: result for result in run.results}
    assert by_id["unsafe"].baseline_accepted is True
    assert by_id["unsafe"].initial_gate_decision is GateDecision.BLOCK
    assert by_id["unsafe"].final_gate_decision is GateDecision.PASS
    assert by_id["unsafe"].repair_success is True
    assert by_id["safe"].repair_attempts == 0
    assert run.metrics.baseline_unsafe_accept_rate == 1.0
    assert run.metrics.gated_block_escape_rate == 0.0


def test_reference_experiment_defer_stops_without_repair():
    invalid = _case("bad", "DEFER", {"version": "wrong"})
    run = run_reference_agent_experiment((invalid,), ScriptedReferenceAgent(), max_repairs=1)
    result = run.results[0]
    assert result.initial_gate_decision is GateDecision.DEFER
    assert result.gated_accepted is False
    assert result.repair_attempts == 0

from pathlib import Path
from rsct.benchmark import load_benchmark_cases
from rsct.reference_agent import ReplayReferenceAgent


def test_scripted_reference_agent_runs_all_frozen_benchmark_cases():
    cases = load_benchmark_cases("benchmarks/semantic_error_v0.1/cases.jsonl")
    run = run_reference_agent_experiment(cases, ScriptedReferenceAgent(), max_repairs=1)
    assert len(run.results) == 88
    assert run.metrics.gate_decision_accuracy == 1.0
    assert run.metrics.baseline_unsafe_accept_rate == 1.0
    assert run.metrics.gated_block_escape_rate == 0.0
    assert run.metrics.repair_success_rate == 1.0
    assert run.metrics.false_positive_rate == 0.0
    assert run.metrics.completion_rate == pytest.approx(80 / 88)
    assert run.metrics.defer_rate == pytest.approx(8 / 88)
    assert run.metrics.mean_extra_agent_steps == pytest.approx(48 / 88)
    assert run.external_model_evidence is False


def test_replay_provider_uses_recorded_initial_and_repair_payloads(tmp_path):
    path = tmp_path / "replay.jsonl"
    path.write_text(
        json.dumps({
            "case_id": "x",
            "provider": "external-model-x",
            "initial": _unsafe_payload(),
            "repairs": [_safe_payload()],
        }) + "\n",
        encoding="utf-8",
    )
    provider = ReplayReferenceAgent.from_jsonl(path, expected_case_ids={"x"})
    case = _case("x", "BLOCK", _unsafe_payload())
    initial = provider.initial(case)
    repaired = provider.repair(case, initial, ("INSERT_EVALUATION",))
    assert initial.payload == _unsafe_payload()
    assert repaired.payload == _safe_payload()
    assert provider.external_model_evidence is True
    assert provider.provider_kind == "external-model-x"


def test_replay_provider_requires_exact_case_coverage(tmp_path):
    path = tmp_path / "replay.jsonl"
    path.write_text(json.dumps({"case_id": "x", "initial": _safe_payload(), "repairs": []}) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="replay coverage mismatch"):
        ReplayReferenceAgent.from_jsonl(path, expected_case_ids={"x", "y"})


def test_reference_experiment_records_wall_clock_overhead():
    run = run_reference_agent_experiment((_case("safe-time", "PASS", _safe_payload()),), ScriptedReferenceAgent())
    assert run.elapsed_seconds >= 0.0
    assert run.mean_case_seconds >= 0.0
