import json

import pytest

from rsct.ai_contract import contract_to_graph, load_ai_contract
from rsct.audit import AuditSeverity, audit_ai_graph
from rsct.model import FailureCode, SemanticType


def _contract(nodes, edges):
    return {"version": "0.1", "nodes": nodes, "edges": edges}


def test_evidence_cannot_be_coerced_directly_to_truth_label():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "e1", "type": "EvidenceState", "surface": "paper supports P", "provenance": "paper:1"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
            ],
            [
                {"id": "x1", "source": "e1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"},
            ],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE in result.failure_codes
    finding = next(f for f in result.findings if f.code is FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE)
    assert finding.severity is AuditSeverity.ERROR
    assert "Evidence -> Claim -> Evaluation" in finding.repair_hint


def test_belief_state_is_not_truth_value():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "b1", "type": "BeliefState", "surface": "I believe P", "provenance": "agent:self"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
            ],
            [{"id": "x1", "source": "b1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_BELIEF_TRUTH_COLLAPSE in result.failure_codes


def test_memory_record_cannot_silently_become_current_belief():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "m1", "type": "MemoryRecord", "surface": "P was recorded", "provenance": "memory:1"},
                {"id": "b1", "type": "BeliefState", "surface": "I believe P", "provenance": "agent:self"},
            ],
            [{"id": "x1", "source": "m1", "target": "b1", "type": "TYPE_COERCION", "operator": "COERCE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_MEMORY_BELIEF_COLLAPSE in result.failure_codes
    assert any("re-evaluation" in f.repair_hint.lower() for f in result.findings)


def test_claim_cannot_be_coerced_directly_to_truth_label():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "c1", "type": "Claim", "surface": "P", "provenance": "agent:a"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
            ],
            [{"id": "x1", "source": "c1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_CLAIM_TRUTH_COLLAPSE in result.failure_codes


def test_role_to_identity_escalation_is_flagged_without_mutating_graph():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "r1", "type": "Role", "surface": "reviewer", "provenance": "workflow"},
                {"id": "i1", "type": "Identity", "surface": "reviewer identity", "provenance": "inferred"},
            ],
            [{"id": "x1", "source": "r1", "target": "i1", "type": "ROLE_REIFICATION", "operator": "REIFY"}],
        )
    )
    before = graph
    result = audit_ai_graph(graph)
    assert FailureCode.AI_ROLE_IDENTITY_ESCALATION in result.failure_codes
    assert result.graph is before
    assert any(f.severity is AuditSeverity.WARNING for f in result.findings)


def test_legal_evidence_claim_evaluation_chain_passes_ai_semantic_audit():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "e1", "type": "EvidenceState", "surface": "paper supports P", "provenance": "paper:1"},
                {"id": "c1", "type": "Claim", "surface": "P", "provenance": "agent:a"},
                {"id": "ev1", "type": "Evaluation", "surface": "evaluate P", "provenance": "rsct:classical"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "rsct:classical"},
            ],
            [
                {"id": "x1", "source": "e1", "target": "c1", "type": "EVIDENCE_SUPPORT", "operator": "SUPPORTS"},
                {"id": "x2", "source": "c1", "target": "ev1", "type": "EVALUATION", "operator": "EVALUATE"},
                {"id": "x3", "source": "ev1", "target": "t1", "type": "PROJECTION", "operator": "TRUTH_PROJECT", "projection": {"lossy": True}},
            ],
        )
    )
    result = audit_ai_graph(graph)
    assert result.failure_codes == ()
    assert result.passed is True


def test_contract_requires_provenance_for_ai_semantic_nodes():
    payload = _contract(
        [{"id": "c1", "type": "Claim", "surface": "P"}],
        [],
    )
    with pytest.raises(ValueError, match="provenance"):
        load_ai_contract(json.dumps(payload))


def test_contract_supports_ai_semantic_types():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "c1", "type": "Claim", "surface": "P", "provenance": "agent:a"},
                {"id": "m1", "type": "MemoryRecord", "surface": "P", "provenance": "memory:1"},
                {"id": "b1", "type": "BeliefState", "surface": "P", "provenance": "agent:a"},
                {"id": "ev1", "type": "Evaluation", "surface": "P", "provenance": "rsct"},
            ],
            [],
        )
    )
    assert {n.semantic_type for n in graph.nodes} >= {
        SemanticType.CLAIM,
        SemanticType.MEMORY_RECORD,
        SemanticType.BELIEF_STATE,
        SemanticType.EVALUATION,
    }


def test_truth_projection_requires_explicit_lossiness_declaration():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "ev1", "type": "Evaluation", "surface": "evaluate P", "provenance": "rsct"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "rsct"},
            ],
            [{"id": "x1", "source": "ev1", "target": "t1", "type": "PROJECTION", "operator": "TRUTH_PROJECT"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.PROJECTION_UNDECLARED_LOSS in result.failure_codes


def test_inference_output_is_not_truth_without_evaluation_contract():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "i1", "type": "Inference", "surface": "therefore P", "provenance": "agent:a"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
            ],
            [{"id": "x1", "source": "i1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_INFERENCE_TRUTH_COLLAPSE in result.failure_codes


def test_observation_is_not_truth_without_evaluation_contract():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "o1", "type": "Observation", "surface": "sensor saw X", "provenance": "sensor:1"},
                {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "inferred"},
            ],
            [{"id": "x1", "source": "o1", "target": "t1", "type": "TYPE_COERCION", "operator": "COERCE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert FailureCode.AI_OBSERVATION_TRUTH_COLLAPSE in result.failure_codes


def test_memory_retrieval_to_claim_is_legal_when_not_promoted_to_belief():
    graph = contract_to_graph(
        _contract(
            [
                {"id": "m1", "type": "MemoryRecord", "surface": "P was recorded", "provenance": "memory:1"},
                {"id": "c1", "type": "Claim", "surface": "historical claim P", "provenance": "agent:a"},
            ],
            [{"id": "x1", "source": "m1", "target": "c1", "type": "RETRIEVAL", "operator": "RETRIEVE"}],
        )
    )
    result = audit_ai_graph(graph)
    assert result.passed is True
    assert result.failure_codes == ()
