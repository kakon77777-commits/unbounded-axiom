import io
import json
import sys

from rsct.cli import main
from rsct.middleware import RSCTSemanticMiddleware


def _illegal_trace():
    return {
        "version": "0.1",
        "trace_id": "trace-cli",
        "steps": [
            {
                "id": "s1",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "e1", "type": "EvidenceState", "provenance": "paper:1"}],
                    "edges": [],
                },
            },
            {
                "id": "s2",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "t1", "type": "TruthValueLabel", "provenance": "agent:a"}],
                    "edges": [],
                },
            },
        ],
        "carry_over": [
            {
                "id": "co1",
                "source_step": "s1",
                "source_node": "e1",
                "target_step": "s2",
                "target_node": "t1",
                "relation": "PROMOTE",
            }
        ],
    }


def _legal_trace():
    return {
        "version": "0.1",
        "trace_id": "trace-ok",
        "steps": [
            {
                "id": "s1",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "e1", "type": "EvidenceState", "provenance": "paper:1"}],
                    "edges": [],
                },
            },
            {
                "id": "s2",
                "contract": {
                    "version": "0.1",
                    "nodes": [{"id": "c1", "type": "Claim", "provenance": "agent:a"}],
                    "edges": [],
                },
            },
        ],
        "carry_over": [
            {
                "id": "co1",
                "source_step": "s1",
                "source_node": "e1",
                "target_step": "s2",
                "target_node": "c1",
                "relation": "SUPPORTS",
            }
        ],
    }


def test_middleware_audits_trace_payload():
    result = RSCTSemanticMiddleware().audit_trace_contract(_illegal_trace())
    assert result.passed is False
    assert [c.value for c in result.failure_codes] == ["F-AI-09"]


def test_middleware_audits_trace_json():
    result = RSCTSemanticMiddleware().audit_trace_json(json.dumps(_legal_trace()))
    assert result.passed is True


def test_audit_ai_trace_cli_json_includes_cross_step_finding_and_repair_plan(tmp_path, capsys):
    path = tmp_path / "trace.json"
    path.write_text(json.dumps(_illegal_trace()), encoding="utf-8")
    code = main(["audit-ai-trace", "--json", "--repair-plan", str(path)])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["passed"] is False
    assert payload["failure_codes"] == ["F-AI-09"]
    assert payload["cross_step_findings"][0]["carry_over_id"] == "co1"
    assert payload["repair_plan"]["actions"][0]["action"] == "INSERT_EVALUATION"


def test_audit_ai_trace_cli_text_passes_legal_trace(tmp_path, capsys):
    path = tmp_path / "trace.json"
    path.write_text(json.dumps(_legal_trace()), encoding="utf-8")
    code = main(["audit-ai-trace", str(path)])
    assert code == 0
    out = capsys.readouterr().out
    assert "AI reasoning trace audit: PASS" in out
    assert "Cross-step findings: 0" in out


def test_audit_ai_trace_cli_reads_stdin(monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO(json.dumps(_illegal_trace())))
    code = main(["audit-ai-trace", "--json", "-"])
    assert code == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["trace_id"] == "trace-cli"
