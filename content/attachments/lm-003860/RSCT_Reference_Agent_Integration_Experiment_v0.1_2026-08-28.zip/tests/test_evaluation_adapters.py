from rsct.evaluation import BoundaryAnalyzer, SymbolicTensionAdapter, SymbolicTensionState
from rsct.model import AnalysisStatus, FailureCode


def test_symbolic_tension_adapter_is_explicitly_non_metric():
    adapter = SymbolicTensionAdapter()
    assert adapter.supports_metric() is False
    assert adapter.supports_boundary() is False
    assert adapter.derive_tension_state("aligned") is SymbolicTensionState.ALIGNED
    assert adapter.derive_tension_state("opposed") is SymbolicTensionState.OPPOSED


def test_boundary_analyzer_fails_closed_when_space_has_no_boundary_contract():
    result = BoundaryAnalyzer().analyze(SymbolicTensionAdapter())
    assert result.status is AnalysisStatus.UNKNOWN
    assert result.failure is FailureCode.BOUNDARY_UNDEFINED
    assert "not defined" in result.explanation
