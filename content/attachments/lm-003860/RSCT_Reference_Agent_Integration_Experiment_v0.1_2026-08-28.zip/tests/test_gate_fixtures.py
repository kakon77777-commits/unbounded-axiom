import json
from pathlib import Path

from rsct.gate import GateDecision
from rsct.middleware import RSCTSemanticMiddleware

ROOT = Path(__file__).parent


def _load(name: str):
    return json.loads((ROOT / "gate_contracts" / name).read_text(encoding="utf-8"))


def test_gate_contract_canonical_fixtures():
    middleware = RSCTSemanticMiddleware()
    expected = {
        "block_evidence_to_truth.json": (GateDecision.BLOCK, "F-AI-02"),
        "warn_role_to_identity.json": (GateDecision.WARN, "F-AI-06"),
        "pass_evidence_to_claim.json": (GateDecision.PASS, None),
        "defer_invalid_contract.json": (GateDecision.DEFER, "F-AI-16"),
    }
    for name, (decision, first_code) in expected.items():
        result = middleware.gate_contract(_load(name))
        assert result.decision is decision, name
        if first_code is None:
            assert result.failure_codes == (), name
        else:
            assert result.failure_codes[0].value == first_code, name


def test_gate_trace_canonical_fixtures():
    middleware = RSCTSemanticMiddleware()
    trace_root = ROOT / "ai_traces"
    expected = {
        "evidence_to_truth_cross_step.json": (GateDecision.BLOCK, "F-AI-09"),
        "memory_to_belief_cross_step.json": (GateDecision.BLOCK, "F-AI-10"),
        "inference_to_truth_cross_step.json": (GateDecision.BLOCK, "F-AI-11"),
        "role_to_identity_cross_step.json": (GateDecision.WARN, "F-AI-12"),
        "claim_to_truth_cross_step.json": (GateDecision.BLOCK, "F-AI-13"),
        "belief_to_truth_cross_step.json": (GateDecision.BLOCK, "F-AI-14"),
        "observation_to_truth_cross_step.json": (GateDecision.BLOCK, "F-AI-15"),
        "legal_reasoning_trace.json": (GateDecision.PASS, None),
    }
    for name, (decision, first_code) in expected.items():
        payload = json.loads((trace_root / name).read_text(encoding="utf-8"))
        result = middleware.gate_trace_contract(payload)
        assert result.decision is decision, name
        if first_code is None:
            assert result.failure_codes == (), name
        else:
            assert result.failure_codes[0].value == first_code, name
