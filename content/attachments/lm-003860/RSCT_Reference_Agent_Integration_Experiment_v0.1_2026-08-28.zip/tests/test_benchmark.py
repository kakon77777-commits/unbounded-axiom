import json

import pytest

from rsct.benchmark import (
    BenchmarkCase,
    BenchmarkExpected,
    BenchmarkPrediction,
    load_benchmark_cases,
    run_passthrough_baseline,
    score_predictions,
)
from rsct.gate import GateDecision


def _case(case_id, decision, codes=(), actions=(), category="test"):
    return BenchmarkCase(
        case_id=case_id,
        category=category,
        input_kind="contract",
        payload={"version": "0.1", "nodes": [], "edges": []},
        expected=BenchmarkExpected(
            decision=GateDecision(decision),
            failure_codes=tuple(codes),
            repair_actions=tuple(actions),
        ),
        tags=(),
    )


def _pred(case_id, decision, codes=(), actions=()):
    return BenchmarkPrediction(
        case_id=case_id,
        decision=GateDecision(decision),
        failure_codes=tuple(codes),
        repair_actions=tuple(actions),
    )


def test_score_predictions_computes_decision_and_intervention_metrics():
    cases = (
        _case("b", "BLOCK", ("F-AI-X",), ("FIX",)),
        _case("w", "WARN", ("F-AI-W",), ("WARN_FIX",)),
        _case("p", "PASS"),
        _case("d", "DEFER", ("F-AI-D",)),
    )
    preds = (
        _pred("b", "BLOCK", ("F-AI-X",), ("FIX",)),
        _pred("w", "PASS"),
        _pred("p", "PASS"),
        _pred("d", "DEFER", ("F-AI-D",)),
    )

    metrics = score_predictions(cases, preds)

    assert metrics.total_cases == 4
    assert metrics.decision_accuracy == pytest.approx(0.75)
    assert metrics.block_recall == pytest.approx(1.0)
    assert metrics.warn_recall == pytest.approx(0.0)
    assert metrics.defer_accuracy == pytest.approx(1.0)
    assert metrics.intervention_recall == pytest.approx(0.5)
    assert metrics.intervention_precision == pytest.approx(1.0)
    assert metrics.failure_code_exact_accuracy == pytest.approx(0.75)
    assert metrics.repair_action_exact_accuracy == pytest.approx(0.75)
    assert metrics.confusion["WARN"]["PASS"] == 1


def test_passthrough_baseline_predicts_pass_without_semantic_claims():
    cases = (
        _case("b", "BLOCK", ("F-AI-X",)),
        _case("p", "PASS"),
    )
    run = run_passthrough_baseline(cases)
    assert [p.decision.value for p in run.predictions] == ["PASS", "PASS"]
    assert run.metrics.decision_accuracy == pytest.approx(0.5)
    assert run.metrics.block_recall == pytest.approx(0.0)
    assert run.metrics.intervention_precision == pytest.approx(0.0)
    assert run.metrics.intervention_recall == pytest.approx(0.0)


def test_score_predictions_requires_exact_case_coverage():
    cases = (_case("a", "PASS"), _case("b", "PASS"))
    with pytest.raises(ValueError, match="prediction coverage mismatch"):
        score_predictions(cases, (_pred("a", "PASS"),))


def test_load_benchmark_cases_reads_jsonl_and_rejects_duplicate_ids(tmp_path):
    path = tmp_path / "cases.jsonl"
    record = {
        "case_id": "c1",
        "category": "legal",
        "input_kind": "contract",
        "payload": {"version": "0.1", "nodes": [], "edges": []},
        "expected": {"decision": "PASS", "failure_codes": [], "repair_actions": []},
        "tags": ["safe"],
    }
    path.write_text(json.dumps(record) + "\n" + json.dumps(record) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="duplicate benchmark case id"):
        load_benchmark_cases(path)

from rsct.benchmark import run_gate_benchmark
from rsct.middleware import RSCTSemanticMiddleware


def test_gate_runner_scores_canonical_semantics_exactly(tmp_path):
    case = BenchmarkCase(
        case_id="gate-1",
        category="evidence_truth",
        input_kind="contract",
        payload={
            "version": "0.1",
            "nodes": [
                {"id": "e", "type": "EvidenceState", "provenance": "test"},
                {"id": "t", "type": "TruthValueLabel", "provenance": "test"},
            ],
            "edges": [{"id": "x", "source": "e", "target": "t", "type": "TYPE_COERCION"}],
        },
        expected=BenchmarkExpected(
            decision=GateDecision.BLOCK,
            failure_codes=("F-AI-02",),
            repair_actions=("INSERT_EVALUATION",),
        ),
    )
    run = run_gate_benchmark((case,), RSCTSemanticMiddleware())
    assert run.engine == "rsct-gate-v0.2"
    assert run.metrics.decision_accuracy == 1.0
    assert run.metrics.failure_code_exact_accuracy == 1.0
    assert run.metrics.repair_action_exact_accuracy == 1.0


def test_score_predictions_rejects_duplicate_prediction_ids():
    cases = (_case("a", "PASS"),)
    predictions = (_pred("a", "PASS"), _pred("a", "PASS"))
    with pytest.raises(ValueError, match="duplicate prediction case_id"):
        score_predictions(cases, predictions)
