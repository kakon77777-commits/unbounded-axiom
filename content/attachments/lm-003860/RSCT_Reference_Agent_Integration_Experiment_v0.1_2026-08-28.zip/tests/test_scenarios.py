from rsct.model import SemanticType
from rsct.parser import parse_surface
from rsct.reference import classify_self_reference
from rsct.semantic import build_semantic_graph


def _graph(text: str):
    return build_semantic_graph(parse_surface(text))


def test_liar_graph_preserves_typed_layers_and_path_generated_self_reference():
    graph = _graph("這句話是假的。")
    types = graph.node_types()
    assert SemanticType.SENTENCE_TOKEN in types
    assert SemanticType.PROPOSITION in types
    assert SemanticType.TRUTH_BEARER in types
    assert SemanticType.FALSE_PREDICATE in types
    result = classify_self_reference(graph)
    assert result["detected"] is True
    assert result["kind"] == "PATH_GENERATED_SELF_REFERENCE"
    assert len(result["path"]) >= 3


def test_harmless_self_reference_has_no_false_predicate():
    graph = _graph("這句話是中文。")
    assert classify_self_reference(graph)["detected"] is True
    assert SemanticType.FALSE_PREDICATE not in graph.node_types()


def test_external_false_predicate_has_no_self_reference():
    graph = _graph("「雪是黑的」是假的。")
    assert SemanticType.FALSE_PREDICATE in graph.node_types()
    assert classify_self_reference(graph)["detected"] is False


def test_role_reification_is_explicit_and_warned():
    graph = _graph("他說過謊，所以他就是永遠的說謊者。")
    assert SemanticType.ACT_REL in graph.node_types()
    assert SemanticType.ROLE in graph.node_types()
    assert SemanticType.IDENTITY in graph.node_types()
    assert any(edge.edge_type == "ROLE_REIFICATION" for edge in graph.edges)
    assert "role-to-identity escalation" in graph.warnings


def test_bidirectional_heterogeneous_relations_are_not_collapsed_to_symmetry():
    graph = _graph("A 照顧 B，但 B 管理 A。")
    relation_edges = [edge for edge in graph.edges if edge.edge_type == "RELATION"]
    assert len(relation_edges) == 2
    assert {(edge.source, edge.target) for edge in relation_edges} == {("entity:A", "entity:B"), ("entity:B", "entity:A")}
    assert {edge.operator for edge in relation_edges} == {"CARE", "MANAGE"}


def test_evidence_conflict_does_not_assign_truth_value():
    graph = _graph("有研究支持 P，也有研究反對 P。")
    assert SemanticType.EVIDENCE_STATE in graph.node_types()
    assert SemanticType.TRUTH_VALUE_LABEL not in graph.node_types()
    assert {edge.edge_type for edge in graph.edges} >= {"EVIDENCE_SUPPORT", "EVIDENCE_OPPOSE"}


def test_simple_fact_produces_truth_bearer_without_self_reference():
    graph = _graph("雪是白的。")
    assert SemanticType.TRUTH_BEARER in graph.node_types()
    assert classify_self_reference(graph)["detected"] is False
