from rsct.model import AnalysisStatus
from rsct.parser import parse_surface


def test_liar_pattern_preserves_exact_surface_spans():
    ir = parse_surface("這句話是假的。")
    assert ir.pattern == "LIAR_CLASSICAL"
    assert ir.status is AnalysisStatus.PASS
    assert ir.tokens[0].surface == "這句話"
    assert ir.tokens[0].span.start == 0
    assert ir.tokens[0].span.end == 3
    assert ir.tokens[1].surface == "是假的"


def test_harmless_self_reference_pattern():
    ir = parse_surface("這句話是中文。")
    assert ir.pattern == "SELF_LANGUAGE"


def test_external_false_predicate_pattern():
    ir = parse_surface("「雪是黑的」是假的。")
    assert ir.pattern == "EXTERNAL_FALSE"
    assert ir.metadata["quoted"] == "雪是黑的"


def test_simple_fact_pattern():
    ir = parse_surface("雪是白的。")
    assert ir.pattern == "SIMPLE_FACT"


def test_role_reification_pattern():
    ir = parse_surface("他說過謊，所以他就是永遠的說謊者。")
    assert ir.pattern == "ROLE_REIFICATION"


def test_bidirectional_heterogeneous_pattern():
    ir = parse_surface("A 照顧 B，但 B 管理 A。")
    assert ir.pattern == "BIDIRECTIONAL_HETEROGENEOUS"


def test_evidence_conflict_pattern():
    ir = parse_surface("有研究支持 P，也有研究反對 P。")
    assert ir.pattern == "EVIDENCE_CONFLICT"


def test_unsupported_input_is_partial_not_fabricated():
    ir = parse_surface("這是一個目前沒有規則的輸入。")
    assert ir.pattern == "UNSUPPORTED"
    assert ir.status is AnalysisStatus.PARTIAL
    assert ir.tokens == ()
