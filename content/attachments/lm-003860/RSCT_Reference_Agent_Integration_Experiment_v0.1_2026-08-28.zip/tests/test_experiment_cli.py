import json

from rsct.cli import main


def test_experiment_reference_agent_cli_json_scripted(capsys):
    code = main([
        "experiment-reference-agent",
        "benchmarks/semantic_error_v0.1/cases.jsonl",
        "--provider",
        "scripted",
        "--max-repairs",
        "1",
        "--json",
    ])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["provider_kind"] == "scripted-reference-agent"
    assert payload["external_model_evidence"] is False
    assert payload["metrics"]["gate_decision_accuracy"] == 1.0
    assert payload["metrics"]["repair_success_rate"] == 1.0
    assert len(payload["results"]) == 88


def test_experiment_reference_agent_cli_replay_requires_file(capsys):
    code = main([
        "experiment-reference-agent",
        "benchmarks/semantic_error_v0.1/cases.jsonl",
        "--provider",
        "replay",
        "--json",
    ])
    assert code == 2
    assert "--replay is required" in capsys.readouterr().out
