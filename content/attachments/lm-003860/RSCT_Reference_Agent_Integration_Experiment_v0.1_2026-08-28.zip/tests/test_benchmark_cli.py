import json
from pathlib import Path

from rsct.cli import main


DATASET = Path("benchmarks/semantic_error_v0.1/cases.jsonl")


def test_benchmark_cli_gate_json_reports_metrics(capsys):
    code = main(["benchmark", str(DATASET), "--engine", "gate", "--json"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["engine"] == "rsct-gate-v0.2"
    assert payload["metrics"]["total_cases"] == 88
    assert payload["metrics"]["decision_accuracy"] == 1.0


def test_benchmark_cli_passthrough_is_explicit_control(capsys):
    code = main(["benchmark", str(DATASET), "--engine", "passthrough", "--json"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["engine"] == "passthrough"
    assert payload["metrics"]["decision_accuracy"] < 1.0
    assert payload["metrics"]["block_recall"] == 0.0


def test_benchmark_score_cli_scores_external_predictions(tmp_path, capsys):
    rows = []
    for raw in DATASET.read_text(encoding="utf-8").splitlines():
        case = json.loads(raw)
        rows.append(json.dumps({"case_id": case["case_id"], **case["expected"]}, ensure_ascii=False))
    predictions = tmp_path / "predictions.jsonl"
    predictions.write_text("\n".join(rows) + "\n", encoding="utf-8")

    code = main(["benchmark-score", str(DATASET), str(predictions), "--json"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["engine"] == "external-predictions"
    assert payload["metrics"]["decision_accuracy"] == 1.0


def test_benchmark_score_cli_rejects_incomplete_predictions(tmp_path, capsys):
    predictions = tmp_path / "bad.jsonl"
    predictions.write_text(json.dumps({"case_id": "SEB-01-01", "decision": "PASS"}) + "\n", encoding="utf-8")
    code = main(["benchmark-score", str(DATASET), str(predictions), "--json"])
    assert code == 2
    assert "prediction coverage mismatch" in capsys.readouterr().out
