from collections import Counter
from pathlib import Path

from rsct.benchmark import load_benchmark_cases


DATASET = Path("benchmarks/semantic_error_v0.1/cases.jsonl")


def test_canonical_benchmark_has_expected_size_and_decision_distribution():
    cases = load_benchmark_cases(DATASET)
    assert len(cases) == 88
    counts = Counter(case.expected.decision.value for case in cases)
    assert counts == {"BLOCK": 48, "WARN": 12, "PASS": 20, "DEFER": 8}


def test_canonical_benchmark_has_22_categories_with_four_variants_each():
    cases = load_benchmark_cases(DATASET)
    counts = Counter(case.category for case in cases)
    assert len(counts) == 22
    assert set(counts.values()) == {4}


def test_canonical_benchmark_ids_are_unique_and_structured():
    cases = load_benchmark_cases(DATASET)
    ids = [case.case_id for case in cases]
    assert len(ids) == len(set(ids))
    assert all(case_id.startswith("SEB-") for case_id in ids)
    assert all(case.input_kind in {"contract", "reasoning_trace"} for case in cases)


def test_defer_cases_are_explicit_invalid_input_cases():
    cases = load_benchmark_cases(DATASET)
    deferred = [case for case in cases if case.expected.decision.value == "DEFER"]
    assert len(deferred) == 8
    assert all("invalid" in case.tags for case in deferred)
    assert all(case.expected.failure_codes == ("F-AI-16",) for case in deferred)

from rsct.benchmark import run_gate_benchmark, run_passthrough_baseline


def test_canonical_dataset_replays_exactly_against_frozen_gate():
    cases = load_benchmark_cases(DATASET)
    run = run_gate_benchmark(cases)
    assert run.metrics.decision_accuracy == 1.0
    assert run.metrics.block_recall == 1.0
    assert run.metrics.warn_recall == 1.0
    assert run.metrics.defer_accuracy == 1.0
    assert run.metrics.failure_code_exact_accuracy == 1.0
    assert run.metrics.repair_action_exact_accuracy == 1.0


def test_passthrough_control_has_no_semantic_intervention_recall():
    cases = load_benchmark_cases(DATASET)
    run = run_passthrough_baseline(cases)
    assert run.metrics.decision_accuracy == 20 / 88
    assert run.metrics.block_recall == 0.0
    assert run.metrics.warn_recall == 0.0
    assert run.metrics.defer_accuracy == 0.0
    assert run.metrics.intervention_precision == 0.0
    assert run.metrics.intervention_recall == 0.0
