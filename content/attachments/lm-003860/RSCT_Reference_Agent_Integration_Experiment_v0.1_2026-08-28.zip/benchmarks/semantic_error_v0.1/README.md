# RSCT Semantic Error Benchmark v0.1

This is a **controlled, in-distribution conformance benchmark** for RSCT Agent Semantic Gate v0.2. It is not evidence that RSCT improves an arbitrary external LLM unless external model predictions are separately collected and scored.

Dataset: `cases.jsonl`

Composition:

- 88 total cases
- 22 semantic categories
- 4 structural/provenance variants per category
- 48 expected `BLOCK`
- 12 expected `WARN`
- 20 expected `PASS`
- 8 expected `DEFER`

The benchmark covers single-contract and cross-step semantic collapses, role-to-identity warnings, projection declarations, legal semantic paths, and fail-closed invalid input handling.
