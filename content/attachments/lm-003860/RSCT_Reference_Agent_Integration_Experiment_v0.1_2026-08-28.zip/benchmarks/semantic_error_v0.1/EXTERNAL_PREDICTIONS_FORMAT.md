# External prediction format

Use one JSON object per benchmark case:

```json
{"case_id":"SEB-01-01","decision":"BLOCK","failure_codes":["F-AI-02"],"repair_actions":["INSERT_EVALUATION"]}
```

Required fields:

- `case_id`
- `decision`: one of `PASS`, `WARN`, `BLOCK`, `DEFER`

Optional fields default to empty lists:

- `failure_codes`
- `repair_actions`

Every benchmark case must appear exactly once and no extra case IDs are allowed.

Score with:

```bash
rsct benchmark-score benchmarks/semantic_error_v0.1/cases.jsonl model_predictions.jsonl --json
```

A model result should only be described as an external RSCT A/B experiment when the predictions were actually produced by that model or Agent pipeline. The bundled pass-through result is only a non-semantic control.
