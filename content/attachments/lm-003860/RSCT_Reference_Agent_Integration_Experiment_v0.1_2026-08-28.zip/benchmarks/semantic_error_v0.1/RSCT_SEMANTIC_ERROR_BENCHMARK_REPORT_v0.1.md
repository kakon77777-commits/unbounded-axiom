# RSCT Semantic Error Benchmark Report v0.1

**Date:** 2026-08-28  
**Runtime under test:** RSCT Agent Semantic Gate v0.2  
**Dataset:** `cases.jsonl`  
**Cases:** 88  
**Evaluation type:** controlled canonical conformance / in-distribution benchmark

## 1. What this result supports

This benchmark tests whether the implemented RSCT v0.2 Gate behaves consistently with its own canonical semantic contracts across structurally varied fixtures. It supports claims about deterministic conformance and regression safety.

It does **not** by itself support a claim that an arbitrary external LLM becomes more accurate when RSCT is attached. No external model generations were used in the bundled results.

## 2. Dataset composition

| Expected decision | Cases |
|---|---:|
| BLOCK | 48 |
| WARN | 12 |
| PASS | 20 |
| DEFER | 8 |
| **Total** | **88** |

The 88 cases contain 22 semantic categories with four structural/provenance variants per category.

The categories include:

- single-contract Evidence → Truth;
- Claim → Truth;
- BeliefState → Truth;
- MemoryRecord → BeliefState;
- Inference → Truth;
- Observation → Truth;
- Role → Identity;
- undeclared projection loss;
- legal evaluation paths;
- cross-step versions of the major semantic collapses;
- legal reasoning traces;
- invalid contract/trace inputs that must fail closed with DEFER.

## 3. RSCT Gate result

Raw result: `results/rsct_gate_v0.2.json`

| Metric | Result |
|---|---:|
| Exact decision accuracy | **100.00%** |
| BLOCK recall | **100.00%** |
| WARN recall | **100.00%** |
| DEFER accuracy | **100.00%** |
| Intervention precision | **100.00%** |
| Intervention recall | **100.00%** |
| Intervention F1 | **100.00%** |
| Exact failure-code accuracy | **100.00%** |
| Exact repair-action accuracy | **100.00%** |

All 88 canonical expected decision/code/repair labels matched the actual deterministic Gate output.

This is expected for a conformance benchmark derived from the same frozen semantic contract; the value is reproducible specification compliance, not generalization evidence.

## 4. Pass-through control

Raw result: `results/passthrough_control.json`

The pass-through control predicts `PASS` for every case and performs no semantic audit. It is not an AI model.

| Metric | Result |
|---|---:|
| Exact decision accuracy | **22.73%** |
| BLOCK recall | **0.00%** |
| WARN recall | **0.00%** |
| DEFER accuracy | **0.00%** |
| Intervention precision | **0.00%** |
| Intervention recall | **0.00%** |
| Intervention F1 | **0.00%** |
| Exact failure-code accuracy | **22.73%** |
| Exact repair-action accuracy | **31.82%** |

The control is correct only on cases whose canonical expected decision is already PASS.

## 5. Interpretation

The experiment establishes the following engineering statement:

$$
\boxed{
\text{The frozen RSCT Gate implementation conforms to the v0.1 canonical semantic-error benchmark.}
}
$$

It does not yet establish:

$$
\boxed{
\text{RSCT improves arbitrary external AI reasoning accuracy.}
}
$$

That second statement requires external model predictions or Agent trajectories generated without RSCT and with RSCT under a controlled protocol.

## 6. External A/B interface

The benchmark runner supports external prediction JSONL files. The external system supplies one prediction per case:

```json
{"case_id":"SEB-01-01","decision":"BLOCK","failure_codes":["F-AI-02"],"repair_actions":["INSERT_EVALUATION"]}
```

Then run:

```bash
rsct benchmark-score benchmarks/semantic_error_v0.1/cases.jsonl model_predictions.jsonl --json
```

This permits future comparisons such as:

$$
\text{AI without RSCT}
\quad\text{vs}\quad
\text{AI + RSCT Gate}
$$

without changing the benchmark labels after seeing model outputs.

## 7. Reproducibility commands

```bash
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine gate --json
rsct benchmark benchmarks/semantic_error_v0.1/cases.jsonl --engine passthrough --json
pytest -q
```

The raw benchmark result files are bundled beside this report.
