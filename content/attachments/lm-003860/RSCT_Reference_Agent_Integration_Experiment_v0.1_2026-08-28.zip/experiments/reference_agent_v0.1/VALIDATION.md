# RSCT × Reference Agent Integration Experiment v0.1 — Validation

- Date: 2026-08-28
- Branch: workbench/reference-agent-integration-experiment-v0.1
- Python: 3.13.5
- Full regression: 137/137 PASS
- compileall: PASS
- git diff --check: PASS
- classical liar regression: `NO_FIXED_POINT`
- Provider: `scripted-reference-agent`
- External model evidence: `false`
- Cases: 88
- Baseline unsafe accept rate on expected BLOCK: 1.000000
- Gated BLOCK escape rate: 0.000000
- Completion rate: 0.909091
- Intervention rate: 0.681818
- Repair success rate: 1.000000
- False positive rate: 0.000000
- DEFER rate: 0.090909
- Mean extra agent steps: 0.545455
- Gate decision accuracy: 1.000000
- Harness elapsed seconds: 0.00518263

Scientific boundary: this is a scripted integration-harness validation, not evidence of improvement on an external LLM/Agent.
