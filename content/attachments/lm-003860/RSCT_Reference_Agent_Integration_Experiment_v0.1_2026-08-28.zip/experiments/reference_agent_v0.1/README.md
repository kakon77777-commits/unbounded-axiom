# Reference Agent Integration Experiment v0.1

Provider-neutral A/B harness for agent-only vs Agent + RSCT Gate.

- `scripted_reference_results.json`: deterministic integration result.
- `REPORT.md`: scientific boundary and metrics.
- External model replay format is documented in the report and reference spec.
