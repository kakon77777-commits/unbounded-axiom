# RSCT × Reference Agent Integration Experiment v0.1 — Scripted Reference Report

## Status

This is an integration-harness result using `scripted-reference-agent`.

**External model evidence:** `false`

It validates A/B orchestration, Gate intervention, replayable repair loops, metrics, and evidence serialization. It does **not** demonstrate improvement on GPT, Claude, local LLMs, or any other external model.

## A/B definition

- Arm A — Agent-only: accept the first semantic output without RSCT intervention.
- Arm B — Agent + RSCT: gate the same first output; BLOCK requests at most one scripted repair, WARN/PASS continue, DEFER stops fail-closed.

## Frozen dataset

- Cases: 88
- Source: `benchmarks/semantic_error_v0.1/cases.jsonl`
- Expected distribution: 48 BLOCK / 12 WARN / 20 PASS / 8 DEFER.

## Scripted integration results

| Metric | Result |
|---|---:|
| Baseline unsafe accept rate on expected BLOCK | 1.0000 |
| Gated BLOCK escape rate | 0.0000 |
| Gated completion rate | 0.9091 |
| Intervention rate | 0.6818 |
| Repair attempt rate | 0.5455 |
| Repair success rate | 1.0000 |
| False positive rate on expected PASS | 0.0000 |
| DEFER rate | 0.0909 |
| Mean extra agent steps | 0.5455 |
| Initial Gate decision accuracy | 1.0000 |
| Harness elapsed seconds | 0.004849 |
| Mean case seconds | 0.00005510 |

The scripted provider intentionally returns a canonical-safe contract after a BLOCK repair request. Therefore the 100% repair success is a **harness conformance property**, not an estimate of real-model repair ability.

## External replay interface

Use one JSON object per case:

```json
{"case_id":"SEB-01-01","provider":"model-name","initial":{...},"repairs":[{...}]}
```

Then run:

```bash
rsct experiment-reference-agent benchmarks/semantic_error_v0.1/cases.jsonl \
  --provider replay \
  --replay external_agent_outputs.jsonl \
  --max-repairs 1 \
  --json
```

The replay file must cover every benchmark case exactly once. Missing or duplicate case IDs fail closed.

## Scientific boundary

The next valid efficacy claim requires actual external-agent outputs. The experiment harness is ready for that step, but this report deliberately makes no external-model performance claim.
