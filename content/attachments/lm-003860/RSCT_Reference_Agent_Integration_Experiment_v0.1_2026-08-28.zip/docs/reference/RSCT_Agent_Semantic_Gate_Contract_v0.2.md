# RSCT Agent Semantic Gate Contract v0.2

**Component:** RSCT Semantic Analyzer Runtime  
**Layer:** AI-facing deterministic middleware  
**Version:** 0.2  
**Status:** Canonical engineering contract

## 1. Purpose

The Agent Semantic Gate turns existing RSCT semantic-audit findings into a deterministic continuation decision for an AI/Agent pipeline. It does not replace the audit layer and does not mutate the submitted graph or reasoning trace.

Canonical flow:

$$
\boxed{
\text{Agent Semantic State}
\rightarrow
\text{RSCT Audit}
\rightarrow
\text{Gate Decision}
\rightarrow
\text{Repair Plan / Continue}
}
$$

## 2. Decisions

The gate returns exactly one of:

```text
PASS
WARN
BLOCK
DEFER
```

Decision semantics:

| Decision | Meaning | Agent may continue |
| --- | --- | --- |
| `PASS` | No semantic findings under the active deterministic policy | yes |
| `WARN` | Warning-only findings; semantics remain executable but must retain warnings | yes |
| `BLOCK` | One or more error findings would permit a prohibited semantic collapse | no |
| `DEFER` | Input cannot be safely interpreted as a valid RSCT contract/trace | no |

Canonical reduction policy:

```text
ERROR finding   => BLOCK
WARNING-only    => WARN
No findings     => PASS
Invalid input   => DEFER
```

## 3. Exit codes

CLI contract:

```text
PASS  -> 0
WARN  -> 0
BLOCK -> 1
DEFER -> 2
```

`WARN` is intentionally non-blocking in v0.2. Warning provenance must remain attached to downstream state.

## 4. Default active assumptions

Every result records the active gate assumptions:

```json
{
  "AUTO_APPLY_REPAIRS": false,
  "DEFER_ON_INVALID_INPUT": true,
  "ALLOW_WARNING_CONTINUE": true,
  "DETERMINISTIC_POLICY": true
}
```

These are evidence about the decision policy; they are not claims about the world.

## 5. Decision provenance

Every gate result must include:

```text
policy_id
policy_version
input_kind
rule
evaluated_finding_count
```

Canonical identity:

```text
policy_id = rsct-agent-semantic-gate
policy_version = 0.2
```

Input kinds:

```text
contract
reasoning_trace
```

## 6. Repair actions

Repairs are proposals only. They never mutate submitted semantic state.

Canonical actions currently include:

```text
INSERT_EVALUATION
PRESERVE_AS_CLAIM
REVALIDATE_MEMORY
KEEP_ROLE_SCOPED
DECLARE_PROJECTION_LOSS
```

Examples:

$$
\text{EvidenceState}
\rightarrow
\text{TruthValueLabel}
$$

produces:

```text
BLOCK
F-AI-02
INSERT_EVALUATION
```

while:

$$
\text{Role}
\rightarrow
\text{Identity}
$$

produces:

```text
WARN
F-AI-06
KEEP_ROLE_SCOPED
```

## 7. Trace behavior

For reasoning traces, the gate combines:

1. step-local audit findings; and
2. cross-step carry-over findings.

Therefore:

$$
\boxed{
\text{Step-local validity}
\not\Rightarrow
\text{Trace-global semantic safety}
}
$$

A repair action must localize either the failing edge or carry-over identifier.

## 8. API

Primary middleware methods:

```python
RSCTSemanticMiddleware.gate_contract(payload)
RSCTSemanticMiddleware.gate_trace_contract(payload)
RSCTSemanticMiddleware.gate(payload)
```

`gate(payload)` auto-detects a reasoning trace when `steps` or `trace_id` is present; otherwise it treats the payload as a single semantic contract.

## 9. CLI

```bash
rsct gate-ai contract.json
rsct gate-ai --json contract.json
rsct gate-ai-trace trace.json
rsct gate-ai-trace --json trace.json
cat contract.json | rsct gate-ai --json -
cat trace.json | rsct gate-ai-trace --json -
```

## 10. JSON result shape

```json
{
  "decision": "BLOCK",
  "may_continue": false,
  "failure_codes": ["F-AI-02"],
  "repair_actions": [
    {
      "action": "INSERT_EVALUATION",
      "finding_code": "F-AI-02",
      "target_id": "edge-1",
      "source_step": null,
      "target_step": null,
      "instruction": "..."
    }
  ],
  "active_assumptions": {},
  "decision_provenance": {
    "policy_id": "rsct-agent-semantic-gate",
    "policy_version": "0.2",
    "input_kind": "contract",
    "rule": "ERROR_FINDING=>BLOCK",
    "evaluated_finding_count": 1
  },
  "reason": "..."
}
```

## 11. Safety invariants

The gate preserves all v0.1 semantic invariants, including:

$$
\text{Evidence} \neq \text{Truth},
$$

$$
\text{Claim} \neq \text{Truth},
$$

$$
\text{BeliefState} \neq \text{Truth},
$$

$$
\text{Observation} \neq \text{Truth},
$$

$$
\text{Inference} \neq \text{Truth},
$$

$$
\text{MemoryRecord} \neq \text{BeliefState},
$$

$$
\text{Role} \neq \text{Identity}.
$$

It additionally fixes:

$$
\boxed{
\text{Audit Finding}
\neq
\text{Automatic Repair}
}
$$

and:

$$
\boxed{
\text{Gate Decision}
\neq
\text{Truth Claim}
}
$$

A `BLOCK` means the active semantic contract is unsafe to continue under the current RSCT policy. It does not mean the underlying proposition is false.

## 12. New failure code

```text
F-AI-16 AI_GATE_INPUT_INVALID
```

This code is used with `DEFER` when a submitted contract or reasoning trace cannot satisfy its structural input contract.

## 13. Non-goals

v0.2 does not:

- automatically rewrite Agent memory or reasoning state;
- expose or require private chain-of-thought;
- decide world truth from model text;
- replace the existing audit result;
- infer arbitrary missing semantic structure;
- turn warnings into identity or truth judgments.

The expected integration surface is an explicit typed semantic contract or structured reasoning summary.
