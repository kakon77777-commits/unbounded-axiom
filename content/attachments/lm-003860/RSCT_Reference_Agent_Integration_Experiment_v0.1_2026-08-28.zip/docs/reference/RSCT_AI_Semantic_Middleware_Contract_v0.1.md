# RSCT AI Semantic Middleware Contract v0.1

**Status:** Canonical MVP contract addendum  
**Parent runtime:** RSCT Semantic Analyzer Runtime MVP v0.1  
**Date:** 2026-08-28  

## 1. Purpose

The AI-facing middleware accepts a structured semantic contract proposed by an AI/agent and validates it with the deterministic RSCT core.

The governing rule is:

$$
\boxed{
\text{AI proposes semantic structure; RSCT Core validates it.}
}
$$

The middleware does not infer truth from model confidence and does not silently repair submitted graphs.

## 2. Canonical AI semantic distinctions

The MVP preserves:

$$
\boxed{
\text{Claim}
\neq
\text{Truth}
}
$$

$$
\boxed{
\text{Evidence}
\neq
\text{Truth}
}
$$

$$
\boxed{
\text{BeliefState}
\neq
\text{Truth}
}
$$

$$
\boxed{
\text{MemoryRecord}
\neq
\text{BeliefState}
}
$$

$$
\boxed{
\text{Inference}
\neq
\text{Truth}
}
$$

$$
\boxed{
\text{Observation}
\neq
\text{Truth}
}
$$

$$
\boxed{
\text{Role}
\neq
\text{Identity}
}
$$

## 3. JSON contract

Minimum top-level structure:

```json
{
  "version": "0.1",
  "nodes": [],
  "edges": []
}
```

Every node must contain:

```text
id
type
provenance
```

Optional node fields:

```text
surface
context
observer
state
inferred
```

Every edge must contain:

```text
id
source
target
type
```

Optional edge fields:

```text
operator
direction
constraints
projection
provenance
```

## 4. AI-facing semantic node types

The v0.1 extension supports the existing RSCT types plus:

```text
Claim
Observation
MemoryRecord
BeliefState
Inference
Evaluation
```

`TruthValueLabel`, `EvidenceState`, `Role`, and `Identity` remain existing canonical RSCT types and are reused directly.

## 5. Legal evaluation path

The preferred minimum path is:

$$
\boxed{
\text{Evidence}
\rightarrow
\text{Claim}
\rightarrow
\text{Evaluation}
\rightarrow
\text{TruthValueLabel}
}
$$

The last step must be an explicit projection. If the projection is lossy, that fact must be declared.

Example:

```json
{
  "version": "0.1",
  "nodes": [
    {"id": "e1", "type": "EvidenceState", "surface": "paper supports P", "provenance": "paper:1"},
    {"id": "c1", "type": "Claim", "surface": "P", "provenance": "agent:a"},
    {"id": "ev1", "type": "Evaluation", "surface": "evaluate P", "provenance": "rsct:classical"},
    {"id": "t1", "type": "TruthValueLabel", "surface": "T", "provenance": "rsct:classical"}
  ],
  "edges": [
    {"id": "x1", "source": "e1", "target": "c1", "type": "EVIDENCE_SUPPORT", "operator": "SUPPORTS"},
    {"id": "x2", "source": "c1", "target": "ev1", "type": "EVALUATION", "operator": "EVALUATE"},
    {"id": "x3", "source": "ev1", "target": "t1", "type": "PROJECTION", "operator": "TRUTH_PROJECT", "projection": {"lossy": true}}
  ]
}
```

## 6. Canonical audit failures

```text
F-AI-01 Claim -> Truth collapse
F-AI-02 Evidence -> Truth collapse
F-AI-03 BeliefState -> Truth collapse
F-AI-04 MemoryRecord -> BeliefState collapse
F-AI-05 Provenance missing (reserved for audit/report integration; contract loader currently rejects missing provenance before graph creation)
F-AI-06 Role -> Identity escalation
F-AI-07 Inference -> Truth collapse
F-AI-08 Observation -> Truth collapse
```

`F-AI-06` is currently a warning-level finding. The others listed above are error-level semantic collapses except `F-AI-05`, which is fail-closed at contract-load time.

## 7. Localized repair principle

The middleware does not mutate a graph automatically.

For every detected collapse it returns a repair hint describing the missing semantic layer. For example:

$$
\text{Evidence}
\rightarrow
\text{Truth}
$$

is repaired conceptually as:

$$
\boxed{
\text{Evidence}
\rightarrow
\text{Claim}
\rightarrow
\text{Evaluation}
\rightarrow
\text{Truth}
}
$$

A `MemoryRecord` must be retrieved as historical input and re-evaluated before it can become a current `BeliefState`.

## 8. CLI

```bash
rsct audit-ai tests/ai_contracts/evidence_to_truth_illegal.json
rsct audit-ai --json tests/ai_contracts/legal_evidence_claim_evaluation.json
cat contract.json | rsct audit-ai -
```

Exit code:

```text
0 = no ERROR-level semantic findings
1 = one or more ERROR-level semantic findings
2 = invalid contract / IO / CLI error
```

Warning-only contracts therefore return exit code `0` while preserving their findings.

## 9. AI integration boundary

A future AI/agent integration may emit candidate semantic contracts, but the AI must not directly determine:

```text
type safety
projection declaration validity
semantic collapse findings
fixed-point status
RSCT invariant pass/fail
```

These remain deterministic-core responsibilities.

## 10. MVP scope

This contract is intentionally structured and explicit. It is not a promise of arbitrary natural-language semantic parsing.

The first AI-facing MVP goal is semantic safety and auditability, not universal language understanding.


## 11. Reasoning trace addendum

Single-contract audit is step-local. Ordered Agent reasoning is covered by `RSCT_AI_Reasoning_Trace_Contract_v0.1.md`, which preserves explicit carry-over references between typed step contracts and adds cross-step semantic-collapse checks.

The additional invariant is:

$$
\boxed{
\text{Step-local validity}
\not\Rightarrow
\text{Trace-global semantic safety}.
}
$$
