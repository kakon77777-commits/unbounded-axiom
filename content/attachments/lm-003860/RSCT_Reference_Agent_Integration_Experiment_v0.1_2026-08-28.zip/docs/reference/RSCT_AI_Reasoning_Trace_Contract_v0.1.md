# RSCT AI Reasoning Trace Contract v0.1

**Status:** Canonical MVP trace-audit addendum  
**Parent:** RSCT AI Semantic Middleware Contract v0.1  
**Date:** 2026-08-28

## 1. Purpose

A single RSCT AI semantic contract audits one typed graph. An AI reasoning loop spans multiple graphs over time or across agent steps. This trace contract preserves those step boundaries and makes semantic carry-over explicit so the deterministic core can detect type collapse that occurs *between* individually valid steps.

The governing rule is:

$$
\boxed{
\text{Step-local validity}
\not\Rightarrow
\text{Trace-global semantic safety}.
}
$$

## 2. Top-level schema

```json
{
  "version": "0.1",
  "trace_id": "trace-001",
  "steps": [],
  "carry_over": []
}
```

Each `steps[]` entry contains:

```json
{
  "id": "s1",
  "contract": {
    "version": "0.1",
    "nodes": [],
    "edges": []
  }
}
```

Each `carry_over[]` entry contains:

```json
{
  "id": "co1",
  "source_step": "s1",
  "source_node": "e1",
  "target_step": "s2",
  "target_node": "c1",
  "relation": "SUPPORTS"
}
```

Carry-over references are fail-closed: referenced steps and nodes must exist.

## 3. Canonical safe reasoning path

A minimal cross-step evidence-to-truth path is:

$$
\boxed{
\text{Evidence}
\rightarrow
\text{Claim}
\rightarrow
\text{Evaluation}
\rightarrow
\text{TruthValueLabel}.
}
$$

The four nodes may live in separate reasoning steps. The trace contract preserves their typed transitions.

## 4. Cross-step failure codes

```text
F-AI-09 EvidenceState -> TruthValueLabel across steps
F-AI-10 MemoryRecord -> BeliefState across steps
F-AI-11 Inference -> TruthValueLabel across steps
F-AI-12 Role -> Identity across steps (warning)
F-AI-13 Claim -> TruthValueLabel across steps
F-AI-14 BeliefState -> TruthValueLabel across steps
F-AI-15 Observation -> TruthValueLabel across steps
```

`F-AI-12` is warning-level. The other cross-step codes are error-level.

## 5. Repair-plan contract

RSCT does not mutate the submitted trace. A repair plan is a deterministic recommendation layer.

Current actions:

```text
INSERT_EVALUATION
PRESERVE_AS_CLAIM
REVALIDATE_MEMORY
KEEP_ROLE_SCOPED
```

Every repair action contains:

```text
finding_code
carry_over_id
source_step
target_step
instruction
```

Therefore repair remains localized and auditable.

## 6. CLI

```bash
rsct audit-ai-trace tests/ai_traces/legal_reasoning_trace.json
rsct audit-ai-trace --json tests/ai_traces/evidence_to_truth_cross_step.json
rsct audit-ai-trace --json --repair-plan tests/ai_traces/evidence_to_truth_cross_step.json
cat trace.json | rsct audit-ai-trace --json -
```

Exit codes:

```text
0 = no ERROR-level findings
1 = one or more ERROR-level findings
2 = invalid trace / IO / CLI error
```

Warning-only trace findings preserve exit code `0`.

## 7. AI reasoning-loop integration

A recommended integration is:

$$
\boxed{
\text{Agent Step}
\rightarrow
\text{Typed Contract}
\rightarrow
\text{Trace Append}
\rightarrow
\text{RSCT Audit}
\rightarrow
\text{Localized Repair Recommendation}
\rightarrow
\text{Next Reasoning Step}.
}
$$

The AI may decide whether to revise or defer, but it cannot overwrite deterministic failure codes.

## 8. Non-goals

v0.1 does not:

- infer arbitrary reasoning traces from raw chain-of-thought;
- expose or require private chain-of-thought;
- mutate agent memory automatically;
- convert warnings into identity judgments;
- assign truth from model confidence;
- require an LLM.

The trace may contain explicit structured reasoning artifacts or externally generated semantic summaries. The deterministic core audits only the submitted typed structure.
