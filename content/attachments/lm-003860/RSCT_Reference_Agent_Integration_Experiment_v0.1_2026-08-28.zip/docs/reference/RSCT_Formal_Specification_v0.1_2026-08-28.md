# RSCT Formal Specification v0.1
## 關係語義構成論形式規格：型別、構造、作用、反身、張力、邊界與真值評價接口

**英文題名**：*RSCT Formal Specification v0.1: Types, Construction, Actuation, Reflexivity, Tension, Boundaries, and Truth-Evaluation Interfaces*  
**所屬理論**：關係語義構成論（Relational Semantic Construction Theory, RSCT）  
**依賴論文**：RSCT 00–06  
**作者**：Neo.K × GPT-5.6 Sol  
**機構**：EveMissLab（一言諾科技有限公司）  
**日期**：2026-08-28  
**版本**：v0.1  
**文件類型**：Canonical Formal Specification／Reference Contract  
**狀態**：第一版形式收斂稿  

---

## 0. 規格目的

本規格將 RSCT 00–06 的概念論述收斂成一套可供：

- 語義 parser；
- typed semantic graph；
- semantic analyzer；
- paradox analyzer；
- runtime validator；
- formal test harness；

使用的最低形式接口。

本規格不宣稱：

$$
\text{RSCT}
=
\text{一套已完備的自然語言語義學}.
$$

本規格只固定：

$$
\boxed{
\text{RSCT v0.1 的 canonical objects、types、operators、invariants 與 failure conditions}.
}
$$

---

# 1. 基本原則

## 1.1 詞彙單位不預設為語義原子

$$
\boxed{
\text{Lexical Unit}
\not\Rightarrow
\text{Semantic Atom}.
}
$$

任何輸入單位都只能先視為：

$$
x:\mathsf{SurfaceUnit}.
$$

只有經過：

$$
\operatorname{TypeInfer}
$$

後，才可進入 RSCT 的正式語義圖。

## 1.2 詞性不等於語義型別

$$
\boxed{
\text{PartOfSpeech}
\neq
\text{SemanticType}.
}
$$

## 1.3 構造先於評價

$$
\boxed{
\text{Parse}
\rightarrow
\text{Type}
\rightarrow
\text{Construct}
\rightarrow
\text{Relate}
\rightarrow
\text{Project}
\rightarrow
\text{Evaluate}.
}
$$

---

# 2. Canonical Type Universe

定義：

$$
\mathbb T_{\mathrm{RSCT}}
$$

為 RSCT v0.1 的型別宇宙。

最低包含：

$$
\mathbb T_{\mathrm{RSCT}}
=
\{
\mathsf{SurfaceUnit},
\mathsf{SentenceToken},
\mathsf{SentenceType},
\mathsf{Deictic},
\mathsf{ReferenceTarget},
\mathsf{Proposition},
\mathsf{TruthBearer},
\mathsf{Entity},
\mathsf{Relation},
\mathsf{ActRel},
\mathsf{Operator},
\mathsf{Constructor},
\mathsf{Role},
\mathsf{Identity},
\mathsf{Constraint},
\mathsf{State},
\mathsf{TensionState},
\mathsf{Boundary},
\mathsf{Extremum},
\mathsf{TruthValueLabel},
\mathsf{EvidenceState},
\mathsf{Projection},
\mathsf{Context},
\mathsf{Observer}
\}.
$$

---

# 3. 型別判定

使用：

$$
x:\tau
$$

表示：

$$
x
$$

具有型別：

$$
\tau.
$$

若：

$$
x
$$

同時可能具有多個合法工作型別，則：

$$
x:
\{\tau_1,\tau_2,\ldots,\tau_n\}.
$$

runtime 必須在每次算子呼叫前解析：

$$
\operatorname{ActiveType}(x,o,c).
$$

---

# 4. 型別安全規則

若：

$$
O:
\alpha
\rightarrow
\beta,
$$

則：

$$
O(x)
$$

只有在：

$$
x:\alpha
$$

時直接合法。

否則：

$$
O(x)\uparrow.
$$

若存在合法 coercion：

$$
C:
\gamma
\rightarrow
\alpha,
$$

才可：

$$
O(C(x)).
$$

---

# 5. Heterogeneous Semantic Construction

異質構造算子：

$$
\mathcal C_{\alpha_1,\ldots,\alpha_n\Rightarrow\beta}
:
\alpha_1
\times
\cdots
\times
\alpha_n
\rightarrow
\beta.
$$

例如：

$$
\mathsf{Agentize}
:
\mathsf{ActRel}
\rightarrow
\mathsf{Role}.
$$

因此：

$$
L:\mathsf{ActRel}
$$

可以得到：

$$
\mathsf{Agentize}(L):
\mathsf{Role}.
$$

---

# 6. Role 與 Identity 分離

角色生成：

$$
\mathsf{Agentize}
:
\mathsf{PredicateLike}
\rightarrow
\mathsf{Role}.
$$

角色綁定：

$$
\mathsf{Bind}
:
\mathsf{Role}
\times
\mathsf{Entity}
\times
\mathsf{Context}
\rightarrow
\mathsf{RoleAssignment}.
$$

本體化：

$$
\mathsf{Reify}
:
\mathsf{Role}
\rightarrow
\mathsf{Identity}.
$$

禁止默認：

$$
\mathsf{Role}
\equiv
\mathsf{Identity}.
$$

---

# 7. Construction Trace

任何正式構造：

$$
y
=
\mathcal C
(
x_1,\ldots,x_n
)
$$

必須保留：

$$
\operatorname{Trace}(y)
=
\langle
x_1:\alpha_1,
\ldots,
x_n:\alpha_n,
\mathcal C,
y:\beta
\rangle.
$$

---

# 8. Structural Actuation

定義：

$$
\mathsf{Actuation}(X)>0
$$

若 $X$ 對至少一種結構差異負責：

$$
\Delta_X
\neq
\varnothing.
$$

$\Delta_X$ 可以是：

$$
\{
\text{state},
\text{type},
\text{reachability},
\text{constraint},
\text{relation},
\text{reference},
\text{evaluation}
\}.
$$

---

# 9. Actuation Classes

最低包含：

$$
\mathsf{DirectActuation},
$$

$$
\mathsf{ConstructionActuation},
$$

$$
\mathsf{RelationalActuation},
$$

$$
\mathsf{SelectionActuation},
$$

$$
\mathsf{ReferenceActuation}.
$$

---

# 10. Directionality

若：

$$
O:
A
\rightarrow
B,
$$

則：

$$
\operatorname{dom}(O)=A,
$$

$$
\operatorname{cod}(O)=B.
$$

禁止默認：

$$
\text{Direction}
\Rightarrow
\text{PhysicalTime}.
$$

---

# 11. Bidirectional Pair

若：

$$
O_{AB}:A\rightarrow B,
$$

與：

$$
O_{BA}:B\rightarrow A,
$$

則：

$$
\mathbf B_{AB}
=
(
O_{AB},
O_{BA}
).
$$

必須保留兩方向的獨立型別與條件。

---

# 12. Bidirectionality Invariants

$$
\boxed{
\text{Bidirectionality}
\neq
\text{Symmetry}.
}
$$

$$
\boxed{
\text{Bidirectionality}
\neq
\text{Reciprocity}.
}
$$

$$
\boxed{
\text{Bidirectionality}
\neq
\text{Invertibility}.
}
$$

$$
\boxed{
\text{Reverse}
\neq
\text{Negation}.
}
$$

---

# 13. Directional Pair State

若：

$$
r_+\in\mathcal S_+,
$$

$$
r_-\in\mathcal S_-,
$$

則：

$$
\mathbf r
=
(r_+,r_-)
\in
\mathcal S^{\leftrightarrow},
$$

其中：

$$
\mathcal S^{\leftrightarrow}
=
\mathcal S_+
\times
\mathcal S_-.
$$

---

# 14. Quantification Interface

$$
Q:
\mathcal S_+
\times
\mathcal S_-
\rightarrow
\mathcal Q.
$$

禁止預設：

$$
\mathcal Q=\mathbb R.
$$

因此：

$$
\boxed{
\text{Quantifiable}
\neq
\text{Already Metric}.
}
$$

---

# 15. Return Composition

若：

$$
A
\xrightarrow{O_{AB}}
B
\xrightarrow{O_{BA}}
A,
$$

則：

$$
\Phi_A
=
O_{BA}
\circ
O_{AB}
:
A
\rightarrow
A.
$$

---

# 16. Generative Reflexivity

定義：

$$
\mathsf{GRef}(A)
$$

成立，若存在非空路徑：

$$
A
\rightarrow
X_1
\rightarrow
\cdots
\rightarrow
A
$$

生成：

$$
\Phi_A:
A\rightarrow A.
$$

與 primitive reflexivity：

$$
R(A,A)
$$

分離。

---

# 17. Relation State

定義：

$$
R_s
\in
\mathcal R_S.
$$

關係狀態必須保留：

- endpoints；
- direction；
- relation type；
- context；
- observer；
- constraints；
- provenance。

---

# 18. Tension Operator

$$
\Theta:
\mathcal R_S
\rightarrow
\mathcal T_R.
$$

禁止把：

$$
\Theta
$$

直接定義成單一實數差。

因此：

$$
\boxed{
\text{Tension}
\not\Rightarrow
\text{Scalar}.
}
$$

---

# 19. Tension State Space

最一般：

$$
\mathcal T_R
=
\prod_{\alpha\in A}
T_\alpha.
$$

其中：

$$
T_\alpha
$$

可以是 real interval、partially ordered set、categorical state、vector、probability distribution、symbolic state 或 heterogeneous subspace。

---

# 20. Difference 與 Tension 分離

若：

$$
x\neq y,
$$

只表示差異。

只有在：

$$
R(x,y)
$$

及相關作用／約束成立時，才可輸入：

$$
\Theta_R(x,y).
$$

所以：

$$
\boxed{
\text{Difference}
\not\Rightarrow
\text{Tension}.
}
$$

---

# 21. Metric Projection

若需要數值化：

$$
\mu:
\mathcal T_R
\rightarrow
M.
$$

因此：

$$
\Theta
\neq
\mu.
$$

---

# 22. Boundary Extraction

一般邊界抽取：

$$
\mathfrak B:
\mathcal T_R
\rightarrow
\mathcal B_R.
$$

若已有拓撲：

$$
\mathfrak B
(
\mathcal T_R
)
=
\partial
\mathcal T_R.
$$

---

# 23. Extremum Extraction

$$
\operatorname{Ext}_{\ell}
:
\mathcal T_R
\rightarrow
\mathcal E_R,
$$

其中：

$$
\ell
$$

為評價方向或排序函數。

禁止默認：

$$
\operatorname{Ext}
(
\mathcal T_R
)
=
\partial
\mathcal T_R.
$$

---

# 24. Truth Bearer

$$
p:
\mathsf{TruthBearer}.
$$

不允許直接把：

$$
\mathsf{SentenceToken}
$$

當成：

$$
\mathsf{TruthBearer}
$$

除非存在合法 coercion。

---

# 25. Evaluation Relation

$$
R_{\mathrm{eval}}
:
\mathsf{TruthBearer}
\times
\mathsf{ReferenceDomain}
\times
\mathsf{Observer}
\times
\mathsf{Context}
\rightarrow
\mathsf{RelationState}.
$$

---

# 26. Evaluation Tension

$$
\tau_p
=
\Theta
\left(
R_{\mathrm{eval}}
(
p,\mathcal D,o,c
)
\right).
$$

其中：

$$
\tau_p
\in
\mathcal T_{\mathrm{eval}}.
$$

---

# 27. Truth Extremes

給定：

$$
\ell:
\mathcal T_{\mathrm{eval}}
\rightarrow
\mathbb R,
$$

定義：

$$
\mathcal E_T
=
\operatorname*{arg\,max}_{\tau}
\ell(\tau),
$$

$$
\mathcal E_F
=
\operatorname*{arg\,min}_{\tau}
\ell(\tau).
$$

---

# 28. Truth Projection

$$
\pi_V:
\mathcal E_T
\cup
\mathcal E_F
\rightarrow
\mathcal V.
$$

二值介面：

$$
\mathcal V
=
\{T,F\}.
$$

---

# 29. Boundary Truth Hypothesis Interface

BTH 只允許在以下條件成立時啟用：

1. 評價關係合法；
2. 張力空間已定義；
3. 評價方向已定義；
4. 真／假極端集合可辨識；
5. $\pi_V$ 可定義。

否則：

$$
\mathsf{BTH}(p)\uparrow.
$$

---

# 30. Truth-Value Non-Atomicity

$$
\boxed{
\text{Formal Primitive}
\not\Rightarrow
\text{Ontological Primitive}.
}
$$

因此：

$$
T,
F
$$

可以是上層 primitive-like interface，

但底層可由：

$$
R_{\mathrm{eval}}
\rightarrow
\Theta
\rightarrow
\operatorname{Ext}
\rightarrow
\pi_V
$$

生成。

---

# 31. Evidence State 分離

證據狀態：

$$
e_p:
\mathsf{EvidenceState}.
$$

禁止：

$$
\mathsf{EvidenceState}
\equiv
\mathsf{TruthValueLabel}.
$$

---

# 32. Negation 分離

$$
\neg
:
\mathsf{Proposition}
\rightarrow
\mathsf{Proposition}.
$$

禁止與 reverse、evidence opposition、false label 直接同一化。

---

# 33. False Predicate

$$
\mathsf{FalsePred}
:
\mathsf{TruthBearer}
\rightarrow
\mathsf{Proposition}.
$$

在經典二值語義中，可要求：

$$
\mathcal B
\left(
\mathsf{FalsePred}(p)
\right)
=
\mathcal N
\left(
\mathcal B(p)
\right).
$$

---

# 34. Bivalent Evaluator

$$
\mathcal B
:
\mathsf{TruthBearer}
\rightarrow
\{T,F\}.
$$

總函數要求：

$$
\forall p,
\quad
\mathcal B(p)
\in
\{T,F\}.
$$

---

# 35. Bivalent Negation

$$
\mathcal N:
\{T,F\}
\rightarrow
\{T,F\},
$$

且：

$$
\mathcal N(T)=F,
$$

$$
\mathcal N(F)=T.
$$

因此：

$$
\operatorname{Fix}
(
\mathcal N
)
=
\varnothing.
$$

---

# 36. Liar Self-Reference Contract

標準說謊者需要：

$$
p_L
=
\mathsf{FalsePred}(p_L).
$$

若不存在合法：

$$
p_L:\mathsf{TruthBearer},
$$

則：

$$
\mathsf{LiarContract}(p_L)\uparrow.
$$

---

# 37. Liar Fixed-Point Obstruction

若：

$$
p_L
=
\mathsf{FalsePred}(p_L),
$$

且：

$$
\mathcal B
(
\mathsf{FalsePred}(p)
)
=
\mathcal N
(
\mathcal B(p)
),
$$

則：

$$
\mathcal B(p_L)
=
\mathcal N
(
\mathcal B(p_L)
).
$$

因：

$$
\operatorname{Fix}
(
\mathcal N
)
=
\varnothing,
$$

故：

$$
\boxed{
\mathsf{BivalentStableValue}(p_L)
=
\varnothing.
}
$$

---

# 38. Failure Taxonomy

## F-TYPE-01：TypeMismatch

$$
O(x)\uparrow
$$

因輸入型別不合法。

## F-TYPE-02：TypeCollapse

不同型別被強制同一。

## F-REF-01：ReferenceUnresolved

$$
\operatorname{Ref}(d,c)\uparrow.
$$

## F-REF-02：ReferenceTypeCollapse

句子 token、命題、真值載體被錯誤同一。

## F-CONST-01：ConstructionUndefined

異質構造不存在合法算子。

## F-PROJ-01：LossyProjectionUndeclared

有損投影發生但未標記。

## F-EVAL-01：EvaluationUndefined

真值載體未形成或參照域缺失。

## F-EVAL-02：TruthTypeCollapse

$$
F_{\mathrm{lex}},
\mathsf{FalsePred},
F_{\mathrm{eval}}
$$

被錯誤同一。

## F-FIX-01：NoFixedPoint

要求：

$$
v=F(v)
$$

但：

$$
\operatorname{Fix}(F)=\varnothing.
$$

## F-BOUND-01：BoundaryUndefined

張力空間未形成，卻直接宣稱邊界。

## F-METRIC-01：IllegalMetricization

異質空間被強行相減或實數化。

---

# 39. Projection Declaration

任何：

$$
\Pi:X\rightarrow Y
$$

若非單射，runtime 必須標記：

$$
\mathsf{lossy}=true.
$$

並記錄：

$$
\operatorname{LostDimensions}(\Pi).
$$

---

# 40. Semantic Graph Node Schema

最低 node：

$$
n
=
(
id,
surface,
type,
context,
provenance,
state
).
$$

---

# 41. Semantic Graph Edge Schema

最低 edge：

$$
e
=
(
source,
target,
relationType,
direction,
constraint,
projection,
provenance
).
$$

必須能區分：

$$
\mathsf{Reference},
\mathsf{Construction},
\mathsf{Evaluation},
\mathsf{Negation},
\mathsf{Return},
\mathsf{Projection},
\mathsf{BoundaryMap}.
$$

---

# 42. Action Graph

$$
\mathfrak A
=
(V,E,\tau,\sigma,\kappa).
$$

其中：

$$
\tau
$$

保存型別，

$$
\sigma
$$

保存方向語義，

$$
\kappa
$$

保存約束與有效域。

---

# 43. Required Provenance

任何解析器輸出的 semantic object 必須至少記錄：

$$
\operatorname{SourceSpan}.
$$

任何 inference-generated node 必須標記：

$$
\mathsf{inferred}=true.
$$

---

# 44. Ambiguity Preservation

若：

$$
x
$$

有多個合法解析：

$$
a_1,
a_2,
\ldots,
a_n,
$$

且尚無足夠證據選擇，

不得強制單一路徑。

應保留：

$$
\operatorname{ParseSet}(x)
=
\{a_1,\ldots,a_n\}.
$$

---

# 45. Observer / Context Relativity

若語義或評價依賴：

$$
o,
c,
$$

必須顯式保留 observer 與 context。

禁止把：

$$
V(p\mid o,c)
$$

投影成全域：

$$
V(p)
$$

而不標記條件消失。

---

# 46. Static vs Dynamic

靜態作用只表示：

$$
\text{possible operation structure}.
$$

動態執行則表示某一步實際發生。

禁止由：

$$
A\rightarrow B
$$

直接推論物理時間順序。

---

# 47. State vs Trajectory

狀態：

$$
x\in\mathcal S.
$$

軌跡：

$$
\gamma:I\rightarrow\mathcal S.
$$

禁止：

$$
\mathsf{State}
\equiv
\mathsf{Trajectory}.
$$

---

# 48. Well-Typed Liar Parse

對輸入：

> 這句話是假的。

reference analyzer 至少應嘗試生成：

$$
s_L:\mathsf{SentenceToken},
$$

$$
d_L:\mathsf{Deictic},
$$

$$
p_L:\mathsf{Proposition},
$$

$$
q_L:\mathsf{TruthBearer},
$$

$$
\mathsf{FalsePred}:
\mathsf{TruthBearer}
\rightarrow
\mathsf{Proposition}.
$$

並建立候選閉環：

$$
q_L
\rightarrow
\mathsf{FalsePred}(q_L)
\rightarrow
p_L.
$$

---

# 49. Liar Analyzer Output

最低輸出：

```text
parse_status
type_graph
reference_graph
construction_trace
evaluation_contract
self_reference_detected
projection_steps
fixed_point_equation
fixed_point_status
failure_classes
```

經典二值 fixed-point equation：

$$
v
=
\mathcal N(v).
$$

fixed-point status：

$$
\mathsf{NO\_FIXED\_POINT}.
$$

---

# 50. Do-Not-Overclaim Rule

Analyzer 不得只因：

$$
\mathsf{NO\_FIXED\_POINT}
$$

就輸出：

> 世界矛盾。

也不得輸出：

> RSCT 已解決說謊者悖論。

應輸出：

$$
\boxed{
\text{No stable value exists under the active semantic contract.}
}
$$

---

# 51. Active Assumption Set

對經典說謊者：

$$
\mathcal A_L
=
\{
\mathsf{SelfReference},
\mathsf{TruthBearerValid},
\mathsf{FalsePredicateClassical},
\mathsf{TotalBivalence},
\mathsf{ImmediateReentry}
\}.
$$

任何結果必須與：

$$
\mathcal A_L
$$

共同輸出。

---

# 52. Assumption Mutation Test

Runtime 應允許逐項修改：

$$
\mathcal A_L.
$$

例如：

$$
\mathsf{TotalBivalence}
\rightarrow
\mathsf{PartialEvaluation}.
$$

或：

$$
\mathsf{ImmediateReentry}
\rightarrow
\mathsf{LayeredEvaluation}.
$$

然後重算固定點條件。

---

# 53. Minimal Validation Cases

## VC-01：普通事實命題

輸入：

> 雪是白的。

要求：

- 無自指；
- 無 truth-type collapse；
- 可建立 truth bearer；
- evaluation relation 合法。

## VC-02：普通自指語法

輸入：

> 這句話是中文。

要求：

- self-reference 可存在；
- 無 polarity reversal；
- 不應標為 liar obstruction。

## VC-03：經典說謊者

輸入：

> 這句話是假的。

要求：

- self-reference detected；
- FalsePred detected；
- bivalent fixed-point equation generated；
- NO_FIXED_POINT。

## VC-04：非自指假述詞

輸入：

> 「雪是黑的」是假的。

要求：

- FalsePred；
- reference target 外部；
- 無 self-evaluative closure。

## VC-05：角色本體化

輸入：

> 他說過謊，所以他就是永遠的說謊者。

要求：

- ActRel；
- Agentize；
- Role；
- Reify candidate；
- role-to-identity escalation warning。

---

# 54. Runtime Invariants

$$
\boxed{
\text{Surface Form}
\neq
\text{Semantic Type}.
}
$$

$$
\boxed{
\text{Construction}
\neq
\text{Projection}.
}
$$

$$
\boxed{
\text{Projection}
\neq
\text{Evaluation}.
}
$$

$$
\boxed{
\text{Orientation}
\neq
\text{Negation}.
}
$$

$$
\boxed{
\text{Evidence}
\neq
\text{Truth}.
}
$$

$$
\boxed{
\text{Role}
\neq
\text{Identity}.
}
$$

$$
\boxed{
\text{Difference}
\neq
\text{Tension}.
}
$$

$$
\boxed{
\text{Tension}
\neq
\text{Metric}.
}
$$

$$
\boxed{
\text{Boundary}
\neq
\text{Truth Label}.
}
$$

$$
\boxed{
\text{Type Safety}
\not\Rightarrow
\text{Fixed-Point Existence}.
}
$$

---

# 55. Canonical Processing Pipeline

$$
\boxed{
\begin{aligned}
&\text{Input}
\\
&\rightarrow
\text{Surface Parse}
\\
&\rightarrow
\text{Semantic Type Inference}
\\
&\rightarrow
\text{Heterogeneous Construction}
\\
&\rightarrow
\text{Reference Resolution}
\\
&\rightarrow
\text{Actuation Graph}
\\
&\rightarrow
\text{Bidirectional / Reflexive Analysis}
\\
&\rightarrow
\text{Relation-State Construction}
\\
&\rightarrow
\text{Tension-State Extraction}
\\
&\rightarrow
\text{Boundary / Extremum Analysis}
\\
&\rightarrow
\text{Evaluation Projection}
\\
&\rightarrow
\text{Fixed-Point Analysis}
\\
&\rightarrow
\text{Report}.
\end{aligned}
}
$$

---

# 56. Minimal Runtime Components

```text
TokenizerAdapter
SurfaceParser
SemanticTypeInferencer
ConstructionEngine
ReferenceResolver
ActuationGraphBuilder
ReflexivityDetector
TensionSpaceAdapter
BoundaryAnalyzer
TruthProjectionAdapter
FixedPointAnalyzer
AssumptionRegistry
ValidationReporter
```

---

# 57. Out of Scope for v0.1

本規格暫不要求：

- 完整自然語言理解；
- 全語言支援；
- 自動證明所有悖論；
- 自動建立真實世界知識庫；
- 完整無限潛能場運算；
- 完整四態 Runtime；
- 物理張力模擬；
- 動態時間 LOOP；
- 語用情緒判讀；
- 主體意圖確定化。

---

# 58. Versioning Rule

升級：

$$
v0.2
$$

前必須：

1. 為所有 v0.1 invariants 提供 migration 說明；
2. 不靜默改變 canonical type names；
3. 不把新增假說寫成已驗證 invariant；
4. liar fixed-point test 必須可回歸。

---

# 59. Canonical Naming Rule

現行理論名稱：

$$
\boxed{
\text{Unified Theory of Infinite Potential Fields}
}
$$

中文：

$$
\boxed{
\text{無限潛能場統一理論}
}
$$

舊稱 MTF 只允許在歷史引用、舊文件標題與 migration note 中保留。

---

# 60. Formal Closure

RSCT v0.1 形式核心：

$$
\boxed{
\mathcal R_{\mathrm{RSCT}}
=
\left\langle
\mathbb T,
\mathcal C,
\mathfrak A,
\mathsf{GRef},
\Theta,
\mathfrak B,
\pi_V,
\mathcal F
\right\rangle
}
$$

其中：

- $\mathbb T$：語義型別宇宙；
- $\mathcal C$：異質構造算子族；
- $\mathfrak A$：作用圖；
- $\mathsf{GRef}$：生成式反身性；
- $\Theta$：張力態抽取；
- $\mathfrak B$：邊界抽取；
- $\pi_V$：評價投影；
- $\mathcal F$：固定點／失敗分析。

完整處理順序：

$$
\boxed{
\text{Type}
\rightarrow
\text{Construct}
\rightarrow
\text{Act}
\rightarrow
\text{Relate}
\rightarrow
\text{Reflect}
\rightarrow
\text{Tension}
\rightarrow
\text{Boundary}
\rightarrow
\text{Project}
\rightarrow
\text{Evaluate}
\rightarrow
\text{Fixed-Point Check}.
}
$$

本規格至此完成 RSCT 00–06 從概念論文到可實作形式契約的第一次收斂。
