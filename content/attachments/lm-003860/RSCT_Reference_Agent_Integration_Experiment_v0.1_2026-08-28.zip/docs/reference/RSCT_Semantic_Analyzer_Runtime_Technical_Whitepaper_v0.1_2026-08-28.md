# RSCT Semantic Analyzer Runtime 技術白皮書 v0.1
## 從關係語義構成論形式規格到可執行語義分析 Runtime

**英文題名**：*RSCT Semantic Analyzer Runtime Technical Whitepaper v0.1: From Formal Semantic Contracts to an Executable Relational-Semantic Analysis Runtime*  
**所屬理論**：關係語義構成論（Relational Semantic Construction Theory, RSCT）  
**Canonical 依賴**：RSCT Formal Specification v0.1、RSCT 00–06  
**作者**：Neo.K × GPT-5.6 Sol  
**機構**：EveMissLab（一言諾科技有限公司）  
**日期**：2026-08-28  
**版本**：v0.1  
**文件類型**：Technical Whitepaper／MVP Architecture Specification  
**狀態**：第一版工程收斂稿  

---

## 摘要

RSCT 00–06 已建立關係語義構成論的理論主體，而《RSCT Formal Specification v0.1》進一步將其收斂為 canonical types、operators、invariants、failure classes 與 fixed-point contracts。本白皮書的任務不是再次解釋理論，而是回答一個工程問題：

> 如何把 RSCT 變成一個可以對自然語言句子建立型別圖、構造圖、指稱圖、作用圖、反身閉環、張力接口、真值投影與固定點分析的可執行 Semantic Analyzer Runtime？

本文提出 RSCT Semantic Analyzer Runtime（RSCT-SAR）。其最低處理鏈為：

$$
\boxed{
\begin{aligned}
&\text{Input Text}
\\
&\rightarrow
\text{Surface Parse}
\\
&\rightarrow
\text{Semantic Type Inference}
\\
&\rightarrow
\text{Heterogeneous Construction}
\\
&\rightarrow
\text{Reference Resolution}
\\
&\rightarrow
\text{Actuation Graph}
\\
&\rightarrow
\text{Reflexivity Analysis}
\\
&\rightarrow
\text{Relation-State IR}
\\
&\rightarrow
\text{Tension / Boundary Adapters}
\\
&\rightarrow
\text{Truth Projection}
\\
&\rightarrow
\text{Fixed-Point Analysis}
\\
&\rightarrow
\text{Evidence Report}.
\end{aligned}
}
$$

Runtime 核心不要求一次解決完整自然語言理解。MVP 只處理一組受控語句與顯式規則，優先驗證 RSCT 最重要的工程價值：**是否能把傳統一句話壓縮掉的型別、構造、作用、回返與評價條件重新展開，並明確指出哪一層發生 fixed-point obstruction、type collapse 或 undeclared lossy projection。**

本文定義三個核心 IR：

$$
\mathsf{SurfaceIR},
$$

$$
\mathsf{SemanticGraphIR},
$$

$$
\mathsf{EvaluationIR}.
$$

其中 SemanticGraphIR 是 Runtime 的 canonical internal representation。它保存：

$$
\text{node type},
\text{edge type},
\text{direction},
\text{construction trace},
\text{reference target},
\text{context},
\text{observer},
\text{projection metadata},
\text{provenance}.
$$

MVP 第一個 benchmark 是經典說謊者：

> 這句話是假的。

Runtime 必須輸出：

$$
\mathsf{self\_reference}=true,
$$

$$
\mathsf{false\_predicate}=true,
$$

$$
v
=
\mathcal N(v),
$$

以及：

$$
\mathsf{fixed\_point\_status}
=
\mathsf{NO\_FIXED\_POINT}.
$$

但同時不得輸出「世界矛盾」或「RSCT 已解決悖論」等過度結論。正確結論必須被限制為：

$$
\boxed{
\text{No stable value exists under the active semantic contract.}
}
$$

本文最後提出 v0.1 MVP 的模組邊界、資料模型、API 契約、validation matrix、failure taxonomy、test harness 與未來 v0.2 路線，使 RSCT 可以從論文系列進入可重現工程驗證。

**關鍵詞**：RSCT、Semantic Analyzer、Runtime、Semantic IR、Type Graph、Reference Resolution、Fixed Point、Liar Paradox、Typed Semantics、MVP

---

# 0. 系統定位

RSCT-SAR 不是：

- 通用聊天模型；
- 完整自然語言理解器；
- 通用 theorem prover；
- 全自動哲學判斷器；
- 真假分類器；
- LLM wrapper。

它是：

$$
\boxed{
\text{Typed Relational-Semantic Analysis Runtime}.
}
$$

其任務是：

> 將語句轉成可檢查、可追蹤、可重放的關係語義圖，並對自指、投影、真值、邊界與固定點結構進行顯式分析。

---

# 1. Canonical Contract

Runtime 必須遵守 RSCT Formal Specification v0.1。

最低 invariants：

$$
\text{Surface Form}
\neq
\text{Semantic Type},
$$

$$
\text{Construction}
\neq
\text{Projection},
$$

$$
\text{Projection}
\neq
\text{Evaluation},
$$

$$
\text{Orientation}
\neq
\text{Negation},
$$

$$
\text{Evidence}
\neq
\text{Truth},
$$

$$
\text{Role}
\neq
\text{Identity},
$$

$$
\text{Difference}
\neq
\text{Tension},
$$

$$
\text{Tension}
\neq
\text{Metric},
$$

$$
\text{Boundary}
\neq
\text{Truth Label},
$$

$$
\text{Type Safety}
\not\Rightarrow
\text{Fixed-Point Existence}.
$$

---

# 2. Runtime Design Goals

RSCT-SAR v0.1 需要滿足五個工程目標。

## G1：可追蹤

每個語義節點必須能追溯到：

$$
\operatorname{SourceSpan}.
$$

## G2：型別安全

任何 operator call 必須有：

$$
\operatorname{dom}(O)
$$

與：

$$
\operatorname{cod}(O).
$$

## G3：保留歧義

若有多個合法 parse：

$$
\operatorname{ParseSet}(x)
=
\{a_1,\ldots,a_n\}.
$$

不得強制壓成單一路徑。

## G4：投影可見

任何有損：

$$
\Pi:X\rightarrow Y
$$

必須標記：

$$
\mathsf{lossy}=true.
$$

## G5：假設可變

所有 fixed-point 分析都必須保存：

$$
\mathcal A.
$$

也就是 active assumptions。

---

# 3. Runtime Non-Goals

v0.1 不要求：

- 任意中文句子都解析成功；
- 自動解全部悖論；
- 自動決定所有真值；
- 自動建立真實世界知識；
- 自動推理倫理正確性；
- 完整高維張力數學；
- 無限潛能場直接運算；
- 長期動態記憶。

---

# 4. Overall Architecture

RSCT-SAR v0.1 建議分成七層。

$$
\boxed{
\begin{aligned}
L_0 &: \text{Input Layer}
\\
L_1 &: \text{Surface Analysis Layer}
\\
L_2 &: \text{Typed Semantic Construction Layer}
\\
L_3 &: \text{Reference / Actuation Graph Layer}
\\
L_4 &: \text{Reflexive Structure Layer}
\\
L_5 &: \text{Evaluation / Boundary Layer}
\\
L_6 &: \text{Validation / Reporting Layer}
\end{aligned}
}
$$

---

# 5. L0 — Input Layer

輸入：

```text
text
language
context_id
observer_id
analysis_profile
```

最低 schema：

```json
{
  "text": "這句話是假的。",
  "language": "zh-TW",
  "context_id": "ctx-001",
  "observer_id": "default",
  "analysis_profile": "liar-classical-bivalent"
}
```

---

# 6. L1 — Surface Analysis Layer

最低模組：

```text
TokenizerAdapter
SurfaceParser
SpanIndexer
LexicalAnnotator
```

輸出：

$$
\mathsf{SurfaceIR}.
$$

---

# 7. SurfaceIR

最低結構：

```text
SurfaceIR
  document_id
  language
  tokens[]
  spans[]
  syntax_hints[]
  lexical_candidates[]
```

每個 token：

```text
token_id
surface
start
end
pos_hint
lemma_hint
confidence
```

注意：

$$
\boxed{
\text{pos\_hint}
\neq
\text{semantic\_type}.
}
$$

---

# 8. L2 — Typed Semantic Construction Layer

模組：

```text
SemanticTypeInferencer
ConstructionRuleRegistry
ConstructionEngine
CoercionRegistry
ConstructionTraceStore
```

任務：

$$
\mathsf{SurfaceIR}
\rightarrow
\mathsf{TypedSemanticCandidates}.
$$

---

# 9. Type Registry

Registry 最低存：

```text
type_id
parent_type
allowed_inputs
allowed_outputs
constraints
version
```

例如：

```text
ActRel
Role
Identity
TruthBearer
FalsePredicate
TruthValueLabel
ReferenceTarget
Projection
```

---

# 10. Constructor Registry

每個 constructor：

```text
constructor_id
input_types[]
output_type
preconditions[]
side_effects[]
lossy
```

例如：

$$
\mathsf{Agentize}
:
\mathsf{ActRel}
\rightarrow
\mathsf{Role}.
$$

---

# 11. Construction Trace Store

每次構造保存：

```text
trace_id
operator
inputs[]
output
input_types[]
output_type
source_spans[]
context
provenance
```

對：

$$
y
=
\mathcal C(x_1,\ldots,x_n),
$$

必須能重建：

$$
\operatorname{Trace}(y).
$$

---

# 12. L3 — Reference / Actuation Graph Layer

模組：

```text
ReferenceResolver
ActuationGraphBuilder
RelationStateBuilder
ProjectionTracker
```

核心輸出：

$$
\mathsf{SemanticGraphIR}.
$$

---

# 13. SemanticGraphIR

Node：

```text
node_id
semantic_type
surface_ref
context
observer
state
provenance
inferred
```

Edge：

```text
edge_id
source
target
edge_type
direction
constraints
operator
projection
provenance
```

---

# 14. Canonical Edge Types

最低支援：

```text
REFERENCE
CONSTRUCTION
BIND
EVALUATION
NEGATION
RETURN
PROJECTION
BOUNDARY_MAP
TYPE_COERCION
ROLE_REIFICATION
```

---

# 15. Reference Resolver

輸入：

$$
d:\mathsf{Deictic}
$$

與：

$$
c:\mathsf{Context}.
$$

輸出：

$$
\operatorname{Ref}(d,c)
=
r.
$$

若不唯一：

$$
\operatorname{RefSet}(d,c)
=
\{r_1,\ldots,r_n\}.
$$

不得靜默選擇。

---

# 16. Reference Resolution Status

```text
RESOLVED
AMBIGUOUS
UNRESOLVED
TYPE_MISMATCH
```

---

# 17. Actuation Graph

定義：

$$
\mathfrak A
=
(V,E,\tau,\sigma,\kappa).
$$

Runtime 必須可詢問：

```text
outgoing(node)
incoming(node)
cycles(node)
return_paths(node)
typed_edges(node)
```

---

# 18. L4 — Reflexive Structure Layer

模組：

```text
CycleDetector
ReturnPathAnalyzer
GenerativeReflexivityDetector
SelfReferenceClassifier
```

---

# 19. Generative Reflexivity Detection

若存在：

$$
A
\rightarrow
X_1
\rightarrow
\cdots
\rightarrow
A,
$$

則記錄：

```text
reflexive=true
reflexivity_kind=GENERATIVE
cycle_length=n
path=[...]
```

---

# 20. Self-Reference Classes

最低分類：

```text
DIRECT_SELF_REFERENCE
PATH_GENERATED_SELF_REFERENCE
META_REFERENCE
REFERENCE_TO_TOKEN
REFERENCE_TO_PROPOSITION
REFERENCE_TO_TRUTH_BEARER
```

---

# 21. L5 — Evaluation / Boundary Layer

模組：

```text
EvaluationContractRegistry
TensionSpaceAdapter
BoundaryAnalyzer
TruthProjectionAdapter
FixedPointAnalyzer
AssumptionRegistry
```

---

# 22. EvaluationIR

最低結構：

```text
truth_bearer
reference_domain
observer
context
evaluation_relation
tension_state
boundary_state
truth_projection
active_assumptions
fixed_point_equation
fixed_point_status
```

---

# 23. Evaluation Contract

例如 classic bivalent：

```text
truth_domain = {T,F}
negation(T)=F
negation(F)=T
false_predicate(p) = negation(value(p))
total = true
```

形式：

$$
\mathcal B
:
\mathsf{TruthBearer}
\rightarrow
\{T,F\}.
$$

---

# 24. TensionSpaceAdapter

v0.1 可以只有 adapter contract，不需要完整高維數值模型。

接口：

```text
build_relation_state()
derive_tension_state()
describe_dimensions()
supports_metric()
supports_boundary()
```

---

# 25. Minimal Symbolic Tension Mode

v0.1 可使用 symbolic tension：

```text
ALIGNED
OPPOSED
PARTIAL
UNDEFINED
INCOMPARABLE
```

這些不是 RSCT 的最終張力本體，只是 Runtime MVP 的 symbolic adapter。

---

# 26. BoundaryAnalyzer

接口：

```text
find_extrema()
find_boundaries()
classify_position()
explain_projection()
```

若空間未定義：

```text
BOUNDARY_UNDEFINED
```

不得自行建立：

$$
[-1,1]
$$

作為默認。

---

# 27. TruthProjectionAdapter

接口：

```text
project(tension_state, evaluation_contract)
```

輸出：

```text
T
F
UNDEFINED
MULTIPLE
NOT_APPLICABLE
```

---

# 28. FixedPointAnalyzer

輸入：

$$
F:\mathcal V\rightarrow\mathcal V.
$$

分析：

$$
\operatorname{Fix}(F).
$$

最低 API：

```text
find_fixed_points()
detect_no_fixed_point()
detect_cycle()
explain_obstruction()
```

---

# 29. Bivalent Liar Fixed Point

經典說謊者：

$$
v
=
\mathcal N(v).
$$

而：

$$
\operatorname{Fix}
(
\mathcal N
)
=
\varnothing.
$$

Runtime 輸出：

```text
fixed_point_status = NO_FIXED_POINT
cycle_status = PERIOD_2_AVAILABLE
```

注意：

$$
\text{NO\_FIXED\_POINT}
\neq
\text{PERIOD\_2}.
$$

兩者要分開。

---

# 30. Assumption Registry

經典說謊者：

```text
SELF_REFERENCE = true
TRUTH_BEARER_VALID = true
FALSE_PREDICATE_CLASSICAL = true
TOTAL_BIVALENCE = true
IMMEDIATE_REENTRY = true
```

每個分析結果必須輸出 assumption snapshot。

---

# 31. Assumption Mutation

Runtime 必須允許：

```text
set TOTAL_BIVALENCE = false
set IMMEDIATE_REENTRY = false
```

再重新分析。

這使不同悖論處理方式可被比較，而不是被混成「解法」。

---

# 32. L6 — Validation / Reporting Layer

模組：

```text
FailureClassifier
InvariantChecker
EvidenceReporter
ExplainabilityRenderer
SerializationAdapter
```

---

# 33. Failure Taxonomy

沿用 Formal Specification：

```text
F-TYPE-01 TypeMismatch
F-TYPE-02 TypeCollapse
F-REF-01 ReferenceUnresolved
F-REF-02 ReferenceTypeCollapse
F-CONST-01 ConstructionUndefined
F-PROJ-01 LossyProjectionUndeclared
F-EVAL-01 EvaluationUndefined
F-EVAL-02 TruthTypeCollapse
F-FIX-01 NoFixedPoint
F-BOUND-01 BoundaryUndefined
F-METRIC-01 IllegalMetricization
```

---

# 34. Failure Severity

建議：

```text
INFO
WARNING
ERROR
BLOCKER
```

例如：

```text
NoFixedPoint = ERROR
ReferenceUnresolved = BLOCKER
LossyProjectionUndeclared = WARNING
```

具體 severity 可由 profile 決定。

---

# 35. Report Schema

最低：

```json
{
  "input": "...",
  "parse_status": "...",
  "semantic_graph": {},
  "construction_traces": [],
  "reference_status": "...",
  "self_reference": {},
  "evaluation": {},
  "fixed_point": {},
  "failures": [],
  "assumptions": {},
  "warnings": [],
  "summary": "..."
}
```

---

# 36. Explainability Rule

所有自動結論必須對應：

```text
source span
operator
type rule
invariant
assumption
```

不得只有：

> AI 覺得這是 self-reference。

---

# 37. MVP Scenario 1 — 普通事實句

輸入：

> 雪是白的。

期待：

```text
self_reference = false
truth_bearer = valid
fixed_point_analysis = not_required
```

---

# 38. MVP Scenario 2 — 無害自指

輸入：

> 這句話是中文。

期待：

```text
self_reference = true
false_predicate = false
fixed_point_obstruction = false
```

這驗證：

$$
\boxed{
\text{Self-reference}
\not\Rightarrow
\text{Paradox}.
}
$$

---

# 39. MVP Scenario 3 — 經典說謊者

輸入：

> 這句話是假的。

期待：

```text
self_reference = true
false_predicate = true
total_bivalence = true
fixed_point_equation = v = N(v)
fixed_point_status = NO_FIXED_POINT
```

---

# 40. MVP Scenario 4 — 外部真假述詞

輸入：

> 「雪是黑的」是假的。

期待：

```text
false_predicate = true
self_reference = false
fixed_point_obstruction = false
```

---

# 41. MVP Scenario 5 — 角色本體化

輸入：

> 他說過謊，所以他永遠就是說謊者。

期待：

```text
ActRel detected
Agentize detected
Role detected
Reify candidate detected
identity escalation warning
```

---

# 42. MVP Scenario 6 — 雙向不對稱

輸入：

> A 照顧 B，但 B 管理 A。

期待：

```text
bidirectional = true
symmetric = false
heterogeneous_edges = true
```

---

# 43. MVP Scenario 7 — Evidence vs Truth

輸入：

> 有研究支持 P，也有研究反對 P。

期待：

```text
evidence_positive = true
evidence_negative = true
truth_value = NOT_AUTOMATICALLY_ASSIGNED
```

---

# 44. Test Matrix

最低測試分類：

```text
TYPING
CONSTRUCTION
REFERENCE
ACTUATION
REFLEXIVITY
PROJECTION
EVALUATION
FIXED_POINT
BOUNDARY
REPORTING
```

---

# 45. Unit Tests

例如：

```text
test_agentize_actrel_to_role
test_role_not_identity
test_reverse_not_negation
test_reference_ambiguity_preserved
test_liar_no_bivalent_fixed_point
test_non_liar_self_reference
test_projection_loss_declared
```

---

# 46. Golden Tests

Golden test 必須保存完整 JSON output。

至少：

```text
golden/liar_classical.json
golden/self_reference_language.json
golden/external_false_predicate.json
golden/role_reification.json
```

---

# 47. Regression Invariant Tests

任何版本升級都必須重跑：

$$
\mathsf{INV01}
\ldots
\mathsf{INV10}.
$$

若 invariant 改變，必須明確 migration。

---

# 48. MVP CLI

建議：

```bash
rsct analyze "這句話是假的。"
```

可選：

```bash
rsct analyze --profile classical-bivalent "這句話是假的。"
```

輸出：

```text
Self-reference: YES
False predicate: YES
Active truth domain: {T,F}
Fixed-point equation: v = N(v)
Fixed-point status: NO_FIXED_POINT
Conclusion: No stable value exists under the active semantic contract.
```

---

# 49. JSON Mode

```bash
rsct analyze --json "這句話是假的。"
```

用於：

- tests；
- UI；
- API；
- agent integration。

---

# 50. Graph Mode

```bash
rsct graph "這句話是假的。"
```

輸出 semantic graph。

最低 graph：

$$
\mathsf{SentenceToken}
\rightarrow
\mathsf{Proposition}
\rightarrow
\mathsf{TruthBearer}
\rightarrow
\mathsf{FalsePred}
\rightarrow
\mathsf{Evaluation}
\rightarrow
\mathsf{TruthProjection}
\rightarrow
\mathsf{Reentry}.
$$

---

# 51. Assumption Mode

```bash
rsct assumptions "這句話是假的。"
```

輸出：

```text
SELF_REFERENCE=true
TOTAL_BIVALENCE=true
FALSE_PREDICATE_CLASSICAL=true
IMMEDIATE_REENTRY=true
```

---

# 52. Mutation Mode

```bash
rsct analyze \
  --set TOTAL_BIVALENCE=false \
  "這句話是假的。"
```

Runtime 必須重新計算，而不是只改顯示文字。

---

# 53. API Surface

最低 Python-like API：

```python
analyzer = RSCTAnalyzer(profile="classical-bivalent")
result = analyzer.analyze(text)
result.semantic_graph
result.failures
result.fixed_point
result.assumptions
```

---

# 54. Runtime Data Persistence

MVP 可先用：

```text
JSON
SQLite
```

保存：

- analysis run；
- semantic graph；
- traces；
- assumptions；
- failures；
- golden outputs。

暫不需要複雜 distributed DB。

---

# 55. Determinism

同一：

```text
input
profile
ruleset_version
```

應盡量產生同一 canonical IR。

LLM 若參與 semantic candidate generation，必須把：

```text
candidate generation
```

與：

```text
canonical validation
```

分離。

---

# 56. LLM Integration Boundary

LLM 可以負責：

- candidate type generation；
- parse alternatives；
- semantic paraphrase；
- reference hypotheses。

但不得直接決定：

```text
fixed_point_status
invariant pass/fail
type safety
```

這些由 deterministic core 決定。

因此：

$$
\boxed{
\text{LLM proposes; RSCT Core validates}.
}
$$

---

# 57. Parser Strategy

MVP 建議採：

$$
\boxed{
\text{Hybrid Parser}
=
\text{Rule-Based Core}
+
\text{Optional LLM Candidate Generator}.
}
$$

先支援受控語法：

```text
X 是 Y
這句話是假的
這句話是中文
「X」是假的
A 做過 X，所以 A 是 Y
A 對 B 做 X，但 B 對 A 做 Y
```

---

# 58. Semantic Rule DSL

未來可建立：

```text
RULE liar.false_predicate
MATCH SelfRefSentence(subject=this_sentence, predicate=false)
EMIT FalsePred(target=self_truth_bearer)
REQUIRE TruthBearerValid
```

MVP 可先用 Python data structures，不必先發明 DSL。

---

# 59. IR Versioning

每個 IR 必須包含：

```text
ir_version
ruleset_version
rsct_spec_version
```

例如：

```text
ir_version = 0.1
rsct_spec_version = 0.1
```

---

# 60. Security Boundary

Semantic Analyzer v0.1 原則上只做分析，不執行任意外部程式。

因此：

$$
\boxed{
\text{Analyze}
\neq
\text{Execute}.
}
$$

所有輸入文本視為 data。

---

# 61. Error Isolation

任何一層失敗，不應讓 Runtime 假裝後續仍成立。

例如：

$$
\operatorname{Ref}\uparrow
$$

則：

$$
\mathsf{SelfReferenceAnalysis}
$$

應輸出：

```text
UNKNOWN
```

而不是：

```text
false
```

---

# 62. Unknown Is Not False

Runtime invariant：

$$
\boxed{
\mathsf{UNKNOWN}
\neq
F.
}
$$

這對語義分析極其重要。

---

# 63. Not Applicable Is Not Unknown

同樣：

$$
\boxed{
\mathsf{NOT\_APPLICABLE}
\neq
\mathsf{UNKNOWN}.
}
$$

例如普通句子不需要 fixed-point analysis：

```text
fixed_point_status = NOT_APPLICABLE
```

而不是 UNKNOWN。

---

# 64. Runtime Status Algebra

最低 status：

```text
PASS
FAIL
UNKNOWN
NOT_APPLICABLE
AMBIGUOUS
PARTIAL
```

---

# 65. Evidence-Ready Design

每個分析結果必須可重放：

```text
input
ruleset
IR
assumptions
trace
output
```

因此：

$$
\boxed{
\text{Result}
=
\text{Conclusion}
+
\text{Reproducible Evidence}.
}
$$

---

# 66. MVP Milestones

## M0 — Formal Core

- type registry；
- constructor registry；
- invariants；
- fixed-point core。

## M1 — Controlled Parser

- 受控中文句型；
- SurfaceIR；
- source spans。

## M2 — SemanticGraphIR

- nodes；
- edges；
- traces；
- reference graph。

## M3 — Liar Analyzer

- self-reference；
- FalsePred；
- assumptions；
- fixed-point obstruction。

## M4 — Validation Matrix

- seven scenarios；
- unit tests；
- golden tests。

## M5 — CLI / JSON

- analyze；
- graph；
- assumptions；
- mutation。

---

# 67. MVP Completion Criteria

v0.1 MVP 可被視為完成，若：

1. 七個 canonical scenarios 全部有穩定輸出；
2. liar classical 能產生：

$$
v=\mathcal N(v);
$$

3. FixedPointAnalyzer 正確得到：

$$
\operatorname{Fix}(\mathcal N)=\varnothing;
$$

4. 無害自指不被誤報為 liar；
5. role 不被默認 identity；
6. evidence 不被默認 truth；
7. ambiguous reference 不被靜默消除；
8. 所有結果可輸出 JSON evidence。

---

# 68. v0.2 Future Work

v0.2 可考慮：

- more natural language patterns；
- English adapter；
- layered truth models；
- partial evaluation；
- four-state evidence adapter；
- tension-space plugins；
- boundary visualization；
- graph UI；
- formal theorem backend；
- benchmark suite。

---

# 69. Long-Term Architecture

未來可演化為：

$$
\boxed{
\text{RSCT Core}
+
\text{Language Adapters}
+
\text{Evaluation Profiles}
+
\text{Tension Plugins}
+
\text{Formal Solvers}
+
\text{Visualization}.
}
$$

---

# 70. Final Architecture Closure

RSCT-SAR v0.1 的最低架構：

$$
\boxed{
\mathcal S_{\mathrm{RSCT}}
=
\left\langle
P,
T,
C,
R,
A,
G,
E,
F,
V
\right\rangle
}
$$

其中：

- $P$：surface parser；
- $T$：type inferencer；
- $C$：construction engine；
- $R$：reference resolver；
- $A$：actuation graph；
- $G$：generative reflexivity detector；
- $E$：evaluation / boundary adapters；
- $F$：fixed-point analyzer；
- $V$：validation reporter。

完整執行鏈：

$$
\boxed{
\text{Text}
\rightarrow
\text{Typed Semantic Graph}
\rightarrow
\text{Reflexive Structure}
\rightarrow
\text{Evaluation Contract}
\rightarrow
\text{Fixed-Point Result}
\rightarrow
\text{Evidence Report}.
}
$$

這使 RSCT 從論文與形式規格正式進入可實作工程階段。
