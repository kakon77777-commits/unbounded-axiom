# RSCT AI Reasoning Loop Extension Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Extend the validated RSCT AI Semantic Middleware so an Agent can submit an ordered reasoning trace, receive per-step semantic audits, detect cross-step semantic collapse, and obtain a deterministic non-mutating localized repair plan.

**Architecture:** Reuse the existing v0.1 AI semantic contract and `audit_ai_graph()` as the per-step validator. Add a `ReasoningTrace` contract containing ordered semantic contracts plus explicit carry-over references; audit each step independently, then run cross-step state-transition checks over Claim/Evidence/BeliefState/MemoryRecord/Inference/Observation/Role/Identity. Produce a repair plan as data only; never mutate submitted contracts.

**Tech Stack:** Python 3.11+, standard library, pytest.

**Spec:** `docs/reference/RSCT_AI_Semantic_Middleware_Contract_v0.1.md`, `docs/reference/RSCT_Formal_Specification_v0.1_2026-08-28.md`

## Global Constraints

- Evidence != Truth.
- Claim != Truth.
- BeliefState != Truth.
- MemoryRecord != CurrentBelief.
- Inference != Truth.
- Observation != Truth.
- Role != Identity.
- Audit findings never mutate the submitted semantic graph or trace.
- UNKNOWN != FALSE.
- Every cross-step finding must include source step, target step, semantic node IDs, failure code, and repair hint.
- Existing single-contract API and CLI behavior must remain backward compatible.

---

### Task 1: Reasoning trace contract and schema

**Files:**
- Create: `src/rsct/trace.py`
- Test: `tests/test_ai_trace.py`

**Interfaces:**
- Produces `load_reasoning_trace(text: str) -> ReasoningTrace`
- Produces `ReasoningTrace`, `ReasoningStep`, `CarryOverRef`
- Trace version: `0.1`

- [x] Write failing tests for valid trace parsing, duplicate step IDs, unknown carry-over node IDs, and provenance preservation.
- [x] Run focused tests and confirm RED.
- [x] Implement minimal dataclasses and strict JSON validation.
- [x] Re-run focused tests and confirm GREEN.

### Task 2: Chain audit and cross-step collapse detection

**Files:**
- Create: `src/rsct/trace_audit.py`
- Modify: `src/rsct/model.py`
- Test: `tests/test_ai_trace.py`

**Interfaces:**
- Produces `audit_reasoning_trace(trace: ReasoningTrace) -> ReasoningTraceAuditResult`
- Adds failure codes `F-AI-09` through `F-AI-12` for cross-step Evidence->Truth, Memory->Belief, Inference->Truth, and Role->Identity carry-over collapse.

- [x] Write failing tests for illegal cross-step carry-over and a legal Evidence->Claim->Evaluation->Truth trace.
- [x] Run focused tests and confirm RED.
- [x] Implement per-step audit aggregation plus cross-step checks.
- [x] Re-run focused tests and confirm GREEN.

### Task 3: Deterministic repair plan

**Files:**
- Create: `src/rsct/repair.py`
- Modify: `src/rsct/trace_audit.py`
- Test: `tests/test_ai_trace.py`

**Interfaces:**
- Produces `RepairAction`, `RepairPlan`
- Produces `build_repair_plan(result: ReasoningTraceAuditResult) -> RepairPlan`

- [x] Write failing tests proving repair actions are localized, deterministic, and do not mutate the original trace.
- [x] Run focused tests and confirm RED.
- [x] Implement repair actions as suggestions with `INSERT_EVALUATION`, `PRESERVE_AS_CLAIM`, `REVALIDATE_MEMORY`, `KEEP_ROLE_SCOPED`.
- [x] Re-run focused tests and confirm GREEN.

### Task 4: Middleware and CLI integration

**Files:**
- Modify: `src/rsct/middleware.py`
- Modify: `src/rsct/reporting.py`
- Modify: `src/rsct/cli.py`
- Test: `tests/test_ai_trace_cli.py`

**Interfaces:**
- Adds `RSCTSemanticMiddleware.audit_trace_contract(payload)` and `audit_trace_json(text)`.
- Adds CLI `rsct audit-ai-trace [--json] [--repair-plan] PATH|-`.

- [x] Write failing file/stdin/JSON CLI tests and exit-code tests.
- [x] Run focused tests and confirm RED.
- [x] Implement middleware/reporting/CLI wiring.
- [x] Re-run focused tests and confirm GREEN.

### Task 5: Canonical trace fixtures and regression closure

**Files:**
- Create: `tests/ai_traces/legal_reasoning_trace.json`
- Create: `tests/ai_traces/evidence_to_truth_cross_step.json`
- Create: `tests/ai_traces/memory_to_belief_cross_step.json`
- Create: `tests/ai_traces/inference_to_truth_cross_step.json`
- Create: `tests/ai_traces/role_to_identity_cross_step.json`
- Create: `tests/test_ai_trace_fixtures.py`
- Modify: `README.md`
- Modify: `VALIDATION.md`

- [x] Add failing fixture expectations first.
- [x] Run and confirm RED until fixtures and loader are wired.
- [x] Add canonical fixtures and documentation.
- [x] Run full `pytest -q`.
- [x] Run single-contract regression and liar fixed-point regression.
- [x] Run trace CLI on legal and illegal fixtures.
- [x] Build release ZIP, extract fresh, run full tests again, record SHA-256 and validation evidence.

## Self-Review

- Scope remains bounded to trace auditing; no arbitrary NLU or autonomous graph mutation.
- Existing `audit-ai` remains unchanged.
- Cross-step checks are explicit and typed rather than inferred from free-form text.
- Repair plans are recommendations, not automatic writes.
