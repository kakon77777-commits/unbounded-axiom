# RSCT AI Semantic Middleware MVP Extension Plan

**Goal:** Extend the validated RSCT Semantic Analyzer Runtime v0.1 with a deterministic AI-facing semantic audit layer that preserves claim/evidence/belief/memory/role/identity distinctions, detects illegal semantic collapses, and emits localized repair guidance before downstream reasoning.

**Architecture:** Reuse `SemanticGraphIR` as the contract between an AI/agent and the deterministic RSCT core. Add AI-specific semantic node types, a structured JSON contract loader, a deterministic graph auditor, repair hints, and an `audit-ai` CLI command. Do not add arbitrary-NLU or LLM dependencies; LLMs may construct candidate contracts externally, while RSCT validates them deterministically.

**Canonical constraints:** Evidence != Truth; BeliefState != Truth; MemoryRecord != CurrentBelief; Claim != Truth; Role != Identity; provenance must remain explicit; no finding may silently repair or mutate the submitted graph.

## Tasks

1. Add AI semantic types, audit findings/results, and AI failure codes with tests first.
2. Add structured AI contract loader with strict validation and provenance preservation, tests first.
3. Add deterministic semantic auditor with legal/illegal transition rules and localized repair hints, tests first.
4. Add `audit-ai` CLI JSON/file/stdin output, tests first.
5. Add canonical AI audit fixtures for evidence->truth, belief->truth, memory->belief, role->identity, and legal evidence->claim->evaluation paths.
6. Run full regression, fresh-zip verification, update README/VALIDATION, and create release bundle.
