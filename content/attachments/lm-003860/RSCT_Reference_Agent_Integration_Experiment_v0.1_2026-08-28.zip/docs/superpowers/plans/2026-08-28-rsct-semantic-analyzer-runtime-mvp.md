# RSCT Semantic Analyzer Runtime MVP v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic RSCT Semantic Analyzer Runtime MVP that converts a controlled set of natural-language inputs into typed semantic IR, detects self-reference and role/type pathologies, evaluates classical liar fixed-point conditions, and emits reproducible CLI/JSON evidence.

**Architecture:** Use a pure-Python deterministic core with three explicit representations: `SurfaceIR`, `SemanticGraphIR`, and `EvaluationIR`. Parsing is intentionally controlled and rule-based in v0.1; semantic graph construction, invariants, assumption mutation, and fixed-point results are deterministic. LLM integration is out of the core and is not required for MVP completion.

**Tech Stack:** Python 3.11+, standard library (`dataclasses`, `enum`, `argparse`, `json`, `re`, `typing`, `pathlib`), pytest.

**Spec:** `/mnt/data/RSCT_Formal_Specification_v0.1_2026-08-28.md` and `/mnt/data/RSCT_Semantic_Analyzer_Runtime_Technical_Whitepaper_v0.1_2026-08-28.md`

## Global Constraints

- Preserve `Surface Form != Semantic Type`.
- Preserve `Construction != Projection != Evaluation`.
- Preserve `Orientation != Negation`.
- Preserve `Evidence != Truth`.
- Preserve `Role != Identity`.
- Preserve `Difference != Tension != Metric`.
- Preserve `Boundary != Truth Label`.
- Preserve `Type Safety != Fixed-Point Existence`.
- LLM may propose candidates in future versions; deterministic RSCT Core alone decides type safety, invariants, and fixed-point results.
- `UNKNOWN != FALSE` and `NOT_APPLICABLE != UNKNOWN`.
- All analysis conclusions must preserve source spans, rule provenance, active assumptions, and failure classes.
- v0.1 accepts controlled sentence patterns only; unsupported inputs return explicit partial/unknown statuses rather than fabricated semantics.
- No arbitrary external code execution.

---

## File Structure

```text
rsct-semantic-analyzer-runtime/
├── pyproject.toml
├── README.md
├── src/
│   └── rsct/
│       ├── __init__.py
│       ├── model.py          # enums, typed IR dataclasses, statuses, failures
│       ├── registry.py       # semantic types, constructors, invariants, assumptions
│       ├── parser.py         # controlled surface parser and source spans
│       ├── semantic.py       # typed semantic graph construction + scenario rules
│       ├── reference.py      # reference resolution and self-reference classification
│       ├── fixedpoint.py     # deterministic finite-domain fixed-point/cycle analysis
│       ├── analyzer.py       # end-to-end RSCTAnalyzer orchestration
│       ├── reporting.py      # JSON/evidence serialization and safe summaries
│       └── cli.py            # analyze/graph/assumptions commands
├── tests/
│   ├── test_model.py
│   ├── test_fixedpoint.py
│   ├── test_parser.py
│   ├── test_scenarios.py
│   ├── test_assumptions.py
│   └── golden/
│       ├── liar_classical.json
│       ├── self_reference_language.json
│       ├── external_false_predicate.json
│       └── role_reification.json
└── docs/
    └── superpowers/
        └── plans/
            └── 2026-08-28-rsct-semantic-analyzer-runtime-mvp.md
```

### Task 1: Core project, typed IR, statuses, and invariants

**Files:**
- Create: `pyproject.toml`
- Create: `src/rsct/__init__.py`
- Create: `src/rsct/model.py`
- Create: `src/rsct/registry.py`
- Test: `tests/test_model.py`

**Interfaces:**
- Produces: `AnalysisStatus`, `SemanticType`, `FailureCode`, `SourceSpan`, `SurfaceToken`, `SurfaceIR`, `SemanticNode`, `SemanticEdge`, `SemanticGraphIR`, `FixedPointResult`, `EvaluationIR`, `AnalysisResult`.
- Produces: `DEFAULT_ASSUMPTIONS`, `RUNTIME_INVARIANTS`.

- [ ] **Step 1: Write the failing core-model tests**

```python
from rsct.model import AnalysisStatus, SemanticType, SourceSpan
from rsct.registry import RUNTIME_INVARIANTS

def test_unknown_is_not_false():
    assert AnalysisStatus.UNKNOWN is not AnalysisStatus.FAIL

def test_truth_bearer_is_distinct_from_sentence_token():
    assert SemanticType.TRUTH_BEARER != SemanticType.SENTENCE_TOKEN

def test_invariants_include_role_identity_separation():
    assert "Role != Identity" in RUNTIME_INVARIANTS

def test_source_span_is_half_open():
    span = SourceSpan(start=2, end=5)
    assert span.length == 3
```

- [ ] **Step 2: Run tests and confirm failure**

Run: `pytest tests/test_model.py -q`  
Expected: import/module failures because the package does not yet exist.

- [ ] **Step 3: Implement minimal typed model and registry**

Implement explicit enums and frozen dataclasses. `AnalysisStatus` must include:
`PASS`, `FAIL`, `UNKNOWN`, `NOT_APPLICABLE`, `AMBIGUOUS`, `PARTIAL`.

`FailureCode` must include:
`F-TYPE-01`, `F-TYPE-02`, `F-REF-01`, `F-REF-02`, `F-CONST-01`, `F-PROJ-01`, `F-EVAL-01`, `F-EVAL-02`, `F-FIX-01`, `F-BOUND-01`, `F-METRIC-01`.

- [ ] **Step 4: Run tests to verify pass**

Run: `pytest tests/test_model.py -q`  
Expected: PASS.

### Task 2: Deterministic fixed-point and cycle core

**Files:**
- Create: `src/rsct/fixedpoint.py`
- Test: `tests/test_fixedpoint.py`

**Interfaces:**
- Consumes: `FixedPointResult`, `AnalysisStatus`.
- Produces:
  - `analyze_finite_map(domain: tuple[str, ...], mapping: dict[str, str]) -> FixedPointResult`
  - `classical_bivalent_negation() -> dict[str, str]`

- [ ] **Step 1: Write failing fixed-point tests**

```python
from rsct.fixedpoint import analyze_finite_map, classical_bivalent_negation

def test_bivalent_negation_has_no_fixed_point_and_period_two():
    result = analyze_finite_map(("T", "F"), classical_bivalent_negation())
    assert result.fixed_points == ()
    assert ("T", "F") in result.cycles or ("F", "T") in result.cycles
    assert result.status.value == "NO_FIXED_POINT"

def test_identity_map_has_two_fixed_points():
    result = analyze_finite_map(("T", "F"), {"T": "T", "F": "F"})
    assert set(result.fixed_points) == {"T", "F"}
```

- [ ] **Step 2: Run and confirm failure**

Run: `pytest tests/test_fixedpoint.py -q`  
Expected: module/function failure.

- [ ] **Step 3: Implement finite map analysis**

Enumerate fixed points directly. Detect simple cycles canonically without duplicating rotated representations. For classical negation return `{"T": "F", "F": "T"}`.

- [ ] **Step 4: Run and verify pass**

Run: `pytest tests/test_fixedpoint.py -q`.

### Task 3: Controlled surface parser and source provenance

**Files:**
- Create: `src/rsct/parser.py`
- Test: `tests/test_parser.py`

**Interfaces:**
- Produces: `parse_surface(text: str, language: str = "zh-TW") -> SurfaceIR`.
- Controlled patterns:
  1. `這句話是假的。`
  2. `這句話是中文。`
  3. `「...」是假的。`
  4. `雪是白的。`
  5. `他說過謊，所以他就是永遠的說謊者。`
  6. `A 照顧 B，但 B 管理 A。`
  7. `有研究支持 P，也有研究反對 P。`

- [ ] **Step 1: Write parser tests**

Verify exact source spans and pattern tags, including unsupported text returning `PARTIAL` rather than invented semantics.

- [ ] **Step 2: Run and confirm failure**
- [ ] **Step 3: Implement regex/rule-based parser**
- [ ] **Step 4: Run and verify pass**

### Task 4: Typed semantic graph construction and reference analysis

**Files:**
- Create: `src/rsct/semantic.py`
- Create: `src/rsct/reference.py`
- Test: `tests/test_scenarios.py`

**Interfaces:**
- Consumes: `SurfaceIR`.
- Produces: `SemanticGraphIR`.
- Produces: `build_semantic_graph(surface_ir: SurfaceIR) -> SemanticGraphIR`.
- Produces: `classify_self_reference(graph: SemanticGraphIR) -> dict[str, object]`.

- [ ] **Step 1: Write failing scenario graph tests**

Required expectations:
- liar has `SentenceToken`, `Proposition`, `TruthBearer`, `FalsePredicate` nodes and a self-reference path.
- `這句話是中文。` has self-reference but no false predicate.
- external false-predicate sentence has false predicate but no self-reference.
- role-reification case emits `ROLE_REIFICATION` edge/candidate and warning.
- bidirectional care/manage case preserves two heterogeneous edges rather than marking symmetry.
- support/oppose case creates evidence nodes without truth assignment.

- [ ] **Step 2: Run and confirm failure**
- [ ] **Step 3: Implement scenario-rule graph builder**
- [ ] **Step 4: Run and verify pass**

### Task 5: End-to-end analyzer, assumptions, and liar evaluation contract

**Files:**
- Create: `src/rsct/analyzer.py`
- Test: `tests/test_assumptions.py`
- Extend: `tests/test_scenarios.py`

**Interfaces:**
- Produces:
  - `RSCTAnalyzer(profile: str = "classical-bivalent", assumptions: dict[str, bool] | None = None)`
  - `RSCTAnalyzer.analyze(text: str) -> AnalysisResult`
- Profiles:
  - `classical-bivalent`
- Assumptions:
  - `SELF_REFERENCE`
  - `TRUTH_BEARER_VALID`
  - `FALSE_PREDICATE_CLASSICAL`
  - `TOTAL_BIVALENCE`
  - `IMMEDIATE_REENTRY`

- [ ] **Step 1: Write failing analyzer tests**

```python
def test_classical_liar_reports_no_fixed_point():
    result = RSCTAnalyzer().analyze("這句話是假的。")
    assert result.evaluation.fixed_point_equation == "v = N(v)"
    assert result.evaluation.fixed_point.status.value == "NO_FIXED_POINT"
    assert result.summary == "No stable value exists under the active semantic contract."

def test_harmless_self_reference_is_not_liar():
    result = RSCTAnalyzer().analyze("這句話是中文。")
    assert result.self_reference["detected"] is True
    assert result.evaluation.fixed_point.status.value == "NOT_APPLICABLE"

def test_disabling_total_bivalence_changes_analysis():
    analyzer = RSCTAnalyzer(assumptions={"TOTAL_BIVALENCE": False})
    result = analyzer.analyze("這句話是假的。")
    assert result.evaluation.fixed_point.status.value != "NO_FIXED_POINT"
```

- [ ] **Step 2: Run and confirm failure**
- [ ] **Step 3: Implement orchestration and active-assumption contract**
- [ ] **Step 4: Run and verify pass**

### Task 6: Reporting, CLI, JSON mode, graph and assumption commands

**Files:**
- Create: `src/rsct/reporting.py`
- Create: `src/rsct/cli.py`
- Modify: `pyproject.toml`
- Test: `tests/test_scenarios.py`

**Interfaces:**
- Produces `result_to_dict(result: AnalysisResult) -> dict`.
- CLI:
  - `rsct analyze TEXT`
  - `rsct analyze --json TEXT`
  - `rsct graph TEXT`
  - `rsct assumptions TEXT`
  - `rsct analyze --set TOTAL_BIVALENCE=false TEXT`

- [ ] **Step 1: Write CLI/reporting tests**
- [ ] **Step 2: Run and confirm failure**
- [ ] **Step 3: Implement deterministic serialization and argparse CLI**
- [ ] **Step 4: Verify commands manually and with pytest**

Expected liar text output:

```text
Self-reference: YES
False predicate: YES
Active truth domain: {T,F}
Fixed-point equation: v = N(v)
Fixed-point status: NO_FIXED_POINT
Conclusion: No stable value exists under the active semantic contract.
```

### Task 7: Golden tests, README, package verification, and release bundle

**Files:**
- Create/Update: `tests/golden/*.json`
- Create: `README.md`
- Copy plan to: `docs/superpowers/plans/2026-08-28-rsct-semantic-analyzer-runtime-mvp.md`

**Interfaces:**
- Final deliverable: installable/testable project directory and ZIP.

- [ ] **Step 1: Generate golden JSON from deterministic analyzer**
- [ ] **Step 2: Add golden comparison tests**
- [ ] **Step 3: Run full test suite**

Run:

```bash
pytest -q
```

Expected: all tests PASS.

- [ ] **Step 4: Verify CLI**

Run:

```bash
python -m rsct.cli analyze "這句話是假的。"
python -m rsct.cli analyze --json "這句話是假的。"
python -m rsct.cli graph "這句話是假的。"
python -m rsct.cli assumptions "這句話是假的。"
```

- [ ] **Step 5: Verify source tree contains no placeholders**

Search for `TBD`, `TODO`, `pass #`, and placeholder markers; remove any incomplete implementation.

- [ ] **Step 6: Build final ZIP with validation report**

Include source, tests, README, formal-spec references, implementation plan, and a validation JSON containing Python version, pytest result, canonical scenario results, and SHA-256 hashes.

---

## Plan Self-Review

- Spec coverage: Formal types, construction trace, reference resolution, action graph, generative reflexivity, truth/evidence separation, fixed-point analysis, assumptions, failure taxonomy, controlled scenarios, CLI/JSON, and evidence-ready reporting all map to tasks.
- Placeholder scan: No implementation placeholders are part of the required deliverable.
- Type consistency: `AnalysisResult -> EvaluationIR -> FixedPointResult` is used consistently; semantic graph always preserves source/provenance.
- Scope: Tension/boundary components are adapters only in v0.1, matching the whitepaper’s YAGNI boundary; no arbitrary NLU or LLM dependency is introduced.
