# RSCT Reference Agent Integration Experiment v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a provider-neutral A/B experiment harness comparing agent-only acceptance with RSCT-gated repair-loop execution over the frozen semantic error benchmark.

**Architecture:** Add a small experiment layer that consumes existing `BenchmarkCase` objects and `RSCTSemanticMiddleware`. A deterministic scripted provider validates the harness; a replay provider accepts pre-recorded external-agent outputs. The frozen Gate and benchmark remain unchanged.

**Tech Stack:** Python 3.11+, standard library, pytest.

**Spec:** `docs/reference/RSCT_Reference_Agent_Integration_Experiment_v0.1.md`

## Global Constraints
- Do not change Gate v0.2 policy or benchmark case labels.
- Scripted-provider results are simulation/reference results, not external-model evidence.
- Repair output must be a new payload; prior attempts are immutable from the experiment's perspective.
- BLOCK requests repair up to `max_repairs`; DEFER stops; PASS/WARN may continue.
- Preserve gate findings, repair actions, provider name, attempt index, and case id in every record.

---

### Task 1: Experiment model and metrics
**Files:** Create `src/rsct/experiment.py`; Test `tests/test_experiment.py`.
**Interfaces:** `AgentAttempt`, `CaseExperimentResult`, `ExperimentMetrics`, `ExperimentRun`, `score_experiment()`.
- [ ] Write failing tests for unsafe acceptance, repair success, false positive, completion, and extra-step metrics.
- [ ] Run RED.
- [ ] Implement minimal immutable models and scorer.
- [ ] Run GREEN.

### Task 2: Provider protocol and scripted reference provider
**Files:** Create `src/rsct/reference_agent.py`; Extend `tests/test_experiment.py`.
**Interfaces:** `ReferenceAgent`, `ScriptedReferenceAgent`, `ReplayReferenceAgent`.
- [ ] Write failing tests that scripted initial output equals case payload, repair returns a new safe payload, and replay provider enforces exact case coverage.
- [ ] Run RED.
- [ ] Implement provider protocol and deterministic providers.
- [ ] Run GREEN.

### Task 3: A/B runner
**Files:** Extend `src/rsct/experiment.py`; Extend `tests/test_experiment.py`.
**Interfaces:** `run_reference_agent_experiment(cases, provider, middleware, max_repairs=1)`.
- [ ] Write failing tests for baseline acceptance, gated BLOCK→repair→PASS, WARN continuation, DEFER stop, and no in-place mutation.
- [ ] Run RED.
- [ ] Implement runner.
- [ ] Run GREEN.

### Task 4: CLI and serialization
**Files:** Modify `src/rsct/cli.py`, `src/rsct/reporting.py`; Test `tests/test_experiment_cli.py`.
**Interfaces:** `rsct experiment-reference-agent DATASET [--provider scripted|replay] [--replay FILE] [--max-repairs N] [--json]`.
- [ ] Write failing CLI tests.
- [ ] Run RED.
- [ ] Implement JSON/text serialization and CLI command.
- [ ] Run GREEN.

### Task 5: Canonical experiment artifact and validation
**Files:** Create `experiments/reference_agent_v0.1/README.md`, results JSON, report MD; update README; update validation evidence.
- [ ] Run full regression.
- [ ] Run scripted A/B experiment on all 88 frozen cases.
- [ ] Record metrics with explicit `provider_kind=scripted` and `external_model_evidence=false`.
- [ ] Fresh archive/extract/install/test and rerun experiment.
