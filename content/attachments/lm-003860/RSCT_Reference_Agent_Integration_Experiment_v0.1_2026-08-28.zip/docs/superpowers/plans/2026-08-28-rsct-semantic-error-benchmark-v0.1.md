# RSCT Semantic Error Benchmark v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a reproducible controlled semantic-error benchmark that scores RSCT Agent Semantic Gate decisions, failure codes, and repair actions against canonical labeled contract/trace cases and compares them with a pass-through baseline.

**Architecture:** Keep Runtime 0.2.0 semantics frozen. Add a benchmark-only module, canonical JSONL dataset, deterministic runner/scorer, CLI commands, external-prediction scoring interface, metrics/report generation, and release evidence. The benchmark is explicitly an in-distribution conformance benchmark, not evidence of external LLM generalization.

**Tech Stack:** Python 3.11+, stdlib dataclasses/json/pathlib/argparse, pytest.

**Spec:** `docs/reference/RSCT_Agent_Semantic_Gate_Contract_v0.2.md`

## Global Constraints

- Do not change Gate decision rules or existing failure semantics.
- Benchmark dataset v0.1 must contain 60–100 cases; target 88.
- Preserve exact expected decision, failure code, and repair action labels.
- Report PASS/WARN/BLOCK/DEFER separately.
- Pass-through baseline means predict PASS for every case; label it explicitly as a non-semantic control, not an AI model.
- External model A/B is not claimed unless external prediction records are supplied.
- Dataset and reports must be deterministic and replayable.
- Full legacy regression must remain green.

---

### Task 1: Benchmark data model and scoring core

**Files:**
- Create: `src/rsct/benchmark.py`
- Test: `tests/test_benchmark.py`

**Interfaces:**
- `BenchmarkCase`
- `BenchmarkPrediction`
- `BenchmarkMetrics`
- `load_benchmark_cases(path)`
- `run_gate_benchmark(cases, middleware=None)`
- `run_passthrough_baseline(cases)`
- `score_predictions(cases, predictions)`

TDD: write tests first for decision accuracy, BLOCK/WARN recall, DEFER accuracy, failure-code exact match, repair-action exact match, and confusion matrix; verify RED; implement minimum; verify GREEN.

### Task 2: Canonical 88-case dataset

**Files:**
- Create: `benchmarks/semantic_error_v0.1/cases.jsonl`
- Create: `benchmarks/semantic_error_v0.1/README.md`
- Test: `tests/test_benchmark_dataset.py`

Dataset composition: 22 categories × 4 structural variants = 88 cases. Categories cover single-contract and cross-step Evidence/Claim/Belief/Memory/Inference/Observation truth collapses, Role→Identity, undeclared lossy projection, legal paths, and invalid contract/trace DEFER cases.

TDD: dataset tests must assert 88 unique IDs, expected decision counts 48 BLOCK / 12 WARN / 20 PASS / 8 DEFER, category cardinality, and schema validity.

### Task 3: Runner and external prediction scoring CLI

**Files:**
- Modify: `src/rsct/cli.py`
- Modify: `src/rsct/reporting.py`
- Test: `tests/test_benchmark_cli.py`

Commands:
- `rsct benchmark DATASET --engine gate|passthrough [--json]`
- `rsct benchmark-score DATASET PREDICTIONS [--json]`

External predictions JSONL schema: `{case_id, decision, failure_codes, repair_actions}`.

TDD: verify exit 0 on a valid completed benchmark, JSON fields, pass-through baseline metrics, and malformed prediction error exit 2.

### Task 4: Canonical benchmark report and release closure

**Files:**
- Create: `benchmarks/semantic_error_v0.1/RSCT_SEMANTIC_ERROR_BENCHMARK_REPORT_v0.1.md`
- Update: `README.md`
- Update: `VALIDATION.md` / `VALIDATION.json`

Run Gate and pass-through baselines. Record exact metrics and explicitly state this is canonical conformance/in-distribution evaluation, not external model efficacy. Run full pytest, compileall, CLI smoke, clean target install, commit, archive, fresh-extract pytest and benchmark replay, SHA-256, and release validation report.
