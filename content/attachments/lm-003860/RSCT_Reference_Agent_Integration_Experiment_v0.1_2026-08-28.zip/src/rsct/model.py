from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping


class AnalysisStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    AMBIGUOUS = "AMBIGUOUS"
    PARTIAL = "PARTIAL"
    NO_FIXED_POINT = "NO_FIXED_POINT"
    FIXED_POINT_FOUND = "FIXED_POINT_FOUND"


class SemanticType(str, Enum):
    SURFACE_UNIT = "SurfaceUnit"
    SENTENCE_TOKEN = "SentenceToken"
    SENTENCE_TYPE = "SentenceType"
    DEICTIC = "Deictic"
    REFERENCE_TARGET = "ReferenceTarget"
    PROPOSITION = "Proposition"
    TRUTH_BEARER = "TruthBearer"
    ENTITY = "Entity"
    RELATION = "Relation"
    ACT_REL = "ActRel"
    OPERATOR = "Operator"
    CONSTRUCTOR = "Constructor"
    ROLE = "Role"
    IDENTITY = "Identity"
    CONSTRAINT = "Constraint"
    STATE = "State"
    TENSION_STATE = "TensionState"
    BOUNDARY = "Boundary"
    EXTREMUM = "Extremum"
    TRUTH_VALUE_LABEL = "TruthValueLabel"
    EVIDENCE_STATE = "EvidenceState"
    PROJECTION = "Projection"
    CONTEXT = "Context"
    OBSERVER = "Observer"
    FALSE_PREDICATE = "FalsePredicate"
    ROLE_ASSIGNMENT = "RoleAssignment"
    CLAIM = "Claim"
    OBSERVATION = "Observation"
    MEMORY_RECORD = "MemoryRecord"
    BELIEF_STATE = "BeliefState"
    INFERENCE = "Inference"
    EVALUATION = "Evaluation"


class FailureCode(str, Enum):
    TYPE_MISMATCH = "F-TYPE-01"
    TYPE_COLLAPSE = "F-TYPE-02"
    REF_UNRESOLVED = "F-REF-01"
    REF_TYPE_COLLAPSE = "F-REF-02"
    CONSTRUCTION_UNDEFINED = "F-CONST-01"
    PROJECTION_UNDECLARED_LOSS = "F-PROJ-01"
    EVALUATION_UNDEFINED = "F-EVAL-01"
    TRUTH_TYPE_COLLAPSE = "F-EVAL-02"
    FIX_NO_FIXED_POINT = "F-FIX-01"
    BOUNDARY_UNDEFINED = "F-BOUND-01"
    ILLEGAL_METRICIZATION = "F-METRIC-01"
    AI_CLAIM_TRUTH_COLLAPSE = "F-AI-01"
    AI_EVIDENCE_TRUTH_COLLAPSE = "F-AI-02"
    AI_BELIEF_TRUTH_COLLAPSE = "F-AI-03"
    AI_MEMORY_BELIEF_COLLAPSE = "F-AI-04"
    AI_PROVENANCE_MISSING = "F-AI-05"
    AI_ROLE_IDENTITY_ESCALATION = "F-AI-06"
    AI_INFERENCE_TRUTH_COLLAPSE = "F-AI-07"
    AI_OBSERVATION_TRUTH_COLLAPSE = "F-AI-08"
    AI_TRACE_EVIDENCE_TRUTH_COLLAPSE = "F-AI-09"
    AI_TRACE_MEMORY_BELIEF_COLLAPSE = "F-AI-10"
    AI_TRACE_INFERENCE_TRUTH_COLLAPSE = "F-AI-11"
    AI_TRACE_ROLE_IDENTITY_ESCALATION = "F-AI-12"
    AI_TRACE_CLAIM_TRUTH_COLLAPSE = "F-AI-13"
    AI_TRACE_BELIEF_TRUTH_COLLAPSE = "F-AI-14"
    AI_TRACE_OBSERVATION_TRUTH_COLLAPSE = "F-AI-15"
    AI_GATE_INPUT_INVALID = "F-AI-16"


@dataclass(frozen=True)
class SourceSpan:
    start: int
    end: int

    def __post_init__(self) -> None:
        if self.start < 0 or self.end < self.start:
            raise ValueError("invalid half-open source span")

    @property
    def length(self) -> int:
        return self.end - self.start


@dataclass(frozen=True)
class SurfaceToken:
    token_id: str
    surface: str
    span: SourceSpan
    pos_hint: str | None = None
    lemma_hint: str | None = None
    confidence: float = 1.0


@dataclass(frozen=True)
class SurfaceIR:
    text: str
    language: str
    tokens: tuple[SurfaceToken, ...] = ()
    pattern: str = "UNSUPPORTED"
    status: AnalysisStatus = AnalysisStatus.PASS
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class SemanticNode:
    node_id: str
    semantic_type: SemanticType
    surface: str | None = None
    span: SourceSpan | None = None
    context: str | None = None
    observer: str | None = None
    state: Mapping[str, Any] = field(default_factory=dict)
    provenance: str = "input"
    inferred: bool = False


@dataclass(frozen=True)
class SemanticEdge:
    edge_id: str
    source: str
    target: str
    edge_type: str
    direction: str = "FORWARD"
    constraints: tuple[str, ...] = ()
    operator: str | None = None
    projection: Mapping[str, Any] = field(default_factory=dict)
    provenance: str = "rule"


@dataclass(frozen=True)
class SemanticGraphIR:
    nodes: tuple[SemanticNode, ...] = ()
    edges: tuple[SemanticEdge, ...] = ()
    construction_traces: tuple[Mapping[str, Any], ...] = ()
    warnings: tuple[str, ...] = ()

    def node_types(self) -> set[SemanticType]:
        return {node.semantic_type for node in self.nodes}


@dataclass(frozen=True)
class FixedPointResult:
    status: AnalysisStatus
    fixed_points: tuple[str, ...] = ()
    cycles: tuple[tuple[str, ...], ...] = ()
    equation: str | None = None
    explanation: str = ""


@dataclass(frozen=True)
class EvaluationIR:
    truth_bearer: str | None = None
    reference_domain: str | None = None
    truth_domain: tuple[str, ...] = ()
    fixed_point_equation: str | None = None
    fixed_point: FixedPointResult = field(
        default_factory=lambda: FixedPointResult(AnalysisStatus.NOT_APPLICABLE)
    )
    false_predicate: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AnalysisResult:
    text: str
    parse_status: AnalysisStatus
    graph: SemanticGraphIR
    evaluation: EvaluationIR
    failures: tuple[FailureCode, ...]
    assumptions: Mapping[str, bool]
    self_reference: Mapping[str, Any]
    summary: str
