from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Mapping

from .audit import AISemanticAuditResult, AuditSeverity
from .model import FailureCode
from .repair import build_repair_plan
from .trace_audit import ReasoningTraceAuditResult


class GateDecision(str, Enum):
    PASS = "PASS"
    WARN = "WARN"
    BLOCK = "BLOCK"
    DEFER = "DEFER"


DEFAULT_GATE_ASSUMPTIONS: Mapping[str, bool] = MappingProxyType(
    {
        "AUTO_APPLY_REPAIRS": False,
        "DEFER_ON_INVALID_INPUT": True,
        "ALLOW_WARNING_CONTINUE": True,
        "DETERMINISTIC_POLICY": True,
    }
)


@dataclass(frozen=True)
class GateRepairAction:
    action: str
    finding_code: FailureCode
    target_id: str
    instruction: str
    source_step: str | None = None
    target_step: str | None = None


@dataclass(frozen=True)
class GateDecisionProvenance:
    policy_id: str
    policy_version: str
    input_kind: str
    rule: str
    evaluated_finding_count: int


@dataclass(frozen=True)
class GateResult:
    decision: GateDecision
    failure_codes: tuple[FailureCode, ...]
    repair_actions: tuple[GateRepairAction, ...]
    active_assumptions: Mapping[str, bool]
    provenance: GateDecisionProvenance
    reason: str

    @property
    def may_continue(self) -> bool:
        return self.decision in {GateDecision.PASS, GateDecision.WARN}


_SINGLE_ACTIONS = {
    FailureCode.AI_CLAIM_TRUTH_COLLAPSE: "INSERT_EVALUATION",
    FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE: "INSERT_EVALUATION",
    FailureCode.AI_BELIEF_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
    FailureCode.AI_MEMORY_BELIEF_COLLAPSE: "REVALIDATE_MEMORY",
    FailureCode.AI_ROLE_IDENTITY_ESCALATION: "KEEP_ROLE_SCOPED",
    FailureCode.AI_INFERENCE_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
    FailureCode.AI_OBSERVATION_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
    FailureCode.PROJECTION_UNDECLARED_LOSS: "DECLARE_PROJECTION_LOSS",
}


def _single_repair_actions(
    findings,
    *,
    source_step: str | None = None,
    target_step: str | None = None,
) -> tuple[GateRepairAction, ...]:
    return tuple(
        GateRepairAction(
            action=_SINGLE_ACTIONS[finding.code],
            finding_code=finding.code,
            target_id=finding.edge_id,
            instruction=finding.repair_hint,
            source_step=source_step,
            target_step=target_step,
        )
        for finding in findings
        if finding.code in _SINGLE_ACTIONS
    )


def _decision_from_severities(severities: tuple[AuditSeverity, ...]) -> tuple[GateDecision, str]:
    if any(value is AuditSeverity.ERROR for value in severities):
        return GateDecision.BLOCK, "ERROR_FINDING=>BLOCK"
    if any(value is AuditSeverity.WARNING for value in severities):
        return GateDecision.WARN, "WARNING_ONLY=>WARN"
    return GateDecision.PASS, "NO_FINDINGS=>PASS"


def _decision_reason(decision: GateDecision) -> str:
    if decision is GateDecision.BLOCK:
        return "Error-level semantic findings block continuation under the active gate policy."
    if decision is GateDecision.WARN:
        return "Warning-only semantic findings permit continuation with attached warnings."
    return "No semantic findings under the active gate policy."


def gate_single_audit(
    audit: AISemanticAuditResult,
    *,
    assumptions: Mapping[str, bool] = DEFAULT_GATE_ASSUMPTIONS,
) -> GateResult:
    decision, rule = _decision_from_severities(tuple(f.severity for f in audit.findings))
    repairs = _single_repair_actions(audit.findings)
    return GateResult(
        decision=decision,
        failure_codes=audit.failure_codes,
        repair_actions=repairs,
        active_assumptions=MappingProxyType(dict(assumptions)),
        provenance=GateDecisionProvenance(
            policy_id="rsct-agent-semantic-gate",
            policy_version="0.2",
            input_kind="contract",
            rule=rule,
            evaluated_finding_count=len(audit.findings),
        ),
        reason=_decision_reason(decision),
    )


def gate_trace_audit(
    audit: ReasoningTraceAuditResult,
    *,
    assumptions: Mapping[str, bool] = DEFAULT_GATE_ASSUMPTIONS,
) -> GateResult:
    all_findings = [f for _, step_audit in audit.step_audits for f in step_audit.findings]
    all_findings.extend(audit.cross_step_findings)
    decision, rule = _decision_from_severities(tuple(f.severity for f in all_findings))
    step_repairs = tuple(
        repair
        for step_id, step_audit in audit.step_audits
        for repair in _single_repair_actions(
            step_audit.findings,
            source_step=step_id,
            target_step=step_id,
        )
    )
    trace_plan = build_repair_plan(audit)
    cross_repairs = tuple(
        GateRepairAction(
            action=action.action,
            finding_code=action.finding_code,
            target_id=action.carry_over_id,
            instruction=action.instruction,
            source_step=action.source_step,
            target_step=action.target_step,
        )
        for action in trace_plan.actions
    )
    repairs = step_repairs + cross_repairs
    return GateResult(
        decision=decision,
        failure_codes=audit.failure_codes,
        repair_actions=repairs,
        active_assumptions=MappingProxyType(dict(assumptions)),
        provenance=GateDecisionProvenance(
            policy_id="rsct-agent-semantic-gate",
            policy_version="0.2",
            input_kind="reasoning_trace",
            rule=rule,
            evaluated_finding_count=len(all_findings),
        ),
        reason=_decision_reason(decision),
    )


def deferred_gate_result(
    *,
    input_kind: str,
    reason: str,
    assumptions: Mapping[str, bool] = DEFAULT_GATE_ASSUMPTIONS,
) -> GateResult:
    return GateResult(
        decision=GateDecision.DEFER,
        failure_codes=(FailureCode.AI_GATE_INPUT_INVALID,),
        repair_actions=(),
        active_assumptions=MappingProxyType(dict(assumptions)),
        provenance=GateDecisionProvenance(
            policy_id="rsct-agent-semantic-gate",
            policy_version="0.2",
            input_kind=input_kind,
            rule="INVALID_INPUT=>DEFER",
            evaluated_finding_count=0,
        ),
        reason=reason,
    )
