DEFAULT_ASSUMPTIONS = {
    "SELF_REFERENCE": True,
    "TRUTH_BEARER_VALID": True,
    "FALSE_PREDICATE_CLASSICAL": True,
    "TOTAL_BIVALENCE": True,
    "IMMEDIATE_REENTRY": True,
}

RUNTIME_INVARIANTS = (
    "Surface Form != Semantic Type",
    "Construction != Projection",
    "Projection != Evaluation",
    "Orientation != Negation",
    "Evidence != Truth",
    "Role != Identity",
    "Difference != Tension",
    "Tension != Metric",
    "Boundary != Truth Label",
    "Type Safety != Fixed-Point Existence",
    "Claim != Truth",
    "BeliefState != Truth",
    "MemoryRecord != BeliefState",
    "Inference != Truth",
    "Observation != Truth",
)
