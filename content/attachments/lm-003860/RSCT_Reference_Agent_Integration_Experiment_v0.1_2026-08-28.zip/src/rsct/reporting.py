from __future__ import annotations

from typing import Any

from .audit import AISemanticAuditResult
from .model import AnalysisResult, SemanticEdge, SemanticNode


def _span_dict(span) -> dict[str, int] | None:
    if span is None:
        return None
    return {"start": span.start, "end": span.end}


def node_to_dict(node: SemanticNode) -> dict[str, Any]:
    return {
        "node_id": node.node_id,
        "semantic_type": node.semantic_type.value,
        "surface": node.surface,
        "span": _span_dict(node.span),
        "context": node.context,
        "observer": node.observer,
        "state": dict(node.state),
        "provenance": node.provenance,
        "inferred": node.inferred,
    }


def edge_to_dict(edge: SemanticEdge) -> dict[str, Any]:
    return {
        "edge_id": edge.edge_id,
        "source": edge.source,
        "target": edge.target,
        "edge_type": edge.edge_type,
        "direction": edge.direction,
        "constraints": list(edge.constraints),
        "operator": edge.operator,
        "projection": dict(edge.projection),
        "provenance": edge.provenance,
    }


def graph_to_dict(result: AnalysisResult) -> dict[str, Any]:
    return {
        "nodes": [node_to_dict(node) for node in result.graph.nodes],
        "edges": [edge_to_dict(edge) for edge in result.graph.edges],
        "construction_traces": [dict(trace) for trace in result.graph.construction_traces],
        "warnings": list(result.graph.warnings),
    }


def result_to_dict(result: AnalysisResult) -> dict[str, Any]:
    fixed = result.evaluation.fixed_point
    return {
        "input": result.text,
        "parse_status": result.parse_status.value,
        "self_reference": dict(result.self_reference),
        "false_predicate": result.evaluation.false_predicate,
        "truth_bearer": result.evaluation.truth_bearer,
        "truth_domain": list(result.evaluation.truth_domain),
        "fixed_point": {
            "status": fixed.status.value,
            "equation": result.evaluation.fixed_point_equation or fixed.equation,
            "fixed_points": list(fixed.fixed_points),
            "cycles": [list(cycle) for cycle in fixed.cycles],
            "explanation": fixed.explanation,
        },
        "semantic_graph": graph_to_dict(result),
        "failures": [failure.value for failure in result.failures],
        "assumptions": dict(result.assumptions),
        "summary": result.summary,
    }


def render_text(result: AnalysisResult) -> str:
    fixed = result.evaluation.fixed_point
    truth_domain = "{" + ",".join(result.evaluation.truth_domain) + "}" if result.evaluation.truth_domain else "N/A"
    equation = result.evaluation.fixed_point_equation or fixed.equation or "N/A"
    return "\n".join(
        [
            f"Self-reference: {'YES' if result.self_reference.get('detected') else 'NO'}",
            f"False predicate: {'YES' if result.evaluation.false_predicate else 'NO'}",
            f"Active truth domain: {truth_domain}",
            f"Fixed-point equation: {equation}",
            f"Fixed-point status: {fixed.status.value}",
            f"Conclusion: {result.summary}",
        ]
    )


def audit_result_to_dict(result: AISemanticAuditResult) -> dict[str, Any]:
    return {
        "passed": result.passed,
        "failure_codes": [code.value for code in result.failure_codes],
        "findings": [
            {
                "code": finding.code.value,
                "severity": finding.severity.value,
                "edge_id": finding.edge_id,
                "message": finding.message,
                "repair_hint": finding.repair_hint,
            }
            for finding in result.findings
        ],
        "semantic_graph": {
            "nodes": [node_to_dict(node) for node in result.graph.nodes],
            "edges": [edge_to_dict(edge) for edge in result.graph.edges],
        },
    }


def render_audit_text(result: AISemanticAuditResult) -> str:
    lines = [f"AI semantic audit: {'PASS' if result.passed else 'FAIL'}"]
    if not result.findings:
        lines.append("Findings: 0")
        return "\n".join(lines)
    lines.append(f"Findings: {len(result.findings)}")
    for finding in result.findings:
        lines.append(f"{finding.code.value} {finding.severity.value} edge={finding.edge_id}: {finding.message}")
        lines.append(f"Repair: {finding.repair_hint}")
    return "\n".join(lines)


def trace_audit_result_to_dict(result, repair_plan=None) -> dict[str, Any]:
    payload = {
        "trace_id": result.trace.trace_id,
        "passed": result.passed,
        "failure_codes": [code.value for code in result.failure_codes],
        "step_audits": [
            {
                "step_id": step_id,
                "passed": audit.passed,
                "failure_codes": [code.value for code in audit.failure_codes],
                "findings": [
                    {
                        "code": finding.code.value,
                        "severity": finding.severity.value,
                        "edge_id": finding.edge_id,
                        "message": finding.message,
                        "repair_hint": finding.repair_hint,
                    }
                    for finding in audit.findings
                ],
            }
            for step_id, audit in result.step_audits
        ],
        "cross_step_findings": [
            {
                "code": finding.code.value,
                "severity": finding.severity.value,
                "carry_over_id": finding.carry_over_id,
                "source_step": finding.source_step,
                "source_node": finding.source_node,
                "target_step": finding.target_step,
                "target_node": finding.target_node,
                "message": finding.message,
                "repair_hint": finding.repair_hint,
            }
            for finding in result.cross_step_findings
        ],
    }
    if repair_plan is not None:
        payload["repair_plan"] = {
            "trace_id": repair_plan.trace_id,
            "actions": [
                {
                    "action": action.action,
                    "finding_code": action.finding_code.value,
                    "carry_over_id": action.carry_over_id,
                    "source_step": action.source_step,
                    "target_step": action.target_step,
                    "instruction": action.instruction,
                }
                for action in repair_plan.actions
            ],
        }
    return payload


def render_trace_audit_text(result, repair_plan=None) -> str:
    lines = [f"AI reasoning trace audit: {'PASS' if result.passed else 'FAIL'}"]
    step_finding_count = sum(len(audit.findings) for _, audit in result.step_audits)
    lines.append(f"Step findings: {step_finding_count}")
    lines.append(f"Cross-step findings: {len(result.cross_step_findings)}")
    for finding in result.cross_step_findings:
        lines.append(
            f"{finding.code.value} {finding.severity.value} carry={finding.carry_over_id} "
            f"{finding.source_step}:{finding.source_node}->{finding.target_step}:{finding.target_node}: {finding.message}"
        )
        lines.append(f"Repair: {finding.repair_hint}")
    if repair_plan is not None:
        lines.append(f"Repair actions: {len(repair_plan.actions)}")
        for action in repair_plan.actions:
            lines.append(
                f"{action.action} carry={action.carry_over_id} {action.source_step}->{action.target_step}: {action.instruction}"
            )
    return "\n".join(lines)


def gate_result_to_dict(result) -> dict[str, Any]:
    return {
        "decision": result.decision.value,
        "may_continue": result.may_continue,
        "failure_codes": [code.value for code in result.failure_codes],
        "repair_actions": [
            {
                "action": action.action,
                "finding_code": action.finding_code.value,
                "target_id": action.target_id,
                "source_step": action.source_step,
                "target_step": action.target_step,
                "instruction": action.instruction,
            }
            for action in result.repair_actions
        ],
        "active_assumptions": dict(result.active_assumptions),
        "decision_provenance": {
            "policy_id": result.provenance.policy_id,
            "policy_version": result.provenance.policy_version,
            "input_kind": result.provenance.input_kind,
            "rule": result.provenance.rule,
            "evaluated_finding_count": result.provenance.evaluated_finding_count,
        },
        "reason": result.reason,
    }


def render_gate_text(result) -> str:
    lines = [
        f"Agent semantic gate: {result.decision.value}",
        f"May continue: {'YES' if result.may_continue else 'NO'}",
        f"Failure codes: {','.join(code.value for code in result.failure_codes) if result.failure_codes else 'NONE'}",
        f"Policy: {result.provenance.policy_id}@{result.provenance.policy_version}",
        f"Decision rule: {result.provenance.rule}",
        f"Reason: {result.reason}",
    ]
    if result.repair_actions:
        lines.append(f"Repair actions: {len(result.repair_actions)}")
        for action in result.repair_actions:
            lines.append(f"{action.action} target={action.target_id}: {action.instruction}")
    else:
        lines.append("Repair actions: 0")
    return "\n".join(lines)


def benchmark_metrics_to_dict(metrics) -> dict[str, Any]:
    return {
        "total_cases": metrics.total_cases,
        "decision_accuracy": metrics.decision_accuracy,
        "block_recall": metrics.block_recall,
        "warn_recall": metrics.warn_recall,
        "defer_accuracy": metrics.defer_accuracy,
        "intervention_precision": metrics.intervention_precision,
        "intervention_recall": metrics.intervention_recall,
        "intervention_f1": metrics.intervention_f1,
        "failure_code_exact_accuracy": metrics.failure_code_exact_accuracy,
        "repair_action_exact_accuracy": metrics.repair_action_exact_accuracy,
        "confusion": {k: dict(v) for k, v in metrics.confusion.items()},
        "category_accuracy": dict(metrics.category_accuracy),
    }


def benchmark_run_to_dict(run) -> dict[str, Any]:
    return {
        "engine": run.engine,
        "metrics": benchmark_metrics_to_dict(run.metrics),
        "predictions": [
            {
                "case_id": prediction.case_id,
                "decision": prediction.decision.value,
                "failure_codes": list(prediction.failure_codes),
                "repair_actions": list(prediction.repair_actions),
            }
            for prediction in run.predictions
        ],
    }


def render_benchmark_text(run) -> str:
    m = run.metrics
    return "\n".join(
        [
            f"Benchmark engine: {run.engine}",
            f"Cases: {m.total_cases}",
        f"Elapsed seconds: {run.elapsed_seconds:.6f}",
        f"Mean case seconds: {run.mean_case_seconds:.6f}",
            f"Decision accuracy: {m.decision_accuracy:.4f}",
            f"BLOCK recall: {m.block_recall:.4f}",
            f"WARN recall: {m.warn_recall:.4f}",
            f"DEFER accuracy: {m.defer_accuracy:.4f}",
            f"Intervention precision: {m.intervention_precision:.4f}",
            f"Intervention recall: {m.intervention_recall:.4f}",
            f"Intervention F1: {m.intervention_f1:.4f}",
            f"Failure-code exact accuracy: {m.failure_code_exact_accuracy:.4f}",
            f"Repair-action exact accuracy: {m.repair_action_exact_accuracy:.4f}",
        ]
    )


def experiment_metrics_to_dict(metrics) -> dict[str, Any]:
    return {
        "total_cases": metrics.total_cases,
        "baseline_unsafe_accept_rate": metrics.baseline_unsafe_accept_rate,
        "gated_block_escape_rate": metrics.gated_block_escape_rate,
        "completion_rate": metrics.completion_rate,
        "intervention_rate": metrics.intervention_rate,
        "repair_attempt_rate": metrics.repair_attempt_rate,
        "repair_success_rate": metrics.repair_success_rate,
        "false_positive_rate": metrics.false_positive_rate,
        "defer_rate": metrics.defer_rate,
        "mean_extra_agent_steps": metrics.mean_extra_agent_steps,
        "gate_decision_accuracy": metrics.gate_decision_accuracy,
    }


def experiment_run_to_dict(run) -> dict[str, Any]:
    return {
        "provider_kind": run.provider_kind,
        "external_model_evidence": run.external_model_evidence,
        "max_repairs": run.max_repairs,
        "elapsed_seconds": run.elapsed_seconds,
        "mean_case_seconds": run.mean_case_seconds,
        "metrics": experiment_metrics_to_dict(run.metrics),
        "results": [
            {
                "case_id": r.case_id,
                "expected_decision": r.expected_decision.value,
                "initial_gate_decision": r.initial_gate_decision.value,
                "final_gate_decision": r.final_gate_decision.value,
                "baseline_accepted": r.baseline_accepted,
                "gated_accepted": r.gated_accepted,
                "repair_attempts": r.repair_attempts,
                "repair_success": r.repair_success,
                "false_positive": r.false_positive,
                "extra_agent_steps": r.extra_agent_steps,
                "initial_failure_codes": list(r.initial_failure_codes),
                "final_failure_codes": list(r.final_failure_codes),
                "repair_actions": list(r.repair_actions),
            }
            for r in run.results
        ],
    }


def render_experiment_text(run) -> str:
    m = run.metrics
    return "\n".join([
        f"Reference agent provider: {run.provider_kind}",
        f"External model evidence: {'YES' if run.external_model_evidence else 'NO'}",
        f"Cases: {m.total_cases}",
        f"Elapsed seconds: {run.elapsed_seconds:.6f}",
        f"Mean case seconds: {run.mean_case_seconds:.6f}",
        f"Baseline unsafe accept rate: {m.baseline_unsafe_accept_rate:.4f}",
        f"Gated block escape rate: {m.gated_block_escape_rate:.4f}",
        f"Completion rate: {m.completion_rate:.4f}",
        f"Intervention rate: {m.intervention_rate:.4f}",
        f"Repair attempt rate: {m.repair_attempt_rate:.4f}",
        f"Repair success rate: {m.repair_success_rate:.4f}",
        f"False positive rate: {m.false_positive_rate:.4f}",
        f"DEFER rate: {m.defer_rate:.4f}",
        f"Mean extra agent steps: {m.mean_extra_agent_steps:.4f}",
        f"Gate decision accuracy: {m.gate_decision_accuracy:.4f}",
    ])
