"""RSCT Semantic Analyzer Runtime MVP."""

__version__ = "0.2.0"
