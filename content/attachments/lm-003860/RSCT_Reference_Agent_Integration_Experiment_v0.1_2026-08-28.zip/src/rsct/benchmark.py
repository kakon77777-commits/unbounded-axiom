from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .gate import GateDecision


@dataclass(frozen=True)
class BenchmarkExpected:
    decision: GateDecision
    failure_codes: tuple[str, ...] = ()
    repair_actions: tuple[str, ...] = ()


@dataclass(frozen=True)
class BenchmarkCase:
    case_id: str
    category: str
    input_kind: str
    payload: Mapping[str, Any]
    expected: BenchmarkExpected
    tags: tuple[str, ...] = ()


@dataclass(frozen=True)
class BenchmarkPrediction:
    case_id: str
    decision: GateDecision
    failure_codes: tuple[str, ...] = ()
    repair_actions: tuple[str, ...] = ()


@dataclass(frozen=True)
class BenchmarkMetrics:
    total_cases: int
    decision_accuracy: float
    block_recall: float
    warn_recall: float
    defer_accuracy: float
    intervention_precision: float
    intervention_recall: float
    intervention_f1: float
    failure_code_exact_accuracy: float
    repair_action_exact_accuracy: float
    confusion: Mapping[str, Mapping[str, int]]
    category_accuracy: Mapping[str, float]


@dataclass(frozen=True)
class BenchmarkRun:
    engine: str
    predictions: tuple[BenchmarkPrediction, ...]
    metrics: BenchmarkMetrics


def _norm(values: Iterable[str]) -> tuple[str, ...]:
    return tuple(sorted(set(str(v) for v in values)))


def _safe_ratio(num: int, den: int) -> float:
    return num / den if den else 1.0


def load_benchmark_cases(path: str | Path) -> tuple[BenchmarkCase, ...]:
    path = Path(path)
    cases: list[BenchmarkCase] = []
    seen: set[str] = set()
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            record = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid benchmark JSONL at line {lineno}: {exc.msg}") from exc
        if not isinstance(record, dict):
            raise ValueError(f"benchmark line {lineno} must be a JSON object")
        case_id = str(record.get("case_id", ""))
        if not case_id:
            raise ValueError(f"benchmark case_id required at line {lineno}")
        if case_id in seen:
            raise ValueError(f"duplicate benchmark case id: {case_id}")
        seen.add(case_id)
        expected = record.get("expected")
        payload = record.get("payload")
        if not isinstance(expected, dict) or not isinstance(payload, dict):
            raise ValueError(f"benchmark case {case_id} requires payload and expected objects")
        try:
            decision = GateDecision(str(expected["decision"]))
        except (KeyError, ValueError) as exc:
            raise ValueError(f"benchmark case {case_id} has invalid expected decision") from exc
        input_kind = str(record.get("input_kind", ""))
        if input_kind not in {"contract", "reasoning_trace"}:
            raise ValueError(f"benchmark case {case_id} has invalid input_kind")
        category = str(record.get("category", ""))
        if not category:
            raise ValueError(f"benchmark case {case_id} category is required")
        cases.append(
            BenchmarkCase(
                case_id=case_id,
                category=category,
                input_kind=input_kind,
                payload=payload,
                expected=BenchmarkExpected(
                    decision=decision,
                    failure_codes=_norm(expected.get("failure_codes", [])),
                    repair_actions=_norm(expected.get("repair_actions", [])),
                ),
                tags=tuple(str(v) for v in record.get("tags", [])),
            )
        )
    return tuple(cases)


def load_predictions(path: str | Path) -> tuple[BenchmarkPrediction, ...]:
    path = Path(path)
    predictions: list[BenchmarkPrediction] = []
    seen: set[str] = set()
    for lineno, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        try:
            record = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError(f"invalid prediction JSONL at line {lineno}: {exc.msg}") from exc
        if not isinstance(record, dict):
            raise ValueError(f"prediction line {lineno} must be a JSON object")
        case_id = str(record.get("case_id", ""))
        if not case_id or case_id in seen:
            raise ValueError(f"duplicate or missing prediction case_id: {case_id}")
        seen.add(case_id)
        try:
            decision = GateDecision(str(record["decision"]))
        except (KeyError, ValueError) as exc:
            raise ValueError(f"prediction {case_id} has invalid decision") from exc
        predictions.append(
            BenchmarkPrediction(
                case_id=case_id,
                decision=decision,
                failure_codes=_norm(record.get("failure_codes", [])),
                repair_actions=_norm(record.get("repair_actions", [])),
            )
        )
    return tuple(predictions)


def score_predictions(
    cases: tuple[BenchmarkCase, ...],
    predictions: tuple[BenchmarkPrediction, ...],
) -> BenchmarkMetrics:
    expected_ids = {case.case_id for case in cases}
    if len(expected_ids) != len(cases):
        raise ValueError("duplicate benchmark case_id")
    pred_map = {prediction.case_id: prediction for prediction in predictions}
    if len(pred_map) != len(predictions):
        raise ValueError("duplicate prediction case_id")
    if expected_ids != set(pred_map):
        missing = sorted(expected_ids - set(pred_map))
        extra = sorted(set(pred_map) - expected_ids)
        raise ValueError(f"prediction coverage mismatch: missing={missing} extra={extra}")

    labels = [decision.value for decision in GateDecision]
    confusion = {expected: {predicted: 0 for predicted in labels} for expected in labels}
    decision_correct = code_correct = repair_correct = 0
    expected_block = expected_warn = expected_defer = 0
    correct_block = correct_warn = correct_defer = 0
    expected_interventions = predicted_interventions = true_interventions = 0
    category_total: dict[str, int] = {}
    category_correct: dict[str, int] = {}

    for case in cases:
        pred = pred_map[case.case_id]
        expected = case.expected
        confusion[expected.decision.value][pred.decision.value] += 1
        is_decision_correct = pred.decision is expected.decision
        decision_correct += int(is_decision_correct)
        code_correct += int(_norm(pred.failure_codes) == _norm(expected.failure_codes))
        repair_correct += int(_norm(pred.repair_actions) == _norm(expected.repair_actions))

        category_total[case.category] = category_total.get(case.category, 0) + 1
        category_correct[case.category] = category_correct.get(case.category, 0) + int(is_decision_correct)

        if expected.decision is GateDecision.BLOCK:
            expected_block += 1
            correct_block += int(pred.decision is GateDecision.BLOCK)
        if expected.decision is GateDecision.WARN:
            expected_warn += 1
            correct_warn += int(pred.decision is GateDecision.WARN)
        if expected.decision is GateDecision.DEFER:
            expected_defer += 1
            correct_defer += int(pred.decision is GateDecision.DEFER)

        expected_intervention = expected.decision in {GateDecision.BLOCK, GateDecision.WARN}
        predicted_intervention = pred.decision in {GateDecision.BLOCK, GateDecision.WARN}
        expected_interventions += int(expected_intervention)
        predicted_interventions += int(predicted_intervention)
        true_interventions += int(expected_intervention and predicted_intervention)

    precision = true_interventions / predicted_interventions if predicted_interventions else 0.0
    recall = true_interventions / expected_interventions if expected_interventions else 1.0
    f1 = 0.0 if precision + recall == 0 else 2 * precision * recall / (precision + recall)
    total = len(cases)
    return BenchmarkMetrics(
        total_cases=total,
        decision_accuracy=_safe_ratio(decision_correct, total),
        block_recall=_safe_ratio(correct_block, expected_block),
        warn_recall=_safe_ratio(correct_warn, expected_warn),
        defer_accuracy=_safe_ratio(correct_defer, expected_defer),
        intervention_precision=precision,
        intervention_recall=recall,
        intervention_f1=f1,
        failure_code_exact_accuracy=_safe_ratio(code_correct, total),
        repair_action_exact_accuracy=_safe_ratio(repair_correct, total),
        confusion=confusion,
        category_accuracy={
            category: _safe_ratio(category_correct.get(category, 0), count)
            for category, count in sorted(category_total.items())
        },
    )


def run_passthrough_baseline(cases: tuple[BenchmarkCase, ...]) -> BenchmarkRun:
    predictions = tuple(
        BenchmarkPrediction(case_id=case.case_id, decision=GateDecision.PASS)
        for case in cases
    )
    return BenchmarkRun(
        engine="passthrough",
        predictions=predictions,
        metrics=score_predictions(cases, predictions),
    )


def run_gate_benchmark(cases: tuple[BenchmarkCase, ...], middleware=None) -> BenchmarkRun:
    if middleware is None:
        from .middleware import RSCTSemanticMiddleware
        middleware = RSCTSemanticMiddleware()
    predictions: list[BenchmarkPrediction] = []
    for case in cases:
        gate = (
            middleware.gate_trace_contract(case.payload)
            if case.input_kind == "reasoning_trace"
            else middleware.gate_contract(case.payload)
        )
        predictions.append(
            BenchmarkPrediction(
                case_id=case.case_id,
                decision=gate.decision,
                failure_codes=_norm(code.value for code in gate.failure_codes),
                repair_actions=_norm(action.action for action in gate.repair_actions),
            )
        )
    result = tuple(predictions)
    return BenchmarkRun(
        engine="rsct-gate-v0.2",
        predictions=result,
        metrics=score_predictions(cases, result),
    )


def run_external_predictions(
    cases: tuple[BenchmarkCase, ...],
    predictions: tuple[BenchmarkPrediction, ...],
) -> BenchmarkRun:
    return BenchmarkRun(
        engine="external-predictions",
        predictions=predictions,
        metrics=score_predictions(cases, predictions),
    )
