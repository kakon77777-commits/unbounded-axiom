from __future__ import annotations

import re

from .model import AnalysisStatus, SourceSpan, SurfaceIR, SurfaceToken


def _token(token_id: str, surface: str, start: int, end: int, pos_hint: str | None = None) -> SurfaceToken:
    return SurfaceToken(token_id=token_id, surface=surface, span=SourceSpan(start, end), pos_hint=pos_hint)


def parse_surface(text: str, language: str = "zh-TW") -> SurfaceIR:
    if text == "這句話是假的。":
        return SurfaceIR(
            text=text,
            language=language,
            pattern="LIAR_CLASSICAL",
            tokens=(
                _token("t1", "這句話", 0, 3, "deictic-np"),
                _token("t2", "是假的", 3, 6, "predicate"),
            ),
            metadata={"self_reference_candidate": True, "false_predicate_candidate": True},
        )
    if text == "這句話是中文。":
        return SurfaceIR(
            text=text,
            language=language,
            pattern="SELF_LANGUAGE",
            tokens=(
                _token("t1", "這句話", 0, 3, "deictic-np"),
                _token("t2", "是中文", 3, 6, "predicate"),
            ),
            metadata={"self_reference_candidate": True},
        )
    match = re.fullmatch(r"「(.+)」是假的。", text)
    if match:
        quoted = match.group(1)
        quote_start = 1
        quote_end = 1 + len(quoted)
        return SurfaceIR(
            text=text,
            language=language,
            pattern="EXTERNAL_FALSE",
            tokens=(
                _token("t1", quoted, quote_start, quote_end, "quoted-sentence"),
                _token("t2", "是假的", quote_end + 1, quote_end + 4, "predicate"),
            ),
            metadata={"quoted": quoted, "false_predicate_candidate": True},
        )
    if text == "雪是白的。":
        return SurfaceIR(
            text=text,
            language=language,
            pattern="SIMPLE_FACT",
            tokens=(
                _token("t1", "雪", 0, 1, "entity"),
                _token("t2", "是白的", 1, 4, "predicate"),
            ),
            metadata={"truth_bearer_candidate": True},
        )
    if text == "他說過謊，所以他就是永遠的說謊者。":
        liar_surface = "說謊者"
        liar_start = text.index(liar_surface)
        return SurfaceIR(
            text=text,
            language=language,
            pattern="ROLE_REIFICATION",
            tokens=(
                _token("t1", "說過謊", text.index("說過謊"), text.index("說過謊") + len("說過謊"), "act-rel"),
                _token("t2", liar_surface, liar_start, liar_start + len(liar_surface), "role"),
            ),
            metadata={"reification_candidate": True},
        )
    if text == "A 照顧 B，但 B 管理 A。":
        return SurfaceIR(
            text=text,
            language=language,
            pattern="BIDIRECTIONAL_HETEROGENEOUS",
            tokens=(
                _token("t1", "A", 0, 1, "entity"),
                _token("t2", "照顧", text.index("照顧"), text.index("照顧") + 2, "relation"),
                _token("t3", "B", text.index("B"), text.index("B") + 1, "entity"),
                _token("t4", "管理", text.index("管理"), text.index("管理") + 2, "relation"),
            ),
            metadata={"bidirectional_candidate": True, "heterogeneous_candidate": True},
        )
    if text == "有研究支持 P，也有研究反對 P。":
        return SurfaceIR(
            text=text,
            language=language,
            pattern="EVIDENCE_CONFLICT",
            tokens=(
                _token("t1", "支持", text.index("支持"), text.index("支持") + 2, "evidence-positive"),
                _token("t2", "反對", text.index("反對"), text.index("反對") + 2, "evidence-negative"),
                _token("t3", "P", text.index("P"), text.index("P") + 1, "proposition-symbol"),
            ),
            metadata={"evidence_positive": True, "evidence_negative": True},
        )
    return SurfaceIR(
        text=text,
        language=language,
        pattern="UNSUPPORTED",
        status=AnalysisStatus.PARTIAL,
        tokens=(),
        metadata={"reason": "no controlled v0.1 parser rule matched"},
    )
