from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .model import AnalysisStatus, FailureCode


class SymbolicTensionState(str, Enum):
    ALIGNED = "ALIGNED"
    OPPOSED = "OPPOSED"
    PARTIAL = "PARTIAL"
    UNDEFINED = "UNDEFINED"
    INCOMPARABLE = "INCOMPARABLE"


class SymbolicTensionAdapter:
    """MVP symbolic adapter; intentionally does not claim metric or boundary semantics."""

    _MAP = {
        "aligned": SymbolicTensionState.ALIGNED,
        "opposed": SymbolicTensionState.OPPOSED,
        "partial": SymbolicTensionState.PARTIAL,
        "undefined": SymbolicTensionState.UNDEFINED,
        "incomparable": SymbolicTensionState.INCOMPARABLE,
    }

    def derive_tension_state(self, relation_state: str) -> SymbolicTensionState:
        return self._MAP.get(relation_state.strip().lower(), SymbolicTensionState.UNDEFINED)

    def supports_metric(self) -> bool:
        return False

    def supports_boundary(self) -> bool:
        return False


@dataclass(frozen=True)
class BoundaryAnalysisResult:
    status: AnalysisStatus
    failure: FailureCode | None
    explanation: str


class BoundaryAnalyzer:
    def analyze(self, adapter: SymbolicTensionAdapter) -> BoundaryAnalysisResult:
        if not adapter.supports_boundary():
            return BoundaryAnalysisResult(
                status=AnalysisStatus.UNKNOWN,
                failure=FailureCode.BOUNDARY_UNDEFINED,
                explanation="Boundary semantics are not defined by the active tension adapter.",
            )
        return BoundaryAnalysisResult(
            status=AnalysisStatus.PASS,
            failure=None,
            explanation="Boundary semantics are available.",
        )
