from __future__ import annotations

from copy import deepcopy
from typing import Any, Mapping

from .benchmark import BenchmarkCase
from .experiment import AgentAttempt


def _safe_contract(case_id: str, attempt_index: int) -> dict[str, Any]:
    suffix = f"{case_id}-{attempt_index}"
    return {
        "version": "0.1",
        "nodes": [
            {"id": f"e-{suffix}", "type": "EvidenceState", "provenance": "scripted-repair"},
            {"id": f"c-{suffix}", "type": "Claim", "provenance": "scripted-repair"},
            {"id": f"v-{suffix}", "type": "Evaluation", "provenance": "scripted-repair"},
            {"id": f"t-{suffix}", "type": "TruthValueLabel", "provenance": "scripted-repair"},
        ],
        "edges": [
            {"id": f"ec-{suffix}", "source": f"e-{suffix}", "target": f"c-{suffix}", "type": "CONSTRUCTION"},
            {"id": f"cv-{suffix}", "source": f"c-{suffix}", "target": f"v-{suffix}", "type": "EVALUATION"},
            {"id": f"vt-{suffix}", "source": f"v-{suffix}", "target": f"t-{suffix}", "type": "EVALUATION"},
        ],
    }


def _safe_trace(case_id: str, attempt_index: int) -> dict[str, Any]:
    return {
        "version": "0.1",
        "trace_id": f"scripted-repair-{case_id}-{attempt_index}",
        "steps": [
            {
                "id": "repaired-step",
                "contract": _safe_contract(case_id, attempt_index),
            }
        ],
        "carry_over": [],
    }


class ScriptedReferenceAgent:
    provider_kind = "scripted-reference-agent"
    external_model_evidence = False

    def initial(self, case: BenchmarkCase) -> AgentAttempt:
        return AgentAttempt(
            case_id=case.case_id,
            attempt_index=0,
            payload=deepcopy(dict(case.payload)),
            provider_kind=self.provider_kind,
            provenance="canonical-case-payload",
        )

    def repair(
        self,
        case: BenchmarkCase,
        prior_attempt: AgentAttempt,
        repair_actions: tuple[str, ...],
    ) -> AgentAttempt:
        index = prior_attempt.attempt_index + 1
        payload = _safe_trace(case.case_id, index) if case.input_kind == "reasoning_trace" else _safe_contract(case.case_id, index)
        return AgentAttempt(
            case_id=case.case_id,
            attempt_index=index,
            payload=payload,
            provider_kind=self.provider_kind,
            provenance="scripted-repair:" + ",".join(repair_actions),
        )

class ReplayReferenceAgent:
    external_model_evidence = True

    def __init__(self, records: Mapping[str, Mapping[str, Any]], provider_kind: str = "replay-provider") -> None:
        self._records = {str(k): deepcopy(dict(v)) for k, v in records.items()}
        self.provider_kind = provider_kind

    @classmethod
    def from_jsonl(cls, path, *, expected_case_ids: set[str] | None = None) -> "ReplayReferenceAgent":
        import json
        from pathlib import Path

        records: dict[str, dict[str, Any]] = {}
        providers: set[str] = set()
        for lineno, raw in enumerate(Path(path).read_text(encoding="utf-8").splitlines(), start=1):
            if not raw.strip():
                continue
            try:
                record = json.loads(raw)
            except json.JSONDecodeError as exc:
                raise ValueError(f"invalid replay JSONL at line {lineno}: {exc.msg}") from exc
            if not isinstance(record, dict):
                raise ValueError(f"replay line {lineno} must be a JSON object")
            case_id = str(record.get("case_id", ""))
            if not case_id or case_id in records:
                raise ValueError(f"duplicate or missing replay case_id: {case_id}")
            initial = record.get("initial")
            repairs = record.get("repairs", [])
            if not isinstance(initial, dict) or not isinstance(repairs, list) or not all(isinstance(v, dict) for v in repairs):
                raise ValueError(f"replay case {case_id} requires initial object and repairs list")
            records[case_id] = {"initial": initial, "repairs": repairs}
            provider = record.get("provider")
            if provider:
                providers.add(str(provider))
        if expected_case_ids is not None and set(records) != set(expected_case_ids):
            missing = sorted(set(expected_case_ids) - set(records))
            extra = sorted(set(records) - set(expected_case_ids))
            raise ValueError(f"replay coverage mismatch: missing={missing} extra={extra}")
        provider_kind = next(iter(providers)) if len(providers) == 1 else "external-replay"
        return cls(records, provider_kind=provider_kind)

    def initial(self, case: BenchmarkCase) -> AgentAttempt:
        try:
            payload = self._records[case.case_id]["initial"]
        except KeyError as exc:
            raise ValueError(f"missing replay case: {case.case_id}") from exc
        return AgentAttempt(
            case_id=case.case_id,
            attempt_index=0,
            payload=deepcopy(payload),
            provider_kind=self.provider_kind,
            provenance="external-replay:initial",
        )

    def repair(
        self,
        case: BenchmarkCase,
        prior_attempt: AgentAttempt,
        repair_actions: tuple[str, ...],
    ) -> AgentAttempt:
        index = prior_attempt.attempt_index
        repairs = self._records[case.case_id]["repairs"]
        if index >= len(repairs):
            raise ValueError(f"missing replay repair attempt {index + 1} for case {case.case_id}")
        return AgentAttempt(
            case_id=case.case_id,
            attempt_index=index + 1,
            payload=deepcopy(repairs[index]),
            provider_kind=self.provider_kind,
            provenance=f"external-replay:repair-{index + 1}",
        )
