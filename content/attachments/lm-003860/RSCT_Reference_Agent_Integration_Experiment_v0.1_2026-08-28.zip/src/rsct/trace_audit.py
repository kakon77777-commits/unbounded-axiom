from __future__ import annotations

from dataclasses import dataclass

from .audit import AISemanticAuditResult, AuditSeverity, audit_ai_graph
from .model import FailureCode, SemanticType
from .trace import ReasoningTrace


@dataclass(frozen=True)
class CrossStepFinding:
    code: FailureCode
    severity: AuditSeverity
    carry_over_id: str
    source_step: str
    source_node: str
    target_step: str
    target_node: str
    message: str
    repair_hint: str


@dataclass(frozen=True)
class ReasoningTraceAuditResult:
    trace: ReasoningTrace
    step_audits: tuple[tuple[str, AISemanticAuditResult], ...]
    cross_step_findings: tuple[CrossStepFinding, ...]

    @property
    def failure_codes(self) -> tuple[FailureCode, ...]:
        codes: list[FailureCode] = []
        for _, audit in self.step_audits:
            codes.extend(audit.failure_codes)
        codes.extend(f.code for f in self.cross_step_findings)
        return tuple(codes)

    @property
    def passed(self) -> bool:
        step_errors = any(not audit.passed for _, audit in self.step_audits)
        cross_errors = any(f.severity is AuditSeverity.ERROR for f in self.cross_step_findings)
        return not step_errors and not cross_errors


def audit_reasoning_trace(trace: ReasoningTrace) -> ReasoningTraceAuditResult:
    step_audits = tuple((step.step_id, audit_ai_graph(step.contract)) for step in trace.steps)
    node_maps = {
        step.step_id: {node.node_id: node for node in step.contract.nodes}
        for step in trace.steps
    }
    findings: list[CrossStepFinding] = []

    for carry in trace.carry_over:
        source = node_maps[carry.source_step][carry.source_node]
        target = node_maps[carry.target_step][carry.target_node]
        pair = (source.semantic_type, target.semantic_type)

        if pair == (SemanticType.EVIDENCE_STATE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_EVIDENCE_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "Evidence crossed reasoning steps and became a truth label without evaluation.",
                    "Preserve the carried item as Evidence/Claim and insert an explicit Evaluation before truth projection.",
                )
            )
        elif pair == (SemanticType.MEMORY_RECORD, SemanticType.BELIEF_STATE):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_MEMORY_BELIEF_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "A historical memory record became a current belief-like state across reasoning steps.",
                    "Retrieve memory as historical input and require current re-evaluation before forming BeliefState.",
                )
            )
        elif pair == (SemanticType.INFERENCE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_INFERENCE_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "An inference result became a truth label across reasoning steps without an evaluation contract.",
                    "Preserve the inference result as a Claim with premise provenance, then evaluate it explicitly.",
                )
            )
        elif pair == (SemanticType.CLAIM, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_CLAIM_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "A claim became a truth label across reasoning steps without explicit evaluation.",
                    "Insert an explicit Evaluation step between the carried Claim and TruthValueLabel.",
                )
            )
        elif pair == (SemanticType.BELIEF_STATE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_BELIEF_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "A belief-like state became a truth label across reasoning steps.",
                    "Preserve the holder/provenance of the BeliefState, render its content as a Claim, then evaluate that Claim separately.",
                )
            )
        elif pair == (SemanticType.OBSERVATION, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_OBSERVATION_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "An observation became a truth label across reasoning steps without evaluation.",
                    "Preserve Observation as evidence/input, form a Claim, then evaluate before truth projection.",
                )
            )
        elif pair == (SemanticType.ROLE, SemanticType.IDENTITY):
            findings.append(
                CrossStepFinding(
                    FailureCode.AI_TRACE_ROLE_IDENTITY_ESCALATION,
                    AuditSeverity.WARNING,
                    carry.carry_over_id,
                    carry.source_step,
                    carry.source_node,
                    carry.target_step,
                    carry.target_node,
                    "A scoped role persisted across reasoning steps as identity.",
                    "Keep the carried semantic object typed as Role unless an explicit scoped reification contract is supplied.",
                )
            )

    return ReasoningTraceAuditResult(
        trace=trace,
        step_audits=step_audits,
        cross_step_findings=tuple(findings),
    )
