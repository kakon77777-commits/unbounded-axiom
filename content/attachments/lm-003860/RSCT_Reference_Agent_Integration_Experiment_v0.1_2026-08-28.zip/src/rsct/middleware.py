from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .ai_contract import contract_to_graph, load_ai_contract
from .audit import AISemanticAuditResult, audit_ai_graph
from .trace import reasoning_trace_from_payload, load_reasoning_trace
from .trace_audit import ReasoningTraceAuditResult, audit_reasoning_trace
from .gate import (
    GateResult,
    deferred_gate_result,
    gate_single_audit,
    gate_trace_audit,
)


class RSCTSemanticMiddleware:
    """Deterministic AI-facing semantic audit entry point."""

    def audit_contract(self, payload: Mapping[str, Any]) -> AISemanticAuditResult:
        return audit_ai_graph(contract_to_graph(payload))

    def audit_json(self, text: str) -> AISemanticAuditResult:
        return self.audit_contract(load_ai_contract(text))

    def audit_trace_contract(self, payload: Mapping[str, Any]) -> ReasoningTraceAuditResult:
        return audit_reasoning_trace(reasoning_trace_from_payload(payload))

    def audit_trace_json(self, text: str) -> ReasoningTraceAuditResult:
        return audit_reasoning_trace(load_reasoning_trace(text))

    def gate_contract(self, payload: Mapping[str, Any]) -> GateResult:
        try:
            audit = self.audit_contract(payload)
        except ValueError as exc:
            return deferred_gate_result(input_kind="contract", reason=str(exc))
        return gate_single_audit(audit)

    def gate_trace_contract(self, payload: Mapping[str, Any]) -> GateResult:
        try:
            audit = self.audit_trace_contract(payload)
        except ValueError as exc:
            return deferred_gate_result(input_kind="reasoning_trace", reason=str(exc))
        return gate_trace_audit(audit)

    def gate(self, payload: Mapping[str, Any]) -> GateResult:
        if "steps" in payload or "trace_id" in payload:
            return self.gate_trace_contract(payload)
        return self.gate_contract(payload)
