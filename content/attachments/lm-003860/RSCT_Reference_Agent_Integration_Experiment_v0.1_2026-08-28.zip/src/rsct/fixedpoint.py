from __future__ import annotations

from collections.abc import Mapping

from .model import AnalysisStatus, FixedPointResult


def classical_bivalent_negation() -> dict[str, str]:
    return {"T": "F", "F": "T"}


def _canonical_cycle(cycle: tuple[str, ...]) -> tuple[str, ...]:
    if not cycle:
        return cycle
    rotations = [cycle[i:] + cycle[:i] for i in range(len(cycle))]
    return min(rotations)


def analyze_finite_map(
    domain: tuple[str, ...], mapping: Mapping[str, str]
) -> FixedPointResult:
    domain_set = set(domain)
    if set(mapping) != domain_set or any(value not in domain_set for value in mapping.values()):
        raise ValueError("mapping must be total on the supplied finite domain")

    fixed_points = tuple(value for value in domain if mapping[value] == value)
    cycles_seen: set[tuple[str, ...]] = set()

    for start in domain:
        path: list[str] = []
        positions: dict[str, int] = {}
        current = start
        while current not in positions:
            positions[current] = len(path)
            path.append(current)
            current = mapping[current]
        cycle = tuple(path[positions[current] :])
        if len(cycle) > 1:
            cycles_seen.add(_canonical_cycle(cycle))

    status = (
        AnalysisStatus.FIXED_POINT_FOUND
        if fixed_points
        else AnalysisStatus.NO_FIXED_POINT
    )
    equation = "v = N(v)" if dict(mapping) == classical_bivalent_negation() else None
    explanation = (
        "No fixed point exists in the active finite domain."
        if not fixed_points
        else f"Fixed points: {', '.join(fixed_points)}"
    )
    return FixedPointResult(
        status=status,
        fixed_points=fixed_points,
        cycles=tuple(sorted(cycles_seen)),
        equation=equation,
        explanation=explanation,
    )
