from __future__ import annotations

from .model import (
    SemanticEdge,
    SemanticGraphIR,
    SemanticNode,
    SemanticType,
    SourceSpan,
    SurfaceIR,
)


def _span_of(surface: SurfaceIR, token_index: int) -> SourceSpan | None:
    if 0 <= token_index < len(surface.tokens):
        return surface.tokens[token_index].span
    return None


def build_semantic_graph(surface: SurfaceIR) -> SemanticGraphIR:
    p = surface.pattern
    if p == "LIAR_CLASSICAL":
        nodes = (
            SemanticNode("sentence:self", SemanticType.SENTENCE_TOKEN, surface.text, SourceSpan(0, len(surface.text))),
            SemanticNode("deictic:self", SemanticType.DEICTIC, "這句話", _span_of(surface, 0), inferred=False),
            SemanticNode("proposition:self", SemanticType.PROPOSITION, surface.text, inferred=True),
            SemanticNode("truthbearer:self", SemanticType.TRUTH_BEARER, surface.text, inferred=True),
            SemanticNode("falsepred:self", SemanticType.FALSE_PREDICATE, "是假的", _span_of(surface, 1), inferred=True),
        )
        edges = (
            SemanticEdge("e:interp", "sentence:self", "proposition:self", "CONSTRUCTION", operator="INTERP"),
            SemanticEdge("e:contains-deictic", "proposition:self", "deictic:self", "CONTAINS"),
            SemanticEdge("e:ref", "deictic:self", "sentence:self", "REFERENCE", operator="REF"),
            SemanticEdge("e:truthbearer", "proposition:self", "truthbearer:self", "TYPE_COERCION", operator="TB"),
            SemanticEdge("e:falsepred-node", "falsepred:self", "proposition:self", "CONSTRUCTS", operator="FALSE_PRED"),
            SemanticEdge("e:falsepred-apply", "truthbearer:self", "proposition:self", "CONSTRUCTION", operator="FALSE_PRED"),
        )
        traces = (
            {
                "operator": "INTERP",
                "inputs": ["sentence:self"],
                "output": "proposition:self",
                "output_type": SemanticType.PROPOSITION.value,
            },
            {
                "operator": "FALSE_PRED",
                "inputs": ["truthbearer:self"],
                "output": "proposition:self",
                "output_type": SemanticType.PROPOSITION.value,
            },
        )
        return SemanticGraphIR(nodes=nodes, edges=edges, construction_traces=traces)

    if p == "SELF_LANGUAGE":
        nodes = (
            SemanticNode("sentence:self", SemanticType.SENTENCE_TOKEN, surface.text, SourceSpan(0, len(surface.text))),
            SemanticNode("deictic:self", SemanticType.DEICTIC, "這句話", _span_of(surface, 0)),
            SemanticNode("proposition:self", SemanticType.PROPOSITION, surface.text, inferred=True),
            SemanticNode("truthbearer:self", SemanticType.TRUTH_BEARER, surface.text, inferred=True),
        )
        edges = (
            SemanticEdge("e:interp", "sentence:self", "proposition:self", "CONSTRUCTION", operator="INTERP"),
            SemanticEdge("e:contains-deictic", "proposition:self", "deictic:self", "CONTAINS"),
            SemanticEdge("e:ref", "deictic:self", "sentence:self", "REFERENCE", operator="REF"),
            SemanticEdge("e:truthbearer", "proposition:self", "truthbearer:self", "TYPE_COERCION", operator="TB"),
        )
        return SemanticGraphIR(nodes=nodes, edges=edges)

    if p == "EXTERNAL_FALSE":
        quoted = str(surface.metadata.get("quoted", ""))
        nodes = (
            SemanticNode("sentence:outer", SemanticType.SENTENCE_TOKEN, surface.text, SourceSpan(0, len(surface.text))),
            SemanticNode("sentence:quoted", SemanticType.SENTENCE_TOKEN, quoted, _span_of(surface, 0)),
            SemanticNode("truthbearer:quoted", SemanticType.TRUTH_BEARER, quoted, inferred=True),
            SemanticNode("falsepred:outer", SemanticType.FALSE_PREDICATE, "是假的", _span_of(surface, 1), inferred=True),
            SemanticNode("proposition:outer", SemanticType.PROPOSITION, surface.text, inferred=True),
        )
        edges = (
            SemanticEdge("e:quoted-tb", "sentence:quoted", "truthbearer:quoted", "TYPE_COERCION", operator="TB"),
            SemanticEdge("e:falsepred", "truthbearer:quoted", "proposition:outer", "CONSTRUCTION", operator="FALSE_PRED"),
            SemanticEdge("e:outer-interp", "sentence:outer", "proposition:outer", "CONSTRUCTION", operator="INTERP"),
        )
        return SemanticGraphIR(nodes=nodes, edges=edges)

    if p == "ROLE_REIFICATION":
        nodes = (
            SemanticNode("act:lie", SemanticType.ACT_REL, "說過謊", _span_of(surface, 0)),
            SemanticNode("role:liar", SemanticType.ROLE, "說謊者", _span_of(surface, 1), inferred=True),
            SemanticNode("identity:liar", SemanticType.IDENTITY, "永遠的說謊者", inferred=True),
        )
        edges = (
            SemanticEdge("e:agentize", "act:lie", "role:liar", "CONSTRUCTION", operator="AGENTIZE"),
            SemanticEdge("e:reify", "role:liar", "identity:liar", "ROLE_REIFICATION", operator="REIFY"),
        )
        return SemanticGraphIR(
            nodes=nodes,
            edges=edges,
            construction_traces=(
                {"operator": "AGENTIZE", "inputs": ["act:lie"], "output": "role:liar"},
                {"operator": "REIFY", "inputs": ["role:liar"], "output": "identity:liar"},
            ),
            warnings=("role-to-identity escalation",),
        )

    if p == "BIDIRECTIONAL_HETEROGENEOUS":
        nodes = (
            SemanticNode("entity:A", SemanticType.ENTITY, "A"),
            SemanticNode("entity:B", SemanticType.ENTITY, "B"),
        )
        edges = (
            SemanticEdge("e:care", "entity:A", "entity:B", "RELATION", operator="CARE"),
            SemanticEdge("e:manage", "entity:B", "entity:A", "RELATION", operator="MANAGE"),
        )
        return SemanticGraphIR(nodes=nodes, edges=edges, warnings=("bidirectional does not imply symmetry",))

    if p == "EVIDENCE_CONFLICT":
        nodes = (
            SemanticNode("proposition:P", SemanticType.PROPOSITION, "P"),
            SemanticNode("evidence:+", SemanticType.EVIDENCE_STATE, "支持", _span_of(surface, 0)),
            SemanticNode("evidence:-", SemanticType.EVIDENCE_STATE, "反對", _span_of(surface, 1)),
        )
        edges = (
            SemanticEdge("e:support", "evidence:+", "proposition:P", "EVIDENCE_SUPPORT"),
            SemanticEdge("e:oppose", "evidence:-", "proposition:P", "EVIDENCE_OPPOSE"),
        )
        return SemanticGraphIR(nodes=nodes, edges=edges, warnings=("evidence polarity is not truth polarity",))

    if p == "SIMPLE_FACT":
        nodes = (
            SemanticNode("sentence:fact", SemanticType.SENTENCE_TOKEN, surface.text, SourceSpan(0, len(surface.text))),
            SemanticNode("proposition:fact", SemanticType.PROPOSITION, surface.text, inferred=True),
            SemanticNode("truthbearer:fact", SemanticType.TRUTH_BEARER, surface.text, inferred=True),
        )
        edges = (
            SemanticEdge("e:fact-interp", "sentence:fact", "proposition:fact", "CONSTRUCTION", operator="INTERP"),
            SemanticEdge("e:fact-tb", "proposition:fact", "truthbearer:fact", "TYPE_COERCION", operator="TB"),
        )
        return SemanticGraphIR(nodes=nodes, edges=edges)

    return SemanticGraphIR(warnings=("unsupported controlled semantic pattern",))
