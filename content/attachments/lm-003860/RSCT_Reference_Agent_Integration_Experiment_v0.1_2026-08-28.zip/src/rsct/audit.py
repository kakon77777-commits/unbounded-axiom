from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .model import FailureCode, SemanticGraphIR, SemanticType


class AuditSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"


@dataclass(frozen=True)
class AuditFinding:
    code: FailureCode
    severity: AuditSeverity
    edge_id: str
    message: str
    repair_hint: str


@dataclass(frozen=True)
class AISemanticAuditResult:
    graph: SemanticGraphIR
    findings: tuple[AuditFinding, ...]

    @property
    def failure_codes(self) -> tuple[FailureCode, ...]:
        return tuple(f.code for f in self.findings)

    @property
    def passed(self) -> bool:
        return not any(f.severity is AuditSeverity.ERROR for f in self.findings)


def audit_ai_graph(graph: SemanticGraphIR) -> AISemanticAuditResult:
    node_map = {node.node_id: node for node in graph.nodes}
    findings: list[AuditFinding] = []

    for edge in graph.edges:
        source = node_map[edge.source]
        target = node_map[edge.target]
        pair = (source.semantic_type, target.semantic_type)

        if pair == (SemanticType.EVIDENCE_STATE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                AuditFinding(
                    FailureCode.AI_EVIDENCE_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "Evidence was coerced directly into a truth label.",
                    "Preserve Evidence -> Claim -> Evaluation -> TruthValueLabel with an explicit evaluation contract.",
                )
            )
        elif pair == (SemanticType.BELIEF_STATE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                AuditFinding(
                    FailureCode.AI_BELIEF_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "A belief-like state was coerced directly into a truth label.",
                    "Render the belief as a Claim, preserve its holder/provenance, then evaluate the claim separately.",
                )
            )
        elif pair == (SemanticType.CLAIM, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                AuditFinding(
                    FailureCode.AI_CLAIM_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "A claim was coerced directly into a truth label.",
                    "Insert an explicit Evaluation node and truth-projection contract between Claim and TruthValueLabel.",
                )
            )
        elif pair == (SemanticType.INFERENCE, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                AuditFinding(
                    FailureCode.AI_INFERENCE_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "An inference output was coerced directly into a truth label.",
                    "Render the inference output as a Claim, preserve its premises/provenance, then evaluate it under an explicit contract.",
                )
            )
        elif pair == (SemanticType.OBSERVATION, SemanticType.TRUTH_VALUE_LABEL):
            findings.append(
                AuditFinding(
                    FailureCode.AI_OBSERVATION_TRUTH_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "An observation was coerced directly into a truth label.",
                    "Preserve Observation as evidence/input, then pass it through Claim and Evaluation before truth projection.",
                )
            )
        elif pair == (SemanticType.MEMORY_RECORD, SemanticType.BELIEF_STATE):
            findings.append(
                AuditFinding(
                    FailureCode.AI_MEMORY_BELIEF_COLLAPSE,
                    AuditSeverity.ERROR,
                    edge.edge_id,
                    "A stored memory record was silently promoted to a current belief-like state.",
                    "Retrieve the MemoryRecord as historical evidence/claim input, then require current re-evaluation before forming a BeliefState.",
                )
            )
        elif pair == (SemanticType.ROLE, SemanticType.IDENTITY) or edge.edge_type == "ROLE_REIFICATION":
            findings.append(
                AuditFinding(
                    FailureCode.AI_ROLE_IDENTITY_ESCALATION,
                    AuditSeverity.WARNING,
                    edge.edge_id,
                    "A local role was escalated toward identity.",
                    "Keep Role separate from Identity unless an explicit reification contract and scope justification are supplied.",
                )
            )

        if edge.edge_type == "PROJECTION" and "lossy" not in edge.projection:
            findings.append(
                AuditFinding(
                    FailureCode.PROJECTION_UNDECLARED_LOSS,
                    AuditSeverity.WARNING,
                    edge.edge_id,
                    "A projection edge does not declare whether it is lossy.",
                    "Declare projection.lossy explicitly and preserve any known lost dimensions in provenance metadata.",
                )
            )

    return AISemanticAuditResult(graph=graph, findings=tuple(findings))
