from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping

from .ai_contract import contract_to_graph
from .model import SemanticGraphIR


@dataclass(frozen=True)
class ReasoningStep:
    step_id: str
    contract: SemanticGraphIR


@dataclass(frozen=True)
class CarryOverRef:
    carry_over_id: str
    source_step: str
    source_node: str
    target_step: str
    target_node: str
    relation: str


@dataclass(frozen=True)
class ReasoningTrace:
    trace_id: str
    steps: tuple[ReasoningStep, ...]
    carry_over: tuple[CarryOverRef, ...]


def load_reasoning_trace(text: str) -> ReasoningTrace:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON reasoning trace: {exc.msg}") from exc
    if not isinstance(payload, dict):
        raise ValueError("reasoning trace must be a JSON object")
    return reasoning_trace_from_payload(payload)


def reasoning_trace_from_payload(payload: Mapping[str, Any]) -> ReasoningTrace:
    if payload.get("version") != "0.1":
        raise ValueError("unsupported reasoning trace version")
    trace_id = payload.get("trace_id")
    if not isinstance(trace_id, str) or not trace_id:
        raise ValueError("trace_id is required")
    raw_steps = payload.get("steps")
    raw_carry = payload.get("carry_over", [])
    if not isinstance(raw_steps, list) or not isinstance(raw_carry, list):
        raise ValueError("steps and carry_over must be lists")

    steps: list[ReasoningStep] = []
    step_ids: set[str] = set()
    node_ids_by_step: dict[str, set[str]] = {}
    for raw in raw_steps:
        if not isinstance(raw, dict):
            raise ValueError("each reasoning step must be an object")
        step_id = raw.get("id")
        if not isinstance(step_id, str) or not step_id:
            raise ValueError("step id is required")
        if step_id in step_ids:
            raise ValueError(f"duplicate step id: {step_id}")
        contract = raw.get("contract")
        if not isinstance(contract, dict):
            raise ValueError(f"step contract is required: {step_id}")
        graph = contract_to_graph(contract)
        steps.append(ReasoningStep(step_id=step_id, contract=graph))
        step_ids.add(step_id)
        node_ids_by_step[step_id] = {node.node_id for node in graph.nodes}

    carry: list[CarryOverRef] = []
    carry_ids: set[str] = set()
    for raw in raw_carry:
        if not isinstance(raw, dict):
            raise ValueError("each carry_over entry must be an object")
        required = ("id", "source_step", "source_node", "target_step", "target_node", "relation")
        for field in required:
            if not isinstance(raw.get(field), str) or not raw.get(field):
                raise ValueError(f"carry_over {field} is required")
        carry_id = raw["id"]
        if carry_id in carry_ids:
            raise ValueError(f"duplicate carry_over id: {carry_id}")
        source_step = raw["source_step"]
        target_step = raw["target_step"]
        if source_step not in step_ids:
            raise ValueError(f"unknown source step: {source_step}")
        if target_step not in step_ids:
            raise ValueError(f"unknown target step: {target_step}")
        if raw["source_node"] not in node_ids_by_step[source_step]:
            raise ValueError(f"unknown source node: {raw['source_node']}")
        if raw["target_node"] not in node_ids_by_step[target_step]:
            raise ValueError(f"unknown target node: {raw['target_node']}")
        carry.append(
            CarryOverRef(
                carry_over_id=carry_id,
                source_step=source_step,
                source_node=raw["source_node"],
                target_step=target_step,
                target_node=raw["target_node"],
                relation=raw["relation"],
            )
        )
        carry_ids.add(carry_id)

    return ReasoningTrace(trace_id=trace_id, steps=tuple(steps), carry_over=tuple(carry))
