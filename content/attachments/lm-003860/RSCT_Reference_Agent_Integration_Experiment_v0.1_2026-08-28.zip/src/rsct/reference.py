from __future__ import annotations

from .model import SemanticGraphIR


def _find_cycle_with_reference(graph: SemanticGraphIR) -> list[str] | None:
    adjacency: dict[str, list[tuple[str, str]]] = {}
    for edge in graph.edges:
        adjacency.setdefault(edge.source, []).append((edge.target, edge.edge_type))

    nodes = [node.node_id for node in graph.nodes]
    for start in nodes:
        stack: list[tuple[str, list[str], bool]] = [(start, [start], False)]
        while stack:
            current, path, has_reference = stack.pop()
            for target, edge_type in adjacency.get(current, []):
                next_has_reference = has_reference or edge_type == "REFERENCE"
                if target == start and len(path) >= 2 and next_has_reference:
                    return path + [start]
                if target not in path and len(path) <= len(nodes):
                    stack.append((target, path + [target], next_has_reference))
    return None


def classify_self_reference(graph: SemanticGraphIR) -> dict[str, object]:
    cycle = _find_cycle_with_reference(graph)
    if cycle is None:
        return {"detected": False, "kind": "NONE", "path": []}
    return {
        "detected": True,
        "kind": "PATH_GENERATED_SELF_REFERENCE",
        "path": cycle,
    }
