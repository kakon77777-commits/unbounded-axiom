from __future__ import annotations

import json
from collections.abc import Mapping
from typing import Any

from .model import SemanticEdge, SemanticGraphIR, SemanticNode, SemanticType


def load_ai_contract(text: str) -> dict[str, Any]:
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"invalid JSON contract: {exc.msg}") from exc
    if not isinstance(payload, dict):
        raise ValueError("AI semantic contract must be a JSON object")
    _validate_contract(payload)
    return payload


def _validate_contract(payload: Mapping[str, Any]) -> None:
    if payload.get("version") != "0.1":
        raise ValueError("unsupported AI semantic contract version")
    nodes = payload.get("nodes")
    edges = payload.get("edges")
    if not isinstance(nodes, list) or not isinstance(edges, list):
        raise ValueError("contract nodes and edges must be lists")

    ids: set[str] = set()
    for node in nodes:
        if not isinstance(node, dict):
            raise ValueError("each node must be an object")
        for field in ("id", "type", "provenance"):
            if not node.get(field):
                raise ValueError(f"node {field} is required")
        if node["id"] in ids:
            raise ValueError(f"duplicate node id: {node['id']}")
        ids.add(str(node["id"]))
        try:
            SemanticType(str(node["type"]))
        except ValueError as exc:
            raise ValueError(f"unknown semantic type: {node['type']}") from exc

    edge_ids: set[str] = set()
    for edge in edges:
        if not isinstance(edge, dict):
            raise ValueError("each edge must be an object")
        for field in ("id", "source", "target", "type"):
            if not edge.get(field):
                raise ValueError(f"edge {field} is required")
        if edge["id"] in edge_ids:
            raise ValueError(f"duplicate edge id: {edge['id']}")
        edge_ids.add(str(edge["id"]))
        if edge["source"] not in ids or edge["target"] not in ids:
            raise ValueError(f"edge references unknown node: {edge['id']}")


def contract_to_graph(payload: Mapping[str, Any]) -> SemanticGraphIR:
    _validate_contract(payload)
    nodes = tuple(
        SemanticNode(
            node_id=str(node["id"]),
            semantic_type=SemanticType(str(node["type"])),
            surface=node.get("surface"),
            context=node.get("context"),
            observer=node.get("observer"),
            state=dict(node.get("state", {})),
            provenance=str(node["provenance"]),
            inferred=bool(node.get("inferred", False)),
        )
        for node in payload["nodes"]
    )
    edges = tuple(
        SemanticEdge(
            edge_id=str(edge["id"]),
            source=str(edge["source"]),
            target=str(edge["target"]),
            edge_type=str(edge["type"]),
            direction=str(edge.get("direction", "FORWARD")),
            constraints=tuple(str(v) for v in edge.get("constraints", [])),
            operator=edge.get("operator"),
            projection=dict(edge.get("projection", {})),
            provenance=str(edge.get("provenance", "ai-contract")),
        )
        for edge in payload["edges"]
    )
    return SemanticGraphIR(nodes=nodes, edges=edges)
