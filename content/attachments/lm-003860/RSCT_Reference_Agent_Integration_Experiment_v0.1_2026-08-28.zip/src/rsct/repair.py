from __future__ import annotations

from dataclasses import dataclass

from .model import FailureCode
from .trace_audit import ReasoningTraceAuditResult


@dataclass(frozen=True)
class RepairAction:
    action: str
    finding_code: FailureCode
    carry_over_id: str
    source_step: str
    target_step: str
    instruction: str


@dataclass(frozen=True)
class RepairPlan:
    trace_id: str
    actions: tuple[RepairAction, ...]


def build_repair_plan(result: ReasoningTraceAuditResult) -> RepairPlan:
    action_by_code = {
        FailureCode.AI_TRACE_EVIDENCE_TRUTH_COLLAPSE: "INSERT_EVALUATION",
        FailureCode.AI_TRACE_MEMORY_BELIEF_COLLAPSE: "REVALIDATE_MEMORY",
        FailureCode.AI_TRACE_INFERENCE_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
        FailureCode.AI_TRACE_ROLE_IDENTITY_ESCALATION: "KEEP_ROLE_SCOPED",
        FailureCode.AI_TRACE_CLAIM_TRUTH_COLLAPSE: "INSERT_EVALUATION",
        FailureCode.AI_TRACE_BELIEF_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
        FailureCode.AI_TRACE_OBSERVATION_TRUTH_COLLAPSE: "PRESERVE_AS_CLAIM",
    }
    actions = tuple(
        RepairAction(
            action=action_by_code[finding.code],
            finding_code=finding.code,
            carry_over_id=finding.carry_over_id,
            source_step=finding.source_step,
            target_step=finding.target_step,
            instruction=finding.repair_hint,
        )
        for finding in sorted(
            result.cross_step_findings,
            key=lambda f: (f.carry_over_id, f.code.value, f.source_step, f.target_step),
        )
        if finding.code in action_by_code
    )
    return RepairPlan(trace_id=result.trace.trace_id, actions=actions)
