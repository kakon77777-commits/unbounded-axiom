from __future__ import annotations

from .fixedpoint import analyze_finite_map, classical_bivalent_negation
from .model import (
    AnalysisResult,
    AnalysisStatus,
    EvaluationIR,
    FailureCode,
    FixedPointResult,
    SemanticType,
)
from .parser import parse_surface
from .reference import classify_self_reference
from .registry import DEFAULT_ASSUMPTIONS
from .semantic import build_semantic_graph


class RSCTAnalyzer:
    def __init__(
        self,
        profile: str = "classical-bivalent",
        assumptions: dict[str, bool] | None = None,
    ) -> None:
        if profile != "classical-bivalent":
            raise ValueError(f"unsupported v0.1 analysis profile: {profile}")
        self.profile = profile
        merged = dict(DEFAULT_ASSUMPTIONS)
        if assumptions:
            unknown = set(assumptions) - set(merged)
            if unknown:
                raise ValueError(f"unknown assumptions: {sorted(unknown)}")
            merged.update(assumptions)
        self.assumptions = merged

    def analyze(self, text: str) -> AnalysisResult:
        surface = parse_surface(text)
        graph = build_semantic_graph(surface)
        self_reference = classify_self_reference(graph)
        false_predicate = SemanticType.FALSE_PREDICATE in graph.node_types()
        truth_bearers = [
            node.node_id
            for node in graph.nodes
            if node.semantic_type is SemanticType.TRUTH_BEARER
        ]

        failures: list[FailureCode] = []
        fixed = FixedPointResult(status=AnalysisStatus.NOT_APPLICABLE)
        equation: str | None = None
        truth_domain: tuple[str, ...] = ()
        summary: str

        if surface.status is AnalysisStatus.PARTIAL:
            fixed = FixedPointResult(status=AnalysisStatus.UNKNOWN)
            summary = "Controlled v0.1 parser did not match this input."
        elif surface.pattern == "LIAR_CLASSICAL":
            active_contract = (
                self_reference["detected"]
                and self.assumptions["SELF_REFERENCE"]
                and bool(truth_bearers)
                and self.assumptions["TRUTH_BEARER_VALID"]
                and false_predicate
                and self.assumptions["FALSE_PREDICATE_CLASSICAL"]
                and self.assumptions["TOTAL_BIVALENCE"]
                and self.assumptions["IMMEDIATE_REENTRY"]
            )
            if active_contract:
                truth_domain = ("T", "F")
                fixed = analyze_finite_map(truth_domain, classical_bivalent_negation())
                equation = "v = N(v)"
                failures.append(FailureCode.FIX_NO_FIXED_POINT)
                summary = "No stable value exists under the active semantic contract."
            else:
                fixed = FixedPointResult(
                    status=AnalysisStatus.UNKNOWN,
                    equation=None,
                    explanation="The classical bivalent liar contract is not fully active.",
                )
                summary = "Classical bivalent fixed-point obstruction is not asserted under the active assumptions."
        elif surface.pattern == "SELF_LANGUAGE":
            summary = "Self-reference detected without false-predicate polarity reversal."
        elif surface.pattern == "EXTERNAL_FALSE":
            summary = "False predicate detected on an external truth bearer; no self-evaluative closure detected."
        elif surface.pattern == "ROLE_REIFICATION":
            summary = "Role construction and role-to-identity escalation candidate detected."
        elif surface.pattern == "BIDIRECTIONAL_HETEROGENEOUS":
            summary = "Bidirectional heterogeneous relations preserved without assuming symmetry."
        elif surface.pattern == "EVIDENCE_CONFLICT":
            summary = "Positive and negative evidence preserved without automatic truth assignment."
        elif surface.pattern == "SIMPLE_FACT":
            summary = "Truth bearer constructed; no world-reference evaluator is configured in MVP v0.1."
        else:
            summary = "Analysis completed without a scenario-specific conclusion."

        evaluation = EvaluationIR(
            truth_bearer=truth_bearers[0] if truth_bearers else None,
            truth_domain=truth_domain,
            fixed_point_equation=equation,
            fixed_point=fixed,
            false_predicate=false_predicate,
            metadata={"profile": self.profile},
        )
        return AnalysisResult(
            text=text,
            parse_status=surface.status,
            graph=graph,
            evaluation=evaluation,
            failures=tuple(failures),
            assumptions=dict(self.assumptions),
            self_reference=self_reference,
            summary=summary,
        )
