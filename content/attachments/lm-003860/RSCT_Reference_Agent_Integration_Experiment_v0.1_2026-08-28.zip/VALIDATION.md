# RSCT Semantic Error Benchmark v0.1 — Validation

This release validates the benchmark harness and the frozen RSCT Agent Semantic Gate v0.2 against a controlled canonical semantic-error dataset.

## Release regression

- Full test suite: **127/127 PASS**
- `python -m compileall -q src`: **PASS**
- `git diff --check`: **PASS**
- Runtime version: **0.2.0**
- Benchmark version: **0.1**
- Existing Gate/Audit/Trace rules are unchanged from commit `b8befa9`.

## Canonical benchmark dataset

- Cases: **88**
- Categories: **22**
- Four structural/provenance variants per category
- Expected decisions: **48 BLOCK / 12 WARN / 20 PASS / 8 DEFER**

## RSCT Gate v0.2 conformance

- Exact decision accuracy: **100.00%**
- BLOCK recall: **100.00%**
- WARN recall: **100.00%**
- DEFER accuracy: **100.00%**
- Intervention precision / recall / F1: **100.00% / 100.00% / 100.00%**
- Exact failure-code accuracy: **100.00%**
- Exact repair-action accuracy: **100.00%**

## Pass-through control

The control predicts `PASS` for every case and performs no semantic reasoning.

- Exact decision accuracy: **22.73%**
- BLOCK recall: **0.00%**
- WARN recall: **0.00%**
- DEFER accuracy: **0.00%**
- Intervention precision / recall / F1: **0.00% / 0.00% / 0.00%**
- Exact failure-code accuracy: **22.73%**
- Exact repair-action accuracy: **31.82%**

## Scientific claim boundary

This is an **in-distribution canonical conformance benchmark**. It verifies that the deterministic Gate implementation matches the frozen benchmark labels and that the benchmark runner/scorer is reproducible.

It does **not** demonstrate that an arbitrary external LLM becomes more accurate when RSCT is attached. The release includes an external prediction scoring format and CLI, but no external model predictions are bundled.

## Fixed-point regression

The classical liar remains:

$$
v=\mathcal N(v)
$$

with `NO_FIXED_POINT` under the active total-bivalent contract.
