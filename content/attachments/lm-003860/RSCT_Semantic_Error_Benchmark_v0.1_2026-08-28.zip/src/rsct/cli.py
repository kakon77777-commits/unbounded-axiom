from __future__ import annotations

import argparse
import json
from pathlib import Path
from collections.abc import Sequence

from .analyzer import RSCTAnalyzer
from .middleware import RSCTSemanticMiddleware
from .reporting import (
    audit_result_to_dict,
    graph_to_dict,
    render_audit_text,
    render_text,
    result_to_dict,
    render_trace_audit_text,
    trace_audit_result_to_dict,
    gate_result_to_dict,
    render_gate_text,
    benchmark_run_to_dict,
    render_benchmark_text,
)
from .repair import build_repair_plan
from .benchmark import (
    load_benchmark_cases,
    load_predictions,
    run_gate_benchmark,
    run_passthrough_baseline,
    run_external_predictions,
)


def _parse_bool(value: str) -> bool:
    normalized = value.strip().lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    raise argparse.ArgumentTypeError(f"invalid boolean value: {value}")


def _parse_assumption_updates(values: list[str]) -> dict[str, bool]:
    updates: dict[str, bool] = {}
    for item in values:
        if "=" not in item:
            raise ValueError(f"assumption mutation must be KEY=BOOL: {item}")
        key, raw = item.split("=", 1)
        updates[key] = _parse_bool(raw)
    return updates


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rsct")
    sub = parser.add_subparsers(dest="command", required=True)

    analyze = sub.add_parser("analyze")
    analyze.add_argument("--json", action="store_true", dest="as_json")
    analyze.add_argument("--set", action="append", default=[], dest="assumptions")
    analyze.add_argument("text")

    graph = sub.add_parser("graph")
    graph.add_argument("text")

    assumptions = sub.add_parser("assumptions")
    assumptions.add_argument("text")

    audit_ai = sub.add_parser("audit-ai")
    audit_ai.add_argument("--json", action="store_true", dest="as_json")
    audit_ai.add_argument("source", help="JSON contract path or '-' for stdin")

    audit_trace = sub.add_parser("audit-ai-trace")
    audit_trace.add_argument("--json", action="store_true", dest="as_json")
    audit_trace.add_argument("--repair-plan", action="store_true", dest="repair_plan")
    audit_trace.add_argument("source", help="JSON reasoning trace path or '-' for stdin")

    gate_ai = sub.add_parser("gate-ai")
    gate_ai.add_argument("--json", action="store_true", dest="as_json")
    gate_ai.add_argument("source", help="JSON contract path or '-' for stdin")

    gate_trace = sub.add_parser("gate-ai-trace")
    gate_trace.add_argument("--json", action="store_true", dest="as_json")
    gate_trace.add_argument("source", help="JSON reasoning trace path or '-' for stdin")

    benchmark = sub.add_parser("benchmark")
    benchmark.add_argument("dataset")
    benchmark.add_argument("--engine", choices=("gate", "passthrough"), default="gate")
    benchmark.add_argument("--json", action="store_true", dest="as_json")

    benchmark_score = sub.add_parser("benchmark-score")
    benchmark_score.add_argument("dataset")
    benchmark_score.add_argument("predictions")
    benchmark_score.add_argument("--json", action="store_true", dest="as_json")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(list(argv) if argv is not None else None)
    if args.command in {"benchmark", "benchmark-score"}:
        try:
            cases = load_benchmark_cases(args.dataset)
            if args.command == "benchmark":
                run = run_gate_benchmark(cases) if args.engine == "gate" else run_passthrough_baseline(cases)
            else:
                predictions = load_predictions(args.predictions)
                run = run_external_predictions(cases, predictions)
        except (OSError, ValueError) as exc:
            print(f"error: {exc}")
            return 2
        if args.as_json:
            print(json.dumps(benchmark_run_to_dict(run), ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(render_benchmark_text(run))
        return 0

    if args.command == "analyze":
        try:
            updates = _parse_assumption_updates(args.assumptions)
            result = RSCTAnalyzer(assumptions=updates).analyze(args.text)
        except ValueError as exc:
            print(f"error: {exc}")
            return 2
        if args.as_json:
            print(json.dumps(result_to_dict(result), ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(render_text(result))
        return 0

    if args.command in {"gate-ai", "gate-ai-trace"}:
        try:
            if args.source == "-":
                import sys
                text = sys.stdin.read()
            else:
                text = Path(args.source).read_text(encoding="utf-8")
            payload = json.loads(text)
            if not isinstance(payload, dict):
                raise ValueError("gate input must be a JSON object")
            middleware = RSCTSemanticMiddleware()
            gate = (
                middleware.gate_trace_contract(payload)
                if args.command == "gate-ai-trace"
                else middleware.gate_contract(payload)
            )
        except json.JSONDecodeError as exc:
            print(f"error: invalid JSON gate input: {exc.msg}")
            return 2
        except (OSError, ValueError) as exc:
            print(f"error: {exc}")
            return 2
        if args.as_json:
            print(json.dumps(gate_result_to_dict(gate), ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(render_gate_text(gate))
        if gate.decision.value == "BLOCK":
            return 1
        if gate.decision.value == "DEFER":
            return 2
        return 0

    if args.command == "audit-ai-trace":
        try:
            if args.source == "-":
                import sys
                text = sys.stdin.read()
            else:
                text = Path(args.source).read_text(encoding="utf-8")
            audit = RSCTSemanticMiddleware().audit_trace_json(text)
            repair_plan = build_repair_plan(audit) if args.repair_plan else None
        except (OSError, ValueError) as exc:
            print(f"error: {exc}")
            return 2
        if args.as_json:
            print(json.dumps(trace_audit_result_to_dict(audit, repair_plan), ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(render_trace_audit_text(audit, repair_plan))
        return 0 if audit.passed else 1

    if args.command == "audit-ai":
        try:
            if args.source == "-":
                import sys
                text = sys.stdin.read()
            else:
                text = Path(args.source).read_text(encoding="utf-8")
            audit = RSCTSemanticMiddleware().audit_json(text)
        except (OSError, ValueError) as exc:
            print(f"error: {exc}")
            return 2
        if args.as_json:
            print(json.dumps(audit_result_to_dict(audit), ensure_ascii=False, indent=2, sort_keys=True))
        else:
            print(render_audit_text(audit))
        return 0 if audit.passed else 1

    result = RSCTAnalyzer().analyze(args.text)
    if args.command == "graph":
        print(json.dumps(graph_to_dict(result), ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    if args.command == "assumptions":
        for key, value in sorted(result.assumptions.items()):
            print(f"{key}={'true' if value else 'false'}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
