# GLM_RH Campaign 01 Seed
## Lossless Witness Globalizer Search

**Method:** `GLM_Backward Search`  
**Scope:** Goal-Led Meta-Research  
**Definition-first classification:** complete  
**Campaign status:** READY

## Target

```text
target_id: GLM-RH-C01
target_name: LOSSLESS_WITNESS_GLOBALIZER
target_type: method/theorem-family search target
```

## Parent frontiers

```text
F-RH-001  GLOBAL_WEIL_ISOLATION_DOMINANCE
F-RH-004  MAJOR_ZERO_PACKET_ISOLATION
```

## Goal

Generate the weakest candidate transform, invariant, or separation theorem that turns an off-critical near-extremal zero witness into a noncancellable global invariant without assuming RH, a fixed zero strip, or witness dominance.

## Required candidate fields

```text
candidate_id
statement
representation
zero_response
near_extremal_response
aggregation_law
background_law
global_invariant
proof_direction
strength_class
obstruction_hits
new_debt
falsification_test
bridge_targets
status = PROOF_OBLIGATION
```

## Hard rejection filters

```text
R1  REPACKAGING_ONLY
R2  HIDDEN_ISOLATION_PREMISE
R3  HIDDEN_SUPREMUM_ATTAINMENT
R4  DENSITY_ONLY_RECURRENCE
R5  FINITE_TO_GLOBAL_JUMP
R6  REPRESENTATION_ONLY_NOVELTY
R7  STRENGTH_LAUNDERING
```

## First backward obligations

1. Define a candidate global invariant.
2. Prove every off-critical zero has nonzero response.
3. Prove near-extremal horizontal displacement is preserved.
4. Prove aggregation cannot erase the extremal response.
5. Close archimedean / trivial-zero / local-factor backgrounds.
6. Perform strength audit before proof promotion.
7. Compile every failure into CSM_RH rather than retrying indefinitely.

## Success condition

A candidate is campaign-successful if it certifiably closes at least one of:

```text
O-RH-005-W
O-RH-005-M
```

without importing a stronger hidden premise.

It need not prove RH.
