#!/usr/bin/env python3
import csv

etas = [0.05, 0.10, 0.25, 0.50, 1.00]
lambdas = [0.00, 0.02, 0.05, 0.10, 0.25]

rows = []
for eta in etas:
    theta = 1 - eta/2
    rows.append(["ZPPF", eta, 0.0, eta, theta])
    for lam in lambdas:
        effective = eta - lam
        implied_theta = None if effective <= 0 else 1 - effective/2
        rows.append(["positive_gate_weight_loss", eta, lam, effective, implied_theta])

with open("positive_gate_exponent_audit.csv", "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f)
    w.writerow(["case", "eta", "lambda_loss", "effective_eta", "implied_Theta_upper"])
    w.writerows(rows)

# Mechanical assertions for the algebra in Theorem 8.
for eta in etas:
    assert abs((1 + 2*(1-eta/2)) - (3-eta)) < 1e-12

print("PASS")
print("Rows:", len(rows))
