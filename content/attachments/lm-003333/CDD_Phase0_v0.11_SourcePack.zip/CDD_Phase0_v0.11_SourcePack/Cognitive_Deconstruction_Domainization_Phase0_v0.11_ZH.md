# 認知解構學域化工程 Phase 0 v0.11
## Controlled Action-Presentation Predictive Interface and Bidirectional World Coupling

**狀態：** Research Draft / Canonical Source Candidate  
**日期：** 2026-08-20  
**作者脈絡：** Neo.K / EveMissLab  
**前版：** Phase 0 v0.10

---

# 0. 摘要

Phase 0.10 得到：

$$
S_t^{obs}
\neq
S_t^{pred}
\neq
\pi_R^{dst}.
$$

並指出單純增加 passive observable-state 欄位並不能有效修復 OOD prediction。

Phase 0.11 因此第一次把 Cognitive-World Boundary 與 MWT action/interaction event 真正放進 runtime：

$$
\boxed{
Presentation_t
\rightarrow
ActionRequest_t
\rightarrow
CWB
\rightarrow
WorldTransition_t
\rightarrow
Presentation_{t+1}.
}
$$

本輪建立 **Controlled Action-Presentation Interface States, CAPIS**。

CAPIS 不再只問：

$$
P(O_{t+1}\mid O_t),
$$

而是：

$$
\boxed{
P(
O_{t+1}
\mid
O_t,A_t=a,\mathrm{CWB}
).
}
$$

其中 action 是實際經過 CWB 合法性閘門並作用 synthetic World 的 action，不是事後從 passive data 猜測的虛構干預。

Main normal test：

$$
Bits_{passive}=5.7867,
$$

$$
Bits_{exact\ obs+action}=3.9936,
$$

$$
Bits_{CAPIS}=3.8866,
$$

$$
Bits_{hidden\ oracle}=2.6449.
$$

因此 action conditioning 本身帶來：

$$
\boxed{
\Delta_{action}
=
1.7932
\text{ bits/transition}
}
$$

而 CAPIS predictive pooling 再帶來：

$$
\boxed{
\Delta_{CAPIS}
=
0.1069
\text{ bits/transition}.
}
$$

五個 normal splits：

$$
\boxed{
CAPIS<ExactObsAction
\quad
5/5
}
$$

平均 gain：

$$
\boxed{
E[\Delta_{CAPIS}]
=
0.1091
\text{ bits/transition}.
}
$$

六個 regime-adapted runs：

$$
\boxed{
6/6
}
$$

全部得到正 gain，平均：

$$
0.3379.
$$

六個 leave-one-regime-out tests：

$$
\boxed{
6/6
}
$$

也全部維持正 gain，平均：

$$
0.0533.
$$

這是目前 CDD 域化線第一次在明確 World action loop 中看到跨 regime 保留的 controlled predictive quotient signal。

---

# 1. MWT / CWB world loop

Phase 0.11 保留三個硬分離：

$$
\boxed{
ActionRequest
\neq
WorldMutation
\neq
OutcomePresentation.
}
$$

每個 action step 都保存：

1. cognitive action-preparation chain；
2. `CWB-001` AcceptActionRequest；
3. `CWB-002` AuthorizeWorldMutation；
4. `CWB-003` MapToWorldOperator；
5. `CWB-004` CommitWorldTransition；
6. `CWB-005` EmitOutcomePresentation。

若 legality precondition 不成立，CWB 會產生：

$$
Authorization=Denied
$$

且：

$$
WorldMutation=False.
$$

因此：

$$
\boxed{
\text{cognition requests}
\neq
\text{World commits}.
}
$$

每一步同時保存 MWT-style event：

$$
\mathsf e_t
=
(
O,
\Gamma,
o,
\vec x,
\vec y,
H,
Q
).
$$

World hidden state 只屬 synthetic simulator 與 oracle baseline，不提供給 CAPIS。

---

# 2. Synthetic controlled World

本輪 synthetic World 的 hidden state 為：

$$
W_t^{hid}
=
(
Stock_t,
Gate_t,
Stability_t,
Energy_t
).
$$

其中：

$$
Stock,Energy\in\{0,1,2\},
$$

$$
Gate,Stability\in\{0,1\}.
$$

所以 hidden full-state space 最多有：

$$
3\times2\times2\times3=36
$$

個狀態。

合法 action set：

$$
\mathcal A
=
\{
Probe,
OpenGate,
Acquire,
Replenish,
Stabilize,
Recharge
\}.
$$

Observer 看不到 hidden state，而只取得 noisy Presentation：

$$
O_t
=
(
StockHint,
GateHint,
StabilityHint,
EnergyHint,
LastOutcome
).
$$

本輪使用六個 World regimes：

- normal；
- noisy observation；
- volatile world；
- low energy；
- access fault；
- mixed。

Behavior policy 保留：

$$
0.65
$$

的隨機探索率，避免 action coverage 被單一 heuristic policy 鎖死。

---

# 3. CAPIS 定義

對 observable presentation $o$，CAPIS 建立 action-conditioned one-step predictive signature。

實作上對每個 action 與每個 future Presentation field 估計：

$$
P(
O_{t+1}^{(j)}
\mid
O_t=o,A_t=a
).
$$

因此：

$$
\Phi(o)
=
\bigoplus_{a\in\mathcal A}
\bigoplus_j
P(
O_{t+1}^{(j)}
\mid
o,a
).
$$

若兩個 presentations $o_i,o_j$ 的 action-conditioned signatures 在目前 finite-data approximation 下足夠接近：

$$
D_{JS}(
\Phi(o_i),
\Phi(o_j)
)
\leq
\delta,
$$

則它們可以被放入同一 CAPIS state。

這只是有限資料、one-step、factorized-observation approximation。

因此：

$$
\boxed{
CAPIS_{v0.11}
\neq
\text{exact PSR}
\neq
\text{POMDP belief state}
\neq
\epsilon\text{-transducer}.
}
$$

---

# 4. Main normal：action conditioning 是主訊號

Main test：

$$
Bits_{passive}
=
5.7867.
$$

只加入 action：

$$
Bits_{exact\ obs+action}
=
3.9936.
$$

改善：

$$
\boxed{
1.7932
}
$$

bits/transition。

這比 Phase 0.10 passive state-field engineering 的效果大一個量級。

所以：

$$
\boxed{
\text{controlled action information}
\text{ is structurally important in this world-coupled runtime}.
}
$$

---

# 5. CAPIS predictive pooling 再增加 compression

Main selected CAPIS：

- JS threshold = `0.08`；
- minimum support = `8`；
- CAPIS states = `36`；
- observed Presentation contexts = `333`。

Main test：

$$
Bits_{CAPIS}
=
3.8866.
$$

相對 exact observation+action：

$$
\boxed{
Gain
=
0.1069
}
$$

bits/transition。

五個 normal split robustness：

$$
ExactMean=3.9580,
$$

$$
CAPISMean=3.8489,
$$

$$
\boxed{
MeanGain=0.1091
}
$$

且：

$$
\boxed{
PositiveGain=5/5.
}
$$

這使 Main gain 不再只是單一 split 現象。

---

# 6. Action-shuffle falsification

若 CAPIS 只是普通 observation clustering，而 action 本身不重要，將 test action labels 打亂不應造成巨大損失。

實際：

$$
Bits_{CAPIS}
=
3.8866,
$$

action-shuffled mean：

$$
E[Bits_{shuffle}]
=
10.3822.
$$

100 permutations：

$$
\boxed{
p_{lower}
=
0.009901.
}
$$

因此本輪支持：

$$
\boxed{
CAPIS
\text{ depends on action-conditioned future structure}
}
$$

而不是只依賴 Presentation identity。

---

# 7. Regime-adapted robustness

六個 regime-adapted CAPIS 相對 exact observation+action 的 gain：

$$
0.0852, 0.7007, 0.2629, 0.1584, 0.3041, 0.5160.
$$

全部為正：

$$
\boxed{6/6}.
$$

平均：

$$
\boxed{
0.3379
\text{ bits/transition}.
}
$$

特別是 noisy observation 與 mixed regime，predictive pooling 的 gain 最大。

這表示在 observation noise 與多重 transition disturbance 增加時，適度 pooling 可能比保留所有 raw Presentation identity 更有效。

---

# 8. Leave-One-Regime-Out

更嚴格的測試是不讓 held-out regime 參與 CAPIS model selection。

六個 holdouts 的 gain：

$$
0.0533, 0.0859, 0.0392, 0.0064, 0.0309, 0.1040.
$$

得到：

$$
\boxed{
PositiveGain=6/6.
}
$$

平均：

$$
\boxed{
0.0533
\text{ bits/transition}.
}
$$

最低 gain 只有：

$$
0.0064,
$$

最高為：

$$
0.1040.
$$

所以跨 regime transfer 的收益比 within-regime adapted 小得多，但方向在六個 holdouts 中一致。

這是 CAPIS 目前最重要的 robustness signal。

---

# 9. CAPIS 不是 World hidden state

Main hidden-state action oracle：

$$
Bits_{oracle}
=
2.6449.
$$

它比 CAPIS 還好：

$$
\boxed{
1.2417
\text{ bits/transition}.
}
$$

所以 CAPIS 仍然遠不是完整 world state。

更有意思的是 Main CAPIS state count 恰好是：

$$
36.
$$

而 hidden World full state cardinality 也是：

$$
36.
$$

但這**不能**被解讀為 exact state recovery。

Main test 上 CAPIS 與 hidden full state 的 NMI：

$$
\boxed{
NMI=0.5503
}
$$

200 次 permutation mean：

$$
0.0536,
$$

$$
p
=
0.004975.
$$

所以：

$$
\boxed{
\text{CAPIS and hidden state are non-randomly related}
\land
\text{CAPIS is not hidden-state identity}.
}
$$

這與 MWT Presentation Non-Identity 原則相容。

---

# 10. Controlled Predictive Interface Candidate

Phase 0.10 的 passive candidate 是：

$$
\rho_{O,t}(\mathbf W)
\rightarrow
S_t^{obs}
\rightarrow
\psi_R
\rightarrow
S_t^{pred}.
$$

Phase 0.11 加入真正 action loop：

$$
\boxed{
\rho_{O,t}(\mathbf W_t)
\rightarrow
S_t^{pred}
\rightarrow
ActionRequest_t
\rightarrow
CWB
\rightarrow
\mathbf W_{t+1}
\rightarrow
\rho_{O,t+1}(\mathbf W_{t+1}).
}
$$

因此 predictive equivalence 不應只問：

$$
\text{如果什麼都不做，未來看起來是否相同？}
$$

而應問：

$$
\boxed{
\text{在同一族合法 actions 下，future Presentations 是否具有近似相同分布？}
}
$$

這是本輪真正的 World-coupled domainization step。

---

# 11. Controlled Cognitive Domain Candidate

本輪不 promotion domain，但可以提出候選形式。

若兩個 Presentations：

$$
o_i,o_j
$$

滿足：

$$
\forall a\in\mathcal A_{legal},
\quad
P(O_{t+1}\mid o_i,a)
\approx
P(O_{t+1}\mid o_j,a),
$$

則：

$$
o_i\sim_{ctrl}o_j.
$$

可形成：

$$
\boxed{
\mathfrak D_{ctrl}
=
\mathcal P_{obs}/\sim_{ctrl}.
}
$$

但 v0.11 只做 one-step、finite-data、factorized observation approximation，不能把這個 quotient 升格成普遍世界域。

---

# 12. 與既有 Cognitive Atlas 的關係

Phase 0.11 沒有證明：

$$
CAPIS=\pi_R^{dst}.
$$

CAPIS 是 World interface 上的 Presentation quotient。

既有 Cognitive Atlas 則仍是 operator transition geometry 的 derived quotient。

因此目前更合理的是：

$$
\boxed{
\text{Cognitive Atlas}
\neq
\text{Controlled World Interface States}.
}
$$

它們可能在未來透過 action routing、operator selection 與 world outcome 形成 coupling map，而不是被強行合併成同一 partition。

---

# 13. 方法學限制

1. World 是 synthetic。
2. action alphabet 是人工設計的六個 CWB-safe world operators。
3. behavior policy 有 0.65 random exploration，但不等於完整 uniform intervention design。
4. CAPIS 只使用 one-step future Presentation。
5. predictive signature 使用 factorized Presentation fields，不是完整 joint future distribution。
6. JS clustering 是近似算法，不是 exact causal-state / exact PSR reconstruction。
7. hidden oracle 只作 simulator diagnostic，不能部署到 CAPIS。
8. leave-one-regime-out gain 雖 6/6 為正，但平均只有 0.0533 bits/transition。
9. 仍沒有真實 AI / human world-interaction traces。
10. DomainPromotionCount 仍為 0。

---

# 14. Phase 0.12 建議

下一輪最值得做的不是增加更多 action 名稱，而是把 one-step CAPIS 升級成**multi-step controlled tests**：

$$
\tau
=
(a_1,o_1,a_2,o_2,\ldots,a_k,o_k).
$$

建立：

$$
P(
o_{1:k}
\mid
h_t,
a_{1:k}
).
$$

然後測：

1. one-step CAPIS 是否被 multi-step controlled predictive state 取代；
2. CAPIS 是否存在 minimal core tests；
3. controlled predictive states 與 Cognitive Atlas 的 coupling 是否具方向性；
4. 世界 regime 改變時，是 action-response kernel 先變，還是 predictive quotient 先變；
5. 真實 Agent tool-action traces 能否進同一 CWB/MWT schema。

---

# 15. Promotion

$$
\boxed{
DomainPromotionCount=0.
}
$$

理由：

- synthetic World；
- one-step predictive signature；
- artificial action alphabet；
- factorized future Presentation；
- 沒有外部 real-agent replication；
- CAPIS 與 hidden World state 仍有巨大 oracle gap。

Phase 0.11 可以支持 **Controlled Predictive Interface Candidate**，不能宣告已發現真實 Cognitive World Domain。

---

# 16. Canonical source

Chat rendering 不是 canonical source。

本 SourcePack 的 UTF-8 documents、frozen traces、CWB/MWT event records、experiment code、tests、results、validation 與 checksums才是 Phase 0.11 正式 source candidate。
