# Phase 0.11 Experiment Design

## Question

Can an action-conditioned predictive quotient over observer-relative World Presentations outperform passive observation and exact Presentation identity, and does that value transfer across world regimes?

## Controlled World

Hidden simulator state:

$$
W_t^{hid}=(Stock,Gate,Stability,Energy).
$$

Observer Presentation:

$$
P_t=(StockHint,GateHint,StabilityHint,EnergyHint,LastOutcome).
$$

Actions:

`probe`, `open_gate`, `acquire`, `replenish`, `stabilize`, `recharge`.

Every action goes through the frozen Phase 0.3 CWB chain. Denied actions do not mutate World.

## Regimes

- normal
- noisy_observation
- volatile_world
- low_energy
- access_fault
- mixed

## Behavior policy

Action choice uses Presentation only and has random exploration probability $0.65$.

Hidden world state is forbidden to the policy and CAPIS.

## CAPIS

For each Presentation context and action, estimate factorized one-step future-Presentation distributions.

Cluster Presentation contexts by mean action-conditioned Jensen-Shannon divergence.

Select JS threshold and minimum support using training plus validation MDL only.

## Baselines

1. passive Presentation only;
2. exact Presentation + action;
3. CAPIS + action;
4. hidden World state + action oracle, non-deployable.

## Falsification

- five normal train/validation/test splits;
- six regime-adapted runs;
- six leave-one-regime-out runs;
- 100 action-label permutations;
- CAPIS versus hidden World-state NMI/permutation;
- context-backoff reporting.

## Hard limits

- one-step future only;
- factorized future Presentation;
- synthetic World;
- artificial action alphabet;
- no exact PSR/belief/bisimulation claim;
- no domain promotion.
