# Phase 0.11 Research Decision Log

**Date:** 2026-08-20

## D1. Action is not optional context

Main passive to exact-action gain:

$$
1.7932
$$

bits/transition.

Action-shuffle null is dramatically worse.

Decision: World-coupled cognitive state must model actions explicitly.

## D2. Promote CAPIS only as a candidate interface, not as a domain

CAPIS beats exact Presentation+action in 5/5 normal splits, 6/6 adapted regimes, and 6/6 leave-one-regime-out tests.

Decision: CAPIS has synthetic operational support as a controlled predictive interface.

## D3. Do not identify CAPIS with World state

Hidden oracle remains better by:

$$
1.2417
$$

bits/transition.

NMI with full hidden state is only:

$$
0.5503.
$$

Decision: equal state counts in Main are not evidence of exact recovery.

## D4. Preserve Presentation Non-Identity

CAPIS is learned from Presentations and outcomes, not from direct World primitive access.

## D5. Next phase is multi-step controlled tests

Phase 0.12 should test action-observation sequences rather than more one-step clustering.
