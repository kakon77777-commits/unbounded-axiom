from __future__ import annotations
import argparse,json
from pathlib import Path
from experiment.run_phase11 import (
    REGIMES, split_episodes, select_capis, baseline_bundle, state_map_serializable,
    action_permutation_test, capis_hidden_relation, per_action_bits, adapted_regime_run,
    leave_one_regime_out,
)
from experiment.controlled_action_observation import fit_factorized_model, capis_model_score

BASE=Path(__file__).resolve().parents[1]
RDIR=BASE/'results'

def load_eps(regime):
    path=RDIR/f'controlled_{regime}_episodes_v0.11.jsonl'
    out=[]
    with path.open(encoding='utf-8') as f:
        for line in f:
            if line.strip(): out.append(json.loads(line))
    return out

def load_all():
    return {r:load_eps(r) for r in REGIMES}

def stage_main():
    eps=load_eps('normal')
    sp=split_episodes(eps,seed=11601)
    sel=select_capis(sp['train'],sp['validation'])
    capis=sel['selected_model']
    b=baseline_bundle(sp['train'],sp['validation'],sp['test'],sel)
    b['split']={k:len(v) for k,v in sp.items()}
    b['capis']['candidate_table']=sel['candidate_table']
    b['capis']['state_map']=state_map_serializable(capis)
    b['capis']['action_permutation_test']=action_permutation_test(capis,sp['test'])
    b['capis']['hidden_control_relation']=capis_hidden_relation(capis,sp['test'])
    b['comparisons_positive_is_better']={
        'action_gain_exact_over_passive': b['passive_obs']['test']['bits_per_transition']-b['exact_obs_action']['test']['bits_per_transition'],
        'capis_gain_over_exact': b['exact_obs_action']['test']['bits_per_transition']-b['capis']['test']['bits_per_transition'],
        'capis_gain_over_passive': b['passive_obs']['test']['bits_per_transition']-b['capis']['test']['bits_per_transition'],
        'oracle_gain_over_capis': b['capis']['test']['bits_per_transition']-b['hidden_state_action_oracle']['test']['bits_per_transition'],
    }
    (RDIR/'main_stage_v0.11.json').write_text(json.dumps(b,ensure_ascii=False,indent=2),encoding='utf-8')
    (RDIR/'selected_capis_model_v0.11.json').write_text(json.dumps({
        'js_threshold':capis['js_threshold'],'min_support':capis['min_support'],'state_count':capis['state_count'],
        'observation_context_count':capis['observation_context_count'],'state_map':state_map_serializable(capis)
    },ensure_ascii=False,indent=2),encoding='utf-8')
    # freeze a compact normal-trained zero-shot score for all regimes
    exact=fit_factorized_model(sp['train'],'obs_action')
    passive=fit_factorized_model(sp['train'],'passive_obs')
    z={}
    for r in REGIMES:
        te=load_eps(r)
        from experiment.controlled_action_observation import score_factorized_model
        z[r]={
            'passive_obs_bits':score_factorized_model(passive,te,'passive_obs')['bits_per_transition'],
            'exact_obs_action_bits':score_factorized_model(exact,te,'obs_action')['bits_per_transition'],
            'capis_bits':capis_model_score(capis,te)['bits_per_transition'],
            'capis_backoff_rate':capis_model_score(capis,te)['context_backoff_rate'],
        }
    (RDIR/'normal_zero_shot_v0.11.json').write_text(json.dumps(z,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'main_bits':{
        'passive':b['passive_obs']['test']['bits_per_transition'],
        'exact_action':b['exact_obs_action']['test']['bits_per_transition'],
        'capis':b['capis']['test']['bits_per_transition'],
        'oracle':b['hidden_state_action_oracle']['test']['bits_per_transition']},
        'states':capis['state_count'],'comparisons':b['comparisons_positive_is_better'],
        'action_perm':b['capis']['action_permutation_test']},indent=2))

def stage_adapted(regime):
    eps=load_eps(regime)
    i=REGIMES.index(regime)
    bundle,_=adapted_regime_run(eps,seed=11701+i*17)
    (RDIR/f'adapted_{regime}_v0.11.json').write_text(json.dumps(bundle,ensure_ascii=False,indent=2),encoding='utf-8')
    print(regime,bundle['passive_obs']['test']['bits_per_transition'],bundle['exact_obs_action']['test']['bits_per_transition'],bundle['capis']['test']['bits_per_transition'],bundle['capis']['selected']['state_count'])

def stage_looro(regime):
    all_eps=load_all()
    i=REGIMES.index(regime)
    res=leave_one_regime_out(all_eps,regime,seed=11801+i*19)
    (RDIR/f'looor_{regime}_v0.11.json').write_text(json.dumps(res,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(res,indent=2))

def assemble():
    main=json.loads((RDIR/'main_stage_v0.11.json').read_text())
    zero=json.loads((RDIR/'normal_zero_shot_v0.11.json').read_text())
    adapted={r:json.loads((RDIR/f'adapted_{r}_v0.11.json').read_text()) for r in REGIMES}
    looro=[json.loads((RDIR/f'looor_{r}_v0.11.json').read_text()) for r in REGIMES]
    out={
      'experiment':'CDD Phase 0.11 Controlled Action-Observation Predictive Interface','version':'0.11','date':'2026-08-20',
      'methodological_status':'synthetic_controlled_cwb_mwt_action_observation_predictive_interface_not_exact_psr_pomdp_or_world_ontology',
      'world_regimes':list(REGIMES),'actions':['probe','open_gate','acquire','replenish','stabilize','recharge'],
      'normal_episode_count':1200,'stress_episode_count_each':400,'steps_per_episode':20,'behavior_exploration_probability':0.65,
      'main_normal':main,'normal_selected_zero_shot':zero,'regime_adapted':adapted,'leave_one_regime_out':looro,
      'domain_promotion_count':0,'exact_psr_claim':False,'world_ontology_claim':False
    }
    (RDIR/'phase11_experiment_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    (RDIR/'leave_one_regime_out_v0.11.json').write_text(json.dumps(looro,ensure_ascii=False,indent=2),encoding='utf-8')
    print('assembled')

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('stage'); ap.add_argument('--regime',choices=REGIMES)
    a=ap.parse_args()
    if a.stage=='main': stage_main()
    elif a.stage=='adapted': stage_adapted(a.regime)
    elif a.stage=='looro': stage_looro(a.regime)
    elif a.stage=='assemble': assemble()
    else: raise SystemExit('bad stage')
