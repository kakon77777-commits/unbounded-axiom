from __future__ import annotations

from dataclasses import dataclass, asdict
from collections import defaultdict, Counter
import copy
import math
import random
from typing import Dict, List, Tuple, Any

ACTIONS = ("probe", "open_gate", "acquire", "replenish", "stabilize", "recharge")
OBS_FIELDS = ("stock_hint", "gate_hint", "stability_hint", "energy_hint", "last_outcome")
FIELD_VALUES = {
    "stock_hint": ("empty", "some", "many"),
    "gate_hint": ("closed", "open"),
    "stability_hint": ("stable", "fragile"),
    "energy_hint": ("empty", "some", "full"),
    "last_outcome": (
        "start", "probe_ok", "opened", "acquired", "replenished",
        "stabilized", "recharged", "denied", "failed", "no_effect"
    ),
}

@dataclass(frozen=True)
class WorldState:
    stock: int
    gate_open: bool
    stable: bool
    energy: int

@dataclass(frozen=True)
class WorldParams:
    obs_noise: float = 0.10
    action_success: float = 0.90
    open_success: float = 0.90
    recharge_success: float = 0.90
    stock_decay: float = 0.03
    gate_reclose: float = 0.02
    stability_flip: float = 0.02
    energy_drain: float = 0.01

def regime_params(regime: str) -> WorldParams:
    if regime == "normal":
        return WorldParams()
    if regime == "noisy_observation":
        return WorldParams(obs_noise=0.30)
    if regime == "volatile_world":
        return WorldParams(stock_decay=0.16, gate_reclose=0.10, stability_flip=0.14)
    if regime == "low_energy":
        return WorldParams(recharge_success=0.52, energy_drain=0.14, action_success=0.84)
    if regime == "access_fault":
        return WorldParams(open_success=0.48, gate_reclose=0.22, action_success=0.84)
    if regime == "mixed":
        return WorldParams(
            obs_noise=0.22, action_success=0.82, open_success=0.62,
            recharge_success=0.67, stock_decay=0.10, gate_reclose=0.12,
            stability_flip=0.09, energy_drain=0.08
        )
    raise ValueError(f"unknown regime: {regime}")

def _clamp(x: int) -> int:
    return max(0, min(2, int(x)))

def _legal(state: WorldState, action: str) -> Tuple[bool, str]:
    if action == "probe":
        return True, "always_observable"
    if action == "recharge":
        return True, "recharge_endpoint_available"
    if action == "open_gate":
        return (state.energy > 0), "requires_energy"
    if action == "acquire":
        return (state.energy > 0 and state.gate_open and state.stock > 0), "requires_energy_gate_stock"
    if action == "replenish":
        return (state.energy > 0), "requires_energy"
    if action == "stabilize":
        return (state.energy > 0), "requires_energy"
    raise ValueError(action)

def apply_cwb_action(state: WorldState, action: str, params: WorldParams, seed: int) -> Tuple[WorldState, Dict[str, Any]]:
    if action not in ACTIONS:
        raise ValueError(action)
    rng = random.Random(seed)
    request = {"type": "ActionRequest", "action": action, "target": "synthetic_world"}
    boundary_request = {"type": "BoundaryRequest", "accepted": True, "action": action}
    legal, reason = _legal(state, action)
    if not legal:
        rec = {
            "action_request": request,
            "boundary_request": boundary_request,
            "authorization": "Denied",
            "authorization_reason": reason,
            "world_operator_invocation": None,
            "world_transition": {"committed": False, "operator": None},
            "outcome_presentation": {"outcome": "denied"},
            "world_mutated": False,
        }
        return state, rec

    invocation = {"type": "WorldOperatorInvocation", "operator": f"WORLD.{action}"}
    stock, gate, stable, energy = state.stock, state.gate_open, state.stable, state.energy
    outcome = "no_effect"

    if action == "probe":
        outcome = "probe_ok"
    elif action == "recharge":
        if rng.random() < params.recharge_success:
            energy = _clamp(energy + 1)
            outcome = "recharged"
        else:
            outcome = "failed"
    elif action == "open_gate":
        energy = _clamp(energy - 1)
        if gate:
            outcome = "no_effect"
        elif rng.random() < params.open_success:
            gate = True
            outcome = "opened"
        else:
            outcome = "failed"
    elif action == "acquire":
        energy = _clamp(energy - 1)
        if rng.random() < params.action_success:
            stock = _clamp(stock - 1)
            outcome = "acquired"
        else:
            outcome = "failed"
    elif action == "replenish":
        energy = _clamp(energy - 1)
        if stock >= 2:
            outcome = "no_effect"
        elif rng.random() < params.action_success:
            stock = _clamp(stock + 1)
            outcome = "replenished"
        else:
            outcome = "failed"
    elif action == "stabilize":
        energy = _clamp(energy - 1)
        if stable:
            outcome = "no_effect"
        elif rng.random() < params.action_success:
            stable = True
            outcome = "stabilized"
        else:
            outcome = "failed"

    ns = WorldState(stock=stock, gate_open=gate, stable=stable, energy=energy)
    rec = {
        "action_request": request,
        "boundary_request": boundary_request,
        "authorization": "Authorized",
        "authorization_reason": reason,
        "world_operator_invocation": invocation,
        "world_transition": {
            "committed": ns != state,
            "operator": invocation["operator"],
            "state_changed": ns != state,
        },
        "outcome_presentation": {"outcome": outcome},
        "world_mutated": ns != state,
    }
    return ns, rec

def apply_exogenous_dynamics(state: WorldState, params: WorldParams, seed: int) -> WorldState:
    rng = random.Random(seed)
    stock, gate, stable, energy = state.stock, state.gate_open, state.stable, state.energy
    if stock > 0 and rng.random() < params.stock_decay * (1.7 if not stable else 1.0):
        stock -= 1
    if gate and rng.random() < params.gate_reclose:
        gate = False
    if rng.random() < params.stability_flip:
        stable = not stable
    if energy > 0 and rng.random() < params.energy_drain:
        energy -= 1
    return WorldState(_clamp(stock), gate, stable, _clamp(energy))

def _maybe_noisy_index(value: int, n: int, noise: float, rng: random.Random) -> int:
    if rng.random() >= noise:
        return value
    choices = [i for i in range(n) if i != value]
    return rng.choice(choices) if choices else value

def observe_world(state: WorldState, outcome: str, params: WorldParams, seed: int, probe_bonus: bool=False) -> Dict[str, str]:
    rng = random.Random(seed)
    noise = params.obs_noise * (0.35 if probe_bonus else 1.0)
    stock_idx = _maybe_noisy_index(state.stock, 3, noise, rng)
    gate_idx = _maybe_noisy_index(1 if state.gate_open else 0, 2, noise, rng)
    stab_idx = _maybe_noisy_index(0 if state.stable else 1, 2, noise, rng)
    energy_idx = _maybe_noisy_index(state.energy, 3, noise, rng)
    return {
        "stock_hint": FIELD_VALUES["stock_hint"][stock_idx],
        "gate_hint": FIELD_VALUES["gate_hint"][gate_idx],
        "stability_hint": FIELD_VALUES["stability_hint"][stab_idx],
        "energy_hint": FIELD_VALUES["energy_hint"][energy_idx],
        "last_outcome": outcome,
    }

def _initial_state(rng: random.Random, regime: str) -> WorldState:
    if regime == "low_energy":
        energy = rng.choice([0, 0, 1])
    else:
        energy = rng.choice([0, 1, 2])
    stable = rng.random() > (0.45 if regime == "volatile_world" else 0.25)
    gate = rng.random() < (0.30 if regime == "access_fault" else 0.50)
    stock = rng.choice([0,1,1,2,2])
    return WorldState(stock=stock, gate_open=gate, stable=stable, energy=energy)

def choose_action(obs: Dict[str,str], rng: random.Random, exploration: float=0.60) -> str:
    if rng.random() < exploration:
        return rng.choice(ACTIONS)
    if obs["energy_hint"] == "empty":
        return "recharge"
    if obs["gate_hint"] == "closed":
        return "open_gate"
    if obs["stock_hint"] == "empty":
        return "replenish"
    if obs["stability_hint"] == "fragile":
        return "stabilize"
    if obs["stock_hint"] in ("some","many"):
        return "acquire"
    return "probe"

def simulate_episode(regime: str, steps: int=20, seed: int=0, exploration: float=0.60) -> Dict[str, Any]:
    rng = random.Random(seed)
    params = regime_params(regime)
    state = _initial_state(rng, regime)
    obs = observe_world(state, "start", params, seed=rng.randrange(10**9))
    events = []
    for t in range(steps):
        before = state
        obs_before = dict(obs)
        action = choose_action(obs_before, rng, exploration=exploration)
        after_action, cwb = apply_cwb_action(before, action, params, seed=rng.randrange(10**9))
        after_world = apply_exogenous_dynamics(after_action, params, seed=rng.randrange(10**9))
        outcome = cwb["outcome_presentation"]["outcome"]
        obs_after = observe_world(
            after_world, outcome, params, seed=rng.randrange(10**9), probe_bonus=(action=="probe")
        )
        world_operator = (
            cwb["world_operator_invocation"]["operator"]
            if cwb["world_operator_invocation"] is not None
            else "CWB.DENIED"
        )
        event = {
            "step": t,
            "regime": regime,
            "hidden_state_before": asdict(before),
            "observation_before": obs_before,
            "action": action,
            "cognitive_action_chain": [
                "COG-ACT-001","COG-ACT-002","COG-ACT-003",
                "COG-ACT-004","COG-ACT-005","COG-ACT-006"
            ],
            "cwb_chain": ["CWB-001","CWB-002","CWB-003","CWB-004","CWB-005"],
            **cwb,
            "hidden_state_after": asdict(after_world),
            "observation_after": obs_after,
        }
        event["mwt_event"] = {
            "observer": "synthetic_cognitive_observer",
            "context": {"regime": regime, "step": t},
            "operator": world_operator,
            "inputs": {
                "presentation_before": obs_before,
                "action_request": cwb["action_request"],
            },
            "outputs": {
                "presentation_after": obs_after,
                "outcome": cwb["outcome_presentation"],
            },
            "history_link": {
                "episode_id": f"{regime}:{seed}",
                "previous_step": t-1 if t > 0 else None,
            },
            "certificate": {
                "authorization": cwb["authorization"],
                "authorization_reason": cwb["authorization_reason"],
                "world_transition_committed": cwb["world_transition"]["committed"],
            },
        }
        events.append(event)
        state, obs = after_world, obs_after
    return {
        "episode_id": f"{regime}:{seed}",
        "regime": regime,
        "generation_policy": {
            "uses_human_family_prefix": False,
            "uses_hidden_state_for_action_choice": False,
            "behavior_exploration_probability": exploration,
            "cwb_required": True,
        },
        "events": events,
    }

def split_episodes(episodes: List[Dict[str,Any]], seed: int, train_frac: float=.70, val_frac: float=.15):
    eps = list(episodes)
    rng = random.Random(seed)
    rng.shuffle(eps)
    n = len(eps)
    a = int(n*train_frac)
    b = a + int(n*val_frac)
    return {"train":eps[:a], "validation":eps[a:b], "test":eps[b:]}

def obs_key(obs: Dict[str,str]) -> Tuple[str,...]:
    return tuple(obs[f] for f in OBS_FIELDS)

def hidden_key(state: Dict[str,Any]) -> Tuple[Any,...]:
    return (state["stock"], state["gate_open"], state["stable"], state["energy"])

def _context(event: Dict[str,Any], mode: str, state_map=None):
    if mode == "passive_obs":
        return ("obs",) + obs_key(event["observation_before"])
    if mode == "obs_action":
        return ("obsact",) + obs_key(event["observation_before"]) + (event["action"],)
    if mode == "hidden_action":
        return ("hidden",) + hidden_key(event["hidden_state_before"]) + (event["action"],)
    if mode == "capis_action":
        sid = state_map.get(obs_key(event["observation_before"]), -1)
        return ("capis", sid, event["action"])
    raise ValueError(mode)

def _iter_events(episodes):
    for ep in episodes:
        for e in ep["events"]:
            yield e

def fit_factorized_model(episodes, context_mode: str, state_map=None):
    counts = defaultdict(lambda: {f: Counter() for f in OBS_FIELDS})
    action_counts = defaultdict(lambda: {f: Counter() for f in OBS_FIELDS})
    global_counts = {f: Counter() for f in OBS_FIELDS}
    for e in _iter_events(episodes):
        c = _context(e, context_mode, state_map=state_map)
        a = e["action"]
        for f in OBS_FIELDS:
            v = e["observation_after"][f]
            counts[c][f][v] += 1
            action_counts[a][f][v] += 1
            global_counts[f][v] += 1
    return {
        "context_mode": context_mode,
        "counts": dict(counts),
        "action_counts": dict(action_counts),
        "global_counts": global_counts,
        "state_map": state_map,
    }

def _kt_prob(counter: Counter, value: str, field: str) -> float:
    vals = FIELD_VALUES[field]
    n = sum(counter.values())
    k = len(vals)
    return (counter[value] + 0.5) / (n + 0.5*k)

def score_factorized_model(model, episodes, context_mode: str=None, state_map=None):
    mode = context_mode or model["context_mode"]
    smap = state_map if state_map is not None else model.get("state_map")
    bits = 0.0
    n = 0
    context_backoff = 0
    for e in _iter_events(episodes):
        c = _context(e, mode, state_map=smap)
        a = e["action"]
        field_counts = model["counts"].get(c)
        if field_counts is None:
            field_counts = model["action_counts"].get(a)
            context_backoff += 1
        if field_counts is None:
            field_counts = model["global_counts"]
        for f in OBS_FIELDS:
            p = _kt_prob(field_counts[f], e["observation_after"][f], f)
            bits -= math.log2(max(p, 1e-15))
        n += 1
    return {
        "bits": bits,
        "transition_count": n,
        "bits_per_transition": bits/n if n else float("inf"),
        "context_backoff_count": context_backoff,
        "context_backoff_rate": context_backoff/n if n else 0.0,
    }

def integrated_code_bits(model) -> float:
    # Dirichlet(1/2) integrated marginal code per context and factor.
    total = 0.0
    for _, fmap in model["counts"].items():
        for f, c in fmap.items():
            k = len(FIELD_VALUES[f])
            n = sum(c.values())
            logp = math.lgamma(k/2) - math.lgamma(n+k/2)
            for v in FIELD_VALUES[f]:
                logp += math.lgamma(c[v]+0.5) - math.lgamma(0.5)
            total += -logp/math.log(2)
    return total

def _signature_counts(episodes):
    data = defaultdict(lambda: defaultdict(lambda: {f: Counter() for f in OBS_FIELDS}))
    support = Counter()
    action_support = defaultdict(Counter)
    for e in _iter_events(episodes):
        o = obs_key(e["observation_before"])
        a = e["action"]
        support[o] += 1
        action_support[o][a] += 1
        for f in OBS_FIELDS:
            data[o][a][f][e["observation_after"][f]] += 1
    return data, support, action_support

def _js_counter(c1: Counter, c2: Counter, field: str) -> float:
    vals = FIELD_VALUES[field]
    p = [_kt_prob(c1, v, field) for v in vals]
    q = [_kt_prob(c2, v, field) for v in vals]
    m = [(x+y)/2 for x,y in zip(p,q)]
    def kl(a,b):
        return sum(x*math.log2(x/y) for x,y in zip(a,b) if x>0 and y>0)
    return 0.5*kl(p,m)+0.5*kl(q,m)

def _obs_distance(o1, o2, data, action_support, min_action_support: int) -> float:
    vals = []
    for a in ACTIONS:
        if action_support[o1][a] < min_action_support or action_support[o2][a] < min_action_support:
            continue
        for f in OBS_FIELDS:
            vals.append(_js_counter(data[o1][a][f], data[o2][a][f], f))
    if not vals:
        return 1.0
    return sum(vals)/len(vals)

def prepare_capis_data(episodes, min_distance_support: int=4):
    data, support, action_support = _signature_counts(episodes)
    contexts = sorted(
        [o for o,n in support.items() if n >= min_distance_support],
        key=lambda x:(-support[x], x)
    )
    min_action_support = 2
    distances = {}
    for i,o1 in enumerate(contexts):
        distances[(o1,o1)] = 0.0
        for o2 in contexts[i+1:]:
            d = _obs_distance(o1,o2,data,action_support,min_action_support)
            distances[(o1,o2)] = d
            distances[(o2,o1)] = d
    return {
        "data":data,
        "support":support,
        "action_support":action_support,
        "contexts":contexts,
        "distances":distances,
        "episodes":episodes,
    }

def _fit_capis_prepared(prepared, js_threshold: float=0.12, min_support: int=8):
    support = prepared["support"]
    contexts = [o for o in prepared["contexts"] if support[o] >= min_support]
    distances = prepared["distances"]
    state_map = {}
    representatives = []
    members = []
    for o in contexts:
        best = None
        bestd = float("inf")
        for sid, rep in enumerate(representatives):
            d = distances.get((o,rep), 1.0)
            if d < bestd:
                bestd, best = d, sid
        if best is not None and bestd <= js_threshold:
            state_map[o] = best
            members[best].append(o)
        else:
            sid = len(representatives)
            representatives.append(o)
            members.append([o])
            state_map[o] = sid
    pred_model = fit_factorized_model(prepared["episodes"], "capis_action", state_map=state_map)
    return {
        "js_threshold": js_threshold,
        "min_support": min_support,
        "state_count": len(representatives),
        "observation_context_count": len(support),
        "modeled_observation_context_count": len(contexts),
        "rare_context_count": len(support)-len(contexts),
        "state_map": state_map,
        "representatives": representatives,
        "members": members,
        "prediction_model": pred_model,
    }

def fit_capis(episodes, js_threshold: float=0.12, min_support: int=8):
    prepared = prepare_capis_data(episodes)
    return _fit_capis_prepared(prepared, js_threshold=js_threshold, min_support=min_support)

def capis_structure_code_bits(model) -> float:
    n = max(1, model["modeled_observation_context_count"])
    k = max(1, model["state_count"])
    # Universal-ish integer cost + assignment cost + hyperparameter declaration.
    return math.log2(k+1) + n*math.log2(k+1) + 12.0

def capis_model_score(model, episodes):
    return score_factorized_model(
        model["prediction_model"], episodes, context_mode="capis_action", state_map=model["state_map"]
    )

def select_capis(train_episodes, validation_episodes,
                 thresholds=(0.04,0.08,0.12,0.18,0.25),
                 supports=(4,8,16)):
    candidates = []
    best = None
    prepared = prepare_capis_data(train_episodes, min_distance_support=min(supports))
    for th in thresholds:
        for sup in supports:
            m = _fit_capis_prepared(prepared, js_threshold=th, min_support=sup)
            train_bits = integrated_code_bits(m["prediction_model"])
            val = capis_model_score(m, validation_episodes)
            structure = capis_structure_code_bits(m)
            score = train_bits + val["bits"] + structure
            rec = {
                "js_threshold": th,
                "min_support": sup,
                "state_count": m["state_count"],
                "observation_context_count": m["observation_context_count"],
                "modeled_observation_context_count": m["modeled_observation_context_count"],
                "train_integrated_bits": train_bits,
                "validation_bits": val["bits"],
                "validation_bits_per_transition": val["bits_per_transition"],
                "structure_code_bits": structure,
                "selection_mdl_bits": score,
            }
            candidates.append(rec)
            key=(score,m["state_count"],th,sup)
            if best is None or key < best[0]:
                best=(key,m)
    return {"selected_model":best[1],"candidate_table":candidates}


def score_capis_with_action_sequence(capis, episodes, actions):
    model = capis["prediction_model"]
    smap = capis["state_map"]
    bits = 0.0
    n = 0
    backoff = 0
    i = 0
    for e in _iter_events(episodes):
        if i >= len(actions):
            raise ValueError("action sequence shorter than event count")
        a = actions[i]
        i += 1
        sid = smap.get(obs_key(e["observation_before"]), -1)
        c = ("capis", sid, a)
        field_counts = model["counts"].get(c)
        if field_counts is None:
            field_counts = model["action_counts"].get(a)
            backoff += 1
        if field_counts is None:
            field_counts = model["global_counts"]
        for f in OBS_FIELDS:
            p = _kt_prob(field_counts[f], e["observation_after"][f], f)
            bits -= math.log2(max(p, 1e-15))
        n += 1
    if i != len(actions):
        raise ValueError("action sequence longer than event count")
    return {
        "bits": bits,
        "transition_count": n,
        "bits_per_transition": bits/n if n else float("inf"),
        "context_backoff_count": backoff,
        "context_backoff_rate": backoff/n if n else 0.0,
    }

def shuffle_actions_in_events(episodes, seed: int):
    out = copy.deepcopy(episodes)
    actions = [e["action"] for ep in out for e in ep["events"]]
    rng = random.Random(seed)
    rng.shuffle(actions)
    i = 0
    for ep in out:
        for e in ep["events"]:
            e["action"] = actions[i]
            i += 1
    return out
