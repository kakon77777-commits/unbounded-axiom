from experiment.controlled_action_observation import (
    WorldState, WorldParams, ACTIONS, apply_cwb_action, observe_world,
    simulate_episode, split_episodes, fit_factorized_model, score_factorized_model,
    fit_capis, capis_model_score, select_capis, shuffle_actions_in_events,
    score_capis_with_action_sequence,
)

def test_cwb_denies_acquire_when_gate_closed():
    s = WorldState(stock=2, gate_open=False, stable=True, energy=2)
    ns, rec = apply_cwb_action(s, "acquire", WorldParams(), seed=1)
    assert rec["authorization"] == "Denied"
    assert rec["world_mutated"] is False
    assert ns == s

def test_cwb_commit_is_separate_from_action_request():
    s = WorldState(stock=1, gate_open=False, stable=True, energy=2)
    ns, rec = apply_cwb_action(s, "open_gate", WorldParams(open_success=1.0), seed=2)
    assert rec["action_request"]["action"] == "open_gate"
    assert rec["boundary_request"]["accepted"] is True
    assert rec["authorization"] == "Authorized"
    assert rec["world_operator_invocation"]["operator"] == "WORLD.open_gate"
    assert rec["world_transition"]["committed"] is True
    assert rec["outcome_presentation"]["outcome"] == "opened"
    assert ns.gate_open is True

def test_observation_is_not_hidden_state_identity():
    s = WorldState(stock=2, gate_open=True, stable=False, energy=2)
    obs = observe_world(s, "probe_ok", WorldParams(obs_noise=0.0), seed=3, probe_bonus=True)
    assert "stock_hint" in obs
    assert "stock" not in obs
    assert set(obs) == {"stock_hint","gate_hint","stability_hint","energy_hint","last_outcome"}

def test_episode_contains_cwb_and_presentation_events():
    ep = simulate_episode("normal", steps=12, seed=4)
    assert len(ep["events"]) == 12
    e = ep["events"][0]
    assert "hidden_state_before" in e
    assert "observation_before" in e
    assert "action_request" in e
    assert "authorization" in e
    assert "world_transition" in e
    assert "observation_after" in e

def test_split_episodes_is_deterministic_and_disjoint():
    eps = [simulate_episode("normal", steps=4, seed=i) for i in range(20)]
    a = split_episodes(eps, seed=7)
    b = split_episodes(eps, seed=7)
    assert [x["episode_id"] for x in a["test"]] == [x["episode_id"] for x in b["test"]]
    ids = [set(x["episode_id"] for x in a[k]) for k in ("train","validation","test")]
    assert not (ids[0] & ids[1] or ids[0] & ids[2] or ids[1] & ids[2])

def test_factorized_model_scores_finite():
    eps = [simulate_episode("normal", steps=10, seed=100+i) for i in range(30)]
    sp = split_episodes(eps, seed=8)
    m = fit_factorized_model(sp["train"], context_mode="obs_action")
    s = score_factorized_model(m, sp["validation"], context_mode="obs_action")
    assert s["transition_count"] > 0
    assert s["bits_per_transition"] > 0
    assert s["bits_per_transition"] < 100

def test_capis_merges_some_observations_and_maps_without_hidden_state():
    eps = [simulate_episode("normal", steps=14, seed=200+i) for i in range(80)]
    sp = split_episodes(eps, seed=9)
    model = fit_capis(sp["train"], js_threshold=0.12, min_support=6)
    assert model["state_count"] >= 1
    assert model["state_count"] < model["observation_context_count"]
    assert all("hidden" not in k.lower() for k in model.keys())

def test_capis_selector_has_no_test_argument():
    import inspect
    sig = inspect.signature(select_capis)
    assert "test_episodes" not in sig.parameters

def test_action_shuffle_changes_actions_but_not_observations():
    eps = [simulate_episode("normal", steps=8, seed=400+i) for i in range(12)]
    shuffled = shuffle_actions_in_events(eps, seed=11)
    orig_obs = [[e["observation_after"] for e in ep["events"]] for ep in eps]
    shuf_obs = [[e["observation_after"] for e in ep["events"]] for ep in shuffled]
    assert orig_obs == shuf_obs
    orig_actions = [e["action"] for ep in eps for e in ep["events"]]
    shuf_actions = [e["action"] for ep in shuffled for e in ep["events"]]
    assert sorted(orig_actions) == sorted(shuf_actions)
    assert orig_actions != shuf_actions


def test_trace_preserves_cwb_chain_and_mwt_event_separation():
    ep = simulate_episode("normal", steps=3, seed=123)
    e = ep["events"][0]
    assert e["cwb_chain"] == ["CWB-001","CWB-002","CWB-003","CWB-004","CWB-005"]
    m = e["mwt_event"]
    assert m["observer"] == "synthetic_cognitive_observer"
    assert m["operator"].startswith("WORLD.") or m["operator"] == "CWB.DENIED"
    assert m["inputs"]["presentation_before"] == e["observation_before"]
    assert m["outputs"]["presentation_after"] == e["observation_after"]
    assert m["certificate"]["authorization"] == e["authorization"]


def test_action_override_scorer_matches_normal_score_for_original_actions():
    eps = [simulate_episode("normal", steps=8, seed=800+i) for i in range(40)]
    sp = split_episodes(eps, seed=21)
    capis = fit_capis(sp["train"], js_threshold=0.12, min_support=4)
    actions = [e["action"] for ep in sp["test"] for e in ep["events"]]
    a = capis_model_score(capis, sp["test"])
    b = score_capis_with_action_sequence(capis, sp["test"], actions)
    assert abs(a["bits_per_transition"] - b["bits_per_transition"]) < 1e-12
