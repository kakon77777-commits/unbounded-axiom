from __future__ import annotations

import csv
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path

from experiment.controlled_action_observation import (
    ACTIONS, OBS_FIELDS, FIELD_VALUES,
    simulate_episode, split_episodes,
    fit_factorized_model, score_factorized_model, integrated_code_bits,
    select_capis, capis_model_score, capis_structure_code_bits,
    shuffle_actions_in_events, obs_key, score_capis_with_action_sequence,
)

REGIMES = ("normal","noisy_observation","volatile_world","low_energy","access_fault","mixed")
COUNTS = {
    "normal": 1200,
    "noisy_observation": 400,
    "volatile_world": 400,
    "low_energy": 400,
    "access_fault": 400,
    "mixed": 400,
}
STEPS = 20
EXPLORATION = 0.65
SEEDS = {
    "normal": 11001,
    "noisy_observation": 11101,
    "volatile_world": 11201,
    "low_energy": 11301,
    "access_fault": 11401,
    "mixed": 11501,
}

def write_jsonl(path: Path, episodes):
    with path.open("w", encoding="utf-8") as f:
        for ep in episodes:
            f.write(json.dumps(ep, ensure_ascii=False, separators=(",",":")) + "\n")

def corpus(regime):
    root = SEEDS[regime]
    return [simulate_episode(regime, steps=STEPS, seed=root+i, exploration=EXPLORATION) for i in range(COUNTS[regime])]

def baseline_bundle(train, val, test, capis_selection):
    passive = fit_factorized_model(train, "passive_obs")
    exact = fit_factorized_model(train, "obs_action")
    oracle = fit_factorized_model(train, "hidden_action")
    capis = capis_selection["selected_model"]

    return {
        "passive_obs": {
            "train_integrated_bits": integrated_code_bits(passive),
            "validation": score_factorized_model(passive,val,"passive_obs"),
            "test": score_factorized_model(passive,test,"passive_obs"),
        },
        "exact_obs_action": {
            "train_integrated_bits": integrated_code_bits(exact),
            "validation": score_factorized_model(exact,val,"obs_action"),
            "test": score_factorized_model(exact,test,"obs_action"),
        },
        "hidden_state_action_oracle": {
            "train_integrated_bits": integrated_code_bits(oracle),
            "validation": score_factorized_model(oracle,val,"hidden_action"),
            "test": score_factorized_model(oracle,test,"hidden_action"),
            "deployable": False,
        },
        "capis": {
            "selected": {
                "js_threshold": capis["js_threshold"],
                "min_support": capis["min_support"],
                "state_count": capis["state_count"],
                "observation_context_count": capis["observation_context_count"],
                "modeled_observation_context_count": capis["modeled_observation_context_count"],
                "rare_context_count": capis["rare_context_count"],
                "structure_code_bits": capis_structure_code_bits(capis),
            },
            "test": capis_model_score(capis, test),
        },
    }

def state_map_serializable(capis):
    return [
        {"observation": list(k), "state": v}
        for k,v in sorted(capis["state_map"].items(), key=lambda kv:(kv[1],kv[0]))
    ]

def action_permutation_test(capis, test, permutations=100, seed=11991):
    observed = capis_model_score(capis, test)["bits_per_transition"]
    original_actions=[e["action"] for ep in test for e in ep["events"]]
    vals=[]
    rng=random.Random(seed)
    for _ in range(permutations):
        actions=list(original_actions)
        rng.shuffle(actions)
        vals.append(score_capis_with_action_sequence(capis,test,actions)["bits_per_transition"])
    lower=(1+sum(v <= observed for v in vals))/(permutations+1)
    return {
        "permutations":permutations,
        "observed_bits_per_transition":observed,
        "permuted_mean_bits_per_transition":sum(vals)/len(vals),
        "permuted_min_bits_per_transition":min(vals),
        "permuted_max_bits_per_transition":max(vals),
        "lower_tail_empirical_p":lower,
    }

def per_action_bits(model, episodes, mode, state_map=None):
    out={}
    for a in ACTIONS:
        sub=[]
        for ep in episodes:
            ne={**ep, "events":[e for e in ep["events"] if e["action"]==a]}
            if ne["events"]:
                sub.append(ne)
        if sub:
            out[a]=score_factorized_model(model,sub,mode,state_map=state_map)["bits_per_transition"]
    return out

def entropy(labels):
    n=len(labels)
    c=Counter(labels)
    return -sum((v/n)*math.log2(v/n) for v in c.values()) if n else 0.0

def mutual_info(xs,ys):
    n=len(xs)
    cx=Counter(xs); cy=Counter(ys); cxy=Counter(zip(xs,ys))
    mi=0.0
    for (x,y),v in cxy.items():
        p=v/n; px=cx[x]/n; py=cy[y]/n
        mi += p*math.log2(p/(px*py))
    return mi

def nmi(xs,ys):
    mi=mutual_info(xs,ys)
    hx=entropy(xs); hy=entropy(ys)
    return 2*mi/(hx+hy) if hx+hy else 1.0

def hidden_control_key(h):
    return (int(h["stock"]>0), bool(h["gate_open"]), bool(h["stable"]), int(h["energy"]>0))

def capis_hidden_relation(capis,test):
    xs=[]; ys=[]
    for ep in test:
        for e in ep["events"]:
            xs.append(capis["state_map"].get(obs_key(e["observation_before"]),-1))
            ys.append(hidden_control_key(e["hidden_state_before"]))
    return {
        "event_count":len(xs),
        "normalized_mutual_information":nmi(xs,ys),
        "capis_entropy_bits":entropy(xs),
        "hidden_control_entropy_bits":entropy(ys),
        "mutual_information_bits":mutual_info(xs,ys),
    }

def adapted_regime_run(episodes, seed):
    sp=split_episodes(episodes,seed=seed)
    sel=select_capis(sp["train"],sp["validation"])
    bundle=baseline_bundle(sp["train"],sp["validation"],sp["test"],sel)
    bundle["split"]={k:len(v) for k,v in sp.items()}
    return bundle, sel["selected_model"]

def leave_one_regime_out(all_eps, heldout, seed):
    train_pool=[]
    for r,eps in all_eps.items():
        if r != heldout:
            train_pool.extend(eps)
    # train/validation only on non-heldout regimes.
    sp=split_episodes(train_pool,seed=seed,train_frac=.82,val_frac=.18)
    train=sp["train"]; val=sp["validation"]
    test=all_eps[heldout]
    sel=select_capis(train,val)
    capis=sel["selected_model"]
    exact=fit_factorized_model(train,"obs_action")
    passive=fit_factorized_model(train,"passive_obs")
    return {
        "heldout_regime":heldout,
        "train_episode_count":len(train),
        "validation_episode_count":len(val),
        "test_episode_count":len(test),
        "selected_capis":{
            "js_threshold":capis["js_threshold"],
            "min_support":capis["min_support"],
            "state_count":capis["state_count"],
        },
        "passive_obs_bits":score_factorized_model(passive,test,"passive_obs")["bits_per_transition"],
        "exact_obs_action_bits":score_factorized_model(exact,test,"obs_action")["bits_per_transition"],
        "capis_bits":capis_model_score(capis,test)["bits_per_transition"],
        "capis_gain_over_exact":score_factorized_model(exact,test,"obs_action")["bits_per_transition"]-capis_model_score(capis,test)["bits_per_transition"],
        "capis_context_backoff_rate":capis_model_score(capis,test)["context_backoff_rate"],
    }

def main(out_dir: Path):
    out_dir.mkdir(parents=True,exist_ok=True)
    all_eps={}
    for r in REGIMES:
        eps=corpus(r)
        all_eps[r]=eps
        write_jsonl(out_dir/f"controlled_{r}_episodes_v0.11.jsonl",eps)

    # Main normal.
    normal_split=split_episodes(all_eps["normal"],seed=11601)
    normal_sel=select_capis(normal_split["train"],normal_split["validation"])
    capis=normal_sel["selected_model"]
    main_bundle=baseline_bundle(
        normal_split["train"],normal_split["validation"],normal_split["test"],normal_sel
    )
    main_bundle["split"]={k:len(v) for k,v in normal_split.items()}
    main_bundle["capis"]["candidate_table"]=normal_sel["candidate_table"]
    main_bundle["capis"]["state_map"]=state_map_serializable(capis)
    main_bundle["capis"]["action_permutation_test"]=action_permutation_test(capis,normal_split["test"])
    main_bundle["capis"]["hidden_control_relation"]=capis_hidden_relation(capis,normal_split["test"])
    main_bundle["per_action_test_bits"]={
        "passive_obs":per_action_bits(
            fit_factorized_model(normal_split["train"],"passive_obs"),
            normal_split["test"],"passive_obs"
        ),
        "exact_obs_action":per_action_bits(
            fit_factorized_model(normal_split["train"],"obs_action"),
            normal_split["test"],"obs_action"
        ),
        "capis":per_action_bits(
            capis["prediction_model"], normal_split["test"],"capis_action",capis["state_map"]
        ),
    }
    b=main_bundle
    b["comparisons_positive_is_better"]={
        "action_gain_exact_over_passive":
            b["passive_obs"]["test"]["bits_per_transition"]-b["exact_obs_action"]["test"]["bits_per_transition"],
        "capis_gain_over_exact":
            b["exact_obs_action"]["test"]["bits_per_transition"]-b["capis"]["test"]["bits_per_transition"],
        "capis_gain_over_passive":
            b["passive_obs"]["test"]["bits_per_transition"]-b["capis"]["test"]["bits_per_transition"],
        "oracle_gain_over_capis":
            b["capis"]["test"]["bits_per_transition"]-b["hidden_state_action_oracle"]["test"]["bits_per_transition"],
    }

    # Normal CAPIS zero-shot across stress regimes.
    normal_exact=fit_factorized_model(normal_split["train"],"obs_action")
    normal_passive=fit_factorized_model(normal_split["train"],"passive_obs")
    zero_shot={}
    for r in REGIMES:
        zero_shot[r]={
            "passive_obs_bits":score_factorized_model(normal_passive,all_eps[r],"passive_obs")["bits_per_transition"],
            "exact_obs_action_bits":score_factorized_model(normal_exact,all_eps[r],"obs_action")["bits_per_transition"],
            "capis_bits":capis_model_score(capis,all_eps[r])["bits_per_transition"],
            "capis_backoff_rate":capis_model_score(capis,all_eps[r])["context_backoff_rate"],
        }

    # Regime-adapted.
    adapted={}
    for i,r in enumerate(REGIMES):
        bundle,_=adapted_regime_run(all_eps[r],seed=11701+i*17)
        adapted[r]=bundle

    # Leave-one-regime-out.
    looro=[]
    for i,r in enumerate(REGIMES):
        looro.append(leave_one_regime_out(all_eps,r,seed=11801+i*19))

    results={
        "experiment":"CDD Phase 0.11 Controlled Action-Observation Predictive Interface",
        "version":"0.11",
        "date":"2026-08-20",
        "methodological_status":"synthetic_controlled_cwb_mwt_action_observation_predictive_interface_not_exact_psr_pomdp_or_world_ontology",
        "world_regimes":list(REGIMES),
        "actions":list(ACTIONS),
        "normal_episode_count":COUNTS["normal"],
        "stress_episode_count_each":COUNTS["noisy_observation"],
        "steps_per_episode":STEPS,
        "behavior_exploration_probability":EXPLORATION,
        "main_normal":main_bundle,
        "normal_selected_zero_shot":zero_shot,
        "regime_adapted":adapted,
        "leave_one_regime_out":looro,
        "domain_promotion_count":0,
        "exact_psr_claim":False,
        "world_ontology_claim":False,
    }
    (out_dir/"phase11_experiment_results.json").write_text(
        json.dumps(results,ensure_ascii=False,indent=2),encoding="utf-8"
    )
    (out_dir/"selected_capis_model_v0.11.json").write_text(
        json.dumps({
            "js_threshold":capis["js_threshold"],
            "min_support":capis["min_support"],
            "state_count":capis["state_count"],
            "observation_context_count":capis["observation_context_count"],
            "state_map":state_map_serializable(capis),
        },ensure_ascii=False,indent=2),encoding="utf-8"
    )
    (out_dir/"leave_one_regime_out_v0.11.json").write_text(
        json.dumps(looro,ensure_ascii=False,indent=2),encoding="utf-8"
    )

    with (out_dir/"regime_summary_v0.11.csv").open("w",encoding="utf-8",newline="") as f:
        w=csv.writer(f)
        w.writerow(["regime","zero_passive","zero_exact_action","zero_capis","zero_capis_backoff","adapted_passive","adapted_exact_action","adapted_capis","adapted_capis_states"])
        for r in REGIMES:
            w.writerow([
                r,
                zero_shot[r]["passive_obs_bits"],
                zero_shot[r]["exact_obs_action_bits"],
                zero_shot[r]["capis_bits"],
                zero_shot[r]["capis_backoff_rate"],
                adapted[r]["passive_obs"]["test"]["bits_per_transition"],
                adapted[r]["exact_obs_action"]["test"]["bits_per_transition"],
                adapted[r]["capis"]["test"]["bits_per_transition"],
                adapted[r]["capis"]["selected"]["state_count"],
            ])

    return results

if __name__=="__main__":
    base=Path(__file__).resolve().parents[1]
    results=main(base/"results")
    print(json.dumps({
        "main":results["main_normal"]["comparisons_positive_is_better"],
        "main_bits":{
            "passive":results["main_normal"]["passive_obs"]["test"]["bits_per_transition"],
            "exact_action":results["main_normal"]["exact_obs_action"]["test"]["bits_per_transition"],
            "capis":results["main_normal"]["capis"]["test"]["bits_per_transition"],
            "oracle":results["main_normal"]["hidden_state_action_oracle"]["test"]["bits_per_transition"],
        },
        "capis_states":results["main_normal"]["capis"]["selected"]["state_count"],
        "action_perm":results["main_normal"]["capis"]["action_permutation_test"],
        "looro":[
            (x["heldout_regime"],x["exact_obs_action_bits"],x["capis_bits"],x["capis_gain_over_exact"])
            for x in results["leave_one_regime_out"]
        ],
    },ensure_ascii=False,indent=2))
