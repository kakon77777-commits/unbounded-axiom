# Phase 0.11 Runtime Contract

1. `World`, hidden simulator state, observer Presentation, CAPIS state, ActionRequest, BoundaryRequest, WorldOperatorInvocation, WorldTransition, and OutcomePresentation are distinct types.
2. Cognitive operators MUST NOT directly mutate World.
3. Every external action MUST traverse CWB acceptance, authorization, mapping, commit, and outcome-presentation stages.
4. A denied request MUST NOT commit a World transition.
5. Hidden simulator state MUST NOT be provided to the behavior policy or CAPIS.
6. CAPIS selection uses training plus validation only; test data MUST NOT select JS threshold or minimum support.
7. Human cognitive family labels and domain seeds MUST NOT generate World transitions.
8. Action labels are first-class predictive inputs and MUST NOT be inferred retroactively from outcomes.
9. Action-shuffle tests MUST alter action labels only and preserve the observed future presentations being scored.
10. CAPIS is a finite one-step predictive quotient and MUST NOT be called an exact PSR, POMDP belief state, epsilon-transducer, exact causal state, bisimulation quotient, or World ontology.
11. Full MWT/CWB traces remain canonical evidence; compact analysis views are derived projections.
12. Compact views MUST preserve episode identity, order, observation-before, action, observation-after, and hidden state only when needed for oracle diagnostics.
13. The hidden-state oracle is diagnostic and non-deployable.
14. Cross-regime gains MUST report backoff rates.
15. No domain promotion is permitted from Phase 0.11 synthetic evidence.
