from pathlib import Path
import json, sys

base=Path(__file__).resolve().parent
issues=[]

required=[
 "Cognitive_Deconstruction_Domainization_Phase0_v0.11_ZH.md",
 "CONTROLLED_ACTION_PRESENTATION_INTERFACE_v0.1.md",
 "EXPERIMENT_DESIGN_v0.11.md",
 "RESEARCH_DECISION_LOG_v0.11.md",
 "RUNTIME_CONTRACT_v0.11.md",
 "DOMAIN_PROMOTION_GATE_v0.11.md",
 "EXTERNAL_RESEARCH_SEEDS_v0.11.md",
 "README.md",
 "experiment/controlled_action_observation.py",
 "experiment/run_phase11.py",
 "experiment/run_phase11_stages.py",
 "experiment/test_phase11.py",
 "results/phase11_experiment_results.json",
 "results/main_stage_v0.11.json",
 "results/normal_split_robustness_v0.11.json",
 "results/leave_one_regime_out_v0.11.json",
 "results/regime_summary_v0.11.csv",
 "results/capis_hidden_state_relation_v0.11.json",
 "results/selected_capis_model_v0.11.json",
 "inputs/cognitive_world_boundary_registry_v0.3.json",
 "inputs/MWT_v0.1_ZH.md",
]
for n in required:
    if not (base/n).exists(): issues.append(f"missing required file: {n}")

try:
    x=json.loads((base/"results/phase11_experiment_results.json").read_text(encoding="utf-8"))
    if x.get("domain_promotion_count")!=0: issues.append("domain promotion count must be zero")
    if x.get("exact_psr_claim") is not False: issues.append("exact PSR claim must be false")
    if x.get("world_ontology_claim") is not False: issues.append("world ontology claim must be false")
    main=x["main_normal"]
    if main["comparisons_positive_is_better"]["action_gain_exact_over_passive"]<=0:
        issues.append("action does not improve main over passive")
    if main["comparisons_positive_is_better"]["capis_gain_over_exact"]<=0:
        issues.append("CAPIS does not improve main over exact obs+action")
    if main["hidden_state_action_oracle"]["test"]["bits_per_transition"] >= main["capis"]["test"]["bits_per_transition"]:
        issues.append("hidden oracle is not better than CAPIS; expected diagnostic gap")
    if main["capis"]["action_permutation_test"]["permuted_mean_bits_per_transition"] <= main["capis"]["action_permutation_test"]["observed_bits_per_transition"]:
        issues.append("action shuffle null not worse")
    rob=x["normal_split_robustness"]
    if rob.get("positive_gain_count")!=5: issues.append("normal robustness positive gain != 5/5")
    if len(x.get("regime_adapted",{}))!=6: issues.append("regime adapted count != 6")
    if not all(
        b["exact_obs_action"]["test"]["bits_per_transition"] > b["capis"]["test"]["bits_per_transition"]
        for b in x.get("regime_adapted",{}).values()
    ):
        issues.append("not all regime-adapted CAPIS gains positive")
    lo=x.get("leave_one_regime_out",[])
    if len(lo)!=6: issues.append("leave-one-regime-out count != 6")
    if not all(r["capis_gain_over_exact"]>0 for r in lo):
        issues.append("not all leave-one-regime-out CAPIS gains positive")
    if any(r["capis_context_backoff_rate"]>=0.01 for r in lo):
        issues.append("unexpected high leave-one-regime-out CAPIS backoff")
except Exception as e:
    issues.append(f"results parse/invariant failure: {e}")

try:
    rel=json.loads((base/"results/capis_hidden_state_relation_v0.11.json").read_text(encoding="utf-8"))
    if not (rel["observed_nmi_full_hidden_state"] > rel["permuted_mean_nmi"]):
        issues.append("CAPIS-hidden NMI not above permutation mean")
    if not (rel["observed_nmi_full_hidden_state"] < 0.95):
        issues.append("CAPIS suspiciously close to hidden-state identity")
except Exception as e:
    issues.append(f"hidden relation failure: {e}")

# Full trace and compact-projection invariants.
expected={"normal":1200,"noisy_observation":400,"volatile_world":400,"low_energy":400,"access_fault":400,"mixed":400}
for regime,nexp in expected.items():
    full=base/f"results/controlled_{regime}_episodes_v0.11.jsonl"
    compact=base/f"results/compact_{regime}_episodes_v0.11.jsonl"
    if not full.exists() or not compact.exists():
        issues.append(f"missing full/compact corpus {regime}")
        continue
    nfull=0; ncompact=0
    full_first=None; compact_first=None
    with full.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip(): continue
            ep=json.loads(line); nfull+=1
            gp=ep.get("generation_policy",{})
            if gp.get("uses_human_family_prefix") is not False:
                issues.append(f"{regime}: family label leakage")
                break
            if gp.get("uses_hidden_state_for_action_choice") is not False:
                issues.append(f"{regime}: hidden state used for action policy")
                break
            for e in ep.get("events",[]):
                if e.get("cwb_chain") != ["CWB-001","CWB-002","CWB-003","CWB-004","CWB-005"]:
                    issues.append(f"{regime}: bad CWB chain")
                    break
                if e.get("authorization")=="Denied" and e.get("world_transition",{}).get("committed"):
                    issues.append(f"{regime}: denied action committed World")
                    break
                if "mwt_event" not in e:
                    issues.append(f"{regime}: missing MWT event")
                    break
            if full_first is None: full_first=ep
    with compact.open(encoding="utf-8") as f:
        for line in f:
            if not line.strip(): continue
            ep=json.loads(line); ncompact+=1
            if compact_first is None: compact_first=ep
    if nfull!=nexp: issues.append(f"{regime}: full count {nfull} != {nexp}")
    if ncompact!=nexp: issues.append(f"{regime}: compact count {ncompact} != {nexp}")
    if full_first and compact_first:
        if full_first["episode_id"] != compact_first["episode_id"]:
            issues.append(f"{regime}: compact episode identity mismatch")
        if len(full_first["events"]) != len(compact_first["events"]):
            issues.append(f"{regime}: compact event count mismatch")
        else:
            for fe,ce in zip(full_first["events"],compact_first["events"]):
                for key in ("observation_before","action","observation_after","hidden_state_before"):
                    if fe[key] != ce[key]:
                        issues.append(f"{regime}: compact projection mismatch {key}")
                        break

# Canonical markdown delimiters.
for p in base.glob("*.md"):
    text=p.read_text(encoding="utf-8")
    for bad in (r"\(",r"\)",r"\[",r"\]"):
        if bad in text: issues.append(f"noncanonical math delimiter {bad} in {p.name}")
    bad_math=set("→←↔⇒⇔≠≤≥∞∈∉∅⊂⊆⊃⊇≈∝∑∏√")
    found=sorted(ch for ch in bad_math if ch in text)
    if found: issues.append(f"unicode math symbols in {p.name}: {''.join(found)}")

main_text=(base/"Cognitive_Deconstruction_Domainization_Phase0_v0.11_ZH.md").read_text(encoding="utf-8")
for forbidden in ("DomainPromotionCount=1","CAPIS=HiddenWorldState","CAPIS=exact PSR","CAPIS is an exact PSR"):
    if forbidden in main_text: issues.append(f"forbidden overclaim: {forbidden}")

status="PASS" if not issues else "FAIL"
report=[
 f"STATUS: {status}",
 "version: 0.11",
 "world_regime_count: 6",
 "action_count: 6",
 "normal_episode_count: 1200",
 "stress_episode_count_each: 400",
 "normal_robustness_positive_gain: 5/5",
 "regime_adapted_positive_gain: 6/6",
 "leave_one_regime_out_positive_gain: 6/6",
 "domain_promotion_count: 0",
 f"issues: {len(issues)}",
]
report.extend(f"- {i}" for i in issues)
(base/"VALIDATION.txt").write_text("\n".join(report)+"\n",encoding="utf-8")
print("\n".join(report))
sys.exit(0 if not issues else 1)
