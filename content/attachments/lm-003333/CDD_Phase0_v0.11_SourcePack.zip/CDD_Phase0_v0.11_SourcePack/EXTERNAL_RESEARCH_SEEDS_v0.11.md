# External Research Seeds v0.11

These works are methodological seeds and comparison points only. CDD Phase 0.11 does not claim to reproduce their exact theories.

## Predictive State Representations

Littman, Sutton, and Singh proposed representing dynamical-system state through multi-step, action-conditional predictions of future observations.

Phase 0.11 uses the action-conditional principle as a seed, but CAPIS is only a one-step finite approximation over observer Presentations.

## POMDPs

POMDP work formalizes control in partially observable stochastic environments and distinguishes underlying state from what an agent can observe.

Phase 0.11 therefore keeps hidden synthetic World state separate from Presentation and from predictive interface state.

## Bisimulation / behavioral state aggregation

Bisimulation metrics for MDPs motivate comparing states by behaviorally relevant consequences under actions rather than raw descriptive identity.

CAPIS uses a much simpler finite action-conditioned future-Presentation similarity and is not an exact bisimulation quotient.

## Epsilon-transducers

Computational mechanics of input-output processes extends predictive-state ideas to stochastic input-output mappings and memoryful channels.

Phase 0.11 is conceptually adjacent because it studies ActionRequest-to-Presentation mappings, but it does not reconstruct an epsilon-transducer.

## Internal contribution boundary

The CDD/MWT/CWB contribution in this SourcePack is the explicit integration:

$$
Presentation
\\rightarrow
ActionRequest
\\rightarrow
CWB
\\rightarrow
WorldTransition
\\rightarrow
Presentation
$$

with CAPIS as a finite controlled predictive interface candidate.
