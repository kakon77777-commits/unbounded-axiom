# Domain Promotion Gate v0.11

$$
\boxed{
DomainPromotionCount=0
}
$$

Phase 0.11 adds **Controlled Predictive Interface Candidate** status, not domain promotion.

## Positive evidence

- CAPIS beats exact Presentation+action in normal robustness: $5/5$.
- CAPIS beats exact Presentation+action in regime-adapted runs: $6/6$.
- CAPIS beats exact Presentation+action in leave-one-regime-out: $6/6$.
- Main action-shuffle test strongly degrades prediction.
- CAPIS has non-random relation to hidden World state.

## Promotion blockers

1. World is synthetic.
2. Action set is designed by the experiment.
3. Predictive signature is one-step only.
4. Future Presentation distribution is factorized.
5. CAPIS-hidden oracle gap remains approximately 1.2417 bits/transition.
6. No multi-step core-test reconstruction.
7. No external human/AI agent replication.
8. Real operator/action annotation reliability is not yet established at required level.

A future promoted domain would need controlled multi-step predictive equivalence, replayable external traces, cross-agent replication, clear legality/provenance boundaries, and complexity-adjusted held-out value.
