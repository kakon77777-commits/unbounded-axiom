# Controlled Action-Presentation Interface v0.1
## CAPIS and the First Bidirectional CDD–MWT World Coupling

**Status:** Candidate theory  
**Date:** 2026-08-20

# 1. Core loop

$$
\boxed{
P_t
\rightarrow
A_t^{request}
\rightarrow
CWB
\rightarrow
\mathbf W_{t+1}
\rightarrow
P_{t+1}.
}
$$

where:

- $P_t=\rho_{O,t}(\mathbf W_t)$ is an observer-relative Presentation;
- $A_t^{request}$ is cognitive intent translated into a world-facing request;
- CWB decides legality/authority and maps the request to a world-native operator;
- World mutation occurs only at the CWB commit stage;
- the result returns as a new Presentation.

# 2. Controlled predictive signature

For presentation $p$:

$$
\Phi_{ctrl}(p)
=
\bigoplus_{a\in\mathcal A}
P(P_{t+1}\mid P_t=p,A_t=a,\mathrm{CWB}).
$$

CAPIS is a finite approximation to the quotient induced by similarity of these signatures.

# 3. Empirical synthetic signal

Normal five-split robustness:

$$
\boxed{
CAPIS<ExactPresentationAction
\quad5/5
}
$$

with mean gain:

$$
0.1091
\text{ bits/transition}.
$$

Leave-one-regime-out:

$$
\boxed{
6/6
}
$$

positive, mean:

$$
0.0533.
$$

Action-label permutation destroys prediction, supporting the interpretation that the state is controlled/action-conditioned rather than passive.

# 4. Non-identity

$$
\boxed{
CAPIS\neq HiddenWorldState.
}
$$

The hidden oracle remains better by about:

$$
1.2417
$$

bits/transition in Main normal.

CAPIS-hidden full-state NMI is:

$$
0.5503,
$$

which is non-random but far from identity.

# 5. Domain interpretation

CAPIS suggests a new class of domain candidate:

$$
\boxed{
\text{Domain as action-conditioned predictive equivalence over World Presentations}
}
$$

rather than:

$$
\text{Domain as a static topic label}.
$$

This is a candidate interface ontology, not a promoted world ontology.

# 6. Hard boundary

CAPIS is not an exact PSR, POMDP belief state, causal state, epsilon-transducer, or exact bisimulation quotient.

Its current evidence is synthetic, one-step, finite, and factorized.
