# CDD Phase 0 v0.11 SourcePack

Phase 0.11 implements the first explicit bidirectional CDD–MWT world coupling.

Core loop:

$$
\boxed{
Presentation_t
\rightarrow
ActionRequest_t
\rightarrow
CWB
\rightarrow
WorldTransition_t
\rightarrow
Presentation_{t+1}.
}
$$

It introduces **Controlled Action-Presentation Interface States (CAPIS)**.

Key synthetic results:

- Main passive: 5.7867 bits/transition
- Main exact Presentation+action: 3.9936
- Main CAPIS: 3.8866
- Hidden-state oracle: 2.6449
- Normal robustness CAPIS gain: 0.1091, positive 5/5
- Regime-adapted CAPIS gain: positive 6/6
- Leave-one-regime-out CAPIS gain: positive 6/6
- Domain promotion count: 0

Full MWT/CWB traces and compact analysis projections are both included. Full traces are canonical evidence; compact traces are derived analysis views.
