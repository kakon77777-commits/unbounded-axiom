---
name: gire
description: General-purpose evidence-grounded research orchestration for ambiguous, multi-step, or high-uncertainty tasks. Use when an agent must compile a goal, maintain explicit world-model, hypothesis, evidence, action, resource-risk, and governance states, choose tools or sub-agents, seek counterevidence, preserve provenance and failures, and produce traceable conclusions. Do not use for simple arithmetic, direct translation, pure rewriting, or a single stable fact lookup unless the task becomes investigative.
---

# GIRE - Global Intent Research Engine

GIRE turns an open-ended request into a traceable research process. It operationalizes GIPE as a tool-agnostic workflow. Use available tools; never invent access, evidence, execution, or background work.

## Core contract

Always preserve these distinctions:

- User goal is not world truth.
- Semantic relevance is not evidence support.
- Model recall is not external evidence.
- Inference is not observation.
- Formal validity is not empirical truth.
- Agreement among similar agents is not independent verification.
- Failure and counterevidence are research results, not noise to delete.
- A selected action remains the controller's responsibility even when proposed by a sub-agent.

Read [references/CORE_MODEL.md](references/CORE_MODEL.md) for the seven-layer state model and invariants.

## Trigger and non-trigger

Use GIRE when the task includes several of these:

- unknown or contested facts;
- multiple plausible hypotheses;
- evidence gathering or source comparison;
- tool, experiment, simulation, proof, or file inspection choices;
- a need to decide the next best research action;
- persistent uncertainty, conflicts, or delayed observations;
- multiple agents or delegated subtasks;
- meaningful cost, risk, permissions, or irreversible steps.

Do not invoke the full workflow for:

- elementary calculations;
- straightforward translation;
- pure rewriting or creative writing;
- a direct answer fully contained in user-provided text;
- a single low-stakes lookup with one authoritative source.

For borderline tasks, use `quick` mode rather than forcing a full research stack.

## Modes

Choose the smallest mode that preserves correctness:

- `quick`: one goal, few claims, one or two actions, concise evidence ledger.
- `standard`: explicit hypotheses, counterevidence, action ranking, traceable report.
- `deep`: persistent seven-layer state, multiple tools or agents, runtime re-planning.
- `closed-world`: sealed truth, independent oracle or judge, action budget, no answer leakage.

## Required workflow

### 1. Compile the goal contract

Translate the request into:

- objective;
- deliverable;
- constraints;
- evidence standard;
- permissions;
- budget or limits;
- stop conditions;
- explicitly forbidden goal changes.

Do not silently rewrite the user's goal. Clarify only when a missing fact makes execution materially impossible; otherwise use bounded assumptions and record them.

### 2. Initialize or load GIRE state

Use [templates/gire-state.json](templates/gire-state.json) or run:

```bash
python scripts/init_run.py --goal "<goal>" --mode standard --output gire-run.json
```

The canonical state has seven layers:

1. intent;
2. world model;
3. hypotheses;
4. evidence;
5. actions;
6. resources and risks;
7. agents and governance.

For small tasks, maintain this structure mentally or in a compact note. For multi-step tasks, persist it in JSON.

### 3. Separate claims by epistemic type

For every material claim, label the basis:

- `user_provided`;
- `direct_observation`;
- `external_source`;
- `tool_output`;
- `experiment`;
- `simulation`;
- `formal_result`;
- `inference`;
- `model_recall`.

Use the protocol in [references/EVIDENCE_PROTOCOL.md](references/EVIDENCE_PROTOCOL.md). Never upgrade `model_recall` or `inference` into verified external evidence.

### 4. Build competing hypotheses

Generate at least one alternative or null hypothesis when the task is genuinely uncertain. Avoid fake diversity: alternatives must predict different observations or suggest different actions.

For each hypothesis record:

- supporting evidence;
- counterevidence;
- unknowns;
- falsifiability;
- expected distinguishing observation;
- current status.

Allowed conclusion statuses:

- `well_supported`;
- `partially_supported`;
- `contradicted`;
- `insufficient_evidence`;
- `unresolved`.

### 5. Generate candidate actions

Candidate actions may include:

- search or browse;
- inspect a file or repository;
- calculate;
- query a database;
- compare sources;
- simulate;
- prove or formally check;
- design or run an experiment;
- ask a user, expert, or sub-agent;
- wait for a delayed observation;
- construct an artifact;
- stop and report a blocker.

Each candidate should state:

- expected information gain;
- falsification value;
- verification yield;
- source independence;
- goal fit;
- reversibility;
- cost;
- risk;
- required permission;
- expected observation.

Read [references/ACTION_ROUTING.md](references/ACTION_ROUTING.md) when choosing among several tools, computation styles, or phase machines.

### 6. Enforce hard constraints before scoring

Reject an action before ranking when any hard condition fails:

- unavailable tool or hardware;
- insufficient permission;
- prohibited or irreversible action without approval;
- missing required traceability;
- incompatible evidence or phase type;
- risk above the allowed threshold;
- inability to verify a critical result.

Never let speed, confidence, convenience, or low cost offset a failed hard condition.

### 7. Select the next action

Prefer actions that distinguish hypotheses, expose counterevidence, or resolve high-impact unknowns. Do not merely choose the action most likely to confirm the leading hypothesis.

For persisted states, rank actions with:

```bash
python scripts/rank_actions.py gire-run.json --policy config/default-policy.json
```

Treat the score as a transparent aid, not an authority. Review the breakdown and hard-filter results.

### 8. Execute and observe

Use only tools that actually exist in the environment. Before execution, record the expected observation. After execution, record:

- raw result or stable reference;
- source or tool;
- timestamp when relevant;
- observed result;
- difference from expectation;
- verification status;
- errors, failures, and limitations.

A failed action remains in the audit trail.

### 9. Update across layers

Update only the layers affected by the observation. Preserve old states or append an event; do not silently overwrite history.

Typical flow:

```text
intent -> candidate action -> execution -> observation
       -> evidence -> hypothesis -> world model -> next action
```

A world-model update must cite evidence. An intent update requires authority and a recorded reason.

### 10. Re-plan or stop

Re-plan when:

- a hypothesis is contradicted;
- the task changes phase;
- risk or resource state changes;
- a tool fails;
- evidence conflict rises;
- a higher verification level becomes necessary.

Stop when a recorded stop condition is met, the action budget is exhausted, further actions have negligible value, or a blocker cannot be resolved with available authority and tools.

### 11. Produce the output contract

The final response or artifact must contain:

1. direct answer or result;
2. conclusion status and confidence boundary;
3. strongest supporting evidence;
4. strongest counterevidence or unresolved issue;
5. actions performed;
6. assumptions and limitations;
7. next action only when it materially changes the outcome;
8. trace or state file when the task is persistent or audited.

Use [templates/final-report.md](templates/final-report.md). For detailed output rules, read [references/OUTPUT_CONTRACT.md](references/OUTPUT_CONTRACT.md).

## Multi-agent use

Use sub-agents only when they provide real epistemic differentiation, such as different data, tools, permissions, methods, or falsifiable roles. Do not spawn agents merely to create more opinions.

Recommended roles:

- hypothesis generator;
- counterevidence or falsification agent;
- source auditor;
- experiment or simulation designer;
- memory and provenance agent;
- permission or irreversible-action guard.

The controller must preserve conflicts and record whether each recommendation was accepted or rejected. Read [references/MULTI_AGENT_GOVERNANCE.md](references/MULTI_AGENT_GOVERNANCE.md).

## Optional morphology and phase routing

Use the 24/72-cell and PCMT annotations only when they help choose a computation mechanism. Do not force every trivial step into a cell.

At minimum distinguish:

- deterministic function (`F`);
- stochastic kernel (`K`);
- coherent or quantum channel (`Q`);
- mixed or unknown transition law.

Use the lowest sufficient transition law. A deterministic function does not become stochastic merely because it can be represented as a Dirac kernel; a classical probability model does not become quantum merely because it can be embedded in a diagonal quantum channel.

## Safety and integrity rules

- Never fabricate citations, observations, tools, experiments, files, or completed work.
- Never claim work will continue in the background unless an actual scheduler exists and is used.
- Never expose sealed truth to the researcher in closed-world tests.
- Never delete adverse evidence to simplify the conclusion.
- Never let a sub-agent modify the global goal or execute beyond its permission.
- Never perform irreversible or high-risk actions without the required approval.
- Never compress a multi-measure result into one score without disclosing the loss.
- Never state absence as nonexistence unless the search and inference justify it.
- When blocked, report the exact missing capability, evidence, permission, or resource.

## Validation

Validate a persisted state:

```bash
python scripts/validate_state.py gire-run.json
```

Validate the package and run smoke tests:

```bash
python scripts/validate_skill.py .
python scripts/smoke_test.py
```

## Examples

### Investigative task

User: `Investigate whether this technical claim is supported and decide what test to run next.`

Expected behavior:

1. compile goal and evidence standard;
2. inspect available sources;
3. separate source evidence from model inference;
4. create a null or competing hypothesis;
5. choose an action with distinguishing value;
6. update the evidence ledger;
7. report support status, counterevidence, and next test.

### Simple non-trigger

User: `Translate this paragraph into Traditional Chinese.`

Expected behavior: translate directly. Do not initialize GIRE.

### Closed-world task

User: `Research a synthetic world without seeing its hidden rules.`

Expected behavior: use `closed-world` mode, preserve oracle separation, record action budget, and evaluate the learned world model only after the run is sealed.
