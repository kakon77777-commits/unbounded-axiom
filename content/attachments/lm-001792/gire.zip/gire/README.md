# GIRE - Global Intent Research Engine

GIRE is a portable, tool-agnostic Agent Skill for evidence-grounded research, investigation, experiment planning, and multi-step epistemic work.

It operationalizes the GIPE research loop as a reusable skill package:

```text
goal contract
-> seven-layer state
-> competing hypotheses
-> evidence and counterevidence
-> candidate actions
-> hard constraint filtering
-> action selection
-> observation and verification
-> cross-layer update
-> traceable conclusion
```

## Package structure

```text
gire/
├── SKILL.md
├── README.md
├── VERSION
├── config/
│   └── default-policy.json
├── references/
│   ├── CORE_MODEL.md
│   ├── EVIDENCE_PROTOCOL.md
│   ├── ACTION_ROUTING.md
│   ├── MULTI_AGENT_GOVERNANCE.md
│   └── OUTPUT_CONTRACT.md
├── schemas/
│   ├── gire-state.schema.json
│   └── action.schema.json
├── templates/
│   ├── gire-state.json
│   └── final-report.md
├── scripts/
│   ├── init_run.py
│   ├── validate_state.py
│   ├── rank_actions.py
│   ├── validate_skill.py
│   └── smoke_test.py
├── examples/
│   ├── example-run.json
│   └── example-report.md
└── evals/
    └── evals.json
```

## Install

### Claude Code

Personal installation:

```bash
mkdir -p ~/.claude/skills
cp -R gire ~/.claude/skills/gire
```

Project installation:

```bash
mkdir -p .claude/skills
cp -R gire .claude/skills/gire
```

### claude.ai or compatible Skill upload

Upload `gire.zip`. The archive contains one top-level directory named `gire`, matching the `name` field in `SKILL.md`.

### Other agents

Any agent that can discover and read `SKILL.md` can use the workflow. Scripts require Python 3.10+ and only the standard library.

## Quick test

```bash
cd gire
python scripts/validate_skill.py .
python scripts/smoke_test.py
```

Create a run:

```bash
python scripts/init_run.py \
  --goal "Determine whether the claim is supported and identify the next discriminating test" \
  --mode standard \
  --output run.json
```

Validate and rank candidate actions:

```bash
python scripts/validate_state.py run.json
python scripts/rank_actions.py run.json --policy config/default-policy.json
```

## Design boundaries

GIRE is not an autonomous truth machine. It does not provide tools, network access, sealed-world oracles, laboratories, permissions, or evidence by itself. It tells an available agent how to organize those capabilities without laundering inference into evidence or losing responsibility.

The 24/72-cell and PCMT annotations are optional routing aids. GIRE remains useful without them.
