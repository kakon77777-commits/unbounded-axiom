# GIRE Multi-Agent Governance

## Principle

A sub-agent is a local epistemic organ, not an independent source of truth and not a way for the controller to evade responsibility.

## Valid reasons to delegate

Delegate when a sub-agent has at least one real difference:

- separate evidence source;
- separate tool or environment;
- distinct falsifiable method;
- permission isolation;
- independent implementation;
- specialized domain knowledge;
- adversarial or auditing role.

Different wording or persona alone does not create epistemic independence.

## Recommended roles

### Hypothesis agent

Generates explanations and predictions. Must not mark them verified.

### Falsification agent

Searches for counterexamples, confounders, boundary failures, and distinguishing tests.

### Source audit agent

Checks provenance, independence, date, entailment, and source quality.

### Experiment agent

Designs controlled interventions and expected observations. Requires authorization for execution.

### Memory agent

Maintains append-only events, provenance, unresolved conflicts, and failed actions.

### Permission guard

Checks irreversible actions, scope, tool rights, and required approval.

## Delegation record

```json
{
  "delegation_id": "del-001",
  "agent_id": "falsifier-1",
  "role": "falsification",
  "task": "Find observations that distinguish H1 and H2",
  "read_permissions": ["hypotheses", "evidence"],
  "write_permissions": ["recommendations"],
  "prohibited": ["execute_action", "modify_intent", "delete_evidence"],
  "budget": {"actions": 3},
  "status": "working"
}
```

## Recommendation handling

Every recommendation must end in one of:

- accepted;
- rejected;
- deferred;
- superseded;
- blocked.

Record controller reason. Do not merge conflicting recommendations into a vague average.

## Independence discount

Reduce evidential weight when agents share:

- the same model;
- the same prompt template;
- the same data;
- the same retrieval results;
- the same code path;
- the same hidden assumption.

Agent count is not evidence count.

## Permission model

Minimum roles:

- read-only researcher;
- local-state writer;
- action recommender;
- low-risk executor;
- irreversible-action proposer;
- controller or human approver.

No sub-agent may expand its own permission.

## Failure modes

Watch for:

- consensus illusion;
- role play without method diversity;
- responsibility dilution;
- goal drift;
- fragmented memory;
- conflict flattening;
- tool overreach;
- unbounded agent spawning;
- fake diversity;
- controller cherry-picking.

## Responsibility closure

```text
global goal
-> delegation
-> local work
-> recommendation
-> controller decision
-> execution
-> observation
-> outcome and audit
```

The audit must identify who proposed, who approved, who executed, and what evidence resulted.
