# GIRE Action Routing

## Purpose

Choose the next action that most improves the research state while respecting hard constraints. The goal is not to maximize activity or confirm the current favorite hypothesis.

## Hard-filter sequence

Reject a candidate before scoring if:

1. the required tool, data, hardware, or permission is unavailable;
2. the action is prohibited;
3. an irreversible action lacks approval;
4. required provenance or traceability cannot be preserved;
5. the action cannot produce an observation relevant to the task;
6. risk exceeds the configured threshold;
7. a critical output cannot be verified;
8. the action's input or evidence type is incompatible.

## Action metrics

All metrics use a 0-1 scale unless otherwise specified:

- `goal_fit`: relevance to the current authorized goal;
- `information_gain`: expected reduction of high-impact uncertainty;
- `falsification_value`: ability to distinguish or refute hypotheses;
- `verification_yield`: likelihood of producing independently checkable output;
- `source_independence`: expected epistemic independence from existing evidence;
- `reversibility`: ease of rollback and low irreversibility;
- `cost`: normalized resource cost;
- `risk`: normalized safety, legal, operational, or epistemic risk.

The default policy is in `config/default-policy.json`. Weights are a conservative research default, not universal truth. Change them when the user or domain provides a justified policy.

## Selection strategy

Prefer actions that:

- distinguish leading hypotheses;
- test a central assumption;
- obtain direct observation instead of another paraphrase;
- verify a high-impact inference;
- resolve a blocker;
- reveal a confounder;
- reduce irreversible risk before execution.

Avoid actions that:

- repeat the same source family;
- produce only rhetorical agreement;
- have no expected observation;
- add detail without changing decisions;
- consume large resources before cheap discriminating tests;
- optimize a scalar score while violating hard requirements.

## Tool routing

### Search or browse

Use when public, current, or external evidence is required. Record query, source, publication or event date when relevant, and provenance.

### File inspection

Use when the answer depends on user-provided or repository artifacts. Prefer direct file content over recollection.

### Calculation or deterministic script

Use when arithmetic, parsing, validation, transformation, or reproducible scoring can reduce ambiguity. Save inputs and outputs.

### Simulation

Use when testing a model under explicit assumptions. Label output `simulation`, not observation.

### Formal proof or solver

Use when correctness relative to premises matters. Preserve premises and certificate.

### Experiment or intervention

Use when observational evidence cannot distinguish hypotheses. Record expected result, controls, risk, permissions, and actual observation.

### Sub-agent

Use only when the agent has a distinct role, method, data source, tool, or permission. Record delegation and controller decision.

### Ask the user

Use when a missing user-specific fact, preference, authority, or irreversible approval materially changes execution. Do not ask for facts that tools or provided files can resolve.

### Stop or report blocked

Choose this when no legal, safe, available, and informative action remains. State the exact blocker.

## Optional 24/72-cell annotation

Use only when it improves routing.

Morphology:

- substrate: continuous or discrete;
- update: sequential, selective/jump, parallel, or recognition/retrieval;
- observation: continuous, discrete, or single-measure refusal.

Transition law:

- `F`: deterministic function;
- `K`: stochastic kernel;
- `Q`: coherent or quantum channel;
- `mixed` or `unknown` when necessary.

Use the lowest sufficient law:

```text
single-valued next state sufficient -> F
classical conditional distribution required -> K
coherence, interference, noncommutativity, or entanglement required -> Q
```

## PCMT routing

Common machine types:

- phase graph: semantic, epistemic, evidence, and agent relations;
- phase stream: time series, drift, delayed observation, long-term state;
- phase event: action lifecycle, delegation, permissions, asynchronous events;
- phase simulation: numerical, stochastic, or physical model execution;
- phase proof: formal validity, constraints, irreversible-action guard;
- phase oscillation: genuine synchronization or physical phase dynamics;
- phase topology: invariant and multi-scale structural analysis;
- meta-phase selector: tool and machine selection, composition, switching.

Do not choose an oscillation machine merely because the task uses the word phase.

## Runtime switching

Re-route when:

- evidence conflict crosses a meaningful threshold;
- the task changes from semantic exploration to empirical testing;
- risk becomes irreversible;
- the selected tool fails;
- a delayed observation becomes available;
- the world model requires a different representation;
- a classical approximation is inadequate and quantum structure is demonstrably necessary.

Record switching cost and information loss.
