# GIRE Evidence Protocol

## Evidence types

Use one of these canonical types:

- `user_provided`: a statement or artifact supplied by the user;
- `direct_observation`: direct inspection by the current agent or trusted sensor;
- `external_source`: a webpage, paper, document, database, or other external source;
- `tool_output`: output of a calculator, parser, compiler, search tool, or deterministic program;
- `experiment`: an intervention followed by observation;
- `simulation`: output of a model, not direct world observation;
- `formal_result`: proof, type check, solver certificate, or formal derivation;
- `inference`: a conclusion derived from other records;
- `model_recall`: internal model knowledge or recollection without current verification.

## Evidence record

```json
{
  "id": "ev-001",
  "type": "external_source",
  "claim": "The source reports X under condition Y.",
  "provenance": {
    "source": "document-or-url-reference",
    "locator": "page, line, section, commit, query, or tool call",
    "retrieved_at": "2026-01-01T00:00:00Z"
  },
  "verification_status": "verified_external",
  "directness": 0.8,
  "quality": 0.7,
  "independence_group": "publisher-a",
  "supports": ["hyp-001"],
  "contradicts": [],
  "limitations": []
}
```

## Verification statuses

- `unverified`;
- `self_checked`;
- `verified_external`;
- `deterministically_checked`;
- `formally_certified`;
- `physically_measured`;
- `disputed`;
- `failed`.

Do not mark `model_recall` as `verified_external`, `formally_certified`, or `physically_measured`.

## Claim statuses

Use one of:

- `well_supported`;
- `partially_supported`;
- `contradicted`;
- `insufficient_evidence`;
- `unresolved`.

These statuses are typed judgments, not arbitrary confidence thresholds.

## Source independence

Two sources are not independent merely because they have different URLs. Reduce independence when they:

- repeat the same press release;
- cite the same original dataset;
- share the same model output;
- derive from the same repository or author;
- reproduce the same unverified claim.

Record an `independence_group` where possible.

## Counterevidence priority

For a leading hypothesis, actively search for:

- observations it predicts should not occur;
- boundary conditions where it fails;
- alternative explanations;
- source criticism;
- failed replications;
- confounders;
- negative results.

Do not search only for confirming keywords.

## Formal and empirical separation

A formal result can establish:

- logical consequence;
- type safety;
- satisfiability;
- invariant preservation;
- correctness relative to premises.

It cannot establish that external premises are true without empirical evidence.

## Absence and nonexistence

Use these different claims carefully:

- `not found`: the search did not locate evidence;
- `not supported`: available evidence is insufficient;
- `contradicted`: evidence conflicts with the claim;
- `does not exist`: requires a justified scope and exclusion argument.

## Evidence conversion

Every conversion must record loss:

```json
{
  "from": "semantic_relevance",
  "to": "epistemic_support",
  "allowed": false,
  "reason": "Relevance alone lacks source reliability and entailment"
}
```

A valid semantic-to-epistemic conversion requires source, entailment, reliability, counterevidence, and context checks.
