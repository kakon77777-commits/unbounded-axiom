# GIRE Core Model

## Purpose

GIRE maintains a typed research state rather than a single narrative scratchpad. The state is intentionally decomposed so that goals, world claims, evidence, actions, resources, and governance cannot silently overwrite one another.

## Seven-layer state

### 1. Intent

Contains:

- objective;
- deliverable;
- constraints;
- evidence standard;
- stop conditions;
- authorized goal changes;
- prohibited goal changes.

Invariant: intent may prioritize what to investigate, but cannot mark a world claim true.

### 2. World model

Contains:

- entities;
- relations;
- known unknowns;
- conflicts;
- temporal state;
- source-linked claims.

Invariant: every material update points to evidence or is explicitly labeled inference.

### 3. Hypotheses

Contains competing explanations and null hypotheses.

Each hypothesis should record:

- prediction;
- support;
- counterevidence;
- unknowns;
- falsifiability;
- distinguishing action;
- status.

Invariant: a hypothesis is not deleted merely because it loses ranking. Mark it contradicted, deprecated, or unresolved.

### 4. Evidence

Contains typed evidence records. Evidence is not a bag of quotations; it is a provenance-preserving ledger.

Invariant: inference, model recall, simulation, formal proof, and external observation retain different evidence types.

### 5. Actions

Contains candidate, selected, executing, completed, failed, rejected, and blocked actions.

Invariant: record expected observation before execution when practical. This reduces hindsight rewriting.

### 6. Resources and risks

Contains:

- time or action budget;
- compute and tool availability;
- cost;
- latency;
- reversible and irreversible risk;
- legal, safety, epistemic, and governance risk.

Invariant: lack of resources means blocked or degraded execution, not that the goal or world fact changed.

### 7. Agents and governance

Contains:

- controller;
- sub-agent roles;
- delegated scope;
- permissions;
- recommendations;
- acceptance or rejection;
- responsibility chain.

Invariant: the controller owns adopted actions. Sub-agent delegation does not dissolve responsibility.

## Core event loop

```text
intent
-> world-model gaps and hypothesis conflicts
-> candidate actions
-> hard constraints
-> action selection
-> execution
-> observation
-> evidence classification
-> hypothesis update
-> world-model update
-> next action or stop
```

## Append-only audit

Prefer events over silent mutation:

```json
{
  "event_id": "evt-001",
  "timestamp": "2026-01-01T00:00:00Z",
  "event_type": "evidence_added",
  "actor": "controller",
  "previous_ref": null,
  "new_ref": "ev-001",
  "reason": "Source inspected",
  "permission_ref": null
}
```

## Required invariants

1. Source preservation.
2. Ontology integrity: semantic relevance is not epistemic support.
3. Intent-truth separation.
4. Permission isolation.
5. Failure preservation.
6. Irreversibility governance.
7. Conversion-loss disclosure.
8. Responsibility closure.
9. No forced scalarization of genuinely multi-measure states.
10. No answer leakage in closed-world mode.

## State compression

GIRE may summarize old events, but compression must preserve:

- material claims;
- evidence provenance;
- counterevidence;
- failed actions;
- accepted and rejected decisions;
- unresolved conflicts;
- permissions and irreversible transitions.

A summary is a derived artifact, not a replacement for the authoritative audit record.
