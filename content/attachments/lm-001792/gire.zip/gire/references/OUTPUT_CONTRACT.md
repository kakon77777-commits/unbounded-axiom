# GIRE Output Contract

## Human-readable result

A complete result should contain, in this order:

1. **Result** - the direct answer, artifact, or decision.
2. **Status** - well supported, partially supported, contradicted, insufficient evidence, or unresolved.
3. **Evidence** - strongest supporting records with provenance.
4. **Counterevidence** - strongest conflict, alternative, or unresolved issue.
5. **What was done** - material actions and tools, not internal hidden reasoning.
6. **Assumptions and limits** - scope, unavailable tools, unverified premises, approximations.
7. **Next action** - only when it materially changes the outcome.

Do not make the user reconstruct the answer from the research log.

## Machine-readable result

Persist the canonical state when:

- the work spans multiple turns;
- multiple tools or agents were used;
- an audit, benchmark, or reproduction is expected;
- the task has unresolved hypotheses;
- the user will hand the work to another agent.

Recommended files:

```text
gire-run.json
research-report.md
artifacts/
```

## Conclusion language

Use precise boundaries:

- `The evidence supports...`
- `The available evidence partially supports...`
- `The claim is contradicted under...`
- `I found insufficient evidence to conclude...`
- `The result remains unresolved because...`

Avoid:

- `proven` when only observational or source evidence exists;
- `does not exist` when merely not found;
- `confirmed by multiple agents` when agents are not independent;
- `verified` without naming the verification method.

## Citation and provenance

For each material externally grounded claim, include a source reference appropriate to the environment. Do not fabricate URLs, page numbers, line numbers, commit hashes, or tool results.

## Failure reporting

A useful failure report includes:

- attempted action;
- expected observation;
- actual failure;
- error or blocker;
- affected hypotheses;
- whether retry is justified;
- whether a fallback changes fidelity.

## Closed-world output

Before unsealing truth, report only the researcher's learned model and evidence. After the run is sealed, the independent evaluator may compare against hidden truth.

## Minimal report template

See `templates/final-report.md`.
