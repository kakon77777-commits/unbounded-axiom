# Research Result

## Result

[Direct answer, decision, or artifact]

## Status

`well_supported | partially_supported | contradicted | insufficient_evidence | unresolved`

## Strongest evidence

- [Evidence record and provenance]

## Counterevidence and unresolved issues

- [Material conflict, alternative explanation, or missing observation]

## Actions performed

- [Material action, tool, experiment, calculation, or file inspection]

## Assumptions and limitations

- [Scope, unavailable capability, approximation, unverified premise]

## Next discriminating action

[Only include when it materially changes the outcome]

## Trace

- State: `gire-run.json`
- Artifacts: `[paths or references]`
