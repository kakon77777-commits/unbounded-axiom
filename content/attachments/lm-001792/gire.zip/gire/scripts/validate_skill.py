#!/usr/bin/env python3
"""Validate GIRE or another Agent Skill directory using standard-library checks."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

NAME_RE = re.compile(r"^[a-z0-9-]{1,64}$")
LINK_RE = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
REQUIRED_FILES = {
    "SKILL.md",
    "README.md",
    "VERSION",
    "templates/gire-state.json",
    "templates/final-report.md",
    "scripts/init_run.py",
    "scripts/validate_state.py",
    "scripts/rank_actions.py",
    "references/CORE_MODEL.md",
    "references/EVIDENCE_PROTOCOL.md",
    "references/ACTION_ROUTING.md",
    "references/MULTI_AGENT_GOVERNANCE.md",
    "references/OUTPUT_CONTRACT.md",
}


def parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    if not text.startswith("---\n"):
        return {}, text
    end = text.find("\n---\n", 4)
    if end < 0:
        return {}, text
    raw = text[4:end]
    body = text[end + 5 :]
    data: dict[str, str] = {}
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip().strip('"').strip("'")
    return data, body


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate an Agent Skill directory.")
    parser.add_argument("root", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    issues: list[str] = []

    skill_path = root / "SKILL.md"
    if not skill_path.exists():
        issues.append("SKILL.md is missing at the skill root")
        text = ""
        meta: dict[str, str] = {}
        body = ""
    else:
        text = skill_path.read_text(encoding="utf-8")
        meta, body = parse_frontmatter(text)

    name = meta.get("name", "")
    description = meta.get("description", "")
    if not NAME_RE.fullmatch(name):
        issues.append("frontmatter name must be 1-64 lowercase letters, numbers, or hyphens")
    if any(word in name for word in ("anthropic", "claude")):
        issues.append("frontmatter name contains a reserved word")
    if not description:
        issues.append("frontmatter description is required")
    elif len(description) > 1024:
        issues.append("frontmatter description exceeds 1024 characters")
    if name and root.name.replace("_", "-").lower() != name.replace("_", "-").lower():
        issues.append(f"root directory {root.name!r} does not match skill name {name!r}")

    body_lines = len(body.splitlines())
    if body_lines > 500:
        issues.append(f"SKILL.md body has {body_lines} lines; keep it at or below 500")

    for rel in sorted(REQUIRED_FILES):
        if not (root / rel).exists():
            issues.append(f"required file missing: {rel}")

    for link in LINK_RE.findall(body):
        if link.startswith(("http://", "https://", "#")):
            continue
        target = (root / link.split("#", 1)[0]).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            issues.append(f"link escapes skill root: {link}")
            continue
        if not target.exists():
            issues.append(f"referenced file missing: {link}")

    if issues:
        print(f"INVALID: {len(issues)} issue(s)")
        for issue in issues:
            print(f"- {issue}")
        return 1

    print("VALID: Agent Skill package passed structural checks")
    print(f"- name: {name}")
    print(f"- SKILL.md body lines: {body_lines}")
    print(f"- files: {sum(1 for p in root.rglob('*') if p.is_file())}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
