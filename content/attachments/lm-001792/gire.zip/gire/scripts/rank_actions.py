#!/usr/bin/env python3
"""Rank GIRE candidate actions after enforcing hard constraints."""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

METRICS = [
    "goal_fit",
    "information_gain",
    "falsification_value",
    "verification_yield",
    "source_independence",
    "reversibility",
    "cost",
    "risk",
]


def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise SystemExit(f"ERROR: file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise SystemExit(f"ERROR: invalid JSON in {path}: {exc}") from exc
    if not isinstance(data, dict):
        raise SystemExit(f"ERROR: {path} must contain a JSON object")
    return data


def hard_filter(action: dict[str, Any], state: dict[str, Any], policy: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    hard = action.get("hard_constraints", {})
    if hard.get("prohibited") is True:
        reasons.append("action_prohibited")
    if policy.get("hard_limits", {}).get("require_available_capability", True) and hard.get("capability_available") is not True:
        reasons.append("required_capability_unavailable")
    if policy.get("hard_limits", {}).get("require_permission", True) and hard.get("permission_granted") is not True:
        reasons.append("permission_not_granted")
    if action.get("traceability_required") and policy.get("hard_limits", {}).get("require_traceability_for_critical_actions", True):
        if hard.get("traceability_available") is not True:
            reasons.append("required_traceability_unavailable")

    resources = state.get("phases", {}).get("resources_risks", {})
    state_max = resources.get("maximum_allowed_risk", 0.8)
    policy_max = policy.get("hard_limits", {}).get("maximum_risk", 0.8)
    max_risk = min(float(state_max), float(policy_max))
    risk = float(action.get("metrics", {}).get("risk", 1.0))
    if risk > max_risk:
        reasons.append(f"risk_{risk:.3f}_exceeds_{max_risk:.3f}")

    available = set(resources.get("available_capabilities", []))
    for capability in action.get("required_capabilities", []):
        if capability not in available and available:
            reasons.append(f"capability_not_listed:{capability}")
    return reasons


def score_action(action: dict[str, Any], weights: dict[str, Any]) -> tuple[float, dict[str, float]]:
    metrics = action.get("metrics", {})
    breakdown: dict[str, float] = {}
    score = 0.0
    for metric in METRICS:
        value = float(metrics.get(metric, 0.0))
        weight = float(weights.get(metric, 0.0))
        contribution = value * weight
        breakdown[metric] = round(contribution, 6)
        score += contribution
    return round(score, 6), breakdown


def rank(state: dict[str, Any], policy: dict[str, Any]) -> dict[str, Any]:
    actions = state.get("phases", {}).get("actions", [])
    weights = policy.get("weights", {})
    ranked: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []

    for action in actions:
        if not isinstance(action, dict) or action.get("state") not in {"candidate", "selected"}:
            continue
        reasons = hard_filter(action, state, policy)
        if reasons:
            rejected.append({
                "id": action.get("id"),
                "description": action.get("description"),
                "reasons": reasons,
            })
            continue
        score, breakdown = score_action(action, weights)
        ranked.append({
            "id": action.get("id"),
            "kind": action.get("kind"),
            "description": action.get("description"),
            "score": score,
            "breakdown": breakdown,
            "expected_observation": action.get("expected_observation", ""),
        })

    ranked.sort(key=lambda item: (-item["score"], str(item.get("id", ""))))
    return {
        "policy": policy.get("policy_name", "unnamed"),
        "run_id": state.get("run_id"),
        "ranked": ranked,
        "hard_rejected": rejected,
        "selected": ranked[0]["id"] if ranked else None,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rank GIRE candidate actions.")
    parser.add_argument("state", help="GIRE state JSON")
    parser.add_argument("--policy", required=True, help="Policy JSON")
    parser.add_argument("--output", help="Write ranking JSON instead of stdout only")
    parser.add_argument("--select", action="store_true", help="Mark the top action selected in a new state file")
    parser.add_argument("--state-output", help="Required with --select; never mutates the input state")
    args = parser.parse_args()
    if args.select and not args.state_output:
        parser.error("--state-output is required with --select")
    return args


def main() -> int:
    args = parse_args()
    state_path = Path(args.state)
    state = load_json(state_path)
    policy = load_json(Path(args.policy))
    result = rank(state, policy)
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(rendered, end="")

    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")

    if args.select:
        selected = result.get("selected")
        if not selected:
            print("ERROR: no eligible action to select", file=sys.stderr)
            return 1
        new_state = json.loads(json.dumps(state))
        for action in new_state.get("phases", {}).get("actions", []):
            if action.get("id") == selected:
                action["state"] = "selected"
            elif action.get("state") == "selected":
                action["state"] = "candidate"
        timestamp = now_utc()
        new_state["updated_at"] = timestamp
        new_state.setdefault("audit", []).append({
            "event_id": f"evt-select-{selected}",
            "timestamp": timestamp,
            "event_type": "action_selected",
            "actor": "gire-ranker",
            "new_ref": selected,
            "reason": f"Top eligible action under policy {result['policy']}",
        })
        output_path = Path(args.state_output)
        output_path.write_text(json.dumps(new_state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"Wrote selected state: {output_path}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
