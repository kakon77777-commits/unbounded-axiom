#!/usr/bin/env python3
"""Validate GIRE research-state invariants without external dependencies."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

MODES = {"quick", "standard", "deep", "closed-world"}
RUN_STATUSES = {"initialized", "active", "blocked", "completed", "aborted"}
CLAIM_STATUSES = {"well_supported", "partially_supported", "contradicted", "insufficient_evidence", "unresolved"}
EVIDENCE_TYPES = {"user_provided", "direct_observation", "external_source", "tool_output", "experiment", "simulation", "formal_result", "inference", "model_recall"}
VERIFICATION_STATUSES = {"unverified", "self_checked", "verified_external", "deterministically_checked", "formally_certified", "physically_measured", "disputed", "failed"}
ACTION_STATES = {"candidate", "selected", "authorized", "executing", "awaiting_observation", "completed", "failed", "rejected", "blocked", "rolled_back", "closed"}
ACTION_KINDS = {"search", "inspect_file", "calculate", "query", "compare", "simulate", "prove", "experiment", "ask_user", "ask_agent", "wait", "construct", "stop"}
METRICS = {"goal_fit", "information_gain", "falsification_value", "verification_yield", "source_independence", "reversibility", "cost", "risk"}


def require_dict(obj: Any, path: str, issues: list[str]) -> dict[str, Any]:
    if not isinstance(obj, dict):
        issues.append(f"{path} must be an object")
        return {}
    return obj


def require_list(obj: Any, path: str, issues: list[str]) -> list[Any]:
    if not isinstance(obj, list):
        issues.append(f"{path} must be an array")
        return []
    return obj


def check_required(obj: dict[str, Any], keys: set[str], path: str, issues: list[str]) -> None:
    for key in sorted(keys):
        if key not in obj:
            issues.append(f"{path}.{key} is required")


def check_unique_ids(items: list[Any], path: str, issues: list[str]) -> None:
    seen: set[str] = set()
    for index, item in enumerate(items):
        if not isinstance(item, dict):
            continue
        item_id = item.get("id") or item.get("event_id")
        if not item_id:
            continue
        if item_id in seen:
            issues.append(f"{path}[{index}] duplicates id {item_id!r}")
        seen.add(item_id)


def validate_metric(value: Any, path: str, issues: list[str]) -> None:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        issues.append(f"{path} must be numeric")
    elif not 0 <= float(value) <= 1:
        issues.append(f"{path} must be between 0 and 1")


def validate_state(data: Any) -> list[str]:
    issues: list[str] = []
    root = require_dict(data, "$", issues)
    check_required(root, {"gire_version", "run_id", "created_at", "updated_at", "mode", "status", "goal_contract", "phases", "conclusions", "audit"}, "$", issues)

    if root.get("mode") not in MODES:
        issues.append(f"$.mode must be one of {sorted(MODES)}")
    if root.get("status") not in RUN_STATUSES:
        issues.append(f"$.status must be one of {sorted(RUN_STATUSES)}")
    if not isinstance(root.get("run_id"), str) or not root.get("run_id"):
        issues.append("$.run_id must be a non-empty string")

    goal = require_dict(root.get("goal_contract"), "$.goal_contract", issues)
    check_required(goal, {"objective", "constraints", "permissions", "stop_conditions", "assumptions"}, "$.goal_contract", issues)
    if not isinstance(goal.get("objective"), str) or not goal.get("objective", "").strip():
        issues.append("$.goal_contract.objective must be non-empty")

    phases = require_dict(root.get("phases"), "$.phases", issues)
    required_phases = {"intent", "world_model", "hypotheses", "evidence", "actions", "resources_risks", "agents_governance"}
    check_required(phases, required_phases, "$.phases", issues)

    hypotheses = require_list(phases.get("hypotheses"), "$.phases.hypotheses", issues)
    evidence = require_list(phases.get("evidence"), "$.phases.evidence", issues)
    actions = require_list(phases.get("actions"), "$.phases.actions", issues)
    conclusions = require_list(root.get("conclusions"), "$.conclusions", issues)
    audit = require_list(root.get("audit"), "$.audit", issues)

    check_unique_ids(hypotheses, "$.phases.hypotheses", issues)
    check_unique_ids(evidence, "$.phases.evidence", issues)
    check_unique_ids(actions, "$.phases.actions", issues)
    check_unique_ids(audit, "$.audit", issues)

    for i, hyp in enumerate(hypotheses):
        p = f"$.phases.hypotheses[{i}]"
        h = require_dict(hyp, p, issues)
        check_required(h, {"id", "statement", "status"}, p, issues)
        if h.get("status") not in CLAIM_STATUSES:
            issues.append(f"{p}.status must be one of {sorted(CLAIM_STATUSES)}")

    for i, ev in enumerate(evidence):
        p = f"$.phases.evidence[{i}]"
        e = require_dict(ev, p, issues)
        check_required(e, {"id", "type", "claim", "provenance", "verification_status"}, p, issues)
        ev_type = e.get("type")
        verification = e.get("verification_status")
        if ev_type not in EVIDENCE_TYPES:
            issues.append(f"{p}.type must be one of {sorted(EVIDENCE_TYPES)}")
        if verification not in VERIFICATION_STATUSES:
            issues.append(f"{p}.verification_status must be one of {sorted(VERIFICATION_STATUSES)}")
        if ev_type == "model_recall" and verification in {"verified_external", "formally_certified", "physically_measured"}:
            issues.append(f"{p}: model_recall cannot be marked {verification}")
        if ev_type == "inference" and verification == "physically_measured":
            issues.append(f"{p}: inference cannot be marked physically_measured")
        provenance = require_dict(e.get("provenance"), f"{p}.provenance", issues)
        if ev_type in {"external_source", "tool_output", "experiment", "direct_observation", "formal_result"} and not provenance.get("source"):
            issues.append(f"{p}.provenance.source is required for {ev_type}")
        for field in ("directness", "quality"):
            if field in e:
                validate_metric(e[field], f"{p}.{field}", issues)

    for i, action in enumerate(actions):
        p = f"$.phases.actions[{i}]"
        a = require_dict(action, p, issues)
        check_required(a, {"id", "kind", "description", "state", "metrics", "hard_constraints"}, p, issues)
        if a.get("kind") not in ACTION_KINDS:
            issues.append(f"{p}.kind must be one of {sorted(ACTION_KINDS)}")
        if a.get("state") not in ACTION_STATES:
            issues.append(f"{p}.state must be one of {sorted(ACTION_STATES)}")
        metrics = require_dict(a.get("metrics"), f"{p}.metrics", issues)
        check_required(metrics, METRICS, f"{p}.metrics", issues)
        for metric in METRICS:
            if metric in metrics:
                validate_metric(metrics[metric], f"{p}.metrics.{metric}", issues)
        hard = require_dict(a.get("hard_constraints"), f"{p}.hard_constraints", issues)
        hard_keys = {"capability_available", "permission_granted", "traceability_available", "prohibited"}
        check_required(hard, hard_keys, f"{p}.hard_constraints", issues)
        for key in hard_keys:
            if key in hard and not isinstance(hard[key], bool):
                issues.append(f"{p}.hard_constraints.{key} must be boolean")

    for i, conclusion in enumerate(conclusions):
        p = f"$.conclusions[{i}]"
        c = require_dict(conclusion, p, issues)
        if "status" in c and c["status"] not in CLAIM_STATUSES:
            issues.append(f"{p}.status must be one of {sorted(CLAIM_STATUSES)}")

    governance = require_dict(phases.get("agents_governance"), "$.phases.agents_governance", issues)
    if governance.get("irreversible_requires_approval") is not True:
        issues.append("$.phases.agents_governance.irreversible_requires_approval should be true")

    resources = require_dict(phases.get("resources_risks"), "$.phases.resources_risks", issues)
    maximum_risk = resources.get("maximum_allowed_risk", 0.8)
    validate_metric(maximum_risk, "$.phases.resources_risks.maximum_allowed_risk", issues)

    return issues


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate a GIRE state JSON file.")
    parser.add_argument("state", help="Path to GIRE JSON state")
    parser.add_argument("--json", action="store_true", help="Emit validation result as JSON")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    path = Path(args.state)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        print(f"ERROR: file not found: {path}", file=sys.stderr)
        return 2
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid JSON: {exc}", file=sys.stderr)
        return 2

    issues = validate_state(data)
    if args.json:
        print(json.dumps({"valid": not issues, "issues": issues}, ensure_ascii=False, indent=2))
    elif issues:
        print(f"INVALID: {len(issues)} issue(s)")
        for issue in issues:
            print(f"- {issue}")
    else:
        print("VALID: GIRE state passed invariant checks")
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
