#!/usr/bin/env python3
"""Initialize a GIRE research-state JSON file using only the Python standard library."""

from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def build_state(args: argparse.Namespace) -> dict[str, Any]:
    timestamp = now_utc()
    return {
        "gire_version": "0.1.0",
        "run_id": args.run_id or f"run-{uuid.uuid4().hex[:12]}",
        "created_at": timestamp,
        "updated_at": timestamp,
        "mode": args.mode,
        "status": "initialized",
        "goal_contract": {
            "objective": args.goal,
            "deliverable": args.deliverable,
            "constraints": args.constraint,
            "evidence_standard": args.evidence_standard,
            "permissions": args.permission,
            "forbidden_goal_changes": ["silent_objective_rewrite", "world_truth_rewrite"],
            "stop_conditions": args.stop_condition,
            "assumptions": args.assumption,
        },
        "phases": {
            "intent": {
                "goal_state": "active",
                "priority": args.priority,
                "authorized_updates": [],
            },
            "world_model": {
                "entities": [],
                "relations": [],
                "claims": [],
                "unknowns": [],
                "conflicts": [],
            },
            "hypotheses": [],
            "evidence": [],
            "actions": [],
            "resources_risks": {
                "budgets": {},
                "available_capabilities": args.capability,
                "unavailable_capabilities": [],
                "risks": [],
                "maximum_allowed_risk": args.maximum_risk,
            },
            "agents_governance": {
                "controller": args.controller,
                "agents": [],
                "delegations": [],
                "permissions": args.permission,
                "irreversible_requires_approval": True,
            },
        },
        "conclusions": [],
        "audit": [
            {
                "event_id": f"evt-{uuid.uuid4().hex[:12]}",
                "timestamp": timestamp,
                "event_type": "run_initialized",
                "actor": args.controller,
                "reason": "GIRE state initialized from goal contract",
            }
        ],
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Initialize a GIRE research run.")
    parser.add_argument("--goal", required=True, help="Authorized research objective")
    parser.add_argument("--output", required=True, help="Output JSON path")
    parser.add_argument("--mode", choices=["quick", "standard", "deep", "closed-world"], default="standard")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--deliverable", default="Research result and traceable state")
    parser.add_argument("--evidence-standard", default="Traceable evidence with explicit uncertainty and counterevidence")
    parser.add_argument("--priority", choices=["low", "normal", "high", "critical"], default="normal")
    parser.add_argument("--controller", default="primary-agent")
    parser.add_argument("--maximum-risk", type=float, default=0.8)
    parser.add_argument("--constraint", action="append", default=[])
    parser.add_argument("--permission", action="append", default=["read", "analyze", "recommend"])
    parser.add_argument("--stop-condition", action="append", default=[])
    parser.add_argument("--assumption", action="append", default=[])
    parser.add_argument("--capability", action="append", default=[])
    args = parser.parse_args()
    if not 0 <= args.maximum_risk <= 1:
        parser.error("--maximum-risk must be between 0 and 1")
    return args


def main() -> int:
    args = parse_args()
    state = build_state(args)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Initialized GIRE run: {state['run_id']}")
    print(f"Wrote: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
