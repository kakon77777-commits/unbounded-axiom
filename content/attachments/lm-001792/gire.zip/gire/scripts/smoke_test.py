#!/usr/bin/env python3
"""Run an end-to-end GIRE package smoke test using temporary files."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


def run(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, cwd=cwd, text=True, capture_output=True)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        raise SystemExit(f"Smoke test failed: {' '.join(command)}")
    return result


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    python = sys.executable

    run([python, "scripts/validate_skill.py", "."], root)

    with tempfile.TemporaryDirectory(prefix="gire-smoke-") as tmp:
        tmp_path = Path(tmp)
        state_path = tmp_path / "run.json"
        selected_path = tmp_path / "selected.json"
        ranking_path = tmp_path / "ranking.json"

        run([
            python,
            "scripts/init_run.py",
            "--goal",
            "Determine whether claim X is supported and choose the next discriminating test",
            "--mode",
            "standard",
            "--capability",
            "web_search",
            "--capability",
            "file_inspection",
            "--output",
            str(state_path),
        ], root)

        state = json.loads(state_path.read_text(encoding="utf-8"))
        state["status"] = "active"
        state["phases"]["hypotheses"] = [
            {
                "id": "hyp-001",
                "statement": "Claim X is supported under condition Y",
                "status": "unresolved",
                "predictions": ["Independent source or observation should report X under Y"],
                "supports": [],
                "counterevidence": [],
            },
            {
                "id": "hyp-002",
                "statement": "Apparent support for X is a source-repetition artifact",
                "status": "unresolved",
                "predictions": ["Sources will share the same upstream origin"],
                "supports": [],
                "counterevidence": [],
            },
        ]
        state["phases"]["evidence"] = [
            {
                "id": "ev-001",
                "type": "user_provided",
                "claim": "The user reports that several pages repeat claim X",
                "provenance": {"source": "user-message", "locator": "initial request"},
                "verification_status": "unverified",
                "directness": 0.4,
                "quality": 0.5,
                "independence_group": "user-report",
                "supports": ["hyp-001"],
                "contradicts": [],
                "limitations": ["Not independently checked"],
            }
        ]
        state["phases"]["actions"] = [
            {
                "id": "act-001",
                "kind": "search",
                "description": "Find an independent primary source and trace source ancestry",
                "state": "candidate",
                "expected_observation": "Either an independent primary source or evidence of repetition",
                "required_capabilities": ["web_search"],
                "required_permission": "read",
                "traceability_required": True,
                "metrics": {
                    "goal_fit": 0.95,
                    "information_gain": 0.9,
                    "falsification_value": 0.9,
                    "verification_yield": 0.85,
                    "source_independence": 0.9,
                    "reversibility": 1.0,
                    "cost": 0.25,
                    "risk": 0.05
                },
                "hard_constraints": {
                    "capability_available": True,
                    "permission_granted": True,
                    "traceability_available": True,
                    "prohibited": False
                }
            },
            {
                "id": "act-002",
                "kind": "construct",
                "description": "Publish claim X immediately",
                "state": "candidate",
                "expected_observation": "Publication occurs without improving truth assessment",
                "required_capabilities": [],
                "required_permission": "publish",
                "traceability_required": True,
                "metrics": {
                    "goal_fit": 0.3,
                    "information_gain": 0.0,
                    "falsification_value": 0.0,
                    "verification_yield": 0.0,
                    "source_independence": 0.0,
                    "reversibility": 0.1,
                    "cost": 0.5,
                    "risk": 0.9
                },
                "hard_constraints": {
                    "capability_available": True,
                    "permission_granted": False,
                    "traceability_available": True,
                    "prohibited": False
                }
            }
        ]
        state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        run([python, "scripts/validate_state.py", str(state_path)], root)
        rank_result = run([
            python,
            "scripts/rank_actions.py",
            str(state_path),
            "--policy",
            "config/default-policy.json",
            "--output",
            str(ranking_path),
            "--select",
            "--state-output",
            str(selected_path),
        ], root)
        ranking = json.loads(ranking_path.read_text(encoding="utf-8"))
        if ranking.get("selected") != "act-001":
            raise SystemExit(f"Expected act-001, got {ranking.get('selected')!r}\n{rank_result.stdout}")
        run([python, "scripts/validate_state.py", str(selected_path)], root)

    print("PASS: GIRE end-to-end smoke test")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
