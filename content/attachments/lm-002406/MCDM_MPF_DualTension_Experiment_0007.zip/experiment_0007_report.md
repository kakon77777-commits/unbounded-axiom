# EXP-0007：VOI Specialist Scheduler

- Experiment ID: `EXP-0007-VOI-SPECIALIST-SCHEDULER`
- 建立時間：2026-08-10T23:31:00+08:00
- 基礎資料：EXP-0006 holdout-style 12 samples
- 性質：**VOI controller simulation**
- 不是獨立 Agent benchmark，也不是實際 token/latency 成本。

## 核心

對 residual doubt vector

$$
D=(D_F,D_S,D_B)
$$

分別表示 formal、source-fidelity、bridge doubt。

對 specialist $M_i$：

$$
\mathrm{VOI}(M_i\mid D)
=
\frac{\mathbb E[\Delta D\mid M_i]}{C(M_i)}.
$$

選擇 VOI 最大且超過門檻的 specialist；每次執行後重新計算 residual doubt。
若 residual doubt 低於 freeze threshold，停止擴張並 freeze target。

## 本輪代理成本

- SURFACE = 1.0
- MPF = 2.0
- SOURCE_FIDELITY = 1.3
- BRIDGE = 1.2

這些只是相對代理，不是實測算力。

## 結果

- Detection accuracy：**1.000**
- Corruption recall：**1.000**
- Clean non-flag rate：**1.000**
- Module calls：**24**
- Avg calls / case：**2.000**
- Weighted proxy cost：**31.80**

## 與其他控制策略比較

| Policy | Module calls | Weighted proxy cost |
|---|---:|---:|
| Always-Dual | 48 | 66.00 |
| EXP-0006 Rule-Based Adaptive | 26 | 35.80 |
| EXP-0007 VOI Scheduler | 24 | 31.80 |
| Oracle Minimum (gold lower bound) | 23 | 30.50 |

### 相對節省（僅代理）

相對 Always-Dual：

- module calls：**50.0%**
- weighted proxy cost：**51.8%**

相對 EXP-0006 Rule-Based Adaptive：

- module calls：**7.7%**
- weighted proxy cost：**11.2%**

相對 gold Oracle Minimum 的 weighted overhead：

- **4.3%**

## 最有意思的 routing

### Erdős 12 / 26
Formal doubt 明顯高於 source/bridge doubt，因此 MPF 的 VOI 最高；不需要 Source Fidelity 或 Bridge。

### Erdős 56
初始 residual doubt 已低，而且 boundary 是 Surface 可直接核對的顯式條件。
乾淨版直接 freeze；刪除門檻的 corruption 也在 Surface 被抓到。

### OQP13
Source-fidelity doubt 主導：問題是在求 maximal $\mu(d)$，而不是預設永遠存在 $d+1$ 個 MUB。
VOI scheduler 先叫 SOURCE_FIDELITY，而不再像 EXP-0006 的保守規則同時加 MPF。

### OQP35
同時有 formal-coverage 與 source-equivalence doubt：
SOURCE_FIDELITY 先降低「這個 representation 是否忠實」的疑點，
剩餘 formal doubt 仍高，再呼叫 MPF 檢查 permutation/subsystem coverage。
這是典型的兩階 specialist chain。

### OEIS A6697
Source/provenance doubt 壓倒 formal doubt。
先檢查「subword-defined a(n)」與「formula-defined sequence」是否已建立等價橋，
不必先深挖 generating-function algebra。

## 新結論

Dual-Tension 現在可以拆成兩個不同控制問題：

1. **Should I think more?**
   - residual doubt / freeze controller

2. **What should think next?**
   - VOI specialist scheduler

所以完整控制器開始變成：

```text
source target
    ↓
SURFACE
    ↓
residual doubt D
    ↓
VOI(MPF), VOI(Source), VOI(Bridge), ...
    ↓
argmax VOI
    ↓
run specialist
    ↓
update D
    ├─ low D → FREEZE
    ├─ corruption → REJECT / REFORMULATE
    └─ high D → next specialist
```

## 下一步

EXP-0008 應把 proxy cost 換成**可觀測成本接口**：
- prompt tokens
- completion tokens
- latency
- tool calls
- theorem-prover nodes
- premise retrieval count

即使目前沒有第二模型，也可以先把 Runtime telemetry schema 做好，
未來一接上本地／外部 Agent 就能直接把實測成本灌進同一個 VOI 公式。
