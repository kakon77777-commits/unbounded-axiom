# EXP-0002：MPF × NLU × Doubt/Tolerance 跨問題壓力測試

Experiment ID: `EXP-0002-CROSS-PROBLEM-DUAL-TENSION`  
建立時間：2026-08-10T22:15:00+08:00  
樣本數：8

## 結構代理結果

- Compact-only 平均未決／需展開槽：**5.75**
- MPF-only：**1.88**
- Dual-Tension：**0.25**

> 注意：以上是 14 個固定 audit dimensions 的人工結構標註，不是 wall-clock、token、Lean nodes 或成功率。

## Case Summary

| Case | Compact | MPF | Dual | Controller |
|---|---:|---:|---:|---|
| C01_MONTY_HALL | 14 | 8 | 2 | EXPAND_THEN_FREEZE_FAMILY |
| C02_ERDOS_90 | 8 | 2 | 0 | CONTRACT_AROUND_UNIFORM_OBSTRUCTION |
| C03_ERDOS_448 | 6 | 2 | 0 | EXPAND_PREDICATE_THEN_CONTRACT |
| C04_ERDOS_707 | 5 | 1 | 0 | CONTRACT_TO_HIERARCHICAL_CERTIFICATE |
| C05_ERDOS_1014 | 4 | 0 | 0 | CONTRACT_BY_DEPENDENCY_GRAPH |
| C06_GREEN_3 | 0 | 0 | 0 | CONTRACT_EARLY |
| C07_SIC_POVM_23 | 3 | 2 | 0 | EXPAND_TARGET_FAMILY_BEFORE_FREEZE |
| C08_ERDOS_34 | 6 | 0 | 0 | CONTRACT_TO_ASYMPTOTIC_COUNTERFAMILY |

## Controller 的新行為

- `CONTRACT_EARLY`：問題已足夠明確，避免 NLU 過度展開。
- `EXPAND_PREDICATE_THEN_CONTRACT`：先展開封裝 predicate 內隱量詞，再縮域。
- `EXPAND_TARGET_FAMILY_BEFORE_FREEZE`：正式 statement 精確，但來源問題有多個不同 formulation，先確認 target fidelity。
- `CONTRACT_TO_HIERARCHICAL_CERTIFICATE`：將「反例」拆成外層 witness + 內層 universal obstruction。
- `CONTRACT_AROUND_UNIFORM_OBSTRUCTION`：量詞順序／uniformity 為核心，裁掉 per-instance witness。
- `EXPAND_THEN_FREEZE_FAMILY`：自然語言問題本身存在多個合法模型，先保留模型族。

## 核心結論

Dual-Tension 的目的不是最大化展開，而是控制：
`何時擴域 → 何時縮域 → 何時 freeze target`。

下一步才是固定模型/Lean agent 的真正 A/B/C 執行測試。
