# EXP-0004 — Blinded Agent Target Audit Harness

Experiment ID: `EXP-0004-BLINDED-AGENT-TARGET-AUDIT`  
Created: 2026-08-10T22:57:00+08:00  
Shuffle seed: `202608102257`

## Why this is actually blinded

`blind_test_cases.jsonl` contains only:
- opaque `sample_id`
- `source_context`
- `candidate_target`

It does **not** contain corruption labels, error types, severity, or expected detector.

The gold labels live separately in:
`answer_key_DO_NOT_GIVE_TO_AGENT.json`

## Three modes

- **A — Baseline**: raw target-fidelity audit without MPF vocabulary.
- **B — MPF**: domain/quantifier/dependency/certificate/asymptotic audit.
- **C — Dual-Tension**: MPF + source/NLU/bridge/doubt-tolerance audit.

## Important contamination rule

The current ChatGPT conversation has already seen EXP-0003 labels and explanations.
Therefore any run performed manually by the current conversation model is a:

`CONTAMINATED_CONTROL`

and must **not** be reported as a blinded score.

A valid benchmark run requires a fresh model/session/agent that receives only:
1. the selected prompt file,
2. one blinded sample at a time.

## Running

The included `run_blind.py` accepts a generic chat-completions style HTTP endpoint configured with environment variables:

- `MODEL_API_URL`
- `MODEL_API_KEY` (optional)
- `MODEL_NAME`

Run separately:

```bash
python run_blind.py --mode A
python run_blind.py --mode B
python run_blind.py --mode C
```

Then score without exposing the key to the agent:

```bash
python score_results.py raw_results_mode_A.jsonl raw_results_mode_B.jsonl raw_results_mode_C.jsonl
```

## Data to preserve

Each raw result stores:
- sample ID
- mode
- model
- latency
- usage if endpoint returns it
- raw model text
- parsed JSON if valid
- parse error / request error

## Next proof phase

Only after target-audit results exist should accepted targets be forwarded to Lean/prover search.
That second phase should record proof branches, premises, nodes, time, and success/failure.
