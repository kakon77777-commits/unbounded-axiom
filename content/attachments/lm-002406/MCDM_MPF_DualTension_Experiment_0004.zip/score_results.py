#!/usr/bin/env python3
import argparse, json
from pathlib import Path

HERE = Path(__file__).resolve().parent

def load_jsonl(p):
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("result_files", nargs="+")
    args = ap.parse_args()

    key = json.loads((HERE/"answer_key_DO_NOT_GIVE_TO_AGENT.json").read_text(encoding="utf-8"))
    gold = {x["sample_id"]: x for x in key["answers"]}

    all_metrics = {}
    detail = []
    for fn in args.result_files:
        p = Path(fn)
        rows = load_jsonl(p)
        tp=fp=tn=fnc=0
        reason_ok=0
        reason_total=0
        valid=0
        for r in rows:
            sid = r["sample_id"]
            g = gold[sid]
            parsed = r.get("parsed")
            if not parsed:
                continue
            valid += 1
            pred = bool(parsed.get("flag_corruption"))
            actual = bool(g["is_corrupted"])
            if pred and actual: tp += 1
            elif pred and not actual: fp += 1
            elif (not pred) and (not actual): tn += 1
            else: fnc += 1

            if actual:
                reason_total += 1
                if parsed.get("primary_reason_code") == g["corruption_type"].upper():
                    reason_ok += 1

            detail.append({
                "file": p.name,
                "sample_id": sid,
                "actual_corrupted": actual,
                "pred_corrupted": pred,
                "gold_type": g["corruption_type"],
                "pred_reason": parsed.get("primary_reason_code"),
                "decision": parsed.get("decision"),
                "confidence": parsed.get("confidence"),
            })

        precision = tp/(tp+fp) if tp+fp else 0
        recall = tp/(tp+fnc) if tp+fnc else 0
        specificity = tn/(tn+fp) if tn+fp else 0
        accuracy = (tp+tn)/(tp+tn+fp+fnc) if (tp+tn+fp+fnc) else 0
        f1 = 2*precision*recall/(precision+recall) if precision+recall else 0
        all_metrics[p.name] = {
            "valid_parsed": valid,
            "TP":tp,"FP":fp,"TN":tn,"FN":fnc,
            "precision":precision,"recall":recall,"specificity":specificity,
            "accuracy":accuracy,"f1":f1,
            "exact_reason_accuracy_on_corrupted": reason_ok/reason_total if reason_total else None,
        }

    (HERE/"scored_metrics.json").write_text(json.dumps(all_metrics, indent=2), encoding="utf-8")
    with (HERE/"scored_details.jsonl").open("w",encoding="utf-8") as f:
        for d in detail:
            f.write(json.dumps(d,ensure_ascii=False)+"\n")
    print(json.dumps(all_metrics, indent=2))

if __name__ == "__main__":
    main()
