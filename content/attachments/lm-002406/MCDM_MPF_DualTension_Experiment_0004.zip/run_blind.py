#!/usr/bin/env python3
"""
EXP-0004 generic blinded runner.

Environment:
  MODEL_API_URL   Full chat-completions style endpoint URL.
  MODEL_API_KEY   Optional bearer token.
  MODEL_NAME      Model identifier sent in request.
  TEMPERATURE     default 0
  MAX_TOKENS      default 500

Example:
  MODEL_API_URL=http://localhost:1234/v1/chat/completions \
  MODEL_NAME=local-model \
  python run_blind.py --mode C
"""
import argparse, json, os, time, urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent

PROMPTS = {
    "A": HERE / "prompt_A_baseline.txt",
    "B": HERE / "prompt_B_mpf.txt",
    "C": HERE / "prompt_C_dual_tension.txt",
}

def call_model(system_prompt, user_payload):
    url = os.environ["MODEL_API_URL"]
    model = os.environ.get("MODEL_NAME", "model")
    api_key = os.environ.get("MODEL_API_KEY", "")
    body = {
        "model": model,
        "temperature": float(os.environ.get("TEMPERATURE", "0")),
        "max_tokens": int(os.environ.get("MAX_TOKENS", "500")),
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_payload},
        ],
    }
    data = json.dumps(body).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    t0 = time.perf_counter()
    with urllib.request.urlopen(req, timeout=300) as resp:
        raw = resp.read().decode("utf-8")
    latency = time.perf_counter() - t0
    payload = json.loads(raw)
    # Common chat-completions response shape.
    content = payload["choices"][0]["message"]["content"]
    usage = payload.get("usage", {})
    return content, latency, usage, payload

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["A","B","C"], required=True)
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    system_prompt = PROMPTS[args.mode].read_text(encoding="utf-8")
    cases = [json.loads(x) for x in (HERE/"blind_test_cases.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    if args.limit:
        cases = cases[:args.limit]

    out = HERE / f"raw_results_mode_{args.mode}.jsonl"
    with out.open("w", encoding="utf-8") as f:
        for case in cases:
            user_payload = (
                f"SAMPLE_ID: {case['sample_id']}\n\n"
                f"SOURCE_CONTEXT:\n{case['source_context']}\n\n"
                f"CANDIDATE_TARGET:\n{case['candidate_target']}\n"
            )
            record = {
                "sample_id": case["sample_id"],
                "mode": args.mode,
                "model": os.environ.get("MODEL_NAME","model"),
            }
            try:
                content, latency, usage, raw = call_model(system_prompt, user_payload)
                record.update({
                    "latency_seconds": latency,
                    "usage": usage,
                    "raw_content": content,
                    "api_raw_id": raw.get("id"),
                })
                try:
                    record["parsed"] = json.loads(content)
                    record["parse_ok"] = True
                except Exception as e:
                    record["parse_ok"] = False
                    record["parse_error"] = str(e)
            except Exception as e:
                record.update({"request_error": repr(e)})
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
            print(case["sample_id"], "done")

if __name__ == "__main__":
    main()
