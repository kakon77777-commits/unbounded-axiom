#!/usr/bin/env python3
"""
Minimal specialist distribution-shift monitor.
Consumes specialist observations (cost + reduction vector), maintains EWMA estimates,
and emits change-point events when innovation exceeds a rolling z-score threshold.
"""
import argparse,json,math,statistics
from collections import defaultdict,deque
from pathlib import Path

DIMS=("formal","source","bridge")

class Monitor:
    def __init__(self,alpha=.16,z_threshold=2.6,min_obs=5):
        self.alpha=alpha
        self.z_threshold=z_threshold
        self.min_obs=min_obs
        self.est={}
        self.resid=defaultdict(lambda:deque(maxlen=20))
    def update(self,module,obs):
        if module not in self.est:
            self.est[module]={"cost":obs["cost"],"red":dict(obs["red"])}
            self.resid[module].append(0.0)
            return {"changed":False,"estimate":self.est[module]}
        e=self.est[module]
        cost_err=(obs["cost"]-e["cost"])/max(e["cost"],.1)
        red_err=max(abs(obs["red"][d]-e["red"][d]) for d in DIMS)
        innovation=abs(cost_err)+red_err
        hist=list(self.resid[module])
        z=None; changed=False
        if len(hist)>=self.min_obs:
            mu=statistics.mean(hist); sd=statistics.pstdev(hist) or 1e-6
            z=(innovation-mu)/sd
            changed=z>self.z_threshold
        self.resid[module].append(innovation)
        a=.65 if changed else self.alpha
        e["cost"]=(1-a)*e["cost"]+a*obs["cost"]
        for d in DIMS:
            e["red"][d]=(1-a)*e["red"][d]+a*obs["red"][d]
        if changed:
            self.resid[module].clear(); self.resid[module].append(innovation)
        return {"changed":changed,"z":z,"innovation":innovation,"estimate":dict(e)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("observations_jsonl")
    args=ap.parse_args()
    mon=Monitor()
    for line in Path(args.observations_jsonl).read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        o=json.loads(line)
        out=mon.update(o["module"],o)
        print(json.dumps({"module":o["module"],**out}))

if __name__=="__main__":
    main()
