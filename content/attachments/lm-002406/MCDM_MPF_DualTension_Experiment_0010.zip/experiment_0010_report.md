# EXP-0010：Distribution-Shift-Aware Orchestrator

- Experiment ID: `EXP-0010-DISTRIBUTION-SHIFT-AWARE-ORCHESTRATOR`
- 建立時間：2026-08-10T23:58:00+08:00
- Horizon：180 synthetic tasks
- Shift points：[61, 121]
- 性質：**non-stationary orchestration simulation**
- 所有能力、成本、任務與觀測均為 synthetic，不能視為真實 AI benchmark。

## 問題

EXP-0009 假設：

$$
P(C,R\mid M)
$$

大致穩定。

但真正 Runtime 裡，specialist 會因：

- 模型版本更新；
- prompt 修改；
- API 價格／latency 改變；
- 硬體變更；
- tool / retrieval quality 改變；
- provider degradation；

使：

$$
P_t(C,R\mid M)
\neq
P_{t+1}(C,R\mid M).
$$

因此歷史 telemetry 可能變成**過期知識**。

## 本輪故意製造的世界變化

### Phase 1 — baseline
三個 specialist 正常。

### Phase 2 — t=61
MPF：
- cost 大幅上升；
- formal doubt reduction 明顯下降。

Source Fidelity：
- cost 下降；
- source-fidelity reduction 提升。

### Phase 3 — t=121
Bridge specialist 大幅升級；
MPF 部分恢復。

## 比較策略

1. **Stationary Mean**  
   永久平均所有歷史，幾乎不忘記。

2. **EWMA**  
   舊 observation 指數衰減，自然追蹤近期狀態。

3. **Change-Point Reset**  
   EWMA + innovation detector；觀測與預期差異過大時，局部重置該 specialist 的估計。

## 整體結果

| Policy | Choice accuracy | Wrong choices | Cumulative VOI regret | Avg regret | Realized cost |
|---|---:|---:|---:|---:|---:|
| stationary_mean | 0.883 | 21 | 3.029 | 0.0168 | 228.36 |
| ewma_0.18 | 0.906 | 17 | 4.877 | 0.0271 | 198.63 |
| changepoint_reset | 0.917 | 15 | 3.745 | 0.0208 | 187.70 |

## Shift recovery delay

| Policy | Recovery delays (tasks after shift) |
|---|---|
| stationary_mean | @61: 3, @121: 0 |
| ewma_0.18 | @61: 0, @121: 0 |
| changepoint_reset | @61: 0, @121: 0 |

## Phase-wise regret

| Policy | Phase | Choice accuracy | Regret | Forced exploration |
|---|---|---:|---:|---:|
| stationary_mean | P1_baseline | 0.967 | 0.602 | 4 |
| stationary_mean | P2_mpf_degrades_source_upgrades | 0.733 | 2.300 | 1 |
| stationary_mean | P3_bridge_upgrade_mpf_partial_recovery | 0.950 | 0.128 | 0 |
| ewma_0.18 | P1_baseline | 0.967 | 0.602 | 4 |
| ewma_0.18 | P2_mpf_degrades_source_upgrades | 0.867 | 2.295 | 3 |
| ewma_0.18 | P3_bridge_upgrade_mpf_partial_recovery | 0.883 | 1.980 | 1 |
| changepoint_reset | P1_baseline | 0.967 | 0.602 | 4 |
| changepoint_reset | P2_mpf_degrades_source_upgrades | 0.917 | 1.102 | 3 |
| changepoint_reset | P3_bridge_upgrade_mpf_partial_recovery | 0.867 | 2.042 | 1 |

## Change-point detector events

Change-point policy emitted **5** local reset events.

The important point is not whether every reset lands exactly on t=61 or t=121.
In a partial-observation scheduler, a specialist can only reveal that it changed **when it is called**.
Therefore detection latency decomposes into:

$$
\boxed{
L_{shift}
=
L_{opportunity}
+
L_{statistical}
}
$$

where:
- $L_{opportunity}$: how long until the changed specialist is actually sampled;
- $L_{statistical}$: how many observations are needed before evidence is strong enough.

This is a new reason why **re-exploration after suspected global change** matters.

## New controller state

The Orchestrator can no longer store only:

$$
\widehat C(M),\widehat R(M).
$$

It should store:

$$
\boxed{
\widehat C_t(M),
\widehat R_t(M),
U_t(M),
A_t(M)
}
$$

where $A_t(M)$ is an **age / staleness state**.

A simple staleness score can be:

$$
S_t(M)
=
f(
\Delta t_{last},
\text{innovation},
\text{model version},
\text{prompt version},
\text{runtime class}
).
$$

When staleness rises:

$$
\text{exploration bonus}\uparrow
$$

or historical weight:

$$
w_{old}\downarrow.
$$

## Architectural consequence

We now have two feedback loops:

### Epistemic loop
$$
D_t
\rightarrow
\text{specialist}
\rightarrow
D_{t+1}.
$$

### Operational loop
$$
\text{telemetry}_t
\rightarrow
\widehat{Capability}_t
\rightarrow
\text{routing}
\rightarrow
\text{new telemetry}.
$$

EXP-0010 adds a third:

### Drift loop
$$
\text{prediction error}
\rightarrow
\text{shift suspicion}
\rightarrow
\text{forget / reset / re-explore}
\rightarrow
\text{re-calibration}.
$$

So the upper AI is no longer just an Orchestrator.
It is becoming a **self-monitoring organization controller**.

## Important limitations

- Synthetic hidden environment.
- Synthetic task mix.
- Shift detector thresholds manually selected.
- Oracle regret uses hidden synthetic potential outcomes unavailable in reality.
- No independent Agent and no Lean telemetry yet.

Therefore only the control logic is validated.

## Next step

EXP-0011 can test **specialist replacement and identity continuity**:

Suppose `MPF-v1` is replaced by `MPF-v2`.

Should history be:
- fully inherited?
- partially inherited?
- reset to zero?
- transferred through a similarity prior?

Then the Orchestrator needs a model of:

$$
\boxed{
\text{Specialist Identity}
\neq
\text{Specialist Role}
}
$$

That starts touching exactly the issue we discussed elsewhere:
**model may be a replaceable substrate, while the higher-level functional identity persists.**

## r1：更嚴格的 adaptation metric

原本的「8-task moving choice accuracy ≥ 75%」容易受 task mix 影響。
因此增加 **parameter-level recovery delay**：

- 成本估計相對誤差 ≤ 20%
- 該 specialist 主能力維度的 reduction 絕對誤差 ≤ 0.10

兩者同時滿足才算「重新學到新環境」。

| Policy | Shift | Module | Parameter recovery delay |
|---|---:|---|---:|
| stationary_mean | 61 | MPF | 未在 horizon 內恢復 |
| stationary_mean | 61 | SOURCE_FIDELITY | 69 |
| stationary_mean | 121 | BRIDGE | 未在 horizon 內恢復 |
| stationary_mean | 121 | MPF | 0 |
| ewma_0.18 | 61 | MPF | 38 |
| ewma_0.18 | 61 | SOURCE_FIDELITY | 6 |
| ewma_0.18 | 121 | BRIDGE | 28 |
| ewma_0.18 | 121 | MPF | 25 |
| changepoint_reset | 61 | MPF | 3 |
| changepoint_reset | 61 | SOURCE_FIDELITY | 2 |
| changepoint_reset | 121 | BRIDGE | 20 |
| changepoint_reset | 121 | MPF | 39 |

### Change-point detector 審計

在 ±4-task（只允許 shift 後）匹配窗內：

- matched shift alarms：**3**
- false / late alarms：**2**
- missed module-level true shifts：**1**

這比單看「有沒有發 alarm」更誠實：變點偵測器可以適應快，但也可能過敏。
因此未來真正目標不是最大化 alarm 數，而是：

$$
\boxed{
\min(
L_{recovery},
\text{regret},
\text{false alarms},
\text{re-exploration cost}
)
}
$$

多目標共同最佳化。
