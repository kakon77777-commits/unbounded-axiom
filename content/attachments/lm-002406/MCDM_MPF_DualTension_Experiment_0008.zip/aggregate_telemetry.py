#!/usr/bin/env python3
import argparse, json
from pathlib import Path
from collections import defaultdict

HERE=Path(__file__).resolve().parent

def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def n(v):
    return 0 if v is None else v

def event_cost(e,cfg):
    norm=cfg["normalization"]
    w=cfg["weights_default_proxy"]
    usage=e.get("usage") or {}
    lat=e.get("latency") or {}
    proof=e.get("proof") or {}
    return (
        w["input_tokens"]*n(usage.get("prompt_tokens"))/norm["token_scale"]
        + w["output_tokens"]*n(usage.get("completion_tokens"))/norm["token_scale"]
        + w["reasoning_tokens"]*n(usage.get("reasoning_tokens"))/norm["token_scale"]
        + w["latency"]*n(lat.get("wall_seconds"))/norm["latency_scale_seconds"]
        + w["tool_calls"]*n(usage.get("tool_calls"))/norm["tool_call_scale"]
        + w["proof_nodes"]*n(proof.get("search_nodes"))/norm["proof_node_scale"]
        + w["premises"]*n(proof.get("premises_retrieved"))/norm["premise_scale"]
    )

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("events")
    ap.add_argument("--cost-config",default=str(HERE/"runtime_cost_model_v0.1.json"))
    ap.add_argument("--out",default=str(HERE/"telemetry_summary.json"))
    args=ap.parse_args()

    events=load_jsonl(args.events)
    cfg=json.loads(Path(args.cost_config).read_text(encoding="utf-8"))

    runs=defaultdict(lambda:{
        "events":0,"prompt_tokens":0,"completion_tokens":0,"reasoning_tokens":0,
        "tool_calls":0,"wall_seconds":0.0,"premises_retrieved":0,"search_nodes":0,
        "proof_attempts":0,"composite_proxy_cost":0.0,
        "modules":defaultdict(int),"final_target_status":None,"proof_success":None
    })

    for e in events:
        k=(e["run_id"],e["sample_id"])
        r=runs[k]
        r["events"]+=1
        r["modules"][e["module"]]+=1
        u=e.get("usage") or {}
        l=e.get("latency") or {}
        p=e.get("proof") or {}
        r["prompt_tokens"]+=n(u.get("prompt_tokens"))
        r["completion_tokens"]+=n(u.get("completion_tokens"))
        r["reasoning_tokens"]+=n(u.get("reasoning_tokens"))
        r["tool_calls"]+=n(u.get("tool_calls"))
        r["wall_seconds"]+=n(l.get("wall_seconds"))
        r["premises_retrieved"]+=n(p.get("premises_retrieved"))
        r["search_nodes"]+=n(p.get("search_nodes"))
        r["proof_attempts"]+=n(p.get("proof_attempts"))
        r["composite_proxy_cost"]+=event_cost(e,cfg)
        status=(e.get("target_state") or {}).get("status")
        if status:
            r["final_target_status"]=status
        if p.get("success") is not None:
            r["proof_success"]=p.get("success")

    serial={}
    for (run_id,sample_id),r in runs.items():
        r["modules"]=dict(r["modules"])
        serial[f"{run_id}:{sample_id}"]=r

    out={"cost_config":cfg,"runs":serial}
    Path(args.out).write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))

if __name__=="__main__":
    main()
