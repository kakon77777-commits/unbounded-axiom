"""
Telemetry adapter helpers.
These functions do not call any service themselves; they normalize outputs from future runtimes.
"""
def usage_from_chat_completion(response):
    u=(response or {}).get("usage") or {}
    details=u.get("completion_tokens_details") or {}
    prompt_details=u.get("prompt_tokens_details") or {}
    return {
        "prompt_tokens":u.get("prompt_tokens"),
        "completion_tokens":u.get("completion_tokens"),
        "reasoning_tokens":details.get("reasoning_tokens"),
        "cached_input_tokens":prompt_details.get("cached_tokens"),
    }

def proof_from_lean_run(*, premises_retrieved=None, proof_branches=None, search_nodes=None,
                        tactic_steps=None, elaboration_failures=None, proof_attempts=None,
                        kernel_check_seconds=None, prover_wall_seconds=None, success=None,
                        certificate_hash=None):
    return {
        "premises_retrieved":premises_retrieved,
        "proof_branches":proof_branches,
        "search_nodes":search_nodes,
        "tactic_steps":tactic_steps,
        "elaboration_failures":elaboration_failures,
        "proof_attempts":proof_attempts,
        "kernel_check_seconds":kernel_check_seconds,
        "prover_wall_seconds":prover_wall_seconds,
        "success":success,
        "certificate_hash":certificate_hash,
    }
