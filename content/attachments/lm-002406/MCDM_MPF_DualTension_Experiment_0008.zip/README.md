# EXP-0008 — Runtime Telemetry Contract

Experiment ID: `EXP-0008-RUNTIME-TELEMETRY-CONTRACT`  
Created: 2026-08-10T23:41:00+08:00

## Purpose

EXP-0007 optimized a proxy cost. EXP-0008 defines the telemetry contract required to replace proxy cost with measured runtime cost.

The system must preserve **raw measurements first**:
- prompt/completion/reasoning/cached tokens
- latency / time-to-first-token / queue time
- tool calls
- premise retrieval count
- proof branches / search nodes / tactic steps
- elaboration failures / proof attempts
- kernel/prover wall time
- proof success and certificate hash
- residual doubt before/after
- specialist VOI selection trace
- target state changes (candidate / frozen / rejected / proving / proved)

## Important rule

Composite cost is optional:

`raw telemetry -> calibrated normalization -> composite cost`

Never overwrite or discard raw telemetry after computing a scalar cost.

## Files

- `telemetry_event_schema_v0.1.json` — event contract.
- `runtime_cost_model_v0.1.json` — optional proxy/calibrated cost view.
- `record_event.py` — append telemetry events.
- `aggregate_telemetry.py` — aggregate JSONL into per-run metrics and composite proxy cost.
- `telemetry_adapters.py` — helper normalization for model/prover responses.
- `synthetic_telemetry_example.jsonl` — **synthetic only**, used to verify plumbing.
- `experiment_0008_dataset.xlsx` — human-readable schema / metric dashboard.

## Integration sequence

```text
Agent/Orchestrator
    ↓ emit events
telemetry.jsonl
    ↓ aggregate
raw run metrics
    ↓ optional calibration
C_real(M_i)
    ↓
VOI(M_i | D_t) = expected_doubt_reduction / C_real(M_i)
```

## Real benchmark requirement

A future run is considered measured only if:
1. `model.provider/name/version` are recorded,
2. raw token/latency fields come from the runtime,
3. proof metrics come from actual prover logs,
4. `tags` do not contain `synthetic`,
5. prompt/output/log hashes are preserved.

The included synthetic telemetry must never be mixed into measured benchmark summaries.
