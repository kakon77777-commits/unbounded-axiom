#!/usr/bin/env python3
import argparse, json, hashlib, uuid
from datetime import datetime, timezone
from pathlib import Path

def utc_now():
    return datetime.now(timezone.utc).isoformat()

def sha256_text(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def emit(path, event):
    event.setdefault("schema_version","0.1")
    event.setdefault("event_id",str(uuid.uuid4()))
    event.setdefault("timestamp_utc",utc_now())
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path,"a",encoding="utf-8") as f:
        f.write(json.dumps(event,ensure_ascii=False)+"\n")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",required=True)
    ap.add_argument("--experiment-id",required=True)
    ap.add_argument("--run-id",required=True)
    ap.add_argument("--sample-id",required=True)
    ap.add_argument("--event-type",required=True)
    ap.add_argument("--module",required=True)
    ap.add_argument("--target-status",required=True)
    ap.add_argument("--payload-json",default="{}")
    args=ap.parse_args()

    payload=json.loads(args.payload_json)
    event={
        "experiment_id":args.experiment_id,
        "run_id":args.run_id,
        "sample_id":args.sample_id,
        "event_type":args.event_type,
        "module":args.module,
        "target_state":{"status":args.target_status},
    }
    event.update(payload)
    emit(args.out,event)

if __name__=="__main__":
    main()
