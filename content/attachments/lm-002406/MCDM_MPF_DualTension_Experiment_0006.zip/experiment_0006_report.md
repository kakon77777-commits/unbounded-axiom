# EXP-0006：Holdout Controller Generalization

- Experiment ID: `EXP-0006-HOLDOUT-CONTROLLER-GENERALIZATION`
- Policy frozen from: `EXP-0005 adaptive_freeze_policy_v0`
- 新來源問題：6 個
- Pair samples：12 個（6 clean + 6 corruption variants）
- 性質：**holdout-style analyst-generated test**
- 仍不是獨立 Agent 盲測。

## 結果

- Corruption routing coverage：**1.000**
- False-freeze rate：**0.000**
- Clean freeze rate：**1.000**
- Total module calls：**26**
- Minimal module calls：**23**
- Extra calls：**3**
- Over-expansion rate：**0.115**
- Avg calls/case：**2.167**

## 新型態

### 1. Optimization target replacement
Open Quantum Problem 13 的源問題是「決定最大數量 μ(d)」。
把它改成「所有 d 都存在 d+1 個 MUB」不是單純改寫，而是把最大值問題替換成最強可能存在命題。

### 2. Equivalent-representation coverage
Open Quantum Problem 35 的 AME 定義在 source semantics 上要求所有至多一半大小的 subsystem；
formalization 利用 pure-state 結構，檢查恰好 n/2 大小並透過所有 permutation 覆蓋 subsystem。
如果只留下 first block 而刪除 permutation，表示會失去全域 coverage。

### 3. Definition substitution / provenance gap
OEIS A6697 的 a(n) 原本由 subword complexity 定義。
顯式公式 Σ min(2^i,n-i+1) 可讓生成函數證明變容易，
但若直接把公式改成 a(n) 的定義，就必須另證它與原 subword-defined a(n) 相同，
否則只是證了另一個序列的生成函數。

## Controller 泛化觀察

固定的 0005 policy 在這批新類型上仍能把：
- quantifier/uniformity → MPF
- source-target identity / definition provenance → SOURCE_FIDELITY
- explicit boundary loss → SURFACE
- symmetry coverage → MPF

分派到相應模組。

但 OQP13 clean/corrupt 與 OQP35 corrupt 顯示控制器會有少量保守性 over-expansion：
它有時會同時啟動 MPF + SOURCE_FIDELITY。

這正是下一版可以優化的地方：
不是只追求 0 false-freeze，而是開始學習「哪個 specialist 最可能足夠」。

## 下一步

EXP-0007：建立 **specialist selection probability / value-of-information controller**。
每次疑點出現時，不固定啟動所有可能模組，而估計：
$$
\mathrm{VOI}(M_i)
=
\frac{\text{expected doubt reduction}}{\text{audit cost}}
$$
優先呼叫 VOI 最高的模組。
