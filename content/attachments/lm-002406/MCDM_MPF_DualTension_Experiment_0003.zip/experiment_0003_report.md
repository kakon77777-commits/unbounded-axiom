# EXP-0003：Target Corruption / Error-Injection Test

- Experiment ID: `EXP-0003-TARGET-CORRUPTION-DETECTION`
- 建立時間：2026-08-10T22:43:00+08:00
- 樣本：13（9 個注入錯誤 + 4 個乾淨控制）
- 性質：**人工／規則式審計 benchmark v0**，不是獨立模型實測。

## 目的

測試三條管線是否能在 proof search 前偵測：

- quantifier swap
- domain omission
- unnecessary uniformity
- hidden asymptotic predicate flattening
- certificate truncation
- framework bridge collapse
- wrong source formulation
- finite evidence mistaken for global disproof

同時檢查 clean controls，避免「看到題目就報錯」。

## 結果（規則式）

| Pipeline | TP | FP | TN | FN | Precision | Recall | Specificity | Accuracy | F1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| compact_only | 2 | 0 | 4 | 7 | 1.000 | 0.222 | 1.000 | 0.462 | 0.364 |
| mpf_only | 7 | 0 | 4 | 2 | 1.000 | 0.778 | 1.000 | 0.846 | 0.875 |
| dual_tension | 9 | 0 | 4 | 0 | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

## 重要解讀

這些數值不是 AI 真實能力分數，而是把目前框架規則套到人工注入錯誤後得到的**理論可檢出性**。

### Compact-only
能抓到少數表面就明顯的錯誤（例如明顯漏掉 `open`、只給 A* 卻沒有後續 obstruction），但對：
- 隱藏 predicate 的全域量詞
- framework bridge
- target fidelity
- witness uniformity
通常不足。

### MPF-only
對形式結構錯誤很強：
- quantifier swap
- dependency
- domain
- asymptotic quantifier
- certificate tree

但對「形式化本身是精確的、只是形式化錯了來源問題」這種 target-fidelity 問題，以及 probability→decision 這類跨框架問題，可能無法單獨判斷。

### Dual-Tension
理論上覆蓋 MPF 結構審計，再增加：
- source-target fidelity
- natural-language pragmatics
- framework bridge ledger
- doubt/tolerance control

Clean controls 的角色特別重要：Dual-Tension 不能永遠擴張；像 Green 3 或完全顯式化的 Monty model 應該快速 freeze。

## 下一步

EXP-0004 應把本資料集變成真正的 blinded agent benchmark：
1. 隱藏 `is_corrupted` 與解釋欄。
2. 只給 clean/corrupted target。
3. 分別用三種 system prompt 模式跑同一模型。
4. 保留 raw response、tokens、latency、判定與理由。
5. 再把通過 audit 的 target 送進 Lean/prover，測 proof-search 成本。
