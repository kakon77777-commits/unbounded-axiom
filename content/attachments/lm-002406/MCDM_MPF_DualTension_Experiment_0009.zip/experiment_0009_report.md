# EXP-0009：Self-Calibrating Orchestrator

- Experiment ID: `EXP-0009-SELF-CALIBRATING-ORCHESTRATOR`
- 建立時間：2026-08-10T23:52:00+08:00
- 性質：**self-calibration plumbing test + synthetic online-learning simulation**
- 目前沒有任何真實 Agent/Lean telemetry，因此不得把本輪解讀為實證性能。

## 從 EXP-0008 到 EXP-0009

EXP-0008 定義：

$$
\text{raw telemetry}
\rightarrow C(M)
$$

EXP-0009 增加：

$$
\text{history}
\rightarrow
\widehat C(M),
\qquad
\widehat R(M,D)
$$

其中 $\widehat R$ 是 specialist 在某種 doubt 狀態下的預期消疑能力。

因此：

$$
\widehat{VOI}(M\mid D)
=
\frac{\mathbb E[\Delta D\mid M,history]}
{\widehat C(M)}.
$$

## 但只做 exploitation 會有新問題

若某 specialist 從未被叫過：

- 沒資料；
- 估計不確定；
- 如果因不確定而永遠不叫；
- 就永遠不可能學到它其實很好。

所以本輪加入：

$$
\boxed{
Score(M)
=
\widehat{VOI}(M)
+
\beta U(M)
}
$$

其中 $U(M)$ 是 uncertainty。

這形成：

$$
\boxed{
Exploitation
\leftrightarrow
Exploration
}
$$

的新張力。

## 初始歷史資料

EXP-0008 的既有 synthetic telemetry 很稀疏：它主要觀測到 MPF，
所以初始時：

- MPF posterior 已開始偏離人工 proxy；
- Source Fidelity / Bridge 仍主要靠 prior；
- 它們的不確定度較高。

這正好測 exploration bonus 是否能避免「有資料的模組永遠壟斷」。

## 三輪 synthetic online simulation

| Epoch | Accuracy | Proxy cost | Calls | Avg cost/case |
|---|---:|---:|---:|---:|
| 1 | 1.000 | 21.36 | 24 | 1.78 |
| 2 | 1.000 | 20.07 | 24 | 1.67 |
| 3 | 1.000 | 20.99 | 24 | 1.75 |

這些數據來自隱藏的 synthetic environment，只用來驗證 update loop 是否工作。

## Calibration movement

| Module | Prior Cost | Initial Posterior | Final Posterior | Hidden Synthetic Cost |
|---|---:|---:|---:|---:|
| MPF | 2.000 | 1.647 | 1.585 | 1.550 |
| SOURCE_FIDELITY | 1.300 | 1.300 | 1.087 | 1.050 |
| BRIDGE | 1.200 | 1.200 | 1.200 | 0.900 |

正常情況下，觀測數增加後：
- posterior cost 應往 telemetry 的實際平均移動；
- reduction matrix 應往觀測消疑率移動；
- uncertainty 應下降；
- exploration bonus 隨之下降。

所以 Orchestrator 的生命週期變成：

```text
cold start
   ↓
prior-based routing
   ↓
telemetry accumulation
   ↓
posterior update
   ↓
exploration + exploitation
   ↓
better specialist selection
   ↓
more telemetry
   ↺
```

## 這和一般「模型訓練」不同

目前它不是重新訓練基礎 LLM。

學的是：

$$
\boxed{
\text{which cognitive resource to allocate, when, and at what cost}
}
$$

即 meta-policy / orchestration policy。

底層 specialist 甚至可以完全不變，
上層 Orchestrator 仍可以因歷史經驗而變得更節省。

## 風險

1. **Selection bias**：只看被叫過的 specialist，歷史不是隨機樣本。
2. **Non-stationarity**：模型版本、硬體、prompt、tool 都會變，舊成本可能失效。
3. **Doubt calibration error**：如果 residual doubt 本身估錯，VOI 也會跟著錯。
4. **Exploration waste**：探索太強會重新退化成 Always-Dual。
5. **Premature exploitation**：探索太弱會鎖死在早期偶然表現好的 specialist。

因此未來應保存：
- model/version
- prompt version
- runtime/hardware class
- timestamp
- source-domain features
- target-state features

並允許 estimator 做版本分層與時間衰減。

## 下一步

EXP-0010 可以開始做 **non-stationary / model-swap test**：

突然把某 specialist 的：
- 模型換掉；
- prompt 改掉；
- latency/price 改掉；
- 正確率退化或提升；

看 Self-Calibrating Orchestrator 能否偵測 distribution shift，
降低舊資料權重並重新探索。
