#!/usr/bin/env python3
"""
Self-calibration learner for Dual-Tension specialists.
Consumes measured telemetry summaries/observations and maintains shrinkage estimates.
No external ML library required.
"""
import argparse, json, math
from pathlib import Path
from collections import defaultdict

MODULES=("MPF","SOURCE_FIDELITY","BRIDGE")
DIMS=("formal","source","bridge")

def load_jsonl(path):
    return [json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]

def posterior(prior_cost, prior_red, observations, prior_strength=2.0):
    by=defaultdict(list)
    for o in observations:
        by[o["module"]].append(o)
    out={}
    for m in MODULES:
        obs=by[m]
        n=len(obs)
        cost=(prior_strength*prior_cost[m]+sum(x["cost"] for x in obs))/(prior_strength+n)
        red={}
        for d in DIMS:
            vals=[x["reduction"].get(d) for x in obs if x.get("reduction",{}).get(d) is not None]
            red[d]=(prior_strength*prior_red[m][d]+sum(vals))/(prior_strength+len(vals))
        out[m]={
            "n_obs":n,
            "cost_mean":cost,
            "reduction_mean":red,
            "uncertainty":1/math.sqrt(prior_strength+n)
        }
    return out

def score(module,doubt,est,beta=0.18):
    er=sum(doubt[d]*est[module]["reduction_mean"][d] for d in DIMS)
    voi=er/max(est[module]["cost_mean"],1e-9)
    return {"voi":voi,"exploration_bonus":beta*est[module]["uncertainty"],
            "score":voi+beta*est[module]["uncertainty"]}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("observations")
    ap.add_argument("--config",default="self_calibration_policy_v0.1.json")
    ap.add_argument("--doubt",default='{"formal":0.5,"source":0.5,"bridge":0.1}')
    args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text(encoding="utf-8"))
    obs=load_jsonl(args.observations)
    est=posterior(cfg["cost_prior"],cfg["reduction_prior"],obs,cfg["prior_strength"])
    d=json.loads(args.doubt)
    scores={m:score(m,d,est,cfg["exploration_beta"]) for m in MODULES}
    print(json.dumps({"estimates":est,"scores":scores,
                      "selected":max(scores,key=lambda m:scores[m]["score"])},indent=2))

if __name__=="__main__":
    main()
