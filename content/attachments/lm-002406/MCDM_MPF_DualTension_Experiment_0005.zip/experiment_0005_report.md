# EXP-0005：Adaptive Freeze Controller / Expansion Budget Test

- Experiment ID: `EXP-0005-ADAPTIVE-FREEZE-CONTROLLER`
- 建立時間：2026-08-10T23:22:00+08:00
- Data revision：**r1**
- Lean/Lake runtime：**此環境未安裝**
- 本輪性質：**gold-triggered controller simulation / 結構成本代理**
- 不可解讀為真實 token、latency 或 theorem-prover node benchmark。

## Revision note

初版輸出曾把「某 audit module 被呼叫」誤當成「該模組報 corruption」，
因此 clean controls 被錯記為 false positive。r1 已修正：
**模組呼叫只是審計成本；乾淨 target 可被審計後正常 FREEZE。**

## 控制目標

$$
\min \; C_{audit}
\quad
\text{subject to}
\quad
\Pr(\text{accept corrupted target}) \approx 0.
$$

本輪把每個 audit module invocation 記為 1 個結構成本單位。

## 四種策略

1. `S0_surface_only`：只跑 Surface。
2. `S1_always_mpf`：每題固定跑 Surface + MPF。
3. `S2_always_dual`：每題固定跑 Surface + MPF + Source Fidelity + Bridge。
4. `S3_adaptive_controller`：Surface 起步，只有 trigger 出現才增加專門模組。

## 修正後結果

| Strategy | Recall | Accuracy | Specificity | Module calls | Avg/case | Over-expansion calls |
|---|---:|---:|---:|---:|---:|---:|
| S0_surface_only | 0.111 | 0.385 | 1.000 | 13 | 1.000 | 0 |
| S1_always_mpf | 0.778 | 0.846 | 1.000 | 26 | 2.000 | 5 |
| S2_always_dual | 1.000 | 1.000 | 1.000 | 52 | 4.000 | 30 |
| S3_adaptive_controller | 1.000 | 1.000 | 1.000 | 22 | 1.692 | 0 |

## 核心觀察

### Surface-only
Development-set corruption recall = **0.111**。
它便宜，但只能抓顯式 domain/statement mismatch 一類錯誤。

### Always-MPF
Recall = **0.778**。
對量詞、uniformity、predicate、certificate、asymptotic corruption 很強，
但仍漏掉：
- cross-framework bridge collapse；
- precise-but-wrong source formulation。

### Always-Dual
Recall / accuracy / specificity 都是 **1.000**（在這個 development-set capability simulation 裡），
但固定四模組對 13 題需 **52** 次 module calls，
其中 **30** 次超過該案例的最小分析路徑。

### Adaptive controller
同樣在 development set 達到完整 coverage，
但只需 **22** 次 module calls，
相較 Always-Dual 的結構 module-call proxy 減少約 **57.7%**。

再次強調：這不是實際算力節省率，而是 audit-module invocation 的代理。

## Freeze 原則

$$
\tau_{interpret}>0,
\qquad
\tau_{proof}=0.
$$

控制器的目的不是永遠懷疑，而是讓疑點驅動專門模組：

```text
SURFACE
  ├─ decisive mismatch → REJECT
  ├─ explicit + stable → FREEZE
  └─ residual doubt
       ├─ formal structure → MPF
       ├─ source identity → SOURCE_FIDELITY
       └─ framework transition → BRIDGE
                    ↓
              recompute doubt
                    ↓
             EXPAND / CONTRACT / FREEZE
```

## 下一個真正檢驗

EXP-0006 必須換成一批**沒有參與 controller 設計的 holdout 問題**。
否則 0005 只能告訴我們 controller 在 development set 上是否自洽，不能證明泛化。
