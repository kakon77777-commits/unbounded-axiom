# EXP-0001：三門問題 Dual-Tension A/B/C 實戰測試

- 建立時間：2026-08-10T22:10:00+08:00
- 實驗 ID：`EXP-0001-MONTY-HALL-DUAL-TENSION`
- 性質：結構性前置實驗（不是 Lean/prover wall-clock benchmark）

## 實驗目的

比較三種輸入處理：

1. **A — Compact-only**：只讀傳統壓縮問題。
2. **B — MPF-only**：先形式化物件、定義域、協議與 proof-relevant semantics。
3. **C — MPF + NLU + Doubt/Tolerance**：形式化收斂線與自然語言擴張線並行，保留橋樑帳本與問題合法性懷疑。

## 主要代理指標

| Pipeline | 未決語義槽 | 候選路由數（proxy） | 相對 A 的路由縮減 | 早熟收斂風險 |
|---|---:|---:|---:|---|
| A_compact_only | 14 | 12 | 0.0% | high |
| B_mpf_only | 8 | 5 | 58.3% | medium |
| C_dual_tension_mpf_nlu_doubt | 2 | 5 | 58.3% | low if freeze rule obeyed |

## 初步結論

### 1. MPF 有效縮小「協議不明」造成的搜索空間
MPF 把 `host policy` 顯式化後，標準 2/3 不再被當作無條件唯一模型，而只是某個 protocol slice。

### 2. MPF 單獨仍會遺漏自然語言／語用層
例如：
- 誰知道規則；
- 參賽者是否信任規則；
- 是否有額外信號；
- 「應該換」是概率陳述還是效用決策。

### 3. Dual-Tension 的目標不是把所有歧義清零
它保留一個**模型族**，並在 theorem-target freeze 前允許高 interpretation tolerance；一旦 target freeze，proof tolerance 必須為 0。

### 4. 本輪最重要的新增資料結構
- Formal lane
- Interpretive lane
- Doubt triggers
- Tolerance state
- Bridge ledger
- Candidate model family
- Target-freeze decision

## 數據誠實性

`candidate_route_count_proxy` 與 `unresolved_semantic_slots` 是本輪人工結構化代理指標，**不是**實際 LLM latency、token 數、Lean search nodes 或 prover runtime。

下一輪若做正式 benchmark，至少應保存：
- raw prompt
- model/version
- seed
- token budget
- latency
- route proposals
- proof branches
- premise retrieval set
- theorem-prover logs
- success/failure certificate
- semantic audit decisions

## 來源追蹤

本實驗以使用者提供的三份三門問題研究檔為主要語義基礎，並保留原始 file_id 與相關行範圍於 `experiment_0001_full.json` 的 `manifest.source_files`。
