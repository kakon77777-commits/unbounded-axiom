from __future__ import annotations

from uuid import uuid4

from sqlalchemy.orm import Session

from ando.db.models import Event, StateMeta, utcnow


def append_event(
    session: Session,
    *,
    event_type: str,
    entity_type: str,
    entity_id: str,
    state_revision: int,
    actor_type: str = "runtime",
    actor_id: str | None = None,
    delegation_id: str | None = None,
    payload: dict | None = None,
) -> Event:
    event = Event(
        event_id=str(uuid4()),
        event_type=event_type,
        actor_type=actor_type,
        actor_id=actor_id,
        entity_type=entity_type,
        entity_id=entity_id,
        delegation_id=delegation_id,
        state_revision=state_revision,
        payload_json=payload or {},
        created_at=utcnow(),
    )
    session.add(event)
    session.flush()
    ledger_meta = session.get(StateMeta, "ledger_seq")
    if ledger_meta is not None:
        ledger_meta.value = str(event.seq)
        ledger_meta.updated_at = utcnow()
    return event
