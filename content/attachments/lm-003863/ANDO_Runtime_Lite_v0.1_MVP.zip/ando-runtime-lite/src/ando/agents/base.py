from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Protocol


@dataclass(frozen=True)
class AgentDescription:
    agent_id: str
    capabilities: frozenset[str] = field(default_factory=frozenset)
    available: bool = True
    adapter_type: str = "generic"


@dataclass(frozen=True)
class ExecutionContext:
    intent: Any
    task: Any
    delegation: Any
    state_revision: int
    task_version: int
    latest_checkpoint: Any = None
    artifact_refs: tuple[str, ...] = ()
    workspace_path: Path | None = None


@dataclass
class AgentResult:
    status: str
    artifacts: list[Path] = field(default_factory=list)
    checkpoint: dict[str, Any] | None = None
    note: str | None = None


class AgentAdapter(Protocol):
    agent_id: str

    def describe(self) -> AgentDescription: ...
    def can_accept(self, task: Any, delegation: Any) -> bool: ...
    def accept(self, delegation: Any) -> bool: ...
    def execute(self, context: ExecutionContext) -> AgentResult: ...
    def resume(self, context: ExecutionContext, checkpoint: Any) -> AgentResult: ...
    def cancel(self, delegation_id: str) -> None: ...
    def health(self) -> bool: ...
