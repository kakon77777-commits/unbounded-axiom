from __future__ import annotations

from ando.agents.base import AgentAdapter


class AgentRegistry:
    def __init__(self) -> None:
        self._agents: dict[str, AgentAdapter] = {}

    def register(self, adapter: AgentAdapter) -> None:
        self._agents[adapter.agent_id] = adapter

    def get(self, agent_id: str) -> AgentAdapter:
        return self._agents[agent_id]

    def all(self) -> list[AgentAdapter]:
        return list(self._agents.values())

    def compatible(self, capability: str | None = None) -> list[AgentAdapter]:
        result: list[AgentAdapter] = []
        for adapter in self._agents.values():
            desc = adapter.describe()
            if not desc.available or not adapter.health():
                continue
            if capability is None or capability in desc.capabilities:
                result.append(adapter)
        return result
