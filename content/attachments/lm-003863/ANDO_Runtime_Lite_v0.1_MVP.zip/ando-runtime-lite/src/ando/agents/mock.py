from __future__ import annotations

from typing import Any, Iterable
from pathlib import Path
import json
import zipfile

from ando.agents.base import AgentDescription, AgentResult, ExecutionContext


class MockAgent:
    def __init__(self, agent_id: str, *, capabilities: Iterable[str] = (), mode: str = "success") -> None:
        self.agent_id = agent_id
        self.capabilities = frozenset(capabilities)
        self.mode = mode
        self._healthy = True
        self._execute_count = 0

    def describe(self) -> AgentDescription:
        return AgentDescription(
            agent_id=self.agent_id,
            capabilities=self.capabilities,
            available=self._healthy,
            adapter_type="mock",
        )

    def can_accept(self, task: Any, delegation: Any) -> bool:
        return self._healthy

    def accept(self, delegation: Any) -> bool:
        return self._healthy

    def health(self) -> bool:
        return self._healthy

    def cancel(self, delegation_id: str) -> None:
        return None

    def execute(self, context: ExecutionContext) -> AgentResult:
        self._execute_count += 1
        if self.mode == "fail_once" and self._execute_count == 1:
            return AgentResult(status="failed", note="injected fail-once")
        if self.mode == "checkpoint_then_success":
            return AgentResult(
                status="completed",
                checkpoint={
                    "progress": 0.5,
                    "completed": ["first-half"],
                    "open": ["finish"],
                    "next_action": "finish",
                },
            )
        if self.mode == "always_fail":
            return AgentResult(status="failed", note="injected permanent failure")
        if self.mode == "crash_after_checkpoint":
            self._healthy = False
            return AgentResult(
                status="crashed",
                checkpoint={
                    "progress": 0.5,
                    "completed": ["before-crash"],
                    "open": ["resume"],
                    "next_action": "resume",
                },
                note="injected crash",
            )
        if self.mode == "demo":
            if context.workspace_path is None:
                return AgentResult(status="failed", note="workspace required")
            artifacts_dir = Path(context.workspace_path) / "artifacts"
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            title = context.task.title
            if title == "Create README":
                path = artifacts_dir / "README.md"
                path.write_text("# ANDO Demo Package\n\nCreated by ANDO Runtime Lite.\n", encoding="utf-8")
                return AgentResult(status="completed", artifacts=[path])
            if title == "Create Metadata":
                path = artifacts_dir / "metadata.json"
                path.write_text(json.dumps({"name": "ando-demo", "version": "0.1"}, indent=2), encoding="utf-8")
                return AgentResult(status="completed", artifacts=[path])
            if title == "Package Output":
                path = artifacts_dir / "demo-package.zip"
                with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
                    for source_name in ("README.md", "metadata.json"):
                        source = artifacts_dir / source_name
                        if source.exists():
                            zf.write(source, source.name)
                return AgentResult(status="completed", artifacts=[path])
            return AgentResult(status="completed")
        return AgentResult(status="completed")

    def resume(self, context: ExecutionContext, checkpoint: Any) -> AgentResult:
        return self.execute(context)
