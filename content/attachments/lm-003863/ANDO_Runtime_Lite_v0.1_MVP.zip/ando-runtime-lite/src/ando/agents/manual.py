from __future__ import annotations

from typing import Any, Iterable

from ando.agents.base import AgentDescription, AgentResult, ExecutionContext


class ManualAgent:
    def __init__(self, agent_id: str, *, capabilities: Iterable[str] = ()) -> None:
        self.agent_id = agent_id
        self.capabilities = frozenset(capabilities)
        self._healthy = True

    def describe(self) -> AgentDescription:
        return AgentDescription(
            agent_id=self.agent_id,
            capabilities=self.capabilities,
            available=self._healthy,
            adapter_type="manual",
        )

    def can_accept(self, task: Any, delegation: Any) -> bool:
        return self._healthy

    def accept(self, delegation: Any) -> bool:
        return self._healthy

    def execute(self, context: ExecutionContext) -> AgentResult:
        return AgentResult(status="manual_required", note="manual action required")

    def resume(self, context: ExecutionContext, checkpoint: Any) -> AgentResult:
        return self.execute(context)

    def cancel(self, delegation_id: str) -> None:
        return None

    def health(self) -> bool:
        return self._healthy
