from __future__ import annotations

from fastapi import FastAPI

from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore
from ando.web.routes import router


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    app = FastAPI(title="ANDO Runtime Lite v0.1")
    app.state.settings = settings
    app.state.engine = engine
    app.state.store = StateStore(session_factory)
    app.include_router(router)
    return app
