from __future__ import annotations

from ando.agents.base import ExecutionContext
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.delegation.receipts import record_receipt
from ando.state.store import StateStore, StaleStateError


class ExecutionSupervisor:
    def __init__(
        self,
        store: StateStore,
        registry: AgentRegistry,
        settings: Settings,
        *,
        max_retries: int = 2,
    ) -> None:
        self.store = store
        self.registry = registry
        self.settings = settings
        self.max_retries = max_retries

    def _accept_if_needed(self, delegation_id: str) -> bool:
        delegation = self.store.get_delegation(delegation_id)
        adapter = self.registry.get(delegation.delegate_agent_id)
        task = self.store.get_task(delegation.task_id)
        if delegation.status == "Offered":
            if not adapter.can_accept(task, delegation) or not adapter.accept(delegation):
                self.store.set_delegation_status(delegation.id, "Rejected")
                return False
            self.store.set_delegation_status(delegation.id, "Accepted")
            task = self.store.get_task(task.id)
            self.store.update_task(
                task.id,
                task.version,
                status="Running",
                assigned_agent_id=adapter.agent_id,
                active_delegation_id=delegation.id,
            )
            self.store.set_delegation_status(delegation.id, "Running")
        return True

    def _context(self, delegation_id: str) -> ExecutionContext:
        delegation = self.store.get_delegation(delegation_id)
        task = self.store.get_task(delegation.task_id)
        intent = self.store.get_intent(task.intent_id)
        checkpoint = self.store.latest_checkpoint(task.id)
        return ExecutionContext(
            intent=intent,
            task=task,
            delegation=delegation,
            state_revision=self.store.current_revision(),
            task_version=task.version,
            latest_checkpoint=checkpoint,
            artifact_refs=tuple(checkpoint.artifact_refs_json if checkpoint else ()),
            workspace_path=self.settings.workspace,
        )

    def run_delegation(self, delegation_id: str) -> str:
        if not self._accept_if_needed(delegation_id):
            return "rejected"
        delegation = self.store.get_delegation(delegation_id)
        adapter = self.registry.get(delegation.delegate_agent_id)

        for attempt in range(self.max_retries + 1):
            context = self._context(delegation_id)
            if attempt == 0 and context.latest_checkpoint is not None and delegation.parent_delegation_id:
                result = adapter.resume(context, context.latest_checkpoint)
            else:
                result = adapter.execute(context)
            record_receipt(
                self.store,
                receipt_type="execution_attempt",
                delegation_id=delegation_id,
                task_id=context.task.id,
                agent_id=adapter.agent_id,
                payload={"attempt": attempt + 1, "status": result.status, "note": result.note},
            )
            for artifact_path in result.artifacts:
                self.store.create_artifact(
                    task_id=context.task.id,
                    delegation_id=delegation_id,
                    type=artifact_path.suffix.lstrip(".") or "file",
                    name=artifact_path.name,
                    path=artifact_path,
                    created_by_agent_id=adapter.agent_id,
                )
            if result.checkpoint:
                self.store.create_checkpoint(
                    task_id=context.task.id,
                    delegation_id=delegation_id,
                    agent_id=adapter.agent_id,
                    task_version=context.task.version,
                    progress=result.checkpoint,
                    next_step={"next_action": result.checkpoint.get("next_action")},
                    open_issues=result.checkpoint.get("open_issues", []),
                    artifact_refs=[],
                )
            if result.status == "completed":
                self.store.set_delegation_status(delegation_id, "Delivered")
                task = self.store.get_task(context.task.id)
                try:
                    self.store.update_task(task.id, task.version, status="Completed")
                except StaleStateError:
                    return "stale"
                self.store.set_delegation_status(delegation_id, "Completed")
                return "completed"
            if result.status == "manual_required":
                return "manual_required"
            if result.status in {"crashed", "unhealthy"}:
                self.store.set_delegation_status(delegation_id, "Paused")
                return "crashed"
            if result.status == "failed" and attempt < self.max_retries:
                continue
            if result.status == "failed":
                task = self.store.get_task(context.task.id)
                self.store.update_task(task.id, task.version, status="Failed")
                self.store.set_delegation_status(delegation_id, "Paused")
                return "failed"
            return result.status
        return "failed"
