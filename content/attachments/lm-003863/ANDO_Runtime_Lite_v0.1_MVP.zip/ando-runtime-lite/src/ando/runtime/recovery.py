from __future__ import annotations

from ando.agents.registry import AgentRegistry
from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore


class RecoveryManager:
    def __init__(
        self,
        store: StateStore,
        registry: AgentRegistry,
        scheduler: Scheduler,
        supervisor: ExecutionSupervisor,
    ) -> None:
        self.store = store
        self.registry = registry
        self.scheduler = scheduler
        self.supervisor = supervisor

    def replace_failed_delegation(self, delegation_id: str):
        old = self.store.get_delegation(delegation_id)
        task = self.store.get_task(old.task_id)
        candidates = [
            a for a in self.registry.compatible(None)
            if a.agent_id != old.delegate_agent_id
        ]
        if not candidates:
            return None
        adapter = candidates[0]
        desc = adapter.describe()
        self.store.register_agent_record(
            agent_id=adapter.agent_id,
            name=adapter.agent_id,
            adapter_type=desc.adapter_type,
            capabilities=sorted(desc.capabilities),
        )
        # Replacement inherits, rather than widens, the prior envelope.
        replacement = self.store.create_delegation_record(
            task_id=task.id,
            delegate_agent_id=adapter.agent_id,
            state_revision=self.store.current_revision(),
            task_version=task.version,
            authority=dict(old.authority_json),
            budget=dict(old.budget_json),
            parent_delegation_id=old.id,
            grantor_type="recovery",
            grantor_id=old.delegate_agent_id,
        )
        self.store.set_delegation_status(old.id, "Expired")
        return replacement

    def revoke(self, delegation_id: str) -> list[str]:
        from sqlalchemy import select
        from ando.db.models import Delegation

        revoked: list[str] = []
        queue = [delegation_id]
        while queue:
            current = queue.pop(0)
            delegation = self.store.get_delegation(current)
            if delegation.status != "Revoked":
                try:
                    self.registry.get(delegation.delegate_agent_id).cancel(current)
                except KeyError:
                    pass
                self.store.set_delegation_status(current, "Revoked")
                revoked.append(current)
            with self.store.session_factory() as session:
                children = list(session.scalars(
                    select(Delegation.id).where(Delegation.parent_delegation_id == current)
                ))
            queue.extend(children)

        # Pause only tasks whose active delegation was revoked.
        for task in self.store.tasks(statuses=["Running"]):
            if task.active_delegation_id in revoked:
                self.store.update_task(task.id, task.version, status="Paused")
        return revoked
