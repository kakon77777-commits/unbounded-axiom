from __future__ import annotations

from dataclasses import dataclass

from ando.agents.registry import AgentRegistry
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore
from ando.tasks.readiness import resolve_ready_tasks


@dataclass(frozen=True)
class TickReport:
    ready_count: int = 0
    delegations_created: int = 0
    executions_processed: int = 0
    recoveries_created: int = 0
    human_items_created: int = 0


class Orchestrator:
    def __init__(
        self,
        store: StateStore,
        registry: AgentRegistry,
        scheduler: Scheduler,
        supervisor: ExecutionSupervisor,
        recovery: RecoveryManager,
    ) -> None:
        self.store = store
        self.registry = registry
        self.scheduler = scheduler
        self.supervisor = supervisor
        self.recovery = recovery

    def tick(self) -> TickReport:
        ready_ids = resolve_ready_tasks(self.store)
        selected = self.scheduler.select(self.store, self.registry)
        created_ids: list[str] = []
        selected_task_ids: set[str] = set()

        for task, adapter in selected:
            # Avoid duplicate scheduling if a task was assigned during an earlier pass.
            current = self.store.get_task(task.id)
            if current.status != "Ready" or current.active_delegation_id:
                continue
            delegation = self.scheduler.create_delegation(self.store, current, adapter)
            created_ids.append(delegation.id)
            selected_task_ids.add(task.id)

        human_created = 0
        for task in self.store.tasks(statuses=["Ready"]):
            if task.id in selected_task_ids:
                continue
            required = task.constraints_json.get("required_capability") if task.constraints_json else None
            if not self.registry.compatible(required):
                before = len(self.store.unresolved_human_items())
                self.store.require_human(
                    task_id=task.id,
                    reason="NO_COMPATIBLE_AGENT",
                    question=f"No compatible agent is available for task '{task.title}'.",
                    options=["manual", "pause", "cancel"],
                    recommendation={"action": "manual"},
                )
                after = len(self.store.unresolved_human_items())
                human_created += max(0, after - before)

        executions = 0
        # Process newly created and any previously offered delegations once per tick.
        runnable = {d.id for d in self.store.delegations(statuses=["Offered", "Accepted", "Running"])}
        for delegation_id in sorted(runnable):
            self.supervisor.run_delegation(delegation_id)
            executions += 1

        recoveries = 0
        for paused in self.store.delegations(statuses=["Paused"]):
            try:
                healthy = self.registry.get(paused.delegate_agent_id).health()
            except KeyError:
                healthy = False
            if not healthy:
                replacement = self.recovery.replace_failed_delegation(paused.id)
                if replacement is not None:
                    recoveries += 1
                else:
                    before = len(self.store.unresolved_human_items())
                    self.store.require_human(
                        task_id=paused.task_id,
                        delegation_id=paused.id,
                        reason="NO_COMPATIBLE_AGENT",
                        question="No replacement agent is available after failure.",
                        options=["manual", "pause", "cancel"],
                        recommendation={"action": "manual"},
                    )
                    human_created += max(0, len(self.store.unresolved_human_items()) - before)

        return TickReport(
            ready_count=len(ready_ids),
            delegations_created=len(created_ids),
            executions_processed=executions,
            recoveries_created=recoveries,
            human_items_created=human_created,
        )
