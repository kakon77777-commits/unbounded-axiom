from __future__ import annotations

from ando.agents.base import AgentAdapter
from ando.agents.registry import AgentRegistry
from ando.db.models import Task
from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.delegation.validation import validate_child_delegation
from ando.state.store import StateStore


class Scheduler:
    def select(self, store: StateStore, registry: AgentRegistry) -> list[tuple[Task, AgentAdapter]]:
        selected: list[tuple[Task, AgentAdapter]] = []
        used_agents: set[str] = set()
        for task in store.tasks(statuses=["Ready"]):
            required = task.constraints_json.get("required_capability") if task.constraints_json else None
            candidates = registry.compatible(required)
            candidate = next((agent for agent in candidates if agent.agent_id not in used_agents), None)
            if candidate is None:
                continue
            selected.append((task, candidate))
            used_agents.add(candidate.agent_id)
        return selected

    def create_delegation(
        self,
        store: StateStore,
        task: Task,
        adapter: AgentAdapter,
        parent_delegation_id: str | None = None,
    ):
        desc = adapter.describe()
        store.register_agent_record(
            agent_id=adapter.agent_id,
            name=adapter.agent_id,
            adapter_type=desc.adapter_type,
            capabilities=sorted(desc.capabilities),
        )
        source_revision = store.current_revision()
        authority = AuthorityEnvelope.default_internal()
        if task.constraints_json.get("allow_export"):
            authority = AuthorityEnvelope(
                actions=authority.actions,
                scopes=authority.scopes,
                commit_classes=frozenset(set(authority.commit_classes) | {"W2"}),
                subdelegation=authority.subdelegation,
            )
        budget = BudgetEnvelope(time_seconds=3600, tool_calls=50, agent_slots=2)
        if parent_delegation_id is not None:
            parent = store.get_delegation(parent_delegation_id)
            validate_child_delegation(
                AuthorityEnvelope.from_dict(parent.authority_json),
                BudgetEnvelope.from_dict(parent.budget_json),
                authority,
                budget,
            )
        return store.create_delegation_record(
            task_id=task.id,
            delegate_agent_id=adapter.agent_id,
            state_revision=source_revision,
            task_version=task.version,
            authority=authority.to_dict(),
            budget=budget.to_dict(),
            parent_delegation_id=parent_delegation_id,
        )
