from __future__ import annotations

from sqlalchemy import create_engine, event, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from ando.config import Settings
from ando.db.models import Base, StateMeta, utcnow


def create_engine_and_session(settings: Settings) -> tuple[Engine, sessionmaker[Session]]:
    engine = create_engine(f"sqlite:///{settings.database_path}", future=True)

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, _connection_record) -> None:
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys = ON")
        cursor.execute("PRAGMA journal_mode = WAL")
        cursor.execute("PRAGMA synchronous = NORMAL")
        cursor.close()

    return engine, sessionmaker(bind=engine, expire_on_commit=False, future=True)


def init_database(engine: Engine) -> None:
    Base.metadata.create_all(engine)
    defaults = {
        "state_revision": "0",
        "ledger_seq": "0",
        "schema_version": "0.1",
    }
    with Session(engine) as session, session.begin():
        for key, value in defaults.items():
            existing = session.scalar(select(StateMeta).where(StateMeta.key == key))
            if existing is None:
                session.add(StateMeta(key=key, value=value, updated_at=utcnow()))
