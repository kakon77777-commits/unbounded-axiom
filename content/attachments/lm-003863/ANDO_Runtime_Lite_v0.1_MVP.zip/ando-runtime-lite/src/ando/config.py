from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    workspace: Path | str = Path("workspace")

    def __post_init__(self) -> None:
        workspace = Path(self.workspace).expanduser().resolve()
        object.__setattr__(self, "workspace", workspace)
        workspace.mkdir(parents=True, exist_ok=True)
        self.artifacts_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    @property
    def database_path(self) -> Path:
        return self.workspace / "runtime.db"

    @property
    def artifacts_dir(self) -> Path:
        return self.workspace / "artifacts"

    @property
    def exports_dir(self) -> Path:
        return self.workspace / "exports"
