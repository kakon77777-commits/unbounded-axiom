from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from fastapi.responses import RedirectResponse
from fastapi.templating import Jinja2Templates

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).parent / "templates"))


@router.get("/")
def dashboard(request: Request):
    store = request.app.state.store
    tasks = store.tasks()
    context = {
        "request": request,
        "active_tasks": sum(t.status == "Running" for t in tasks),
        "ready_tasks": sum(t.status == "Ready" for t in tasks),
        "blocked_tasks": sum(t.status == "Blocked" for t in tasks),
        "need_human": len(store.unresolved_human_items()),
        "open_delegations": len(store.delegations(statuses=["Offered", "Accepted", "Running", "Paused"])),
        "recent_events": list(reversed(store.events()))[:10],
    }
    return templates.TemplateResponse(request, "dashboard.html", context)


@router.post("/human/{item_id}/resolve")
def resolve_human(item_id: str, request: Request, action: str, note: str | None = None):
    request.app.state.store.resolve_human_item(item_id, action=action, note=note)
    return RedirectResponse(url="/human", status_code=303)


@router.get("/tasks")
def tasks_page(request: Request):
    return templates.TemplateResponse(request, "tasks.html", {"tasks": request.app.state.store.tasks()})


@router.get("/agents")
def agents_page(request: Request):
    return templates.TemplateResponse(request, "agents.html", {"agents": request.app.state.store.agent_records()})


@router.get("/delegations")
def delegations_page(request: Request):
    return templates.TemplateResponse(request, "delegations.html", {"delegations": request.app.state.store.delegations()})


@router.get("/human")
def human_page(request: Request):
    return templates.TemplateResponse(request, "human.html", {"items": request.app.state.store.unresolved_human_items()})


@router.get("/ledger")
def ledger_page(request: Request):
    return templates.TemplateResponse(request, "ledger.html", {"events": list(reversed(request.app.state.store.events()))})


@router.get("/artifacts")
def artifacts_page(request: Request):
    return templates.TemplateResponse(request, "artifacts.html", {"artifacts": request.app.state.store.artifacts()})
