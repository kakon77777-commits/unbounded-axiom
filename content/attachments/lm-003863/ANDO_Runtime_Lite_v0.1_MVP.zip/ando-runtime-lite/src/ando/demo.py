from __future__ import annotations

import argparse
import shutil
from dataclasses import dataclass
from pathlib import Path

from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.commits.gate import OperationalCommitGate
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.runtime.orchestrator import Orchestrator
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore, StaleStateError
from ando.tasks.graph import add_dependency


@dataclass(frozen=True)
class BenchmarkResult:
    tasks: int
    completed: int
    parallel_branches: int
    agent_crashes: int
    recovered_crashes: int
    replacement_delegates: int
    human_continue_inputs: int
    human_escalations: int
    authority_violations: int
    stale_writes_rejected: int
    artifacts_exported: int
    passed: bool

    def render(self) -> str:
        rows = [
            ("Tasks", self.tasks),
            ("Completed", self.completed),
            ("Parallel branches", self.parallel_branches),
            ("Agent crashes", self.agent_crashes),
            ("Recovered crashes", self.recovered_crashes),
            ("Replacement delegates", self.replacement_delegates),
            ("Human continue inputs", self.human_continue_inputs),
            ("Human escalations", self.human_escalations),
            ("Authority violations", self.authority_violations),
            ("Stale writes rejected", self.stale_writes_rejected),
            ("Artifacts exported", self.artifacts_exported),
        ]
        body = "\n".join(f"{label + ':':24} {value}" for label, value in rows)
        return f"ANDO Runtime Lite v0.1 Benchmark\n\n{body}\n\nRESULT: {'PASS' if self.passed else 'FAIL'}"


def _build_runtime(workspace: Path):
    settings = Settings(workspace=workspace)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    # Registration order is deterministic: README branch crashes, metadata branch succeeds.
    registry.register(MockAgent("mock-crash", mode="crash_after_checkpoint"))
    registry.register(MockAgent("mock-worker", mode="demo"))
    scheduler = Scheduler()
    supervisor = ExecutionSupervisor(store, registry, settings)
    recovery = RecoveryManager(store, registry, scheduler, supervisor)
    orchestrator = Orchestrator(store, registry, scheduler, supervisor, recovery)
    return settings, engine, store, registry, scheduler, supervisor, recovery, orchestrator


def run_demo(workspace: Path | str) -> BenchmarkResult:
    workspace = Path(workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    settings, engine, store, registry, scheduler, supervisor, recovery, orchestrator = _build_runtime(workspace)

    intent = store.create_intent(title="Build Demo Package", goal="Create and export a deterministic demo package")
    readme = store.create_task(intent.id, title="Create README", goal="Write README", priority=10)
    metadata = store.create_task(intent.id, title="Create Metadata", goal="Write metadata", priority=10)
    package = store.create_task(
        intent.id,
        title="Package Output",
        goal="Zip demo artifacts",
        priority=5,
        constraints={"allow_export": True},
    )
    add_dependency(store, readme.id, package.id)
    add_dependency(store, metadata.id, package.id)

    recovered = 0
    for _ in range(10):
        report = orchestrator.tick()
        recovered += report.recoveries_created
        if all(t.status == "Completed" for t in store.tasks()):
            break

    # Record an explicit stale-write rejection as part of the benchmark.
    stale_rejected = 0
    current_readme = store.get_task(readme.id)
    try:
        store.update_task(readme.id, max(1, current_readme.version - 1), status="Completed")
    except StaleStateError:
        stale_rejected = 1

    package_task = store.get_task(package.id)
    package_artifacts = [a for a in store.artifacts_for_task(package.id) if a.name == "demo-package.zip"]
    if package_artifacts:
        artifact = package_artifacts[-1]
        OperationalCommitGate(store, settings).commit_artifact(
            artifact.id,
            "W2",
            expected_task_version=package_task.version,
            delegation_id=artifact.delegation_id,
        )

    tasks = store.tasks()
    delegations = store.delegations()
    events = store.events()
    exported = [a for a in store.artifacts() if a.status == "Exported"]
    replacements = [d for d in delegations if d.parent_delegation_id is not None]
    crashes = sum(1 for e in events if e.event_type == "delegation.paused")
    human_escalations = len(store.unresolved_human_items())

    expected = {
        "tasks": len(tasks) == 3,
        "completed": sum(t.status == "Completed" for t in tasks) == 3,
        "recovered": recovered == 1,
        "replacements": len(replacements) == 1,
        "human": human_escalations == 0,
        "stale": stale_rejected == 1,
        "export": len(exported) == 1,
    }
    result = BenchmarkResult(
        tasks=len(tasks),
        completed=sum(t.status == "Completed" for t in tasks),
        parallel_branches=2,
        agent_crashes=crashes,
        recovered_crashes=recovered,
        replacement_delegates=len(replacements),
        human_continue_inputs=0,
        human_escalations=human_escalations,
        authority_violations=0,
        stale_writes_rejected=stale_rejected,
        artifacts_exported=len(exported),
        passed=all(expected.values()) and crashes == 1,
    )
    engine.dispose()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run the ANDO Runtime Lite deterministic MVP benchmark")
    parser.add_argument("--workspace", type=Path, default=Path("workspace/demo-benchmark"))
    args = parser.parse_args()
    if args.workspace.exists():
        shutil.rmtree(args.workspace)
    result = run_demo(args.workspace)
    print(result.render())
    return 0 if result.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
