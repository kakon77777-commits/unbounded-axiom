from __future__ import annotations

import shutil
from pathlib import Path
from uuid import uuid4

from sqlalchemy import select

from ando.config import Settings
from ando.db.models import Artifact, Commit, Delegation, Receipt, Task, utcnow
from ando.delegation.envelope import AuthorityEnvelope
from ando.ledger.events import append_event
from ando.state.store import StateStore


class CommitRejectedError(RuntimeError):
    code = "COMMIT_REJECTED"


class OperationalCommitGate:
    ALLOWED_CLASSES = {"W0", "W1", "W2"}

    def __init__(self, store: StateStore, settings: Settings) -> None:
        self.store = store
        self.settings = settings

    def commit_artifact(
        self,
        artifact_id: str,
        commit_class: str,
        *,
        expected_task_version: int,
        delegation_id: str,
    ) -> Commit:
        if commit_class not in self.ALLOWED_CLASSES:
            raise CommitRejectedError(f"unsupported commit class {commit_class}")

        with self.store.session_factory() as session, session.begin():
            artifact = session.get(Artifact, artifact_id)
            delegation = session.get(Delegation, delegation_id)
            if artifact is None or delegation is None:
                raise CommitRejectedError("artifact or delegation not found")
            task = session.get(Task, artifact.task_id)
            if task is None:
                raise CommitRejectedError("task not found")
            if task.version != expected_task_version:
                raise CommitRejectedError("stale task version")
            if not artifact.sha256:
                raise CommitRejectedError("artifact sha256 required")
            artifact_path = Path(artifact.path)
            if not artifact_path.exists():
                raise CommitRejectedError("artifact file does not exist")
            authority = AuthorityEnvelope.from_dict(delegation.authority_json)
            if commit_class not in authority.commit_classes:
                raise CommitRejectedError("commit class not authorized")
            execution_receipt = session.scalar(
                select(Receipt).where(
                    Receipt.delegation_id == delegation_id,
                    Receipt.receipt_type == "execution_attempt",
                ).order_by(Receipt.created_at.desc()).limit(1)
            )
            if execution_receipt is None:
                raise CommitRejectedError("execution receipt required")

            before_revision = self.store.current_revision()
            receipt = Receipt(
                id=str(uuid4()),
                receipt_type="commit",
                delegation_id=delegation_id,
                task_id=task.id,
                agent_id=delegation.delegate_agent_id,
                payload_json={"artifact_id": artifact.id, "commit_class": commit_class},
                created_at=utcnow(),
            )
            session.add(receipt)
            revision = self.store._advance_revision(session)
            commit = Commit(
                id=str(uuid4()),
                task_id=task.id,
                artifact_id=artifact.id,
                delegation_id=delegation_id,
                commit_class=commit_class,
                before_revision=before_revision,
                after_revision=revision,
                authority_snapshot_json=delegation.authority_json,
                receipt_id=receipt.id,
                created_at=utcnow(),
            )
            session.add(commit)
            if commit_class == "W1":
                artifact.status = "Canonical"
            elif commit_class == "W2":
                self.settings.exports_dir.mkdir(parents=True, exist_ok=True)
                target = self.settings.exports_dir / artifact_path.name
                shutil.copy2(artifact_path, target)
                artifact.status = "Exported"
            append_event(
                session,
                event_type="commit.created",
                entity_type="commit",
                entity_id=commit.id,
                delegation_id=delegation_id,
                state_revision=revision,
                payload={"artifact_id": artifact.id, "commit_class": commit_class},
            )
        return commit
