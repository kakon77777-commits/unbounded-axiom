from __future__ import annotations

from typing import Any
from uuid import uuid4

from ando.db.models import Receipt, utcnow
from ando.state.store import StateStore


def record_receipt(
    store: StateStore,
    *,
    receipt_type: str,
    delegation_id: str | None = None,
    task_id: str | None = None,
    agent_id: str | None = None,
    payload: dict[str, Any] | None = None,
) -> Receipt:
    with store.session_factory() as session, session.begin():
        receipt = Receipt(
            id=str(uuid4()),
            receipt_type=receipt_type,
            delegation_id=delegation_id,
            task_id=task_id,
            agent_id=agent_id,
            payload_json=payload or {},
            created_at=utcnow(),
        )
        session.add(receipt)
    return receipt
