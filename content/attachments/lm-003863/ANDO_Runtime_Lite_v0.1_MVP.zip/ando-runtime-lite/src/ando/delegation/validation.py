from __future__ import annotations

from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope


class DelegationValidationError(RuntimeError):
    code = "DELEGATION_VALIDATION_ERROR"


class AuthorityEscalationError(DelegationValidationError):
    code = "AUTHORITY_ESCALATION"


class BudgetEscalationError(DelegationValidationError):
    code = "BUDGET_ESCALATION"


def _is_bounded_child_value_allowed(parent: float | int | None, child: float | int | None) -> bool:
    if parent is None:
        return True
    if child is None:
        return False
    return child <= parent


def validate_child_delegation(
    parent_authority: AuthorityEnvelope,
    parent_budget: BudgetEnvelope,
    child_authority: AuthorityEnvelope,
    child_budget: BudgetEnvelope,
) -> None:
    if not child_authority.actions <= parent_authority.actions:
        raise AuthorityEscalationError("child actions exceed parent authority")
    if not child_authority.scopes <= parent_authority.scopes:
        raise AuthorityEscalationError("child scopes exceed parent authority")
    if not child_authority.commit_classes <= parent_authority.commit_classes:
        raise AuthorityEscalationError("child commit classes exceed parent authority")
    if child_authority.subdelegation and not parent_authority.subdelegation:
        raise AuthorityEscalationError("child cannot enable subdelegation when parent disabled it")


    for field in ("time_seconds", "tool_calls", "agent_slots", "token", "money"):
        parent = getattr(parent_budget, field)
        child = getattr(child_budget, field)
        if not _is_bounded_child_value_allowed(parent, child):
            raise BudgetEscalationError(f"child {field} exceeds parent budget")
