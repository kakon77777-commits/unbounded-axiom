from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuthorityEnvelope:
    actions: frozenset[str]
    scopes: frozenset[str]
    commit_classes: frozenset[str]
    subdelegation: bool = False

    @classmethod
    def default_internal(cls) -> "AuthorityEnvelope":
        return cls(
            actions=frozenset({
                "read_state",
                "write_checkpoint",
                "create_artifact",
                "complete_task",
            }),
            scopes=frozenset({"project"}),
            commit_classes=frozenset({"W0", "W1"}),
            subdelegation=True,
        )

    def to_dict(self) -> dict:
        return {
            "actions": sorted(self.actions),
            "scopes": sorted(self.scopes),
            "commit_classes": sorted(self.commit_classes),
            "subdelegation": self.subdelegation,
        }

    @classmethod
    def from_dict(cls, value: dict) -> "AuthorityEnvelope":
        return cls(
            actions=frozenset(value.get("actions", [])),
            scopes=frozenset(value.get("scopes", [])),
            commit_classes=frozenset(value.get("commit_classes", [])),
            subdelegation=bool(value.get("subdelegation", False)),
        )


@dataclass(frozen=True)
class BudgetEnvelope:
    time_seconds: float | None = None
    tool_calls: int | None = None
    agent_slots: int | None = None
    token: float | None = None
    money: float | None = None

    def to_dict(self) -> dict:
        return {
            "time_seconds": self.time_seconds,
            "tool_calls": self.tool_calls,
            "agent_slots": self.agent_slots,
            "token": self.token,
            "money": self.money,
        }

    @classmethod
    def from_dict(cls, value: dict) -> "BudgetEnvelope":
        return cls(
            time_seconds=value.get("time_seconds"),
            tool_calls=value.get("tool_calls"),
            agent_slots=value.get("agent_slots"),
            token=value.get("token"),
            money=value.get("money"),
        )
