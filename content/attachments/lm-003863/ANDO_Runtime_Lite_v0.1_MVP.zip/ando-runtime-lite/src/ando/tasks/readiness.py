from __future__ import annotations

from ando.state.store import StateStore, StaleStateError
from ando.tasks.graph import dependencies


def resolve_ready_tasks(store: StateStore) -> list[str]:
    transitioned: list[str] = []
    for task in store.tasks(statuses=["Pending"]):
        deps = dependencies(store, task.id)
        if all(store.get_task(dep).status == "Completed" for dep in deps):
            try:
                store.update_task(task.id, task.version, status="Ready")
                transitioned.append(task.id)
            except StaleStateError:
                continue
    return transitioned
