from __future__ import annotations

from collections import defaultdict, deque
from uuid import uuid4

from sqlalchemy import select

from ando.db.models import Task, TaskEdge, utcnow
from ando.ledger.events import append_event
from ando.state.store import StateStore


class TaskCycleError(RuntimeError):
    code = "DEADLOCK"


def _all_edges(store: StateStore) -> list[TaskEdge]:
    with store.session_factory() as session:
        return list(session.scalars(select(TaskEdge)))


def dependencies(store: StateStore, task_id: str) -> list[str]:
    with store.session_factory() as session:
        stmt = select(TaskEdge.parent_task_id).where(
            TaskEdge.child_task_id == task_id,
            TaskEdge.edge_type == "depends_on",
        )
        return list(session.scalars(stmt))


def dependents(store: StateStore, task_id: str) -> list[str]:
    with store.session_factory() as session:
        stmt = select(TaskEdge.child_task_id).where(
            TaskEdge.parent_task_id == task_id,
            TaskEdge.edge_type == "depends_on",
        )
        return list(session.scalars(stmt))


def _would_cycle(store: StateStore, prerequisite_id: str, dependent_id: str) -> bool:
    if prerequisite_id == dependent_id:
        return True
    graph: dict[str, set[str]] = defaultdict(set)
    for edge in _all_edges(store):
        if edge.edge_type == "depends_on":
            graph[edge.parent_task_id].add(edge.child_task_id)
    graph[prerequisite_id].add(dependent_id)

    # A cycle exists if dependent can reach prerequisite after adding the edge.
    queue = deque([dependent_id])
    seen: set[str] = set()
    while queue:
        node = queue.popleft()
        if node == prerequisite_id:
            return True
        if node in seen:
            continue
        seen.add(node)
        queue.extend(graph.get(node, ()))
    return False


def add_dependency(store: StateStore, prerequisite_id: str, dependent_id: str) -> TaskEdge:
    # Validate task existence before graph work.
    store.get_task(prerequisite_id)
    store.get_task(dependent_id)
    if _would_cycle(store, prerequisite_id, dependent_id):
        raise TaskCycleError(f"dependency {prerequisite_id} -> {dependent_id} would create a cycle")

    with store.session_factory() as session, session.begin():
        existing = session.scalar(
            select(TaskEdge).where(
                TaskEdge.parent_task_id == prerequisite_id,
                TaskEdge.child_task_id == dependent_id,
                TaskEdge.edge_type == "depends_on",
            )
        )
        if existing is not None:
            return existing
        edge = TaskEdge(
            id=str(uuid4()),
            parent_task_id=prerequisite_id,
            child_task_id=dependent_id,
            edge_type="depends_on",
            created_at=utcnow(),
        )
        session.add(edge)
        revision = store._advance_revision(session)
        append_event(
            session,
            event_type="task.dependency_added",
            entity_type="task",
            entity_id=dependent_id,
            state_revision=revision,
            payload={"prerequisite_task_id": prerequisite_id},
        )
    return edge
