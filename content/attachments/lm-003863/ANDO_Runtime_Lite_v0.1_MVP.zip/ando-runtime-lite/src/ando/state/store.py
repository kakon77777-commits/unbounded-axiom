from __future__ import annotations

from collections.abc import Iterable
import hashlib
from pathlib import Path
from typing import Any
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from ando.db.models import Agent as AgentRecord, Artifact, Checkpoint, Delegation, Event, HumanQueueItem, Intent, Receipt, StateMeta, Task, utcnow
from ando.ledger.events import append_event


class StateStoreError(RuntimeError):
    code = "STATE_STORE_ERROR"


class StaleStateError(StateStoreError):
    code = "STALE_STATE"

    def __init__(self, entity_id: str, expected: int, actual: int):
        super().__init__(f"stale state for {entity_id}: expected version {expected}, actual {actual}")
        self.entity_id = entity_id
        self.expected = expected
        self.actual = actual


class StateStore:
    def __init__(self, session_factory: sessionmaker[Session]):
        self.session_factory = session_factory

    def _advance_revision(self, session: Session) -> int:
        meta = session.get(StateMeta, "state_revision")
        if meta is None:
            meta = StateMeta(key="state_revision", value="0", updated_at=utcnow())
            session.add(meta)
            session.flush()
        revision = int(meta.value) + 1
        meta.value = str(revision)
        meta.updated_at = utcnow()
        return revision

    def current_revision(self) -> int:
        with self.session_factory() as session:
            meta = session.get(StateMeta, "state_revision")
            return int(meta.value) if meta else 0

    def ledger_seq(self) -> int:
        with self.session_factory() as session:
            meta = session.get(StateMeta, "ledger_seq")
            return int(meta.value) if meta else 0

    def create_intent(
        self,
        *,
        title: str,
        goal: str,
        parent_intent_id: str | None = None,
        scope: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        priority: int = 0,
        status: str = "Active",
    ) -> Intent:
        with self.session_factory() as session, session.begin():
            intent = Intent(
                id=str(uuid4()),
                parent_intent_id=parent_intent_id,
                title=title,
                goal=goal,
                scope_json=scope or {},
                constraints_json=constraints or {},
                priority=priority,
                status=status,
                version=1,
                created_at=utcnow(),
                updated_at=utcnow(),
            )
            session.add(intent)
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="intent.created",
                entity_type="intent",
                entity_id=intent.id,
                state_revision=revision,
                payload={"title": title},
            )
        return intent

    def create_task(
        self,
        intent_id: str,
        *,
        title: str,
        goal: str,
        priority: int = 0,
        success_criteria: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        status: str = "Pending",
    ) -> Task:
        with self.session_factory() as session, session.begin():
            task = Task(
                id=str(uuid4()),
                intent_id=intent_id,
                title=title,
                goal=goal,
                status=status,
                priority=priority,
                success_criteria_json=success_criteria or {},
                constraints_json=constraints or {},
                version=1,
                created_at=utcnow(),
                updated_at=utcnow(),
            )
            session.add(task)
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="task.created",
                entity_type="task",
                entity_id=task.id,
                state_revision=revision,
                payload={"title": title, "status": status},
            )
        return task

    def get_task(self, task_id: str) -> Task:
        with self.session_factory() as session:
            task = session.get(Task, task_id)
            if task is None:
                raise KeyError(task_id)
            session.expunge(task)
            return task

    def get_intent(self, intent_id: str) -> Intent:
        with self.session_factory() as session:
            intent = session.get(Intent, intent_id)
            if intent is None:
                raise KeyError(intent_id)
            session.expunge(intent)
            return intent

    def update_task(self, task_id: str, expected_version: int, **changes: Any) -> Task:
        with self.session_factory() as session, session.begin():
            task = session.get(Task, task_id)
            if task is None:
                raise KeyError(task_id)
            if task.version != expected_version:
                raise StaleStateError(task_id, expected_version, task.version)
            for key, value in changes.items():
                if not hasattr(task, key):
                    raise AttributeError(key)
                setattr(task, key, value)
            task.version += 1
            task.updated_at = utcnow()
            revision = self._advance_revision(session)
            event_type = self._event_type_for_task_changes(changes)
            append_event(
                session,
                event_type=event_type,
                entity_type="task",
                entity_id=task.id,
                state_revision=revision,
                delegation_id=task.active_delegation_id,
                payload={"changes": changes, "version": task.version},
            )
        return task

    @staticmethod
    def _event_type_for_task_changes(changes: dict[str, Any]) -> str:
        status = changes.get("status")
        mapping = {
            "Ready": "task.ready",
            "Running": "task.started",
            "Blocked": "task.blocked",
            "Paused": "task.paused",
            "Failed": "task.failed",
            "Completed": "task.completed",
            "Cancelled": "task.cancelled",
        }
        return mapping.get(status, "task.updated")



    def register_agent_record(
        self,
        *,
        agent_id: str,
        name: str,
        adapter_type: str,
        capabilities: list[str] | None = None,
        provider: str | None = None,
        model: str | None = None,
        status: str = "Idle",
    ) -> AgentRecord:
        with self.session_factory() as session, session.begin():
            existing = session.get(AgentRecord, agent_id)
            if existing is not None:
                session.expunge(existing)
                return existing
            agent = AgentRecord(
                id=agent_id,
                name=name,
                adapter_type=adapter_type,
                provider=provider,
                model=model,
                capabilities_json=capabilities or [],
                limits_json={},
                cost_profile_json={},
                status=status,
                created_at=utcnow(),
                updated_at=utcnow(),
            )
            session.add(agent)
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="agent.registered",
                entity_type="agent",
                entity_id=agent_id,
                state_revision=revision,
                payload={"adapter_type": adapter_type},
            )
        return agent

    def create_delegation_record(
        self,
        *,
        task_id: str,
        delegate_agent_id: str,
        state_revision: int,
        task_version: int,
        authority: dict[str, Any],
        budget: dict[str, Any],
        parent_delegation_id: str | None = None,
        grantor_type: str = "runtime",
        grantor_id: str = "root",
    ) -> Delegation:
        delegation_id = str(uuid4())
        root_id = delegation_id
        if parent_delegation_id is not None:
            parent = self.get_delegation(parent_delegation_id)
            root_id = parent.root_delegation_id
        with self.session_factory() as session, session.begin():
            delegation = Delegation(
                id=delegation_id,
                root_delegation_id=root_id,
                parent_delegation_id=parent_delegation_id,
                task_id=task_id,
                grantor_type=grantor_type,
                grantor_id=grantor_id,
                delegate_agent_id=delegate_agent_id,
                state_revision=state_revision,
                task_version=task_version,
                authority_json=authority,
                budget_json=budget,
                risk_json={},
                output_contract_json={},
                checkpoint_policy_json={},
                escalation_policy_json={},
                termination_json={},
                status="Offered",
                created_at=utcnow(),
            )
            session.add(delegation)
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="delegation.offered",
                entity_type="delegation",
                entity_id=delegation.id,
                delegation_id=delegation.id,
                state_revision=revision,
                payload={"task_id": task_id, "delegate_agent_id": delegate_agent_id},
            )
        return delegation

    def get_delegation(self, delegation_id: str) -> Delegation:
        with self.session_factory() as session:
            delegation = session.get(Delegation, delegation_id)
            if delegation is None:
                raise KeyError(delegation_id)
            session.expunge(delegation)
            return delegation



    def set_delegation_status(self, delegation_id: str, status: str) -> Delegation:
        with self.session_factory() as session, session.begin():
            delegation = session.get(Delegation, delegation_id)
            if delegation is None:
                raise KeyError(delegation_id)
            delegation.status = status
            if status == "Accepted":
                delegation.accepted_at = utcnow()
            if status in {"Completed", "Rejected", "Revoked", "Expired"}:
                delegation.closed_at = utcnow()
            revision = self._advance_revision(session)
            event_suffix = status.lower()
            append_event(
                session,
                event_type=f"delegation.{event_suffix}",
                entity_type="delegation",
                entity_id=delegation.id,
                delegation_id=delegation.id,
                state_revision=revision,
                payload={"status": status},
            )
        return delegation

    def create_checkpoint(
        self,
        *,
        task_id: str,
        delegation_id: str,
        agent_id: str,
        task_version: int,
        progress: dict[str, Any],
        next_step: dict[str, Any] | None = None,
        open_issues: list[Any] | None = None,
        artifact_refs: list[str] | None = None,
    ) -> Checkpoint:
        with self.session_factory() as session, session.begin():
            checkpoint = Checkpoint(
                id=str(uuid4()),
                task_id=task_id,
                delegation_id=delegation_id,
                agent_id=agent_id,
                state_revision=self.current_revision(),
                task_version=task_version,
                progress_json=progress,
                next_step_json=next_step or {},
                open_issues_json=open_issues or [],
                artifact_refs_json=artifact_refs or [],
                created_at=utcnow(),
            )
            session.add(checkpoint)
            revision = self._advance_revision(session)
            checkpoint.state_revision = revision
            append_event(
                session,
                event_type="checkpoint.created",
                entity_type="checkpoint",
                entity_id=checkpoint.id,
                delegation_id=delegation_id,
                state_revision=revision,
                payload={"task_id": task_id, "progress": progress},
            )
        return checkpoint

    def checkpoints_for_task(self, task_id: str) -> list[Checkpoint]:
        with self.session_factory() as session:
            rows = list(session.scalars(
                select(Checkpoint)
                .where(Checkpoint.task_id == task_id)
                .order_by(Checkpoint.created_at.asc())
            ))
            for row in rows:
                session.expunge(row)
            return rows

    def latest_checkpoint(self, task_id: str) -> Checkpoint | None:
        with self.session_factory() as session:
            row = session.scalar(
                select(Checkpoint)
                .where(Checkpoint.task_id == task_id)
                .order_by(Checkpoint.created_at.desc())
                .limit(1)
            )
            if row is not None:
                session.expunge(row)
            return row

    def execution_attempt_count(self, delegation_id: str) -> int:
        with self.session_factory() as session:
            rows = list(session.scalars(
                select(Receipt).where(
                    Receipt.delegation_id == delegation_id,
                    Receipt.receipt_type == "execution_attempt",
                )
            ))
            return len(rows)



    def require_human(
        self,
        *,
        reason: str,
        question: str,
        task_id: str | None = None,
        delegation_id: str | None = None,
        risk_level: str = "medium",
        options: list[Any] | None = None,
        recommendation: dict[str, Any] | None = None,
    ) -> HumanQueueItem:
        with self.session_factory() as session, session.begin():
            existing = session.scalar(
                select(HumanQueueItem).where(
                    HumanQueueItem.reason == reason,
                    HumanQueueItem.task_id == task_id,
                    HumanQueueItem.delegation_id == delegation_id,
                    HumanQueueItem.status == "Open",
                ).limit(1)
            )
            if existing is not None:
                session.expunge(existing)
                return existing
            item = HumanQueueItem(
                id=str(uuid4()),
                task_id=task_id,
                delegation_id=delegation_id,
                reason=reason,
                risk_level=risk_level,
                question=question,
                options_json=options or [],
                recommendation_json=recommendation or {},
                state_revision=self.current_revision(),
                status="Open",
                created_at=utcnow(),
            )
            session.add(item)
            revision = self._advance_revision(session)
            item.state_revision = revision
            append_event(
                session,
                event_type="human.required",
                entity_type="human_queue",
                entity_id=item.id,
                delegation_id=delegation_id,
                state_revision=revision,
                payload={"reason": reason, "task_id": task_id},
            )
        return item



    def open_tasks(self) -> list[Task]:
        terminal = {"Completed", "Cancelled"}
        return [task for task in self.tasks() if task.status not in terminal]

    def latest_checkpoint_for_open_task(self) -> Checkpoint | None:
        open_ids = {task.id for task in self.open_tasks()}
        if not open_ids:
            return None
        with self.session_factory() as session:
            row = session.scalar(
                select(Checkpoint)
                .where(Checkpoint.task_id.in_(open_ids))
                .order_by(Checkpoint.created_at.desc())
                .limit(1)
            )
            if row is not None:
                session.expunge(row)
            return row



    def resolve_human_item(self, item_id: str, *, action: str, note: str | None = None) -> HumanQueueItem:
        with self.session_factory() as session, session.begin():
            item = session.get(HumanQueueItem, item_id)
            if item is None:
                raise KeyError(item_id)
            if item.status != "Open":
                return item
            item.status = "Resolved"
            item.resolved_at = utcnow()
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="human.resolved",
                entity_type="human_queue",
                entity_id=item.id,
                delegation_id=item.delegation_id,
                state_revision=revision,
                payload={"action": action, "note": note},
            )
        return item

    def unresolved_human_items(self) -> list[HumanQueueItem]:
        with self.session_factory() as session:
            rows = list(session.scalars(
                select(HumanQueueItem)
                .where(HumanQueueItem.status == "Open")
                .order_by(HumanQueueItem.created_at.asc())
            ))
            for row in rows:
                session.expunge(row)
            return rows







    def create_artifact(
        self,
        *,
        task_id: str,
        delegation_id: str | None,
        type: str,
        name: str,
        path: str | Path,
        created_by_agent_id: str | None,
        status: str = "Candidate",
    ) -> Artifact:
        artifact_path = Path(path).resolve()
        if not artifact_path.exists() or not artifact_path.is_file():
            raise FileNotFoundError(artifact_path)
        digest = hashlib.sha256(artifact_path.read_bytes()).hexdigest()
        with self.session_factory() as session, session.begin():
            artifact = Artifact(
                id=str(uuid4()),
                task_id=task_id,
                delegation_id=delegation_id,
                type=type,
                name=name,
                path=str(artifact_path),
                sha256=digest,
                status=status,
                version=1,
                created_by_agent_id=created_by_agent_id,
                created_at=utcnow(),
            )
            session.add(artifact)
            revision = self._advance_revision(session)
            append_event(
                session,
                event_type="artifact.created",
                entity_type="artifact",
                entity_id=artifact.id,
                delegation_id=delegation_id,
                state_revision=revision,
                payload={"task_id": task_id, "name": name, "sha256": digest},
            )
        return artifact

    def get_artifact(self, artifact_id: str) -> Artifact:
        with self.session_factory() as session:
            row = session.get(Artifact, artifact_id)
            if row is None:
                raise KeyError(artifact_id)
            session.expunge(row)
            return row

    def artifacts_for_task(self, task_id: str) -> list[Artifact]:
        with self.session_factory() as session:
            rows = list(session.scalars(
                select(Artifact)
                .where(Artifact.task_id == task_id)
                .order_by(Artifact.created_at.asc())
            ))
            for row in rows:
                session.expunge(row)
            return rows

    def agent_records(self) -> list[AgentRecord]:
        with self.session_factory() as session:
            rows = list(session.scalars(select(AgentRecord).order_by(AgentRecord.id.asc())))
            for row in rows:
                session.expunge(row)
            return rows

    def artifacts(self) -> list[Artifact]:
        with self.session_factory() as session:
            rows = list(session.scalars(select(Artifact).order_by(Artifact.created_at.asc())))
            for row in rows:
                session.expunge(row)
            return rows

    def delegations(self, statuses: Iterable[str] | None = None) -> list[Delegation]:
        with self.session_factory() as session:
            stmt = select(Delegation).order_by(Delegation.created_at.asc())
            if statuses is not None:
                stmt = stmt.where(Delegation.status.in_(list(statuses)))
            rows = list(session.scalars(stmt))
            for row in rows:
                session.expunge(row)
            return rows

    def events(self, limit: int | None = None) -> list[Event]:
        with self.session_factory() as session:
            stmt = select(Event).order_by(Event.seq.asc())
            if limit is not None:
                stmt = stmt.limit(limit)
            rows = list(session.scalars(stmt))
            for row in rows:
                session.expunge(row)
            return rows

    def tasks(self, statuses: Iterable[str] | None = None) -> list[Task]:
        with self.session_factory() as session:
            stmt = select(Task).order_by(Task.priority.desc(), Task.created_at.asc())
            if statuses is not None:
                stmt = stmt.where(Task.status.in_(list(statuses)))
            rows = list(session.scalars(stmt))
            for row in rows:
                session.expunge(row)
            return rows
