# ANDO Runtime Lite v0.1 — Design Specification

## AI-Native Distributed Organization Runtime Lite

**文件類型**：Architectural Design Specification  
**版本**：v0.1  
**日期**：2026-08-21  
**狀態**：Design Approved / Awaiting Implementation Plan  
**範圍**：ANDO Reference Architecture Phase 0–2  
**Canonical encoding**：UTF-8  
**Canonical math delimiters**：`$...$` 與 `$$...$$`

---

# 0. 文件目的

本文件將《AI-Native Distributed Organization Reference Architecture v0.1》中的 Phase 0–2 收斂成第一個可實作 MVP。

本 MVP 的第一目的不是接入最強模型，也不是建立完整 AI 公司，而是工程性驗證以下命題：

$$
\boxed{
\text{Human interaction is not required as the transition trigger for every Agent work step}.
}
$$

亦即，將人類從以下低資訊、高頻率操作中移出：

- `continue`；
- `retry`；
- `copy-paste context`；
- `manual handoff`；
- `manual routing`；
- `manual checkpoint reminder`；
- `manual packaging trigger`。

同時保留人類在真正需要治理判斷的位置。

---

# 1. Scope Classification

本工作屬於：

$$
\boxed{
\text{Architectural Project}
}
$$

原因是它建立新的 runtime、canonical data model、Agent adapter interface、delegation semantics、recovery semantics 與 UI boundary，而不是對既有單一流程做小修改。

---

# 2. MVP 核心目標

Phase 0–2 的正式目標為：

$$
\boxed{
\text{Human Kernel}
\rightarrow
\text{Local Organizational Runtime}
}
$$

MVP 必須能做到：

1. 組織 state 存在於 Agent context 之外；
2. Task dependency 可由 runtime 自動推進；
3. Ready task 可由 scheduler 自動委任；
4. Agent 可被替換而不造成組織失憶；
5. Delegation authority 與 budget 不可自我擴張；
6. stale write 必須被拒絕；
7. revocation 必須沿 delegation lineage 傳播；
8. 每個重要 mutation 必須進 ledger；
9. 無法自動處理的治理問題必須進 Human Queue；
10. Demo workflow 完成時不需要 human `continue` message。

---

# 3. 明確非目標

Phase 0–2 不做：

- 真實商業模型 API；
- Browser automation；
- Web AI interaction；
- YouTube / Facebook / Google 等公共平台；
- autonomous publishing；
-完整 Research Claim Graph；
-完整 Typed Verification Contract；
- vector database；
- RAG；
- multi-user authentication；
- cloud deployment；
- distributed workers；
- payments；
- plugin ecosystem；
- multi-principal governance；
- complex graph visual editor；
- chat-first frontend。

這些功能全部延後，避免把 runtime correctness 與外部模型／平台錯誤混在一起。

---

# 4. 技術棧

第一版固定：

$$
\boxed{
\text{Python}
+
\text{FastAPI}
+
\text{SQLite}
+
\text{SQLAlchemy}
+
\text{Jinja}
}
$$

附加規則：

- Python 3.12+；
- SQLite WAL mode；
- SQLAlchemy 2.x style；
- server-rendered dashboard；
- 原生 JavaScript 僅做必要互動；
- 不需要 Node.js build chain；
- 不需要 API key；
- 可在 Windows 直接啟動；
- 提供 `run.bat` 與 `run.sh`。

---

# 5. 高階架構

ANDO Runtime Lite v0.1 分為七個核心模組：

$$
\boxed{
StateStore
+
TaskGraph
+
AgentRegistry
+
DelegationRuntime
+
Ledger
+
CommitGate
+
Dashboard
}
$$

並由 Runtime Orchestrator 統合。

邏輯結構：

```text
Dashboard / Human Interface
          |
          v
Runtime Orchestrator
  |       |       |       |
  v       v       v       v
Task    Agent   Deleg.   Recovery
Graph   Registry Runtime Manager
  \       |       /       /
   \      |      /       /
    ------StateStore------
            |
            v
          Ledger
            |
            v
        CommitGate
```

---

# 6. 架構原則

## 6.1 Canonical State Outside Agent Context

$$
\boxed{
CanonicalState
\not\subseteq
SingleAgentContext.
}
$$

Agent conversation、scratchpad、temporary summary 均不得成為唯一正式 state。

## 6.2 Capability Is Not Authority

$$
\boxed{
Capability
\neq
Authority.
}
$$

Agent 做得到某件事，不表示 runtime 允許它做。

## 6.3 Assignment Is Not Delegation

$$
\boxed{
AssignedAgent
\neq
GovernanceAuthority.
}
$$

`assigned_agent_id` 表示 execution state。

`active_delegation_id` 表示 governance state。

## 6.4 Proposal Is Not Commit

$$
\boxed{
ArtifactExists
\neq
ArtifactCommitted.
}
$$

## 6.5 Process Restart Is Not Organization Reset

$$
\boxed{
ProcessRestart
\neq
OrganizationReset.
}
$$

---

# 7. Canonical Data Model

Phase 0–2 使用下列表：

```text
state_meta
intents
tasks
task_edges
agents
delegations
artifacts
checkpoints
commits
events
human_queue
receipts
```

---

# 8. `state_meta`

用途：保存 global runtime metadata。

主要欄位：

```text
key
value
updated_at
```

至少保存：

```text
state_revision
ledger_seq
schema_version
```

其中：

$$
state\_revision
$$

只在 canonical commit / canonical mutation 成功後前進。

---

# 9. `intents`

概念模型：

$$
Intent
=
(
id,
parent,
goal,
scope,
constraints,
priority,
status,
version
).
$$

主要欄位：

```text
id
parent_intent_id
title
goal
scope_json
constraints_json
priority
status
version
created_at
updated_at
```

Intent 是 task graph 的 root semantic anchor。

---

# 10. `tasks`

概念模型：

$$
Task
=
(
id,
intent,
goal,
status,
priority,
success,
version
).
$$

主要欄位：

```text
id
intent_id
title
goal
status
priority
success_criteria_json
constraints_json
assigned_agent_id
active_delegation_id
version
created_at
updated_at
```

Status 固定：

```text
Pending
Ready
Running
Blocked
Paused
Failed
Completed
Cancelled
```

---

# 11. `task_edges`

欄位：

```text
parent_task_id
child_task_id
edge_type
created_at
```

第一版 `edge_type`：

```text
depends_on
blocks
parent_of
```

任務 Ready 條件：

$$
Ready(t_i)=1
$$

當且僅當：

$$
Status(t_i)=Pending
$$

且：

$$
\forall d\in Dependencies(t_i),
\quad
Status(d)=Completed.
$$

新增 dependency edge 時必須先做 cycle detection。

---

# 12. `agents`

Agent Profile：

$$
Agent
=
(
id,
type,
capabilities,
limits,
status
).
$$

欄位：

```text
id
name
adapter_type
provider
model
capabilities_json
limits_json
cost_profile_json
status
created_at
updated_at
```

第一版只實作：

```text
mock
manual
```

未來 adapter：

```text
openai
local
browser
web_ai
coding
```

但不屬於 Phase 0–2。

---

# 13. `delegations`

Delegation Envelope：

$$
\mathfrak D
=
(
DID,
RID,
Task,
State,
Authority,
Budget,
Risk,
Output,
Checkpoint,
Escalation,
Termination
).
$$

欄位：

```text
id
root_delegation_id
parent_delegation_id
task_id
grantor_type
grantor_id
delegate_agent_id
state_revision
task_version
authority_json
budget_json
risk_json
output_contract_json
checkpoint_policy_json
escalation_policy_json
termination_json
status
accepted_at
closed_at
created_at
```

Status：

```text
Offered
Accepted
Running
Paused
Delivered
Completed
Rejected
Revoked
Expired
```

---

# 14. Authority Envelope

第一版 authority shape：

```json
{
  "actions": [
    "read_state",
    "write_checkpoint",
    "create_artifact",
    "complete_task"
  ],
  "scopes": ["project"],
  "commit_classes": ["W0", "W1"],
  "subdelegation": true
}
```

核心不變量：

$$
Actions_{child}
\subseteq
Actions_{parent},
$$

$$
Scopes_{child}
\subseteq
Scopes_{parent},
$$

$$
CommitClasses_{child}
\subseteq
CommitClasses_{parent}.
$$

任何 child 擴權要求均回傳：

```text
AUTHORITY_ESCALATION
```

並且不得自動 retry。

---

# 15. Budget Envelope

第一版 budget shape：

```json
{
  "token": null,
  "money": null,
  "time_seconds": 3600,
  "tool_calls": 50,
  "agent_slots": 2
}
```

`null` 表示該維度目前不限制。

核心不變量：

$$
B_{child}
\preceq
B_{parent}.
$$

對不可超賣的 budget class：

$$
\sum_j B_{child,j}
\le
B_{parent}.
$$

超額回傳：

```text
BUDGET_ESCALATION
```

---

# 16. `artifacts`

SQLite 僅保存 metadata。

欄位：

```text
id
task_id
delegation_id
type
name
path
sha256
status
version
created_by_agent_id
created_at
```

實體檔案放在：

```text
workspace/artifacts/
```

Status：

```text
Candidate
Canonical
Exported
Archived
```

---

# 17. `checkpoints`

欄位：

```text
id
task_id
delegation_id
agent_id
state_revision
task_version
progress_json
next_step_json
open_issues_json
artifact_refs_json
created_at
```

Checkpoint 語義：

$$
Checkpoint
=
(
Progress,
CompletedSubsteps,
OpenSubsteps,
ArtifactRefs,
OpenIssues,
NextSuggestedAction,
StateVersion
).
$$

Checkpoint 不保存完整聊天歷史。

---

# 18. `commits`

Phase 0–2 commit classes：

$$
W_0
=
Candidate,
$$

$$
W_1
=
InternalCanonical,
$$

$$
W_2
=
ExportedArtifact.
$$

欄位：

```text
id
task_id
artifact_id
delegation_id
commit_class
before_revision
after_revision
authority_snapshot_json
receipt_id
created_at
```

注意：

$$
W_1
$$

只表示 runtime operationally 接受 artifact 成為 internal canonical artifact。

它不表示學術、數學、法律或其他 epistemic correctness 已經被完整驗證。

---

# 19. `events`

Event Ledger 必須 append-only。

欄位：

```text
seq
event_id
event_type
actor_type
actor_id
entity_type
entity_id
delegation_id
state_revision
payload_json
created_at
```

Phase 0–2 event types：

```text
intent.created
intent.updated

task.created
task.ready
task.started
task.blocked
task.completed
task.failed
task.paused
task.cancelled

agent.registered
agent.status_changed
agent.unhealthy

delegation.offered
delegation.accepted
delegation.started
delegation.paused
delegation.delivered
delegation.completed
delegation.rejected
delegation.revoked
delegation.expired

checkpoint.created

artifact.created
artifact.updated

commit.created

human.required
human.resolved

orphan.detected
```

---

# 20. `receipts`

Phase 0–2 receipt types：

$$
Receipt_D,
Receipt_X,
Receipt_C.
$$

欄位：

```text
id
receipt_type
delegation_id
task_id
agent_id
payload_json
created_at
```

Phase 3 才加入正式：

$$
Receipt_V.
$$

---

# 21. `human_queue`

欄位：

```text
id
task_id
delegation_id
reason
risk_level
question
options_json
recommendation_json
state_revision
status
created_at
resolved_at
```

第一版觸發：

```text
AUTHORITY_ESCALATION
BUDGET_EXHAUSTED
DEADLOCK
NO_COMPATIBLE_AGENT
AMBIGUOUS_RECOVERY
MANUAL_AGENT_TASK
```

不是所有錯誤都進 Human Queue。

---

# 22. Version Model

系統同時使用：

$$
\boxed{
\text{Entity Version}
+
\text{Global State Revision}
}
$$

Entity version 用來拒絕 stale entity write。

Global state revision 用來標示 delegation 接受時的 canonical organization revision。

所有 canonical mutation 都帶：

```text
expected_version
```

若：

$$
ExpectedVersion
\neq
CurrentVersion,
$$

則：

```text
STALE_STATE
```

---

# 23. Canonical Mutation Transaction

所有重要 canonical mutation：

$$
Validate
\rightarrow
UpdateEntity
\rightarrow
AppendEvent
\rightarrow
AdvanceRevision
\rightarrow
CommitDB.
$$

任何一步失敗：

$$
Rollback.
$$

---

# 24. SQLite Runtime Rules

啟動時設定：

```text
PRAGMA foreign_keys = ON
PRAGMA journal_mode = WAL
PRAGMA synchronous = NORMAL
```

使用短 transaction 與 optimistic concurrency。

Phase 0–2 不做 distributed lock。

---

# 25. Runtime Orchestrator

核心結構：

```text
ANDO Runtime
├─ State Store
├─ Ready Resolver
├─ Scheduler
├─ Delegation Manager
├─ Agent Adapter Registry
├─ Execution Supervisor
├─ Checkpoint Manager
├─ Commit Manager
├─ Recovery Manager
└─ Human Queue
```

Runtime 是 deterministic organizational kernel，而不是某個 AI personality。

---

# 26. Runtime Loop

主流程：

$$
Observe
\rightarrow
ResolveReadyTasks
\rightarrow
Schedule
\rightarrow
Delegate
\rightarrow
Execute
\rightarrow
Checkpoint
\rightarrow
Deliver
\rightarrow
CloseOrEscalate
\rightarrow
Repeat.
$$

Phase 0–2 的 correctness 來自 state transition rules，而不是 LLM 判斷。

---

# 27. Ready Resolver

當 canonical state 發生變化時：

$$
Pending
\rightarrow
Ready
$$

只由 task dependency 與 blocking state 決定。

這一層完全 deterministic。

---

# 28. Scheduler

Phase 0–2 不使用 LLM scheduler。

排序規則：

1. `priority DESC`；
2. 同 priority 用 `created_at ASC`；
3. 找第一個 capability match 且 available Agent；
4. 無 Agent 則 Blocked 或進 Human Queue。

這建立 deterministic baseline。

---

# 29. Agent Adapter Interface

所有 Agent 必須實作：

```text
describe()
can_accept(task, delegation)
accept(delegation)
execute(context)
resume(context, checkpoint)
cancel(delegation_id)
health()
```

核心 interface 名稱可以在 implementation plan 中微調，但語義不得變。

---

# 30. ExecutionContext

Agent 只取得 minimum sufficient context：

$$
X_c
=
(
Intent,
Task,
Delegation,
StateVersion,
Checkpoint,
Artifacts,
Constraints
).
$$

不直接取得整個 organization database。

---

# 31. MockAgent

第一版 MockAgent modes：

```text
success
fail_once
always_fail
checkpoint_then_success
crash_after_checkpoint
stale_write
budget_exhaust
spawn_child
invalid_child_authority
hang
```

MockAgent 是 runtime correctness 的主要測試工具。

---

# 32. ManualAgent

ManualAgent 代表：

- human node；
- 尚未整合的 external AI；
- 暫時人工完成的 task。

Dashboard 可以提交 result、artifact、status 與 note。

Runtime 仍產生 execution receipt。

---

# 33. Delegation Flow

Ready Task：

```text
1. read task current version
2. read global state revision
3. derive parent authority and budget
4. create delegation envelope
5. validate envelope
6. append delegation.offered
7. call adapter.can_accept()
8. accept or reject
9. append delegation.accepted
10. mark task started
```

核心原則：

$$
\boxed{
GovernanceBeforeExecution.
}
$$

---

# 34. Execution Supervisor

Supervisor 負責：

- timeout；
- cancellation；
- checkpoint requests；
- budget tracking；
- retry；
- health；
- result capture。

Agent 是 bounded execution unit。

---

# 35. Delegation State Machine

合法主要 transition：

$$
Offered
\rightarrow
Accepted
\rightarrow
Running
\rightarrow
Delivered
\rightarrow
Completed.
$$

旁路：

$$
Running
\rightarrow
Paused,
$$

$$
Running
\rightarrow
Failed,
$$

$$
Running
\rightarrow
Revoked,
$$

$$
Running
\rightarrow
Expired.
$$

`Revoked` 不可直接 transition 到 `Completed`。

---

# 36. Checkpoint Trigger

Phase 0–2 支援：

1. Event trigger；
2. Budget trigger；
3. Explicit trigger。

不要求固定秒數 checkpoint。

---

# 37. Resume Package

Agent replacement 時：

$$
ResumePackage
=
(
Intent,
Task,
Delegation,
LatestCheckpoint,
CanonicalArtifacts,
CurrentStateVersion
).
$$

新 Agent 讀 ResumePackage，不讀舊 Agent 的完整聊天。

---

# 38. Crash Recovery

當：

$$
Health(A_i)=0,
$$

Runtime：

$$
FindLatestCheckpoint
\rightarrow
FindCompatibleAgent
\rightarrow
CreateReplacementDelegation
\rightarrow
Resume.
$$

Replacement 必須建立新的：

$$
DID.
$$

舊 delegation 保留 lineage。

---

# 39. Retry 與 Replace

Retry：

$$
SameAgent
+
SameDelegation.
$$

Replace：

$$
NewAgent
+
NewDelegation.
$$

Transient error 可以 retry。

Agent crash、repeated failure、capability mismatch 走 replace。

---

# 40. Error Taxonomy

固定 machine-readable errors：

```text
STALE_STATE
AUTHORITY_ESCALATION
BUDGET_ESCALATION
BUDGET_EXHAUSTED
AGENT_UNAVAILABLE
AGENT_FAILED
TOOL_FAILED
TIMEOUT
INVALID_OUTPUT
CHECKPOINT_MISSING
DELEGATION_REVOKED
DEADLOCK
INTERNAL_ERROR
```

自然語言 message 只是補充。

---

# 41. Retry Policy

預設：

$$
RetryCount
\le
2.
$$

Retry 也消耗 budget。

`AUTHORITY_ESCALATION` 不自動 retry。

---

# 42. Revocation

流程：

```text
1. mark delegation revoked
2. cancel adapter execution
3. find descendants
4. revoke or revalidate descendants
5. pause affected tasks
6. append events
7. release reserved budget
```

Revocation 只沿該 delegation subtree 傳播。

---

# 43. Pause 與 Revoke

Pause：

$$
AuthorityValid=1.
$$

可以 resume。

Revoke：

$$
AuthorityValid=0.
$$

必須建立新 delegation 才能恢復。

---

# 44. Commit Gate

Phase 0–2 只實作 Operational Integrity Gate。

檢查：

- authority；
- current state version；
- success criteria；
- artifact exists；
- artifact has sha256；
- required execution receipt exists。

不冒充完整 epistemic verification。

---

# 45. Dashboard

首頁顯示：

```text
Active Tasks
Ready Tasks
Blocked Tasks
Need Human
Open Delegations
Recent Commits
```

主要區塊：

1. Task Graph；
2. Agent Activity；
3. Delegations；
4. Need Human；
5. Recent Ledger。

---

# 46. Dashboard Pages

Phase 0–2 只做：

```text
/
├─ /tasks
├─ /agents
├─ /delegations
├─ /human
├─ /ledger
└─ /artifacts
```

不做 chat frontend。

---

# 47. New Intent Flow

使用者：

1. 建立 Intent；
2. 建立 Tasks；
3. 建立 dependencies；
4. Start Runtime。

第一版不使用 AI 自動拆 task。

這是刻意保留的 baseline。

---

# 48. Human Decision Packet

Human Queue item：

$$
h_i
=
(
Reason,
Risk,
State,
Options,
Recommendation,
Deadline,
Reversibility
).
$$

人類不需要重新閱讀 raw Agent transcript。

---

# 49. Demo Workflow

Demo Intent：

```text
Build Demo Package
```

Task Graph：

$$
T_1
=
\text{Create README},
$$

$$
T_2
=
\text{Create Metadata},
$$

$$
T_3
=
\text{Package Output}.
$$

依賴：

$$
T_1,T_2
\prec
T_3.
$$

其中：

$$
T_1
\parallel
T_2.
$$

一個 MockAgent 故意：

$$
Checkpoint
\rightarrow
Crash.
$$

Runtime 必須：

$$
Detect
\rightarrow
Replace
\rightarrow
Resume.
$$

最後：

$$
T_1,T_2
\rightarrow
T_3
\rightarrow
W_1
\rightarrow
W_2.
$$

整個過程：

$$
HumanContinueMessages=0.
$$

---

# 50. 專案目錄

```text
ando-runtime-lite/
│
├─ README.md
├─ pyproject.toml
├─ run.bat
├─ run.sh
│
├─ src/
│  └─ ando/
│     ├─ app.py
│     ├─ config.py
│     │
│     ├─ db/
│     │  ├─ engine.py
│     │  ├─ models.py
│     │  └─ migrations.py
│     │
│     ├─ state/
│     │  ├─ store.py
│     │  └─ transactions.py
│     │
│     ├─ tasks/
│     │  ├─ graph.py
│     │  └─ readiness.py
│     │
│     ├─ agents/
│     │  ├─ base.py
│     │  ├─ registry.py
│     │  ├─ mock.py
│     │  └─ manual.py
│     │
│     ├─ delegation/
│     │  ├─ envelope.py
│     │  ├─ validation.py
│     │  └─ receipts.py
│     │
│     ├─ runtime/
│     │  ├─ orchestrator.py
│     │  ├─ scheduler.py
│     │  ├─ supervisor.py
│     │  └─ recovery.py
│     │
│     ├─ ledger/
│     │  └─ events.py
│     │
│     ├─ commits/
│     │  └─ gate.py
│     │
│     └─ web/
│        ├─ routes.py
│        ├─ templates/
│        └─ static/
│
├─ workspace/
│  ├─ artifacts/
│  ├─ exports/
│  └─ runtime.db
│
├─ tests/
│  ├─ unit/
│  ├─ integration/
│  └─ acceptance/
│
├─ schemas/
│  ├─ delegation-envelope.json
│  └─ runtime-event.json
│
└─ docs/
   └─ architecture/
```

---

# 51. Testing Strategy

三層：

$$
Unit
+
Integration
+
Acceptance.
$$

並加入少量 property-based tests 與 failure injection。

---

# 52. Unit Tests

至少測：

- authority subset；
- budget subset；
- graph acyclic；
- stale write rejection；
- invalid commit rejection；
- legal state transitions。

---

# 53. Integration Tests

至少測：

$$
TaskReady
\rightarrow
Scheduler
\rightarrow
Delegation
\rightarrow
MockAgent.
$$

以及：

$$
Crash
\rightarrow
Recovery
\rightarrow
ReplacementDelegation.
$$

---

# 54. Acceptance Gates

正式 10 Gate：

1. dependency 自動 Ready；
2. ready task 自動 delegation；
3. parallel tasks 可執行；
4. checkpoint 可建立；
5. Agent crash 可 replace + resume；
6. stale write 被拒；
7. child authority escalation 被拒；
8. child budget escalation 被拒；
9. revoke 可傳播；
10. human queue 可接住 unresolved governance。

只有：

$$
10/10
$$

通過，才標記：

$$
\boxed{
MVP\ PASS.
}
$$

---

# 55. Restart Recovery Test

關閉整個 ANDO Runtime。

重新啟動後必須恢復：

- open tasks；
- paused delegations；
- checkpoints；
- human queue；
- artifact refs；
- ledger。

因此：

$$
\boxed{
ProcessRestart
\neq
OrganizationReset.
}
$$

---

# 56. Failure Injection

Mock modes：

```text
fail_once
always_fail
crash_after_checkpoint
budget_exhaust
stale_write
invalid_child_authority
hang
```

目標不是只證明 happy path，而是：

$$
\boxed{
Failure
\not\Rightarrow
OrganizationalAmnesia.
}
$$

---

# 57. Success Criteria

正式成功條件：

$$
S_1:
\text{Canonical state survives restart}.
$$

$$
S_2:
A_i
\rightsquigarrow
A_j
\Rightarrow
Resume(Task).
$$

$$
S_3:
\text{No human context copy-paste required}.
$$

$$
S_4:
A_{child}
\subseteq
A_{parent}.
$$

$$
S_5:
B_{child}
\preceq
B_{parent}.
$$

$$
S_6:
OldVersionWrite
\Rightarrow
Rejected.
$$

$$
S_7:
Revoke(parent)
\Rightarrow
DescendantsStopped.
$$

$$
S_8:
\text{Every important mutation is traceable}.
$$

$$
S_9:
\text{Unresolvable governance issues enter Human Queue}.
$$

$$
S_{10}:
\text{Demo finishes with zero human continue messages}.
$$

因此：

$$
\boxed{
MVP\ PASS
\iff
\bigwedge_{i=1}^{10}S_i.
}
$$

---

# 58. Benchmark Output

Demo 至少輸出：

```text
ANDO Runtime Lite v0.1 Benchmark

Tasks:                  3
Completed:              3
Parallel branches:      2
Agent crashes:          1
Recovered crashes:      1
Replacement delegates:  1
Human continue inputs:  0
Human escalations:      0
Authority violations:   0
Stale writes rejected:  1
Artifacts exported:     1

RESULT: PASS
```

---

# 59. Design Boundary

Phase 0–2 完成時，系統應證明：

$$
\boxed{
\text{Chat Session}
\rightarrow
\text{Replaceable Executor over Canonical Organizational State}.
}
$$

而不是證明：

> 大模型已經可以完全自治公司。

這個 boundary 必須在 README 與 benchmark 中清楚標示。

---

# 60. 下一階段條件

只有當 Phase 0–2：

$$
MVP\ PASS
$$

後，才進 Phase 3：

$$
\boxed{
\text{Typed Verification}.
}
$$

Phase 4 才接：

$$
\boxed{
\text{Browser / Web-AI Adapter}.
}
$$

Phase 5 才接：

$$
\boxed{
\text{Persistent Public AI Actor}.
}
$$

---

# 61. 最終設計結論

ANDO Runtime Lite v0.1 的最小形式：

$$
\boxed{
\text{SQLite Canonical State}
+
\text{Task DAG}
+
\text{Deterministic Scheduler}
+
\text{Agent Adapter}
+
\text{Delegation Envelope}
+
\text{Checkpoint / Resume}
+
\text{Append-only Ledger}
+
\text{Operational Commit Gate}
+
\text{Human Queue}
+
\text{Dashboard}.
}
$$

最核心工程命題：

$$
\boxed{
\text{Human does not need to be the transition trigger for every Agent work step}.
}
$$

只要這個命題在 MockAgent 與 deterministic runtime 中被穩定證明，才值得接真實 AI provider。

---

# 62. Spec Self-Review

## Placeholder Scan

- 未發現待定標記。
- 未發現未完成實作標記。
- 無需使用者補充的必填架構欄位。

## Internal Consistency

- Phase 0–2 不包含完整 epistemic verification。
- `W1` 僅為 internal operational canonical commit。
- `W2` 僅為 exported artifact，不代表 public platform publishing。
- `assigned_agent_id` 與 `active_delegation_id` 分離。
- `Pause` 與 `Revoke` 語義分離。
- Retry 與 Replace 語義分離。
- Agent replacement 建立新 DID，不覆寫舊 delegation lineage。

## Scope Check

Phase 0–2 聚焦於 local single-user runtime，未包含外部模型／平台整合，範圍適合單一 implementation plan。

## Ambiguity Check

以下決策已明確固定：

- scheduler 第一版 deterministic；
- storage 第一版 SQLite；
- UI 第一版 server-rendered；
- agent 第一版 Mock + Manual；
- deployment 第一版 local single-machine；
- commit 第一版只支援 W0–W2；
- authority / budget 採 child subset rule；
- state conflict 採 optimistic concurrency；
- runtime correctness 不依賴背景 sleep timing；
- restart recovery 為正式 acceptance requirement。

---

# 63. Design Approval State

本設計已完成四個設計段落：

1. Overall Architecture；
2. Canonical Data Model / Delegation / Ledger；
3. Runtime / Scheduler / Recovery；
4. Dashboard / Tests / Acceptance Boundary。

下一步不是直接實作。

下一步為：

$$
\boxed{
\text{Implementation Plan}
}
$$

在進入 implementation plan 前，需由使用者對本正式 spec 做最後 review / approval。
