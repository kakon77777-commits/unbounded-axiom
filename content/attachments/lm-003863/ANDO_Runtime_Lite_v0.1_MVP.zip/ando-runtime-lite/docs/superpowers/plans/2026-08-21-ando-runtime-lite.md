# ANDO Runtime Lite v0.1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build a local single-user ANDO Runtime Lite that persists canonical organizational state, advances a Task DAG without human `continue` messages, delegates Ready tasks to replaceable Mock/Manual agents, rejects authority/budget escalation and stale writes, recovers from agent failure using checkpoints, records an append-only ledger, exposes a Human Queue, and exports a working demo artifact.

**Architecture:** FastAPI + server-rendered Jinja UI sit over a deterministic Python runtime. SQLite/SQLAlchemy store canonical entities and append-only events; runtime services are separated into task readiness, agent registry, delegation validation, execution/recovery, commits, and dashboard queries. Agent adapters only receive a bounded `ExecutionContext`, never direct database ownership.

**Tech Stack:** Python 3.12+, FastAPI, SQLAlchemy 2.x, SQLite WAL, Jinja2, Uvicorn, pytest.

**Spec:** `docs/superpowers/specs/2026-08-21-ando-runtime-lite-design.md`

## Global Constraints

- Local single-machine runtime only.
- No commercial model API, browser automation, public social integrations, RAG, vector database, multi-user auth, cloud deployment, or distributed workers.
- First adapters are `MockAgent` and `ManualAgent` only.
- Scheduler is deterministic: priority descending, creation time ascending, then first compatible available agent.
- Canonical state must live outside Agent context.
- SQLite uses `PRAGMA foreign_keys = ON`, `journal_mode = WAL`, `synchronous = NORMAL`.
- Child authority, scopes, commit classes, and bounded budgets may never exceed the parent delegation.
- Phase 0–2 commit classes are W0 Candidate, W1 InternalCanonical, W2 ExportedArtifact.
- W1/W2 mean operational integrity only; they do not claim epistemic correctness.
- All important canonical mutations must append a ledger event in the same transaction.
- Runtime correctness must not depend on sleep timing.
- Full process restart must preserve organizational state.
- TDD is mandatory: write each behavior test first, run it and confirm the expected failure, then write minimal implementation.

---

## File Map

- `pyproject.toml` — package metadata, dependencies, pytest configuration.
- `src/ando/config.py` — workspace/database paths and runtime constants.
- `src/ando/db/engine.py` — SQLite engine/session setup and PRAGMAs.
- `src/ando/db/models.py` — SQLAlchemy canonical tables.
- `src/ando/state/store.py` — canonical CRUD/mutation helpers with optimistic versioning.
- `src/ando/ledger/events.py` — append-only event creation/query.
- `src/ando/tasks/graph.py` — DAG edge validation and cycle detection.
- `src/ando/tasks/readiness.py` — deterministic Ready transition logic.
- `src/ando/agents/base.py` — adapter protocol and execution dataclasses.
- `src/ando/agents/registry.py` — adapter registration/lookup.
- `src/ando/agents/mock.py` — deterministic failure-injection agent.
- `src/ando/agents/manual.py` — human/external-manual bridge.
- `src/ando/delegation/envelope.py` — authority/budget envelope dataclasses.
- `src/ando/delegation/validation.py` — subset and budget checks.
- `src/ando/delegation/receipts.py` — receipt persistence helpers.
- `src/ando/runtime/scheduler.py` — deterministic task/agent matching.
- `src/ando/runtime/supervisor.py` — execution, retries, checkpoints, result capture.
- `src/ando/runtime/recovery.py` — replacement delegation and resume.
- `src/ando/runtime/orchestrator.py` — one deterministic `tick()` state-transition pass.
- `src/ando/commits/gate.py` — W0/W1/W2 operational commit gate.
- `src/ando/demo.py` — deterministic three-task demo and benchmark summary.
- `src/ando/web/routes.py` — dashboard routes and minimal command endpoints.
- `src/ando/web/templates/*.html` — server-rendered dashboard pages.
- `src/ando/app.py` — FastAPI application factory.
- `run.bat`, `run.sh` — one-click local launchers.
- `tests/unit/*` — invariants and model behavior.
- `tests/integration/*` — subsystem flows.
- `tests/acceptance/*` — ten MVP gates, restart recovery, and demo benchmark.

---

### Task 1: Project bootstrap and SQLite canonical schema

**Files:**
- Create: `pyproject.toml`
- Create: `src/ando/__init__.py`
- Create: `src/ando/config.py`
- Create: `src/ando/db/__init__.py`
- Create: `src/ando/db/engine.py`
- Create: `src/ando/db/models.py`
- Test: `tests/unit/test_database_bootstrap.py`

**Interfaces:**
- Produces: `ando.config.Settings`, `ando.db.engine.create_engine_and_session(settings) -> tuple[Engine, sessionmaker]`, `ando.db.engine.init_database(engine) -> None`.
- Produces SQLAlchemy models: `StateMeta`, `Intent`, `Task`, `TaskEdge`, `Agent`, `Delegation`, `Artifact`, `Checkpoint`, `Commit`, `Event`, `HumanQueueItem`, `Receipt`.

- [x] **Step 1: Write failing database bootstrap test**

```python
from sqlalchemy import inspect, text
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database


def test_database_bootstrap_creates_required_tables_and_pragmas(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, _ = create_engine_and_session(settings)
    init_database(engine)

    tables = set(inspect(engine).get_table_names())
    assert {
        "state_meta", "intents", "tasks", "task_edges", "agents",
        "delegations", "artifacts", "checkpoints", "commits", "events",
        "human_queue", "receipts",
    } <= tables

    with engine.connect() as conn:
        assert conn.execute(text("PRAGMA foreign_keys")).scalar_one() == 1
        assert conn.execute(text("PRAGMA journal_mode")).scalar_one().lower() == "wal"
```

- [x] **Step 2: Run RED**

Run: `pytest tests/unit/test_database_bootstrap.py -q`
Expected: FAIL because `ando.config` / database modules do not exist.

- [x] **Step 3: Add minimal package/config/schema implementation**

`Settings` resolves `workspace/runtime.db`, creates `artifacts/` and `exports/`; engine connection hook applies the three required PRAGMAs; `init_database()` calls `Base.metadata.create_all()` and seeds `state_revision=0`, `ledger_seq=0`, `schema_version=0.1`.

- [x] **Step 4: Run GREEN**

Run: `pytest tests/unit/test_database_bootstrap.py -q`
Expected: PASS.

- [x] **Step 5: Commit**

```bash
git add pyproject.toml src/ando tests/unit/test_database_bootstrap.py
git commit -m "feat: add canonical sqlite schema"
```

---

### Task 2: Canonical store, versioning, and append-only ledger

**Files:**
- Create: `src/ando/state/__init__.py`
- Create: `src/ando/state/store.py`
- Create: `src/ando/ledger/__init__.py`
- Create: `src/ando/ledger/events.py`
- Test: `tests/unit/test_state_versioning.py`
- Test: `tests/unit/test_ledger.py`

**Interfaces:**
- Produces: `StateStore.create_intent(...)`, `StateStore.create_task(...)`, `StateStore.update_task(task_id, expected_version, **changes)`.
- Produces: `StateStore.current_revision() -> int`, `StateStore.events(limit: int | None = None) -> list[Event]`.
- Raises: `StaleStateError(code="STALE_STATE")`.

- [x] **Step 1: Write failing stale-write test**

```python
import pytest
from ando.state.store import StateStore, StaleStateError


def test_stale_task_write_is_rejected(store: StateStore):
    intent = store.create_intent(title="Demo", goal="Build demo")
    task = store.create_task(intent.id, title="README", goal="Write README")
    store.update_task(task.id, expected_version=task.version, status="Ready")

    with pytest.raises(StaleStateError) as exc:
        store.update_task(task.id, expected_version=task.version, status="Running")
    assert exc.value.code == "STALE_STATE"
```

- [x] **Step 2: Run RED**

Run: `pytest tests/unit/test_state_versioning.py -q`
Expected: FAIL because `StateStore` is missing.

- [x] **Step 3: Implement transaction-scoped mutation and version checks**

Every canonical mutation must update the entity, increment its version, append the corresponding `Event`, and advance global `state_revision` in one database transaction.

- [x] **Step 4: Run GREEN**

Run: `pytest tests/unit/test_state_versioning.py -q`
Expected: PASS.

- [x] **Step 5: Write failing append-only ledger test**

```python
def test_create_intent_and_task_append_ordered_events(store: StateStore):
    intent = store.create_intent(title="Demo", goal="Build demo")
    store.create_task(intent.id, title="README", goal="Write README")
    events = store.events()
    assert [e.event_type for e in events] == ["intent.created", "task.created"]
    assert [e.seq for e in events] == sorted(e.seq for e in events)
```

- [x] **Step 6: Run RED then implement ledger sequence assignment**

Run: `pytest tests/unit/test_ledger.py -q`
Expected: FAIL until event query/sequence logic exists.

- [x] **Step 7: Run GREEN and full unit subset**

Run: `pytest tests/unit/test_state_versioning.py tests/unit/test_ledger.py -q`
Expected: PASS.

- [x] **Step 8: Commit**

```bash
git add src/ando/state src/ando/ledger tests/unit
git commit -m "feat: add versioned state store and ledger"
```

---

### Task 3: Task DAG and Ready transitions

**Files:**
- Create: `src/ando/tasks/__init__.py`
- Create: `src/ando/tasks/graph.py`
- Create: `src/ando/tasks/readiness.py`
- Test: `tests/unit/test_task_graph.py`
- Test: `tests/integration/test_task_readiness.py`

**Interfaces:**
- Produces: `add_dependency(store, prerequisite_id, dependent_id) -> TaskEdge`.
- Raises: `TaskCycleError` when an edge would introduce a cycle.
- Produces: `resolve_ready_tasks(store) -> list[str]` of task IDs transitioned to Ready.

- [x] **Step 1: Write failing cycle-rejection test**

```python
import pytest
from ando.tasks.graph import add_dependency, TaskCycleError


def test_dependency_cycle_is_rejected(store):
    intent = store.create_intent(title="Demo", goal="Demo")
    a = store.create_task(intent.id, title="A", goal="A")
    b = store.create_task(intent.id, title="B", goal="B")
    add_dependency(store, a.id, b.id)
    with pytest.raises(TaskCycleError):
        add_dependency(store, b.id, a.id)
```

- [x] **Step 2: Run RED, implement graph validation, run GREEN**

Run: `pytest tests/unit/test_task_graph.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing Ready transition test**

```python
def test_dependent_task_becomes_ready_after_prerequisites_complete(store):
    intent = store.create_intent(title="Demo", goal="Demo")
    a = store.create_task(intent.id, title="A", goal="A")
    b = store.create_task(intent.id, title="B", goal="B")
    add_dependency(store, a.id, b.id)
    resolve_ready_tasks(store)
    assert store.get_task(a.id).status == "Ready"
    assert store.get_task(b.id).status == "Pending"
    a = store.get_task(a.id)
    store.update_task(a.id, a.version, status="Completed")
    resolve_ready_tasks(store)
    assert store.get_task(b.id).status == "Ready"
```

- [x] **Step 4: Run RED, implement readiness resolver, run GREEN**

Run: `pytest tests/integration/test_task_readiness.py -q`
Expected: FAIL then PASS.

- [x] **Step 5: Commit**

```bash
git add src/ando/tasks tests/unit/test_task_graph.py tests/integration/test_task_readiness.py
git commit -m "feat: add task dag readiness engine"
```

---

### Task 4: Agent adapter protocol, registry, MockAgent, and ManualAgent

**Files:**
- Create: `src/ando/agents/__init__.py`
- Create: `src/ando/agents/base.py`
- Create: `src/ando/agents/registry.py`
- Create: `src/ando/agents/mock.py`
- Create: `src/ando/agents/manual.py`
- Test: `tests/unit/test_agent_registry.py`
- Test: `tests/unit/test_mock_agent.py`

**Interfaces:**
- `ExecutionContext(intent, task, delegation, state_revision, task_version, latest_checkpoint, artifact_refs, workspace_path)`.
- `AgentResult(status: str, artifacts: list[Path], checkpoint: dict | None, note: str | None)`.
- `AgentAdapter` methods: `describe`, `can_accept`, `accept`, `execute`, `resume`, `cancel`, `health`.
- `AgentRegistry.register(adapter)`, `AgentRegistry.get(agent_id)`, `AgentRegistry.compatible(capability) -> list[AgentAdapter]`.

- [x] **Step 1: Write failing registry capability test**

```python
def test_registry_returns_available_capability_match():
    registry = AgentRegistry()
    agent = MockAgent("mock-1", capabilities={"write_file"})
    registry.register(agent)
    assert [a.agent_id for a in registry.compatible("write_file")] == ["mock-1"]
```

- [x] **Step 2: Run RED, implement adapter protocol and registry, run GREEN**

Run: `pytest tests/unit/test_agent_registry.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing failure-injection test**

```python
def test_fail_once_agent_fails_then_succeeds(execution_context):
    agent = MockAgent("mock-1", mode="fail_once")
    first = agent.execute(execution_context)
    second = agent.execute(execution_context)
    assert first.status == "failed"
    assert second.status == "completed"
```

- [x] **Step 4: Run RED, implement MockAgent modes required by current tests, run GREEN**

Run: `pytest tests/unit/test_mock_agent.py -q`
Expected: FAIL then PASS.

- [x] **Step 5: Add ManualAgent with `can_accept=True` and `execute` returning `manual_required`**

Add a failing test first that asserts the returned status is `manual_required`, then implement it and rerun.

- [x] **Step 6: Commit**

```bash
git add src/ando/agents tests/unit/test_agent_registry.py tests/unit/test_mock_agent.py
git commit -m "feat: add mock and manual agent adapters"
```

---

### Task 5: Delegation envelope, authority/budget validation, and receipts

**Files:**
- Create: `src/ando/delegation/__init__.py`
- Create: `src/ando/delegation/envelope.py`
- Create: `src/ando/delegation/validation.py`
- Create: `src/ando/delegation/receipts.py`
- Test: `tests/unit/test_delegation_validation.py`

**Interfaces:**
- `AuthorityEnvelope(actions: frozenset[str], scopes: frozenset[str], commit_classes: frozenset[str], subdelegation: bool)`.
- `BudgetEnvelope(time_seconds: float | None, tool_calls: int | None, agent_slots: int | None, token: float | None = None, money: float | None = None)`.
- `validate_child_delegation(parent_authority, parent_budget, child_authority, child_budget) -> None`.
- Raises `AuthorityEscalationError(code="AUTHORITY_ESCALATION")`, `BudgetEscalationError(code="BUDGET_ESCALATION")`.

- [x] **Step 1: Write failing authority escalation test**

```python
import pytest


def test_child_cannot_add_publish_or_higher_commit_class():
    parent = AuthorityEnvelope(
        actions=frozenset({"read_state", "create_artifact"}),
        scopes=frozenset({"project"}),
        commit_classes=frozenset({"W0"}),
        subdelegation=True,
    )
    child = AuthorityEnvelope(
        actions=frozenset({"read_state", "create_artifact", "publish"}),
        scopes=frozenset({"project"}),
        commit_classes=frozenset({"W0", "W2"}),
        subdelegation=False,
    )
    with pytest.raises(AuthorityEscalationError):
        validate_child_delegation(parent, BudgetEnvelope(tool_calls=20), child, BudgetEnvelope(tool_calls=10))
```

- [x] **Step 2: Run RED, implement authority subset rules, run GREEN**

Run: `pytest tests/unit/test_delegation_validation.py::test_child_cannot_add_publish_or_higher_commit_class -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing budget escalation test**

```python
def test_child_cannot_exceed_parent_tool_budget():
    auth = AuthorityEnvelope.default_internal()
    with pytest.raises(BudgetEscalationError):
        validate_child_delegation(auth, BudgetEnvelope(tool_calls=20), auth, BudgetEnvelope(tool_calls=100))
```

- [x] **Step 4: Run RED, implement budget comparison, run GREEN**

Run: `pytest tests/unit/test_delegation_validation.py -q`
Expected: PASS after implementation.

- [x] **Step 5: Add receipt persistence tests first, then minimal helper**

Test that `record_receipt(..., receipt_type="delegation")` stores a Receipt row and appends no implicit commit.

- [x] **Step 6: Commit**

```bash
git add src/ando/delegation tests/unit/test_delegation_validation.py
git commit -m "feat: add bounded delegation envelopes"
```

---

### Task 6: Deterministic scheduler and delegation creation

**Files:**
- Create: `src/ando/runtime/__init__.py`
- Create: `src/ando/runtime/scheduler.py`
- Test: `tests/integration/test_scheduler.py`

**Interfaces:**
- `Scheduler.select(store, registry) -> list[tuple[Task, AgentAdapter]]`.
- `Scheduler.create_delegation(store, task, adapter, parent_delegation_id=None) -> Delegation`.
- Default root authority is internal W0/W1 with actions needed for MockAgent demo; root budget is finite but generous.

- [x] **Step 1: Write failing priority-order scheduling test**

```python
def test_scheduler_selects_highest_priority_ready_task_first(runtime_fixture):
    store, registry = runtime_fixture
    intent = store.create_intent(title="I", goal="G")
    low = store.create_task(intent.id, title="low", goal="low", priority=1)
    high = store.create_task(intent.id, title="high", goal="high", priority=9)
    resolve_ready_tasks(store)
    selected = Scheduler().select(store, registry)
    assert [task.id for task, _ in selected][:2] == [high.id, low.id]
```

- [x] **Step 2: Run RED, implement deterministic selection, run GREEN**

Run: `pytest tests/integration/test_scheduler.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing delegation persistence test**

Assert a selected Ready task receives an Offered delegation carrying current `state_revision` and `task_version`.

- [x] **Step 4: Run RED, implement `create_delegation`, run GREEN**

- [x] **Step 5: Commit**

```bash
git add src/ando/runtime/scheduler.py tests/integration/test_scheduler.py
git commit -m "feat: add deterministic scheduler"
```

---

### Task 7: Execution supervisor, checkpoints, retries, and operational commits

**Files:**
- Create: `src/ando/runtime/supervisor.py`
- Create: `src/ando/commits/__init__.py`
- Create: `src/ando/commits/gate.py`
- Test: `tests/integration/test_supervisor.py`
- Test: `tests/unit/test_commit_gate.py`

**Interfaces:**
- `ExecutionSupervisor.run_delegation(delegation_id) -> str` returns terminal/action status.
- `create_checkpoint(...) -> Checkpoint` persists structured progress and `checkpoint.created`.
- `OperationalCommitGate.commit_artifact(..., commit_class: str, expected_task_version: int) -> Commit`.

- [x] **Step 1: Write failing checkpoint persistence test**

```python
def test_checkpoint_then_success_agent_persists_checkpoint_before_completion(runtime):
    delegation = runtime.make_ready_delegation(mode="checkpoint_then_success")
    runtime.supervisor.run_delegation(delegation.id)
    checkpoints = runtime.store.checkpoints_for_task(delegation.task_id)
    assert len(checkpoints) == 1
    assert checkpoints[0].progress_json["progress"] > 0
```

- [x] **Step 2: Run RED, implement execution context/checkpoint persistence, run GREEN**

Run: `pytest tests/integration/test_supervisor.py::test_checkpoint_then_success_agent_persists_checkpoint_before_completion -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing retry-ceiling test**

```python
def test_always_fail_agent_stops_after_retry_ceiling(runtime):
    delegation = runtime.make_ready_delegation(mode="always_fail")
    status = runtime.supervisor.run_delegation(delegation.id)
    assert status == "failed"
    assert runtime.store.execution_attempt_count(delegation.id) == 3
```

- [x] **Step 4: Run RED, implement max two retries beyond first attempt, run GREEN**

- [x] **Step 5: Write failing commit-gate test**

```python
import pytest


def test_commit_requires_artifact_hash_and_allowed_commit_class(runtime):
    artifact = runtime.store.create_artifact_without_hash(...)
    with pytest.raises(CommitRejectedError):
        runtime.commit_gate.commit_artifact(artifact.id, "W1", expected_task_version=1)
```

- [x] **Step 6: Run RED, implement operational integrity gate, run GREEN**

Commit checks current task version, authority snapshot, artifact existence/hash, and execution receipt. W2 copies committed artifact into `workspace/exports/`.

- [x] **Step 7: Run integration subset**

Run: `pytest tests/integration/test_supervisor.py tests/unit/test_commit_gate.py -q`
Expected: PASS.

- [x] **Step 8: Commit**

```bash
git add src/ando/runtime/supervisor.py src/ando/commits tests/integration/test_supervisor.py tests/unit/test_commit_gate.py
git commit -m "feat: supervise execution checkpoints and commits"
```

---

### Task 8: Recovery, replacement delegation, revocation, and Human Queue

**Files:**
- Create: `src/ando/runtime/recovery.py`
- Modify: `src/ando/state/store.py`
- Test: `tests/integration/test_recovery.py`
- Test: `tests/integration/test_revocation.py`
- Test: `tests/integration/test_human_queue.py`

**Interfaces:**
- `RecoveryManager.replace_failed_delegation(delegation_id) -> Delegation | None`.
- `RecoveryManager.revoke(delegation_id) -> list[str]` returns revoked subtree IDs.
- `StateStore.require_human(...) -> HumanQueueItem`.

- [x] **Step 1: Write failing crash replacement test**

```python
def test_crashed_agent_is_replaced_with_new_delegation_and_latest_checkpoint(runtime):
    old = runtime.make_ready_delegation(mode="crash_after_checkpoint")
    runtime.supervisor.run_delegation(old.id)
    replacement = runtime.recovery.replace_failed_delegation(old.id)
    assert replacement.id != old.id
    assert replacement.parent_delegation_id == old.id
    assert runtime.store.latest_checkpoint(old.task_id) is not None
```

- [x] **Step 2: Run RED, implement replacement lineage/resume package, run GREEN**

- [x] **Step 3: Write failing revocation propagation test**

Build D1 -> D2 -> D4 and sibling D3; revoke D2; assert D2/D4 revoked and D3 unchanged.

- [x] **Step 4: Run RED, implement subtree revocation, run GREEN**

- [x] **Step 5: Write failing Human Queue test**

No compatible agent for a Ready task must create exactly one unresolved `NO_COMPATIBLE_AGENT` item, not one item per tick.

- [x] **Step 6: Run RED, implement de-duplicated Human Queue insertion, run GREEN**

- [x] **Step 7: Commit**

```bash
git add src/ando/runtime/recovery.py src/ando/state/store.py tests/integration
git commit -m "feat: recover failures and route governance decisions"
```

---

### Task 9: Deterministic orchestrator tick and restart recovery

**Files:**
- Create: `src/ando/runtime/orchestrator.py`
- Test: `tests/integration/test_orchestrator.py`
- Test: `tests/acceptance/test_restart_recovery.py`

**Interfaces:**
- `Orchestrator.tick() -> TickReport` performs one finite transition pass.
- `TickReport` fields: `ready_count`, `delegations_created`, `executions_processed`, `recoveries_created`, `human_items_created`.

- [x] **Step 1: Write failing finite-tick flow test**

```python
def test_ticks_advance_task_without_human_transition_trigger(runtime):
    intent, task = runtime.create_single_task_demo()
    for _ in range(6):
        runtime.orchestrator.tick()
    assert runtime.store.get_task(task.id).status == "Completed"
```

- [x] **Step 2: Run RED, implement finite `tick`, run GREEN**

Run: `pytest tests/integration/test_orchestrator.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Write failing restart recovery test**

```python
def test_restart_preserves_tasks_checkpoints_human_queue_and_ledger(tmp_path):
    first = build_runtime(tmp_path)
    first.seed_paused_state_for_restart_test()
    event_count = len(first.store.events())
    first.dispose()

    second = build_runtime(tmp_path)
    assert second.store.open_tasks()
    assert second.store.latest_checkpoint_for_open_task() is not None
    assert second.store.unresolved_human_items()
    assert len(second.store.events()) == event_count
```

- [x] **Step 4: Run RED, implement startup reconstruction from SQLite, run GREEN**

- [x] **Step 5: Commit**

```bash
git add src/ando/runtime/orchestrator.py tests/integration/test_orchestrator.py tests/acceptance/test_restart_recovery.py
git commit -m "feat: add deterministic runtime tick and restart recovery"
```

---

### Task 10: FastAPI dashboard and Manual decision workflow

**Files:**
- Create: `src/ando/web/__init__.py`
- Create: `src/ando/web/routes.py`
- Create: `src/ando/web/templates/base.html`
- Create: `src/ando/web/templates/dashboard.html`
- Create: `src/ando/web/templates/tasks.html`
- Create: `src/ando/web/templates/agents.html`
- Create: `src/ando/web/templates/delegations.html`
- Create: `src/ando/web/templates/human.html`
- Create: `src/ando/web/templates/ledger.html`
- Create: `src/ando/web/templates/artifacts.html`
- Create: `src/ando/app.py`
- Test: `tests/integration/test_web_dashboard.py`

**Interfaces:**
- `create_app(settings: Settings | None = None) -> FastAPI`.
- GET routes: `/`, `/tasks`, `/agents`, `/delegations`, `/human`, `/ledger`, `/artifacts`.
- POST `/human/{item_id}/resolve` accepts `action` and optional `note`.

- [x] **Step 1: Write failing dashboard route test**

```python
from fastapi.testclient import TestClient


def test_dashboard_shows_operational_counters(app):
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert "Active Tasks" in response.text
    assert "Need Human" in response.text
    assert "Open Delegations" in response.text
```

- [x] **Step 2: Run RED, implement minimal application factory/routes/template, run GREEN**

Run: `pytest tests/integration/test_web_dashboard.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Add failing Human Queue resolution test, implement canonical resolution event, run GREEN**

- [x] **Step 4: Add the remaining six read-only list pages and route tests**

Each test asserts HTTP 200 and a page-specific heading.

- [x] **Step 5: Commit**

```bash
git add src/ando/web src/ando/app.py tests/integration/test_web_dashboard.py
git commit -m "feat: add organizational state dashboard"
```

---

### Task 11: Demo workflow, export artifact, launchers, and ten acceptance gates

**Files:**
- Create: `src/ando/demo.py`
- Create: `tests/acceptance/test_mvp_gates.py`
- Create: `tests/acceptance/test_demo_benchmark.py`
- Create: `run.bat`
- Create: `run.sh`
- Modify: `README.md`

**Interfaces:**
- `run_demo(workspace: Path) -> BenchmarkResult`.
- `BenchmarkResult` exposes the fields printed in the design benchmark and `passed: bool`.

- [x] **Step 1: Write failing end-to-end demo benchmark test**

```python
def test_demo_finishes_without_human_continue_messages(tmp_path):
    result = run_demo(tmp_path)
    assert result.tasks == 3
    assert result.completed == 3
    assert result.parallel_branches == 2
    assert result.agent_crashes == 1
    assert result.recovered_crashes == 1
    assert result.replacement_delegates == 1
    assert result.human_continue_inputs == 0
    assert result.human_escalations == 0
    assert result.artifacts_exported == 1
    assert result.passed is True
```

- [x] **Step 2: Run RED, implement the deterministic demo using runtime services, run GREEN**

Run: `pytest tests/acceptance/test_demo_benchmark.py -q`
Expected: FAIL then PASS.

- [x] **Step 3: Encode all ten formal acceptance gates as tests**

`tests/acceptance/test_mvp_gates.py` must contain one test for each S1–S10 from the design spec, using real runtime behavior rather than mocking service internals.

- [x] **Step 4: Run acceptance suite**

Run: `pytest tests/acceptance -q`
Expected: all PASS.

- [x] **Step 5: Add launchers and README usage**

`run.bat` and `run.sh` launch `uvicorn ando.app:create_app --factory --host 127.0.0.1 --port 8765`; README documents `python -m pip install -e .`, dashboard URL, demo command, MVP boundary, and test command.

- [x] **Step 6: Commit**

```bash
git add src/ando/demo.py tests/acceptance run.bat run.sh README.md
git commit -m "feat: complete ANDO runtime lite demo"
```

---

### Task 12: Full verification, package, and evidence report

**Files:**
- Create: `docs/verification/2026-08-21-mvp-verification.md`
- Create outside Git working tree at handoff: `/mnt/data/ANDO_Runtime_Lite_v0.1_MVP.zip`
- Create outside Git working tree at handoff: `/mnt/data/ANDO_Runtime_Lite_v0.1_FINAL_VERIFICATION.txt`
- Create outside Git working tree at handoff: `/mnt/data/ANDO_Runtime_Lite_v0.1_SHA256SUMS.txt`

**Interfaces:**
- Produces fresh source-tree evidence plus independent final-archive evidence.
- The final ZIP SHA-256 is stored in a sidecar because an archive cannot truthfully contain its own raw hash without changing its bytes.

- [x] **Step 1: Run full test suite**

Run: `python -m pytest -q`
Expected: 0 failed, 0 errors.

- [x] **Step 2: Run acceptance suite**

Run: `python -m pytest tests/acceptance -q`
Expected: all acceptance tests PASS.

- [x] **Step 3: Run demo as a fresh process**

Run: `PYTHONPATH=src python -m ando.demo --workspace /mnt/data/ando-final-benchmark-workspace`
Expected: benchmark prints `RESULT: PASS` and exit code 0.

- [x] **Step 4: Run dashboard application-factory smoke check**

Create `Settings(workspace=<fresh path>)`, call `create_app(settings)`, and verify the title plus required routes.
Expected: `ANDO Runtime Lite v0.1` and the seven MVP dashboard routes.

- [x] **Step 5: Write source-tree verification evidence document**

Record exact commands, observed test counts, benchmark output, dashboard smoke output, project boundary, and the self-hash limitation for the archive.

- [x] **Step 6: Create release-candidate ZIP**

Package source, tests, docs, schemas, launchers, and empty workspace directories; exclude `.git`, `.venv`, cache folders, and runtime database.

- [x] **Step 7: Verify the release-candidate extraction**

Extract into a fresh directory, run `PYTHONPATH=src python -m pytest -q`, run the demo, and run the dashboard smoke check.
Expected: 42 tests PASS, benchmark `RESULT: PASS`, dashboard app factory loads.

- [x] **Step 8: Commit source-tree verification evidence and completed implementation status**

```bash
git add docs/verification/2026-08-21-mvp-verification.md docs/superpowers/plans/2026-08-21-ando-runtime-lite.md
git commit -m "docs: record MVP verification evidence"
```

- [x] **Step 9: Build canonical final ZIP from the committed tree**

Create `/mnt/data/ANDO_Runtime_Lite_v0.1_MVP.zip` from `git ls-files`, preserving the `ando-runtime-lite/` top-level directory and excluding Git metadata, caches, and runtime state.

- [x] **Step 10: Verify the canonical final ZIP in a fresh extraction**

Run full tests, the deterministic benchmark, and dashboard app-factory smoke check against the extracted final ZIP.
Expected: 42 tests PASS, benchmark `RESULT: PASS`, dashboard app factory loads.

- [x] **Step 11: Generate independent final evidence sidecars**

Write the final ZIP SHA-256 and exact post-extraction verification results to:

```text
/mnt/data/ANDO_Runtime_Lite_v0.1_FINAL_VERIFICATION.txt
/mnt/data/ANDO_Runtime_Lite_v0.1_SHA256SUMS.txt
```

## Plan Self-Review

### Spec coverage

- Canonical persistence: Tasks 1–2, 9.
- Task DAG/readiness: Task 3.
- Deterministic scheduler: Task 6.
- Mock/Manual agents: Task 4.
- Delegation envelope and subset invariants: Task 5.
- Checkpoints/retries/commits: Task 7.
- Recovery/replacement/revocation/Human Queue: Task 8.
- Deterministic tick and restart recovery: Task 9.
- Dashboard: Task 10.
- Demo and ten formal gates: Task 11.
- Fresh verification/package evidence: Task 12.

No Phase 0–2 requirement is intentionally omitted.

### Placeholder scan

No TBD/TODO/"implement later" instructions are present. Each behavior-changing task requires a failing test, explicit verification command, implementation target, and commit.

### Type/interface consistency

`Settings`, `StateStore`, `AgentAdapter`, `ExecutionContext`, `AuthorityEnvelope`, `BudgetEnvelope`, `Scheduler`, `ExecutionSupervisor`, `RecoveryManager`, `OperationalCommitGate`, `Orchestrator`, and `BenchmarkResult` are introduced before downstream use. Task and delegation identifiers remain strings throughout; version checks use integer entity versions and global state revision separately.
