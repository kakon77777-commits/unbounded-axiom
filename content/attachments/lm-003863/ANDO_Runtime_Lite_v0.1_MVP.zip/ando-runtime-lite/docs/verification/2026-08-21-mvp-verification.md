# ANDO Runtime Lite v0.1 — MVP Verification Evidence

**Date:** 2026-08-21  
**Scope:** Phase 0–2  
**Branch:** `feat/mvp-phase-0-2`  
**Purpose:** Record fresh verification evidence for the source tree before release packaging.

## Environment

- Python: 3.13.5 (project requires Python 3.12+)
- FastAPI: 0.128.2
- SQLAlchemy: 2.0.50
- Jinja2: 3.1.6
- Uvicorn: 0.48.0
- pytest: 9.0.2

## Source-tree verification

### Full test suite

Command:

```bash
python -m pytest -q
```

Observed result:

```text
..........................................                               [100%]
42 passed in 5.71s
```

### Acceptance suite

Command:

```bash
python -m pytest tests/acceptance -q
```

Observed result:

```text
............                                                             [100%]
12 passed in 2.52s
```

### Deterministic benchmark

Command:

```bash
PYTHONPATH=src python -m ando.demo --workspace /mnt/data/ando-final-benchmark-workspace
```

Observed result:

```text
ANDO Runtime Lite v0.1 Benchmark

Tasks:                   3
Completed:               3
Parallel branches:       2
Agent crashes:           1
Recovered crashes:       1
Replacement delegates:   1
Human continue inputs:   0
Human escalations:       0
Authority violations:    0
Stale writes rejected:   1
Artifacts exported:      1

RESULT: PASS
```

### Dashboard application factory

Command used a `Settings(workspace=...)` instance and called `create_app(settings)`.

Observed result:

```text
TITLE: ANDO Runtime Lite v0.1
ROUTES: ['/', '/agents', '/artifacts', '/delegations', '/docs', '/docs/oauth2-redirect', '/human', '/human/{item_id}/resolve', '/ledger', '/openapi.json', '/redoc', '/tasks']
```

## Verified behaviors represented by the test suite

- canonical SQLite persistence and required PRAGMAs
- optimistic entity versioning and stale-write rejection
- acyclic Task DAG and deterministic readiness transitions
- deterministic task/Agent scheduling
- MockAgent and ManualAgent adapter behavior
- Delegation Envelope authority/budget subset enforcement
- execution receipts and append-only ledger events
- operational W0/W1/W2 commit gating
- checkpoint creation, crash replacement, and resume
- subtree revocation propagation
- Human Queue routing and canonical resolution event
- restart recovery
- server-rendered dashboard pages
- end-to-end zero-human-continue benchmark

## Release packaging rule

The final ZIP is verified only after extraction into a fresh directory. Its raw SHA-256 is recorded in the companion sidecar file `ANDO_Runtime_Lite_v0.1_SHA256SUMS.txt` and the external final verification report. The ZIP cannot contain a truthful hash of itself because embedding that hash would change the archive bytes.

## Known boundary

This release intentionally does **not** include commercial model APIs, Browser/Web-AI automation, social-platform publishing, full typed epistemic verification, RAG/vector DB, multi-user auth, cloud deployment, or distributed workers. `W1`/`W2` are operational commit classes only; they do not assert epistemic correctness.

## Release-candidate extraction verification

A source ZIP containing tracked release files plus this verification document was extracted into a fresh directory with no `.git`, cache directories, or runtime database.

### Extracted full suite

```text
42 passed in 6.09s
```

### Extracted benchmark

```text
Tasks:                   3
Completed:               3
Parallel branches:       2
Agent crashes:           1
Recovered crashes:       1
Replacement delegates:   1
Human continue inputs:   0
Human escalations:       0
Authority violations:    0
Stale writes rejected:   1
Artifacts exported:      1

RESULT: PASS
```

### Extracted dashboard smoke

```text
DASHBOARD: ANDO Runtime Lite v0.1
ROUTE_COUNT: 12
```

This candidate extraction verifies that the code/tests do not depend on the Git working tree or an existing runtime database. A second verification is performed against the final committed release ZIP after this document and plan status are committed.

## Committed-tree pre-final archive verification

After committing the source-tree verification document, the complete committed file set (`git ls-files`) was packaged into a clean archive and extracted again.

Observed results from the extracted committed tree:

```text
42 passed in 5.54s
RESULT: PASS
DASHBOARD_TITLE ANDO Runtime Lite v0.1
REQUIRED_ROUTES_OK True
```

This validates the exact release construction method. The canonical final archive is rebuilt from the final documentation commit and independently re-verified; its hash and final extracted results are stored in the external sidecars described above.
