from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore
from ando.tasks.graph import add_dependency
from ando.tasks.readiness import resolve_ready_tasks


def make_store(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    return StateStore(session_factory)


def test_dependent_task_becomes_ready_after_prerequisites_complete(tmp_path):
    store = make_store(tmp_path)
    intent = store.create_intent(title="Demo", goal="Demo")
    a = store.create_task(intent.id, title="A", goal="A")
    b = store.create_task(intent.id, title="B", goal="B")
    add_dependency(store, a.id, b.id)
    resolve_ready_tasks(store)
    assert store.get_task(a.id).status == "Ready"
    assert store.get_task(b.id).status == "Pending"
    a = store.get_task(a.id)
    store.update_task(a.id, a.version, status="Completed")
    resolve_ready_tasks(store)
    assert store.get_task(b.id).status == "Ready"
