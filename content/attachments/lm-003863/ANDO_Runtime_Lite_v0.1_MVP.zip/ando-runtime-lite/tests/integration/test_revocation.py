from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore


def test_revocation_propagates_only_through_descendant_subtree(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    for name in ["a1", "a2", "a3", "a4"]:
        agent = MockAgent(name)
        registry.register(agent)
        desc = agent.describe()
        store.register_agent_record(agent_id=name, name=name, adapter_type=desc.adapter_type)

    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    auth = AuthorityEnvelope.default_internal().to_dict()
    budget = BudgetEnvelope(tool_calls=50, agent_slots=4).to_dict()

    d1 = store.create_delegation_record(
        task_id=task.id, delegate_agent_id="a1", state_revision=store.current_revision(),
        task_version=task.version, authority=auth, budget=budget,
    )
    d2 = store.create_delegation_record(
        task_id=task.id, delegate_agent_id="a2", state_revision=store.current_revision(),
        task_version=task.version, authority=auth, budget=budget, parent_delegation_id=d1.id,
    )
    d3 = store.create_delegation_record(
        task_id=task.id, delegate_agent_id="a3", state_revision=store.current_revision(),
        task_version=task.version, authority=auth, budget=budget, parent_delegation_id=d1.id,
    )
    d4 = store.create_delegation_record(
        task_id=task.id, delegate_agent_id="a4", state_revision=store.current_revision(),
        task_version=task.version, authority=auth, budget=budget, parent_delegation_id=d2.id,
    )

    recovery = RecoveryManager(store, registry, Scheduler(), ExecutionSupervisor(store, registry, settings))
    revoked = recovery.revoke(d2.id)

    assert set(revoked) == {d2.id, d4.id}
    assert store.get_delegation(d2.id).status == "Revoked"
    assert store.get_delegation(d4.id).status == "Revoked"
    assert store.get_delegation(d3.id).status == "Offered"
