from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore
from ando.tasks.readiness import resolve_ready_tasks


def make_runtime(tmp_path, mode):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    agent = MockAgent("mock-1", mode=mode)
    registry.register(agent)
    intent = store.create_intent(title="Demo", goal="Demo")
    task = store.create_task(intent.id, title="Task", goal="Task")
    resolve_ready_tasks(store)
    task = store.get_task(task.id)
    delegation = Scheduler().create_delegation(store, task, agent)
    supervisor = ExecutionSupervisor(store, registry, settings)
    return store, registry, supervisor, delegation


def test_checkpoint_then_success_agent_persists_checkpoint_before_completion(tmp_path):
    store, _, supervisor, delegation = make_runtime(tmp_path, "checkpoint_then_success")
    status = supervisor.run_delegation(delegation.id)
    checkpoints = store.checkpoints_for_task(delegation.task_id)
    assert status == "completed"
    assert len(checkpoints) == 1
    assert checkpoints[0].progress_json["progress"] > 0
    assert store.get_task(delegation.task_id).status == "Completed"


def test_always_fail_agent_stops_after_retry_ceiling(tmp_path):
    store, _, supervisor, delegation = make_runtime(tmp_path, "always_fail")
    status = supervisor.run_delegation(delegation.id)
    assert status == "failed"
    assert store.execution_attempt_count(delegation.id) == 3
