from fastapi.testclient import TestClient

from ando.app import create_app
from ando.config import Settings


def test_dashboard_shows_operational_counters(tmp_path):
    app = create_app(Settings(workspace=tmp_path))
    client = TestClient(app)
    response = client.get("/")
    assert response.status_code == 200
    assert "Active Tasks" in response.text
    assert "Need Human" in response.text
    assert "Open Delegations" in response.text


def test_human_queue_resolution_records_canonical_event(tmp_path):
    app = create_app(Settings(workspace=tmp_path))
    store = app.state.store
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    item = store.require_human(
        task_id=task.id,
        reason="NO_COMPATIBLE_AGENT",
        question="Assign manually?",
        options=["manual", "pause"],
        recommendation={"action": "manual"},
    )
    client = TestClient(app)
    response = client.post(
        f"/human/{item.id}/resolve",
        params={"action": "manual", "note": "approved"},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert store.unresolved_human_items() == []
    assert store.events()[-1].event_type == "human.resolved"


import pytest


@pytest.mark.parametrize(
    ("path", "heading"),
    [
        ("/tasks", "Tasks"),
        ("/agents", "Agents"),
        ("/delegations", "Delegations"),
        ("/human", "Need Human"),
        ("/ledger", "Ledger"),
        ("/artifacts", "Artifacts"),
    ],
)
def test_read_only_dashboard_pages_exist(tmp_path, path, heading):
    app = create_app(Settings(workspace=tmp_path))
    client = TestClient(app)
    response = client.get(path)
    assert response.status_code == 200
    assert f"<h2>{heading}</h2>" in response.text
