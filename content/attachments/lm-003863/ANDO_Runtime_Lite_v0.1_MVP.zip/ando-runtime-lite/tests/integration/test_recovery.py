from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore
from ando.tasks.readiness import resolve_ready_tasks


def build_runtime(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    crashing = MockAgent("mock-crash", mode="crash_after_checkpoint")
    backup = MockAgent("mock-backup", mode="success")
    registry.register(crashing)
    registry.register(backup)
    intent = store.create_intent(title="Demo", goal="Demo")
    task = store.create_task(intent.id, title="Task", goal="Task")
    resolve_ready_tasks(store)
    task = store.get_task(task.id)
    old = Scheduler().create_delegation(store, task, crashing)
    supervisor = ExecutionSupervisor(store, registry, settings)
    recovery = RecoveryManager(store, registry, Scheduler(), supervisor)
    return store, registry, supervisor, recovery, old


def test_crashed_agent_is_replaced_with_new_delegation_and_latest_checkpoint(tmp_path):
    store, _, supervisor, recovery, old = build_runtime(tmp_path)
    assert supervisor.run_delegation(old.id) == "crashed"
    replacement = recovery.replace_failed_delegation(old.id)
    assert replacement is not None
    assert replacement.id != old.id
    assert replacement.parent_delegation_id == old.id
    assert replacement.delegate_agent_id == "mock-backup"
    assert store.latest_checkpoint(old.task_id) is not None
