from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.runtime.orchestrator import Orchestrator
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore


def build_runtime(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    registry.register(MockAgent("mock-1"))
    scheduler = Scheduler()
    supervisor = ExecutionSupervisor(store, registry, settings)
    recovery = RecoveryManager(store, registry, scheduler, supervisor)
    orchestrator = Orchestrator(store, registry, scheduler, supervisor, recovery)
    return store, orchestrator


def test_ticks_advance_task_without_human_transition_trigger(tmp_path):
    store, orchestrator = build_runtime(tmp_path)
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")

    for _ in range(6):
        orchestrator.tick()

    assert store.get_task(task.id).status == "Completed"
    assert len(store.unresolved_human_items()) == 0
