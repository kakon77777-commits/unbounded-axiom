from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.runtime.scheduler import Scheduler
from ando.state.store import StateStore
from ando.tasks.readiness import resolve_ready_tasks


def make_runtime_fixture(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    registry.register(MockAgent("mock-1"))
    registry.register(MockAgent("mock-2"))
    return store, registry


def test_scheduler_selects_highest_priority_ready_task_first(tmp_path):
    store, registry = make_runtime_fixture(tmp_path)
    intent = store.create_intent(title="I", goal="G")
    low = store.create_task(intent.id, title="low", goal="low", priority=1)
    high = store.create_task(intent.id, title="high", goal="high", priority=9)
    resolve_ready_tasks(store)
    selected = Scheduler().select(store, registry)
    assert [task.id for task, _ in selected][:2] == [high.id, low.id]


def test_create_delegation_captures_current_revision_and_task_version(tmp_path):
    store, registry = make_runtime_fixture(tmp_path)
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="task", goal="goal", priority=1)
    resolve_ready_tasks(store)
    task = store.get_task(task.id)
    adapter = registry.get("mock-1")

    delegation = Scheduler().create_delegation(store, task, adapter)

    assert delegation.status == "Offered"
    assert delegation.task_version == task.version
    assert delegation.state_revision <= store.current_revision()
    assert delegation.delegate_agent_id == "mock-1"
