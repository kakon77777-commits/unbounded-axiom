from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore


def test_require_human_deduplicates_open_governance_item(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")

    first = store.require_human(
        task_id=task.id,
        reason="NO_COMPATIBLE_AGENT",
        question="Assign manually?",
        options=["manual", "pause"],
        recommendation={"action": "manual"},
    )
    second = store.require_human(
        task_id=task.id,
        reason="NO_COMPATIBLE_AGENT",
        question="Assign manually?",
        options=["manual", "pause"],
        recommendation={"action": "manual"},
    )

    assert first.id == second.id
    assert len(store.unresolved_human_items()) == 1
