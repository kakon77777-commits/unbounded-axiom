import json
from pathlib import Path


def test_machine_readable_schemas_are_valid_json():
    root = Path(__file__).resolve().parents[2]
    for name in ["delegation-envelope.json", "runtime-event.json"]:
        data = json.loads((root / "schemas" / name).read_text(encoding="utf-8"))
        assert data["$schema"].startswith("https://json-schema.org/")
        assert data["type"] == "object"
