from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore


def make_store(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    return StateStore(session_factory)


def test_create_intent_and_task_append_ordered_events(tmp_path):
    store = make_store(tmp_path)
    intent = store.create_intent(title="Demo", goal="Build demo")
    store.create_task(intent.id, title="README", goal="Write README")
    events = store.events()
    assert [e.event_type for e in events] == ["intent.created", "task.created"]
    assert [e.seq for e in events] == sorted(e.seq for e in events)
    assert events[-1].state_revision == store.current_revision()


def test_ledger_meta_tracks_last_append_sequence(tmp_path):
    store = make_store(tmp_path)
    intent = store.create_intent(title="Demo", goal="Build demo")
    store.create_task(intent.id, title="README", goal="Write README")
    assert store.ledger_seq() == store.events()[-1].seq
