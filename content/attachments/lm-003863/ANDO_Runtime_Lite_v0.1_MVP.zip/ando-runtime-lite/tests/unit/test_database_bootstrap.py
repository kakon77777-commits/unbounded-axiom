from sqlalchemy import inspect, text
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database


def test_database_bootstrap_creates_required_tables_and_pragmas(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, _ = create_engine_and_session(settings)
    init_database(engine)

    tables = set(inspect(engine).get_table_names())
    assert {
        "state_meta", "intents", "tasks", "task_edges", "agents",
        "delegations", "artifacts", "checkpoints", "commits", "events",
        "human_queue", "receipts",
    } <= tables

    with engine.connect() as conn:
        assert conn.execute(text("PRAGMA foreign_keys")).scalar_one() == 1
        assert conn.execute(text("PRAGMA journal_mode")).scalar_one().lower() == "wal"
