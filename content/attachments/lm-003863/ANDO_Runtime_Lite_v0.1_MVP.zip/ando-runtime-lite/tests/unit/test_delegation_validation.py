import pytest

from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.delegation.validation import (
    AuthorityEscalationError,
    BudgetEscalationError,
    validate_child_delegation,
)


def test_child_cannot_add_publish_or_higher_commit_class():
    parent = AuthorityEnvelope(
        actions=frozenset({"read_state", "create_artifact"}),
        scopes=frozenset({"project"}),
        commit_classes=frozenset({"W0"}),
        subdelegation=True,
    )
    child = AuthorityEnvelope(
        actions=frozenset({"read_state", "create_artifact", "publish"}),
        scopes=frozenset({"project"}),
        commit_classes=frozenset({"W0", "W2"}),
        subdelegation=False,
    )
    with pytest.raises(AuthorityEscalationError) as exc:
        validate_child_delegation(
            parent,
            BudgetEnvelope(tool_calls=20),
            child,
            BudgetEnvelope(tool_calls=10),
        )
    assert exc.value.code == "AUTHORITY_ESCALATION"


def test_child_cannot_exceed_parent_tool_budget():
    auth = AuthorityEnvelope.default_internal()
    with pytest.raises(BudgetEscalationError) as exc:
        validate_child_delegation(
            auth,
            BudgetEnvelope(tool_calls=20),
            auth,
            BudgetEnvelope(tool_calls=100),
        )
    assert exc.value.code == "BUDGET_ESCALATION"
