from uuid import uuid4

import pytest

from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.commits.gate import CommitRejectedError, OperationalCommitGate
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.db.models import Artifact, utcnow
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore
from ando.tasks.readiness import resolve_ready_tasks


def make_runtime(tmp_path, mode="success"):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    agent = MockAgent("mock-1", mode=mode)
    registry.register(agent)
    intent = store.create_intent(title="Demo", goal="Demo")
    task = store.create_task(intent.id, title="Task", goal="Task")
    resolve_ready_tasks(store)
    task = store.get_task(task.id)
    delegation = Scheduler().create_delegation(store, task, agent)
    supervisor = ExecutionSupervisor(store, registry, settings)
    return settings, store, supervisor, delegation


def test_commit_requires_artifact_hash(tmp_path):
    settings, store, supervisor, delegation = make_runtime(tmp_path)
    assert supervisor.run_delegation(delegation.id) == "completed"
    task = store.get_task(delegation.task_id)

    artifact_id = str(uuid4())
    with store.session_factory() as session, session.begin():
        session.add(Artifact(
            id=artifact_id,
            task_id=task.id,
            delegation_id=delegation.id,
            type="text",
            name="README.md",
            path=str(tmp_path / "artifacts" / "README.md"),
            sha256=None,
            status="Candidate",
            version=1,
            created_by_agent_id="mock-1",
            created_at=utcnow(),
        ))

    gate = OperationalCommitGate(store, settings)
    with pytest.raises(CommitRejectedError):
        gate.commit_artifact(
            artifact_id,
            "W1",
            expected_task_version=task.version,
            delegation_id=delegation.id,
        )
