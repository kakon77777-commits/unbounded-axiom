from pathlib import Path
from types import SimpleNamespace

from ando.agents.base import ExecutionContext
from ando.agents.mock import MockAgent


def make_context(tmp_path):
    return ExecutionContext(
        intent=SimpleNamespace(id="i1"),
        task=SimpleNamespace(id="t1", title="Task"),
        delegation=SimpleNamespace(id="d1"),
        state_revision=1,
        task_version=1,
        workspace_path=Path(tmp_path),
    )


def test_fail_once_agent_fails_then_succeeds(tmp_path):
    context = make_context(tmp_path)
    agent = MockAgent("mock-1", mode="fail_once")
    first = agent.execute(context)
    second = agent.execute(context)
    assert first.status == "failed"
    assert second.status == "completed"


def test_manual_agent_returns_manual_required(tmp_path):
    from ando.agents.manual import ManualAgent

    context = make_context(tmp_path)
    agent = ManualAgent("manual-1")
    assert agent.execute(context).status == "manual_required"
