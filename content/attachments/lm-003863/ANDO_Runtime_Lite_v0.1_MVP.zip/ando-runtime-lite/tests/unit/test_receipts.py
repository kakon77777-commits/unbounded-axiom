from sqlalchemy import func, select

from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.db.models import Commit, Receipt
from ando.delegation.receipts import record_receipt
from ando.state.store import StateStore


def test_record_receipt_persists_receipt_without_implicit_commit(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="G")

    receipt = record_receipt(
        store,
        receipt_type="delegation",
        task_id=task.id,
        payload={"accepted": True},
    )

    assert receipt.receipt_type == "delegation"
    with session_factory() as session:
        assert session.scalar(select(func.count()).select_from(Receipt)) == 1
        assert session.scalar(select(func.count()).select_from(Commit)) == 0
