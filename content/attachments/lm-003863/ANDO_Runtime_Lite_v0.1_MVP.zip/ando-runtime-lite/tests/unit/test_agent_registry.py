from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry


def test_registry_returns_available_capability_match():
    registry = AgentRegistry()
    agent = MockAgent("mock-1", capabilities={"write_file"})
    registry.register(agent)
    assert [a.agent_id for a in registry.compatible("write_file")] == ["mock-1"]
