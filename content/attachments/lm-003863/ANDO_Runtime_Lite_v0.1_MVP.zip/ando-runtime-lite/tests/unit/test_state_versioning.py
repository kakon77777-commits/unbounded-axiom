import pytest

from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore, StaleStateError


def make_store(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    return StateStore(session_factory)


def test_stale_task_write_is_rejected(tmp_path):
    store = make_store(tmp_path)
    intent = store.create_intent(title="Demo", goal="Build demo")
    task = store.create_task(intent.id, title="README", goal="Write README")
    store.update_task(task.id, expected_version=task.version, status="Ready")

    with pytest.raises(StaleStateError) as exc:
        store.update_task(task.id, expected_version=task.version, status="Running")
    assert exc.value.code == "STALE_STATE"
