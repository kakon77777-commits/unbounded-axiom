import pytest

from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.state.store import StateStore
from ando.tasks.graph import add_dependency, TaskCycleError


def make_store(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    return StateStore(session_factory)


def test_dependency_cycle_is_rejected(tmp_path):
    store = make_store(tmp_path)
    intent = store.create_intent(title="Demo", goal="Demo")
    a = store.create_task(intent.id, title="A", goal="A")
    b = store.create_task(intent.id, title="B", goal="B")
    add_dependency(store, a.id, b.id)
    with pytest.raises(TaskCycleError):
        add_dependency(store, b.id, a.id)
