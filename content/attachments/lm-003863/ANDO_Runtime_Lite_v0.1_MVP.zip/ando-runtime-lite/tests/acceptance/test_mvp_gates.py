from pathlib import Path

import pytest

from ando.agents.mock import MockAgent
from ando.agents.registry import AgentRegistry
from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.delegation.validation import AuthorityEscalationError, BudgetEscalationError
from ando.demo import run_demo
from ando.runtime.orchestrator import Orchestrator
from ando.runtime.recovery import RecoveryManager
from ando.runtime.scheduler import Scheduler
from ando.runtime.supervisor import ExecutionSupervisor
from ando.state.store import StateStore, StaleStateError
from ando.tasks.readiness import resolve_ready_tasks


def build_runtime(workspace: Path, agents: list[MockAgent] | None = None):
    settings = Settings(workspace=workspace)
    engine, session_factory = create_engine_and_session(settings)
    init_database(engine)
    store = StateStore(session_factory)
    registry = AgentRegistry()
    for agent in agents or []:
        registry.register(agent)
    scheduler = Scheduler()
    supervisor = ExecutionSupervisor(store, registry, settings)
    recovery = RecoveryManager(store, registry, scheduler, supervisor)
    orchestrator = Orchestrator(store, registry, scheduler, supervisor, recovery)
    return settings, engine, store, registry, scheduler, supervisor, recovery, orchestrator


def test_s1_canonical_state_survives_process_restart(tmp_path):
    settings, engine, store, *_ = build_runtime(tmp_path)
    intent = store.create_intent(title="Persistent", goal="Survive restart")
    task = store.create_task(intent.id, title="Task", goal="Persist")
    revision = store.current_revision()
    engine.dispose()

    _, engine2, store2, *_ = build_runtime(tmp_path)
    assert store2.get_task(task.id).title == "Task"
    assert store2.current_revision() == revision
    engine2.dispose()


def test_s2_agent_replacement_resumes_task_from_checkpoint(tmp_path):
    crash = MockAgent("crash", mode="crash_after_checkpoint")
    backup = MockAgent("backup", mode="demo")
    _, _, store, _, _, _, _, orchestrator = build_runtime(tmp_path, [crash, backup])
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="Create README", goal="Write")

    reports = [orchestrator.tick(), orchestrator.tick(), orchestrator.tick()]

    assert store.get_task(task.id).status == "Completed"
    assert store.latest_checkpoint(task.id) is not None
    replacements = [d for d in store.delegations() if d.parent_delegation_id]
    assert len(replacements) == 1
    assert sum(r.recoveries_created for r in reports) == 1


def test_s3_no_human_context_copy_paste_is_required(tmp_path):
    result = run_demo(tmp_path)
    assert result.human_continue_inputs == 0
    assert result.completed == result.tasks


def test_s4_child_authority_cannot_exceed_parent(tmp_path):
    child_agent = MockAgent("child")
    _, _, store, registry, scheduler, *_ = build_runtime(tmp_path, [child_agent])
    store.register_agent_record(agent_id="parent-agent", name="parent-agent", adapter_type="mock")
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    parent_auth = AuthorityEnvelope(
        actions=frozenset({"read_state"}),
        scopes=frozenset({"project"}),
        commit_classes=frozenset({"W0"}),
        subdelegation=True,
    )
    parent = store.create_delegation_record(
        task_id=task.id,
        delegate_agent_id="parent-agent",
        state_revision=store.current_revision(),
        task_version=task.version,
        authority=parent_auth.to_dict(),
        budget=BudgetEnvelope(tool_calls=100, agent_slots=2).to_dict(),
    )
    with pytest.raises(AuthorityEscalationError):
        scheduler.create_delegation(store, task, child_agent, parent_delegation_id=parent.id)


def test_s5_child_budget_cannot_exceed_parent(tmp_path):
    child_agent = MockAgent("child")
    _, _, store, registry, scheduler, *_ = build_runtime(tmp_path, [child_agent])
    store.register_agent_record(agent_id="parent-agent", name="parent-agent", adapter_type="mock")
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    parent = store.create_delegation_record(
        task_id=task.id,
        delegate_agent_id="parent-agent",
        state_revision=store.current_revision(),
        task_version=task.version,
        authority=AuthorityEnvelope.default_internal().to_dict(),
        budget=BudgetEnvelope(time_seconds=3600, tool_calls=1, agent_slots=1).to_dict(),
    )
    with pytest.raises(BudgetEscalationError):
        scheduler.create_delegation(store, task, child_agent, parent_delegation_id=parent.id)


def test_s6_old_version_write_is_rejected(tmp_path):
    _, _, store, *_ = build_runtime(tmp_path)
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    store.update_task(task.id, task.version, status="Ready")
    with pytest.raises(StaleStateError):
        store.update_task(task.id, task.version, status="Running")


def test_s7_revocation_stops_descendant_subtree(tmp_path):
    agents = [MockAgent(name) for name in ["a1", "a2", "a3"]]
    settings, _, store, registry, scheduler, supervisor, recovery, _ = build_runtime(tmp_path, agents)
    for agent in agents:
        store.register_agent_record(agent_id=agent.agent_id, name=agent.agent_id, adapter_type="mock")
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    auth = AuthorityEnvelope.default_internal().to_dict()
    budget = BudgetEnvelope(tool_calls=50, agent_slots=3).to_dict()
    d1 = store.create_delegation_record(task_id=task.id, delegate_agent_id="a1", state_revision=store.current_revision(), task_version=task.version, authority=auth, budget=budget)
    d2 = store.create_delegation_record(task_id=task.id, delegate_agent_id="a2", state_revision=store.current_revision(), task_version=task.version, authority=auth, budget=budget, parent_delegation_id=d1.id)
    d3 = store.create_delegation_record(task_id=task.id, delegate_agent_id="a3", state_revision=store.current_revision(), task_version=task.version, authority=auth, budget=budget, parent_delegation_id=d2.id)
    assert set(recovery.revoke(d2.id)) == {d2.id, d3.id}
    assert store.get_delegation(d2.id).status == "Revoked"
    assert store.get_delegation(d3.id).status == "Revoked"
    assert store.get_delegation(d1.id).status == "Offered"


def test_s8_important_mutations_are_traceable_in_ledger(tmp_path):
    agent = MockAgent("mock")
    _, _, store, registry, scheduler, supervisor, *_ = build_runtime(tmp_path, [agent])
    intent = store.create_intent(title="I", goal="G")
    task = store.create_task(intent.id, title="T", goal="T")
    resolve_ready_tasks(store)
    task = store.get_task(task.id)
    delegation = scheduler.create_delegation(store, task, agent)
    assert supervisor.run_delegation(delegation.id) == "completed"
    event_types = [e.event_type for e in store.events()]
    for event_type in [
        "intent.created", "task.created", "task.ready", "delegation.offered",
        "delegation.accepted", "task.started", "delegation.running",
        "delegation.delivered", "task.completed", "delegation.completed",
    ]:
        assert event_type in event_types


def test_s9_unresolvable_governance_enters_human_queue(tmp_path):
    _, _, store, _, _, _, _, orchestrator = build_runtime(tmp_path, [])
    intent = store.create_intent(title="I", goal="G")
    store.create_task(intent.id, title="T", goal="T")
    orchestrator.tick()
    items = store.unresolved_human_items()
    assert len(items) == 1
    assert items[0].reason == "NO_COMPATIBLE_AGENT"


def test_s10_demo_finishes_with_zero_human_continue_messages(tmp_path):
    result = run_demo(tmp_path)
    assert result.passed is True
    assert result.human_continue_inputs == 0
