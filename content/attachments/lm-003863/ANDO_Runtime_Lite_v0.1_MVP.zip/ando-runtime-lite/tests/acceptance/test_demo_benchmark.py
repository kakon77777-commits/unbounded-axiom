from ando.demo import run_demo


def test_demo_finishes_without_human_continue_messages(tmp_path):
    result = run_demo(tmp_path)
    assert result.tasks == 3
    assert result.completed == 3
    assert result.parallel_branches == 2
    assert result.agent_crashes == 1
    assert result.recovered_crashes == 1
    assert result.replacement_delegates == 1
    assert result.human_continue_inputs == 0
    assert result.human_escalations == 0
    assert result.authority_violations == 0
    assert result.stale_writes_rejected == 1
    assert result.artifacts_exported == 1
    assert result.passed is True
