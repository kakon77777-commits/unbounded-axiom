from ando.config import Settings
from ando.db.engine import create_engine_and_session, init_database
from ando.delegation.envelope import AuthorityEnvelope, BudgetEnvelope
from ando.state.store import StateStore


def test_restart_preserves_tasks_checkpoints_human_queue_and_ledger(tmp_path):
    settings = Settings(workspace=tmp_path)
    engine1, sf1 = create_engine_and_session(settings)
    init_database(engine1)
    first = StateStore(sf1)
    first.register_agent_record(agent_id="mock-1", name="mock-1", adapter_type="mock")
    intent = first.create_intent(title="I", goal="G")
    task = first.create_task(intent.id, title="T", goal="T", status="Paused")
    delegation = first.create_delegation_record(
        task_id=task.id,
        delegate_agent_id="mock-1",
        state_revision=first.current_revision(),
        task_version=task.version,
        authority=AuthorityEnvelope.default_internal().to_dict(),
        budget=BudgetEnvelope(tool_calls=10).to_dict(),
    )
    first.create_checkpoint(
        task_id=task.id,
        delegation_id=delegation.id,
        agent_id="mock-1",
        task_version=task.version,
        progress={"progress": 0.5},
    )
    first.require_human(
        task_id=task.id,
        delegation_id=delegation.id,
        reason="AMBIGUOUS_RECOVERY",
        question="Resume?",
    )
    event_count = len(first.events())
    engine1.dispose()

    engine2, sf2 = create_engine_and_session(settings)
    init_database(engine2)
    second = StateStore(sf2)

    assert [t.id for t in second.open_tasks()] == [task.id]
    assert second.latest_checkpoint_for_open_task() is not None
    assert len(second.unresolved_human_items()) == 1
    assert len(second.events()) == event_count
