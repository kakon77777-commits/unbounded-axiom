# ANDO Runtime Lite v0.1

A local, single-user MVP for the **AI-Native Distributed Organization (ANDO)** reference architecture. Its purpose is to prove that canonical organizational state can live outside any single AI chat/session, and that routine task transitions can proceed without a human acting as the scheduler, router, copy-paste layer, or retry button.

## What this MVP includes

- SQLite canonical state with WAL and optimistic entity versioning
- Intent + Task DAG
- deterministic Ready resolver and scheduler
- `MockAgent` and `ManualAgent` adapters
- bounded Delegation Envelopes
- child authority/budget anti-escalation rules
- structured checkpoints and replacement delegation lineage
- append-only event ledger
- operational W0/W1/W2 commit gate
- Human Queue for unresolved governance decisions
- local FastAPI/Jinja dashboard
- deterministic failure-injection demo

## What it intentionally does not include

No commercial model API, Browser/Web-AI automation, social-platform publishing, RAG/vector DB, multi-user auth, cloud deployment, distributed workers, payments, or full typed epistemic verification are included in Phase 0–2.

`W1` and `W2` are **operational** commit classes. They do not claim that an artifact has been scientifically, mathematically, legally, or otherwise epistemically verified.

## Requirements

- Python 3.12+

## Install

```bash
python -m pip install -e .
```

For development:

```bash
python -m pip install -e '.[dev]'
```

## Run the deterministic MVP benchmark

```bash
python -m ando.demo --workspace ./workspace/demo-benchmark
```

Expected final line:

```text
RESULT: PASS
```

The demo builds three tasks:

```text
Create README ----\
                   > Package Output
Create Metadata --/
```

The README branch intentionally crashes after a checkpoint. The runtime creates a replacement delegation, resumes from canonical state, completes both branches, then packages and exports the result. No human `continue` message is used as a transition trigger.

## Run the dashboard

Windows:

```text
run.bat
```

Linux/macOS:

```bash
./run.sh
```

Then open:

```text
http://127.0.0.1:8765
```

Dashboard pages:

- `/` overview
- `/tasks`
- `/agents`
- `/delegations`
- `/human`
- `/ledger`
- `/artifacts`

## Run tests

```bash
pytest -q
```

The formal Phase 0–2 acceptance gates cover persistence, replacement/resume, no human context-copy requirement, authority and budget monotonicity, stale-write rejection, revocation propagation, ledger traceability, Human Queue routing, and the zero-continue-message demo.

## Architecture documents

- Design: `docs/superpowers/specs/2026-08-21-ando-runtime-lite-design.md`
- Implementation plan: `docs/superpowers/plans/2026-08-21-ando-runtime-lite.md`

## Core invariant

```text
Human Intent
    -> Persistent Canonical State
    -> Replaceable Agent Execution
    -> Bounded Delegation
    -> Operational Commit
```

The MVP does **not** claim that a fully autonomous company has been implemented. It tests the smaller engineering claim that **human interaction does not need to be the transition trigger for every Agent work step**.
