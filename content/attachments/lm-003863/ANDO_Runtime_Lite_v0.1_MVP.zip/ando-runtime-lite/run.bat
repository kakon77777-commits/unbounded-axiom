@echo off
setlocal
cd /d "%~dp0"
set "PYTHONPATH=%CD%\src;%PYTHONPATH%"
python -m uvicorn ando.app:create_app --factory --host 127.0.0.1 --port 8765
endlocal
