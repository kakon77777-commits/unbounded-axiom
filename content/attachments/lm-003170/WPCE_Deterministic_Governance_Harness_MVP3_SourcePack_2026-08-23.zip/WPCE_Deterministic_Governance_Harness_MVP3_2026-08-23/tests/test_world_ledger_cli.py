import io
import json
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
import tempfile
import unittest

from wpce_harness.world_ledger_cli import main


class WorldLedgerCLITests(unittest.TestCase):
    def run_cli(self, argv):
        out = io.StringIO()
        err = io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            status = main(argv)
        return status, out.getvalue(), err.getvalue()

    def test_init_join_option_and_show_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            self.assertEqual(0, self.run_cli(["init", str(path), "--world", "world-1", "--name", "World One"])[0])
            self.assertEqual(0, self.run_cli(["join", str(path), "alice", "--agency", "1", "--floor", "0.25"])[0])
            self.assertEqual(0, self.run_cli(["option", str(path), "alice", "leave", "--formal", "true", "--reachable", "true", "--meaningful", "true"])[0])
            status, output, error = self.run_cli(["show", str(path)])
            self.assertEqual(0, status)
            self.assertEqual("", error)
            payload = json.loads(output)
            self.assertEqual("world-1", payload["world_id"])
            self.assertEqual(1.0, payload["subjects"]["alice"]["agency"])
            self.assertTrue(payload["subjects"]["alice"]["options"]["leave"]["reachable"])

    def test_conflict_noop_defer_and_resolve_commands(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            self.run_cli(["init", str(path), "--world", "world-1", "--name", "World One"])
            self.run_cli(["join", str(path), "alice", "--agency", "1", "--floor", "0.25"])
            self.run_cli(["join", str(path), "bob", "--agency", "1", "--floor", "0.25"])
            self.assertEqual(0, self.run_cli(["conflict", str(path), "c1", "alice", "bob", "resource"])[0])
            self.assertEqual(0, self.run_cli(["set-noop", str(path), "false"])[0])
            self.assertEqual(0, self.run_cli(["set-defer", str(path), "false"])[0])
            status, output, _ = self.run_cli(["show", str(path), "--pretty"])
            payload = json.loads(output)
            self.assertIn("c1", payload["conflicts"])
            self.assertFalse(payload["noop_available"])
            self.assertFalse(payload["defer_available"])
            self.assertEqual(0, self.run_cli(["resolve-conflict", str(path), "c1"])[0])
            status, output, _ = self.run_cli(["show", str(path)])
            payload = json.loads(output)
            self.assertNotIn("c1", payload["conflicts"])
            self.assertIn("c1", payload["resolved_conflicts"])

    def test_head_verify_and_invalid_transition(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            self.assertEqual(0, self.run_cli(["init", str(path), "--world", "world-1", "--name", "World One"])[0])
            status, head_output, _ = self.run_cli(["head", str(path)])
            self.assertEqual(0, status)
            head = head_output.strip()
            self.assertEqual(64, len(head))
            self.assertEqual(0, self.run_cli(["verify", str(path), "--expected-head", head])[0])
            status, output, error = self.run_cli(["set-agency", str(path), "ghost", "0.5"])
            self.assertEqual(2, status)
            self.assertEqual("", output)
            self.assertIn("unknown subject", error)


if __name__ == "__main__":
    unittest.main()
