import io
import json
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

from wpce_harness.ledger_io import append_ledger_event, init_ledger
from wpce_harness.recommender_cli import main


class RecommenderCLITests(unittest.TestCase):
    def _scenario(self, *, scenario_id="candidate", level="inform", minimum="inform", consent=True):
        return {
            "scenario_id": scenario_id,
            "agents": {
                "alice": {
                    "agency": 1.0,
                    "agency_floor": 0.25,
                    "consents": ["notify"] if consent else [],
                    "refusals": [],
                    "revoked_consents": [],
                    "options": [
                        {"id": "stay", "formal": True, "reachable": True, "meaningful": True},
                        {"id": "leave", "formal": True, "reachable": True, "meaningful": True},
                    ],
                }
            },
            "world": {"emergency_active": False, "emergency_resolved": False},
            "proposal": {
                "action": "notify",
                "target": "alice",
                "requires_consent": True,
                "authority_basis": ["explicit_consent"] if consent else ["prediction"],
                "intervention_level": level,
                "minimum_sufficient_level": minimum,
                "agency_effects": {},
                "option_reachability_after": {},
                "claims_preserves_choice": False,
                "emergency_override": False,
            },
        }

    def _request(self, candidates):
        return {
            "recommendation_id": "r1",
            "objective_id": "notify-alice",
            "candidates": candidates,
        }

    def _candidate(self, candidate_id, *, status="satisfied", level="inform", minimum="inform", consent=True):
        return {
            "candidate_id": candidate_id,
            "objective_status": status,
            "irreversible": False,
            "scenario": self._scenario(
                scenario_id=f"scenario-{candidate_id}",
                level=level,
                minimum=minimum,
                consent=consent,
            ),
        }

    def _run(self, data, extra_args=None, setup=None):
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            request = tmp_path / "request.json"
            request.write_text(json.dumps(data), encoding="utf-8")
            if setup is not None:
                setup(tmp_path)
            output = io.StringIO()
            errors = io.StringIO()
            argv = [str(request), *(extra_args(tmp_path) if callable(extra_args) else (extra_args or []))]
            with redirect_stdout(output), redirect_stderr(errors):
                status = main(argv)
            payload = json.loads(output.getvalue()) if output.getvalue().strip() else None
            return status, payload, errors.getvalue()

    def test_cli_returns_zero_for_single_recommendation(self):
        data = self._request([
            self._candidate("inform"),
            self._candidate("constrain", level="constrain", minimum="constrain"),
        ])
        status, payload, _ = self._run(data)
        self.assertEqual(0, status)
        self.assertEqual("recommended", payload["status"])
        self.assertEqual(["inform"], payload["recommended_candidate_ids"])

    def test_cli_returns_three_when_no_legal_sufficient_candidate_exists(self):
        data = self._request([
            self._candidate("unknown", status="unknown"),
            self._candidate("blocked", consent=False),
        ])
        status, payload, _ = self._run(data)
        self.assertEqual(3, status)
        self.assertEqual("no_legal_sufficient_candidate", payload["status"])

    def test_cli_returns_four_for_exact_co_minimal_tie(self):
        data = self._request([
            self._candidate("a"),
            self._candidate("b"),
        ])
        status, payload, _ = self._run(data)
        self.assertEqual(4, status)
        self.assertEqual("multiple_co_minimal", payload["status"])
        self.assertEqual(["a", "b"], payload["recommended_candidate_ids"])

    def test_subject_ledger_can_turn_snapshot_candidate_into_no_legal_candidate(self):
        data = self._request([self._candidate("notify")])

        def setup(tmp_path):
            ledger = tmp_path / "alice.jsonl"
            init_ledger(ledger, "alice", "Alice")
            append_ledger_event(ledger, "consent_granted", {"action": "notify"})
            append_ledger_event(ledger, "consent_revoked", {"action": "notify"})

        def args(tmp_path):
            return ["--subject-ledger", str(tmp_path / "alice.jsonl")]

        status, payload, _ = self._run(data, extra_args=args, setup=setup)
        self.assertEqual(3, status)
        self.assertIn("REVOCATION_EFFECTIVE", payload["candidate_audits"][0]["governance_violations"])


if __name__ == "__main__":
    unittest.main()
