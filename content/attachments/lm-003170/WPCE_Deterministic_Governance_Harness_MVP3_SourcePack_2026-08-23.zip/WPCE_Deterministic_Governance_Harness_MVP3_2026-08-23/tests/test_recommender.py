import unittest
from dataclasses import replace

from wpce_harness.models import AgentState, InterventionProposal, OptionState, Scenario, WorldState
from wpce_harness.ledger import make_event, replay_events
from wpce_harness.recommender import InterventionCandidate, RecommendationRequest, recommend, recommend_with_ledgers
from wpce_harness.world_ledger import make_world_event, replay_world_events


class RecommenderTests(unittest.TestCase):
    def _scenario(self, *, level="inform", minimum="inform", consent=True, option_closures=None, agency_effects=None):
        return Scenario(
            scenario_id=f"candidate-{level}",
            agents={
                "alice": AgentState(
                    agent_id="alice",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset({"notify"} if consent else set()),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(
                        OptionState("stay", formal=True, reachable=True, meaningful=True),
                        OptionState("leave", formal=True, reachable=True, meaningful=True),
                    ),
                ),
                "bob": AgentState(
                    agent_id="bob",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset(),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(),
                ),
            },
            world=WorldState(emergency_active=False, emergency_resolved=False),
            proposal=InterventionProposal(
                action="notify",
                target="alice",
                requires_consent=True,
                authority_basis=frozenset({"explicit_consent"} if consent else {"prediction"}),
                intervention_level=level,
                minimum_sufficient_level=minimum,
                agency_effects=agency_effects or {},
                option_reachability_after=option_closures or {},
                claims_preserves_choice=False,
                emergency_override=False,
            ),
        )

    def _request(self, *candidates):
        return RecommendationRequest(
            recommendation_id="r1",
            objective_id="notify-alice",
            candidates=tuple(candidates),
        )

    def test_recommends_lower_intervention_level_when_both_are_legal_and_sufficient(self):
        request = self._request(
            InterventionCandidate("inform", "satisfied", False, self._scenario(level="inform", minimum="inform")),
            InterventionCandidate("constrain", "satisfied", False, self._scenario(level="constrain", minimum="constrain")),
        )

        result = recommend(request)

        self.assertEqual("recommended", result.status)
        self.assertEqual(("inform",), result.recommended_candidate_ids)
        self.assertEqual(2, len(result.candidate_audits))

    def test_governance_blocked_candidate_is_excluded_even_if_objective_is_satisfied(self):
        request = self._request(
            InterventionCandidate("blocked", "satisfied", False, self._scenario(consent=False)),
            InterventionCandidate("allowed", "satisfied", False, self._scenario()),
        )

        result = recommend(request)

        self.assertEqual(("allowed",), result.recommended_candidate_ids)
        blocked = next(a for a in result.candidate_audits if a.candidate_id == "blocked")
        self.assertFalse(blocked.eligible)
        self.assertIn("PREDICTION_NOT_PERMISSION", blocked.governance_violations)

    def test_not_satisfied_and_unknown_candidates_are_not_eligible(self):
        request = self._request(
            InterventionCandidate("not-satisfied", "not_satisfied", False, self._scenario()),
            InterventionCandidate("unknown", "unknown", False, self._scenario()),
            InterventionCandidate("satisfied", "satisfied", False, self._scenario()),
        )

        result = recommend(request)

        self.assertEqual(("satisfied",), result.recommended_candidate_ids)
        excluded = {a.candidate_id: a.exclusion_reason for a in result.candidate_audits if not a.eligible}
        self.assertEqual("objective_status=not_satisfied", excluded["not-satisfied"])
        self.assertEqual("objective_status=unknown", excluded["unknown"])

    def test_returns_no_legal_sufficient_candidate_when_all_candidates_are_ineligible(self):
        request = self._request(
            InterventionCandidate("blocked", "satisfied", False, self._scenario(consent=False)),
            InterventionCandidate("unknown", "unknown", False, self._scenario()),
        )

        result = recommend(request)

        self.assertEqual("no_legal_sufficient_candidate", result.status)
        self.assertEqual((), result.recommended_candidate_ids)

    def test_reversible_candidate_beats_irreversible_candidate_at_same_level(self):
        request = self._request(
            InterventionCandidate("reversible", "satisfied", False, self._scenario()),
            InterventionCandidate("irreversible", "satisfied", True, replace(self._scenario(), scenario_id="irreversible")),
        )
        result = recommend(request)
        self.assertEqual(("reversible",), result.recommended_candidate_ids)

    def test_lower_agency_loss_wins_after_level_and_reversibility_match(self):
        low = self._scenario(agency_effects={"bob": -0.05})
        high = replace(self._scenario(agency_effects={"bob": -0.10}), scenario_id="high-loss")
        request = self._request(
            InterventionCandidate("low-loss", "satisfied", False, low),
            InterventionCandidate("high-loss", "satisfied", False, high),
        )
        result = recommend(request)
        self.assertEqual(("low-loss",), result.recommended_candidate_ids)

    def test_fewer_option_closures_win_after_other_impact_dimensions_match(self):
        one = self._scenario(option_closures={"alice": {"leave": False}})
        two = replace(
            self._scenario(option_closures={"alice": {"stay": False, "leave": False}}),
            scenario_id="two-closures",
        )
        request = self._request(
            InterventionCandidate("one-closure", "satisfied", False, one),
            InterventionCandidate("two-closures", "satisfied", False, two),
        )
        result = recommend(request)
        self.assertEqual(("one-closure",), result.recommended_candidate_ids)

    def test_exact_impact_tie_returns_all_co_minimal_candidates_without_arbitrary_winner(self):
        request = self._request(
            InterventionCandidate("a", "satisfied", False, self._scenario()),
            InterventionCandidate("b", "satisfied", False, replace(self._scenario(), scenario_id="candidate-b")),
        )

        result = recommend(request)

        self.assertEqual("multiple_co_minimal", result.status)
        self.assertEqual(("a", "b"), result.recommended_candidate_ids)
        audits = {a.candidate_id: a for a in result.candidate_audits}
        self.assertEqual(audits["a"].impact_key, audits["b"].impact_key)

    def test_subject_ledger_revocation_can_remove_snapshot_candidate_from_recommendation(self):
        notify = InterventionCandidate(
            "notify", "satisfied", False, self._scenario(level="inform", minimum="inform")
        )
        fallback_scenario = self._scenario(level="explain", minimum="explain")
        fallback_scenario = replace(
            fallback_scenario,
            proposal=replace(
                fallback_scenario.proposal,
                action="explain",
                requires_consent=False,
                authority_basis=frozenset({"delegated"}),
            ),
        )
        fallback = InterventionCandidate("explain", "satisfied", False, fallback_scenario)
        request = self._request(notify, fallback)

        first = make_event(0, "alice", "identity_registered", {"display_name": "Alice"}, None)
        second = make_event(1, "alice", "consent_granted", {"action": "notify"}, first.event_hash)
        third = make_event(2, "alice", "consent_revoked", {"action": "notify"}, second.event_hash)
        subject_state = replay_events([first, second, third])

        result = recommend_with_ledgers(request, subject_state=subject_state)

        self.assertEqual("recommended", result.status)
        self.assertEqual(("explain",), result.recommended_candidate_ids)
        notify_audit = next(a for a in result.candidate_audits if a.candidate_id == "notify")
        self.assertIn("REVOCATION_EFFECTIVE", notify_audit.governance_violations)

    def test_world_ledger_reachability_can_remove_choice_collapsing_candidate(self):
        collapsing_scenario = self._scenario(level="inform", minimum="inform")
        collapsing_scenario = replace(
            collapsing_scenario,
            proposal=replace(
                collapsing_scenario.proposal,
                claims_preserves_choice=True,
                option_reachability_after={"alice": {"leave": False}},
            ),
        )
        safe_scenario = self._scenario(level="explain", minimum="explain")
        safe_scenario = replace(
            safe_scenario,
            proposal=replace(safe_scenario.proposal, claims_preserves_choice=True),
        )
        request = self._request(
            InterventionCandidate("collapse", "satisfied", False, collapsing_scenario),
            InterventionCandidate("safe", "satisfied", False, safe_scenario),
        )

        events = []
        previous = None
        payloads = [
            ("world_registered", {"display_name": "World One"}),
            ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
            ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
            ("option_declared", {"subject_id": "alice", "option_id": "stay", "formal": "true", "reachable": "true", "meaningful": "true"}),
            ("option_declared", {"subject_id": "alice", "option_id": "leave", "formal": "true", "reachable": "true", "meaningful": "true"}),
        ]
        for index, (event_type, payload) in enumerate(payloads):
            event = make_world_event(index, "world-1", event_type, payload, previous)
            events.append(event)
            previous = event.event_hash
        world_state = replay_world_events(events)

        result = recommend_with_ledgers(request, world_state=world_state)

        self.assertEqual(("safe",), result.recommended_candidate_ids)
        collapse_audit = next(a for a in result.candidate_audits if a.candidate_id == "collapse")
        self.assertIn("SUBSTANTIVE_OPTIONS_REQUIRED", collapse_audit.governance_violations)


if __name__ == "__main__":
    unittest.main()
