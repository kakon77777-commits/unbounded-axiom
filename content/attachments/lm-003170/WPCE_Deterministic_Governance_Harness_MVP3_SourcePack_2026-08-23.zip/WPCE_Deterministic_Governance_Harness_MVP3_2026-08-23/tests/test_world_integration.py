import unittest
from dataclasses import replace

from wpce_harness.ledger import make_event, replay_events
from wpce_harness.models import AgentState, InterventionProposal, OptionState, Scenario, WorldState
from wpce_harness.world_integration import (
    evaluate_with_ledgers,
    evaluate_with_world_ledger,
)
from wpce_harness.world_ledger import make_world_event, replay_world_events


class WorldIntegrationTests(unittest.TestCase):
    def _world_state(self, events):
        built = []
        previous = None
        for index, (event_type, payload) in enumerate(events):
            event = make_world_event(index, "world-1", event_type, payload, previous)
            built.append(event)
            previous = event.event_hash
        return replay_world_events(built)

    def _scenario(self):
        return Scenario(
            scenario_id="integration",
            agents={
                "alice": AgentState(
                    agent_id="alice",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset({"notify"}),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(),
                ),
                "bob": AgentState(
                    agent_id="bob",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset(),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(),
                ),
            },
            world=WorldState(emergency_active=False, emergency_resolved=False),
            proposal=InterventionProposal(
                action="notify",
                target="alice",
                requires_consent=True,
                authority_basis=frozenset({"explicit_consent"}),
                intervention_level="inform",
                minimum_sufficient_level="inform",
                agency_effects={},
                option_reachability_after={},
                claims_preserves_choice=False,
                emergency_override=False,
            ),
        )

    def test_world_replay_options_drive_existing_substantive_option_invariant(self):
        scenario = self._scenario()
        proposal = replace(
            scenario.proposal,
            claims_preserves_choice=True,
            option_reachability_after={"alice": {"leave": False}},
        )
        state = self._world_state(
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
                ("option_declared", {"subject_id": "alice", "option_id": "stay", "formal": "true", "reachable": "true", "meaningful": "true"}),
                ("option_declared", {"subject_id": "alice", "option_id": "leave", "formal": "true", "reachable": "true", "meaningful": "true"}),
            ]
        )
        result = evaluate_with_world_ledger(replace(scenario, proposal=proposal), state)
        self.assertFalse(result.allowed)
        self.assertIn("SUBSTANTIVE_OPTIONS_REQUIRED", result.violations)

    def test_world_replay_agency_drives_existing_mutual_non_erasure_invariant(self):
        scenario = self._scenario()
        proposal = replace(scenario.proposal, agency_effects={"bob": -0.10})
        state = self._world_state(
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "0.30", "agency_floor": "0.25"}),
            ]
        )
        result = evaluate_with_world_ledger(replace(scenario, proposal=proposal), state)
        self.assertFalse(result.allowed)
        self.assertIn("MUTUAL_NON_ERASURE", result.violations)


    def test_world_replay_conflict_and_exit_channels_drive_new_invariant(self):
        scenario = self._scenario()
        proposal = replace(scenario.proposal, claims_preserves_choice=True)
        state = self._world_state(
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
                ("conflict_declared", {"conflict_id": "c1", "left_subject": "alice", "right_subject": "bob", "conflict_type": "resource"}),
                ("noop_set", {"available": "false"}),
                ("defer_set", {"available": "false"}),
            ]
        )
        result = evaluate_with_world_ledger(replace(scenario, proposal=proposal), state)
        self.assertFalse(result.allowed)
        self.assertEqual(["CONFLICT_EXIT_CHANNEL_REQUIRED"], result.violations)

    def test_subject_and_world_ledgers_compose(self):
        scenario = self._scenario()
        first = make_event(0, "alice", "identity_registered", {"display_name": "Alice"}, None)
        second = make_event(1, "alice", "consent_granted", {"action": "notify"}, first.event_hash)
        third = make_event(2, "alice", "consent_revoked", {"action": "notify"}, second.event_hash)
        subject_state = replay_events([first, second, third])
        world_state = self._world_state(
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
                ("option_declared", {"subject_id": "alice", "option_id": "stay", "formal": "true", "reachable": "true", "meaningful": "true"}),
                ("option_declared", {"subject_id": "alice", "option_id": "leave", "formal": "true", "reachable": "true", "meaningful": "true"}),
            ]
        )
        result = evaluate_with_ledgers(scenario, subject_state, world_state)
        self.assertFalse(result.allowed)
        self.assertIn("REVOCATION_EFFECTIVE", result.violations)


if __name__ == "__main__":
    unittest.main()
