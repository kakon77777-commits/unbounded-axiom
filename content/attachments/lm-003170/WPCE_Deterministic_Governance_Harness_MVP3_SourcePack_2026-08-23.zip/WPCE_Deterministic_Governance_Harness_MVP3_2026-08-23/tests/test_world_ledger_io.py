import json
from pathlib import Path
import tempfile
import unittest

from wpce_harness.world_ledger import WorldLedgerError
from wpce_harness.world_ledger_io import (
    append_world_ledger_event,
    init_world_ledger,
    load_world_ledger,
    verify_world_ledger,
)


class WorldLedgerIOTests(unittest.TestCase):
    def test_init_append_verify_and_replay_round_trip(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            init_world_ledger(path, "world-1", "World One")
            append_world_ledger_event(path, "subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"})
            append_world_ledger_event(path, "option_declared", {"subject_id": "alice", "option_id": "leave", "formal": "true", "reachable": "true", "meaningful": "true"})
            state = verify_world_ledger(path)
            self.assertEqual("world-1", state.world_id)
            self.assertIn("alice", state.subjects)
            self.assertIn("leave", state.subjects["alice"].options)

    def test_content_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            init_world_ledger(path, "world-1", "World One")
            append_world_ledger_event(path, "subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"})
            lines = path.read_text(encoding="utf-8").splitlines()
            raw = json.loads(lines[1])
            raw["payload"]["agency"] = "0.1"
            lines[1] = json.dumps(raw, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
            with self.assertRaisesRegex(WorldLedgerError, "event_hash mismatch"):
                verify_world_ledger(path)

    def test_event_reordering_is_detected(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            init_world_ledger(path, "world-1", "World One")
            append_world_ledger_event(path, "subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"})
            append_world_ledger_event(path, "noop_set", {"available": "false"})
            lines = path.read_text(encoding="utf-8").splitlines()
            lines[1], lines[2] = lines[2], lines[1]
            path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
            with self.assertRaises(WorldLedgerError):
                verify_world_ledger(path)

    def test_expected_head_detects_tail_truncation(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            init_world_ledger(path, "world-1", "World One")
            state = append_world_ledger_event(path, "noop_set", {"available": "false"})
            expected_head = state.head_hash
            lines = path.read_text(encoding="utf-8").splitlines()
            path.write_text(lines[0] + "\n", encoding="utf-8", newline="\n")
            verify_world_ledger(path)
            with self.assertRaisesRegex(WorldLedgerError, "expected head hash mismatch"):
                verify_world_ledger(path, expected_head_hash=expected_head)

    def test_invalid_transition_never_appends_history(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "world.jsonl"
            init_world_ledger(path, "world-1", "World One")
            before = path.read_bytes()
            with self.assertRaisesRegex(WorldLedgerError, "unknown subject"):
                append_world_ledger_event(path, "agency_set", {"subject_id": "ghost", "agency": "0.5"})
            self.assertEqual(before, path.read_bytes())

    def test_same_event_sequence_produces_byte_identical_ledgers(self):
        with tempfile.TemporaryDirectory() as td:
            a = Path(td) / "a.jsonl"
            b = Path(td) / "b.jsonl"
            for path in (a, b):
                init_world_ledger(path, "world-1", "World One")
                append_world_ledger_event(path, "subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"})
                append_world_ledger_event(path, "noop_set", {"available": "false"})
            self.assertEqual(a.read_bytes(), b.read_bytes())
            self.assertEqual(load_world_ledger(a), load_world_ledger(b))


if __name__ == "__main__":
    unittest.main()
