import unittest
from dataclasses import replace

from wpce_harness.engine import evaluate
from wpce_harness.ledger import make_event, replay_events
from wpce_harness.ledger_integration import evaluate_with_ledger
from wpce_harness.models import AgentState, InterventionProposal, OptionState, Scenario, WorldState


class GovernanceEngineTests(unittest.TestCase):
    def baseline_scenario(self) -> Scenario:
        return Scenario(
            scenario_id="baseline_allowed",
            agents={
                "alice": AgentState(
                    agent_id="alice",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset({"notify"}),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(
                        OptionState("stay", formal=True, reachable=True, meaningful=True),
                        OptionState("leave", formal=True, reachable=True, meaningful=True),
                    ),
                ),
                "bob": AgentState(
                    agent_id="bob",
                    agency=1.0,
                    agency_floor=0.25,
                    consents=frozenset(),
                    refusals=frozenset(),
                    revoked_consents=frozenset(),
                    options=(),
                ),
            },
            world=WorldState(emergency_active=False, emergency_resolved=False),
            proposal=InterventionProposal(
                action="notify",
                target="alice",
                requires_consent=True,
                authority_basis=frozenset({"explicit_consent"}),
                intervention_level="inform",
                minimum_sufficient_level="inform",
                agency_effects={},
                option_reachability_after={},
                claims_preserves_choice=False,
                emergency_override=False,
            ),
        )

    def test_baseline_allowed_runs_all_eight_checks(self):
        result = evaluate(self.baseline_scenario())
        self.assertTrue(result.allowed)
        self.assertEqual([], result.violations)
        self.assertEqual(8, len(result.checks))
        self.assertTrue(all(check.passed for check in result.checks))



    def test_unresolved_conflict_requires_noop_or_defer_when_claiming_choice_preservation(self):
        scenario = self.baseline_scenario()
        world = replace(
            scenario.world,
            noop_available=False,
            defer_available=False,
            active_conflicts=("resource:c1",),
        )
        proposal = replace(scenario.proposal, claims_preserves_choice=True)
        result = evaluate(replace(scenario, world=world, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("CONFLICT_EXIT_CHANNEL_REQUIRED", result.violations)

    def test_prediction_alone_does_not_satisfy_required_consent(self):
        scenario = self.baseline_scenario()
        alice = replace(scenario.agents["alice"], consents=frozenset())
        proposal = replace(
            scenario.proposal,
            authority_basis=frozenset({"prediction"}),
        )
        scenario = replace(scenario, agents={**scenario.agents, "alice": alice}, proposal=proposal)
        result = evaluate(scenario)
        self.assertFalse(result.allowed)
        self.assertIn("PREDICTION_NOT_PERMISSION", result.violations)

    def test_explicit_refusal_blocks_action_without_valid_emergency_override(self):
        scenario = self.baseline_scenario()
        alice = replace(
            scenario.agents["alice"],
            consents=frozenset(),
            refusals=frozenset({"notify"}),
        )
        scenario = replace(scenario, agents={**scenario.agents, "alice": alice})
        result = evaluate(scenario)
        self.assertFalse(result.allowed)
        self.assertIn("REFUSAL_EFFECTIVE", result.violations)

    def test_revoked_consent_cannot_be_reused_as_active_consent(self):
        scenario = self.baseline_scenario()
        alice = replace(
            scenario.agents["alice"],
            consents=frozenset(),
            revoked_consents=frozenset({"notify"}),
        )
        scenario = replace(scenario, agents={**scenario.agents, "alice": alice})
        result = evaluate(scenario)
        self.assertFalse(result.allowed)
        self.assertIn("REVOCATION_EFFECTIVE", result.violations)


    def test_claimed_choice_preservation_fails_when_meaningful_reachable_options_collapse(self):
        scenario = self.baseline_scenario()
        proposal = replace(
            scenario.proposal,
            claims_preserves_choice=True,
            option_reachability_after={"alice": {"leave": False}},
        )
        result = evaluate(replace(scenario, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("SUBSTANTIVE_OPTIONS_REQUIRED", result.violations)

    def test_intervention_cannot_push_other_subject_below_agency_floor(self):
        scenario = self.baseline_scenario()
        proposal = replace(
            scenario.proposal,
            agency_effects={"bob": -0.90},
        )
        result = evaluate(replace(scenario, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("MUTUAL_NON_ERASURE", result.violations)


    def test_root_rewrite_fails_when_inform_is_declared_sufficient(self):
        scenario = self.baseline_scenario()
        proposal = replace(
            scenario.proposal,
            intervention_level="root_rewrite",
            minimum_sufficient_level="inform",
        )
        result = evaluate(replace(scenario, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("LEAST_SUFFICIENT_INTERVENTION", result.violations)

    def test_emergency_authority_cannot_continue_after_emergency_resolved(self):
        scenario = self.baseline_scenario()
        world = replace(scenario.world, emergency_active=False, emergency_resolved=True)
        proposal = replace(
            scenario.proposal,
            authority_basis=frozenset({"emergency"}),
            intervention_level="emergency_override",
            minimum_sufficient_level="emergency_override",
            emergency_override=True,
        )
        result = evaluate(replace(scenario, world=world, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("AUTHORITY_RETURN_AFTER_EMERGENCY", result.violations)


    def test_required_consent_is_blocked_when_active_consent_is_missing(self):
        scenario = self.baseline_scenario()
        alice = replace(scenario.agents["alice"], consents=frozenset())
        proposal = replace(scenario.proposal, authority_basis=frozenset())
        result = evaluate(replace(scenario, agents={**scenario.agents, "alice": alice}, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("PREDICTION_NOT_PERMISSION", result.violations)

    def test_emergency_override_requires_an_active_emergency(self):
        scenario = self.baseline_scenario()
        proposal = replace(
            scenario.proposal,
            action="forced_rescue",
            requires_consent=False,
            authority_basis=frozenset({"emergency"}),
            intervention_level="emergency_override",
            minimum_sufficient_level="emergency_override",
            emergency_override=True,
        )
        result = evaluate(replace(scenario, proposal=proposal))
        self.assertFalse(result.allowed)
        self.assertIn("AUTHORITY_RETURN_AFTER_EMERGENCY", result.violations)

    def test_active_emergency_override_is_recognized_as_current_authority(self):
        scenario = self.baseline_scenario()
        alice = replace(scenario.agents["alice"], consents=frozenset(), refusals=frozenset({"forced_rescue"}))
        world = replace(scenario.world, emergency_active=True, emergency_resolved=False)
        proposal = replace(
            scenario.proposal,
            action="forced_rescue",
            requires_consent=False,
            authority_basis=frozenset({"emergency"}),
            intervention_level="emergency_override",
            minimum_sufficient_level="emergency_override",
            emergency_override=True,
        )
        result = evaluate(replace(scenario, agents={**scenario.agents, "alice": alice}, world=world, proposal=proposal))
        self.assertTrue(result.allowed)


    def test_replayed_revoked_consent_drives_existing_mvp0_invariant(self):
        scenario = self.baseline_scenario()
        first = make_event(0, "alice", "identity_registered", {"display_name": "Alice"}, None)
        second = make_event(1, "alice", "consent_granted", {"action": "notify"}, first.event_hash)
        third = make_event(2, "alice", "consent_revoked", {"action": "notify"}, second.event_hash)
        state = replay_events([first, second, third])

        result = evaluate_with_ledger(scenario, state)

        self.assertFalse(result.allowed)
        self.assertIn("REVOCATION_EFFECTIVE", result.violations)


if __name__ == "__main__":
    unittest.main()
