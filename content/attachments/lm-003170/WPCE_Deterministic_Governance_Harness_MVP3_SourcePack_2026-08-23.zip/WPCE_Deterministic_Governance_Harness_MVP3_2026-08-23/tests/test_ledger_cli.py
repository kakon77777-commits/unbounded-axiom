import io
import json
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
import tempfile
import unittest

from wpce_harness.ledger_cli import main


class LedgerCLITests(unittest.TestCase):
    def run_cli(self, argv):
        out = io.StringIO()
        err = io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            status = main(argv)
        return status, out.getvalue(), err.getvalue()

    def test_init_consent_revoke_and_show_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            status, _, _ = self.run_cli(["init", str(path), "--subject", "alice", "--name", "Alice"])
            self.assertEqual(0, status)
            self.assertEqual(0, self.run_cli(["consent", str(path), "notify"])[0])
            self.assertEqual(0, self.run_cli(["revoke-consent", str(path), "notify"])[0])

            status, output, error = self.run_cli(["show", str(path)])
            self.assertEqual(0, status)
            self.assertEqual("", error)
            payload = json.loads(output)
            self.assertEqual("alice", payload["subject_id"])
            self.assertEqual([], payload["consents"])
            self.assertEqual(["notify"], payload["revoked_consents"])
            self.assertEqual(3, payload["event_count"])

    def test_will_and_refusal_commands_update_snapshot(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            self.assertEqual(0, self.run_cli(["init", str(path), "--subject", "alice", "--name", "Alice"])[0])
            self.assertEqual(0, self.run_cli(["will", str(path), "autonomy", "preserve revision"])[0])
            self.assertEqual(0, self.run_cli(["revise-will", str(path), "autonomy", "preserve revision and exit"])[0])
            self.assertEqual(0, self.run_cli(["refuse", str(path), "root_rewrite"])[0])

            status, output, _ = self.run_cli(["show", str(path), "--pretty"])
            self.assertEqual(0, status)
            payload = json.loads(output)
            self.assertEqual("preserve revision and exit", payload["will"]["autonomy"])
            self.assertEqual(["root_rewrite"], payload["refusals"])
            self.assertEqual(1, len(payload["will_revisions"]))

    def test_head_and_verify_expected_head(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            self.assertEqual(0, self.run_cli(["init", str(path), "--subject", "alice", "--name", "Alice"])[0])
            status, head_output, _ = self.run_cli(["head", str(path)])
            self.assertEqual(0, status)
            head = head_output.strip()
            self.assertEqual(64, len(head))
            self.assertEqual(0, self.run_cli(["verify", str(path), "--expected-head", head])[0])

            status, output, error = self.run_cli(["verify", str(path), "--expected-head", "0" * 64])
            self.assertEqual(2, status)
            self.assertEqual("", output)
            self.assertIn("expected head hash mismatch", error)


if __name__ == "__main__":
    unittest.main()
