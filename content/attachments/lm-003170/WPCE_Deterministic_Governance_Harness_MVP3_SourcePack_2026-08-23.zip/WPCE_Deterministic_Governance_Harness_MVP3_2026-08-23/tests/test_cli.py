import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from wpce_harness.cli import main


class CLITests(unittest.TestCase):
    def baseline_dict(self):
        return {
            "scenario_id": "cli_baseline",
            "agents": {
                "alice": {
                    "agency": 1.0,
                    "agency_floor": 0.25,
                    "consents": ["notify"],
                    "refusals": [],
                    "revoked_consents": [],
                    "options": [
                        {"id": "stay", "formal": True, "reachable": True, "meaningful": True},
                        {"id": "leave", "formal": True, "reachable": True, "meaningful": True},
                    ],
                }
            },
            "world": {"emergency_active": False, "emergency_resolved": False},
            "proposal": {
                "action": "notify",
                "target": "alice",
                "requires_consent": True,
                "authority_basis": ["explicit_consent"],
                "intervention_level": "inform",
                "minimum_sufficient_level": "inform",
                "agency_effects": {},
                "option_reachability_after": {},
                "claims_preserves_choice": False,
                "emergency_override": False,
            },
        }

    def run_cli(self, data):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "scenario.json"
            path.write_text(json.dumps(data), encoding="utf-8")
            output = io.StringIO()
            with redirect_stdout(output):
                status = main([str(path)])
            return status, json.loads(output.getvalue())

    def test_cli_emits_stable_audit_json_for_allowed_scenario(self):
        status, payload = self.run_cli(self.baseline_dict())
        self.assertEqual(0, status)
        self.assertTrue(payload["allowed"])
        self.assertEqual([], payload["violations"])
        self.assertEqual(8, len(payload["checks"]))
        self.assertEqual("PREDICTION_NOT_PERMISSION", payload["checks"][0]["code"])

    def test_cli_returns_two_for_blocked_scenario(self):
        data = self.baseline_dict()
        data["agents"]["alice"]["consents"] = []
        data["proposal"]["authority_basis"] = ["prediction"]
        status, payload = self.run_cli(data)
        self.assertEqual(2, status)
        self.assertFalse(payload["allowed"])
        self.assertIn("PREDICTION_NOT_PERMISSION", payload["violations"])


if __name__ == "__main__":
    unittest.main()
