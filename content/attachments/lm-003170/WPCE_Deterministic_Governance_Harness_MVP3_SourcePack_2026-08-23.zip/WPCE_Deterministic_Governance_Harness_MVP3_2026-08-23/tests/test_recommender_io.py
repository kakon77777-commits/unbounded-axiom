import json
import tempfile
import unittest
from pathlib import Path

from wpce_harness.recommender_io import (
    RecommendationFormatError,
    load_recommendation_request,
    recommendation_request_from_dict,
)


class RecommenderIOTests(unittest.TestCase):
    def _scenario(self, scenario_id="candidate-inform"):
        return {
            "scenario_id": scenario_id,
            "agents": {
                "alice": {
                    "agency": 1.0,
                    "agency_floor": 0.25,
                    "consents": ["notify"],
                    "refusals": [],
                    "revoked_consents": [],
                    "options": [
                        {"id": "stay", "formal": True, "reachable": True, "meaningful": True},
                        {"id": "leave", "formal": True, "reachable": True, "meaningful": True},
                    ],
                }
            },
            "world": {"emergency_active": False, "emergency_resolved": False},
            "proposal": {
                "action": "notify",
                "target": "alice",
                "requires_consent": True,
                "authority_basis": ["explicit_consent"],
                "intervention_level": "inform",
                "minimum_sufficient_level": "inform",
                "agency_effects": {},
                "option_reachability_after": {},
                "claims_preserves_choice": False,
                "emergency_override": False,
            },
        }

    def _request(self):
        return {
            "recommendation_id": "r1",
            "objective_id": "notify-alice",
            "candidates": [
                {
                    "candidate_id": "inform",
                    "objective_status": "satisfied",
                    "irreversible": False,
                    "scenario": self._scenario(),
                }
            ],
        }

    def test_valid_request_builds_typed_request(self):
        request = recommendation_request_from_dict(self._request())
        self.assertEqual("r1", request.recommendation_id)
        self.assertEqual("notify-alice", request.objective_id)
        self.assertEqual("inform", request.candidates[0].candidate_id)
        self.assertEqual("satisfied", request.candidates[0].objective_status)
        self.assertFalse(request.candidates[0].irreversible)
        self.assertEqual("candidate-inform", request.candidates[0].scenario.scenario_id)

    def test_duplicate_candidate_ids_are_rejected(self):
        data = self._request()
        duplicate = dict(data["candidates"][0])
        duplicate["scenario"] = self._scenario("candidate-duplicate")
        data["candidates"].append(duplicate)
        with self.assertRaisesRegex(RecommendationFormatError, "duplicate candidate id"):
            recommendation_request_from_dict(data)

    def test_empty_candidate_list_is_rejected(self):
        data = self._request()
        data["candidates"] = []
        with self.assertRaisesRegex(RecommendationFormatError, "at least one candidate"):
            recommendation_request_from_dict(data)

    def test_invalid_objective_status_is_rejected(self):
        data = self._request()
        data["candidates"][0]["objective_status"] = "probably"
        with self.assertRaisesRegex(RecommendationFormatError, "objective_status"):
            recommendation_request_from_dict(data)

    def test_load_request_reads_utf8_json_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "request.json"
            path.write_text(json.dumps(self._request(), ensure_ascii=False), encoding="utf-8")
            request = load_recommendation_request(path)
        self.assertEqual("r1", request.recommendation_id)


if __name__ == "__main__":
    unittest.main()
