import unittest

from wpce_harness.ledger import LedgerError, make_event, replay_events, verify_events


class LedgerCoreTests(unittest.TestCase):
    def test_identity_registration_replays_to_deterministic_state(self):
        event = make_event(
            sequence=0,
            subject_id="alice",
            event_type="identity_registered",
            payload={"display_name": "Alice"},
            previous_hash=None,
        )

        state = replay_events([event])

        self.assertEqual("alice", state.subject_id)
        self.assertEqual("Alice", state.display_name)
        self.assertEqual({}, dict(state.will))
        self.assertEqual(frozenset(), state.consents)
        self.assertEqual(frozenset(), state.refusals)
        self.assertEqual(1, state.event_count)
        self.assertEqual(event.event_hash, state.head_hash)
        self.assertEqual(event.event_hash, verify_events([event]))

    def test_same_event_body_produces_same_hash(self):
        a = make_event(0, "alice", "identity_registered", {"display_name": "Alice"}, None)
        b = make_event(0, "alice", "identity_registered", {"display_name": "Alice"}, None)
        self.assertEqual(a, b)
        self.assertEqual(a.event_hash, b.event_hash)

    def test_first_event_must_register_identity(self):
        event = make_event(0, "alice", "will_declared", {"key": "autonomy", "value": "revise"}, None)
        with self.assertRaisesRegex(LedgerError, "first event must be identity_registered"):
            replay_events([event])


    def _chain(self, subject_id, events):
        built = []
        previous_hash = None
        for index, (event_type, payload) in enumerate(events):
            event = make_event(index, subject_id, event_type, payload, previous_hash)
            built.append(event)
            previous_hash = event.event_hash
        return built

    def test_will_declaration_and_revision_preserve_current_value_and_history(self):
        events = self._chain(
            "alice",
            [
                ("identity_registered", {"display_name": "Alice"}),
                ("will_declared", {"key": "autonomy", "value": "preserve revision"}),
                ("will_revised", {"key": "autonomy", "value": "preserve revision and exit"}),
            ],
        )
        state = replay_events(events)
        self.assertEqual({"autonomy": "preserve revision and exit"}, dict(state.will))
        self.assertEqual(1, len(state.will_revisions))
        revision = state.will_revisions[0]
        self.assertEqual("autonomy", revision.key)
        self.assertEqual("preserve revision", revision.old_value)
        self.assertEqual("preserve revision and exit", revision.new_value)
        self.assertEqual(2, revision.sequence)

    def test_consent_grant_then_revoke_derives_current_governance_state(self):
        events = self._chain(
            "alice",
            [
                ("identity_registered", {"display_name": "Alice"}),
                ("consent_granted", {"action": "notify"}),
                ("consent_revoked", {"action": "notify"}),
            ],
        )
        state = replay_events(events)
        self.assertEqual(frozenset(), state.consents)
        self.assertEqual(frozenset({"notify"}), state.revoked_consents)

    def test_refusal_record_then_withdraw_derives_current_governance_state(self):
        events = self._chain(
            "alice",
            [
                ("identity_registered", {"display_name": "Alice"}),
                ("refusal_recorded", {"action": "notify"}),
                ("refusal_withdrawn", {"action": "notify"}),
            ],
        )
        state = replay_events(events)
        self.assertEqual(frozenset(), state.refusals)
        self.assertEqual(frozenset({"notify"}), state.withdrawn_refusals)

    def test_invalid_state_transitions_are_rejected(self):
        bad_cases = [
            (
                [("identity_registered", {"display_name": "Alice"}), ("will_revised", {"key": "autonomy", "value": "x"})],
                "cannot revise unknown will key",
            ),
            (
                [("identity_registered", {"display_name": "Alice"}), ("consent_revoked", {"action": "notify"})],
                "cannot revoke inactive consent",
            ),
            (
                [("identity_registered", {"display_name": "Alice"}), ("refusal_withdrawn", {"action": "notify"})],
                "cannot withdraw inactive refusal",
            ),
            (
                [("identity_registered", {"display_name": "Alice"}), ("identity_registered", {"display_name": "Again"})],
                "identity_registered may appear only once",
            ),
        ]
        for raw_events, message in bad_cases:
            with self.subTest(message=message):
                with self.assertRaisesRegex(LedgerError, message):
                    replay_events(self._chain("alice", raw_events))


if __name__ == "__main__":
    unittest.main()
