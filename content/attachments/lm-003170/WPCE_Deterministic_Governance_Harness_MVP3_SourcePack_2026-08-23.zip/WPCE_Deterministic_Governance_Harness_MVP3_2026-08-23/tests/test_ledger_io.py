import json
from pathlib import Path
import tempfile
import unittest

from wpce_harness.ledger import LedgerError
from wpce_harness.ledger_io import (
    append_ledger_event,
    init_ledger,
    load_ledger,
    verify_ledger,
)


class LedgerIOTests(unittest.TestCase):
    def test_init_append_verify_and_replay_round_trip(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_state = init_ledger(path, "alice", "Alice")
            self.assertEqual("alice", init_state.subject_id)

            append_ledger_event(path, "will_declared", {"key": "autonomy", "value": "preserve revision"})
            state = append_ledger_event(path, "consent_granted", {"action": "notify"})

            self.assertEqual({"autonomy": "preserve revision"}, dict(state.will))
            self.assertEqual(frozenset({"notify"}), state.consents)
            self.assertEqual(state.head_hash, verify_ledger(path).head_hash)
            self.assertEqual(3, len(load_ledger(path)))

    def test_same_event_sequence_produces_byte_identical_ledgers(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = Path(tmp) / "a.jsonl"
            b = Path(tmp) / "b.jsonl"
            for path in (a, b):
                init_ledger(path, "alice", "Alice")
                append_ledger_event(path, "will_declared", {"key": "autonomy", "value": "preserve revision"})
                append_ledger_event(path, "consent_granted", {"action": "notify"})
            self.assertEqual(a.read_bytes(), b.read_bytes())

    def test_content_tampering_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_ledger(path, "alice", "Alice")
            append_ledger_event(path, "consent_granted", {"action": "notify"})
            lines = path.read_text(encoding="utf-8").splitlines()
            second = json.loads(lines[1])
            second["payload"]["action"] = "root_rewrite"
            lines[1] = json.dumps(second, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
            with self.assertRaisesRegex(LedgerError, "event_hash mismatch"):
                verify_ledger(path)

    def test_event_reordering_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_ledger(path, "alice", "Alice")
            append_ledger_event(path, "will_declared", {"key": "autonomy", "value": "preserve revision"})
            append_ledger_event(path, "consent_granted", {"action": "notify"})
            lines = path.read_text(encoding="utf-8").splitlines()
            lines[1], lines[2] = lines[2], lines[1]
            path.write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")
            with self.assertRaisesRegex(LedgerError, "sequence mismatch"):
                verify_ledger(path)

    def test_expected_head_detects_tail_truncation_that_chain_alone_cannot(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_ledger(path, "alice", "Alice")
            append_ledger_event(path, "will_declared", {"key": "autonomy", "value": "preserve revision"})
            complete = append_ledger_event(path, "consent_granted", {"action": "notify"})
            expected_head = complete.head_hash

            lines = path.read_text(encoding="utf-8").splitlines()
            path.write_text("\n".join(lines[:-1]) + "\n", encoding="utf-8", newline="\n")

            truncated_state = verify_ledger(path)
            self.assertNotEqual(expected_head, truncated_state.head_hash)
            with self.assertRaisesRegex(LedgerError, "expected head hash mismatch"):
                verify_ledger(path, expected_head_hash=expected_head)


    def test_invalid_transition_never_appends_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_ledger(path, "alice", "Alice")
            before = path.read_bytes()
            with self.assertRaisesRegex(LedgerError, "cannot revoke inactive consent"):
                append_ledger_event(path, "consent_revoked", {"action": "notify"})
            self.assertEqual(before, path.read_bytes())

    def test_init_does_not_overwrite_existing_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "alice.jsonl"
            init_ledger(path, "alice", "Alice")
            before = path.read_bytes()
            with self.assertRaisesRegex(LedgerError, "ledger already exists"):
                init_ledger(path, "alice", "Alice Again")
            self.assertEqual(before, path.read_bytes())


if __name__ == "__main__":
    unittest.main()
