import unittest

from wpce_harness.world_ledger import (
    WorldLedgerError,
    make_world_event,
    replay_world_events,
    verify_world_events,
)


class WorldLedgerCoreTests(unittest.TestCase):
    def _chain(self, world_id, events):
        built = []
        previous_hash = None
        for index, (event_type, payload) in enumerate(events):
            event = make_world_event(index, world_id, event_type, payload, previous_hash)
            built.append(event)
            previous_hash = event.event_hash
        return built

    def test_registration_subject_and_option_replay(self):
        events = self._chain(
            "world-1",
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1.0", "agency_floor": "0.25"}),
                (
                    "option_declared",
                    {
                        "subject_id": "alice",
                        "option_id": "leave",
                        "formal": "true",
                        "reachable": "true",
                        "meaningful": "true",
                    },
                ),
            ],
        )

        state = replay_world_events(events)

        self.assertEqual("world-1", state.world_id)
        self.assertEqual("World One", state.display_name)
        self.assertEqual(1.0, state.subjects["alice"].agency)
        self.assertEqual(0.25, state.subjects["alice"].agency_floor)
        option = state.subjects["alice"].options["leave"]
        self.assertTrue(option.formal)
        self.assertTrue(option.reachable)
        self.assertTrue(option.meaningful)
        self.assertEqual(events[-1].event_hash, verify_world_events(events))

    def test_option_reachability_and_meaningfulness_updates_replay(self):
        events = self._chain(
            "world-1",
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("option_declared", {"subject_id": "alice", "option_id": "leave", "formal": "true", "reachable": "true", "meaningful": "true"}),
                ("option_reachability_set", {"subject_id": "alice", "option_id": "leave", "reachable": "false"}),
                ("option_meaningfulness_set", {"subject_id": "alice", "option_id": "leave", "meaningful": "false"}),
            ],
        )
        state = replay_world_events(events)
        option = state.subjects["alice"].options["leave"]
        self.assertFalse(option.reachable)
        self.assertFalse(option.meaningful)

    def test_agency_update_replays(self):
        events = self._chain(
            "world-1",
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1.0", "agency_floor": "0.25"}),
                ("agency_set", {"subject_id": "bob", "agency": "0.40"}),
            ],
        )
        state = replay_world_events(events)
        self.assertEqual(0.4, state.subjects["bob"].agency)

    def test_conflict_declare_resolve_and_exit_channels_replay(self):
        events = self._chain(
            "world-1",
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
                ("conflict_declared", {"conflict_id": "c1", "left_subject": "alice", "right_subject": "bob", "conflict_type": "resource"}),
                ("noop_set", {"available": "false"}),
                ("defer_set", {"available": "true"}),
            ],
        )
        state = replay_world_events(events)
        self.assertIn("c1", state.conflicts)
        self.assertFalse(state.noop_available)
        self.assertTrue(state.defer_available)

        resolved = self._chain(
            "world-1",
            [
                ("world_registered", {"display_name": "World One"}),
                ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ("subject_joined", {"subject_id": "bob", "agency": "1", "agency_floor": "0.25"}),
                ("conflict_declared", {"conflict_id": "c1", "left_subject": "alice", "right_subject": "bob", "conflict_type": "resource"}),
                ("conflict_resolved", {"conflict_id": "c1"}),
            ],
        )
        state2 = replay_world_events(resolved)
        self.assertNotIn("c1", state2.conflicts)
        self.assertIn("c1", state2.resolved_conflicts)

    def test_invalid_transitions_are_rejected(self):
        cases = [
            (
                [
                    ("world_registered", {"display_name": "World One"}),
                    ("option_declared", {"subject_id": "ghost", "option_id": "x", "formal": "true", "reachable": "true", "meaningful": "true"}),
                ],
                "unknown subject",
            ),
            (
                [
                    ("world_registered", {"display_name": "World One"}),
                    ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                    ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                ],
                "already joined",
            ),
            (
                [
                    ("world_registered", {"display_name": "World One"}),
                    ("subject_joined", {"subject_id": "alice", "agency": "1.2", "agency_floor": "0.25"}),
                ],
                "agency must be between 0 and 1",
            ),
            (
                [
                    ("world_registered", {"display_name": "World One"}),
                    ("subject_joined", {"subject_id": "alice", "agency": "1", "agency_floor": "0.25"}),
                    ("conflict_resolved", {"conflict_id": "missing"}),
                ],
                "cannot resolve inactive conflict",
            ),
        ]
        for raw, message in cases:
            with self.subTest(message=message):
                with self.assertRaisesRegex(WorldLedgerError, message):
                    replay_world_events(self._chain("world-1", raw))


if __name__ == "__main__":
    unittest.main()
