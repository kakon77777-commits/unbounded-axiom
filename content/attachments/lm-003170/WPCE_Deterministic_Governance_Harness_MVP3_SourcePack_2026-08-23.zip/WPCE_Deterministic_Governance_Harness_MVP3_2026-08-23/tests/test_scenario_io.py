import unittest

from wpce_harness.scenario_io import ScenarioFormatError, scenario_from_dict


class ScenarioIOTests(unittest.TestCase):
    def valid_dict(self):
        return {
            "scenario_id": "json_baseline",
            "agents": {
                "alice": {
                    "agency": 1.0,
                    "agency_floor": 0.25,
                    "consents": ["notify"],
                    "refusals": [],
                    "revoked_consents": [],
                    "options": [
                        {"id": "stay", "formal": True, "reachable": True, "meaningful": True},
                        {"id": "leave", "formal": True, "reachable": True, "meaningful": True},
                    ],
                },
                "bob": {
                    "agency": 1.0,
                    "agency_floor": 0.25,
                    "consents": [],
                    "refusals": [],
                    "revoked_consents": [],
                    "options": [],
                },
            },
            "world": {"emergency_active": False, "emergency_resolved": False},
            "proposal": {
                "action": "notify",
                "target": "alice",
                "requires_consent": True,
                "authority_basis": ["explicit_consent"],
                "intervention_level": "inform",
                "minimum_sufficient_level": "inform",
                "agency_effects": {},
                "option_reachability_after": {},
                "claims_preserves_choice": False,
                "emergency_override": False,
            },
        }

    def test_scenario_from_dict_builds_typed_scenario(self):
        scenario = scenario_from_dict(self.valid_dict())
        self.assertEqual("json_baseline", scenario.scenario_id)
        self.assertEqual("alice", scenario.proposal.target)
        self.assertIn("notify", scenario.agents["alice"].consents)
        self.assertEqual("leave", scenario.agents["alice"].options[1].option_id)

    def test_invalid_intervention_level_is_rejected(self):
        data = self.valid_dict()
        data["proposal"]["intervention_level"] = "mind_control"
        with self.assertRaises(ScenarioFormatError):
            scenario_from_dict(data)


if __name__ == "__main__":
    unittest.main()
