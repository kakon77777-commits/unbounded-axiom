from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .ledger import LedgerError
from .ledger_io import verify_ledger
from .recommender import RecommendationResult, recommend_with_ledgers
from .recommender_io import RecommendationFormatError, load_recommendation_request
from .world_ledger import WorldLedgerError
from .world_ledger_io import verify_world_ledger


def recommendation_result_to_dict(result: RecommendationResult) -> dict:
    return {
        "recommendation_id": result.recommendation_id,
        "objective_id": result.objective_id,
        "status": result.status,
        "recommended_candidate_ids": list(result.recommended_candidate_ids),
        "candidate_audits": [
            {
                "candidate_id": audit.candidate_id,
                "objective_status": audit.objective_status,
                "governance_allowed": audit.governance_allowed,
                "governance_violations": list(audit.governance_violations),
                "eligible": audit.eligible,
                "impact_key": list(audit.impact_key) if audit.impact_key is not None else None,
                "exclusion_reason": audit.exclusion_reason,
            }
            for audit in result.candidate_audits
        ],
    }


def _print_json(payload: dict, pretty: bool = False) -> None:
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            indent=2 if pretty else None,
            separators=None if pretty else (",", ":"),
        )
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wpce-recommend",
        description="Recommend among explicit finite WPCE MVP-3 intervention candidates.",
    )
    parser.add_argument("request", help="Path to a recommendation request JSON file")
    parser.add_argument("--subject-ledger")
    parser.add_argument("--world-ledger")
    parser.add_argument("--expected-subject-head")
    parser.add_argument("--expected-world-head")
    parser.add_argument("--pretty", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.expected_subject_head and not args.subject_ledger:
            raise RecommendationFormatError("--expected-subject-head requires --subject-ledger")
        if args.expected_world_head and not args.world_ledger:
            raise RecommendationFormatError("--expected-world-head requires --world-ledger")

        request = load_recommendation_request(args.request)
        subject_state = (
            verify_ledger(args.subject_ledger, expected_head_hash=args.expected_subject_head)
            if args.subject_ledger
            else None
        )
        world_state = (
            verify_world_ledger(args.world_ledger, expected_head_hash=args.expected_world_head)
            if args.world_ledger
            else None
        )
        result = recommend_with_ledgers(
            request,
            subject_state=subject_state,
            world_state=world_state,
        )
        _print_json(recommendation_result_to_dict(result), pretty=args.pretty)
        if result.status == "recommended":
            return 0
        if result.status == "no_legal_sufficient_candidate":
            return 3
        if result.status == "multiple_co_minimal":
            return 4
        raise AssertionError(f"unhandled recommendation status {result.status!r}")
    except (RecommendationFormatError, LedgerError, WorldLedgerError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
