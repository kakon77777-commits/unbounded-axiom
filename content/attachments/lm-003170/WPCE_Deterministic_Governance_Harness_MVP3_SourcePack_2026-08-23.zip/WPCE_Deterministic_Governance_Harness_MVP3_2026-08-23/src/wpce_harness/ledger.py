from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from types import MappingProxyType
from typing import Iterable, Mapping


SCHEMA_VERSION = "wpce-ledger-v0.1"
EVENT_TYPES = (
    "identity_registered",
    "will_declared",
    "will_revised",
    "consent_granted",
    "consent_revoked",
    "refusal_recorded",
    "refusal_withdrawn",
)


class LedgerError(ValueError):
    """Raised when a ledger event or transition violates MVP-1 rules."""


@dataclass(frozen=True)
class LedgerEvent:
    schema_version: str
    sequence: int
    subject_id: str
    event_type: str
    payload: Mapping[str, str]
    previous_hash: str | None
    event_hash: str


@dataclass(frozen=True)
class WillRevision:
    sequence: int
    key: str
    old_value: str
    new_value: str


@dataclass(frozen=True)
class LedgerState:
    subject_id: str
    display_name: str
    will: Mapping[str, str]
    will_revisions: tuple[WillRevision, ...]
    consents: frozenset[str]
    revoked_consents: frozenset[str]
    refusals: frozenset[str]
    withdrawn_refusals: frozenset[str]
    event_count: int
    head_hash: str


def _validate_string(value: object, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise LedgerError(f"{where} must be a non-empty string")
    return value


def _payload_copy(payload: Mapping[str, str]) -> dict[str, str]:
    if not isinstance(payload, Mapping):
        raise LedgerError("payload must be an object")
    result: dict[str, str] = {}
    for key in sorted(payload):
        _validate_string(key, "payload key")
        result[key] = _validate_string(payload[key], f"payload.{key}")
    return result


def _hash_material(
    *,
    schema_version: str,
    sequence: int,
    subject_id: str,
    event_type: str,
    payload: Mapping[str, str],
    previous_hash: str | None,
) -> bytes:
    body = {
        "schema_version": schema_version,
        "sequence": sequence,
        "subject_id": subject_id,
        "event_type": event_type,
        "payload": dict(payload),
        "previous_hash": previous_hash,
    }
    return json.dumps(
        body,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def compute_event_hash(
    *,
    schema_version: str,
    sequence: int,
    subject_id: str,
    event_type: str,
    payload: Mapping[str, str],
    previous_hash: str | None,
) -> str:
    return hashlib.sha256(
        _hash_material(
            schema_version=schema_version,
            sequence=sequence,
            subject_id=subject_id,
            event_type=event_type,
            payload=payload,
            previous_hash=previous_hash,
        )
    ).hexdigest()


def make_event(
    sequence: int,
    subject_id: str,
    event_type: str,
    payload: Mapping[str, str],
    previous_hash: str | None,
) -> LedgerEvent:
    if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
        raise LedgerError("sequence must be a non-negative integer")
    subject_id = _validate_string(subject_id, "subject_id")
    if event_type not in EVENT_TYPES:
        raise LedgerError(f"unsupported event_type {event_type!r}")
    parsed_payload = _payload_copy(payload)
    if previous_hash is not None:
        _validate_string(previous_hash, "previous_hash")
    event_hash = compute_event_hash(
        schema_version=SCHEMA_VERSION,
        sequence=sequence,
        subject_id=subject_id,
        event_type=event_type,
        payload=parsed_payload,
        previous_hash=previous_hash,
    )
    return LedgerEvent(
        schema_version=SCHEMA_VERSION,
        sequence=sequence,
        subject_id=subject_id,
        event_type=event_type,
        payload=MappingProxyType(parsed_payload),
        previous_hash=previous_hash,
        event_hash=event_hash,
    )


def verify_events(events: Iterable[LedgerEvent], expected_head_hash: str | None = None) -> str:
    sequence = list(events)
    if not sequence:
        raise LedgerError("ledger must contain at least one event")
    previous_hash: str | None = None
    subject_id: str | None = None
    for index, event in enumerate(sequence):
        if event.schema_version != SCHEMA_VERSION:
            raise LedgerError(f"event {index} schema_version mismatch")
        if event.sequence != index:
            raise LedgerError(f"event {index} sequence mismatch")
        if subject_id is None:
            subject_id = event.subject_id
        elif event.subject_id != subject_id:
            raise LedgerError(f"event {index} subject_id mismatch")
        if event.previous_hash != previous_hash:
            raise LedgerError(f"event {index} previous_hash mismatch")
        expected = compute_event_hash(
            schema_version=event.schema_version,
            sequence=event.sequence,
            subject_id=event.subject_id,
            event_type=event.event_type,
            payload=event.payload,
            previous_hash=event.previous_hash,
        )
        if event.event_hash != expected:
            raise LedgerError(f"event {index} event_hash mismatch")
        previous_hash = event.event_hash
    assert previous_hash is not None
    if expected_head_hash is not None and previous_hash != expected_head_hash:
        raise LedgerError("expected head hash mismatch")
    return previous_hash


def _require_payload(event: LedgerEvent, keys: set[str]) -> None:
    actual = set(event.payload)
    if actual != keys:
        expected = ", ".join(sorted(keys))
        raise LedgerError(f"{event.event_type} payload must contain exactly: {expected}")


def replay_events(events: Iterable[LedgerEvent]) -> LedgerState:
    sequence = list(events)
    head_hash = verify_events(sequence)
    first = sequence[0]
    if first.event_type != "identity_registered":
        raise LedgerError("first event must be identity_registered")
    _require_payload(first, {"display_name"})

    will: dict[str, str] = {}
    revisions: list[WillRevision] = []
    consents: set[str] = set()
    revoked_consents: set[str] = set()
    refusals: set[str] = set()
    withdrawn_refusals: set[str] = set()

    for event in sequence[1:]:
        if event.event_type == "identity_registered":
            raise LedgerError("identity_registered may appear only once")

        if event.event_type == "will_declared":
            _require_payload(event, {"key", "value"})
            key = event.payload["key"]
            if key in will:
                raise LedgerError(f"will key {key!r} already exists; use will_revised")
            will[key] = event.payload["value"]
            continue

        if event.event_type == "will_revised":
            _require_payload(event, {"key", "value"})
            key = event.payload["key"]
            if key not in will:
                raise LedgerError(f"cannot revise unknown will key {key!r}")
            old_value = will[key]
            new_value = event.payload["value"]
            will[key] = new_value
            revisions.append(
                WillRevision(
                    sequence=event.sequence,
                    key=key,
                    old_value=old_value,
                    new_value=new_value,
                )
            )
            continue

        if event.event_type == "consent_granted":
            _require_payload(event, {"action"})
            action = event.payload["action"]
            if action in consents:
                raise LedgerError(f"consent already active for action {action!r}")
            consents.add(action)
            revoked_consents.discard(action)
            continue

        if event.event_type == "consent_revoked":
            _require_payload(event, {"action"})
            action = event.payload["action"]
            if action not in consents:
                raise LedgerError(f"cannot revoke inactive consent for action {action!r}")
            consents.remove(action)
            revoked_consents.add(action)
            continue

        if event.event_type == "refusal_recorded":
            _require_payload(event, {"action"})
            action = event.payload["action"]
            if action in refusals:
                raise LedgerError(f"refusal already active for action {action!r}")
            refusals.add(action)
            withdrawn_refusals.discard(action)
            continue

        if event.event_type == "refusal_withdrawn":
            _require_payload(event, {"action"})
            action = event.payload["action"]
            if action not in refusals:
                raise LedgerError(f"cannot withdraw inactive refusal for action {action!r}")
            refusals.remove(action)
            withdrawn_refusals.add(action)
            continue

        raise LedgerError(f"unsupported event_type {event.event_type!r}")

    return LedgerState(
        subject_id=first.subject_id,
        display_name=first.payload["display_name"],
        will=MappingProxyType(dict(sorted(will.items()))),
        will_revisions=tuple(revisions),
        consents=frozenset(consents),
        revoked_consents=frozenset(revoked_consents),
        refusals=frozenset(refusals),
        withdrawn_refusals=frozenset(withdrawn_refusals),
        event_count=len(sequence),
        head_hash=head_hash,
    )

