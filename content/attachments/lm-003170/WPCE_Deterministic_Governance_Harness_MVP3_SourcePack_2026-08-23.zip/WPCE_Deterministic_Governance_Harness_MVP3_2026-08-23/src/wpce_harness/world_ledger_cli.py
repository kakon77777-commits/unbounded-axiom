from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .world_ledger import WorldLedgerError, WorldLedgerState
from .world_ledger_io import append_world_ledger_event, init_world_ledger, verify_world_ledger


def state_to_dict(state: WorldLedgerState) -> dict:
    return {
        "world_id": state.world_id,
        "display_name": state.display_name,
        "subjects": {
            subject_id: {
                "agency": subject.agency,
                "agency_floor": subject.agency_floor,
                "options": {
                    option_id: {
                        "formal": option.formal,
                        "reachable": option.reachable,
                        "meaningful": option.meaningful,
                    }
                    for option_id, option in sorted(subject.options.items())
                },
            }
            for subject_id, subject in sorted(state.subjects.items())
        },
        "conflicts": {
            conflict_id: {
                "left_subject": conflict.left_subject,
                "right_subject": conflict.right_subject,
                "conflict_type": conflict.conflict_type,
            }
            for conflict_id, conflict in sorted(state.conflicts.items())
        },
        "resolved_conflicts": sorted(state.resolved_conflicts),
        "noop_available": state.noop_available,
        "defer_available": state.defer_available,
        "event_count": state.event_count,
        "head_hash": state.head_hash,
    }


def _print_json(payload: dict, pretty: bool = False) -> None:
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2 if pretty else None, separators=None if pretty else (",", ":")))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="wpce-world-ledger", description="Manage deterministic WPCE MVP-2 world option/reachability history.")
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init")
    init.add_argument("ledger")
    init.add_argument("--world", required=True)
    init.add_argument("--name", required=True)

    join = sub.add_parser("join")
    join.add_argument("ledger")
    join.add_argument("subject_id")
    join.add_argument("--agency", required=True)
    join.add_argument("--floor", required=True)

    option = sub.add_parser("option")
    option.add_argument("ledger")
    option.add_argument("subject_id")
    option.add_argument("option_id")
    option.add_argument("--formal", required=True)
    option.add_argument("--reachable", required=True)
    option.add_argument("--meaningful", required=True)

    set_reachable = sub.add_parser("set-reachable")
    set_reachable.add_argument("ledger")
    set_reachable.add_argument("subject_id")
    set_reachable.add_argument("option_id")
    set_reachable.add_argument("value")

    set_meaningful = sub.add_parser("set-meaningful")
    set_meaningful.add_argument("ledger")
    set_meaningful.add_argument("subject_id")
    set_meaningful.add_argument("option_id")
    set_meaningful.add_argument("value")

    set_agency = sub.add_parser("set-agency")
    set_agency.add_argument("ledger")
    set_agency.add_argument("subject_id")
    set_agency.add_argument("value")

    conflict = sub.add_parser("conflict")
    conflict.add_argument("ledger")
    conflict.add_argument("conflict_id")
    conflict.add_argument("left_subject")
    conflict.add_argument("right_subject")
    conflict.add_argument("conflict_type")

    resolve = sub.add_parser("resolve-conflict")
    resolve.add_argument("ledger")
    resolve.add_argument("conflict_id")

    set_noop = sub.add_parser("set-noop")
    set_noop.add_argument("ledger")
    set_noop.add_argument("value")

    set_defer = sub.add_parser("set-defer")
    set_defer.add_argument("ledger")
    set_defer.add_argument("value")

    verify = sub.add_parser("verify")
    verify.add_argument("ledger")
    verify.add_argument("--expected-head")

    show = sub.add_parser("show")
    show.add_argument("ledger")
    show.add_argument("--pretty", action="store_true")

    head = sub.add_parser("head")
    head.add_argument("ledger")
    return parser


def _append(args: argparse.Namespace, event_type: str, payload: dict[str, str]) -> WorldLedgerState:
    return append_world_ledger_event(args.ledger, event_type, payload)


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            state = init_world_ledger(args.ledger, args.world, args.name)
        elif args.command == "join":
            state = _append(args, "subject_joined", {"subject_id": args.subject_id, "agency": args.agency, "agency_floor": args.floor})
        elif args.command == "option":
            state = _append(args, "option_declared", {"subject_id": args.subject_id, "option_id": args.option_id, "formal": args.formal, "reachable": args.reachable, "meaningful": args.meaningful})
        elif args.command == "set-reachable":
            state = _append(args, "option_reachability_set", {"subject_id": args.subject_id, "option_id": args.option_id, "reachable": args.value})
        elif args.command == "set-meaningful":
            state = _append(args, "option_meaningfulness_set", {"subject_id": args.subject_id, "option_id": args.option_id, "meaningful": args.value})
        elif args.command == "set-agency":
            state = _append(args, "agency_set", {"subject_id": args.subject_id, "agency": args.value})
        elif args.command == "conflict":
            state = _append(args, "conflict_declared", {"conflict_id": args.conflict_id, "left_subject": args.left_subject, "right_subject": args.right_subject, "conflict_type": args.conflict_type})
        elif args.command == "resolve-conflict":
            state = _append(args, "conflict_resolved", {"conflict_id": args.conflict_id})
        elif args.command == "set-noop":
            state = _append(args, "noop_set", {"available": args.value})
        elif args.command == "set-defer":
            state = _append(args, "defer_set", {"available": args.value})
        elif args.command == "verify":
            state = verify_world_ledger(args.ledger, expected_head_hash=args.expected_head)
            _print_json({"valid": True, "event_count": state.event_count, "head_hash": state.head_hash})
            return 0
        elif args.command == "show":
            state = verify_world_ledger(args.ledger)
            _print_json(state_to_dict(state), pretty=args.pretty)
            return 0
        elif args.command == "head":
            print(verify_world_ledger(args.ledger).head_hash)
            return 0
        else:
            raise AssertionError(f"unhandled command {args.command!r}")
        _print_json(state_to_dict(state))
        return 0
    except WorldLedgerError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
