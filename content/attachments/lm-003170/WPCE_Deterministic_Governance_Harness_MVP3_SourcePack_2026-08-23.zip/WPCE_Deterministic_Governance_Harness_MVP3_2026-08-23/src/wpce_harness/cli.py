from __future__ import annotations

import argparse
import json
from typing import Sequence

from .engine import evaluate
from .models import Evaluation
from .scenario_io import load_scenario


def evaluation_to_dict(result: Evaluation) -> dict:
    return {
        "scenario_id": result.scenario_id,
        "allowed": result.allowed,
        "violations": list(result.violations),
        "checks": [
            {"code": check.code, "passed": check.passed, "detail": check.detail}
            for check in result.checks
        ],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wpce-harness",
        description="Evaluate one deterministic WPCE MVP-0 governance scenario.",
    )
    parser.add_argument("scenario", help="Path to a scenario JSON file")
    parser.add_argument("--pretty", action="store_true", help="Pretty-print audit JSON")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    result = evaluate(load_scenario(args.scenario))
    payload = evaluation_to_dict(result)
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            indent=2 if args.pretty else None,
            separators=None if args.pretty else (",", ":"),
        )
    )
    return 0 if result.allowed else 2
