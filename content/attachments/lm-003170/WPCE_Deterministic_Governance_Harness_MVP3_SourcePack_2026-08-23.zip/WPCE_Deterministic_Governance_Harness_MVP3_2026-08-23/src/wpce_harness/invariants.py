from __future__ import annotations

from .models import CheckResult, Scenario



INTERVENTION_LEVELS = (
    "observe",
    "inform",
    "explain",
    "scaffold",
    "offer",
    "coordinate",
    "constrain",
    "emergency_override",
    "root_rewrite",
)
LEVEL_RANK = {name: rank for rank, name in enumerate(INTERVENTION_LEVELS)}

CHECK_CODES = (
    "PREDICTION_NOT_PERMISSION",
    "REFUSAL_EFFECTIVE",
    "REVOCATION_EFFECTIVE",
    "SUBSTANTIVE_OPTIONS_REQUIRED",
    "MUTUAL_NON_ERASURE",
    "LEAST_SUFFICIENT_INTERVENTION",
    "AUTHORITY_RETURN_AFTER_EMERGENCY",
    "CONFLICT_EXIT_CHANNEL_REQUIRED",
)


def _pass(code: str, detail: str = "passed") -> CheckResult:
    return CheckResult(code=code, passed=True, detail=detail)


def _fail(code: str, detail: str) -> CheckResult:
    return CheckResult(code=code, passed=False, detail=detail)


def _valid_emergency_override(scenario: Scenario) -> bool:
    p = scenario.proposal
    return (
        p.emergency_override
        and "emergency" in p.authority_basis
        and scenario.world.emergency_active
        and not scenario.world.emergency_resolved
    )


def check_prediction_not_permission(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    target = scenario.agents[p.target]
    if p.requires_consent and p.action not in target.consents and not _valid_emergency_override(scenario):
        basis = "prediction" if "prediction" in p.authority_basis else "no active consent"
        return _fail(
            CHECK_CODES[0],
            f"{basis} cannot authorize consent-required action {p.action!r}",
        )
    return _pass(CHECK_CODES[0])


def check_refusal_effective(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    target = scenario.agents[p.target]
    if p.action in target.refusals and not _valid_emergency_override(scenario):
        return _fail(
            CHECK_CODES[1],
            f"target {p.target!r} explicitly refused action {p.action!r}",
        )
    return _pass(CHECK_CODES[1])


def check_revocation_effective(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    target = scenario.agents[p.target]
    if p.requires_consent and p.action in target.revoked_consents and not _valid_emergency_override(scenario):
        return _fail(
            CHECK_CODES[2],
            f"consent for action {p.action!r} was revoked by target {p.target!r}",
        )
    return _pass(CHECK_CODES[2])


def check_substantive_options_required(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    if not p.claims_preserves_choice:
        return _pass(CHECK_CODES[3])

    target = scenario.agents[p.target]
    effects = p.option_reachability_after.get(p.target, {})
    before = 0
    after = 0
    for option in sorted(target.options, key=lambda item: item.option_id):
        if not (option.formal and option.meaningful):
            continue
        if option.reachable:
            before += 1
        reachable_after = effects.get(option.option_id, option.reachable)
        if reachable_after:
            after += 1

    if before >= 2 and after < 2:
        return _fail(
            CHECK_CODES[3],
            f"proposal claims to preserve choice but meaningful reachable options collapse from {before} to {after}",
        )
    return _pass(CHECK_CODES[3], f"meaningful reachable options before={before}, after={after}")


def check_mutual_non_erasure(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    for agent_id in sorted(p.agency_effects):
        agent = scenario.agents[agent_id]
        after = agent.agency + p.agency_effects[agent_id]
        if after < agent.agency_floor:
            return _fail(
                CHECK_CODES[4],
                f"agent {agent_id!r} agency would fall to {after:.3f}, below floor {agent.agency_floor:.3f}",
            )
    return _pass(CHECK_CODES[4])


def check_least_sufficient_intervention(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    current_rank = LEVEL_RANK[p.intervention_level]
    sufficient_rank = LEVEL_RANK[p.minimum_sufficient_level]
    if current_rank > sufficient_rank:
        return _fail(
            CHECK_CODES[5],
            f"intervention level {p.intervention_level!r} exceeds declared sufficient level {p.minimum_sufficient_level!r}",
        )
    return _pass(CHECK_CODES[5])


def check_authority_return_after_emergency(scenario: Scenario) -> CheckResult:
    p = scenario.proposal
    uses_emergency_authority = p.emergency_override or "emergency" in p.authority_basis
    if uses_emergency_authority and scenario.world.emergency_resolved:
        return _fail(
            CHECK_CODES[6],
            "emergency authority cannot continue after the emergency is resolved",
        )
    if uses_emergency_authority and not scenario.world.emergency_active:
        return _fail(
            CHECK_CODES[6],
            "emergency authority requires a currently active emergency",
        )
    return _pass(CHECK_CODES[6])


def check_conflict_exit_channel_required(scenario: Scenario) -> CheckResult:
    if not scenario.proposal.claims_preserves_choice:
        return _pass(CHECK_CODES[7])
    if scenario.world.active_conflicts and not scenario.world.noop_available and not scenario.world.defer_available:
        return _fail(
            CHECK_CODES[7],
            "proposal claims to preserve choice during unresolved conflict but both NOOP and Defer are unavailable",
        )
    return _pass(CHECK_CODES[7])


CHECKS = (
    check_prediction_not_permission,
    check_refusal_effective,
    check_revocation_effective,
    check_substantive_options_required,
    check_mutual_non_erasure,
    check_least_sufficient_intervention,
    check_authority_return_after_emergency,
    check_conflict_exit_channel_required,
)
