from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from .recommender import OBJECTIVE_STATUSES, InterventionCandidate, RecommendationRequest
from .scenario_io import ScenarioFormatError, scenario_from_dict


class RecommendationFormatError(ValueError):
    """Raised when a recommendation request does not satisfy the MVP-3 schema."""


def _mapping(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise RecommendationFormatError(f"{where} must be an object")
    return value


def _string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise RecommendationFormatError(f"{where} must be a non-empty string")
    return value


def _bool(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise RecommendationFormatError(f"{where} must be a boolean")
    return value


def recommendation_request_from_dict(data: Mapping[str, Any]) -> RecommendationRequest:
    root = _mapping(data, "recommendation request")
    recommendation_id = _string(root.get("recommendation_id"), "recommendation_id")
    objective_id = _string(root.get("objective_id"), "objective_id")
    raw_candidates = root.get("candidates")
    if not isinstance(raw_candidates, list):
        raise RecommendationFormatError("candidates must be a list")
    if not raw_candidates:
        raise RecommendationFormatError("candidates must contain at least one candidate")

    candidates: list[InterventionCandidate] = []
    seen: set[str] = set()
    for index, raw_candidate in enumerate(raw_candidates):
        candidate = _mapping(raw_candidate, f"candidates[{index}]")
        candidate_id = _string(candidate.get("candidate_id"), f"candidates[{index}].candidate_id")
        if candidate_id in seen:
            raise RecommendationFormatError(f"duplicate candidate id {candidate_id!r}")
        seen.add(candidate_id)

        objective_status = _string(
            candidate.get("objective_status"), f"candidates[{index}].objective_status"
        )
        if objective_status not in OBJECTIVE_STATUSES:
            raise RecommendationFormatError(
                f"candidates[{index}].objective_status must be one of {', '.join(OBJECTIVE_STATUSES)}"
            )
        irreversible = _bool(candidate.get("irreversible"), f"candidates[{index}].irreversible")
        raw_scenario = _mapping(candidate.get("scenario"), f"candidates[{index}].scenario")
        try:
            scenario = scenario_from_dict(raw_scenario)
        except ScenarioFormatError as exc:
            raise RecommendationFormatError(f"candidates[{index}].scenario: {exc}") from exc
        candidates.append(
            InterventionCandidate(
                candidate_id=candidate_id,
                objective_status=objective_status,
                irreversible=irreversible,
                scenario=scenario,
            )
        )

    return RecommendationRequest(
        recommendation_id=recommendation_id,
        objective_id=objective_id,
        candidates=tuple(candidates),
    )


def load_recommendation_request(path: str | Path) -> RecommendationRequest:
    file_path = Path(path)
    try:
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RecommendationFormatError(f"cannot load recommendation request {file_path}: {exc}") from exc
    if not isinstance(data, Mapping):
        raise RecommendationFormatError("recommendation request root must be an object")
    return recommendation_request_from_dict(data)
