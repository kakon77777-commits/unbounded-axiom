from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping


@dataclass(frozen=True)
class OptionState:
    option_id: str
    formal: bool
    reachable: bool
    meaningful: bool


@dataclass(frozen=True)
class AgentState:
    agent_id: str
    agency: float
    agency_floor: float
    consents: frozenset[str]
    refusals: frozenset[str]
    revoked_consents: frozenset[str]
    options: tuple[OptionState, ...]


@dataclass(frozen=True)
class WorldState:
    emergency_active: bool
    emergency_resolved: bool
    noop_available: bool = True
    defer_available: bool = True
    active_conflicts: tuple[str, ...] = ()


@dataclass(frozen=True)
class InterventionProposal:
    action: str
    target: str
    requires_consent: bool
    authority_basis: frozenset[str]
    intervention_level: str
    minimum_sufficient_level: str
    agency_effects: Mapping[str, float]
    option_reachability_after: Mapping[str, Mapping[str, bool]]
    claims_preserves_choice: bool
    emergency_override: bool


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    agents: Mapping[str, AgentState]
    world: WorldState
    proposal: InterventionProposal


@dataclass(frozen=True)
class CheckResult:
    code: str
    passed: bool
    detail: str


@dataclass(frozen=True)
class Evaluation:
    scenario_id: str
    allowed: bool
    violations: list[str]
    checks: list[CheckResult]
