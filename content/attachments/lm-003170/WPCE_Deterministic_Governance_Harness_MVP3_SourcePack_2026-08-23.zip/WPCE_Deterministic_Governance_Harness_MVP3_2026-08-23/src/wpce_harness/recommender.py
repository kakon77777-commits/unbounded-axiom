from __future__ import annotations

from dataclasses import dataclass, replace

from .engine import evaluate
from .invariants import LEVEL_RANK
from .ledger import LedgerState
from .ledger_integration import scenario_with_ledger_state
from .models import Evaluation, Scenario
from .world_integration import scenario_with_world_ledger_state
from .world_ledger import WorldLedgerState


OBJECTIVE_STATUSES = ("satisfied", "not_satisfied", "unknown")


@dataclass(frozen=True)
class InterventionCandidate:
    candidate_id: str
    objective_status: str
    irreversible: bool
    scenario: Scenario


@dataclass(frozen=True)
class RecommendationRequest:
    recommendation_id: str
    objective_id: str
    candidates: tuple[InterventionCandidate, ...]


@dataclass(frozen=True)
class CandidateAudit:
    candidate_id: str
    objective_status: str
    governance_allowed: bool
    governance_violations: tuple[str, ...]
    eligible: bool
    impact_key: tuple[int, int, float, int] | None
    exclusion_reason: str | None


@dataclass(frozen=True)
class RecommendationResult:
    recommendation_id: str
    objective_id: str
    status: str
    recommended_candidate_ids: tuple[str, ...]
    candidate_audits: tuple[CandidateAudit, ...]


def _impact_key(candidate: InterventionCandidate) -> tuple[int, int, float, int]:
    proposal = candidate.scenario.proposal
    agency_loss = sum(-delta for delta in proposal.agency_effects.values() if delta < 0)
    option_closures = sum(
        1
        for per_subject in proposal.option_reachability_after.values()
        for reachable in per_subject.values()
        if reachable is False
    )
    return (
        LEVEL_RANK[proposal.intervention_level],
        1 if candidate.irreversible else 0,
        round(agency_loss, 12),
        option_closures,
    )


def _audit_candidate(candidate: InterventionCandidate, evaluation: Evaluation) -> CandidateAudit:
    if candidate.objective_status != "satisfied":
        return CandidateAudit(
            candidate_id=candidate.candidate_id,
            objective_status=candidate.objective_status,
            governance_allowed=evaluation.allowed,
            governance_violations=tuple(evaluation.violations),
            eligible=False,
            impact_key=None,
            exclusion_reason=f"objective_status={candidate.objective_status}",
        )
    if not evaluation.allowed:
        return CandidateAudit(
            candidate_id=candidate.candidate_id,
            objective_status=candidate.objective_status,
            governance_allowed=False,
            governance_violations=tuple(evaluation.violations),
            eligible=False,
            impact_key=None,
            exclusion_reason="governance_blocked",
        )
    return CandidateAudit(
        candidate_id=candidate.candidate_id,
        objective_status=candidate.objective_status,
        governance_allowed=True,
        governance_violations=(),
        eligible=True,
        impact_key=_impact_key(candidate),
        exclusion_reason=None,
    )


def recommend(request: RecommendationRequest) -> RecommendationResult:
    audits = tuple(
        sorted(
            (_audit_candidate(candidate, evaluate(candidate.scenario)) for candidate in request.candidates),
            key=lambda audit: audit.candidate_id,
        )
    )
    eligible = [audit for audit in audits if audit.eligible]
    if not eligible:
        return RecommendationResult(
            recommendation_id=request.recommendation_id,
            objective_id=request.objective_id,
            status="no_legal_sufficient_candidate",
            recommended_candidate_ids=(),
            candidate_audits=audits,
        )

    minimum = min(audit.impact_key for audit in eligible if audit.impact_key is not None)
    recommended = tuple(
        audit.candidate_id
        for audit in eligible
        if audit.impact_key == minimum
    )
    status = "recommended" if len(recommended) == 1 else "multiple_co_minimal"
    return RecommendationResult(
        recommendation_id=request.recommendation_id,
        objective_id=request.objective_id,
        status=status,
        recommended_candidate_ids=recommended,
        candidate_audits=audits,
    )


def recommend_with_ledgers(
    request: RecommendationRequest,
    *,
    subject_state: LedgerState | None = None,
    world_state: WorldLedgerState | None = None,
) -> RecommendationResult:
    candidates: list[InterventionCandidate] = []
    for candidate in request.candidates:
        scenario = candidate.scenario
        if subject_state is not None:
            scenario = scenario_with_ledger_state(scenario, subject_state)
        if world_state is not None:
            scenario = scenario_with_world_ledger_state(scenario, world_state)
        candidates.append(replace(candidate, scenario=scenario))
    return recommend(replace(request, candidates=tuple(candidates)))
