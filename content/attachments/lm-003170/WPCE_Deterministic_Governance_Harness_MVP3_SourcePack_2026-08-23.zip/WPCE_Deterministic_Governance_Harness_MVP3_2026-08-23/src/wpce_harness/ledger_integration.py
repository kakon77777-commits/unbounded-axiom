from __future__ import annotations

from dataclasses import replace

from .engine import evaluate
from .ledger import LedgerError, LedgerState
from .models import Evaluation, Scenario


def scenario_with_ledger_state(scenario: Scenario, state: LedgerState) -> Scenario:
    target_id = scenario.proposal.target
    if state.subject_id != target_id:
        raise LedgerError(
            f"ledger subject {state.subject_id!r} does not match proposal target {target_id!r}"
        )
    target = scenario.agents[target_id]
    updated_target = replace(
        target,
        consents=state.consents,
        refusals=state.refusals,
        revoked_consents=state.revoked_consents,
    )
    agents = dict(scenario.agents)
    agents[target_id] = updated_target
    return replace(scenario, agents=agents)


def evaluate_with_ledger(scenario: Scenario, state: LedgerState) -> Evaluation:
    return evaluate(scenario_with_ledger_state(scenario, state))
