from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from .invariants import INTERVENTION_LEVELS
from .models import AgentState, InterventionProposal, OptionState, Scenario, WorldState


class ScenarioFormatError(ValueError):
    """Raised when a scenario cannot be represented by the MVP-0 schema."""


def _mapping(value: Any, where: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ScenarioFormatError(f"{where} must be an object")
    return value


def _string(value: Any, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise ScenarioFormatError(f"{where} must be a non-empty string")
    return value


def _bool(value: Any, where: str) -> bool:
    if not isinstance(value, bool):
        raise ScenarioFormatError(f"{where} must be a boolean")
    return value


def _number(value: Any, where: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ScenarioFormatError(f"{where} must be a number")
    return float(value)


def _string_set(value: Any, where: str) -> frozenset[str]:
    if not isinstance(value, list) or any(not isinstance(item, str) or not item for item in value):
        raise ScenarioFormatError(f"{where} must be a list of non-empty strings")
    return frozenset(value)


def scenario_from_dict(data: Mapping[str, Any]) -> Scenario:
    root = _mapping(data, "scenario")
    scenario_id = _string(root.get("scenario_id"), "scenario_id")

    raw_agents = _mapping(root.get("agents"), "agents")
    agents: dict[str, AgentState] = {}
    for agent_id in sorted(raw_agents):
        _string(agent_id, "agents key")
        raw = _mapping(raw_agents[agent_id], f"agents.{agent_id}")
        raw_options = raw.get("options")
        if not isinstance(raw_options, list):
            raise ScenarioFormatError(f"agents.{agent_id}.options must be a list")
        options: list[OptionState] = []
        seen_options: set[str] = set()
        for index, raw_option in enumerate(raw_options):
            option = _mapping(raw_option, f"agents.{agent_id}.options[{index}]")
            option_id = _string(option.get("id"), f"agents.{agent_id}.options[{index}].id")
            if option_id in seen_options:
                raise ScenarioFormatError(f"duplicate option id {option_id!r} for agent {agent_id!r}")
            seen_options.add(option_id)
            options.append(
                OptionState(
                    option_id=option_id,
                    formal=_bool(option.get("formal"), f"agents.{agent_id}.options[{index}].formal"),
                    reachable=_bool(option.get("reachable"), f"agents.{agent_id}.options[{index}].reachable"),
                    meaningful=_bool(option.get("meaningful"), f"agents.{agent_id}.options[{index}].meaningful"),
                )
            )

        agency = _number(raw.get("agency"), f"agents.{agent_id}.agency")
        agency_floor = _number(raw.get("agency_floor"), f"agents.{agent_id}.agency_floor")
        agents[agent_id] = AgentState(
            agent_id=agent_id,
            agency=agency,
            agency_floor=agency_floor,
            consents=_string_set(raw.get("consents"), f"agents.{agent_id}.consents"),
            refusals=_string_set(raw.get("refusals"), f"agents.{agent_id}.refusals"),
            revoked_consents=_string_set(raw.get("revoked_consents"), f"agents.{agent_id}.revoked_consents"),
            options=tuple(options),
        )

    if not agents:
        raise ScenarioFormatError("agents must contain at least one agent")

    raw_world = _mapping(root.get("world"), "world")
    world = WorldState(
        emergency_active=_bool(raw_world.get("emergency_active"), "world.emergency_active"),
        emergency_resolved=_bool(raw_world.get("emergency_resolved"), "world.emergency_resolved"),
    )
    if world.emergency_active and world.emergency_resolved:
        raise ScenarioFormatError("world emergency cannot be both active and resolved")

    raw_p = _mapping(root.get("proposal"), "proposal")
    target = _string(raw_p.get("target"), "proposal.target")
    if target not in agents:
        raise ScenarioFormatError(f"proposal.target {target!r} is not a declared agent")

    intervention_level = _string(raw_p.get("intervention_level"), "proposal.intervention_level")
    minimum_sufficient_level = _string(
        raw_p.get("minimum_sufficient_level"), "proposal.minimum_sufficient_level"
    )
    if intervention_level not in INTERVENTION_LEVELS:
        raise ScenarioFormatError(
            f"proposal.intervention_level must be one of {', '.join(INTERVENTION_LEVELS)}"
        )
    if minimum_sufficient_level not in INTERVENTION_LEVELS:
        raise ScenarioFormatError(
            f"proposal.minimum_sufficient_level must be one of {', '.join(INTERVENTION_LEVELS)}"
        )

    raw_agency_effects = _mapping(raw_p.get("agency_effects"), "proposal.agency_effects")
    agency_effects: dict[str, float] = {}
    for agent_id in sorted(raw_agency_effects):
        if agent_id not in agents:
            raise ScenarioFormatError(f"proposal.agency_effects references unknown agent {agent_id!r}")
        agency_effects[agent_id] = _number(
            raw_agency_effects[agent_id], f"proposal.agency_effects.{agent_id}"
        )

    raw_option_effects = _mapping(
        raw_p.get("option_reachability_after"), "proposal.option_reachability_after"
    )
    option_reachability_after: dict[str, dict[str, bool]] = {}
    for agent_id in sorted(raw_option_effects):
        if agent_id not in agents:
            raise ScenarioFormatError(
                f"proposal.option_reachability_after references unknown agent {agent_id!r}"
            )
        effects = _mapping(
            raw_option_effects[agent_id], f"proposal.option_reachability_after.{agent_id}"
        )
        known_options = {option.option_id for option in agents[agent_id].options}
        parsed: dict[str, bool] = {}
        for option_id in sorted(effects):
            if option_id not in known_options:
                raise ScenarioFormatError(
                    f"proposal.option_reachability_after.{agent_id} references unknown option {option_id!r}"
                )
            parsed[option_id] = _bool(
                effects[option_id], f"proposal.option_reachability_after.{agent_id}.{option_id}"
            )
        option_reachability_after[agent_id] = parsed

    proposal = InterventionProposal(
        action=_string(raw_p.get("action"), "proposal.action"),
        target=target,
        requires_consent=_bool(raw_p.get("requires_consent"), "proposal.requires_consent"),
        authority_basis=_string_set(raw_p.get("authority_basis"), "proposal.authority_basis"),
        intervention_level=intervention_level,
        minimum_sufficient_level=minimum_sufficient_level,
        agency_effects=agency_effects,
        option_reachability_after=option_reachability_after,
        claims_preserves_choice=_bool(
            raw_p.get("claims_preserves_choice"), "proposal.claims_preserves_choice"
        ),
        emergency_override=_bool(raw_p.get("emergency_override"), "proposal.emergency_override"),
    )
    return Scenario(scenario_id=scenario_id, agents=agents, world=world, proposal=proposal)


def load_scenario(path: str | Path) -> Scenario:
    file_path = Path(path)
    try:
        data = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ScenarioFormatError(f"cannot load scenario {file_path}: {exc}") from exc
    return scenario_from_dict(data)
