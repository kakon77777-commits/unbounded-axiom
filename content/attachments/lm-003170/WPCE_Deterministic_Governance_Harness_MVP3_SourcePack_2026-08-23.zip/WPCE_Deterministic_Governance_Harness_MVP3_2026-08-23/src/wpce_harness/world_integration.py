from __future__ import annotations

from dataclasses import replace

from .engine import evaluate
from .ledger import LedgerState
from .ledger_integration import scenario_with_ledger_state
from .models import Evaluation, OptionState, Scenario
from .world_ledger import WorldLedgerError, WorldLedgerState


def scenario_with_world_ledger_state(scenario: Scenario, state: WorldLedgerState) -> Scenario:
    affected = {scenario.proposal.target}
    affected.update(scenario.proposal.agency_effects)
    affected.update(scenario.proposal.option_reachability_after)
    missing = sorted(subject_id for subject_id in affected if subject_id not in state.subjects)
    if missing:
        raise WorldLedgerError(f"world ledger missing affected subject(s): {', '.join(missing)}")

    agents = dict(scenario.agents)
    for subject_id, world_subject in state.subjects.items():
        if subject_id not in agents:
            continue
        current = agents[subject_id]
        options = tuple(
            OptionState(
                option_id=option.option_id,
                formal=option.formal,
                reachable=option.reachable,
                meaningful=option.meaningful,
            )
            for _, option in sorted(world_subject.options.items())
        )
        agents[subject_id] = replace(
            current,
            agency=world_subject.agency,
            agency_floor=world_subject.agency_floor,
            options=options,
        )

    world = replace(
        scenario.world,
        noop_available=state.noop_available,
        defer_available=state.defer_available,
        active_conflicts=tuple(sorted(state.conflicts)),
    )
    return replace(scenario, agents=agents, world=world)


def evaluate_with_world_ledger(scenario: Scenario, state: WorldLedgerState) -> Evaluation:
    return evaluate(scenario_with_world_ledger_state(scenario, state))


def evaluate_with_ledgers(
    scenario: Scenario,
    subject_state: LedgerState,
    world_state: WorldLedgerState,
) -> Evaluation:
    with_subject = scenario_with_ledger_state(scenario, subject_state)
    with_world = scenario_with_world_ledger_state(with_subject, world_state)
    return evaluate(with_world)
