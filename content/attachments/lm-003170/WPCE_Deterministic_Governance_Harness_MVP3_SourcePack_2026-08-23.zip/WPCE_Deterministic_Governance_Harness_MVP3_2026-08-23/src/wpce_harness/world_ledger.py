from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
from types import MappingProxyType
from typing import Iterable, Mapping


WORLD_SCHEMA_VERSION = "wpce-world-ledger-v0.1"
WORLD_EVENT_TYPES = (
    "world_registered",
    "subject_joined",
    "option_declared",
    "option_reachability_set",
    "option_meaningfulness_set",
    "agency_set",
    "conflict_declared",
    "conflict_resolved",
    "noop_set",
    "defer_set",
)


class WorldLedgerError(ValueError):
    """Raised when world ledger content or transitions violate MVP-2 rules."""


@dataclass(frozen=True)
class WorldLedgerEvent:
    schema_version: str
    sequence: int
    world_id: str
    event_type: str
    payload: Mapping[str, str]
    previous_hash: str | None
    event_hash: str


@dataclass(frozen=True)
class ReplayedOptionState:
    option_id: str
    formal: bool
    reachable: bool
    meaningful: bool


@dataclass(frozen=True)
class WorldSubjectState:
    subject_id: str
    agency: float
    agency_floor: float
    options: Mapping[str, ReplayedOptionState]


@dataclass(frozen=True)
class ConflictState:
    conflict_id: str
    left_subject: str
    right_subject: str
    conflict_type: str


@dataclass(frozen=True)
class WorldLedgerState:
    world_id: str
    display_name: str
    subjects: Mapping[str, WorldSubjectState]
    conflicts: Mapping[str, ConflictState]
    resolved_conflicts: frozenset[str]
    noop_available: bool
    defer_available: bool
    event_count: int
    head_hash: str


def _validate_string(value: object, where: str) -> str:
    if not isinstance(value, str) or not value:
        raise WorldLedgerError(f"{where} must be a non-empty string")
    return value


def _payload_copy(payload: Mapping[str, str]) -> dict[str, str]:
    if not isinstance(payload, Mapping):
        raise WorldLedgerError("payload must be an object")
    result: dict[str, str] = {}
    for key in sorted(payload):
        _validate_string(key, "payload key")
        result[key] = _validate_string(payload[key], f"payload.{key}")
    return result


def _hash_material(*, schema_version: str, sequence: int, world_id: str, event_type: str, payload: Mapping[str, str], previous_hash: str | None) -> bytes:
    body = {
        "schema_version": schema_version,
        "sequence": sequence,
        "world_id": world_id,
        "event_type": event_type,
        "payload": dict(payload),
        "previous_hash": previous_hash,
    }
    return json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def compute_world_event_hash(*, schema_version: str, sequence: int, world_id: str, event_type: str, payload: Mapping[str, str], previous_hash: str | None) -> str:
    return hashlib.sha256(
        _hash_material(
            schema_version=schema_version,
            sequence=sequence,
            world_id=world_id,
            event_type=event_type,
            payload=payload,
            previous_hash=previous_hash,
        )
    ).hexdigest()


def make_world_event(sequence: int, world_id: str, event_type: str, payload: Mapping[str, str], previous_hash: str | None) -> WorldLedgerEvent:
    if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
        raise WorldLedgerError("sequence must be a non-negative integer")
    world_id = _validate_string(world_id, "world_id")
    if event_type not in WORLD_EVENT_TYPES:
        raise WorldLedgerError(f"unsupported event_type {event_type!r}")
    parsed_payload = _payload_copy(payload)
    if previous_hash is not None:
        _validate_string(previous_hash, "previous_hash")
    event_hash = compute_world_event_hash(
        schema_version=WORLD_SCHEMA_VERSION,
        sequence=sequence,
        world_id=world_id,
        event_type=event_type,
        payload=parsed_payload,
        previous_hash=previous_hash,
    )
    return WorldLedgerEvent(
        schema_version=WORLD_SCHEMA_VERSION,
        sequence=sequence,
        world_id=world_id,
        event_type=event_type,
        payload=MappingProxyType(parsed_payload),
        previous_hash=previous_hash,
        event_hash=event_hash,
    )


def verify_world_events(events: Iterable[WorldLedgerEvent], expected_head_hash: str | None = None) -> str:
    sequence = list(events)
    if not sequence:
        raise WorldLedgerError("world ledger must contain at least one event")
    previous_hash: str | None = None
    world_id: str | None = None
    for index, event in enumerate(sequence):
        if event.schema_version != WORLD_SCHEMA_VERSION:
            raise WorldLedgerError(f"event {index} schema_version mismatch")
        if event.sequence != index:
            raise WorldLedgerError(f"event {index} sequence mismatch")
        if world_id is None:
            world_id = event.world_id
        elif event.world_id != world_id:
            raise WorldLedgerError(f"event {index} world_id mismatch")
        if event.previous_hash != previous_hash:
            raise WorldLedgerError(f"event {index} previous_hash mismatch")
        expected = compute_world_event_hash(
            schema_version=event.schema_version,
            sequence=event.sequence,
            world_id=event.world_id,
            event_type=event.event_type,
            payload=event.payload,
            previous_hash=event.previous_hash,
        )
        if event.event_hash != expected:
            raise WorldLedgerError(f"event {index} event_hash mismatch")
        previous_hash = event.event_hash
    assert previous_hash is not None
    if expected_head_hash is not None and previous_hash != expected_head_hash:
        raise WorldLedgerError("expected head hash mismatch")
    return previous_hash


def _require_payload(event: WorldLedgerEvent, keys: set[str]) -> None:
    actual = set(event.payload)
    if actual != keys:
        expected = ", ".join(sorted(keys))
        raise WorldLedgerError(f"{event.event_type} payload must contain exactly: {expected}")


def _parse_bool(raw: str, where: str) -> bool:
    if raw == "true":
        return True
    if raw == "false":
        return False
    raise WorldLedgerError(f"{where} must be 'true' or 'false'")


def _parse_unit_float(raw: str, where: str) -> float:
    try:
        value = float(raw)
    except ValueError as exc:
        raise WorldLedgerError(f"{where} must be a decimal number") from exc
    if not 0.0 <= value <= 1.0:
        raise WorldLedgerError(f"{where} must be between 0 and 1")
    return value


def _require_subject(subjects: dict[str, WorldSubjectState], subject_id: str) -> WorldSubjectState:
    if subject_id not in subjects:
        raise WorldLedgerError(f"unknown subject {subject_id!r}")
    return subjects[subject_id]


def replay_world_events(events: Iterable[WorldLedgerEvent]) -> WorldLedgerState:
    sequence = list(events)
    head_hash = verify_world_events(sequence)
    first = sequence[0]
    if first.event_type != "world_registered":
        raise WorldLedgerError("first event must be world_registered")
    _require_payload(first, {"display_name"})

    subjects: dict[str, WorldSubjectState] = {}
    conflicts: dict[str, ConflictState] = {}
    resolved_conflicts: set[str] = set()
    noop_available = True
    defer_available = True

    for event in sequence[1:]:
        if event.event_type == "world_registered":
            raise WorldLedgerError("world_registered may appear only once")

        if event.event_type == "subject_joined":
            _require_payload(event, {"subject_id", "agency", "agency_floor"})
            subject_id = event.payload["subject_id"]
            if subject_id in subjects:
                raise WorldLedgerError(f"subject {subject_id!r} already joined")
            agency = _parse_unit_float(event.payload["agency"], "agency")
            floor = _parse_unit_float(event.payload["agency_floor"], "agency_floor")
            subjects[subject_id] = WorldSubjectState(
                subject_id=subject_id,
                agency=agency,
                agency_floor=floor,
                options=MappingProxyType({}),
            )
            continue

        if event.event_type == "option_declared":
            _require_payload(event, {"subject_id", "option_id", "formal", "reachable", "meaningful"})
            subject_id = event.payload["subject_id"]
            subject = _require_subject(subjects, subject_id)
            option_id = event.payload["option_id"]
            options = dict(subject.options)
            if option_id in options:
                raise WorldLedgerError(f"option {option_id!r} already exists for subject {subject_id!r}")
            options[option_id] = ReplayedOptionState(
                option_id=option_id,
                formal=_parse_bool(event.payload["formal"], "formal"),
                reachable=_parse_bool(event.payload["reachable"], "reachable"),
                meaningful=_parse_bool(event.payload["meaningful"], "meaningful"),
            )
            subjects[subject_id] = replace(subject, options=MappingProxyType(dict(sorted(options.items()))))
            continue

        if event.event_type in {"option_reachability_set", "option_meaningfulness_set"}:
            field = "reachable" if event.event_type == "option_reachability_set" else "meaningful"
            _require_payload(event, {"subject_id", "option_id", field})
            subject_id = event.payload["subject_id"]
            subject = _require_subject(subjects, subject_id)
            option_id = event.payload["option_id"]
            options = dict(subject.options)
            if option_id not in options:
                raise WorldLedgerError(f"unknown option {option_id!r} for subject {subject_id!r}")
            option = options[option_id]
            options[option_id] = replace(option, **{field: _parse_bool(event.payload[field], field)})
            subjects[subject_id] = replace(subject, options=MappingProxyType(dict(sorted(options.items()))))
            continue

        if event.event_type == "agency_set":
            _require_payload(event, {"subject_id", "agency"})
            subject_id = event.payload["subject_id"]
            subject = _require_subject(subjects, subject_id)
            subjects[subject_id] = replace(subject, agency=_parse_unit_float(event.payload["agency"], "agency"))
            continue

        if event.event_type == "conflict_declared":
            _require_payload(event, {"conflict_id", "left_subject", "right_subject", "conflict_type"})
            conflict_id = event.payload["conflict_id"]
            if conflict_id in conflicts:
                raise WorldLedgerError(f"conflict {conflict_id!r} already active")
            _require_subject(subjects, event.payload["left_subject"])
            _require_subject(subjects, event.payload["right_subject"])
            conflicts[conflict_id] = ConflictState(
                conflict_id=conflict_id,
                left_subject=event.payload["left_subject"],
                right_subject=event.payload["right_subject"],
                conflict_type=event.payload["conflict_type"],
            )
            resolved_conflicts.discard(conflict_id)
            continue

        if event.event_type == "conflict_resolved":
            _require_payload(event, {"conflict_id"})
            conflict_id = event.payload["conflict_id"]
            if conflict_id not in conflicts:
                raise WorldLedgerError(f"cannot resolve inactive conflict {conflict_id!r}")
            del conflicts[conflict_id]
            resolved_conflicts.add(conflict_id)
            continue

        if event.event_type == "noop_set":
            _require_payload(event, {"available"})
            noop_available = _parse_bool(event.payload["available"], "available")
            continue

        if event.event_type == "defer_set":
            _require_payload(event, {"available"})
            defer_available = _parse_bool(event.payload["available"], "available")
            continue

        raise WorldLedgerError(f"unsupported event_type {event.event_type!r}")

    return WorldLedgerState(
        world_id=first.world_id,
        display_name=first.payload["display_name"],
        subjects=MappingProxyType(dict(sorted(subjects.items()))),
        conflicts=MappingProxyType(dict(sorted(conflicts.items()))),
        resolved_conflicts=frozenset(resolved_conflicts),
        noop_available=noop_available,
        defer_available=defer_available,
        event_count=len(sequence),
        head_hash=head_hash,
    )
