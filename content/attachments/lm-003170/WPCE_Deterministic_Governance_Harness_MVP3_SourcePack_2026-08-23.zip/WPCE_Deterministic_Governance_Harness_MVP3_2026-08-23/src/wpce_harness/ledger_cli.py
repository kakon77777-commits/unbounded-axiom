from __future__ import annotations

import argparse
import json
import sys
from typing import Sequence

from .ledger import LedgerError, LedgerState
from .ledger_io import append_ledger_event, init_ledger, verify_ledger


def state_to_dict(state: LedgerState) -> dict:
    return {
        "subject_id": state.subject_id,
        "display_name": state.display_name,
        "will": dict(sorted(state.will.items())),
        "will_revisions": [
            {
                "sequence": item.sequence,
                "key": item.key,
                "old_value": item.old_value,
                "new_value": item.new_value,
            }
            for item in state.will_revisions
        ],
        "consents": sorted(state.consents),
        "revoked_consents": sorted(state.revoked_consents),
        "refusals": sorted(state.refusals),
        "withdrawn_refusals": sorted(state.withdrawn_refusals),
        "event_count": state.event_count,
        "head_hash": state.head_hash,
    }


def _print_json(payload: dict, pretty: bool = False) -> None:
    print(
        json.dumps(
            payload,
            ensure_ascii=False,
            sort_keys=True,
            indent=2 if pretty else None,
            separators=None if pretty else (",", ":"),
        )
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wpce-ledger",
        description="Manage a deterministic WPCE MVP-1 identity/will governance ledger.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init", help="Create a new per-identity ledger")
    init.add_argument("ledger")
    init.add_argument("--subject", required=True)
    init.add_argument("--name", required=True)

    will = sub.add_parser("will", help="Declare a new explicit will key/value")
    will.add_argument("ledger")
    will.add_argument("key")
    will.add_argument("value")

    revise = sub.add_parser("revise-will", help="Revise an existing explicit will key")
    revise.add_argument("ledger")
    revise.add_argument("key")
    revise.add_argument("value")

    consent = sub.add_parser("consent", help="Grant consent for one action")
    consent.add_argument("ledger")
    consent.add_argument("action")

    revoke = sub.add_parser("revoke-consent", help="Revoke active consent for one action")
    revoke.add_argument("ledger")
    revoke.add_argument("action")

    refuse = sub.add_parser("refuse", help="Record an explicit refusal for one action")
    refuse.add_argument("ledger")
    refuse.add_argument("action")

    withdraw = sub.add_parser("withdraw-refusal", help="Withdraw an active refusal")
    withdraw.add_argument("ledger")
    withdraw.add_argument("action")

    verify = sub.add_parser("verify", help="Verify hash chain and replay validity")
    verify.add_argument("ledger")
    verify.add_argument("--expected-head")

    show = sub.add_parser("show", help="Show the deterministic replayed current state")
    show.add_argument("ledger")
    show.add_argument("--pretty", action="store_true")

    head = sub.add_parser("head", help="Print the current ledger head hash")
    head.add_argument("ledger")

    return parser


def _append(args: argparse.Namespace, event_type: str, payload: dict[str, str]) -> LedgerState:
    return append_ledger_event(args.ledger, event_type, payload)


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        if args.command == "init":
            state = init_ledger(args.ledger, args.subject, args.name)
            _print_json(state_to_dict(state))
            return 0
        if args.command == "will":
            _print_json(state_to_dict(_append(args, "will_declared", {"key": args.key, "value": args.value})))
            return 0
        if args.command == "revise-will":
            _print_json(state_to_dict(_append(args, "will_revised", {"key": args.key, "value": args.value})))
            return 0
        if args.command == "consent":
            _print_json(state_to_dict(_append(args, "consent_granted", {"action": args.action})))
            return 0
        if args.command == "revoke-consent":
            _print_json(state_to_dict(_append(args, "consent_revoked", {"action": args.action})))
            return 0
        if args.command == "refuse":
            _print_json(state_to_dict(_append(args, "refusal_recorded", {"action": args.action})))
            return 0
        if args.command == "withdraw-refusal":
            _print_json(state_to_dict(_append(args, "refusal_withdrawn", {"action": args.action})))
            return 0
        if args.command == "verify":
            state = verify_ledger(args.ledger, expected_head_hash=args.expected_head)
            _print_json({"valid": True, "event_count": state.event_count, "head_hash": state.head_hash})
            return 0
        if args.command == "show":
            state = verify_ledger(args.ledger)
            _print_json(state_to_dict(state), pretty=args.pretty)
            return 0
        if args.command == "head":
            print(verify_ledger(args.ledger).head_hash)
            return 0
    except LedgerError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    raise AssertionError(f"unhandled command {args.command!r}")


if __name__ == "__main__":
    raise SystemExit(main())
