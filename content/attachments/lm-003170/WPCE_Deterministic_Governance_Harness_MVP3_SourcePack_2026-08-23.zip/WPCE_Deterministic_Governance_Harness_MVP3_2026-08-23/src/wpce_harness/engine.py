from __future__ import annotations

from .invariants import CHECKS
from .models import Evaluation, Scenario


def evaluate(scenario: Scenario) -> Evaluation:
    checks = [check(scenario) for check in CHECKS]
    violations = [check.code for check in checks if not check.passed]
    return Evaluation(
        scenario_id=scenario.scenario_id,
        allowed=not violations,
        violations=violations,
        checks=checks,
    )
