from __future__ import annotations

import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping

from .world_ledger import (
    WORLD_SCHEMA_VERSION,
    WorldLedgerError,
    WorldLedgerEvent,
    WorldLedgerState,
    make_world_event,
    replay_world_events,
    verify_world_events,
)

_EVENT_KEYS = {
    "schema_version",
    "sequence",
    "world_id",
    "event_type",
    "payload",
    "previous_hash",
    "event_hash",
}


def world_event_to_dict(event: WorldLedgerEvent) -> dict[str, Any]:
    return {
        "schema_version": event.schema_version,
        "sequence": event.sequence,
        "world_id": event.world_id,
        "event_type": event.event_type,
        "payload": dict(event.payload),
        "previous_hash": event.previous_hash,
        "event_hash": event.event_hash,
    }


def canonical_world_event_line(event: WorldLedgerEvent) -> str:
    return json.dumps(
        world_event_to_dict(event),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ) + "\n"


def _event_from_dict(raw: Mapping[str, Any], line_number: int) -> WorldLedgerEvent:
    if set(raw) != _EVENT_KEYS:
        raise WorldLedgerError(f"line {line_number} event fields mismatch")
    if raw["schema_version"] != WORLD_SCHEMA_VERSION:
        raise WorldLedgerError(f"line {line_number} schema_version mismatch")
    sequence = raw["sequence"]
    if isinstance(sequence, bool) or not isinstance(sequence, int) or sequence < 0:
        raise WorldLedgerError(f"line {line_number} sequence must be a non-negative integer")
    world_id = raw["world_id"]
    event_type = raw["event_type"]
    event_hash = raw["event_hash"]
    previous_hash = raw["previous_hash"]
    if not isinstance(world_id, str) or not world_id:
        raise WorldLedgerError(f"line {line_number} world_id must be a non-empty string")
    if not isinstance(event_type, str) or not event_type:
        raise WorldLedgerError(f"line {line_number} event_type must be a non-empty string")
    if not isinstance(event_hash, str) or not event_hash:
        raise WorldLedgerError(f"line {line_number} event_hash must be a non-empty string")
    if previous_hash is not None and (not isinstance(previous_hash, str) or not previous_hash):
        raise WorldLedgerError(f"line {line_number} previous_hash must be null or a non-empty string")
    payload = raw["payload"]
    if not isinstance(payload, Mapping):
        raise WorldLedgerError(f"line {line_number} payload must be an object")
    parsed_payload: dict[str, str] = {}
    for key in sorted(payload):
        value = payload[key]
        if not isinstance(key, str) or not key or not isinstance(value, str) or not value:
            raise WorldLedgerError(f"line {line_number} payload keys and values must be non-empty strings")
        parsed_payload[key] = value
    return WorldLedgerEvent(
        schema_version=WORLD_SCHEMA_VERSION,
        sequence=sequence,
        world_id=world_id,
        event_type=event_type,
        payload=MappingProxyType(parsed_payload),
        previous_hash=previous_hash,
        event_hash=event_hash,
    )


def load_world_ledger(path: str | Path) -> tuple[WorldLedgerEvent, ...]:
    file_path = Path(path)
    try:
        text = file_path.read_text(encoding="utf-8")
    except OSError as exc:
        raise WorldLedgerError(f"cannot read world ledger {file_path}: {exc}") from exc
    if not text:
        raise WorldLedgerError("world ledger must contain at least one event")
    events: list[WorldLedgerEvent] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        if not line:
            raise WorldLedgerError(f"line {line_number} must not be blank")
        try:
            raw = json.loads(line)
        except json.JSONDecodeError as exc:
            raise WorldLedgerError(f"line {line_number} is not valid JSON: {exc.msg}") from exc
        if not isinstance(raw, Mapping):
            raise WorldLedgerError(f"line {line_number} must contain a JSON object")
        events.append(_event_from_dict(raw, line_number))
    return tuple(events)


def verify_world_ledger(path: str | Path, expected_head_hash: str | None = None) -> WorldLedgerState:
    events = load_world_ledger(path)
    verify_world_events(events, expected_head_hash=expected_head_hash)
    return replay_world_events(events)


def init_world_ledger(path: str | Path, world_id: str, display_name: str) -> WorldLedgerState:
    file_path = Path(path)
    if file_path.exists() and file_path.stat().st_size > 0:
        raise WorldLedgerError(f"world ledger already exists: {file_path}")
    file_path.parent.mkdir(parents=True, exist_ok=True)
    event = make_world_event(
        sequence=0,
        world_id=world_id,
        event_type="world_registered",
        payload={"display_name": display_name},
        previous_hash=None,
    )
    state = replay_world_events([event])
    file_path.write_text(canonical_world_event_line(event), encoding="utf-8", newline="\n")
    return state


def append_world_ledger_event(path: str | Path, event_type: str, payload: Mapping[str, str]) -> WorldLedgerState:
    file_path = Path(path)
    events = list(load_world_ledger(file_path))
    current = replay_world_events(events)
    event = make_world_event(
        sequence=len(events),
        world_id=current.world_id,
        event_type=event_type,
        payload=payload,
        previous_hash=current.head_hash,
    )
    candidate = [*events, event]
    state = replay_world_events(candidate)
    with file_path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(canonical_world_event_line(event))
    return state
