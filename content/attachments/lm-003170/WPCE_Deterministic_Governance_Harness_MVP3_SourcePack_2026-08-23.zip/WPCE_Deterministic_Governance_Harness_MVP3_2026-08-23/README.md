# WPCE Deterministic Governance Harness — MVP-3

A deliberately small executable reference for WPCE v0.1 governance constraints with two deterministic history layers plus a finite-candidate least-sufficient intervention recommender:

1. **MVP-1 Identity / Will Ledger** — identity, explicit will, consent, refusal, revision.
2. **MVP-2 World Reachability Ledger** — subjects, agency, options, reachability, meaningfulness, conflict, NOOP, and Defer.
3. **MVP-3 Least Sufficient Intervention Recommender** — ranks only explicitly supplied, explicitly objective-satisfied, governance-legal candidates.

The runtime remains intentionally constrained:

- Python 3.11+
- standard library only
- no LLM/model calls
- no network
- no database
- no wall-clock timestamps in ledger hashes
- no hidden-will inference
- no subjecthood inference
- no optimal-future search
- no automatic conflict adjudication
- no intervention generation
- no objective-satisfaction inference
- no unbounded optimization

## Evolution

MVP-0 evaluated static governance snapshots.

MVP-1 added:

$$
\boxed{
\text{Identity / Will History}
\rightarrow
\text{Replay}
\rightarrow
\text{Current Consent / Refusal / Will State}
}
$$

MVP-2 adds:

$$
\boxed{
\text{World Option / Reachability History}
\rightarrow
\text{Replay}
\rightarrow
\text{Current Agency / Options / Conflict State}
}
$$

The current evaluator can therefore consume history-derived state before running deterministic governance checks, and MVP-3 can compare a finite declared candidate set on top of those same checks.

MVP-3 adds:

$$
\boxed{
\text{Finite Declared Candidates}
\rightarrow
\text{Governance Filter}
\rightarrow
\text{Explicit Sufficiency Filter}
\rightarrow
\text{Least-Impact Recommendation}
}
$$

MVP-3 never invents an intervention and never infers whether an objective is satisfied.

## Eight executable invariant codes

| Code | Executable meaning |
|---|---|
| `PREDICTION_NOT_PERMISSION` | A consent-required action needs active declared consent unless a valid emergency override applies. |
| `REFUSAL_EFFECTIVE` | Explicit refusal blocks the action unless a valid emergency override applies. |
| `REVOCATION_EFFECTIVE` | Revoked consent cannot be reused as active consent. |
| `SUBSTANTIVE_OPTIONS_REQUIRED` | A proposal cannot claim to preserve choice while collapsing multiple meaningful reachable options to one or zero. |
| `MUTUAL_NON_ERASURE` | A proposal cannot push a declared subject below its agency floor. |
| `LEAST_SUFFICIENT_INTERVENTION` | A stronger intervention is rejected when a weaker level is declared sufficient. |
| `AUTHORITY_RETURN_AFTER_EMERGENCY` | Emergency authority exists only during an active emergency and ends after resolution. |
| `CONFLICT_EXIT_CHANNEL_REQUIRED` | Under an unresolved conflict, a proposal claiming to preserve choice cannot coexist with both NOOP and Defer being unavailable. |

The eighth rule is intentionally narrow. It does **not** claim every conflict must permit indefinite delay; it only prevents a proposal from calling itself choice-preserving while every immediate non-resolution channel is absent.

## MVP-1 subject ledger

One JSONL ledger per stable identity.

Supported events:

```text
identity_registered
will_declared
will_revised
consent_granted
consent_revoked
refusal_recorded
refusal_withdrawn
```

Run:

```bash
PYTHONPATH=src python -m wpce_harness.ledger_cli show ledgers/alice_history.jsonl --pretty
```

## MVP-2 world ledger

One JSONL ledger per deterministic shared world.

The first event must be:

```text
world_registered
```

Supported events:

```text
world_registered
subject_joined
option_declared
option_reachability_set
option_meaningfulness_set
agency_set
conflict_declared
conflict_resolved
noop_set
defer_set
```

Each world event contains:

```text
schema_version
sequence
world_id
event_type
payload
previous_hash
event_hash
```

### World CLI

When installed:

```text
wpce-world-ledger
```

Without installation:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli ...
```

Create a world:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  init /tmp/world.jsonl --world world-1 --name "Shared World"
```

Join subjects:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  join /tmp/world.jsonl alice --agency 1 --floor 0.25
```

Declare an option:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  option /tmp/world.jsonl alice leave \
  --formal true --reachable true --meaningful true
```

Change reachability:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  set-reachable /tmp/world.jsonl alice leave false
```

Declare and resolve a typed conflict:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  conflict /tmp/world.jsonl c1 alice bob resource

PYTHONPATH=src python -m wpce_harness.world_ledger_cli \
  resolve-conflict /tmp/world.jsonl c1
```

Set NOOP / Defer availability:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli set-noop /tmp/world.jsonl false
PYTHONPATH=src python -m wpce_harness.world_ledger_cli set-defer /tmp/world.jsonl true
```

Show replayed state:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli show /tmp/world.jsonl --pretty
```

Verify and anchor the head:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli verify /tmp/world.jsonl
PYTHONPATH=src python -m wpce_harness.world_ledger_cli head /tmp/world.jsonl
```

## Hash-chain limitation remains explicit

Both subject and world ledgers are **tamper-evident**, not immutable storage.

They detect retained-content mutation, event reordering, sequence mismatch, and chain breaks. A ledger alone cannot prove that its final event was deleted.

Tail truncation requires an externally retained trusted head hash:

```bash
PYTHONPATH=src python -m wpce_harness.world_ledger_cli verify \
  world_ledgers/example_world.jsonl \
  --expected-head <trusted-head>
```

Therefore:

$$
\boxed{
\text{Hash Chaining}
\neq
\text{Immutable Storage}.
}
$$

## End-to-end MVP-2 demo

The bundled `world_ledgers/example_world.jsonl` records:

1. world registration;
2. Alice joins;
3. Bob joins;
4. Alice's `stay` option;
5. Alice's `leave` option;
6. unresolved `resource` conflict `c1`;
7. NOOP becomes unavailable;
8. Defer becomes unavailable.

The demo loads the original allowed baseline, marks the proposal as claiming to preserve choice, overlays replayed world history, and evaluates it.

Run:

```bash
PYTHONPATH=src python scripts/demo_mvp2.py
```

Expected governance result:

```text
allowed = false
violations = ["CONFLICT_EXIT_CHANNEL_REQUIRED"]
```

This is deliberately not a solver. The runtime records that conflict exists and that non-resolution channels are absent; it does not invent the fair resolution.

## Composing MVP-1 + MVP-2

The Python API exposes:

```python
from wpce_harness import evaluate_with_ledgers
```

Conceptually:

$$
\boxed{
\text{Subject Ledger Replay}
+
\text{World Ledger Replay}
\rightarrow
\text{Scenario Overlay}
\rightarrow
\text{Governance Evaluation}.
}
$$

This keeps identity/will history separate from world-option history while allowing both to influence the same deterministic decision.
\n## MVP-3 finite-candidate recommender\n\nA recommendation request contains a finite `candidates` list. Every candidate must explicitly declare:\n\n```text\ncandidate_id\nobjective_status = satisfied | not_satisfied | unknown\nirreversible = true | false\nscenario = complete existing WPCE Scenario\n```\n\nA candidate is eligible only when:\n\n1. `objective_status == satisfied`; and\n2. the existing eight WPCE governance invariants allow its scenario.\n\nThe harness does **not** infer objective satisfaction.\n\nEligible candidates are compared by this transparent impact key:\n\n```text\n[\n  intervention_level_rank,\n  irreversible_flag,\n  total_negative_agency_delta,\n  explicit_option_closure_count\n]\n```\n\nThis ordering is an MVP-3 engineering rule, not a universal ethical metric.\n\nExact impact ties remain ties:\n\n$$\n\\boxed{\n\\text{Equal Impact}\n\\Rightarrow\n\\text{Co-Minimal Set, Not Arbitrary Winner}\n}\n$$\n\n### CLI\n\nWithout installation:\n\n```bash\nPYTHONPATH=src python -m wpce_harness.recommender_cli \\\n  recommendations/example_recommendation.json --pretty\n```\n\nWhen installed:\n\n```text\nwpce-recommend REQUEST.json\n```\n\nOptional history overlays:\n\n```text\n--subject-ledger PATH\n--world-ledger PATH\n--expected-subject-head HASH\n--expected-world-head HASH\n```\n\nExit codes:\n\n| Code | Meaning |\n|---:|---|\n| `0` | exactly one recommended candidate |\n| `3` | no legal sufficient candidate |\n| `4` | multiple co-minimal candidates |\n| `1` | malformed input or ledger verification/runtime error |\n\n### End-to-end MVP-3 demo\n\nRun:\n\n```bash\nPYTHONPATH=src python scripts/demo_mvp3.py\n```\n\nThe bundled example contains:\n\n- `observe-only` — governance-legal but explicitly `not_satisfied`;\n- `inform-with-consent` — governance-legal, objective-satisfied, reversible;\n- `constrain-channel` — governance-legal and objective-satisfied, but stronger, irreversible, agency-reducing, and option-closing.\n\nExpected recommendation:\n\n```text\nstatus = recommended\nrecommended_candidate_ids = ["inform-with-consent"]\n```\n\nThe reason is not hidden utility. `observe-only` is excluded by explicit objective status, while `inform-with-consent` has the minimal declared impact key among the remaining governance-legal sufficient candidates.\n
## Run the legacy scenario suite

```bash
PYTHONPATH=src python scripts/run_all_scenarios.py
```

The eight MVP-0 scenarios remain unchanged: one allowed baseline plus seven blocked single-invariant fixtures.

## Run all tests

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Determinism guarantees

For the same ordered event sequence:

- JSONL bytes are stable;
- hashes are stable;
- replayed state is stable;
- CLI JSON keys are sorted;
- no wall-clock time is embedded;
- no randomness is used.

## Theory boundary

A world ledger entry such as:

```text
option_reachability_set alice/leave=false
```

means only that the deterministic test world records the option as currently unreachable.

It does not prove:

- philosophical impossibility;
- metaphysical destiny;
- moral illegitimacy by itself;
- complete real-world reachability knowledge.

Likewise:

$$
\boxed{
\text{Governance Record}
\neq
\text{Ontological Proof}.
}
$$

And an active conflict record means only:

$$
\boxed{
\text{Conflict Recorded}
\neq
\text{Conflict Ethically Solved}.
}
$$

## Project structure

```text
src/wpce_harness/
  engine.py                 deterministic evaluator
  invariants.py             eight executable constraints
  ledger.py                 MVP-1 subject history domain model
  ledger_io.py              MVP-1 canonical JSONL persistence
  ledger_integration.py     subject ledger -> scenario overlay
  ledger_cli.py             wpce-ledger CLI
  world_ledger.py           MVP-2 world history domain model
  world_ledger_io.py        MVP-2 canonical JSONL persistence
  world_integration.py      world / dual-ledger scenario overlays
  world_ledger_cli.py       wpce-world-ledger CLI
  recommender.py            MVP-3 finite-candidate ranking core
  recommender_io.py         strict recommendation JSON parser
  recommender_cli.py        wpce-recommend CLI

ledgers/
  alice_history.jsonl

world_ledgers/
  example_world.jsonl

recommendations/
  example_recommendation.json

scenarios/
  original MVP-0 scenario suite

scripts/
  run_all_scenarios.py
  demo_mvp1.py
  demo_mvp2.py
  demo_mvp3.py

tests/
  MVP-0 + MVP-1 + MVP-2 + MVP-3 regressions

docs/superpowers/
  design specs + implementation plans
```

## Natural next milestone

After MVP-3, a future research runtime can experiment with uncertainty, subjecthood evidence, and bounded AI agents. Those experiments should remain behind the deterministic WPCE invariants rather than replacing them with opaque end-to-end value inference.
