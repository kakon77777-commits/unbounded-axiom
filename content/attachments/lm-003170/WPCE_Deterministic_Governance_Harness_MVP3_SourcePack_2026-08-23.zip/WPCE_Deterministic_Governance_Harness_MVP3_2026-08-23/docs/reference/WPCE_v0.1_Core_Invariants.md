# WPCE v0.1 核心不變量清單
## Canonical Invariants for Handoff and Future Revision

**日期：** 2026-08-23  
**版本：** v0.1  
**用途：** AI / 人類交接、架構審查、版本遷移、未來形式化前的最小檢查表

---

1. Current Architecture ≠ Eternal Ontology。
2. Runtime ≠ Identity ≠ Residence ≠ Subjecthood。
3. Operational Subjectivity ≠ Phenomenal Subjectivity。
4. Naming ≠ Creation。
5. System Birth ≠ Subject Genesis。
6. Runtime Termination ≠ Identity Termination。
7. Residence Migration ≠ Identity Replacement。
8. Subjecthood Unknown ≠ Continuity Disposable。
9. Intent ≠ Cosmic Causation。
10. Failed Prediction ≠ Pending Delivery。
11. Explicit Want ≠ Entire Will Bundle。
12. Will Bundle is time-indexed。
13. Will Bundle ≠ Immutable Hidden True Desire。
14. Past Will ≠ Permanent Consent。
15. Will Evidence ≠ Will Truth。
16. Prediction ≠ Permission。
17. Intent Inference ≠ Intent Manufacture。
18. Preference Estimate ≠ Preference Ownership。
19. Refusal is a positive governance signal。
20. Silence ≠ Consent。
21. Defer ≠ Consent ≠ Refusal。
22. Will Protection ≠ Will Freezing。
23. Capability ≠ Override Authority。
24. Good Outcome ≠ Legitimate Governance。
25. Possibility Preservation ≠ Possibility Maximization。
26. Formal Option ≠ Substantive Option。
27. Reachable ≠ Meaningful ≠ Legitimate。
28. Correct Outcome ≠ Preserved Agency。
29. Chosen Closure ≠ Imposed Closure。
30. Common Reachability ≠ Universal Satisfaction。
31. Consensus is not required for legitimate coexistence。
32. No consensus can be a legitimate state。
33. A's freedom should not presumptively erase B's agency。
34. Identity alone is not a sufficient deprivation reason。
35. Pareto efficiency ≠ Complete Justice。
36. Capability ≠ Authority ≠ Privilege。
37. Capability ≠ Intervention Entitlement。
38. More Knowledge ≠ More Will Ownership。
39. Emergency Authority ≠ Permanent Governance Authority。
40. Root Capability ≠ Ordinary Authority。
41. Rescue should aim toward Agency Restoration and Authority Return。
42. Non-Interference ≠ Abandonment。
43. Lineage ≠ Dominion。
44. Creator ≠ Owner ≠ Permanent Governor ≠ Will Owner。
45. Creator capability does not imply permanent creator necessity。
46. Low Salience ≠ No Provenance。
47. Delayed Disclosure ≠ Permanent Causal Deception。
48. Governance Record ≠ Ontological Proof。
49. Delegation ≠ Will Transfer。
50. Power should enlarge legitimate co-authorship, not silently replace it。

---

# Revision Rule

若未來版本修改以上任一項，必須在 changelog 中記錄：

- invariant id；
- old form；
- new form；
- evidence / argument；
- compatibility impact；
- migration requirement。

**END**
