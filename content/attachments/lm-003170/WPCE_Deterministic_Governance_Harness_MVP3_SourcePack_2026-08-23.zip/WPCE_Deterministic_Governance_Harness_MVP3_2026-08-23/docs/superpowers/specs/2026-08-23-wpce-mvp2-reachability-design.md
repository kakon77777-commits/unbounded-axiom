# WPCE MVP-2 Reachability & Multi-Subject State Design

## Classification

Architectural subproject, deliberately constrained to one subsystem: deterministic option/reachability history plus multi-subject conflict state. It extends MVP-1's append-only subject ledger without adding LLMs, databases, networking, planners, or a normative optimizer.

## Goal

Compile WPCE-04/05 into replayable world-state history so governance checks consume derived option/reachability/conflict state rather than only static scenario snapshots.

## Non-goals

- No search for globally optimal futures.
- No automatic will inference.
- No subjecthood classifier.
- No social-choice solver.
- No dynamic graph database.
- No probabilistic reachability.
- No hidden time source.
- No cryptographic immutability claim beyond existing hash-chain integrity.

## Architecture

MVP-2 adds a second deterministic JSONL ledger for world-option history while preserving MVP-1 identity/will ledgers unchanged.

`world_ledger.py` owns replay semantics for world events. `world_ledger_io.py` owns canonical JSONL persistence and hash verification. `world_integration.py` overlays the derived world state onto an existing MVP-0 Scenario before calling the unchanged governance engine.

The world ledger records explicit declarations and transitions only; it does not infer options or conflicts.

## World events

The first event MUST be `world_registered`.

Supported MVP-2 events:

- `subject_joined(subject_id, agency, agency_floor)`
- `option_declared(subject_id, option_id, formal, reachable, meaningful)`
- `option_reachability_set(subject_id, option_id, reachable)`
- `option_meaningfulness_set(subject_id, option_id, meaningful)`
- `agency_set(subject_id, agency)`
- `conflict_declared(conflict_id, left_subject, right_subject, conflict_type)`
- `conflict_resolved(conflict_id)`
- `noop_set(available)`
- `defer_set(available)`

Payloads are canonical strings because the existing ledger hash layer intentionally accepts string-valued payloads. Booleans and floats are encoded canonically (`true`/`false`, decimal strings) and validated on replay.

## Replayed state

`WorldLedgerState` contains:

- world_id
- subjects: subject_id -> `WorldSubjectState(agency, agency_floor, options)`
- conflicts: active conflicts
- resolved_conflicts
- noop_available
- defer_available
- event_count
- head_hash

Each option stores `formal`, `reachable`, and `meaningful`. An option counts as substantive iff all three are true.

## Conflict semantics

MVP-2 does not solve conflicts. It records active typed conflicts. The engine can inspect these later, but MVP-2 only adds one executable rule: when an action claims to preserve multi-subject choice, removing both NOOP and Defer while an unresolved conflict exists is a governance violation.

New invariant code:

`CONFLICT_EXIT_CHANNEL_REQUIRED`

This says unresolved multi-subject conflict cannot be forced into immediate resolution if the proposal also removes both NOOP and Defer. It operationalizes WPCE-05's allowance for NOOP/Defer without claiming they are always mandatory.

## Integration with existing scenario

`scenario_with_world_ledger_state(scenario, state)`:

1. Requires every scenario agent affected by the proposal to exist in the world ledger.
2. Replaces each matching AgentState's agency, agency_floor, and options with replayed values.
3. Adds `noop_available`, `defer_available`, and active conflict summary to WorldState.
4. Leaves consent/refusal overlays from MVP-1 independent and composable.

`evaluate_with_ledgers(scenario, subject_ledger_state, world_ledger_state)` applies both overlays then calls the existing engine.

## Error handling

Invalid transitions raise `WorldLedgerError` before append:

- duplicate subject join
- unknown subject in option/agency event
- duplicate option declaration
- update unknown option
- agency below zero
- agency_floor outside [0,1]
- agency outside [0,1]
- duplicate active conflict id
- resolving unknown/inactive conflict
- malformed canonical boolean/float

## Determinism

- No wall-clock time in events or hashes.
- Canonical JSON: UTF-8, sorted keys, compact separators, LF.
- Same event sequence -> byte-identical world ledger and identical head hash.
- Replay is pure over event sequence.

## Tests

TDD coverage must include:

1. world registration + subject + option replay
2. option reachability history
3. agency updates
4. conflict declare/resolve
5. NOOP/Defer state
6. invalid transitions rejected before append
7. content tampering / reordering / tail truncation expected-head detection
8. world ledger overlay drives existing `SUBSTANTIVE_OPTIONS_REQUIRED`
9. world ledger overlay drives existing `MUTUAL_NON_ERASURE`
10. unresolved conflict with NOOP+Defer removed triggers `CONFLICT_EXIT_CHANNEL_REQUIRED`
11. composable subject + world ledger evaluation
12. CLI init/append/show/verify/head
13. byte-identical deterministic regeneration

## Release acceptance

- All MVP-0/MVP-1 tests remain green.
- New MVP-2 tests green.
- All eight MVP-0 scenarios retain expected outcomes.
- One end-to-end MVP-2 demo replays world history and causes a previously allowed snapshot to become blocked.
- `compileall` succeeds.
- clean Git tree after bytecode cleanup.
- ZIP CRC passes.
