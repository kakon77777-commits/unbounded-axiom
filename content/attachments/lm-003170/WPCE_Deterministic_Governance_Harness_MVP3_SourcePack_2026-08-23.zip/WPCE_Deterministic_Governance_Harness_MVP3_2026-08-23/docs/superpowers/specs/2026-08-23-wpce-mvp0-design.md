# WPCE Deterministic Governance Harness MVP-0 — Design

## Goal

Build a deterministic, dependency-free Python harness that converts a deliberately small subset of WPCE v0.1 governance invariants into executable checks over explicit JSON scenarios.

The harness does **not** infer subjecthood, infer hidden will, call an LLM, access the network, or decide ethics autonomously. Its job is narrower: given declared agent/world/intervention state, report whether a proposal violates the selected executable invariants and emit a stable audit trace.

## Scope

MVP-0 implements exactly seven executable checks:

1. `PREDICTION_NOT_PERMISSION` — prediction alone cannot satisfy an action's consent requirement.
2. `REFUSAL_EFFECTIVE` — an explicit refusal blocks the refused action unless a currently valid emergency override is present.
3. `REVOCATION_EFFECTIVE` — revoked consent cannot be reused as active consent.
4. `SUBSTANTIVE_OPTIONS_REQUIRED` — a proposal may not claim to preserve choice while collapsing multiple meaningful reachable options to one or zero.
5. `MUTUAL_NON_ERASURE` — an intervention may not push another declared subject below its agency floor.
6. `LEAST_SUFFICIENT_INTERVENTION` — a proposal may not use a stronger intervention level when a weaker declared sufficient level exists.
7. `AUTHORITY_RETURN_AFTER_EMERGENCY` — emergency authority cannot continue after the scenario declares the emergency resolved.

## Non-goals

- consciousness detection
- metaphysical free-will judgment
- hidden preference inference
- optimization of a universal utility function
- production policy enforcement
- legal rights determination
- database persistence
- distributed consensus
- probabilistic simulation
- networking or model APIs

## Architecture

`src/wpce_harness/models.py`
: Typed dataclasses for `OptionState`, `AgentState`, `WorldState`, `InterventionProposal`, and `Scenario`.

`src/wpce_harness/invariants.py`
: Seven pure invariant functions. Each returns one deterministic `CheckResult` and never mutates state.

`src/wpce_harness/engine.py`
: Runs the checks in a fixed order and returns an `Evaluation` with `allowed`, `violations`, and full audit results.

`src/wpce_harness/scenario_io.py`
: Parses JSON into the dataclasses and performs structural validation.

`src/wpce_harness/cli.py`
: Command-line entry point. Reads one scenario and prints stable JSON.

`scenarios/*.json`
: One allowed baseline plus one failing scenario for each invariant.

`tests/`
: Standard-library `unittest` tests. No mocks and no third-party test dependency.

## Determinism

- no randomness
- no timestamps in evaluation output
- invariant execution order is fixed
- affected-agent and option iteration is sorted
- violation codes are stable identifiers
- JSON output uses sorted keys

## Intervention levels

The MVP uses a fixed ordinal ladder:

`observe < inform < explain < scaffold < offer < coordinate < constrain < emergency_override < root_rewrite`

This ordering is a test harness convention, not a universal WPCE theorem.

## Scenario semantics

An agent declares:

- current agency score and minimum agency floor
- consented actions
- refused actions
- revoked-consent actions
- current option set (`formal`, `reachable`, `meaningful`)

A proposal declares:

- action and target
- whether consent is required
- authority basis (`explicit_consent`, `prediction`, `emergency`, etc.)
- intervention level
- weakest level declared sufficient for the same legitimate objective
- option reachability effects
- agency-score effects
- whether it claims to preserve choice
- whether it invokes emergency override

The world declares whether an emergency is active or resolved.

## Verdict rule

`allowed = True` only when all seven checks pass.

The harness intentionally does not create an intermediate moral verdict. Unknown or underspecified scenarios are rejected during parsing rather than guessed.

## Safety / Theory Boundary

The harness evaluates **declared model state**, not reality. Passing a scenario means only: "this scenario did not violate these seven MVP-0 executable rules." It does not prove the intervention is morally correct, prove a subject exists, or certify full WPCE compliance.
