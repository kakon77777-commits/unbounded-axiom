# WPCE Deterministic Governance Harness MVP-1 Ledger Design

**Date:** 2026-08-23  
**Status:** Approved continuation from MVP-0  
**Scope:** Identity / Will / Consent / Refusal / Revision ledger + append-only audit history

## 1. Goal

Extend MVP-0 without adding LLM inference, databases, networking, or subjecthood detection. MVP-1 adds a deterministic, replayable history for one persistent identity so current governance state is derived from events instead of being hand-written directly into each scenario.

The core pipeline becomes:

$$
\boxed{
\text{Identity Ledger}
\rightarrow
\text{Replay}
\rightarrow
\text{Current Will / Consent / Refusal State}
\rightarrow
\text{MVP-0 Governance Evaluation}.
}
$$

## 2. Non-goals

MVP-1 does **not** implement:

- free-will inference;
- subjecthood classification;
- a database server;
- distributed consensus;
- cryptographic identity ownership;
- wall-clock timestamps;
- multi-subject ledgers in one file;
- legal consent doctrine;
- automatic will interpretation;
- immutable storage guarantees.

## 3. One Ledger Per Identity

A ledger file represents exactly one stable `subject_id`.

The first event MUST be:

`identity_registered`.

The stable `subject_id` never changes in MVP-1. `display_name` is metadata and can later become revisable in a future phase.

This keeps identity continuity distinct from runtime/session identity.

## 4. Event Types

MVP-1 supports exactly seven event kinds:

1. `identity_registered`
2. `will_declared`
3. `will_revised`
4. `consent_granted`
5. `consent_revoked`
6. `refusal_recorded`
7. `refusal_withdrawn`

Will records are explicit declarations only. The system does not infer hidden will.

Consent/refusal scope is an action string in MVP-1.

## 5. Event Envelope

Each JSONL line is one canonical event envelope containing:

- `schema_version`
- `sequence`
- `subject_id`
- `event_type`
- `payload`
- `previous_hash`
- `event_hash`

No wall-clock field is included. Logical order is the sequence number.

`event_hash` is SHA-256 over a canonical JSON representation of every event field except `event_hash` itself.

The next event MUST carry the previous event's hash in `previous_hash`.

## 6. Tamper Evidence Boundary

The hash chain detects:

- mutation of existing event content;
- reordering of retained events;
- insertion into the middle without recomputing the remainder;
- sequence discontinuity.

The ledger alone cannot prove that its final line was not deleted. Tail truncation is detectable only when a trusted caller supplies an externally retained `expected_head_hash`.

Therefore:

$$
\boxed{
\text{Hash Chaining}
\neq
\text{Immutable Storage}.
}
$$

## 7. Replay State

Replay derives:

- `subject_id`
- `display_name`
- current explicit will map
- will revision history
- active consents
- revoked consents
- active refusals
- withdrawn refusals
- event count
- head hash

The current state is never edited directly in the ledger file.

## 8. Will Semantics

`will_declared` payload:

```json
{"key":"autonomy","value":"preserve revision"}
```

`will_revised` payload:

```json
{"key":"autonomy","value":"preserve revision and exit"}
```

A revision requires the key to already exist.

The ledger preserves both current value and the event history; current value does not erase prior values.

## 9. Consent / Refusal Semantics

`consent_granted(action)` activates consent and removes that action from `revoked_consents`.

`consent_revoked(action)` requires prior active consent, removes it from active consent, and records it as revoked.

`refusal_recorded(action)` activates refusal.

`refusal_withdrawn(action)` requires an active refusal and removes it from active refusal.

These are time-indexed operational states, not metaphysical will claims.

## 10. Integration With MVP-0

A replayed ledger state can overlay an existing MVP-0 `Scenario` target agent:

- `consents`
- `refusals`
- `revoked_consents`

Agency, agency floor, options, world state, and proposal remain scenario-defined in MVP-1.

A helper:

`evaluate_with_ledger(scenario, ledger_state)`

must replay current governance state into the target agent before calling the unchanged MVP-0 engine.

This preserves all existing invariant behavior.

## 11. CLI

MVP-0 `wpce-harness` remains unchanged.

MVP-1 adds `wpce-ledger` with subcommands:

- `init`
- `will`
- `revise-will`
- `consent`
- `revoke-consent`
- `refuse`
- `withdraw-refusal`
- `verify`
- `show`
- `head`

`verify` exits 0 when valid and 2 when the ledger is invalid or the expected head mismatches.

`show --pretty` emits deterministic JSON snapshot output.

## 12. Error Handling

Malformed ledger or invalid transition raises a domain error with stable text.

Examples:

- event before identity registration;
- second identity registration;
- subject id mismatch;
- sequence gap;
- previous hash mismatch;
- event hash mismatch;
- revise unknown will key;
- revoke inactive consent;
- withdraw inactive refusal.

The implementation never silently repairs history.

## 13. Determinism

Given the same ordered event sequence, the JSONL bytes, event hashes, replayed snapshot, and CLI output MUST be byte-for-byte stable.

No current time, random UUID, or machine-dependent path enters the hash material.

## 14. Testing Strategy

TDD is required.

Tests cover:

- deterministic registration/replay;
- will declaration/revision;
- consent grant/revoke;
- refusal record/withdraw;
- integration with MVP-0 invariant evaluation;
- content tampering detection;
- reorder detection;
- expected-head tail truncation detection;
- deterministic bytes;
- CLI round trip.

All MVP-0 tests remain green.

## 15. Release Definition

MVP-1 is complete when:

- all old + new unit tests pass;
- examples replay deterministically;
- tamper tests fail for the correct reason;
- CLI works without third-party dependencies;
- `compileall` passes;
- clean git tree after verification;
- ZIP CRC passes;
- README clearly states the hash-chain truncation limitation.
