# WPCE MVP-3 Rule-Based Least Sufficient Intervention Recommender — Design

## Status
Approved continuation of the MVP-0 → MVP-1 → MVP-2 roadmap. Scope is intentionally bounded.

## Goal
Build a deterministic recommender that chooses only among a finite, explicitly supplied set of intervention candidates. It must never invent candidates, infer a subject's true will, infer objective satisfaction, or search an unbounded action space.

## Core contract
A recommendation request contains:

- `recommendation_id`
- `objective_id`
- a finite list of candidates

Each candidate contains:

- `candidate_id`
- `objective_status`: `satisfied`, `not_satisfied`, or `unknown`
- `irreversible`: boolean
- one complete existing WPCE `Scenario`

The scenario's proposal is evaluated by the existing eight governance invariants. A candidate is eligible only if:

1. `objective_status == satisfied`
2. existing governance evaluation returns `allowed == true`

The recommender MUST NOT reinterpret `objective_status`.

## Least-sufficient ordering
Eligible candidates are compared by the deterministic impact key:

1. intervention-level rank from existing `INTERVENTION_LEVELS`
2. irreversible flag (`false` before `true`)
3. total negative agency delta magnitude
4. number of explicit option closures (`reachable -> false`) declared by the proposal

This is a v0.1 engineering ordering, not a universal moral metric.

If several candidates share the same minimal impact key, the system returns all as co-minimal and does not select an arbitrary winner.

## Result statuses

- `recommended`: exactly one minimal eligible candidate
- `multiple_co_minimal`: two or more equally minimal eligible candidates
- `no_legal_sufficient_candidate`: no candidate is both governance-allowed and explicitly objective-satisfied

Every candidate receives an audit record containing:

- governance allow/block result
- governance violations
- objective status
- eligibility
- impact key when eligible
- exclusion reason when ineligible

## Ledger integration
MVP-3 can optionally replay the existing subject ledger and world ledger before evaluating every candidate. The same replayed states are applied to each candidate scenario. This allows revoked consent, refusal, agency floors, option reachability, and unresolved conflict history to affect the recommendation without adding new ethical inference.

## CLI
Add `wpce-recommend`.

Input: one recommendation-request JSON file.
Optional:

- `--subject-ledger PATH`
- `--world-ledger PATH`
- `--expected-subject-head HASH`
- `--expected-world-head HASH`
- `--pretty`

Exit codes:

- `0`: exactly one recommendation
- `3`: no legal sufficient candidate
- `4`: multiple co-minimal candidates
- `1`: malformed input / ledger verification / runtime error

## Non-goals

MVP-3 does NOT:

- generate interventions
- infer objective satisfaction
- infer true preferences
- aggregate multi-subject utilities
- resolve moral dilemmas
- prove subjecthood
- perform probabilistic planning
- call an LLM
- access network services
- use a database

## Files

Create:

- `src/wpce_harness/recommender.py`
- `src/wpce_harness/recommender_io.py`
- `src/wpce_harness/recommender_cli.py`
- `tests/test_recommender.py`
- `tests/test_recommender_io.py`
- `tests/test_recommender_cli.py`
- `scripts/demo_mvp3.py`
- `recommendations/example_recommendation.json`

Modify:

- `pyproject.toml`
- `README.md`

## Verification

- All MVP-0/1/2 regression tests remain green.
- TDD red/green evidence for recommender core, parser, ledger integration, and CLI.
- Example recommendation deterministically selects a lower-impact legal sufficient candidate.
- A revoked-consent ledger can remove an otherwise eligible candidate.
- Equal impact produces `multiple_co_minimal`, never arbitrary winner selection.
- `compileall`, `git diff --check`, SHA manifest, clean tree, ZIP CRC all pass before release.
