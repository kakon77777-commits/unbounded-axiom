# WPCE Deterministic Governance Harness MVP-0 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: use test-driven development task-by-task; verify the full suite before claiming completion.

**Goal:** Build a deterministic Python harness that executes seven WPCE v0.1 governance invariants over explicit JSON scenarios and emits stable pass/fail audit output.

**Architecture:** Pure dataclasses model declared state; seven pure invariant functions evaluate one proposal; a small engine aggregates results; JSON I/O and a CLI provide reproducible demonstrations. No LLM, network, database, randomness, or third-party runtime dependency.

**Tech Stack:** Python 3.11+ standard library (`dataclasses`, `json`, `argparse`, `unittest`).

**Spec:** `docs/superpowers/specs/2026-08-23-wpce-mvp0-design.md`

## Global Constraints

- Exactly seven executable invariants in MVP-0.
- Deterministic output and fixed check order.
- No hidden-will inference or subjecthood inference.
- No third-party runtime dependencies.
- Tests are written and observed failing before production implementation.

---

### Task 1: Core models and baseline engine

**Files:** create `tests/test_engine.py`, `src/wpce_harness/models.py`, `src/wpce_harness/engine.py`, `src/wpce_harness/invariants.py`, `src/wpce_harness/__init__.py`.

- [ ] Write a failing baseline test requiring a valid declared-consent / low-impact proposal to be allowed and to return seven audit checks.
- [ ] Run the test and verify failure because production package does not exist.
- [ ] Implement minimal dataclasses, check result types, seven check function stubs with correct baseline behavior, and fixed-order evaluation.
- [ ] Run the baseline test and verify pass.

### Task 2: Consent, refusal, and revocation invariants

**Files:** modify `tests/test_engine.py`, `src/wpce_harness/invariants.py`.

- [ ] Add failing tests for prediction-only consent, explicit refusal, and revoked consent.
- [ ] Run and verify those tests fail for the intended missing behaviors.
- [ ] Implement `PREDICTION_NOT_PERMISSION`, `REFUSAL_EFFECTIVE`, and `REVOCATION_EFFECTIVE` minimally.
- [ ] Run the focused tests and then the suite.

### Task 3: Possibility and multi-subject invariants

**Files:** modify `tests/test_engine.py`, `src/wpce_harness/invariants.py`.

- [ ] Add failing tests for substantive option collapse and agency-floor erasure.
- [ ] Verify failures.
- [ ] Implement `SUBSTANTIVE_OPTIONS_REQUIRED` and `MUTUAL_NON_ERASURE`.
- [ ] Run focused and full tests.

### Task 4: Intervention strength and emergency authority-return invariants

**Files:** modify `tests/test_engine.py`, `src/wpce_harness/invariants.py`.

- [ ] Add failing tests for root rewrite when `inform` is sufficient and emergency override after emergency resolution.
- [ ] Verify failures.
- [ ] Implement `LEAST_SUFFICIENT_INTERVENTION` and `AUTHORITY_RETURN_AFTER_EMERGENCY`.
- [ ] Run focused and full tests.

### Task 5: Scenario JSON I/O and CLI

**Files:** create `tests/test_scenario_io.py`, `src/wpce_harness/scenario_io.py`, `src/wpce_harness/cli.py`, `src/wpce_harness/__main__.py`.

- [ ] Write failing parse/CLI-behavior tests for a valid scenario and malformed intervention level.
- [ ] Verify failures.
- [ ] Implement strict JSON parsing, intervention-level validation, and deterministic CLI JSON output.
- [ ] Run focused and full tests.

### Task 6: Demonstration scenarios and documentation

**Files:** create `scenarios/*.json`, `README.md`, `pyproject.toml`.

- [ ] Add one passing baseline and seven single-invariant failing scenarios.
- [ ] Run each scenario through the CLI and verify the expected single violation code.
- [ ] Document install/run/test commands, explicit non-goals, and mapping from invariant code to WPCE concept.
- [ ] Run the full test suite and all scenario smoke tests.

### Task 7: Release verification and source pack

**Files:** create `VALIDATION.md`, `SHA256SUMS.txt`, release ZIP.

- [ ] Run `python -m unittest discover -s tests -v`.
- [ ] Run all JSON scenarios and verify deterministic expected verdicts.
- [ ] Run Python bytecode compilation over `src`.
- [ ] Generate hashes and a ZIP; verify ZIP CRC.
- [ ] Record exact verification results without claiming broader ethical correctness.
