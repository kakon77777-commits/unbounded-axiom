# WPCE MVP-1 Identity/Will Ledger Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Build a deterministic per-identity append-only JSONL ledger whose replayed consent/refusal state can drive the existing WPCE MVP-0 governance engine.

**Architecture:** Keep MVP-0 engine/invariants unchanged. Add a hash-chained ledger domain module, JSONL file store, replay-to-current-state model, engine overlay helper, and a separate `wpce-ledger` CLI. One file represents one stable identity; no wall-clock time or randomness is used.

**Tech Stack:** Python >=3.11 standard library only, `dataclasses`, `json`, `hashlib`, `argparse`, `unittest`.

**Spec:** `docs/superpowers/specs/2026-08-23-wpce-mvp1-ledger-design.md`

## Global Constraints

- No LLM/model/API/network calls.
- No database dependency.
- One ledger file per stable identity.
- JSONL is canonical UTF-8 with LF newlines.
- Hash material contains no wall-clock time or random values.
- Existing `wpce-harness` CLI and seven MVP-0 invariants remain behavior-compatible.
- Never silently repair or rewrite invalid history.

---

### Task 1: Ledger Core and Deterministic Hash Chain

**Files:**
- Create: `src/wpce_harness/ledger.py`
- Test: `tests/test_ledger.py`

**Interfaces:**
- Produces: `LedgerEvent`, `LedgerState`, `LedgerError`, `make_event(...)`, `replay_events(...)`, `verify_events(...)`

- [x] **Step 1: Write failing registration/replay tests**
- [x] **Step 2: Run `PYTHONPATH=src python -m unittest tests.test_ledger -v` and verify RED**
- [x] **Step 3: Implement minimal canonical hash envelope and identity replay**
- [x] **Step 4: Re-run and verify GREEN**
- [x] **Step 5: Commit**

### Task 2: Will / Consent / Refusal / Revision Transitions

**Files:**
- Modify: `src/wpce_harness/ledger.py`
- Modify: `tests/test_ledger.py`

**Interfaces:**
- Consumes: `LedgerEvent`, `LedgerState`, `make_event`, `replay_events`
- Produces: the seven event transition semantics from the spec

- [x] **Step 1: Add failing transition tests**
- [x] **Step 2: Verify RED**
- [x] **Step 3: Implement minimum valid transitions**
- [x] **Step 4: Verify GREEN**
- [x] **Step 5: Commit**

### Task 3: JSONL Store and Tamper Verification

**Files:**
- Create: `src/wpce_harness/ledger_io.py`
- Test: `tests/test_ledger_io.py`

**Interfaces:**
- Produces: `init_ledger(path, subject_id, display_name)`, `append_ledger_event(path, event_type, payload)`, `load_ledger(path)`, `verify_ledger(path, expected_head_hash=None)`

- [x] **Step 1: Add failing file round-trip and tamper tests**
- [x] **Step 2: Verify RED**
- [x] **Step 3: Implement canonical JSONL storage and verification**
- [x] **Step 4: Verify GREEN including expected-head truncation detection**
- [x] **Step 5: Commit**

### Task 4: Governance Engine Integration

**Files:**
- Create: `src/wpce_harness/ledger_integration.py`
- Modify: `tests/test_engine.py`

**Interfaces:**
- Produces: `scenario_with_ledger_state(scenario, state)`, `evaluate_with_ledger(scenario, state)`

- [x] **Step 1: Add failing test showing revoked consent from replay blocks MVP-0 action**
- [x] **Step 2: Verify RED**
- [x] **Step 3: Implement target-agent overlay and evaluation helper**
- [x] **Step 4: Verify GREEN and all existing engine tests**
- [x] **Step 5: Commit**

### Task 5: Ledger CLI

**Files:**
- Create: `src/wpce_harness/ledger_cli.py`
- Modify: `pyproject.toml`
- Test: `tests/test_ledger_cli.py`

**Interfaces:**
- Produces console script `wpce-ledger = wpce_harness.ledger_cli:main`

- [x] **Step 1: Add failing CLI init/append/show/verify tests**
- [x] **Step 2: Verify RED**
- [x] **Step 3: Implement argparse subcommands from the spec**
- [x] **Step 4: Verify GREEN**
- [x] **Step 5: Commit**

### Task 6: Examples, Documentation, and Release Verification

**Files:**
- Create: `ledgers/alice_history.jsonl`
- Create: `scripts/demo_mvp1.py`
- Modify: `README.md`
- Modify: `VALIDATION.md`

**Interfaces:**
- Demonstrates: declaration -> consent -> revocation -> refusal -> withdrawal -> will revision -> replay -> engine evaluation

- [x] **Step 1: Create deterministic example via public API/CLI**
- [x] **Step 2: Run full unit suite and example replay**
- [x] **Step 3: Run `compileall`, deterministic byte comparison, git cleanliness checks**
- [x] **Step 4: Build SourcePack ZIP and run CRC verification**
- [x] **Step 5: Record SHA-256 and final validation evidence**
