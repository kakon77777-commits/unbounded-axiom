# WPCE MVP-3 Least Sufficient Intervention Recommender Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a deterministic finite-candidate least-sufficient intervention recommender on top of MVP-2 governance evaluation and ledgers.

**Architecture:** Parse an explicit recommendation request containing full candidate scenarios. Evaluate each candidate through existing invariants, optionally after replaying subject/world ledgers, then rank only governance-allowed and explicitly objective-satisfied candidates using a transparent lexicographic impact key. Exact impact ties remain ties.

**Tech Stack:** Python 3.11+ standard library, `dataclasses`, `json`, `argparse`, `unittest`.

**Spec:** `docs/superpowers/specs/2026-08-23-wpce-mvp3-lsi-recommender-design.md`

## Global Constraints

- No network calls, LLMs, databases, or external Python dependencies.
- Do not infer objective satisfaction; accept only explicit `objective_status`.
- Do not generate intervention candidates.
- Preserve all MVP-0/1/2 behavior and tests.
- Exact score ties must not be broken arbitrarily.
- All user-visible audit output must be deterministic JSON.

---

### Task 1: Core recommendation model and ranking

**Files:**
- Create: `src/wpce_harness/recommender.py`
- Test: `tests/test_recommender.py`

**Interfaces:**
- Produces: `InterventionCandidate`, `CandidateAudit`, `RecommendationResult`, `recommend(request)`.

- [ ] Write failing tests for single minimal recommendation, blocked candidate exclusion, unsatisfied/unknown exclusion, no eligible candidate, and exact co-minimal tie.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_recommender -v` and verify RED because `wpce_harness.recommender` does not exist.
- [ ] Implement minimal dataclasses, eligibility audit, impact-key calculation, and deterministic result assembly.
- [ ] Re-run the focused tests and verify GREEN.
- [ ] Run full suite.

### Task 2: Recommendation JSON parser

**Files:**
- Create: `src/wpce_harness/recommender_io.py`
- Test: `tests/test_recommender_io.py`

**Interfaces:**
- Consumes: existing `scenario_from_dict`.
- Produces: `recommendation_request_from_dict(data)` and `load_recommendation_request(path)`.

- [ ] Write failing tests for valid parsing, duplicate candidate IDs, empty candidate list, and invalid objective status.
- [ ] Verify focused RED because parser module does not exist.
- [ ] Implement strict parser using existing scenario parser for each candidate's full scenario.
- [ ] Verify focused GREEN and full suite.

### Task 3: Subject/world ledger integration

**Files:**
- Modify: `src/wpce_harness/recommender.py`
- Test: `tests/test_recommender.py`

**Interfaces:**
- Produces: `recommend_with_ledgers(request, subject_state=None, world_state=None)`.

- [ ] Write a failing test where a candidate is eligible in snapshot state but becomes blocked after replayed consent revocation.
- [ ] Verify RED.
- [ ] Apply existing `scenario_with_ledger_state` and `scenario_with_world_ledger_state` before candidate evaluation.
- [ ] Verify GREEN and full suite.

### Task 4: CLI

**Files:**
- Create: `src/wpce_harness/recommender_cli.py`
- Create or modify entry point in: `pyproject.toml`
- Test: `tests/test_recommender_cli.py`

**Interfaces:**
- CLI: `wpce-recommend REQUEST.json [--subject-ledger ...] [--world-ledger ...] [--expected-subject-head ...] [--expected-world-head ...] [--pretty]`.

- [ ] Write failing CLI tests for exit `0`, `3`, and `4`, plus ledger-driven blocking.
- [ ] Verify RED.
- [ ] Implement CLI with existing ledger verification/load helpers.
- [ ] Verify GREEN and full suite.

### Task 5: Example and documentation

**Files:**
- Create: `recommendations/example_recommendation.json`
- Create: `scripts/demo_mvp3.py`
- Modify: `README.md`

- [ ] Add one deterministic example with at least three candidates: insufficient, legal+sufficient low-impact, legal+sufficient high-impact.
- [ ] Add demo that prints the recommendation audit.
- [ ] Document schema, statuses, exit codes, ranking key, and explicit non-goals.
- [ ] Run demo twice and compare bytes for determinism.

### Task 6: Release verification

**Files:**
- Create/update: `VALIDATION.md`, `SHA256SUMS.txt`, `RELEASE_COMMIT.txt`

- [ ] Run full unit suite.
- [ ] Run all eight legacy scenarios.
- [ ] Run MVP-1, MVP-2, and MVP-3 demos.
- [ ] Verify expected-head behavior for subject and world ledgers.
- [ ] Run `python -m compileall src tests scripts` then remove `__pycache__`/`.pyc`.
- [ ] Run `git diff --check` and verify clean tree after release commit.
- [ ] Recompute SHA-256 manifest.
- [ ] Build ZIP excluding `.git`, bytecode caches, and temporary files.
- [ ] Run ZIP CRC test and publish ZIP SHA-256.
