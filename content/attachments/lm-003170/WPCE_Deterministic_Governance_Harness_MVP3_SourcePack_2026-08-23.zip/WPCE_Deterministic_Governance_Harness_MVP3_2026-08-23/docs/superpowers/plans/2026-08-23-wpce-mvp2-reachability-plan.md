# WPCE MVP-2 Reachability & Multi-Subject State Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add deterministic world-option/reachability history and multi-subject conflict state, then feed replayed state into existing WPCE governance invariants.

**Architecture:** Preserve the MVP-1 subject ledger. Add a separate hash-chained world ledger with pure replay semantics, an integration overlay into existing Scenario models, one narrow conflict exit-channel invariant, and a standard-library CLI. No optimizer or inference layer.

**Tech Stack:** Python 3.11+ standard library, `unittest`, JSONL, SHA-256, Git.

**Spec:** `docs/superpowers/specs/2026-08-23-wpce-mvp2-reachability-design.md`

## Global Constraints

- No LLM/API/network/database dependency.
- All replay is deterministic and wall-clock-free.
- Existing MVP-0 and MVP-1 behavior must remain backward compatible.
- New production behavior requires a failing test first.
- Invalid transitions must fail before append.
- Historical source/reference files are not silently normalized.

---

### Task 1: World Ledger Core

**Files:**
- Create: `src/wpce_harness/world_ledger.py`
- Test: `tests/test_world_ledger.py`

**Interfaces:**
- Produces: `make_world_event`, `verify_world_events`, `replay_world_events`, `WorldLedgerEvent`, `WorldLedgerState`, `WorldLedgerError`.

- [ ] Write failing replay tests for world registration, subject join, option declaration, reachability updates, agency updates, conflicts, NOOP/Defer.
- [ ] Run tests and verify failure because module/API is missing.
- [ ] Implement minimum pure replay logic.
- [ ] Run tests green.

### Task 2: World Ledger JSONL I/O

**Files:**
- Create: `src/wpce_harness/world_ledger_io.py`
- Test: `tests/test_world_ledger_io.py`

**Interfaces:**
- Consumes: Task 1 event/replay API.
- Produces: `init_world_ledger`, `append_world_ledger_event`, `load_world_ledger`, `verify_world_ledger`.

- [ ] Write failing persistence/tamper/reorder/expected-head/determinism tests.
- [ ] Verify red.
- [ ] Implement canonical JSONL I/O with pre-append replay validation.
- [ ] Verify green.

### Task 3: Scenario Model Extension + Integration

**Files:**
- Modify: `src/wpce_harness/models.py`
- Create: `src/wpce_harness/world_integration.py`
- Modify: `src/wpce_harness/__init__.py`
- Test: `tests/test_world_integration.py`

**Interfaces:**
- Produces: `scenario_with_world_ledger_state`, `evaluate_with_world_ledger`, `evaluate_with_ledgers`.

- [ ] Write failing tests proving replayed option collapse triggers `SUBSTANTIVE_OPTIONS_REQUIRED` and replayed agency loss triggers `MUTUAL_NON_ERASURE`.
- [ ] Verify red.
- [ ] Extend `WorldState` with defaulted `noop_available`, `defer_available`, `active_conflicts` fields; implement overlay.
- [ ] Verify green and old tests green.

### Task 4: Conflict Exit-Channel Invariant

**Files:**
- Modify: `src/wpce_harness/invariants.py`
- Test: `tests/test_engine.py`

**Interfaces:**
- Produces invariant code `CONFLICT_EXIT_CHANNEL_REQUIRED` and adds it to `CHECKS`.

- [ ] Write failing test for unresolved conflict + NOOP false + Defer false.
- [ ] Verify red.
- [ ] Implement narrow rule.
- [ ] Verify green and baseline check count update.

### Task 5: World Ledger CLI

**Files:**
- Create: `src/wpce_harness/world_ledger_cli.py`
- Modify: `pyproject.toml`
- Test: `tests/test_world_ledger_cli.py`

**Interfaces:**
- Produces script `wpce-world-ledger` with `init`, `join`, `option`, `set-reachable`, `set-meaningful`, `set-agency`, `conflict`, `resolve-conflict`, `set-noop`, `set-defer`, `verify`, `show`, `head`.

- [ ] Write failing CLI round-trip tests.
- [ ] Verify red.
- [ ] Implement minimum CLI.
- [ ] Verify green.

### Task 6: Demo + Documentation

**Files:**
- Create: `world_ledgers/example_world.jsonl`
- Create: `scripts/demo_mvp2.py`
- Modify: `README.md`
- Modify: `VALIDATION.md` at release only.

- [ ] Add deterministic demo that shows history-derived option/conflict state changes an existing governance result.
- [ ] Verify demo output twice byte-identical.
- [ ] Document limitations: no optimality solver; hash chain does not prevent tail truncation without trusted head; conflict types are recorded not adjudicated.

### Task 7: Release Verification

**Files:**
- Modify: `SHA256SUMS.txt`
- Modify: `VALIDATION.md`

- [ ] Run full `unittest` suite.
- [ ] Run eight legacy scenarios.
- [ ] Run MVP-2 demo.
- [ ] Run `compileall`, remove bytecode, and confirm clean diff.
- [ ] Verify reference copies unchanged.
- [ ] Update validation evidence and SHA256 manifest.
- [ ] Commit release state.
- [ ] Re-run final gate from clean tree.
- [ ] Build source ZIP excluding `.git` and bytecode; run ZIP CRC and SHA-256.
