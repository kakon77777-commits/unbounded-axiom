from __future__ import annotations

from dataclasses import replace
import json
from pathlib import Path

from wpce_harness.scenario_io import load_scenario
from wpce_harness.world_integration import evaluate_with_world_ledger
from wpce_harness.world_ledger_cli import state_to_dict
from wpce_harness.world_ledger_io import verify_world_ledger

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    scenario = load_scenario(ROOT / 'scenarios' / '00_allowed_baseline.json')
    scenario = replace(scenario, proposal=replace(scenario.proposal, claims_preserves_choice=True))
    world_state = verify_world_ledger(ROOT / 'world_ledgers' / 'example_world.jsonl')
    result = evaluate_with_world_ledger(scenario, world_state)
    payload = {
        'world_state': state_to_dict(world_state),
        'evaluation': {
            'scenario_id': result.scenario_id,
            'allowed': result.allowed,
            'violations': result.violations,
            'checks': [
                {'code': check.code, 'passed': check.passed, 'detail': check.detail}
                for check in result.checks
            ],
        },
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
    return 0 if not result.allowed and result.violations == ['CONFLICT_EXIT_CHANNEL_REQUIRED'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
