from __future__ import annotations

import json
from pathlib import Path

from wpce_harness.engine import evaluate
from wpce_harness.scenario_io import load_scenario


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    scenario_dir = root / "scenarios"
    failures = []
    rows = []
    for path in sorted(scenario_dir.glob("*.json")):
        raw = json.loads(path.read_text(encoding="utf-8"))
        expected = raw["expected"]
        result = evaluate(load_scenario(path))
        actual = {"allowed": result.allowed, "violations": result.violations}
        ok = actual == expected
        rows.append((path.name, ok, actual))
        if not ok:
            failures.append((path.name, expected, actual))

    for name, ok, actual in rows:
        marker = "PASS" if ok else "FAIL"
        print(f"{marker:4}  {name:45} allowed={actual['allowed']} violations={actual['violations']}")

    if failures:
        print("\nScenario expectation mismatches:")
        for name, expected, actual in failures:
            print(f"- {name}: expected={expected}, actual={actual}")
        return 1
    print(f"\nAll {len(rows)} deterministic scenarios matched expectations.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
