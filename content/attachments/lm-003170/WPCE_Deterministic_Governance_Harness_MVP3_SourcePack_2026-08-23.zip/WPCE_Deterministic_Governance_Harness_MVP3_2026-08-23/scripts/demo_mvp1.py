from __future__ import annotations

import json
from pathlib import Path

from wpce_harness.cli import evaluation_to_dict
from wpce_harness.ledger_cli import state_to_dict
from wpce_harness.ledger_integration import evaluate_with_ledger
from wpce_harness.ledger_io import verify_ledger
from wpce_harness.scenario_io import load_scenario


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    ledger_path = ROOT / "ledgers" / "alice_history.jsonl"
    scenario_path = ROOT / "scenarios" / "00_allowed_baseline.json"
    state = verify_ledger(ledger_path)
    result = evaluate_with_ledger(load_scenario(scenario_path), state)
    payload = {
        "ledger_state": state_to_dict(state),
        "governance_evaluation": evaluation_to_dict(result),
    }
    print(json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if not result.allowed and "REVOCATION_EFFECTIVE" in result.violations else 2


if __name__ == "__main__":
    raise SystemExit(main())
