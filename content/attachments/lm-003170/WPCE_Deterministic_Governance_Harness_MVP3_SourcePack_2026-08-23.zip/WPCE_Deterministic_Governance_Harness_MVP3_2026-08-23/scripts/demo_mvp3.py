from __future__ import annotations

import json
from pathlib import Path

from wpce_harness.recommender import recommend
from wpce_harness.recommender_cli import recommendation_result_to_dict
from wpce_harness.recommender_io import load_recommendation_request


ROOT = Path(__file__).resolve().parents[1]
REQUEST = ROOT / "recommendations" / "example_recommendation.json"


def main() -> int:
    result = recommend(load_recommendation_request(REQUEST))
    print(
        json.dumps(
            recommendation_result_to_dict(result),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
