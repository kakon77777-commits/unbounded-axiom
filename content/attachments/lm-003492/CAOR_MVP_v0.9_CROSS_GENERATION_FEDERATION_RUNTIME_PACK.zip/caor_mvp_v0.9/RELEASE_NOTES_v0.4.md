# CAOR MVP v0.4 Release Notes

## Release

**CAOR MVP v0.4 — Policy-Mediated Development Selection Runtime**

## New

- `DecisionActionKind`
- `DecisionSignalKind`
- `DecisionOperator`
- `DecisionAction`
- `DecisionCondition`
- `DecisionScoreTerm`
- `DecisionCandidate`
- `DecisionPolicy`
- `DecisionContext`
- `PolicySelectionEvidence`
- `PolicyExecutionResult`
- `build_decision_context`
- `select_policy_candidate`
- `apply_policy_selection`
- stale-context execution protection
- policy-selection provenance in development events
- executable `policy_mediated_development.py` demo

## Preserved

- v0.1 initialization / lineage / classifier semantics
- v0.2 append-only development and divergence semantics
- v0.3 counterfactual trajectory semantics
- source proposal-only write boundary
- standard-library-only runtime

## Canonical v0.4 statement

$$
\boxed{
\text{Replayable State + History + Environment + Candidates}
\rightarrow
\text{Deterministic Policy Selection Evidence}.
}
$$

This release does not claim consciousness, subjectivity, autonomy, or free will.
