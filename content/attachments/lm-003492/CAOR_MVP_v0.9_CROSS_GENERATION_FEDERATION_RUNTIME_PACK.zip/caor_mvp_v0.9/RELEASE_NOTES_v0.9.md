# CAOR MVP v0.9.0 Release Notes

## Cross-Generation Federation & Boundary Contract Runtime

CAOR v0.9 extends v0.8 runtime-generation forking with a separate, deterministic federation layer for bounded cooperation between exact immutable generations.

### Added

- `src/caor/federation.py`
- immutable boundary disclosure policies;
- ontology translation profiles that preserve both classifications;
- exact generation-digest-bound boundary proposals;
- dual endpoint technical authorization evidence;
- immutable active boundary contracts;
- append-only ACTIVE / SUSPENDED / REVOKED / EXPIRED lifecycle events;
- capability/authority separation;
- cross-generation protected/admin authority denial;
- deterministic cross-generation request evidence;
- stale descendant generation contract rejection;
- six executable federation demonstrations;
- Defensive Disclosure Clauses 117–136.

### Canonical Distinctions

```text
Interoperability != Ontological Agreement
Capability != Authority
Data Disclosure != Memory Ownership
Translation != Identity Rewrite
Federation != Fusion != Supersession
Technical Authorization != Subjective Consent Proven
```

### Scope

v0.9 does not add network transport, distributed consensus, PKI, legal-contract semantics, subjective-consent detection, automatic generation migration, or ontology convergence.
