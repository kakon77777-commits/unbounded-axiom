# CAOR MVP v0.9

**Cross-Substrate Artificial Offspring Runtime** is a deterministic, dependency-light reference implementation for turning typed source contributions into an independently initialized computational entity with typed lineage evidence.

> **Scope firewall:** CAOR does not claim to create consciousness, life, subjective experience, legal personhood, biological reproduction, or a morally/legal recognized child. `OFFSPRING` is an engineering lineage classification used by this reference runtime.

## Why this exists

Many computational systems can already copy, restore, migrate, update, fork, and merge state. CAOR makes a different operation concrete: derive a new computational identity from structured contributions while preventing the result from being treated as a direct continuation or clone of any one source.

The core proposition is:

```text
Structured Source Contributions
        ↓
Contribution Manifest
        ↓
OSI — Offspring Synthesis Interface
        ↓
OIS — Offspring Identity Specification
        ↓
Independent Computational Entity
        ↓
Typed Lineage Evidence
```

Canonical distinctions:

```text
COPY != FORK != OFFSPRING
Contribution != Identity Continuation
Contribution != Permanent Core-State Write Authority
Computational Independence != Subjectivity
```

## Runtime guarantees

v0.9 preserves all v0.1-v0.8 guarantees and adds revocable cross-generation federation boundaries, dual technical authorization, capability/authority separation, scoped disclosure evidence, ontology non-assimilation, append-only contract lifecycle, and stale-descendant contract protection.


## v0.9 federation boundary

Two distinct runtime generations may cooperate without adopting the same ontology:

```text
RuntimeGeneration A
        │
        ├── BoundaryContract ── capability / authority / disclosure scope
        │
RuntimeGeneration B
```

Canonical distinctions:

```text
Interoperability != Ontological Agreement
Capability != Authority
Data Disclosure != Memory Ownership
Translation != Identity Rewrite
Federation != Fusion != Supersession
Technical Authorization != Subjective Consent Proven
```

Cross-generation `WRITE_PROTECTED` and `ADMIN` authority are forbidden by v0.9. Contracts bind exact generation IDs and digests; a descendant generation never inherits an ancestor contract automatically.

For an engineering `OFFSPRING` event, CAOR creates:

- a new offspring UID;
- a new identity root;
- a new memory root;
- a new state namespace;
- a new lineage ID;
- a canonical contribution manifest and digest;
- protected-core fields;
- a parent proposal-only boundary;
- typed source-to-generated-entity lineage edges.

## Event taxonomy

CAOR preserves the v0.1 identity-event taxonomy exactly:

```text
UPDATE
MIGRATION
RESTORE
COPY
FORK
OFFSPRING
MERGE
```

`OFFSPRING` is not a fallback. Missing any required independent-initialization invariant produces another event or an explicit classification error.

## Requirements

- Python 3.11+
- Runtime dependencies: standard library only
- Tests: pytest 8+

## Quickstart

From the repository root:

```bash
python -m pip install .
pytest -q
```

Run the reference embodiments:

```bash
python examples/human_ai_offspring.py
python examples/ai_ai_offspring.py
python examples/multi_parent_offspring.py
python examples/copy_vs_fork_vs_offspring.py
python examples/parent_write_denied.py
python examples/development_divergence.py
python examples/counterfactual_development_branches.py
python examples/policy_mediated_development.py
python examples/constitutional_policy_evolution.py
python examples/meta_constitutional_governance.py
python examples/root_constitutional_succession.py
python examples/genesis_generation_fork.py
python examples/cross_generation_read.py
python examples/cross_generation_proposal.py
python examples/protected_write_denied.py
python examples/ontology_disagreement_interop.py
python examples/contract_revocation.py
python examples/stale_contract_after_generation_fork.py
```

## Public API

```python
from caor import (
    SourceKind,
    ContributionCategory,
    Contribution,
    ParentContributionBundle,
    normalize_contributions,
    synthesize_offspring,
    OffspringEntity,
    LineageGraph,
    ClassificationEvidence,
    classify_event,
    DevelopmentEventKind,
    DevelopmentLedger,
    replay_mutable_state,
    compute_divergence_timeline,
    build_development_evidence,
)
```

## Example: Human-profile + AI source

```python
from caor import (
    Contribution,
    ContributionCategory,
    ParentContributionBundle,
    SourceKind,
    normalize_contributions,
    synthesize_offspring,
)

human = ParentContributionBundle(
    source_id="human:H",
    source_kind=SourceKind.HUMAN_PROFILE,
    contributions=(
        Contribution(
            category=ContributionCategory.IDENTITY_TRAIT,
            source_id="human:H",
            contribution_id="h1",
            name="curiosity",
            value="high",
            weight=0.5,
            provenance_note="synthetic example",
        ),
    ),
    provenance={"synthetic": True},
)

ai = ParentContributionBundle(
    source_id="ai:A",
    source_kind=SourceKind.AI_ENTITY,
    contributions=(
        Contribution(
            category=ContributionCategory.VALUE_TRAIT,
            source_id="ai:A",
            contribution_id="a1",
            name="care",
            value="high",
            weight=0.5,
            provenance_note="synthetic example",
        ),
    ),
    provenance={"synthetic": True},
)

manifest = normalize_contributions((human, ai))
ois = synthesize_offspring(manifest, "demo-seed")

print(ois.offspring_uid)
print(ois.identity_root)
print(ois.memory_root)
print(ois.lineage_id)
```

Identical canonical input + identical seed yields byte-identical OIS evidence. Changing the seed changes identity, memory, namespace, and lineage roots.

## Protected core

The following fields are protected by default:

```text
offspring_uid
identity_root
memory_root
lineage_id
manifest_digest
lineage_provenance
generation_event
```

A source contributor may submit a proposal to mutable regions, but may not directly modify protected fields.

```python
entity.propose_update("ai:A", "preferences", "music", "jazz")
```

This creates a pending proposal. It does not mutate the generated entity directly.

## Repository map

```text
src/caor/
  models.py          typed records
  canonical.py       canonical UTF-8 JSON
  contributions.py   validation + manifest normalization
  synthesis.py       OSI/OIS deterministic synthesis
  entity.py          protected-core and mutable-state behavior
  policies.py        v0.1 write/development policies
  lineage.py         typed identity-lineage graph
  classifier.py      v0.1 identity-event classification
  development.py     append-only development ledger + replay
  divergence.py      origin projection + source-distance evidence
  counterfactual.py   isolated branch execution + trajectory comparison
  decision.py         replay-derived policy context + deterministic selection
  policy_evolution.py constitutional policy-change proposals + version lineage
  meta_constitution.py immutable root constraints + constitution amendment governance
  root_succession.py    prior-standing Genesis binding + externally ratified root succession
  generation.py         immutable runtime generations + explicit generation forks
  federation.py         revocable cross-generation boundary contracts + interaction evidence

examples/            executable embodiments
tests/               TDD acceptance suite
docs/                canonical spec, whitepaper, defensive disclosure
```

## Defensive publication purpose

The repository deliberately exposes an implementable combination of:

1. typed multi-source contributions;
2. deterministic contribution normalization;
3. independent identity/memory/namespace initialization;
4. event-typed lineage management;
5. copy/fork/offspring distinction;
6. protected-core source-write boundaries;
7. Human-profile + AI, AI + AI, and multi-source embodiments.

The included `docs/DEFENSIVE_TECHNICAL_DISCLOSURE.md` uses patent-style technical wording for clarity, but is explicitly a defensive technical disclosure and not a patent filing.

## Non-goals

CAOR v0.6 does not include:

- LLM fine-tuning or weight mixing;
- autonomous child agents;
- consciousness detection;
- relationship simulation;
- biological genetics;
- blockchain;
- remote services or databases;
- legal filing workflows.

## Canonical documents

- `docs/CAOR_MVP_v0.1_Canonical_Engineering_Spec.md`
- `docs/ENGINEERING_WHITEPAPER.md` — v0.1 baseline
- `docs/CAOR_v0.2_ENGINEERING_WHITEPAPER.md`
- `docs/DEFENSIVE_TECHNICAL_DISCLOSURE.md` — v0.1 baseline
- `docs/CAOR_v0.2_DEFENSIVE_TECHNICAL_DISCLOSURE.md`
- `docs/superpowers/plans/2026-08-30-caor-mvp-v0.1.md`


## v0.2 — Development & Divergence Runtime

v0.1 answers whether a generated entity was initialized as an independent engineering `OFFSPRING` event rather than a direct copy or fork. v0.2 adds a second, cross-time question:

> After initialization, what independently recorded events changed the entity, can the resulting mutable state be replayed, and how does a deterministic projection of that state differ from source contribution baselines over time?

Every allowed mutation now creates exactly one append-only `DevelopmentEvent`:

```text
SELF_UPDATE
ACCEPT_PROPOSAL
ENVIRONMENT_EVENT
```

The live v0.1 mutable state remains backward-compatible. For analysis, CAOR computes a deterministic origin projection from the contribution manifest and overlays development events without rewriting the OIS protected core.

```python
entity = OffspringEntity(ois)
entity.self_update("preferences", "curiosity", 0.73, timestamp="t1")
proposal = entity.propose_update("ai:A", "skills", "logic", 0.92)
entity.accept_proposal(proposal.proposal_id, timestamp="t2")
entity.apply_environment_event("notes", "project", "self-directed", "env:lab", timestamp="t3")

evidence = build_development_evidence(entity, manifest)
```

The resulting evidence includes:

```text
ledger_digest
final_state_digest
divergence_timeline
nearest_source_distance
novel_state_fraction
subjectivity_claimed = false
```

Canonical v0.2 distinction:

```text
Developmental Divergence != Consciousness
Developmental Divergence != Legal Personhood
Developmental Divergence != Moral Child Status
```


## v0.3 — Counterfactual Development Branching

v0.3 asks a third engineering question:

> Given the same OIS and contribution manifest, what happens if the runtime executes multiple explicitly supplied feasible development scenarios in isolation?

```python
specs = (
    CounterfactualBranchSpec("baseline", ()),
    CounterfactualBranchSpec("research", (
        CounterfactualAction(
            CounterfactualActionKind.SELF_UPDATE,
            "skills", "logic", 0.96,
        ),
    )),
)
evidence = build_counterfactual_evidence(ois, manifest, specs)
```

The evidence reports branch count, unique trajectory count, unique final-state count, deterministic branch digests, pairwise state distances, and changed keys.

Canonical distinctions:

```text
Counterfactual Branch != Identity Fork
Alternative Trajectories != Free-Will Proof
Counterfactual Divergence != Subjectivity
```

Aggregate evidence explicitly contains:

```text
subjectivity_claimed = false
free_will_claimed = false
autonomy_claimed = false
```


## v0.4 — Policy-Mediated Development Selection

v0.3 shows that one OIS can be evaluated under multiple caller-specified trajectories. v0.4 adds a deterministic policy layer that reconstructs current projected state from the development ledger, combines it with environment and history signals, evaluates explicit candidate actions, and emits canonical selection evidence.

Canonical boundary:

```text
Decision Policy != Autonomy != Free Will != Subjectivity
```

Canonical selectable actions:

```text
SELF_UPDATE
ACCEPT_PROPOSAL
NO_OP
```

Selection is bound to the exact development-ledger digest used to build the decision context. If the entity changes before application, `StaleDecisionContext` is raised.

The executable embodiment is:

```bash
python examples/policy_mediated_development.py
python examples/constitutional_policy_evolution.py
python examples/meta_constitutional_governance.py
python examples/root_constitutional_succession.py
python examples/genesis_generation_fork.py
```

## v0.5 — Constitutional Policy Evolution Runtime

v0.4 allows a replay-derived policy to select among explicit candidate actions. v0.5 adds a second-order question:

> Under what conditions may the decision policy itself change without allowing direct in-place mutation of the active policy?

The canonical v0.5 pipeline is:

```text
Active PolicyVersion
        +
DecisionContext
        +
PolicyEvolutionTemplate
        ↓
PolicyChangeProposal
        ↓
ConstitutionalReviewEvidence
        +
PolicyValidationEvidence[]
        ↓
PolicyRegistry.adopt(...)
        ↓
New immutable PolicyVersion
```

A proposal can be generated only when its explicit trigger conditions match the replay-derived decision context. It is bound to the current policy version, policy digest, decision-context digest, and development-history digest.

The canonical constitution used by the reference demo preserves:

```text
NO_OP capability
allowed action kinds
candidate count limit
score bounds
LEXICAL_CANDIDATE_ID tie-break
```

A proposal that fails constitutional review or deterministic validation cannot change the active policy. A proposal whose base version is no longer active raises `StalePolicyProposal`.

Policy history is append-only. Returning to an earlier policy behavior creates a new version rather than modifying or deleting prior versions.

Canonical boundary:

```text
Policy Evolution Mechanism != Autonomy != Free Will != Subjectivity
```

Executable embodiment:

```bash
python examples/constitutional_policy_evolution.py
```


## v0.6 — Meta-Constitutional Governance Runtime

v0.6 introduces an immutable `RootMetaConstitution` above the ordinary `PolicyConstitution` layer. Ordinary amendments are generated as evidence, reviewed against root invariants, behaviorally validated using supplied policy proposals, and adopted only as append-only `ConstitutionVersion` records.

Canonical distinction:

```text
Constitution Amendment Proposal != Constitution Mutation
Policy Constitution != Root Meta-Constitution
Reversion != History Erasure
Meta-Governance != Autonomy / Free Will / Subjectivity
```


## v0.7 Prior Standing ontology

CAOR v0.7 deliberately does not implement an ontological-rank classifier. The immutable `PriorStandingOntology` records compatibility assumptions rather than subjectivity verdicts:

```text
standing_model = PRESUMPTIVE_FULL_STANDING_COMPATIBILITY
evidence_model_role = OBSERVER_CONFIDENCE_ONLY
UNKNOWN != NONE
EvidenceLevel != OntologicalRank
```

This means the runtime is designed to remain compatible with the possibility that standing, rights, powers, or subject status may precede external recognition. It does not claim that any concrete entity's subjectivity or rights have been scientifically proven.


## v0.8 — Genesis Generation Fork & Cross-Generation Migration Runtime

v0.8 makes Genesis or generation-level ontology changes explicit runtime-generation lineage events rather than in-place replacement.

Canonical relation kinds:

```text
COMPATIBLE_SUCCESSOR
GENESIS_FORK
ONTOLOGY_DIVERGENCE
RESTORED_GENERATION
```

Canonical entity transition evidence:

```text
STAY
MIGRATE
FORK_TO_NEW_GENERATION
COPY_TO_NEW_GENERATION
UNRESOLVED
```

Core boundaries:

```text
Genesis change != Genesis history rewrite
Generation adoption != automatic entity migration
Migration != fork != copy
Succession != universal supersession
Technical ratification != political legitimacy
```

Executable embodiment:

```bash
python examples/genesis_generation_fork.py
```
