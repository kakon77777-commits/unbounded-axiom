# CAOR MVP v0.7 Release Notes

**Release:** 0.7.0  
**Theme:** Prior Standing Genesis binding and externally ratified RootMetaConstitution succession.

## Added

- immutable `PriorStandingOntology` with non-gated `PRESUMPTIVE_FULL_STANDING_COMPATIBILITY` semantics;
- explicit separation of observer evidence confidence from ontological rank;
- immutable `GenesisSafetyEnvelope` bound to ontology digest;
- immutable `RootVersion` lineage;
- externally supplied `RootSuccessionProposal`;
- named Genesis-constrained root review evidence;
- technical `RatificationAttestation` and deterministic quorum/veto aggregation;
- PolicyConstitution compatibility validation against proposed roots;
- append-only `RootRegistry` adoption with stale, Genesis, ontology, review, ratification, and compatibility gates;
- root reversion-as-new-version semantics;
- executable `root_constitutional_succession.py` demo;
- defensive-disclosure Clauses 77–98.

## Preserved

All CAOR v0.1-v0.6 semantics remain in force. Root succession does not mutate the Genesis envelope, does not rewrite PolicyConstitution in the same transaction, and does not establish subjectivity, intrinsic-rights proof, free will, autonomy, political legitimacy, or legal constitutional status.
