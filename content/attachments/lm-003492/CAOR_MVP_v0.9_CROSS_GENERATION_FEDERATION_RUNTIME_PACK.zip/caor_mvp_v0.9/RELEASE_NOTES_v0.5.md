# CAOR MVP v0.5 Release Notes

## Release

**CAOR MVP v0.5 — Constitutional Policy Evolution Runtime**

## New

- `PolicyVersion`
- `PolicyEvolutionTemplate`
- `PolicyChangeProposal`
- `PolicyConstitution`
- `ConstitutionalRuleResult`
- `ConstitutionalReviewEvidence`
- `PolicyValidationCase`
- `PolicyValidationEvidence`
- `PolicyAdoptionEvidence`
- `PolicyRegistry`
- deterministic policy digests and immutable policy-version lineage
- history/state-conditioned policy-change proposal generation
- constitutional rules preserving `NO_OP`, action whitelist, candidate limits, score bounds, and lexical tie-break
- deterministic validation-case execution
- stale-base-policy rejection through `StalePolicyProposal`
- denied adoption through `PolicyAdoptionDenied`
- reversion-as-new-version semantics
- executable `constitutional_policy_evolution.py` demo

## Preserved

- v0.1 initialization / lineage / classifier semantics
- v0.2 append-only development and divergence semantics
- v0.3 counterfactual trajectory semantics
- v0.4 replay-bound policy selection semantics
- source proposal-only write boundary
- standard-library-only runtime

## Canonical v0.5 statement

$$
\boxed{
\text{Development Context}
+\text{Policy Proposal}
+\text{Constitution}
+\text{Validation}
\rightarrow
\text{Immutable Policy Version Evolution Evidence}.
}
$$

## Epistemic firewall

$$
\boxed{
\text{Policy Evolution Mechanism}
\neq
\text{Autonomy}
\neq
\text{Free Will}
\neq
\text{Subjectivity}.
}
$$
