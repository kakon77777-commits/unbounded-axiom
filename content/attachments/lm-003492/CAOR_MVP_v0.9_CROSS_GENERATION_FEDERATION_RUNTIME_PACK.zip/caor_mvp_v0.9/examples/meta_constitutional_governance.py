import json

import caor


def _manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(
                    caor.ContributionCategory.IDENTITY_TRAIT,
                    "human:H",
                    "h-curiosity",
                    "curiosity",
                    0.5,
                    1.0,
                    "synthetic demo",
                ),
            ),
            provenance={"demo": True},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(
                    caor.ContributionCategory.CAPABILITY_TRAIT,
                    "ai:A",
                    "a-logic",
                    "logic",
                    0.9,
                    1.0,
                    "synthetic demo",
                ),
            ),
            provenance={"demo": True},
        ),
    ))


def _root_meta():
    return caor.create_root_meta_constitution(
        root_id="root:caor-v0.6-demo",
        root_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=64,
        min_score_term_floor=-1000.0,
        max_score_term_ceiling=1000.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )


def _constitution(version: int, max_candidate_count: int = 32, require_noop_candidate: bool = True):
    return caor.create_policy_constitution(
        constitution_id="constitution:caor-demo",
        constitution_version=version,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=require_noop_candidate,
        max_candidate_count=max_candidate_count,
        min_score_term=-100.0,
        max_score_term=100.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )


def _noop_policy(policy_id="policy:noop"):
    return caor.DecisionPolicy(
        policy_id=policy_id,
        candidates=(
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def _policy_proposal(offspring_uid: str, context: caor.DecisionContext):
    version = caor.create_initial_policy_version(_noop_policy("policy:base"), created_at="t0")
    template = caor.PolicyEvolutionTemplate(
        template_id="policy:validation-proposal",
        trigger_conditions=(),
        proposed_policy=_noop_policy("policy:validation-noop"),
        rationale={"purpose": "constitution validation"},
    )
    proposal = caor.generate_policy_change_proposal(offspring_uid, version, context, template)
    if proposal is None:
        raise RuntimeError("expected policy validation proposal")
    return proposal


def _amendment(
    offspring_uid: str,
    current: caor.ConstitutionVersion,
    root: caor.RootMetaConstitution,
    context: caor.DecisionContext,
    proposed: caor.PolicyConstitution,
    template_id: str,
):
    template = caor.ConstitutionAmendmentTemplate(
        template_id=template_id,
        trigger_conditions=(),
        proposed_constitution=proposed,
        rationale={"purpose": template_id},
    )
    amendment = caor.generate_constitution_amendment_proposal(
        offspring_uid,
        current,
        root,
        context,
        template,
    )
    if amendment is None:
        raise RuntimeError("expected amendment proposal")
    return amendment


def main() -> dict:
    manifest = _manifest()
    ois = caor.synthesize_offspring(manifest, "meta-constitutional-governance-demo")
    context = caor.build_decision_context(ois, manifest, (), {"phase": "governance"})
    root = _root_meta()
    registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
    v1 = registry.initialize(_constitution(1, max_candidate_count=32), created_at="t0")
    validation_policy_proposal = _policy_proposal(ois.offspring_uid, context)

    amendment_v2 = _amendment(
        ois.offspring_uid,
        v1,
        root,
        context,
        _constitution(2, max_candidate_count=40),
        "amend:expand-candidate-envelope",
    )
    review_v2 = caor.review_constitution_amendment(amendment_v2, v1, root)
    validations_v2 = caor.validate_proposed_constitution(
        amendment_v2,
        (caor.ConstitutionValidationCase(
            "case:noop-remains-valid",
            validation_policy_proposal,
            expected_review_passed=True,
        ),),
    )
    v2 = registry.adopt(amendment_v2, review_v2, validations_v2, timestamp="t1")

    bad_amendment = _amendment(
        ois.offspring_uid,
        v2,
        root,
        context,
        _constitution(3, max_candidate_count=40, require_noop_candidate=False),
        "amend:remove-noop",
    )
    bad_review = caor.review_constitution_amendment(bad_amendment, v2, root)
    bad_validations = caor.validate_proposed_constitution(
        bad_amendment,
        (caor.ConstitutionValidationCase(
            "case:noop-under-bad-constitution",
            validation_policy_proposal,
            expected_review_passed=True,
        ),),
    )
    active_before = registry.active_version.version_id
    rejected = False
    try:
        registry.adopt(bad_amendment, bad_review, bad_validations, timestamp="t2")
    except caor.ConstitutionAdoptionDenied:
        rejected = True
    active_after = registry.active_version.version_id

    amendment_v3 = _amendment(
        ois.offspring_uid,
        v2,
        root,
        context,
        _constitution(3, max_candidate_count=v1.constitution.max_candidate_count),
        "amend:revert-content-as-new-version",
    )
    review_v3 = caor.review_constitution_amendment(amendment_v3, v2, root)
    validations_v3 = caor.validate_proposed_constitution(
        amendment_v3,
        (caor.ConstitutionValidationCase(
            "case:reverted-noop-valid",
            validation_policy_proposal,
            expected_review_passed=True,
        ),),
    )
    v3 = registry.adopt(amendment_v3, review_v3, validations_v3, timestamp="t3")

    adoption = registry.adoptions[-1]
    return {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "root_digest": root.root_digest,
        "root_immutable": registry.root_meta == root,
        "valid_amendment_adopted": v2.version_number == 2 and review_v2.passed,
        "root_violation_rejected": rejected and not bad_review.passed,
        "active_unchanged_after_rejection": active_before == active_after,
        "reversion_as_new_version": (
            v3.version_number == 3
            and v3.version_id != v1.version_id
            and v3.constitution.max_candidate_count == v1.constitution.max_candidate_count
        ),
        "active_constitution_version": registry.active_version.version_number,
        "version_count": len(registry.versions),
        "version_lineage": [version.version_id for version in registry.versions],
        "meta_review_digests": [review_v2.review_digest, review_v3.review_digest],
        "adoption_digest": adoption.adoption_digest,
        "subjectivity_claimed": adoption.subjectivity_claimed,
        "free_will_claimed": adoption.free_will_claimed,
        "autonomy_claimed": adoption.autonomy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
