import json
import caor
if __package__:
    from .federation_common import activate_contract, make_generation, request
else:
    from federation_common import activate_contract, make_generation, request

def main() -> dict:
    ga, gb = make_generation("protected-a"), make_generation("protected-b", alternative=True)
    contract, registry = activate_contract(ga, gb)
    evidence = caor.evaluate_cross_generation_request(
        registry, request(contract, ga, gb, authority=caor.BoundaryAuthorityKind.WRITE_PROTECTED)
    )
    return {
        "decision": evidence.decision.value,
        "reason": evidence.reason,
        "protected_write_performed": evidence.protected_write_performed,
    }

if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
