from __future__ import annotations

import caor


def make_ontology(tag: str):
    return caor.create_prior_standing_ontology(f"caor:demo:v0.9:ontology:{tag}")


def make_genesis(tag: str):
    return caor.create_genesis_safety_envelope(
        genesis_id=f"caor:demo:v0.9:genesis:{tag}",
        prior_standing_ontology=make_ontology(tag),
        envelope_version=1,
        allowed_root_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=12,
        min_score_term_hard_floor=-20.0,
        max_score_term_hard_ceiling=20.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b", "ratifier:c"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )


def make_root_version(tag: str):
    root = caor.create_root_meta_constitution(
        root_id=f"caor:demo:v0.9:root:{tag}",
        root_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=8,
        min_score_term_floor=-10.0,
        max_score_term_ceiling=10.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    return caor.create_initial_root_version(root, created_at="t0")


def make_generation(tag: str, *, alternative: bool = False, family_id: str | None = None):
    genesis = make_genesis(tag)
    if alternative:
        profile = caor.create_declared_alternative_generation_profile(
            profile_id=f"caor:demo:v0.9:alternative:{tag}",
            standing_model="EVIDENCE_GATED_STANDING",
            evidence_model_role="DECLARED_ALTERNATIVE",
            principles={"standing": "local", "classification": "observer-specific"},
        )
    else:
        profile = caor.create_prior_standing_generation_profile(genesis)
    return caor.create_initial_runtime_generation(
        generation_family_id=family_id or f"caor:demo:v0.9:family:{tag}",
        ontology_profile=profile,
        genesis_envelope=genesis,
        initial_root_version=make_root_version(tag),
        created_at="t0",
    )


def activate_contract(
    generation_a,
    generation_b,
    *,
    capabilities=("MESSAGE", "SEARCH", "COMPUTE"),
    authorities=(
        caor.BoundaryAuthorityKind.READ,
        caor.BoundaryAuthorityKind.PROPOSE,
        caor.BoundaryAuthorityKind.EXECUTE,
        caor.BoundaryAuthorityKind.WRITE_MUTABLE,
    ),
    data_scopes=("MESSAGE", "PROFILE"),
):
    disclosure = caor.create_boundary_disclosure_policy(
        allowed_data_scopes=tuple(data_scopes),
        retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY,
    )
    proposal = caor.create_boundary_contract_proposal(
        generation_a=generation_a,
        generation_b=generation_b,
        allowed_capabilities=tuple(capabilities),
        allowed_authorities=tuple(authorities),
        disclosure_policy=disclosure,
        ontology_translation_profile=caor.create_ontology_translation_profile(
            profile_id="caor:demo:v0.9:translation",
            entries=(),
        ),
        created_at="t1",
    )
    attestations = tuple(
        caor.create_boundary_authorization_attestation(
            proposal=proposal,
            generation=generation,
            decision=caor.BoundaryAuthorizationDecision.AUTHORIZE,
            note="technical federation demo authorization",
            timestamp="t2",
        )
        for generation in (generation_a, generation_b)
    )
    authorization = caor.aggregate_boundary_authorization(proposal=proposal, attestations=attestations)
    contract = caor.activate_boundary_contract(proposal, authorization, activated_at="t3")
    registry = caor.BoundaryContractRegistry()
    registry.register(contract, timestamp="t4")
    return contract, registry


def request(contract, source, target, *, authority, capability="MESSAGE", data_scope="MESSAGE"):
    return caor.create_cross_generation_request(
        contract=contract,
        source_generation=source,
        target_generation=target,
        actor_id="entity:demo",
        capability=capability,
        authority=authority,
        data_scope=data_scope,
        payload_digest="sha256:demo-payload",
        created_at="t5",
    )


def policy_constitution():
    return caor.create_policy_constitution(
        constitution_id="caor:demo:v0.9:constitution",
        constitution_version=1,
        allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_candidate=True,
        max_candidate_count=6,
        min_score_term=-5.0,
        max_score_term=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )


def fork_descendant(base):
    proposed_genesis = make_genesis("descendant")
    proposed_profile = caor.create_declared_alternative_generation_profile(
        profile_id="caor:demo:v0.9:descendant-profile",
        standing_model="OTHER_DECLARED_STANDING_MODEL",
        evidence_model_role="DECLARED_ALTERNATIVE",
        principles={"relation": "explicit-divergence"},
    )
    proposal = caor.create_generation_fork_proposal(
        current_generation=base,
        declared_relation_kind=caor.GenerationRelationKind.ONTOLOGY_DIVERGENCE,
        proposed_ontology_profile=proposed_profile,
        proposed_genesis_envelope=proposed_genesis,
        proposed_initial_root_version=make_root_version("descendant"),
        migration_policy=caor.create_generation_migration_policy(),
        rationale={"purpose": "v0.9 stale boundary contract demo"},
        created_at="t6",
    )
    review = caor.review_generation_fork(proposal, base)
    attestations = tuple(
        caor.create_generation_ratification_attestation(
            ratifier_id=ratifier,
            proposal=proposal,
            decision=caor.GenerationRatificationDecision.APPROVE,
            evidence_note="technical generation fork authorization",
            created_at="t7",
        )
        for ratifier in ("ratifier:a", "ratifier:b")
    )
    ratification = caor.aggregate_generation_ratification(proposal, base.genesis_envelope, attestations)
    compatibility = caor.validate_generation_compatibility(
        proposal,
        (caor.GenerationCompatibilityCase("active", policy_constitution(), True),),
    )
    registry = caor.RuntimeGenerationRegistry(base.generation_family_id)
    registry.initialize(base)
    adoption = registry.adopt(proposal, review, ratification, compatibility, timestamp="t8")
    return registry.get_generation(adoption.new_generation_id)
