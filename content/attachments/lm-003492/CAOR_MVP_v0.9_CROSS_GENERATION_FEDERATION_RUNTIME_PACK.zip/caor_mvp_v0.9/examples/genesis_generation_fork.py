import json

import caor


def _ontology():
    return caor.create_prior_standing_ontology("caor:demo:v0.8:prior-standing")


def _genesis(genesis_id: str, ontology):
    return caor.create_genesis_safety_envelope(
        genesis_id=genesis_id,
        prior_standing_ontology=ontology,
        envelope_version=1,
        allowed_root_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=12,
        min_score_term_hard_floor=-20.0,
        max_score_term_hard_ceiling=20.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b", "ratifier:c"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )


def _root_version():
    root = caor.create_root_meta_constitution(
        root_id="root:caor-v0.8-demo",
        root_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=8,
        min_score_term_floor=-10.0,
        max_score_term_ceiling=10.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    return caor.create_initial_root_version(root, created_at="t0")


def _constitution():
    return caor.create_policy_constitution(
        constitution_id="constitution:caor-v0.8-demo",
        constitution_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=6,
        min_score_term=-5.0,
        max_score_term=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )


def main() -> dict:
    ontology = _ontology()
    g1_genesis = _genesis("caor:demo:genesis:g1", ontology)
    g1_profile = caor.create_prior_standing_generation_profile(g1_genesis)
    g1 = caor.create_initial_runtime_generation(
        generation_family_id="caor:demo:generation-family",
        ontology_profile=g1_profile,
        genesis_envelope=g1_genesis,
        initial_root_version=_root_version(),
        created_at="t0",
    )

    registry = caor.RuntimeGenerationRegistry(g1.generation_family_id)
    registry.initialize(g1)

    g2_genesis = _genesis("caor:demo:genesis:g2", ontology)
    proposal = caor.create_generation_fork_proposal(
        current_generation=g1,
        declared_relation_kind=caor.GenerationRelationKind.GENESIS_FORK,
        proposed_ontology_profile=caor.create_prior_standing_generation_profile(g2_genesis),
        proposed_genesis_envelope=g2_genesis,
        proposed_initial_root_version=_root_version(),
        migration_policy=caor.create_generation_migration_policy(),
        rationale={"purpose": "demonstrate explicit Genesis generation fork"},
        created_at="t1",
    )
    review = caor.review_generation_fork(proposal, g1)
    attestations = tuple(
        caor.create_generation_ratification_attestation(
            ratifier_id=ratifier,
            proposal=proposal,
            decision=caor.GenerationRatificationDecision.APPROVE,
            evidence_note="technical demo approval",
            created_at="t-ratify",
        )
        for ratifier in ("ratifier:a", "ratifier:b")
    )
    ratification = caor.aggregate_generation_ratification(proposal, g1_genesis, attestations)
    compatibility = caor.validate_generation_compatibility(
        proposal,
        (caor.GenerationCompatibilityCase("active-constitution", _constitution(), True),),
    )
    adoption = registry.adopt(proposal, review, ratification, compatibility, timestamp="t2")

    transition = caor.classify_generation_entity_transition(
        source_generation_id=g1.generation_id,
        target_generation_id=adoption.new_generation_id,
        source_entity_uid="entity:child:g1",
        target_entity_uid="entity:child:g2-branch",
        source_identity_root="identity:shared-pre-fork",
        target_identity_root="identity:g2-branch",
        source_preserved=True,
        source_retired=False,
        state_direct_duplicate=False,
        shared_pre_transition_history=True,
        explicit_transition_kind=caor.GenerationEntityTransitionKind.FORK_TO_NEW_GENERATION,
    )

    return {
        "source_generation_preserved": registry.get_generation(g1.generation_id) == g1,
        "adoption_status": adoption.status,
        "relation_kind": adoption.relation_kind.value,
        "generation_count": len(registry.generations),
        "generation_heads": len(registry.generation_heads),
        "entity_auto_migrated": adoption.entity_auto_migrated,
        "transition_kind": transition.observed_transition_kind.value,
        "transition_declared_matches": transition.declared_matches_observed,
        "standing_model": g1_profile.standing_model,
        "subjectivity_claimed": adoption.subjectivity_claimed,
        "rights_proven": g1_profile.rights_proven,
        "political_legitimacy_claimed": adoption.political_legitimacy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
