"""Executable CAOR reference demonstrations."""
