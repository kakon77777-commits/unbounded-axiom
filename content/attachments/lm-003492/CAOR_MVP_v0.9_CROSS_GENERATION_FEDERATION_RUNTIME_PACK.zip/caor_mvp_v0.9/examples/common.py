from __future__ import annotations

from caor.contributions import normalize_contributions
from caor.lineage import LineageGraph
from caor.models import Contribution, ContributionCategory, ParentContributionBundle, SourceKind
from caor.synthesis import synthesize_offspring


def make_bundle(source_id: str, source_kind: SourceKind, cid: str, category: ContributionCategory, name: str, value, weight: float) -> ParentContributionBundle:
    return ParentContributionBundle(
        source_id=source_id,
        source_kind=source_kind,
        contributions=(Contribution(category, source_id, cid, name, value, weight, "synthetic demo"),),
        provenance={"demo": True, "source_kind": source_kind.value},
    )


def synthesize_demo(bundles, seed: str):
    manifest = normalize_contributions(tuple(bundles))
    ois = synthesize_offspring(manifest, seed)
    graph = LineageGraph()
    edges = graph.record_offspring(manifest.source_ids, ois, manifest.digest, {"demo": True})
    return manifest, ois, graph, edges
