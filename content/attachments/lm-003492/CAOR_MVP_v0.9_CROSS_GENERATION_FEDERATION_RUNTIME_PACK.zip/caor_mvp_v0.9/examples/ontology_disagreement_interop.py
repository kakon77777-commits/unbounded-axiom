import json
import caor
if __package__:
    from .federation_common import activate_contract, make_generation, request
else:
    from federation_common import activate_contract, make_generation, request

def main() -> dict:
    ga = make_generation("ontology-a")
    gb = make_generation("ontology-b", alternative=True)
    a_before, b_before = ga.ontology_profile_digest, gb.ontology_profile_digest
    contract, registry = activate_contract(ga, gb, capabilities=("MESSAGE",))
    evidence = caor.evaluate_cross_generation_request(
        registry, request(contract, ga, gb, authority=caor.BoundaryAuthorityKind.READ)
    )
    return {
        "decision": evidence.decision.value,
        "ontologies_differ": a_before != b_before,
        "ontology_a_unchanged": ga.ontology_profile_digest == a_before,
        "ontology_b_unchanged": gb.ontology_profile_digest == b_before,
        "ontology_assimilation_performed": evidence.ontology_assimilation_performed,
    }

if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
