import json

from caor.entity import OffspringEntity
from caor.errors import ProtectedCoreWriteDenied
from caor.models import ContributionCategory, SourceKind
try:
    from .common import make_bundle, synthesize_demo
except ImportError:  # direct script execution
    from common import make_bundle, synthesize_demo


def main() -> dict:
    manifest, ois, _graph, _edges = synthesize_demo((
        make_bundle("ai:parent", SourceKind.AI_ENTITY, "p-care", ContributionCategory.VALUE_TRAIT, "care", True, 1.0),
    ), "write-policy-demo")
    entity = OffspringEntity(ois)
    original = entity.protected_core_snapshot()
    denied = False
    try:
        entity.direct_core_write("ai:parent", "identity_root", "replacement")
    except ProtectedCoreWriteDenied:
        denied = True
    proposal = entity.propose_update("ai:parent", "preferences", "music", "jazz")
    return {
        "denied": denied,
        "protected_core_unchanged": entity.protected_core_snapshot() == original,
        "proposal_status": proposal.status,
        "offspring_uid": ois.offspring_uid,
        "manifest_digest": manifest.digest,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
