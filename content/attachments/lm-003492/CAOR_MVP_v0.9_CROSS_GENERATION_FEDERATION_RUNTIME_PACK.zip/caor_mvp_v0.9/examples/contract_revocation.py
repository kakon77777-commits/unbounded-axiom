import json
import caor
if __package__:
    from .federation_common import activate_contract, make_generation, request
else:
    from federation_common import activate_contract, make_generation, request

def main() -> dict:
    ga, gb = make_generation("revoke-a"), make_generation("revoke-b", alternative=True)
    contract, registry = activate_contract(ga, gb)
    req = request(contract, ga, gb, authority=caor.BoundaryAuthorityKind.READ)
    before = caor.evaluate_cross_generation_request(registry, req)
    registry.revoke(contract.contract_id, reason="demo exit", timestamp="t6")
    after = caor.evaluate_cross_generation_request(registry, req)
    return {
        "before_revocation": before.decision.value,
        "after_revocation": after.decision.value,
        "final_state": registry.state(contract.contract_id).value,
    }

if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
