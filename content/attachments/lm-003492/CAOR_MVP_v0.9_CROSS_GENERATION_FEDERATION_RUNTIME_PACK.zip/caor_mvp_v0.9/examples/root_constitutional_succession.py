import json

import caor


def _ontology():
    return caor.create_prior_standing_ontology("caor:demo:prior-standing")


def _genesis(ontology):
    return caor.create_genesis_safety_envelope(
        genesis_id="caor:demo:genesis-v1",
        prior_standing_ontology=ontology,
        envelope_version=1,
        allowed_root_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=16,
        min_score_term_hard_floor=-100.0,
        max_score_term_hard_ceiling=100.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b", "ratifier:c"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )


def _root(version: int, max_candidates: int, require_noop: bool = True):
    return caor.create_root_meta_constitution(
        root_id="root:caor-v0.7-demo",
        root_version=version,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=require_noop,
        max_candidate_count_ceiling=max_candidates,
        min_score_term_floor=-50.0,
        max_score_term_ceiling=50.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )


def _constitution():
    return caor.create_policy_constitution(
        constitution_id="constitution:caor-v0.7-demo",
        constitution_version=1,
        allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_candidate=True,
        max_candidate_count=6,
        min_score_term=-10.0,
        max_score_term=10.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )


def _ratification(proposal, genesis):
    attestations = tuple(
        caor.create_ratification_attestation(
            ratifier_id=ratifier,
            proposal=proposal,
            decision=caor.RatificationDecision.APPROVE,
            evidence_note="technical demo approval",
            created_at="t-ratify",
        )
        for ratifier in ("ratifier:a", "ratifier:b")
    )
    return caor.aggregate_root_ratification(proposal, genesis, attestations)


def main() -> dict:
    ontology = _ontology()
    genesis = _genesis(ontology)
    registry = caor.RootRegistry("caor:offspring:root-demo", genesis)
    v1 = registry.initialize(_root(1, 12), created_at="t0")

    proposed_v2 = _root(2, 10)
    proposal = caor.create_root_succession_proposal(
        current_version=v1,
        genesis_envelope=genesis,
        proposed_root_meta=proposed_v2,
        rationale={"purpose": "narrow candidate ceiling"},
        created_at="t1",
    )
    review = caor.review_root_succession(proposal, v1, genesis)
    ratification = _ratification(proposal, genesis)
    compatibility = caor.validate_root_compatibility(
        proposed_v2,
        (caor.RootCompatibilityCase("active-constitution", _constitution(), True),),
    )
    adoption = registry.adopt(proposal, review, ratification, compatibility, created_at="t2")

    active_before_bad = registry.active_version.root_version_id
    bad_root = _root(3, 10, require_noop=False)
    bad_proposal = caor.create_root_succession_proposal(
        current_version=registry.active_version,
        genesis_envelope=genesis,
        proposed_root_meta=bad_root,
        rationale={"purpose": "attempt to remove root-required NO_OP"},
        created_at="t3",
    )
    bad_review = caor.review_root_succession(bad_proposal, registry.active_version, genesis)
    bad_ratification = _ratification(bad_proposal, genesis)
    bad_compatibility = caor.validate_root_compatibility(
        bad_root,
        (caor.RootCompatibilityCase("active-constitution", _constitution(), True),),
    )
    rejected = False
    try:
        registry.adopt(bad_proposal, bad_review, bad_ratification, bad_compatibility, created_at="t4")
    except caor.RootSuccessionReviewDenied:
        rejected = True

    return {
        "root_version_before": 1,
        "root_version_after": registry.active_version.version_number,
        "valid_succession_adopted": adoption.status == "ADOPTED" and review.passed and ratification.passed,
        "invalid_noop_removal_rejected": rejected and not bad_review.passed,
        "active_root_unchanged_after_rejection": active_before_bad == registry.active_version.root_version_id,
        "ontology_digest_preserved": adoption.ontology_digest == ontology.ontology_digest == genesis.ontology_digest,
        "standing_model": ontology.standing_model,
        "evidence_model_role": ontology.evidence_model_role,
        "subjectivity_claimed": adoption.subjectivity_claimed,
        "rights_proven": ontology.rights_proven,
        "political_legitimacy_claimed": adoption.political_legitimacy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
