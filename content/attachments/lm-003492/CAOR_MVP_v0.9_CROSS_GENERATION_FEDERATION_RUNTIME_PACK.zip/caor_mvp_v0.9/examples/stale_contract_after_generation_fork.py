import json
import caor
if __package__:
    from .federation_common import activate_contract, fork_descendant, make_generation, request
else:
    from federation_common import activate_contract, fork_descendant, make_generation, request

def main() -> dict:
    ga = make_generation("stale-a")
    gb = make_generation("stale-b", alternative=True, family_id="caor:demo:v0.9:stale-family")
    contract, registry = activate_contract(ga, gb)
    descendant = fork_descendant(gb)
    original = caor.evaluate_cross_generation_request(
        registry, request(contract, ga, gb, authority=caor.BoundaryAuthorityKind.READ)
    )
    stale = False
    try:
        caor.evaluate_cross_generation_request(
            registry, request(contract, ga, descendant, authority=caor.BoundaryAuthorityKind.READ)
        )
    except caor.StaleBoundaryContract:
        stale = True
    return {
        "original_endpoint_still_allowed": original.decision is caor.CrossGenerationInteractionDecision.ALLOWED,
        "descendant_rejected_as_stale": stale,
        "automatic_contract_inheritance": False,
    }

if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
