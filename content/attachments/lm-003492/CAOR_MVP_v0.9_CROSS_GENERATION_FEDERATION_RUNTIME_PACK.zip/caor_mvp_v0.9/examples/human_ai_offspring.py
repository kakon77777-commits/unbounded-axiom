import json

from caor.models import ContributionCategory, SourceKind
try:
    from .common import make_bundle, synthesize_demo
except ImportError:  # direct script execution
    from common import make_bundle, synthesize_demo


def main() -> dict:
    bundles = (
        make_bundle("human:H", SourceKind.HUMAN_PROFILE, "h-curiosity", ContributionCategory.IDENTITY_TRAIT, "curiosity", "high", 0.5),
        make_bundle("ai:A", SourceKind.AI_ENTITY, "a-care", ContributionCategory.VALUE_TRAIT, "care", "high", 0.5),
    )
    manifest, ois, _graph, edges = synthesize_demo(bundles, "human-ai-demo")
    result = {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "sources": list(manifest.source_ids),
        "manifest_digest": manifest.digest,
        "lineage_edges": len(edges),
    }
    return result


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
