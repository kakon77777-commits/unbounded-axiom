import json
import caor
if __package__:
    from .federation_common import activate_contract, make_generation, request
else:
    from federation_common import activate_contract, make_generation, request

def main() -> dict:
    ga, gb = make_generation("read-a"), make_generation("read-b", alternative=True)
    contract, registry = activate_contract(ga, gb)
    evidence = caor.evaluate_cross_generation_request(
        registry, request(contract, ga, gb, authority=caor.BoundaryAuthorityKind.READ)
    )
    return {
        "decision": evidence.decision.value,
        "authority": evidence.authority.value,
        "ontology_assimilation_performed": evidence.ontology_assimilation_performed,
    }

if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
