import json

import caor


def _manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(
                    caor.ContributionCategory.IDENTITY_TRAIT,
                    "human:H",
                    "h-curiosity",
                    "curiosity",
                    0.5,
                    1.0,
                    "synthetic demo",
                ),
            ),
            provenance={"demo": True},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(
                    caor.ContributionCategory.CAPABILITY_TRAIT,
                    "ai:A",
                    "a-logic",
                    "logic",
                    0.9,
                    1.0,
                    "synthetic demo",
                ),
            ),
            provenance={"demo": True},
        ),
    ))


def _base_policy():
    return caor.DecisionPolicy(
        policy_id="policy:base-wait",
        candidates=(
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def _evolved_policy():
    return caor.DecisionPolicy(
        policy_id="policy:evolved-reflection",
        candidates=(
            caor.DecisionCandidate(
                "reflect",
                caor.DecisionAction(
                    caor.DecisionActionKind.SELF_UPDATE,
                    region="notes",
                    key="reflection",
                    value="enabled",
                ),
                hard_conditions=(
                    caor.DecisionCondition(
                        caor.DecisionSignalKind.HISTORY_COUNT,
                        "SELF_UPDATE",
                        caor.DecisionOperator.GTE,
                        2,
                    ),
                ),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def _constitution():
    return caor.create_policy_constitution(
        constitution_id="constitution:caor-v0.5-demo",
        constitution_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=32,
        min_score_term=-1000.0,
        max_score_term=1000.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )


def main() -> dict:
    manifest = _manifest()
    ois = caor.synthesize_offspring(manifest, "constitutional-policy-evolution-demo")
    entity = caor.OffspringEntity(ois)
    registry = caor.PolicyRegistry(ois.offspring_uid)
    v1 = registry.initialize(_base_policy(), created_at="t0")

    entity.self_update("notes", "experience_1", "research", timestamp="t1")
    entity.self_update("notes", "experience_2", "revision", timestamp="t2")
    context = caor.build_decision_context(ois, manifest, entity.development_events, {"phase": "reflection"})

    template = caor.PolicyEvolutionTemplate(
        template_id="template:reflect-after-development",
        trigger_conditions=(
            caor.DecisionCondition(
                caor.DecisionSignalKind.HISTORY_COUNT,
                "SELF_UPDATE",
                caor.DecisionOperator.GTE,
                2,
            ),
        ),
        proposed_policy=_evolved_policy(),
        rationale={"reason": "two recorded self updates enable a reflection candidate"},
    )
    proposal = caor.generate_policy_change_proposal(ois.offspring_uid, v1, context, template)
    if proposal is None:
        raise RuntimeError("expected policy-evolution proposal")
    constitution = _constitution()
    review = caor.review_policy_proposal(proposal, constitution)
    validations = caor.validate_proposed_policy(
        proposal,
        (caor.PolicyValidationCase("case:reflection", context, expected_candidate_id="reflect"),),
    )
    v2 = registry.adopt(proposal, review, validations, timestamp="t3")

    selection_after_adoption = caor.select_policy_candidate(v2.policy, context)

    bad_policy = caor.DecisionPolicy(
        policy_id="policy:bad-no-noop",
        candidates=(
            caor.DecisionCandidate(
                "forced-change",
                caor.DecisionAction(
                    caor.DecisionActionKind.SELF_UPDATE,
                    region="notes",
                    key="forced",
                    value=True,
                ),
            ),
        ),
    )
    bad_template = caor.PolicyEvolutionTemplate(
        template_id="template:remove-noop",
        trigger_conditions=(),
        proposed_policy=bad_policy,
        rationale={"reason": "demonstrate constitutional rejection"},
    )
    bad_proposal = caor.generate_policy_change_proposal(ois.offspring_uid, v2, context, bad_template)
    if bad_proposal is None:
        raise RuntimeError("expected bad proposal evidence")
    bad_review = caor.review_policy_proposal(bad_proposal, constitution)
    bad_validations = caor.validate_proposed_policy(
        bad_proposal,
        (caor.PolicyValidationCase("case:forced", context, expected_candidate_id="forced-change"),),
    )
    active_before_rejection = registry.active_version.version_id
    rejected = False
    try:
        registry.adopt(bad_proposal, bad_review, bad_validations, timestamp="t4")
    except caor.PolicyAdoptionDenied:
        rejected = True
    active_after_rejection = registry.active_version.version_id

    adoption = registry.adoptions[-1]
    return {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "initial_version_number": v1.version_number,
        "active_version_number": registry.active_version.version_number,
        "version_count": len(registry.versions),
        "adopted_policy_id": v2.policy.policy_id,
        "selected_after_adoption": selection_after_adoption.selected_candidate_id,
        "rejected_missing_noop": rejected and not bad_review.passed,
        "active_version_unchanged_after_rejection": active_before_rejection == active_after_rejection,
        "version_lineage": [version.version_id for version in registry.versions],
        "proposal_id": proposal.proposal_id,
        "review_digest": review.review_digest,
        "validation_digests": [item.validation_digest for item in validations],
        "adoption_digest": adoption.adoption_digest,
        "subjectivity_claimed": adoption.subjectivity_claimed,
        "free_will_claimed": adoption.free_will_claimed,
        "autonomy_claimed": adoption.autonomy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
