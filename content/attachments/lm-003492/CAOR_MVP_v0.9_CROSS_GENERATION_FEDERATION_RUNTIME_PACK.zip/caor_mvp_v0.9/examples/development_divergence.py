import json

import caor
try:
    from .common import make_bundle
except ImportError:  # direct script execution
    from common import make_bundle


def main() -> dict:
    bundles = (
        make_bundle(
            "human:H",
            caor.SourceKind.HUMAN_PROFILE,
            "h-curiosity",
            caor.ContributionCategory.IDENTITY_TRAIT,
            "curiosity",
            0.4,
            0.5,
        ),
        make_bundle(
            "ai:A",
            caor.SourceKind.AI_ENTITY,
            "a-curiosity",
            caor.ContributionCategory.IDENTITY_TRAIT,
            "curiosity",
            0.8,
            0.5,
        ),
    )
    manifest = caor.normalize_contributions(bundles)
    ois = caor.synthesize_offspring(manifest, "development-divergence-demo")
    entity = caor.OffspringEntity(ois)

    proposal = entity.propose_update("ai:A", "skills", "logic", 0.92)
    entity.self_update("preferences", "curiosity", 0.73, timestamp="t1", evidence={"reason": "independent-selection"})
    entity.accept_proposal(proposal.proposal_id, timestamp="t2")
    entity.apply_environment_event(
        "notes",
        "project",
        "self-directed-study",
        environment_id="env:lab",
        timestamp="t3",
        evidence={"source": "synthetic-environment"},
    )

    replayed = caor.replay_mutable_state(entity.ois, entity.development_events)
    evidence = caor.build_development_evidence(entity, manifest)
    final = evidence.divergence_timeline[-1]

    return {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "sources": list(manifest.source_ids),
        "development_event_kinds": [event.event_kind.value for event in entity.development_events],
        "event_count": evidence.event_count,
        "timeline_steps": [snapshot.step for snapshot in evidence.divergence_timeline],
        "replay_equal": caor.canonical_json_bytes(replayed) == caor.canonical_json_bytes(entity.mutable_state),
        "final_nearest_source_id": final.nearest_source_id,
        "final_nearest_source_distance": final.nearest_source_distance,
        "final_novel_state_fraction": final.novel_state_fraction,
        "changed_keys": list(final.changed_keys),
        "ledger_digest": evidence.ledger_digest,
        "final_state_digest": evidence.final_state_digest,
        "subjectivity_claimed": evidence.subjectivity_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
