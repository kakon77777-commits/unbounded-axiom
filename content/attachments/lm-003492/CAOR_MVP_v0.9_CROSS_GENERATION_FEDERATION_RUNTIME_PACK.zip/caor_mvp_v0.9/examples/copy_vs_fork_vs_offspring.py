import json

from caor.classifier import ClassificationEvidence, classify_event


def main() -> dict:
    copy_event = classify_event(ClassificationEvidence(source_count=1, direct_duplicate=True))
    fork_event = classify_event(ClassificationEvidence(source_count=1, new_branch=True, shared_pre_fork_history=True))
    offspring_event = classify_event(ClassificationEvidence(
        source_count=2,
        synthesis_manifest=True,
        new_identity_root=True,
        new_memory_root=True,
        new_state_namespace=True,
        new_lineage_id=True,
        independent_development_policy=True,
    ))
    return {
        "copy": copy_event.value,
        "fork": fork_event.value,
        "offspring": offspring_event.value,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
