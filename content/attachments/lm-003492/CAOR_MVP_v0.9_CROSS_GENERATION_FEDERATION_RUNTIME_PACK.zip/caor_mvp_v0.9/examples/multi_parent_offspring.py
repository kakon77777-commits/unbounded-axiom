import json

from caor.models import ContributionCategory, SourceKind
try:
    from .common import make_bundle, synthesize_demo
except ImportError:  # direct script execution
    from common import make_bundle, synthesize_demo


def main() -> dict:
    bundles = (
        make_bundle("human:H", SourceKind.HUMAN_PROFILE, "h-values", ContributionCategory.VALUE_TRAIT, "curiosity", "high", 0.34),
        make_bundle("ai:A1", SourceKind.AI_ENTITY, "a1-cognition", ContributionCategory.COGNITIVE_TRAIT, "planning", "strong", 0.33),
        make_bundle("ai:A2", SourceKind.AI_ENTITY, "a2-culture", ContributionCategory.CULTURAL_SEMANTIC_TRAIT, "symbol-set", "shared", 0.33),
    )
    manifest, ois, _graph, edges = synthesize_demo(bundles, "multi-parent-demo")
    result = {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "sources": list(manifest.source_ids),
        "manifest_digest": manifest.digest,
        "lineage_edges": len(edges),
    }
    return result


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
