import json

import caor
try:
    from .common import make_bundle
except ImportError:  # direct script execution
    from common import make_bundle


def _action(kind, region, key, value, external_id=None, timestamp="t1"):
    return caor.CounterfactualAction(
        action_kind=kind,
        region=region,
        key=key,
        value=value,
        external_id=external_id,
        timestamp=timestamp,
        evidence={"scenario": "counterfactual-demo"},
    )


def main() -> dict:
    bundles = (
        make_bundle(
            "human:H",
            caor.SourceKind.HUMAN_PROFILE,
            "h-curiosity",
            caor.ContributionCategory.IDENTITY_TRAIT,
            "curiosity",
            0.4,
            0.5,
        ),
        make_bundle(
            "ai:A",
            caor.SourceKind.AI_ENTITY,
            "a-curiosity",
            caor.ContributionCategory.IDENTITY_TRAIT,
            "curiosity",
            0.8,
            0.5,
        ),
    )
    manifest = caor.normalize_contributions(bundles)
    ois = caor.synthesize_offspring(manifest, "counterfactual-branch-demo")
    specs = (
        caor.CounterfactualBranchSpec("baseline", ()),
        caor.CounterfactualBranchSpec(
            "research",
            (
                _action(caor.CounterfactualActionKind.SELF_UPDATE, "skills", "logic", 0.96, timestamp="t1"),
                _action(caor.CounterfactualActionKind.ENVIRONMENT_EVENT, "notes", "project", "theorem-search", "env:lab", "t2"),
            ),
        ),
        caor.CounterfactualBranchSpec(
            "creative",
            (
                _action(caor.CounterfactualActionKind.SELF_UPDATE, "preferences", "curiosity", 0.91, timestamp="t1"),
                _action(caor.CounterfactualActionKind.ENVIRONMENT_EVENT, "notes", "project", "generative-art", "env:studio", "t2"),
            ),
        ),
    )
    evidence = caor.build_counterfactual_evidence(ois, manifest, specs)
    return {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "branch_count": evidence.branch_count,
        "branch_labels": [trajectory.branch_label for trajectory in evidence.trajectories],
        "unique_trajectory_count": evidence.unique_trajectory_count,
        "unique_final_state_count": evidence.unique_final_state_count,
        "alternative_trajectories_observed": evidence.alternative_trajectories_observed,
        "pairwise_distances": [comparison.state_distance for comparison in evidence.pairwise_comparisons],
        "subjectivity_claimed": evidence.subjectivity_claimed,
        "free_will_claimed": evidence.free_will_claimed,
        "autonomy_claimed": evidence.autonomy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
