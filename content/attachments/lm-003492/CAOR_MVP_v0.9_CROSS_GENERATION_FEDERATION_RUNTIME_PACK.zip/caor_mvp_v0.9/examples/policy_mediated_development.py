import json

import caor


def _manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h-curiosity", "curiosity", 0.2, 0.75, "synthetic demo"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "human:H", "h-logic", "logic", 0.4, 1.0, "synthetic demo"),
            ),
            provenance={"demo": True},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "ai:A", "a-curiosity", "curiosity", 0.8, 0.25, "synthetic demo"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a-logic", "logic", 0.9, 1.0, "synthetic demo"),
            ),
            provenance={"demo": True},
        ),
    ))


def _condition(signal, path, operator, expected=None):
    return caor.DecisionCondition(signal, path, operator, expected)


def _score(condition, amount):
    return caor.DecisionScoreTerm(condition, amount)


def main() -> dict:
    manifest = _manifest()
    ois = caor.synthesize_offspring(manifest, "policy-mediated-demo")
    entity = caor.OffspringEntity(ois)

    orientation_policy = caor.DecisionPolicy(
        policy_id="policy:orientation",
        candidates=(
            caor.DecisionCandidate(
                "creative",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="path", value="creative"),
                hard_conditions=(
                    _condition(caor.DecisionSignalKind.ENVIRONMENT, "opportunity", caor.DecisionOperator.EQ, "creative"),
                ),
            ),
            caor.DecisionCandidate(
                "research",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="path", value="research"),
                hard_conditions=(
                    _condition(caor.DecisionSignalKind.ENVIRONMENT, "opportunity", caor.DecisionOperator.EQ, "research"),
                ),
                score_terms=(
                    _score(_condition(caor.DecisionSignalKind.STATE, "skills.logic", caor.DecisionOperator.GTE, 0.6), 2.0),
                    _score(_condition(caor.DecisionSignalKind.ENVIRONMENT, "challenge", caor.DecisionOperator.GTE, 0.5), 1.0),
                ),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )
    initial_context = caor.build_decision_context(
        ois,
        manifest,
        entity.development_events,
        {"opportunity": "research", "challenge": 0.8},
    )
    initial_selection = caor.select_policy_candidate(orientation_policy, initial_context)
    caor.apply_policy_selection(entity, initial_selection, timestamp="t1")

    events_before_followup = entity.development_events
    followup_policy = caor.DecisionPolicy(
        policy_id="policy:followup",
        candidates=(
            caor.DecisionCandidate(
                "reflect",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="reflection", value=True),
                hard_conditions=(
                    _condition(caor.DecisionSignalKind.HISTORY_COUNT, "SELF_UPDATE", caor.DecisionOperator.GTE, 1),
                    _condition(caor.DecisionSignalKind.STATE, "notes.path", caor.DecisionOperator.EQ, "research"),
                    _condition(caor.DecisionSignalKind.ENVIRONMENT, "phase", caor.DecisionOperator.EQ, "reflect"),
                ),
                score_terms=(
                    _score(_condition(caor.DecisionSignalKind.HISTORY_TOTAL, "", caor.DecisionOperator.GTE, 1), 1.0),
                ),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )
    followup_environment = {"phase": "reflect"}
    followup_context = caor.build_decision_context(ois, manifest, events_before_followup, followup_environment)
    followup_selection = caor.select_policy_candidate(followup_policy, followup_context)
    replay_context = caor.build_decision_context(ois, manifest, tuple(events_before_followup), dict(followup_environment))
    replay_selection = caor.select_policy_candidate(followup_policy, replay_context)
    caor.apply_policy_selection(entity, followup_selection, timestamp="t2")

    return {
        "event": ois.generation_event,
        "offspring_uid": ois.offspring_uid,
        "initial_selected_candidate": initial_selection.selected_candidate_id,
        "followup_selected_candidate": followup_selection.selected_candidate_id,
        "decision_count": 2,
        "selection_digests": [initial_selection.selection_digest, followup_selection.selection_digest],
        "development_event_kinds": [event.event_kind.value for event in entity.development_events],
        "replay_selection_equal": followup_selection.canonical_bytes == replay_selection.canonical_bytes,
        "final_mutable_state": entity.mutable_state,
        "subjectivity_claimed": followup_selection.subjectivity_claimed,
        "free_will_claimed": followup_selection.free_will_claimed,
        "autonomy_claimed": followup_selection.autonomy_claimed,
    }


if __name__ == "__main__":
    print(json.dumps(main(), ensure_ascii=False, sort_keys=True))
