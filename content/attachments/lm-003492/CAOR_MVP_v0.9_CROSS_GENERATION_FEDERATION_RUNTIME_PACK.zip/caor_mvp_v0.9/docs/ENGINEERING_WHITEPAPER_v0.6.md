# CAOR MVP v0.6 — Meta-Constitutional Governance Runtime
## Engineering Whitepaper

**Version:** 0.6.0  
**Date:** 2026-08-31  
**Scope:** Deterministic reference runtime and defensive technical disclosure.  

## 1. Purpose

CAOR v0.5 introduced constitution-bounded evolution of a computational entity's decision policy. That immediately creates a higher-order engineering problem: if the policy constitution can itself be changed, what prevents an ordinary amendment from deleting the constraints that made policy evolution bounded in the first place?

CAOR v0.6 introduces a deliberately narrow answer: an immutable `RootMetaConstitution` constrains ordinary `PolicyConstitution` amendments. The ordinary amendment path can change a bounded set of constitution parameters, but it cannot modify or replace the root layer through the v0.6 governance API.

The runtime demonstrates governance mechanics only. It does not claim self-legislation, autonomous norm creation, political legitimacy, legal constitutional status, free will, or subjectivity.

## 2. Evolution Across CAOR Releases

```text
v0.1  independent identity initialization
v0.2  append-only development and divergence evidence
v0.3  counterfactual development trajectories
v0.4  replay-bound deterministic policy selection
v0.5  constitutional policy-change proposal and adoption
v0.6  root-constrained constitution amendment governance
```

The cumulative technical chain is:

```text
Source Contributions
    ↓
Independent Origin
    ↓
Development History
    ↓
Alternative Trajectories
    ↓
Policy Selection
    ↓
Policy Change Proposal
    ↓
Policy Constitution
    ↓
Constitution Amendment Proposal
    ↓
Root Meta-Constitution Review
    ↓
Append-Only Constitution Version
```

## 3. Root Meta-Constitution

The root layer is an immutable record containing:

```text
root_id
root_version
allowed_action_kinds
require_noop_enforcement
max_candidate_count_ceiling
min_score_term_floor
max_score_term_ceiling
required_tie_break_rule
require_validation_cases
require_append_only_versions
root_digest
```

It also emits explicit epistemic-firewall fields:

```text
subjectivity_claimed = false
free_will_claimed = false
autonomy_claimed = false
```

The root is intentionally not ordinary-amendable in v0.6. No public `amend_root_meta_constitution()` function exists.

## 4. Why a Root Layer Is Needed

Without a higher-order boundary, a constitution may contain a rule such as:

```text
require_noop_candidate = true
```

while simultaneously permitting an amendment that changes it to:

```text
require_noop_candidate = false
```

If no higher layer constrains that amendment, the original invariant is only advisory.

v0.6 therefore makes the following distinction explicit:

```text
Policy Constitution Rule
    !=
Root Meta-Constitution Invariant
```

The policy constitution is versioned and ordinary-amendable. The root is fixed for the lifetime of a `ConstitutionRegistry` in v0.6.

## 5. Amendment Proposal Is Not Constitution Mutation

A constitution amendment is first represented as evidence:

```text
ConstitutionAmendmentProposal
```

It is bound to:

```text
base_version_id
base_constitution_digest
root_meta_digest
context_digest
development_digest
proposed_constitution_digest
```

Generating this record does not change the active constitution.

## 6. Meta-Constitutional Review

Every proposal is evaluated against named rules:

```text
STRUCTURAL_VALIDITY
NEXT_CONSTITUTION_VERSION
ROOT_REQUIRED_NO_OP
ROOT_ALLOWED_ACTION_KINDS
ROOT_MAX_CANDIDATE_COUNT
ROOT_SCORE_BOUNDS
ROOT_TIE_BREAK_RULE
```

Each rule generates evidence independently. A failed rule does not disappear into a single opaque rejection code.

## 7. Behavioral Constitution Validation

Structural compliance alone is insufficient. A proposed constitution is also applied to supplied policy-change proposals through the existing v0.5 policy review mechanism.

A `ConstitutionValidationCase` specifies:

```text
case_id
policy_proposal
expected_review_passed
```

The runtime records whether the proposed constitution produces the expected policy-review outcome.

This is deterministic regression evidence, not a proof that the constitution is universally correct.

## 8. Append-Only Constitution Registry

`ConstitutionRegistry` stores:

```text
RootMetaConstitution
ConstitutionVersion[]
ConstitutionAmendmentProposal[]
MetaConstitutionalReviewEvidence[]
ConstitutionAdoptionEvidence[]
```

A successful amendment creates:

```text
v1 → v2 → v3 ...
```

and never mutates a prior version.

## 9. Stale Amendment Protection

An amendment generated against v1 cannot overwrite v2 after v2 becomes active.

The proposal carries both base version ID and base constitution digest. Adoption compares those values to the current active version and rejects stale evidence with `StaleConstitutionAmendment`.

## 10. Reversion Is Not Rollback

Returning to prior constitution content requires a new later version.

Example:

```text
v1: candidate ceiling = 32
v2: candidate ceiling = 40
v3: candidate ceiling = 32
```

v3 is not v1. v3 has its own version ID and v2 remains part of the evidence lineage.

## 11. Root-Bounded Ordinary Amendment Surface

The ordinary amendment surface cannot:

- disable root-required `NO_OP` enforcement;
- add action kinds not allowed by the root;
- increase candidate count above the root ceiling;
- widen score terms outside the root interval;
- replace the root-required tie-break rule;
- replace the root itself.

This does not assert that the chosen root invariants are ethically complete. It only makes the engineering authority boundary explicit and testable.

## 12. Scope Firewall

The reference runtime does not establish:

```text
meta-governance mechanism == autonomy
meta-governance mechanism == free will
meta-governance mechanism == subjectivity
meta-governance mechanism == political legitimacy
meta-governance mechanism == legal constitution
```

It establishes only deterministic, replayable, append-only evidence for bounded constitution changes.

## 13. Defensive Publication Significance

v0.6 makes technically explicit the combination:

```text
Immutable Root Constraints
+
Context-Bound Constitution Amendment Proposal
+
Named Meta-Rule Review
+
Behavioral Validation
+
Stale-Base Protection
+
Append-Only Constitution Version Adoption
```

The value of the reference runtime is that these steps are not merely described abstractly: they are exposed as executable types, functions, tests, and evidence artifacts.

## 14. Closure

CAOR v0.6 answers the narrow engineering question:

> If a computational entity's policy constitution can evolve, how can ordinary constitution changes remain bounded by a higher-order invariant layer without pretending that the system has become a sovereign or subjective lawgiver?

The reference answer is:

```text
Proposal, not mutation.
Root review, not unrestricted amendment.
Validation, not assumption.
Append-only adoption, not rollback.
Evidence, not subjectivity claims.
```
