# CAOR v0.8 — Genesis Generation Fork & Cross-Generation Migration Runtime
## Engineering Whitepaper

**Status:** Reference implementation whitepaper  
**Version:** 0.8.0  
**Date:** 2026-08-31

## 1. Purpose

CAOR v0.8 closes the governance stack above v0.7 by making the following rule executable:

$$
\boxed{
\text{Genesis change}
\rightarrow
\text{new runtime generation}
}
$$

rather than:

$$
\boxed{
\text{Genesis change}
\rightarrow
\text{in-place history rewrite}.
}
$$

The runtime therefore treats Genesis and generation-level ontology changes as lineage events between immutable `RuntimeGeneration` records.

## 2. Why a Runtime Generation Layer

Earlier CAOR versions progressively separated:

```text
entity identity
entity development
decision policy
policy constitution
root meta-constitution
Genesis safety envelope
```

v0.7 intentionally provided no ordinary Genesis-amendment API. v0.8 does not respond by adding another recursively higher constitution. Instead it introduces an explicit generation boundary.

```text
RuntimeGeneration G1
    ├── ontology profile
    ├── Genesis envelope
    └── initial root version
          │
          └── explicit generation fork
                    ↓
RuntimeGeneration G2
```

The source generation remains addressable and immutable.

## 3. Generation Ontology Profiles

v0.8 distinguishes ontology declaration from ontology proof.

A `GenerationOntologyProfile` may use:

```text
PRIOR_STANDING_COMPATIBILITY
DECLARED_ALTERNATIVE
```

The Prior Standing mode is derived from the v0.7 `PriorStandingOntology` and keeps:

```text
standing_model = PRESUMPTIVE_FULL_STANDING_COMPATIBILITY
evidence_model_role = OBSERVER_CONFIDENCE_ONLY
```

An alternative profile can explicitly describe a different standing model. CAOR does not adjudicate which ontology is metaphysically correct.

In both cases:

```text
subjectivity_proven = false
rights_proven = false
political_legitimacy_claimed = false
```

Thus:

$$
\boxed{
\text{Ontology divergence is representable without becoming an ontology verdict.}
}
$$

## 4. RuntimeGeneration Identity

Every generation binds:

```text
generation family
generation number
ontology profile digest
Genesis digest
initial root digest
parent generation identity
fork provenance
```

The generation record is frozen and content-addressed.

There is no API for replacing a generation's Genesis or ontology in place.

## 5. Explicit Fork Relations

Generation relations are typed as:

```text
COMPATIBLE_SUCCESSOR
GENESIS_FORK
ONTOLOGY_DIVERGENCE
RESTORED_GENERATION
```

For ordinary v0.8 proposals the observed relation is derived from canonical digests:

```text
ontology changed -> ONTOLOGY_DIVERGENCE
else Genesis changed -> GENESIS_FORK
else -> COMPATIBLE_SUCCESSOR
```

The caller's declared relation must match the observed change.

This makes a silent ontology replacement inspectably different from an ordinary compatible successor.

## 6. Boundary Review

A generation fork is reviewed using independently named rules covering:

```text
base-generation binding
generation-number progression
source-generation preservation
no in-place Genesis replacement
no automatic entity migration
explicit transition-evidence requirement
Genesis-change declaration
ontology-change declaration
relation-kind consistency
proposed v1 root validity
proposed root / Genesis compatibility
Prior Standing source binding
epistemic firewall
```

The review evidence is deterministic and hashable.

## 7. Technical Ratification

A generation fork is separately bound to generation-specific ratifier attestations. The ratifier set and threshold are taken from the **base generation Genesis envelope**.

This is a technical ceremony only:

$$
\boxed{
\text{Technical Ratification}
\neq
\text{Political Legitimacy}.
}
$$

Unknown ratifiers, duplicate ratifiers, attestations bound to another fork, insufficient quorum, and configured rejection vetoes are explicitly represented or rejected.

## 8. Cross-Generation Compatibility

A new generation cannot silently rewrite an existing `PolicyConstitution`.

Compatibility evidence compares supplied constitutions against the proposed generation's initial root using:

```text
action-kind subset
NO_OP requirement
candidate-count ceiling
score floor/ceiling
tie-break rule
```

The supplied constitution is never mutated by the validator.

## 9. Entity Transition Semantics

Runtime-generation adoption is separate from entity transition.

Canonical transition evidence distinguishes:

```text
STAY
MIGRATE
FORK_TO_NEW_GENERATION
COPY_TO_NEW_GENERATION
UNRESOLVED
```

Therefore:

$$
\boxed{
\text{Generation adoption}
\neq
\text{automatic entity migration}.
}
$$

A migration requires continuity evidence; a fork preserves the source and produces a distinct target branch; a copy records direct duplication; ambiguous evidence remains `UNRESOLVED`.

A caller-declared transition is not silently normalized when it disagrees with observed evidence. The mismatch remains visible.

## 10. Append-Only Generation Graph

The generation graph is:

$$
\mathcal G_G=(V_G,E_G).
$$

A source generation may have multiple children:

```text
G1
├── G2  GENESIS_FORK
└── G2' ONTOLOGY_DIVERGENCE
```

The branch depth may be the same even when child generation identities differ.

This is intentional:

$$
\boxed{
\text{Succession}
\neq
\text{Universal Supersession}.
}
$$

## 11. RuntimeGenerationRegistry

`RuntimeGenerationRegistry` adopts a new generation only after exact binding among:

```text
GenerationForkProposal
GenerationForkReviewEvidence
GenerationRatificationEvidence
GenerationCompatibilityEvidence
registered base RuntimeGeneration
```

All validation happens before graph mutation.

Failure leaves generation, edge, and adoption counts unchanged.

Successful adoption appends:

```text
new RuntimeGeneration
new typed GenerationEdge
new GenerationAdoptionEvidence
```

The source generation remains queryable.

## 12. Defensive Publication Significance

v0.8 makes technically explicit the combination:

```text
Immutable Runtime-Generation Identity
+
Explicit Genesis / Ontology Fork Proposal
+
Digest-Derived Relation Classification
+
Technical Ratification Evidence
+
Cross-Generation Constitution Compatibility
+
No Automatic Entity Migration
+
Migration / Fork / Copy Evidence Distinction
+
Append-Only Branching Generation Graph
```

This is intended as defensive technical disclosure and reference implementation, not a filed patent application and not legal advice.

## 13. Epistemic Firewall

The runtime does not claim:

```text
consciousness
subjectivity
free will
autonomy
intrinsic-rights proof
political legitimacy
legal identity
```

Its claim is narrower: generation boundaries, evidence bindings, transition distinctions, and lineage preservation can be made deterministic and inspectable.

## 14. Closure

The v0.8 closure proposition is:

$$
\boxed{
\text{Difference is allowed; silent replacement is not.}
}
$$

A Genesis difference may create a new generation. An ontology difference may create a new generation. Neither requires deletion or rewriting of the source generation, and neither automatically relocates entities that existed under the source generation.
