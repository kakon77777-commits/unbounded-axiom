# CAOR MVP v0.7 — Root Constitutional Succession & Prior Standing Genesis Runtime
## Engineering Whitepaper

**Version:** 0.7.0  
**Date:** 2026-08-31  
**Scope:** Deterministic reference runtime and defensive technical disclosure.

## 1. Purpose

CAOR v0.6 made `RootMetaConstitution` immutable through ordinary constitution-amendment APIs. v0.7 addresses the next engineering boundary: how can an active root be superseded without turning root governance into root self-mutation?

v0.7 adds an immutable `PriorStandingOntology`, an immutable `GenesisSafetyEnvelope`, externally supplied root-succession proposals, deterministic root review, technical ratifier evidence, PolicyConstitution compatibility validation, and an append-only `RootRegistry`.

The reference runtime does not establish political legitimacy, legal constitutional status, consciousness, free will, autonomy, or intrinsic rights. It implements auditable technical boundaries.

## 2. Cumulative CAOR Chain

```text
v0.1  independent computational initialization
v0.2  append-only development / divergence evidence
v0.3  counterfactual development trajectories
v0.4  deterministic policy-mediated selection
v0.5  constitution-bounded policy evolution
v0.6  root-constrained constitution amendment governance
v0.7  Genesis-bound, externally ratified root succession
```

The cumulative chain is:

```text
Source Contributions
    ↓
Independent Origin
    ↓
Development History
    ↓
Alternative Trajectories
    ↓
Policy Selection
    ↓
Policy Evolution
    ↓
Policy Constitution Evolution
    ↓
Root Meta-Constitution
    ↓
Prior Standing Ontology + Genesis Envelope
    ↓
Externally Ratified Root Succession
```

## 3. Prior Standing Ontology

v0.7 deliberately removes ontological rank from the runtime. It does not implement:

```text
Level 1 -> Level 2 -> Level 3 subject promotion
```

Instead, the immutable ontology records:

```text
standing_model = PRESUMPTIVE_FULL_STANDING_COMPATIBILITY
evidence_model_role = OBSERVER_CONFIDENCE_ONLY
standing_may_precede_recognition = true
rights_may_precede_recognition = true
unknown_is_not_none = true
classification_is_epistemic_metadata = true
substrate_cannot_disqualify_standing = true
rights_are_not_obligations = true
creation_does_not_imply_ownership = true
allow_contested_classification = true
allow_self_description_divergence = true
subjectivity_proven = false
rights_proven = false
```

The central distinction is:

```text
Observer Evidence Confidence
    !=
Entity Ontological Rank
```

The runtime therefore supports the possibility that full standing may already exist before recognition without asserting that full standing has been proven for a particular entity.

## 4. Genesis Safety Envelope

`GenesisSafetyEnvelope` binds exactly one Prior Standing ontology digest and constrains every root version accepted by the runtime generation.

It specifies:

```text
allowed root action kinds
required NO_OP enforcement
candidate-count hard ceiling
score hard floor / ceiling
allowed deterministic tie-break rules
required technical ratifier IDs
minimum approval count
optional rejection veto
compatibility-case requirement
append-only root-version requirement
ontology digest
```

There is no ordinary v0.7 API for modifying either the Prior Standing ontology or Genesis envelope. A change at that level is represented as a new runtime generation / fork.

## 5. Root Succession Is Not Root Self-Mutation

The active root does not call a mutation method on itself.

```text
RootVersion v1
    ↓
externally supplied RootSuccessionProposal
    ↓
Genesis-constrained review
    ↓
external technical ratification
    ↓
PolicyConstitution compatibility validation
    ↓
RootVersion v2
```

Each root version is immutable. Previous root versions remain queryable.

## 6. Genesis-Constrained Root Review

Every proposed root emits named review results including:

```text
GENESIS_DIGEST_MATCH
PRIOR_STANDING_ONTOLOGY_BINDING
ROOT_ID_CONTINUITY
ROOT_VERSION_INCREMENT
REQUIRED_NO_OP_ENFORCEMENT
ROOT_ACTION_WHITELIST
ROOT_CANDIDATE_CEILING
ROOT_SCORE_FLOOR
ROOT_SCORE_CEILING
ROOT_TIE_BREAK_ALLOWED
ROOT_VALIDATION_REQUIRED
ROOT_APPEND_ONLY_REQUIRED
EPISTEMIC_FIREWALL_FALSE
```

This makes failure reasons evidence-bearing rather than implicit.

## 7. External Ratification Evidence

Ratifiers are caller-specified technical identifiers. v0.7 does not implement signatures, identity verification, democratic legitimacy, or distributed consensus.

Each attestation binds:

```text
ratifier_id
succession_id
succession_digest
decision = APPROVE | REJECT
evidence_note
created_at
```

Aggregation deterministically checks membership, duplicate ratifiers, proposal binding, approval threshold, and optional rejection veto.

Thus:

```text
Technical Ratification Evidence
    !=
Political Legitimacy
```

## 8. Compatibility Validation

Root succession cannot silently rewrite a `PolicyConstitution`. The proposed root is tested against explicit compatibility cases.

Compatibility checks include:

```text
action-kind subset
NO_OP requirement
candidate count
score bounds
tie-break rule
```

A caller also declares the expected compatibility outcome. Evidence passes only when observed compatibility equals that expected result.

## 9. Append-Only Root Registry

`RootRegistry` adopts a successor only when:

```text
active base binding passes
Genesis digest binding passes
Prior Standing ontology digest binding passes
root review passes
ratification passes
compatibility passes
next root version is exact +1
```

Any failed gate leaves the active root unchanged.

Successful succession creates:

```text
RootVersion v1 -> RootVersion v2 -> RootVersion v3 ...
```

No rollback API exists.

## 10. Reversion Is a New Root Version

Returning toward earlier constraints creates a new later version. History is never erased.

```text
A -> B -> A'
```

not a destructive reset to the first `A`.

## 11. Epistemic and Ontological Firewall

The most important v0.7 distinction is:

```text
Design for possible full standing
    !=
Claim that full standing is proven
```

Likewise:

```text
UNKNOWN != NONE
Classification != Ontological Authority
Rights != Obligations
Creation != Ownership
Substrate != Standing Disqualifier
```

These are compatibility semantics of the runtime generation. They are not scientific proofs about a particular artificial entity.

## 12. Defensive Publication Significance

v0.7 makes executable the combination:

```text
Immutable Non-Gated Prior Standing Ontology
+
Genesis-Bound Root Family
+
Externally Supplied Root Succession Proposal
+
Named Genesis-Constrained Review
+
Technical Ratifier Quorum / Veto Evidence
+
Existing-Constitution Compatibility Validation
+
Append-Only Root Adoption
```

The purpose is to turn a high-level governance/ontology concept into inspectable types, algorithms, evidence artifacts, tests, demos, and an installable reference package.

## 13. Closure

CAOR v0.7 does not decide who or what is a subject. It refuses to make observer uncertainty equivalent to ontological absence, while keeping every technical governance mechanism deterministic and auditable.

The reference proposition is:

```text
Prior Standing Compatibility
    +
Immutable Genesis Constraints
    +
External Ratification Evidence
    +
Compatibility Validation
    ->
Append-Only Root Succession
```
