# CAOR MVP v0.3 — Counterfactual Development Branching Runtime
## Engineering Whitepaper

**Version:** 0.3.0  
**Date:** 2026-08-30

## 1. From divergence to counterfactual development

CAOR v0.1 made independent initialization and typed lineage executable. v0.2 added append-only development evidence, deterministic replay, source-derived origin projection, and cross-time divergence.

v0.3 adds a missing intermediate layer: a single generated origin can be evaluated under multiple explicitly supplied development scenarios without cloning or mutating a common live object.

The resulting pipeline is:

```text
Contribution Bundles
      ↓
Manifest
      ↓
OIS / Independent Origin
      ↓
CounterfactualBranchSpec[]
      ├── baseline
      ├── research path
      └── creative path
      ↓
Isolated OffspringEntity per branch
      ↓
DevelopmentLedger per branch
      ↓
Replay + Origin Projection
      ↓
CounterfactualTrajectory[]
      ↓
Pairwise Comparison
      ↓
CounterfactualEvidenceBundle
```

## 2. Why this matters

An initialization system can be deterministic without implying that every later development state is uniquely determined by the initialization record. A runtime can expose a set of feasible subsequent event histories while remaining fully deterministic for each individual history.

Thus:

$$
\boxed{
\text{Deterministic Replay}
\neq
\text{Unique Future Path}.
}
$$

This is a software-architecture statement, not a free-will claim.

## 3. Branches are simulations, not identity forks

A CAOR v0.3 counterfactual branch is an evidence simulation over one OIS. It is not automatically written into the v0.1 identity lineage graph as a `FORK` event.

This distinction is essential:

$$
\boxed{
\text{Counterfactual Branch}
\neq
\text{Identity Fork}.
}
$$

The former is a simulated feasible trajectory. The latter is a canonical identity-lineage event representing an extant branch.

## 4. No bypass of parent-write boundaries

`SOURCE_PROPOSAL` deliberately composes existing v0.2 APIs:

```text
source -> proposal(PENDING)
branch entity -> accept_proposal
ledger -> ACCEPT_PROPOSAL
```

The counterfactual runtime therefore cannot introduce a shortcut in which a parent source writes protected or mutable child state directly.

## 5. Replay-based branch state

A branch trajectory's final state is not trusted merely because a live dictionary says so.

CAOR reconstructs the branch event history through the v0.2 ledger semantics and combines it with the deterministic origin projection.

This makes each trajectory independently inspectable.

## 6. Pairwise trajectory evidence

Two trajectories can be compared even if they share the same OIS and source manifest.

The runtime reports:

- final-state digests;
- normalized state distance;
- keys that differ;
- development-ledger digests.

This permits an observer to distinguish:

```text
same origin + same history
```

from:

```text
same origin + different history
```

without using narrative descriptions.

## 7. Counterfactual evidence flags

Every aggregate bundle includes:

```text
subjectivity_claimed = false
free_will_claimed = false
autonomy_claimed = false
```

These flags are not decoration. They are part of the canonical evidence payload and therefore affect its digest.

## 8. Defensive publication significance

The disclosed combination now spans three layers:

$$
\boxed{
\text{Independent Initialization}
+
\text{Append-Only Development Provenance}
+
\text{Counterfactual Trajectory Comparison}.
}
$$

This makes the underlying concept substantially easier to implement and inspect than a high-level statement that an artificial offspring "may develop differently from its parents."

## 9. What v0.3 still does not prove

It does not prove:

- that the entity possesses intrinsic preferences;
- that a SELF_UPDATE was phenomenally self-authored;
- that one branch was truly chosen;
- that the entity could have done otherwise in a metaphysical sense;
- consciousness;
- legal or moral child status.

The precise statement is narrower:

> The same independently initialized computational origin can be executed under multiple supplied feasible event sequences, each producing isolated, replayable, and comparable development evidence.

## 10. Closure

v0.1 answers **what kind of initialization event occurred**.

v0.2 answers **what happened over time**.

v0.3 answers **what different supplied development paths from the same origin produce**.

Together:

$$
\boxed{
\text{Origin}
\rightarrow
\text{History}
\rightarrow
\text{Counterfactual Trajectory Space}.
}
$$
