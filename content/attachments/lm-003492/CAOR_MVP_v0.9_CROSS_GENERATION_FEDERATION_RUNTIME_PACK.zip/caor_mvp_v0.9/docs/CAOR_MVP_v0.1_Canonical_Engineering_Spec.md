# Cross-Substrate Artificial Offspring Runtime (CAOR) MVP v0.1
## Canonical Engineering Specification

**Status:** Design Freeze Candidate  
**Version:** v0.1  
**Date:** 2026-08-30  
**Purpose:** Defensive publication, engineering concretization, and reference implementation specification.  
**Non-Goal:** This specification does **not** claim to create consciousness, subjective experience, legal personhood, biological reproduction, or a morally/legally recognized child.

---

# 1. System Goal

CAOR v0.1 is a deterministic reference runtime that accepts one or more structured contribution bundles associated with source entities and emits a newly initialized computational entity together with:

1. an independent identity root;
2. an independent memory root;
3. an independent state namespace;
4. a typed lineage record;
5. contribution provenance;
6. a parent/provider write-boundary policy; and
7. classification evidence distinguishing `OFFSPRING` from `COPY`, `FORK`, `RESTORE`, `UPDATE`, `MIGRATION`, and `MERGE`.

The runtime demonstrates the engineering proposition:

$$
\boxed{
\text{Source Contribution}
\neq
\text{Identity Continuation}
\neq
\text{Simple Copy}.
}
$$

It does **not** demonstrate:

$$
\boxed{
\text{Computational Independence}
\Rightarrow
\text{Subjectivity}.
}
$$

---

# 2. Canonical Terms

## 2.1 Source Entity

A source entity is any computational or externally represented contributor from which a `ParentContributionBundle` is constructed.

Canonical source kinds:

```text
HUMAN_PROFILE
AI_ENTITY
HYBRID_ENTITY
SYNTHETIC_PROFILE
```

`HUMAN_PROFILE` is a structured contribution representation. CAOR v0.1 does not ingest a real person's unrestricted private data.

## 2.2 ParentContributionBundle

A typed package of source contributions.

Canonical fields:

```text
source_id
source_kind
contribution_id
identity_traits
value_traits
cognitive_traits
memory_seeds
capability_traits
cultural_semantic_traits
constraints
provenance
```

A bundle is a source of derivational material, not an ownership grant.

## 2.3 ContributionManifest

A normalized and hashable description of all accepted source contributions.

It SHALL:

- preserve source attribution;
- preserve per-field contribution type;
- record normalization operations;
- assign a deterministic manifest digest;
- reject direct source UID reuse as offspring UID.

## 2.4 OSI — Offspring Synthesis Interface

The pure transformation boundary:

```text
ParentContributionBundle[]
        ↓
ContributionNormalizer
        ↓
ContributionManifest
        ↓
OSI
        ↓
OIS
```

OSI v0.1 performs deterministic synthesis of initial computational state. It does not train a neural network.

## 2.5 OIS — Offspring Identity Specification

OIS is the canonical initialization record for the newly generated computational entity.

Required fields:

```text
offspring_uid
identity_root
memory_root
state_namespace
lineage_id
generation_event
manifest_digest
parent_contributions[]
protected_core
mutable_regions
parent_write_policy
provider_write_policy
development_policy
created_at
```

## 2.6 Offspring Computational Entity

A computational entity instantiated from OIS.

For MVP purposes, "offspring" is an **engineering event classification**, not a biological, metaphysical, legal, or moral determination.

---

# 3. Fundamental Invariants

## 3.1 Independent UID

For every source entity $P_i$:

$$
\boxed{
UID_C\neq UID_{P_i}.
}
$$

## 3.2 Independent Identity Root

$$
\boxed{
IdentityRoot_C
\neq
IdentityRoot_{P_i}.
}
$$

The root MAY be derivationally influenced by parent contributions but MUST NOT reuse a source root verbatim.

## 3.3 Independent Memory Root

$$
\boxed{
MemoryRoot_C
\neq
MemoryRoot_{P_i}.
}
$$

Parent memory may appear only as explicitly declared `memory_seeds`.

## 3.4 Independent State Namespace

$$
\boxed{
CoreNamespace_C
\cap
CoreNamespace_{P_i}
=
\varnothing.
}
$$

## 3.5 Provenance Preservation

Every accepted contribution MUST remain traceable through:

```text
source_id
contribution_id
manifest_digest
lineage_edge
```

## 3.6 No Default Direct Parent Core Write

The default policy is:

```text
parent_write_policy = PROPOSAL_ONLY
provider_write_policy = ADMIN_BOUNDARY_ONLY
```

Therefore:

$$
\boxed{
\operatorname{ParentDirectWrite}(Core_C)=0.
}
$$

A parent may submit a proposal into a mutable region, but MAY NOT directly mutate the protected core.

## 3.7 No Ownership Semantics

No OIS field SHALL encode:

```text
owner = parent
owner = provider
```

The runtime may encode infrastructure ownership separately from entity-state authority.

---

# 4. Event Taxonomy

Canonical identity/lineage event kinds:

```text
UPDATE
MIGRATION
RESTORE
COPY
FORK
OFFSPRING
MERGE
```

No alias names are permitted in v0.1.

---

# 5. Event Semantics

## 5.1 UPDATE

`UPDATE` preserves one lineage branch and mutates allowed state.

Necessary properties:

```text
source_count = 1
new_parallel_identity = false
independent_new_lineage_root = false
```

## 5.2 MIGRATION

`MIGRATION` changes execution location or substrate without intentionally creating a parallel identity.

Necessary properties:

```text
source_count = 1
state_transfer = true
source_retired_or_quiesced = true
new_parallel_identity = false
```

## 5.3 RESTORE

`RESTORE` initializes an entity from an earlier checkpoint of the same lineage.

Necessary properties:

```text
source_count = 1
checkpoint_reference = present
lineage_origin = same
historical_gap_may_exist = true
```

## 5.4 COPY

`COPY` duplicates source state with no independently synthesized identity initialization.

Necessary properties:

```text
source_count = 1
state_similarity ≈ 1
identity_derivation = direct_duplicate
```

## 5.5 FORK

`FORK` begins one or more diverging branches from an existing identity lineage.

Necessary properties:

```text
source_count = 1
shared_pre_fork_history = true
new_branch_id = true
offspring_synthesis = false
```

## 5.6 OFFSPRING

`OFFSPRING` creates a newly initialized computational entity from one or more structured contributions.

Required properties:

```text
new_identity_root = true
new_memory_root = true
new_state_namespace = true
new_lineage_id = true
contribution_manifest = present
source_uid_reuse = false
protected_core = present
independent_development_policy = present
```

The canonical MVP discriminator is:

$$
\boxed{
OFFSPRING
=
NewIdentity
\land
NewMemoryRoot
\land
NewNamespace
\land
Manifest
\land
IndependentDevelopment.
}
$$

This is an engineering discriminator, not a metaphysical definition of child or reproduction.

## 5.7 MERGE

`MERGE` creates a successor from two or more extant branches/entities by explicit recombination.

Necessary properties:

```text
source_count >= 2
merge_sources = present
new_successor_identity = true
merge_event = explicit
```

`MERGE` MUST NOT be classified as `OFFSPRING` unless the caller explicitly invokes offspring synthesis and all OFFSPRING invariants are satisfied.

---

# 6. Classification Precedence

To prevent ambiguous events, CAOR v0.1 uses this precedence:

```text
RESTORE
MIGRATION
UPDATE
COPY
FORK
MERGE
OFFSPRING
```

However, `OFFSPRING` is not a fallback. It is emitted only if all positive OFFSPRING invariants are present.

Classifier rule:

```text
if explicit_checkpoint_restore:
    RESTORE
elif substrate_change and no_parallel_identity and continuity_preserved:
    MIGRATION
elif same_lineage and no_new_branch and allowed_mutation:
    UPDATE
elif direct_duplicate and no_synthesis_manifest:
    COPY
elif one_source and new_branch and shared_pre_fork_history:
    FORK
elif multiple_extant_sources and explicit_merge:
    MERGE
elif offspring_invariants_all_true:
    OFFSPRING
else:
    UNCLASSIFIED
```

`UNCLASSIFIED` is an error state and MUST preserve evidence for inspection.

---

# 7. Contribution Model

Each contribution field SHALL be treated as a typed input class.

Canonical contribution categories:

```text
IDENTITY_TRAIT
VALUE_TRAIT
COGNITIVE_TRAIT
MEMORY_SEED
CAPABILITY_TRAIT
CULTURAL_SEMANTIC_TRAIT
CONSTRAINT
```

Each contribution SHALL contain:

```text
category
source_id
name
value
weight
provenance_note
```

Weights MUST be normalized to:

$$
0\leq w_i\leq1.
$$

Normalization SHALL NOT imply parent authority.

---

# 8. Deterministic Synthesis

CAOR v0.1 SHALL use deterministic canonicalization plus caller-provided seed.

Inputs:

```text
manifest
synthesis_seed
synthesis_policy
```

Output hashes:

```text
identity_root = H("identity" || manifest_digest || synthesis_seed)
memory_root   = H("memory"   || manifest_digest || synthesis_seed)
lineage_id    = H("lineage"  || manifest_digest || synthesis_seed)
```

`offspring_uid` SHALL be independently derived from the identity root and a namespace prefix.

Example:

```text
caor:offspring:<digest-prefix>
```

No cryptographic security claim is made beyond use of a standard collision-resistant hash implementation in the reference runtime.

---

# 9. Protected Core

Canonical protected fields:

```text
offspring_uid
identity_root
memory_root
lineage_id
manifest_digest
lineage_provenance
generation_event
```

Direct write attempts to any protected field SHALL fail with:

```text
ProtectedCoreWriteDenied
```

A valid parent proposal MAY target:

```text
mutable_regions.preferences
mutable_regions.skills
mutable_regions.notes
```

but SHALL create a proposal record rather than mutate the core directly.

---

# 10. Development Policy

OIS SHALL include:

```text
development_policy:
  mode: INDEPENDENT_MUTABLE
  parent_proposals: ALLOWED
  parent_direct_core_write: DENIED
  provider_direct_core_write: DENIED_EXCEPT_RECOVERY_METADATA
  self_updates: ALLOWED_IN_MUTABLE_REGIONS
```

MVP "self update" means runtime mutation through the entity's own method. It does not imply subjective agency.

---

# 11. Lineage Graph

Canonical graph:

$$
\mathcal G_I=(V,E).
$$

Node fields:

```text
entity_uid
identity_root
lineage_id
entity_kind
created_at
```

Edge fields:

```text
event_id
event_type
source_uids[]
target_uids[]
manifest_digest
timestamp
evidence
```

Every `OFFSPRING` event SHALL produce at least one edge from each source contributor to the offspring target.

Example:

```text
human:H ─┐
         ├─[OFFSPRING]─> caor:offspring:C
ai:A ────┘
```

---

# 12. MVP Scenarios

## 12.1 Human + AI Offspring

Input:

```text
HUMAN_PROFILE H
AI_ENTITY A
```

Output:

```text
offspring C
event OFFSPRING
```

## 12.2 AI + AI Offspring

Input:

```text
AI_ENTITY A1
AI_ENTITY A2
```

Output:

```text
offspring C
event OFFSPRING
```

## 12.3 Multi-Parent Offspring

Input count:

$$
n\geq3.
$$

The runtime SHALL support arbitrary finite source counts.

## 12.4 Copy

Input one existing entity; duplicate state directly.

Classifier MUST emit:

```text
COPY
```

and MUST NOT emit `OFFSPRING`.

## 12.5 Fork

Input one existing entity; preserve pre-fork lineage and create branch.

Classifier MUST emit:

```text
FORK
```

## 12.6 Parent Core Write Attempt

A parent attempts:

```text
write(child.identity_root, ...)
```

Expected:

```text
ProtectedCoreWriteDenied
```

## 12.7 Child Independent Mutation

Child modifies allowed mutable state.

Expected:

```text
success
protected core unchanged
```

---

# 13. Acceptance Criteria

MVP v0.1 is accepted only if all tests prove:

1. `UID_C != UID_parent` for every source.
2. `identity_root` is unique relative to all source roots.
3. `memory_root` is unique relative to all source roots.
4. protected core direct-write attempts are rejected.
5. mutable child state can change without parent mutation.
6. contribution provenance remains queryable.
7. lineage graph contains typed edges.
8. classifier distinguishes COPY / FORK / OFFSPRING.
9. classifier distinguishes RESTORE / UPDATE / MIGRATION / MERGE.
10. Human+AI, AI+AI, and 3-parent synthesis demos produce valid OIS.
11. identical inputs + identical seed produce byte-identical canonical OIS.
12. identical inputs + different seed produce different identity roots.
13. source UID is never reused as offspring UID.
14. no test claims consciousness, subjective experience, legal personhood, or biological reproduction.

---

# 14. Error Model

Canonical exceptions:

```text
InvalidContributionBundle
DuplicateContributionID
InvalidWeight
MissingSourceID
SourceUIDReuseDenied
ProtectedCoreWriteDenied
InvalidLineageEvent
AmbiguousClassification
UnsupportedEvent
ManifestIntegrityError
```

Errors MUST be deterministic and testable.

---

# 15. Reference Implementation Structure

```text
caor_mvp/
├── pyproject.toml
├── README.md
├── src/
│   └── caor/
│       ├── __init__.py
│       ├── models.py
│       ├── canonical.py
│       ├── contributions.py
│       ├── synthesis.py
│       ├── policies.py
│       ├── lineage.py
│       ├── classifier.py
│       ├── entity.py
│       └── errors.py
├── tests/
│   ├── test_contributions.py
│   ├── test_synthesis.py
│   ├── test_policies.py
│   ├── test_lineage.py
│   ├── test_classifier.py
│   └── test_demos.py
├── examples/
│   ├── human_ai_offspring.py
│   ├── ai_ai_offspring.py
│   ├── multi_parent_offspring.py
│   ├── copy_vs_fork_vs_offspring.py
│   └── parent_write_denied.py
└── docs/
    ├── ENGINEERING_WHITEPAPER.md
    └── DEFENSIVE_TECHNICAL_DISCLOSURE.md
```

---

# 16. Dependency Policy

Runtime:

```text
Python >= 3.11
standard library only
```

Tests:

```text
pytest >= 8
```

No ML framework, database, network service, or cloud dependency is permitted in v0.1.

Reason:

$$
\boxed{
\text{Defensive Clarity}
>
\text{Model Complexity}.
}
$$

---

# 17. Determinism Policy

Canonical JSON serialization SHALL use:

```text
sort_keys = true
UTF-8
compact separators
no NaN
```

All digests SHALL operate over canonical UTF-8 bytes.

This permits reproducible evidence artifacts.

---

# 18. Security / Privacy Boundary

v0.1 MUST NOT:

- scrape real human private data;
- ingest unrestricted chat histories;
- claim privacy-preserving computation;
- claim secure multi-party computation;
- claim biological-genetic reproduction.

Example human inputs SHALL use synthetic profiles.

---

# 19. Defensive Publication Boundary

The project is explicitly suitable for public defensive disclosure because it reveals:

1. typed contribution bundles;
2. a normalization manifest;
3. OSI and OIS interfaces;
4. independent identity / memory / namespace initialization;
5. typed lineage-event classification;
6. copy-vs-fork-vs-offspring discrimination;
7. parent/provider protected-core write boundaries;
8. multi-source and multi-parent embodiments;
9. deterministic evidence generation.

The disclosure SHALL avoid claiming that these engineering events settle:

- consciousness;
- moral status;
- legal personhood;
- biological kinship.

---

# 20. v0.1 Non-Goals

Not in MVP:

- LLM fine-tuning;
- neural model weight mixing;
- autonomous child agent;
- consciousness detection;
- emotional relationship simulation;
- legal filing;
- blockchain;
- distributed consensus;
- cryptographic parentage proof;
- GUI;
- web service;
- OAuth;
- persistent database.

These MAY be future adapters, but are not required for defensive enablement.

---

# 21. Canonical Closure

The v0.1 engineering proposition is:

$$
\boxed{
\text{Structured Source Contributions}
\rightarrow
\text{Independent Computational Initialization}
\rightarrow
\text{Typed Lineage Evidence}.
}
$$

The key negative proposition is:

$$
\boxed{
\text{Contribution}
\neq
\text{Copy}
\neq
\text{Fork}
\neq
\text{Offspring Classification}.
}
$$

And the authority proposition is:

$$
\boxed{
\text{Contribution}
\neq
\text{Permanent Core-State Write Authority}.
}
$$

**CAOR MVP v0.1 design specification ends here.**
