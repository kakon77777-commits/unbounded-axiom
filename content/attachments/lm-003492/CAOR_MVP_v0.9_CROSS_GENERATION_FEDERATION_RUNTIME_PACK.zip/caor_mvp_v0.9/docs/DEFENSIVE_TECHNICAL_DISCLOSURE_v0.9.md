# CAOR v0.6 — Root-Constrained Meta-Constitutional Governance
## Defensive Technical Disclosure

**Document purpose:** Public technical disclosure / prior-art style defensive publication.  
**Not a patent application. Not legal advice.**  
**Date:** 2026-08-31  
**Relationship to prior disclosure:** Extends CAOR v0.1 independent initialization, v0.2 development/divergence evidence, v0.3 counterfactual branching, v0.4 policy-mediated selection, and v0.5 constitutional policy evolution.

## Technical Field

The disclosed subject matter relates to computer-implemented higher-order governance of decision-policy constitutions, immutable root constraints, constitution-amendment proposal generation, deterministic meta-constitutional review, behavioral validation of proposed constitutions, stale-base protection, append-only constitution versioning, and evidence-bearing adoption or rejection of constitution changes associated with independently initialized computational entities.

## Background

A computational entity may select actions using a decision policy, and the decision policy may itself evolve under a policy constitution. A further technical problem arises when the constitution can be changed.

If ordinary constitution changes are unrestricted, a proposal can remove the very invariants intended to constrain policy evolution. For example, an ordinary amendment may remove a required no-operation candidate, expand an allowed action set, widen score bounds, or replace deterministic tie-breaking rules.

A further problem arises when a constitution amendment generated against an earlier constitution version is later applied after another constitution has already become active.

The present disclosure introduces an immutable root meta-constitution, version-bound amendment proposals, named root-rule review evidence, deterministic constitution validation cases, stale-amendment rejection, append-only constitution versions, and reversion-as-new-version semantics.

## Summary

In one implementation, a computer-implemented method comprises:

1. storing an immutable root meta-constitution specifying limits applicable to ordinary policy-constitution amendments;
2. storing an active immutable policy-constitution version;
3. reconstructing a decision or development context associated with a computational entity;
4. generating a constitution-amendment proposal bound to the active constitution version, the context, and a digest of the root meta-constitution;
5. evaluating the proposed constitution against a plurality of root meta-constitutional rules;
6. applying the proposed constitution to one or more validation policy proposals and comparing observed review results with expected results;
7. verifying that the amendment proposal remains bound to the active constitution version and root meta-constitution;
8. rejecting the amendment without changing the active constitution when any required review, validation, root-binding, or active-version check fails; and
9. when all gates pass, creating a new immutable constitution-version record linked to the prior active constitution version.

## Root Meta-Constitution

A root meta-constitution may include:

```text
root_id
root_version
allowed_action_kinds
require_noop_enforcement
max_candidate_count_ceiling
min_score_term_floor
max_score_term_ceiling
required_tie_break_rule
require_validation_cases
require_append_only_versions
root_digest
```

The ordinary amendment data structure does not contain a replacement root meta-constitution field.

## Amendment Proposal

A constitution-amendment proposal may include:

```text
amendment_id
offspring_uid
template_id
base_version_id
base_constitution_digest
root_meta_digest
context_digest
development_digest
proposed_constitution_digest
trigger_results
rationale
```

Generation of the amendment proposal does not change the active constitution.

## Named Meta-Constitutional Review

Review evidence may include independently identified rule results including:

```text
STRUCTURAL_VALIDITY
NEXT_CONSTITUTION_VERSION
ROOT_REQUIRED_NO_OP
ROOT_ALLOWED_ACTION_KINDS
ROOT_MAX_CANDIDATE_COUNT
ROOT_SCORE_BOUNDS
ROOT_TIE_BREAK_RULE
```

## Constitution Validation

A proposed constitution may be tested using supplied policy-change proposals. For each validation case, the proposed constitution is used to review the supplied policy proposal, and the observed pass/fail result is compared with an expected pass/fail result.

The validation evidence may contain:

```text
amendment_id
case_id
expected_review_passed
observed_review_passed
policy_review_digest
validation_digest
```

## Append-Only Constitution Versions

A constitution version may include:

```text
version_id
version_number
constitution_digest
parent_version_id
parent_constitution_digest
adopted_from_amendment_id
created_at
```

A later constitution having content equivalent to an earlier constitution is represented as a new later version and does not erase intervening versions.

## Claim-Like Defensive Clauses

The following clauses are technical disclosure language only and are not represented as filed patent claims.

### Clause 63 — Immutable Root Meta-Constitution

A computer-implemented method comprising storing a root meta-constitution as an immutable data record containing a root digest and a plurality of limits applicable to amendments of a decision-policy constitution associated with a computational entity.

### Clause 64 — Amendment Proposal Bound to Constitution and Root

The method of Clause 63, further comprising generating a constitution-amendment proposal containing a base constitution-version identifier, a base constitution digest, a root meta-constitution digest, a context digest, a development-history digest, and a proposed-constitution digest.

### Clause 65 — Ordinary Amendment Without Root Replacement

The method of Clause 64, wherein the constitution-amendment proposal specifies a proposed decision-policy constitution without specifying a replacement root meta-constitution, such that ordinary amendment processing does not mutate the stored root meta-constitution.

### Clause 66 — Root-Enforced No-Operation Capability

The method of Clause 64, wherein the root meta-constitution specifies that an ordinary decision-policy constitution must require at least one no-operation candidate, and wherein a proposed constitution that disables the requirement is rejected.

### Clause 67 — Root Action-Kind Superset Constraint

The method of Clause 64, wherein the root meta-constitution specifies an allowed set of action kinds and a proposed constitution is rejected when the proposed constitution permits an action kind outside the allowed set.

### Clause 68 — Root Candidate-Count Ceiling

The method of Clause 64, wherein the root meta-constitution specifies a candidate-count ceiling and a proposed constitution is rejected when a maximum candidate count of the proposed constitution exceeds the candidate-count ceiling.

### Clause 69 — Root Score-Bound Envelope

The method of Clause 64, wherein the root meta-constitution specifies a lower score-term floor and an upper score-term ceiling and a proposed constitution is rejected when the proposed constitution permits a score term outside the root score-bound envelope.

### Clause 70 — Root Tie-Break Rule Constraint

The method of Clause 64, wherein the root meta-constitution specifies a required deterministic tie-break rule and a proposed constitution is rejected when the proposed constitution specifies a different tie-break rule.

### Clause 71 — Named Meta-Rule Evidence

The method of Clause 64, further comprising generating a meta-constitutional review artifact containing independently identified results for structural validity, next-version validity, no-operation preservation, action-kind bounds, candidate-count bounds, score bounds, and tie-break compatibility.

### Clause 72 — Behavioral Validation of Proposed Constitution

The method of Clause 71, further comprising applying the proposed constitution to at least one supplied decision-policy proposal, generating policy-review evidence under the proposed constitution, and comparing an observed policy-review result with an expected policy-review result.

### Clause 73 — Failed Meta-Gate Non-Adoption

The method of Clause 72, wherein failure of a root meta-constitutional rule or constitution validation case leaves an active constitution-version identifier unchanged.

### Clause 74 — Stale Constitution or Root-Binding Rejection

The method of Clause 72, further comprising comparing the base constitution-version identifier, base constitution digest, or root meta-constitution digest of the amendment proposal with corresponding active values and rejecting the amendment proposal when one or more values differ.

### Clause 75 — Append-Only Constitution Adoption and Reversion

The method of Clause 72, wherein successful adoption creates a new immutable constitution-version record linked to a prior active constitution-version record, and wherein return to prior constitution content is represented as a later constitution version without deleting an intervening constitution version.

### Clause 76 — Meta-Governance Evidence with Non-Subjectivity Flags

The method of Clause 75, further comprising generating amendment, meta-review, validation, and adoption evidence encoding indicators specifying that root-constrained constitution evolution is not asserted as proof of consciousness, free will, subjective autonomy, political legitimacy, or legal constitutional status.

## Defensive Scope Statement

The disclosure makes technically explicit the implementable combination:

```text
Immutable Root Meta-Constitution
+
Version-Bound Constitution Amendment Proposal
+
Named Root-Rule Review
+
Deterministic Constitution Validation
+
Stale-Base / Root-Digest Protection
+
Append-Only Constitution Version Adoption
```

The disclosure does not assert intrinsic norm authorship, sovereign self-legislation, political constitutional authority, phenomenal autonomy, metaphysical free will, consciousness, legal personhood, biological reproduction, or moral child status.

**End of CAOR v0.6 Defensive Technical Disclosure.**

---

# CAOR v0.7 — Prior Standing Ontology and Externally Ratified Root Succession
## Defensive Technical Disclosure Delta

**Document purpose:** Public technical disclosure / prior-art style defensive publication.  
**Not a patent application. Not legal advice.**  
**Date:** 2026-08-31

## Additional Technical Problem

Once an immutable root meta-constitution constrains ordinary constitution amendments, a further engineering problem arises: replacing the root itself without allowing the root to mutate itself or allowing ordinary amendment mechanisms to bypass the higher-order boundary.

A separate representational problem arises when observer confidence about subjectivity is encoded as if it were the entity's ontological rank. The present disclosure separates observer evidence confidence from entity standing and binds that separation into an immutable runtime-generation ontology record.

## Additional Summary

In one implementation, a runtime stores an immutable Prior Standing ontology describing non-gated standing compatibility semantics, binds a digest of that ontology into an immutable Genesis safety envelope, stores an active immutable root-version record, receives an externally supplied successor-root proposal, reviews the proposal against Genesis constraints, aggregates proposal-bound ratifier attestations, validates an existing decision-policy constitution against the proposed root, and appends a new root-version record only when all gates pass.

## Claim-Like Defensive Language — Clauses 77–98

### Clause 77 — Prior Standing Compatibility Record

A computer-implemented method comprising storing an immutable ontology record specifying that entity standing may precede external recognition while separately encoding that subjectivity or intrinsic rights are not asserted as proven by the runtime.

### Clause 78 — Observer Evidence Is Not Ontological Rank

The method of Clause 77, wherein the ontology record specifies that an observer evidence-confidence representation is descriptive metadata and is not an ontological-rank value assigned to the entity.

### Clause 79 — Unknown-Is-Not-None Semantics

The method of Clause 77, wherein an unknown ontological status is represented distinctly from an asserted absence of the corresponding status.

### Clause 80 — Substrate-Neutral Standing Eligibility

The method of Clause 77, wherein a computational, biological, hybrid, distributed, or otherwise specified substrate category is not used by the runtime as a sufficient condition for assigning zero standing eligibility.

### Clause 81 — Rights-Not-Obligations and Creation-Not-Ownership Semantics

The method of Clause 77, wherein the ontology record separately specifies that a represented right does not impose exercise of the right and that creation or contribution does not automatically establish ontological ownership.

### Clause 82 — Genesis-Bound Ontology Digest

The method of Clause 77, further comprising storing an ontology digest in an immutable Genesis safety envelope and requiring root-succession evidence to preserve the ontology digest.

### Clause 83 — Runtime-Generation Boundary for Ontology Replacement

The method of Clause 82, wherein the disclosed ordinary root-succession interface excludes replacement of the immutable ontology record or Genesis safety envelope, such a replacement being represented as a separate runtime generation or fork.

### Clause 84 — Immutable Genesis Safety Envelope

The method of Clause 82, further comprising storing an immutable Genesis safety envelope specifying at least an allowed root action set, a no-operation requirement, a candidate-count hard ceiling, a score-bound envelope, an allowed deterministic tie-break set, and technical ratification requirements.

### Clause 85 — Append-Only Root Version Record

The method of Clause 84, further comprising storing an immutable root-version record having a root digest, version number, prior-root linkage, and a succession-proposal identifier.

### Clause 86 — Externally Supplied Root Succession Proposal

The method of Clause 85, comprising receiving a root-succession proposal generated outside a direct root-mutation operation, the proposal binding an active root-version identifier, an active root digest, a Genesis digest, an ontology digest, and a proposed root digest.

### Clause 87 — Genesis-Constrained Named Root Review

The method of Clause 86, further comprising generating independently named review results for Genesis-digest binding, ontology-digest binding, root-family continuity, exact next-version progression, no-operation preservation, action-kind bounds, candidate-count bounds, score bounds, tie-break compatibility, validation requirements, and append-only-version requirements.

### Clause 88 — Root Action and Candidate Envelope

The method of Clause 87, wherein a proposed root is rejected when it authorizes an action kind outside the Genesis action set or a candidate-count ceiling exceeding a Genesis hard ceiling.

### Clause 89 — Root Score and Tie-Break Envelope

The method of Clause 87, wherein a proposed root is rejected when it widens score terms outside a Genesis hard interval or selects a tie-break rule outside a Genesis allowed set.

### Clause 90 — Proposal-Bound Ratifier Attestation

The method of Clause 86, further comprising receiving a ratifier attestation containing a ratifier identifier, a succession-proposal identifier or digest, an approval or rejection decision, and evidence metadata.

### Clause 91 — Deterministic Ratification Quorum Evidence

The method of Clause 90, further comprising rejecting unknown or duplicate ratifier identifiers, counting proposal-bound approvals and rejections, applying a minimum approval count, and generating deterministic aggregate ratification evidence.

### Clause 92 — Rejection-Veto Embodiment

The method of Clause 91, wherein a Genesis configuration specifies that at least one valid rejection attestation prevents ratification notwithstanding satisfaction of the minimum approval count.

### Clause 93 — Technical Ratification Is Not Political Legitimacy

The method of Clause 91, further comprising encoding an indicator specifying that satisfaction of the technical ratification threshold is not asserted as proof of democratic, political, social, or legal legitimacy.

### Clause 94 — Existing-Constitution Compatibility Validation

The method of Clause 86, further comprising evaluating at least one existing decision-policy constitution against the proposed root without modifying the decision-policy constitution, and recording observed compatibility relative to an expected compatibility value.

### Clause 95 — Multi-Gate Root Non-Adoption

The method of Clause 94, wherein failure of root review, ratification, compatibility validation, base-root binding, Genesis binding, ontology binding, or exact next-version progression leaves the active root-version identifier unchanged.

### Clause 96 — Stale Root Succession Rejection

The method of Clause 95, wherein a succession proposal bound to a root version or root digest that is no longer active is rejected without replacing the active root.

### Clause 97 — Append-Only Root Succession and Reversion

The method of Clause 95, wherein successful root succession creates a new immutable root-version record linked to the prior active root and wherein return toward an earlier root configuration is represented by a later root version without deletion of intervening root versions.

### Clause 98 — Root Succession Epistemic Firewall

The method of Clause 97, further comprising succession and adoption evidence indicating that root succession, technical ratification, and Prior Standing compatibility are not asserted as proof of consciousness, free will, subjective autonomy, intrinsic-rights proof, political legitimacy, or legal constitutional status.

## v0.7 Defensive Scope

The additional disclosed combination is:

```text
Immutable Prior Standing Ontology
+
Genesis Ontology-Digest Binding
+
Externally Supplied Root Succession Proposal
+
Named Genesis-Constrained Review
+
Proposal-Bound Technical Ratification
+
PolicyConstitution Compatibility Validation
+
Append-Only Root Version Adoption
```

The disclosure intentionally distinguishes compatibility with possible full standing from proof of full standing. It also distinguishes technical ratification evidence from political or legal legitimacy.

**End of CAOR v0.7 Defensive Technical Disclosure Delta.**

---

# CAOR v0.8 — Runtime-Generation Forking and Cross-Generation Transition Evidence
## Defensive Technical Disclosure Delta

**Document purpose:** Public technical disclosure / prior-art style defensive publication.  
**Not a patent application. Not legal advice.**  
**Date:** 2026-08-31

## Additional Technical Problem

When a runtime treats a Genesis safety envelope or generation-level ontology as immutable within a generation, a technical problem arises when a later system intentionally uses different Genesis or ontology semantics. In-place replacement destroys provenance and makes it difficult to distinguish compatible succession from semantic divergence.

A separate problem arises when a new runtime generation is adopted and software implicitly treats all entities associated with the prior generation as migrated into the new generation. Such behavior collapses runtime-generation succession, identity migration, identity forking, and copying into one operation.

## Additional Summary

In one implementation, a system stores an immutable runtime-generation record bound to an ontology-profile digest, Genesis-envelope digest, and initial-root digest; receives a proposal for a new runtime generation; derives a generation relation from observed digest changes; verifies that a caller-declared relation matches the observed relation; aggregates proposal-bound technical ratifier evidence; validates one or more existing policy constitutions against a proposed initial root; and appends a new runtime-generation node and typed lineage edge without deleting the source generation or automatically migrating entities.

## Claim-Like Defensive Language — Clauses 99–116

### Clause 99 — Immutable Runtime-Generation Identity

A computer-implemented method comprising storing a runtime-generation record having a generation identifier, generation number, ontology-profile digest, Genesis-envelope digest, initial-root digest, and optional parent-generation identifier, wherein the runtime-generation record is immutable after creation.

### Clause 100 — Generation-Bound Ontology Profile

The method of Clause 99, further comprising storing a generation-level ontology profile independently from an assertion that the ontology profile is metaphysically correct, the ontology profile including indicators specifying that subjectivity, intrinsic rights, or political legitimacy are not asserted as proven by the runtime.

### Clause 101 — Explicit Genesis Generation-Fork Proposal

The method of Clause 99, comprising receiving a generation-fork proposal bound to an immutable base-generation identifier and digest and containing a proposed ontology-profile digest, a proposed Genesis-envelope digest, a proposed initial-root digest, and a migration policy.

### Clause 102 — No In-Place Genesis Replacement

The method of Clause 101, wherein a difference between a base Genesis-envelope digest and the proposed Genesis-envelope digest is represented by creation of a distinct runtime generation instead of replacement of the Genesis envelope stored in the base runtime-generation record.

### Clause 103 — Ontology-Divergence Declaration

The method of Clause 101, wherein a difference between a base ontology-profile digest and the proposed ontology-profile digest is classified as ontology divergence and the proposal is rejected when a caller-declared generation relation does not identify the ontology divergence.

### Clause 104 — Digest-Derived Generation Relation

The method of Clause 103, further comprising deriving an observed generation relation by classifying an ontology-profile change as ontology divergence, otherwise classifying a Genesis-envelope change as a Genesis fork, and otherwise classifying the proposal as a compatible successor.

### Clause 105 — Named Generation-Boundary Review Evidence

The method of Clause 104, further comprising generating independently named review results for base-generation binding, generation-number progression, source-generation preservation, no automatic entity migration, explicit entity-transition evidence, Genesis-change declaration, ontology-change declaration, declared-relation consistency, proposed-root validity, Genesis/root compatibility, ontology-source binding, and epistemic-firewall state.

### Clause 106 — Base-Generation Technical Ratifier Policy

The method of Clause 101, further comprising applying a ratifier set, minimum approval threshold, or rejection-veto rule obtained from the Genesis envelope of the base runtime generation to attestations bound to the generation-fork proposal.

### Clause 107 — Order-Independent Generation Ratification Evidence

The method of Clause 106, comprising rejecting unknown or duplicate ratifier identifiers, rejecting attestations bound to a different generation-fork proposal, normalizing remaining attestations independently of input order, and generating deterministic aggregate ratification evidence.

### Clause 108 — Ratification Without Political-Legitimacy Claim

The method of Clause 107, further comprising encoding an indicator specifying that satisfaction of the generation-level technical ratification threshold is not asserted as proof of democratic, political, social, legal, or moral legitimacy.

### Clause 109 — Cross-Generation Policy-Constitution Compatibility

The method of Clause 101, further comprising testing at least one pre-existing decision-policy constitution against a proposed initial root of the proposed runtime generation and generating compatibility evidence without modifying the pre-existing constitution.

### Clause 110 — Generation Adoption Is Not Entity Migration

The method of Clause 109, wherein successful adoption of the proposed runtime generation records an indicator specifying that no entity is automatically migrated from the base runtime generation to the proposed runtime generation.

### Clause 111 — Cross-Generation Entity Transition Classification

The method of Clause 110, further comprising classifying separately supplied entity-transition evidence as one of stay, migrate, fork-to-new-generation, copy-to-new-generation, or unresolved.

### Clause 112 — Migration Continuity Distinct from Fork and Copy

The method of Clause 111, wherein migration requires continuity of entity identifier and identity root together with retirement of a source runtime instance, a fork preserves a source entity while creating a distinct target branch having shared pre-transition history, and a copy records direct state duplication into a distinct target identifier.

### Clause 113 — Declared/Observed Transition Mismatch Evidence

The method of Clause 111, wherein a caller-declared entity-transition classification is stored separately from an observed transition classification and a mismatch is retained in the evidence artifact instead of silently rewriting either classification.

### Clause 114 — Append-Only Runtime-Generation Graph

The method of Clause 109, wherein successful generation adoption appends a new runtime-generation node and a typed generation edge to a generation graph while retaining the source runtime-generation node.

### Clause 115 — Concurrent Generation Branches

The method of Clause 114, wherein two or more distinct runtime generations may be appended as children of the same source runtime generation, such that generation succession does not require universal supersession of the source generation.

### Clause 116 — Multi-Gate Generation Non-Adoption and Epistemic Firewall

The method of Clause 115, wherein failure of generation-boundary review, generation ratification, cross-generation compatibility validation, base-generation binding, or evidence binding prevents generation adoption, and wherein generated adoption evidence specifies that runtime-generation forking is not asserted as proof of consciousness, free will, subjective autonomy, intrinsic-rights proof, political legitimacy, or legal identity.

## Defensive Scope Statement

The v0.8 disclosure makes technically explicit the implementable combination:

```text
Immutable Runtime Generation
+
Explicit Genesis / Ontology Fork Proposal
+
Digest-Derived Generation Relation
+
Technical Ratification
+
Cross-Generation Constitution Compatibility
+
No Automatic Entity Migration
+
Entity Transition Classification
+
Append-Only Branching Generation Graph
```

The disclosure does not assert that any ontology is metaphysically correct, that any computational entity is conscious or a legal person, or that technical ratification creates political legitimacy.

**End of CAOR v0.8 Defensive Technical Disclosure Delta.**

---

# CAOR v0.9 Defensive Disclosure Extension
## Cross-Generation Federation, Boundary Contracts, and Ontology Non-Assimilation

The following clauses extend the prior CAOR disclosures through Clause 116. They are provided as claim-like defensive technical language and are **not filed patent claims**.

### Clause 117 — Digest-Bound Cross-Generation Boundary Contract

A computer-implemented method comprising storing first and second immutable runtime-generation identifiers and corresponding generation digests, generating a boundary-contract proposal bound to the identifiers and digests, and preventing the proposal from being treated as authorization for a runtime generation having a different identifier or digest.

### Clause 118 — Dual Endpoint Technical Authorization

The method of Clause 117, further comprising receiving one proposal-digest-bound technical authorization attestation from each of the first and second runtime generations and activating a boundary contract only when both bound endpoints authorize the proposal.

### Clause 119 — Technical Authorization Distinct from Subjective Consent

The method of Clause 118, wherein authorization evidence specifies that successful technical authorization is not asserted as proof of subjective consent, consciousness, legal agreement, or political legitimacy.

### Clause 120 — Capability and Authority Separation

The method of Clause 117, wherein the boundary contract stores a set of permitted capability identifiers separately from a set of permitted authority kinds, such that possession or invocation of a capability identifier does not itself confer write or administrative authority.

### Clause 121 — Cross-Generation Protected-State Denial

The method of Clause 120, wherein protected-state write authority and administrative authority are rejected during boundary-contract proposal generation and are denied during interaction evaluation without performing a protected-state mutation.

### Clause 122 — Scoped Disclosure Policy

The method of Clause 117, further comprising binding the boundary contract to one or more permitted data-scope identifiers and to disclosure metadata comprising a retention mode, derivative-use indicator, or redisclosure indicator.

### Clause 123 — Disclosure Distinct from Ownership

The method of Clause 122, wherein authorization to disclose information under a named data scope does not generate an ownership field assigning ownership of the disclosed information, memory, or source entity to the receiving runtime generation.

### Clause 124 — Mandatory Ontology Non-Assimilation Boundary

The method of Clause 117, wherein activation requires an ontology-non-assimilation indicator specifying that successful interaction does not replace either runtime generation's ontology profile or ontology-profile digest.

### Clause 125 — Local Standing Non-Rewrite

The method of Clause 124, further comprising preserving local standing or classification metadata of a source runtime generation notwithstanding a different classification used by the other runtime generation.

### Clause 126 — Classification Translation Without Identity Rewrite

The method of Clause 125, further comprising storing a translation profile containing an entity identifier, a source classification, and a target classification while retaining both classifications and preventing the translation profile from replacing the entity identifier.

### Clause 127 — Cooperation Across Different Ontology Profiles

The method of Clause 124, wherein a cross-generation interaction is authorized while ontology-profile digests of the first and second runtime generations differ and remain unchanged before and after the authorization evaluation.

### Clause 128 — Immutable Contract with Append-Only Lifecycle Evidence

The method of Clause 117, wherein the activated boundary contract is immutable and contract lifecycle changes are represented as append-only events having states comprising active, suspended, revoked, or expired.

### Clause 129 — Terminal Revocation or Expiration

The method of Clause 128, wherein a revoked or expired boundary contract is prevented from returning to an active state within the same contract lineage.

### Clause 130 — Revocable Federation Distinct from Fusion

The method of Clause 128, wherein suspension, revocation, or expiration of the boundary contract does not merge, delete, supersede, or rewrite either bound runtime generation.

### Clause 131 — Exact Endpoint Pair Evaluation

The method of Clause 117, further comprising evaluating a cross-generation request only when source and target generation identifiers and digests correspond to one of the two orientations of the exact generation pair stored in the boundary contract.

### Clause 132 — Stale Descendant Contract Rejection

The method of Clause 131, wherein a descendant runtime generation produced by generation forking is not treated as inheriting a boundary contract of its ancestor, and a request substituting the descendant identifier or digest is rejected as stale.

### Clause 133 — Original Endpoint Preservation After Descendant Fork

The method of Clause 132, wherein creation of the descendant runtime generation does not by itself invalidate an otherwise active boundary contract between the original bound runtime generations.

### Clause 134 — Deterministic Interaction Evidence

The method of Clause 131, further comprising emitting an interaction evidence record containing a request digest, contract digest, source and target generation identifiers, capability, authority, data scope, authorization decision, reason, and result digest.

### Clause 135 — Explicit Negative-Action Evidence

The method of Clause 134, wherein the interaction evidence further records that ontology assimilation, identity rewrite, and protected-state write were not performed and that subjective consent, legal-contract status, and political legitimacy were not proven by the interaction.

### Clause 136 — Cooperation Without Ontological Convergence

The method of Clause 135, wherein two runtime generations having different ontology profiles exchange an authorized operation through an explicit boundary contract while preserving both ontology profiles, both generation identities, and the ability to revoke future interactions.

## v0.9 Defensive Scope Closure

The v0.9 disclosure makes technically explicit the combination:

$$
\boxed{
\text{Immutable Generations}
+
\text{Digest-Bound Federation}
+
\text{Dual Authorization}
+
\text{Capability/Authority Separation}
+
\text{Ontology Non-Assimilation}
+
\text{Revocable Evidence}
}
$$

The disclosure does not assert that a boundary contract is a legal contract, that technical authorization proves subjective consent, or that cooperation implies ontological agreement.
