# CAOR MVP v0.2 — Development & Divergence Runtime
## Engineering Whitepaper

**Version:** v0.2  
**Date:** 2026-08-30  
**Baseline:** CAOR v0.1 — Independent Initialization & Typed Lineage  
**Purpose:** Engineering reference implementation and defensive technical publication.

---

## 1. Why v0.2 exists

CAOR v0.1 made one narrow idea executable: a generated computational entity can be initialized from structured multi-source contributions while receiving a UID, identity root, memory root, state namespace, lineage ID, and source-write boundary that are distinct from any source entity. It also made `COPY`, `FORK`, and `OFFSPRING` explicit event types rather than rhetorical labels.

That is necessary but incomplete. A critic can reasonably say:

> The generated entity has different identifiers, but what happens after initialization? Is there any inspectable history showing that it developed through its own sequence of events rather than merely carrying a renamed snapshot?

CAOR v0.2 addresses that engineering question without adding any claim about consciousness.

The new proposition is:

$$
\boxed{
\text{Independent Initialization}
+
\text{Independent Event History}
\rightarrow
\text{Replayable Cross-Time Development Evidence}.
}
$$

The deliberately excluded proposition is:

$$
\boxed{
\text{Developmental Divergence}
\not\Rightarrow
\text{Subjectivity}.
}
$$

---

## 2. Event sourcing instead of mutable-state storytelling

A naive implementation can mutate a dictionary and later claim that the object "developed." That is weak evidence because the final state does not reveal who changed it, when it changed, or whether the history was reconstructed after the fact.

v0.2 therefore uses an append-only `DevelopmentLedger`.

Every allowed developmental mutation creates one typed event:

```text
SELF_UPDATE
ACCEPT_PROPOSAL
ENVIRONMENT_EVENT
```

An event contains:

```text
event_id
event_index
actor_id
event_kind
region
key
value
previous_value
source_event_id
timestamp
evidence
```

The event ID is deterministically derived from canonical event content. The ledger requires contiguous event indices, rejects event-ID collisions, exports canonical UTF-8 JSON, and exposes a deterministic SHA-256 digest.

The result is an evidence chain rather than a narrative assertion.

---

## 3. Three different causes of development

### 3.1 Self update

A runtime-local update is recorded as:

```text
SELF_UPDATE
actor_id = offspring_uid
```

The label "self" means only that the runtime operation was invoked through the generated entity's own mutation surface. It does not imply phenomenal agency or free will.

### 3.2 Accepted parent proposal

v0.1 already allowed a source contributor to submit a proposal without mutating the child state. v0.2 adds an explicit acceptance operation.

```text
parent -> PROPOSAL(PENDING)
child runtime -> ACCEPT_PROPOSAL
```

The original proposal record remains immutable and `PENDING`; acceptance is represented separately in proposal-status state plus a development event whose `source_event_id` links back to the proposal ID.

This makes a critical distinction executable:

$$
\boxed{
\text{Parent Suggestion}
\neq
\text{Parent Direct Write}.
}
$$

### 3.3 Environment event

An external developmental input can be recorded without pretending that it was a parent action or a self-originated preference.

```text
ENVIRONMENT_EVENT
actor_id = environment_id
```

Examples include a synthetic curriculum event, laboratory stimulus, game-world event, or deterministic simulation input.

This provenance matters because otherwise all state changes are flattened into an ambiguous "the child changed" statement.

---

## 4. Replay is the primary integrity check

The function:

```python
replay_mutable_state(ois, events)
```

reconstructs mutable state from the OIS mutable-region definition and the ordered development events.

Replay rejects:

- event-index gaps;
- duplicate event IDs;
- writes outside declared mutable regions.

For a valid history:

$$
\boxed{
Canonical(Replay(events))
=
Canonical(LiveMutableState).
}
$$

The protected OIS core is never reconstructed from development events. This maintains the v0.1 separation between identity initialization evidence and post-initialization mutable development.

---

## 5. Why an origin projection is necessary

A subtle problem appears if divergence is measured directly from v0.1 `mutable_state`: that dictionary is intentionally empty at initialization. Treating an empty overlay as the entity's complete birth state would make the child appear maximally distant from source contributions before any development occurred.

v0.2 therefore distinguishes:

```text
live mutable overlay
```

from:

```text
origin state projection
```

The origin projection deterministically maps contribution categories into comparison coordinates:

```text
IDENTITY_TRAIT          -> preferences
VALUE_TRAIT             -> preferences
CAPABILITY_TRAIT        -> skills
COGNITIVE_TRAIT         -> notes
MEMORY_SEED             -> notes
CULTURAL_SEMANTIC_TRAIT -> notes
CONSTRAINT              -> notes
```

For the same `region.key`:

- numeric non-boolean contributions use a normalized weighted mean when possible;
- non-numeric values select the highest-weight contribution with deterministic source/contribution-ID tie-breaking.

The projection is not stored as a psychological truth and does not modify the runtime object. It is an analysis coordinate derived from the manifest.

---

## 6. Projected developmental state

Divergence uses:

$$
\boxed{
State_C^{projected}(t)
=
OriginProjection(Manifest)
\oplus
DevelopmentOverlay(t).
}
$$

The operator $\oplus$ means the replayed development overlay replaces origin values at the same mutable keys and adds new keys where necessary.

This lets the runtime answer a concrete question:

> Given the source contribution profile that influenced initialization, which later state values were introduced or changed by the recorded event history?

---

## 7. Source baselines

Each source contributor receives a deterministic baseline profile using the same category-to-region mapping.

For source $P_i$:

$$
Baseline(P_i)
=
Project(Contributions_{P_i}).
$$

This remains an engineering representation of supplied contribution data. It is not a reconstruction of a human mind or an AI's full internal state.

---

## 8. Divergence metric

For non-numeric canonical values:

$$
d(a,b)=
\begin{cases}
0,&a=b\\
1,&a\neq b.
\end{cases}
$$

For numeric non-boolean values:

$$
d(a,b)=\frac{|a-b|}{1+|a|+|b|}.
$$

Missing keys contribute distance `1.0`.

For the union of comparable keys:

$$
D(C,P_i)
=
\frac{1}{|K|}
\sum_{k\in K} d(C_k,P_{i,k}).
$$

The nearest source is selected by minimum distance with lexicographic source-ID tie-breaking.

The metric is intentionally simple. It is a reproducible reference metric, not a psychological similarity scale.

---

## 9. Novel state fraction

A projected entity key is novel when no source baseline contains the same canonical value at the same mapped key.

$$
N_C
=
\frac{|K_{novel}|}{|K_{entity}|}.
$$

A weighted numeric origin value can itself be novel relative to all individual source values. This is expected: combination can create an initial projected value not equal to any one contributor.

---

## 10. Divergence is not required to increase

The runtime explicitly does not impose:

$$
D_{t+1}\geq D_t.
$$

An environment event, accepted proposal, or later self update may move the entity closer to a source baseline.

Therefore:

$$
\boxed{
\text{Divergence}
\neq
\text{Monotonic Separation}.
}
$$

This is important for conceptual clarity. Independence does not mean permanent opposition to source traits.

---

## 11. Development evidence bundle

The public function:

```python
build_development_evidence(entity, manifest)
```

produces:

```text
offspring_uid
manifest_digest
ois_digest
ledger_digest
event_count
final_state_digest
divergence_timeline
subjectivity_claimed = false
```

For identical OIS + identical event history, evidence bytes are identical. A different event history changes the ledger and/or final-state digest.

This is the core v0.2 reproducibility contract.

---

## 12. What v0.2 proves and does not prove

v0.2 can establish, within its own engineering model, that:

1. an entity was independently initialized according to v0.1 invariants;
2. subsequent mutations were recorded as typed events;
3. the event sequence can deterministically reconstruct mutable state;
4. an origin projection can be derived from source contributions;
5. cross-time projected state can be compared reproducibly with source baselines;
6. two entities with the same origin but different event histories can produce different evidence artifacts.

v0.2 cannot establish that the generated computational entity:

- is conscious;
- has subjective feelings;
- possesses metaphysical personal identity;
- is legally a person or child;
- exercises philosophical free will;
- is biologically reproduced.

---

## 13. Defensive publication significance

v0.1 disclosed independent initialization and typed lineage classification. v0.2 adds a concrete implementation of:

$$
\boxed{
\text{Multi-Source Derivation}
+
\text{Independent Identity Initialization}
+
\text{Append-Only Development History}
+
\text{Replay}
+
\text{Cross-Time Divergence Evidence}.
}
$$

This makes the broader concept materially easier to inspect, reproduce, and discuss in engineering language without requiring a neural-model implementation.

---

## 14. Closure

CAOR v0.1 answered:

> Was the entity initialized as something other than a simple source copy or fork under the disclosed engineering rules?

CAOR v0.2 additionally answers:

> What happened after initialization, can that history be replayed, and what deterministic evidence describes its changing relationship to the source contribution baselines?

That is the complete v0.2 claim surface.
