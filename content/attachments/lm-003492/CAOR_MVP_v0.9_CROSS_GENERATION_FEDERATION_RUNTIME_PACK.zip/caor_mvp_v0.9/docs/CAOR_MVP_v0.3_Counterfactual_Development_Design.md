# CAOR MVP v0.3 — Counterfactual Development Branching Runtime
## Canonical Design Specification

**Version:** v0.3  
**Date:** 2026-08-30  
**Baseline:** CAOR v0.2 — Development & Divergence Runtime

## 1. Purpose

v0.2 proves that one independently initialized computational entity can accumulate an append-only, replayable development history and can be compared against source-contribution baselines over time.

v0.3 addresses a different engineering question:

> Given the same OIS and the same contribution manifest, can the runtime represent multiple explicitly specified feasible development histories, replay each history independently, and compare the resulting trajectories without treating any one future as uniquely predetermined by the source contributions?

The v0.3 engineering proposition is:

$$
\boxed{
\text{Same Origin}
+
\text{Different Feasible Event Sequences}
\rightarrow
\text{Distinct Replayable Development Trajectories}.
}
$$

The deliberately excluded propositions are:

$$
\boxed{
\text{Alternative Trajectories}
\not\Rightarrow
\text{Free Will}
}
$$

$$
\boxed{
\text{Counterfactual Divergence}
\not\Rightarrow
\text{Subjectivity or Autonomy}.
}
$$

## 2. Scope

v0.3 adds exactly one subsystem: counterfactual development branching over the v0.2 runtime.

It does not change:

- OIS synthesis;
- `COPY / FORK / OFFSPRING` classification;
- protected-core policy;
- DevelopmentLedger semantics;
- divergence metric;
- lineage graph semantics.

## 3. Counterfactual Action Model

Canonical scenario action kinds:

```text
SELF_UPDATE
ENVIRONMENT_EVENT
SOURCE_PROPOSAL
```

A `CounterfactualAction` contains:

```text
action_kind
region
key
value
external_id
timestamp
evidence
```

`SOURCE_PROPOSAL` does not directly write child state. It invokes the v0.2 proposal path and then the branch entity explicitly accepts that proposal.

## 4. Branch Specification

A `CounterfactualBranchSpec` contains:

```text
branch_label
actions[]
feasibility_note
```

The label is descriptive only. The caller supplies the scenario; the runtime does not infer that the generated entity selected it autonomously.

## 5. Isolated Branch Execution

For each branch specification, CAOR instantiates a fresh `OffspringEntity` from the same OIS and applies only the actions in that branch specification.

Therefore:

$$
\boxed{
State(B_i)
\cap
Mutation(B_j)
=
\varnothing
\quad i\neq j.
}
$$

One branch cannot contaminate another branch's live state.

## 6. Deterministic Branch Identity

A branch-spec digest is derived from:

```text
offspring_uid
manifest_digest
canonical branch specification
```

The branch ID is derived from the origin UID and branch-spec digest.

Same origin + same manifest + same branch spec yields byte-identical trajectory evidence.

## 7. Counterfactual Trajectory

Each executed branch produces a `CounterfactualTrajectory` containing:

```text
offspring_uid
branch_id
branch_label
spec_digest
event_count
ledger_digest
final_state_digest
final_projected_state
events[]
divergence_timeline[]
canonical_bytes
```

The final projected state uses the v0.2 rule:

$$
\boxed{
State_C^{projected}
=
OriginProjection(Manifest)
\oplus
Replay(BranchEvents).
}
$$

## 8. Pairwise Branch Comparison

For two trajectories sharing the same OIS origin, CAOR compares the union of projected state keys.

A branch comparison records:

```text
left_branch_id
right_branch_id
left_final_state_digest
right_final_state_digest
state_distance
changed_keys
```

Canonical-equal values receive distance zero. Numeric and nonnumeric comparison reuse v0.2 value-distance semantics.

## 9. Aggregate Counterfactual Evidence

`build_counterfactual_evidence` accepts one OIS, one manifest, and multiple uniquely labelled branch specifications.

It emits:

```text
offspring_uid
manifest_digest
ois_digest
branch_count
unique_trajectory_count
unique_final_state_count
alternative_trajectories_observed
trajectories[]
pairwise_comparisons[]
subjectivity_claimed = false
free_will_claimed = false
autonomy_claimed = false
```

`alternative_trajectories_observed=true` means only that more than one development-ledger digest occurred among the supplied feasible scenarios.

It does not mean that an entity autonomously chose among them.

## 10. Counterfactual Non-Uniqueness

v0.3 makes this engineering statement executable:

$$
\boxed{
Manifest + OIS
\not\Rightarrow
\text{One Unique Development History}.
}
$$

The statement is about representable and executable trajectories under different supplied event sequences, not metaphysical indeterminism.

## 11. Acceptance Criteria

v0.3 is accepted only if:

1. same OIS + same spec produces byte-identical trajectory evidence;
2. separate branches do not contaminate each other's state;
3. `SOURCE_PROPOSAL` uses proposal + acceptance rather than direct parent mutation;
4. environment events require an explicit external source identifier;
5. branch final state is derived from origin projection plus branch event replay;
6. identical trajectories compare at distance zero;
7. distinct final states can produce positive branch distance and changed-key evidence;
8. aggregate evidence rejects duplicate branch labels;
9. aggregate evidence records unique trajectory and final-state counts;
10. aggregate evidence explicitly sets subjectivity, free-will, and autonomy claims to false;
11. all v0.1/v0.2 tests remain green;
12. the installed wheel can build counterfactual evidence in an offline clean venv.

## 12. Non-Goals

Not included:

- autonomous scenario generation;
- reinforcement learning;
- stochastic policy search;
- free-will detection;
- consciousness detection;
- preference authenticity scoring;
- moral or legal offspring status;
- networked simulation;
- GUI.

## 13. Canonical v0.3 Closure

$$
\boxed{
\text{Independent Initialization}
+
\text{Replayable Development}
+
\text{Counterfactual Branch Set}
\rightarrow
\text{Comparable Alternative Trajectory Evidence}.
}
$$

And:

$$
\boxed{
\text{Alternative Trajectory Evidence}
\neq
\text{Autonomous Choice Proof}.
}
$$
