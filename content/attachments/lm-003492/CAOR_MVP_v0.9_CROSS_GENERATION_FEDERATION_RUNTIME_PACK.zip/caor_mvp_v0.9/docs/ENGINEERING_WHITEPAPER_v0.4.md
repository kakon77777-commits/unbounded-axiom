# CAOR MVP v0.4 — Policy-Mediated Development Selection Runtime
## Engineering Whitepaper

**Version:** 0.4.0  
**Date:** 2026-08-30

## 1. From counterfactual paths to policy-mediated selection

CAOR v0.1 made independent computational initialization and typed lineage executable. v0.2 added append-only development history and cross-time divergence. v0.3 added isolated counterfactual trajectories from a common OIS.

v0.4 adds a narrower and more concrete capability: given the current replay-derived state, development history, an external environment mapping, and a finite candidate-action set, the runtime can deterministically evaluate a policy and produce an inspectable selection artifact.

The pipeline is:

```text
OIS + ContributionManifest
        ↓
DevelopmentEvent[]
        ↓ replay
Projected Current State
        +
Environment
        +
History Counts
        ↓
DecisionContext
        ↓
DecisionPolicy
  ├── hard conditions
  ├── score terms
  └── candidate actions
        ↓
CandidateEvaluation[]
        ↓
Deterministic Selection
        ↓
PolicySelectionEvidence
        ↓ stale-context guard
SELF_UPDATE / ACCEPT_PROPOSAL / NO_OP
```

## 2. The central boundary

v0.4 deliberately avoids naming this mechanism "autonomous choice".

The canonical statement is:

$$
\boxed{
\text{Decision Policy}
\neq
\text{Autonomy}
\neq
\text{Free Will}
\neq
\text{Subjectivity}.
}
$$

The runtime demonstrates that an entity-associated state/history can participate in deterministic action selection. It does not demonstrate phenomenological authorship or metaphysical freedom.

## 3. Replay-derived decision context

The policy does not trust a live mutable dictionary as the sole source of current state.

`build_decision_context` reconstructs mutable state from the append-only `DevelopmentEvent[]`, then overlays that state on the deterministic `origin_state_projection(manifest)`.

The context therefore binds:

```text
offspring_uid
manifest_digest
development_digest
projected_state
history_event_counts
history_total
environment
```

and emits a `context_digest`.

This makes the policy input reproducible from prior evidence.

## 4. Signal model

The v0.4 selector reads only four canonical signal classes:

```text
STATE
ENVIRONMENT
HISTORY_COUNT
HISTORY_TOTAL
```

This is intentionally limited. The policy does not inspect hidden model activations, neural logits, or undeclared private state.

Conditions use explicit operators:

```text
EQ NE GT GTE LT LTE EXISTS NOT_EXISTS
```

## 5. Eligibility before scoring

Each candidate has:

- zero or more hard conditions; and
- zero or more score terms.

A candidate with a failed hard condition is ineligible regardless of its nominal score.

For an eligible candidate:

$$
Score(c)=\sum_k s_k(c).
$$

The highest score is selected. Equal scores are resolved by lexical ascending `candidate_id`.

Thus the selector is deterministic for a fixed policy and context.

## 6. Candidate evaluation evidence

The evidence payload records every candidate, not only the winner.

Each `CandidateEvaluation` includes:

```text
candidate_id
eligible
score
hard_results
score_results
```

Each condition result includes the observed value and match result.

This supports the question:

> Why was candidate A selected instead of B or C?

without requiring narrative post-hoc explanation.

## 7. Entity actions are not environment events

Canonical selectable actions are exactly:

```text
SELF_UPDATE
ACCEPT_PROPOSAL
NO_OP
```

`ENVIRONMENT_EVENT` remains an external event type. Treating an external event as an entity action would erase causal provenance.

## 8. Proposal acceptance still preserves the source-write boundary

A parent/source may create a `ProposalRecord`, but the policy can only select an `ACCEPT_PROPOSAL` action that invokes the existing entity acceptance operation.

The causal chain remains:

```text
source -> proposal(PENDING)
entity policy -> selects ACCEPT_PROPOSAL
entity -> accept_proposal
ledger -> ACCEPT_PROPOSAL
```

There is still no source-to-child direct mutation path.

## 9. NO_OP is a real selected outcome

A deterministic policy system that cannot select no action is biased toward forced mutation.

v0.4 therefore makes `NO_OP` a first-class candidate.

A `NO_OP` selection yields canonical `PolicySelectionEvidence` but does not append a development event.

Thus:

$$
\boxed{
\text{Decision Evidence}
\not\Rightarrow
\text{State Mutation}.
}
$$

## 10. Stale-context safety

Selection and execution are intentionally separated.

A selection is bound to the `development_digest` used when the context was built. Before applying the selected action, CAOR compares the entity's current ledger digest with the bound digest.

If they differ, execution raises `StaleDecisionContext`.

This prevents:

```text
select on S_t
entity changes to S_t+k
silently apply old selection to S_t+k
```

and gives:

$$
\boxed{
\text{Selection Evidence from }S_t
\text{ cannot silently mutate }S_{t+k}.
}
$$

## 11. Replay-consistent re-selection

Given the same:

- OIS;
- manifest;
- development-event sequence;
- environment;
- policy;

CAOR reconstructs byte-identical `DecisionContext` and `PolicySelectionEvidence`.

This is the v0.4 reproducibility property.

## 12. Defensive publication significance

The cumulative disclosed chain is now:

$$
\boxed{
\text{Independent Initialization}
+
\text{Development Ledger}
+
\text{Counterfactual Trajectories}
+
\text{Policy-Mediated Selection Evidence}.
}
$$

This makes a substantially more concrete engineering statement than saying that an artificial offspring "develops its own preferences".

The actual demonstrated statement is narrower:

> A generated computational entity can have policy inputs reconstructed from its source-derived origin projection and append-only development history, evaluate multiple explicit candidate actions against hard and weighted conditions, deterministically select one action, and apply that selection through existing protected mutation boundaries.

## 13. What v0.4 still does not prove

v0.4 does not prove:

- intrinsic preference authorship;
- autonomous goal creation;
- phenomenal decision experience;
- metaphysical ability to have done otherwise;
- consciousness;
- legal personhood;
- moral or biological child status.

## 14. Closure

v0.1 answers **what kind of initialization event occurred**.  
v0.2 answers **what happened over time**.  
v0.3 answers **what multiple supplied trajectories produce**.  
v0.4 answers **how an explicit deterministic policy can select among candidate development actions using replayable state/history/environment evidence**.

Thus:

$$
\boxed{
\text{Origin}
\rightarrow
\text{History}
\rightarrow
\text{Counterfactual Space}
\rightarrow
\text{Policy Selection Evidence}.
}
$$
