# CAOR MVP v0.5 — Constitutional Policy Evolution Runtime
## Engineering Whitepaper

**Version:** 0.5.0  
**Date:** 2026-08-30

## 1. From policy-mediated action to policy-mediated policy change

CAOR v0.4 demonstrates that a deterministic policy can reconstruct an entity-associated decision context from its OIS, source-derived origin projection, append-only development history, and environment, then evaluate explicit candidate actions and emit reproducible selection evidence.

v0.5 asks a separate engineering question:

> How may the decision policy itself change without permitting the active policy to be directly rewritten in place?

The v0.5 answer is proposal-based, constitution-bounded, validation-gated, and append-only.

```text
Active PolicyVersion
        +
Replay-Derived DecisionContext
        +
PolicyEvolutionTemplate
        ↓
PolicyChangeProposal
        ↓
Constitutional Review
        ↓
Deterministic Validation Cases
        ↓
ADOPT / REJECT
        ↓
New Immutable PolicyVersion
```

## 2. The central boundary

The runtime deliberately avoids describing the mechanism as autonomous self-governance.

$$
\boxed{
\text{Policy Evolution Mechanism}
\neq
\text{Autonomy}
\neq
\text{Free Will}
\neq
\text{Subjectivity}.
}
$$

The demonstrated claim is narrower: a computational entity can have a policy-change proposal generated from replay-derived state/history conditions, and the proposal can be accepted only through explicit structural and behavioral gates.

## 3. Immutable policy versions

Each active decision policy is wrapped in a frozen `PolicyVersion` containing:

```text
version_id
version_number
policy
policy_digest
parent_version_id
parent_policy_digest
adopted_from_proposal_id
created_at
```

A policy is never mutated in place.

Adoption produces:

```text
v1 --proposal:p1--> v2 --proposal:p2--> v3
```

The prior versions remain retrievable byte-for-byte.

## 4. History-conditioned proposal generation

`PolicyEvolutionTemplate` contains:

```text
template_id
trigger_conditions[]
proposed_policy
rationale
```

Trigger conditions reuse the v0.4 decision signal model:

```text
STATE
ENVIRONMENT
HISTORY_COUNT
HISTORY_TOTAL
```

If any trigger fails, no proposal is emitted.

If all triggers pass, `generate_policy_change_proposal` emits a deterministic `PolicyChangeProposal` bound to:

```text
offspring_uid
base_version_id
base_policy_digest
context_digest
development_digest
proposed_policy_digest
```

Thus the proposal cannot be detached from the exact policy and development context that caused it to be generated.

## 5. Proposal is not adoption

A proposal is evidence that a replacement policy became eligible for review. It is not authority to replace the active policy.

$$
\boxed{
\text{Policy Proposal}
\neq
\text{Active Policy Mutation}.
}
$$

This preserves the same proposal-versus-direct-write distinction used for source contributions in earlier CAOR versions.

## 6. Constitutional rules

The canonical v0.5 constitution produces an explicit result for each rule.

The reference rules require:

1. structural validity under the existing v0.4 `DecisionPolicy` validator;
2. the canonical `LEXICAL_CANDIDATE_ID` tie-break;
3. a bounded candidate count;
4. at least one `NO_OP` candidate when configured;
5. only allowed decision action kinds; and
6. bounded score-term values.

The reference constitution therefore makes it technically possible to say:

> A policy may evolve, but it may not silently delete the ability to choose no mutation.

The constitutional requirement for `NO_OP` is a technical reference constraint, not a claim about moral agency.

## 7. Named review evidence

`ConstitutionalReviewEvidence` stores every rule result, including failed rules.

```text
STRUCTURAL_VALIDITY
REQUIRED_TIE_BREAK_RULE
MAX_CANDIDATE_COUNT
REQUIRED_NO_OP
ALLOWED_ACTION_KINDS
SCORE_BOUNDS
```

A proposal passes only if all rule results pass.

The review produces a canonical `review_digest`.

## 8. Deterministic validation cases

Structural validity does not prove that a proposed policy behaves correctly in relevant contexts.

v0.5 therefore adds `PolicyValidationCase`:

```text
case_id
DecisionContext
expected_candidate_id?  # optional
```

Each case executes the proposed policy using the existing deterministic v0.4 selector.

Evidence records:

```text
selected_candidate_id
selection_digest
passed
error_type
error_message
validation_digest
```

A caller may require an expected candidate to make the test behavioral rather than merely structural.

## 9. Adoption gate

`PolicyRegistry.adopt` requires all of the following:

```text
proposal belongs to registry offspring UID
proposal base version == active version
proposal base policy digest == active policy digest
proposal policy digest is internally valid
constitutional review belongs to proposal
constitutional review passed
at least one validation case exists
all validation evidence belongs to proposal
all validation cases passed
```

If any gate fails, the active policy remains unchanged.

## 10. Stale-base protection

Suppose proposal $p$ was generated from policy version $v_1$.

If another valid proposal is adopted first:

$$
v_1\rightarrow v_2,
$$

then attempting to adopt $p$ against the registry raises `StalePolicyProposal`.

Thus:

$$
\boxed{
\text{Proposal from }v_1
\text{ cannot silently replace active }v_2.
}
$$

## 11. Reversion is a new version

v0.5 does not provide destructive rollback of policy history.

If the runtime wishes to return to policy content identical to an earlier version, it creates a new proposal and a new version.

For example:

```text
v1(policy A)
  ↓
v2(policy B)
  ↓
v3(policy A-content)
```

Then:

```text
v3.policy_digest == v1.policy_digest
v3.version_id != v1.version_id
v3.parent_version_id == v2.version_id
```

This preserves provenance of the fact that the system changed away from A and later returned to A-like behavior.

## 12. The relation to v0.1 source-write boundaries

Earlier CAOR releases established:

$$
\boxed{
\text{Source Contribution}
\neq
\text{Direct Protected-Core Mutation Authority}.
}
$$

v0.5 establishes an analogous policy rule:

$$
\boxed{
\text{Policy-Change Proposal}
\neq
\text{Direct Active-Policy Mutation Authority}.
}
$$

Both use proposal, evidence, and explicit acceptance boundaries.

## 13. Reproducibility

Given the same:

- active `PolicyVersion`;
- replay-derived `DecisionContext`;
- `PolicyEvolutionTemplate`;
- `PolicyConstitution`;
- validation cases; and
- timestamps used for version creation;

CAOR produces deterministic proposal, review, validation, adoption, and version artifacts.

## 14. Defensive-publication significance

The cumulative CAOR chain is now:

$$
\boxed{
\text{Independent Initialization}
+\text{Development Ledger}
+\text{Counterfactual Trajectories}
+\text{Policy Selection}
+\text{Constitutional Policy Evolution}.
}
$$

The disclosed engineering statement is not that an artificial offspring "writes its own mind".

The demonstrated statement is:

> A generated computational entity can have a decision-policy replacement proposal conditionally generated from its replay-derived state/history, have that proposal reviewed against explicit constitutional invariants and deterministic validation cases, and create a new immutable active policy version only through an evidence-bearing adoption gate.

## 15. What v0.5 still does not prove

v0.5 does not prove:

- intrinsic policy authorship;
- autonomous norm creation;
- self-legislation in a philosophical sense;
- phenomenal decision experience;
- free will;
- consciousness;
- legal personhood;
- moral or biological child status.

## 16. Closure

v0.1 asks **what initialization event occurred**.  
v0.2 asks **what changed over time**.  
v0.3 asks **what multiple feasible supplied trajectories produce**.  
v0.4 asks **how replay-derived state/history/environment can deterministically select an action**.  
v0.5 asks **how the action-selection policy itself can change without in-place mutation and without bypassing constitutional constraints**.

Thus:

$$
\boxed{
\text{Origin}
\rightarrow
\text{History}
\rightarrow
\text{Alternative Trajectories}
\rightarrow
\text{Policy Selection}
\rightarrow
\text{Constitutional Policy Evolution}.
}
$$
