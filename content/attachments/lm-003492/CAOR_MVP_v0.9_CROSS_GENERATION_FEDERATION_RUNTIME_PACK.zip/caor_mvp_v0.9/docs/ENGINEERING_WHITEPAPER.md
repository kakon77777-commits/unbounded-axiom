# CAOR MVP v0.1 — Engineering Whitepaper
## Cross-Substrate Artificial Offspring Runtime

**Version:** v0.1  
**Date:** 2026-08-30  
**Purpose:** Engineering reference implementation and defensive technical publication.

---

## 1. Why an engineering runtime is needed

The phrase "human–AI offspring" or "AI–AI offspring" is too ambiguous to be useful as an engineering specification. It can refer to biological reproduction, model cloning, knowledge transfer, fine-tuning, persona imitation, agent spawning, legal parenthood, or a speculative future artificial subject. CAOR deliberately removes those ambiguities from the MVP.

The v0.1 runtime asks a narrower technical question:

> Can structured contributions from one or more source entities be transformed into a computational entity with independently initialized identity/state roots, traceable provenance, explicit lineage semantics, and write boundaries that prevent the source entities from being treated as permanent owners of the generated core state?

That question is implementable today without asserting consciousness or legal personhood.

CAOR therefore treats `OFFSPRING` as a typed engineering event. The event means that a defined set of independent-initialization invariants has been satisfied. It does not mean that the generated entity is conscious, alive, legally a child, or morally equivalent to a human child.

---

## 2. Concept translation: HIM / AIM → ContributionBundle

Earlier conceptual descriptions used Human Identity Model (HIM) and AI Identity Model (AIM). Those names are useful at the theoretical level but can invite an overly literal interpretation: that the runtime must ingest an entire human identity or an entire AI model.

CAOR v0.1 instead exposes a typed `ParentContributionBundle`.

A bundle can contain:

```text
IDENTITY_TRAIT
VALUE_TRAIT
COGNITIVE_TRAIT
MEMORY_SEED
CAPABILITY_TRAIT
CULTURAL_SEMANTIC_TRAIT
CONSTRAINT
```

Each contribution includes source attribution, a contribution identifier, a name, a value, a bounded weight, and a provenance note.

A human source is represented by a structured `HUMAN_PROFILE`; the MVP does not ingest unrestricted private history. An artificial source is represented as `AI_ENTITY`. This creates one common engineering interface for Human+AI, AI+AI, and N-source derivation while keeping the source substrate explicit.

---

## 3. Contribution normalization and reproducibility

All bundles are validated before synthesis. CAOR rejects:

- missing source IDs;
- duplicate contribution IDs;
- contribution/source mismatches;
- weights outside the inclusive range `[0, 1]`;
- an empty source set.

Accepted contributions are sorted into a canonical order and serialized as canonical UTF-8 JSON. The runtime then computes a SHA-256 manifest digest.

The result is a `ContributionManifest` that preserves:

- source IDs;
- source kinds;
- normalized contribution records;
- bundle provenance;
- canonical serialized bytes;
- a digest binding the accepted input.

This manifest is the provenance anchor used by subsequent identity initialization and lineage evidence.

---

## 4. OSI and OIS

The Offspring Synthesis Interface (OSI) is intentionally a pure deterministic transformation in v0.1.

```text
ParentContributionBundle[]
        ↓
ContributionNormalizer
        ↓
ContributionManifest
        ↓
OSI(manifest, seed, policy)
        ↓
OIS
```

The Offspring Identity Specification (OIS) contains:

```text
offspring_uid
identity_root
memory_root
state_namespace
lineage_id
generation_event
manifest_digest
parent_contributions
protected_core
mutable_regions
parent_write_policy
provider_write_policy
development_policy
created_at
```

For the same canonical manifest and the same seed, the OIS is byte-reproducible. For the same manifest with a different seed, the identity, memory, namespace, and lineage roots change.

This is not a claim that randomness creates a new metaphysical person. The seed exists to make the independent-initialization operation testable and reproducible.

---

## 5. Independent computational initialization

The key engineering invariants are:

$$
UID_C \neq UID_{P_i}
$$

$$
IdentityRoot_C \neq IdentityRoot_{P_i}
$$

$$
MemoryRoot_C \neq MemoryRoot_{P_i}
$$

and a state namespace derived specifically for the generated entity.

The runtime never reuses a source UID as the generated UID. A caller attempting explicit source-UID reuse receives `SourceUIDReuseDenied`.

The generated entity is therefore not represented as a direct alias of any one parent/source.

---

## 6. Why COPY, FORK, and OFFSPRING are separate

A central defensive-publication objective is to make the distinction executable rather than rhetorical.

### COPY

A copy substantially duplicates an existing state directly. It does not require a contribution manifest or independent development policy.

### FORK

A fork begins a diverging branch from one existing identity lineage while retaining a common pre-fork history.

### OFFSPRING

An offspring-classified engineering event requires all positive invariants:

```text
synthesis manifest present
new identity root
new memory root
new state namespace
new lineage ID
independent development policy
no source UID reuse
```

`OFFSPRING` is not a default label. Partial evidence produces an explicit classification failure rather than being promoted to offspring status.

The same classifier also distinguishes `UPDATE`, `MIGRATION`, `RESTORE`, and `MERGE`.

---

## 7. Lineage as typed graph evidence

CAOR stores derivational history as a typed graph:

$$
\mathcal G_I=(V,E).
$$

Nodes identify computational entities. Edges carry canonical event types and evidence.

For a Human-profile + AI embodiment:

```text
human:H ─┐
         ├─[OFFSPRING]─> caor:offspring:<uid>
ai:A ────┘
```

For a three-source embodiment, three source-to-target edges are retained. This makes contribution provenance queryable without implying legal ownership or family status.

The graph is exported as canonical JSON to support deterministic validation and defensive publication evidence.

---

## 8. Non-ownership translated into technical authority

The theoretical non-ownership principle cannot be proven merely by writing `owner = none`. The MVP therefore translates one part of non-ownership into an enforceable technical boundary.

Protected fields include:

```text
offspring_uid
identity_root
memory_root
lineage_id
manifest_digest
lineage_provenance
generation_event
```

A parent/source attempting to directly change a protected field receives `ProtectedCoreWriteDenied`.

A parent may instead call a proposal interface for mutable regions such as:

```text
preferences
skills
notes
```

The proposal is recorded as `PENDING`; it does not mutate the generated entity.

The entity's own runtime surface may update allowed mutable regions. In CAOR v0.1, "self-update" is only an object-level mutation API. It is not evidence of subjective agency.

This distinction concretizes:

$$
\text{Contribution} \neq \text{Permanent Core-State Write Authority}.
$$

---

## 9. Embodiments

CAOR ships five executable embodiments.

### Human-profile + AI

Demonstrates heterogeneous source kinds using one structured human profile and one AI entity.

### AI + AI

Demonstrates two artificial source entities contributing through the same normalized interface.

### Multi-source

Demonstrates three independent contribution sources and three typed lineage edges.

### Copy vs Fork vs Offspring

Runs the event classifier on three explicit evidence records and demonstrates that the events are not aliases.

### Parent write denied

Attempts a protected identity-root mutation, confirms rejection, then submits a proposal to a mutable preference region and confirms that no direct mutation occurred.

---

## 10. Defensive publication value

A purely philosophical statement such as "future humans and AIs may have offspring" leaves enormous ambiguity about implementation. CAOR deliberately discloses a narrower, testable technical combination:

1. typed source contribution records;
2. canonical multi-source contribution normalization;
3. deterministic manifest binding;
4. independent identity, memory, state, and lineage initialization;
5. explicit `COPY / FORK / OFFSPRING / RESTORE / UPDATE / MIGRATION / MERGE` classification;
6. typed lineage graph evidence;
7. protected-core source-write boundaries;
8. Human-profile + AI, AI + AI, and multi-source embodiments.

The accompanying defensive technical disclosure restates these elements using claim-like engineering language. It is not a patent filing and makes no representation about patentability or legal effect.

---

## 11. What v0.1 intentionally does not prove

CAOR does not solve the hard questions that motivated the broader theory.

It does not prove:

```text
subjectivity
consciousness
love
moral status
legal personhood
legal parenthood
biological reproduction
```

The runtime proves something smaller but useful: that the conceptual pipeline can be expressed as deterministic, testable computer operations with explicit state and lineage semantics.

That makes the idea easier to inspect, critique, reproduce, extend, and cite defensively.

---

## 12. Future adapters

Possible later adapters include:

- neural model or embedding contributions;
- cryptographic provenance;
- persistent lineage stores;
- policy engines;
- distributed identity migration;
- agent runtimes;
- relationship/kinship legal adapters.

None is necessary for the v0.1 proposition.

The v0.1 priority is deliberately:

$$
\boxed{\text{Defensive Clarity} > \text{Model Complexity}.}
$$

---

## 13. Closure

CAOR MVP v0.1 turns the original conceptual chain:

```text
HIM + AIM → OSI → OIS → Child
```

into the more implementation-neutral chain:

```text
Typed Source Contributions
        ↓
Canonical Manifest
        ↓
Deterministic OSI
        ↓
Independent OIS
        ↓
Guarded Computational Entity
        ↓
Typed Lineage Evidence
```

Its central engineering proposition is:

$$
\boxed{
\text{Structured Source Contributions}
\rightarrow
\text{Independent Computational Initialization}
\rightarrow
\text{Typed Lineage Evidence}.
}
$$

Its central defensive distinctions are:

$$
\boxed{
\text{COPY} \neq \text{FORK} \neq \text{OFFSPRING}
}
$$

and:

$$
\boxed{
\text{Contribution} \neq \text{Permanent Core-State Write Authority}.
}
$$

**CAOR MVP v0.1 therefore closes the conceptual-to-engineering translation layer without claiming the subjectivity layer is solved.**
