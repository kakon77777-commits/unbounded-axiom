# CAOR MVP v0.1 — Release Notes

**Date:** 2026-08-30

## Status

`MVP v0.1 = COMPLETE`

## Verified evidence

- `...................................                                      [100%]
35 passed in 6.07s`
- `compileall = PASS`
- Five source-tree demos = PASS
- Offline clean-venv install from source = PASS
- Offline clean-venv install from wheel = PASS
- `subjectivity_claimed = false`
- `legal_personhood_claimed = false`
- `biological_reproduction_claimed = false`

## Canonical distinctions

```text
COPY != FORK != OFFSPRING
Contribution != Permanent Core-State Write Authority
Computational Independence != Subjectivity
```

## Deliverables

- deterministic CAOR runtime
- 35-test TDD suite
- five executable embodiments
- canonical engineering specification
- engineering whitepaper
- defensive technical disclosure with claim-like clauses
- offline-installable pure-Python wheel
- validation manifest
