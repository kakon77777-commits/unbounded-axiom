# CAOR MVP v0.2 Release Notes

**Release:** v0.2.0 — Development & Divergence Runtime  
**Date:** 2026-08-30

## Added

- append-only `DevelopmentLedger`;
- deterministic `DevelopmentEvent` types: `SELF_UPDATE`, `ACCEPT_PROPOSAL`, `ENVIRONMENT_EVENT`;
- state replay from event history;
- explicit parent-proposal acceptance without direct parent core mutation;
- deterministic source baselines and origin-state projection;
- cross-time `DivergenceSnapshot` and divergence timeline;
- deterministic `DevelopmentEvidenceBundle` with `subjectivity_claimed=false`;
- executable `development_divergence.py` reference demo;
- v0.2 engineering whitepaper;
- v0.2 defensive technical disclosure with claim-like Clauses 15–26.

## Preserved

- all CAOR v0.1 event classification semantics;
- `COPY != FORK != OFFSPRING` distinction;
- protected OIS core;
- standard-library-only runtime;
- offline clean-venv installability;
- explicit non-subjectivity scope firewall.

## Core v0.2 proposition

$$
\boxed{
\text{Independent Initialization}
+
\text{Independent Event History}
\rightarrow
\text{Replayable Cross-Time Development Evidence}.
}
$$

This remains an engineering claim only.
