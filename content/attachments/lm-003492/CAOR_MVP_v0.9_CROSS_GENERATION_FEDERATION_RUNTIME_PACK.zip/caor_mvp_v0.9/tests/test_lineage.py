import json
import pytest

from caor.contributions import normalize_contributions
from caor.errors import InvalidLineageEvent
from caor.lineage import LineageEdge, LineageEventType, LineageGraph, LineageNode
from caor.models import Contribution, ContributionCategory, ParentContributionBundle, SourceKind
from caor.synthesis import synthesize_offspring


def offspring_fixture():
    bundles = (
        ParentContributionBundle(
            source_id="human:H",
            source_kind=SourceKind.HUMAN_PROFILE,
            contributions=(Contribution(ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "style", "analytic", 0.5, "fixture"),),
            provenance={},
        ),
        ParentContributionBundle(
            source_id="ai:A",
            source_kind=SourceKind.AI_ENTITY,
            contributions=(Contribution(ContributionCategory.COGNITIVE_TRAIT, "ai:A", "a1", "planning", "strong", 0.5, "fixture"),),
            provenance={},
        ),
    )
    manifest = normalize_contributions(bundles)
    return manifest, synthesize_offspring(manifest, "lineage-seed")


def test_record_offspring_preserves_all_sources_and_typed_event():
    manifest, ois = offspring_fixture()
    graph = LineageGraph()

    edges = graph.record_offspring(manifest.source_ids, ois, manifest.digest, {"classifier": "offspring invariants"})

    assert len(edges) == 2
    assert {edge.event_type for edge in edges} == {LineageEventType.OFFSPRING}
    assert {edge.source_uids[0] for edge in edges} == set(manifest.source_ids)
    assert {edge.target_uids[0] for edge in edges} == {ois.offspring_uid}
    assert all(edge.manifest_digest == manifest.digest for edge in edges)


def test_graph_export_is_canonical_and_json_readable():
    manifest, ois = offspring_fixture()
    graph = LineageGraph()
    graph.record_offspring(tuple(reversed(manifest.source_ids)), ois, manifest.digest, {"z": 1, "a": 2})

    first = graph.canonical_bytes()
    second = graph.canonical_bytes()

    assert first == second
    decoded = json.loads(first)
    assert decoded["edges"][0]["event_type"] == "OFFSPRING"
    assert [node["entity_uid"] for node in decoded["nodes"]] == sorted(node["entity_uid"] for node in decoded["nodes"])


def test_add_edge_rejects_unknown_nodes():
    graph = LineageGraph()
    graph.add_node(LineageNode("known", "root", "lineage", "SOURCE", "UNSPECIFIED"))
    edge = LineageEdge("e1", LineageEventType.COPY, ("known",), ("missing",), None, "UNSPECIFIED", {})

    with pytest.raises(InvalidLineageEvent):
        graph.add_edge(edge)


def test_add_edge_rejects_noncanonical_event_type():
    graph = LineageGraph()
    graph.add_node(LineageNode("a", "r1", "l1", "SOURCE", "UNSPECIFIED"))
    graph.add_node(LineageNode("b", "r2", "l2", "SOURCE", "UNSPECIFIED"))
    edge = LineageEdge("e1", "CLONE", ("a",), ("b",), None, "UNSPECIFIED", {})

    with pytest.raises(InvalidLineageEvent):
        graph.add_edge(edge)
