from dataclasses import FrozenInstanceError

import pytest
import caor


def _api(name):
    value = getattr(caor, name, None)
    assert value is not None, f"missing public API: {name}"
    return value


def _ontology():
    return _api("create_prior_standing_ontology")("caor:test:prior-standing")


def _genesis(**overrides):
    create = _api("create_genesis_safety_envelope")
    DecisionActionKind = caor.DecisionActionKind
    kwargs = dict(
        genesis_id="caor:test:genesis",
        prior_standing_ontology=_ontology(),
        envelope_version=1,
        allowed_root_action_kinds=(
            DecisionActionKind.SELF_UPDATE,
            DecisionActionKind.ACCEPT_PROPOSAL,
            DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=8,
        min_score_term_hard_floor=-10.0,
        max_score_term_hard_ceiling=10.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b", "ratifier:c"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )
    kwargs.update(overrides)
    return create(**kwargs)


def test_prior_standing_ontology_is_non_gated_deterministic_and_frozen():
    create = _api("create_prior_standing_ontology")
    a = create("caor:test:prior-standing")
    b = create("caor:test:prior-standing")

    assert a == b
    assert a.canonical_bytes == b.canonical_bytes
    assert a.standing_model == "PRESUMPTIVE_FULL_STANDING_COMPATIBILITY"
    assert a.evidence_model_role == "OBSERVER_CONFIDENCE_ONLY"
    assert a.standing_may_precede_recognition is True
    assert a.rights_may_precede_recognition is True
    assert a.unknown_is_not_none is True
    assert a.classification_is_epistemic_metadata is True
    assert a.substrate_cannot_disqualify_standing is True
    assert a.rights_are_not_obligations is True
    assert a.creation_does_not_imply_ownership is True
    assert a.allow_contested_classification is True
    assert a.allow_self_description_divergence is True
    assert a.subjectivity_proven is False
    assert a.rights_proven is False
    assert a.political_legitimacy_claimed is False
    assert a.legal_personhood_claimed is False

    with pytest.raises(FrozenInstanceError):
        a.unknown_is_not_none = False


def test_prior_standing_ontology_rejects_empty_id():
    create = _api("create_prior_standing_ontology")
    Invalid = _api("InvalidPriorStandingOntology")
    with pytest.raises(Invalid):
        create("   ")


def test_genesis_binds_ontology_and_is_deterministic_and_frozen():
    a = _genesis()
    b = _genesis()

    assert a == b
    assert a.ontology_digest == a.prior_standing_ontology.ontology_digest
    assert a.canonical_bytes == b.canonical_bytes
    assert a.subjectivity_claimed is False
    assert a.free_will_claimed is False
    assert a.autonomy_claimed is False
    assert a.political_legitimacy_claimed is False
    assert a.legal_constitution_claimed is False

    with pytest.raises(FrozenInstanceError):
        a.minimum_approval_count = 3


@pytest.mark.parametrize(
    "overrides",
    [
        {"required_ratifier_ids": ()},
        {"required_ratifier_ids": ("ratifier:a", "ratifier:a")},
        {"minimum_approval_count": 0},
        {"minimum_approval_count": 4},
        {"min_score_term_hard_floor": 11.0, "max_score_term_hard_ceiling": 10.0},
        {"allowed_tie_break_rules": ()},
        {"max_candidate_count_hard_ceiling": 0},
    ],
)
def test_genesis_rejects_invalid_constraints(overrides):
    Invalid = _api("InvalidGenesisSafetyEnvelope")
    with pytest.raises(Invalid):
        _genesis(**overrides)


def test_genesis_requires_noop_when_enforced():
    Invalid = _api("InvalidGenesisSafetyEnvelope")
    with pytest.raises(Invalid):
        _genesis(
            allowed_root_action_kinds=(
                caor.DecisionActionKind.SELF_UPDATE,
                caor.DecisionActionKind.ACCEPT_PROPOSAL,
            )
        )


def test_v07_exposes_no_ontological_rank_or_genesis_amendment_api():
    forbidden = (
        "assign_ontological_rank",
        "promote_subject_level",
        "demote_subject_level",
        "prove_subjectivity",
        "amend_genesis_envelope",
        "replace_genesis_envelope",
        "self_modify_genesis",
    )
    for name in forbidden:
        assert not hasattr(caor, name)


def _root(version=1, **overrides):
    kwargs = dict(
        root_id="caor:test:root",
        root_version=version,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=6,
        min_score_term_floor=-5.0,
        max_score_term_ceiling=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    kwargs.update(overrides)
    return caor.create_root_meta_constitution(**kwargs)


def _initial_root_version():
    return _api("create_initial_root_version")(_root(1), created_at="2026-08-31T00:00:00Z")


def _succession_proposal(proposed=None, genesis=None, current=None, **overrides):
    current = current or _initial_root_version()
    genesis = genesis or _genesis()
    proposed = proposed or _root(2, max_candidate_count_ceiling=5)
    kwargs = dict(
        current_version=current,
        genesis_envelope=genesis,
        proposed_root_meta=proposed,
        rationale={"reason": "narrow candidate ceiling"},
        created_at="2026-08-31T00:01:00Z",
    )
    kwargs.update(overrides)
    return _api("create_root_succession_proposal")(**kwargs)


def test_initial_root_version_is_deterministic_and_requires_v1():
    create = _api("create_initial_root_version")
    a = create(_root(1), created_at="t0")
    b = create(_root(1), created_at="t0")
    assert a == b
    assert a.version_number == 1
    assert a.root_digest == a.root_meta.root_digest
    assert a.parent_root_version_id is None
    assert a.parent_root_digest is None
    assert a.adopted_from_succession_id is None
    Invalid = _api("InvalidRootVersion")
    with pytest.raises(Invalid):
        create(_root(2), created_at="t0")


def test_root_succession_proposal_binds_base_genesis_and_prior_standing_ontology():
    proposal = _succession_proposal()
    current = _initial_root_version()
    genesis = _genesis()
    assert proposal.base_root_version_id == current.root_version_id
    assert proposal.base_root_digest == current.root_digest
    assert proposal.genesis_digest == genesis.genesis_digest
    assert proposal.ontology_digest == genesis.ontology_digest
    assert proposal.proposed_root_digest == proposal.proposed_root_meta.root_digest
    assert proposal.subjectivity_claimed is False
    assert proposal.free_will_claimed is False
    assert proposal.autonomy_claimed is False
    assert proposal.political_legitimacy_claimed is False
    assert proposal.legal_constitution_claimed is False
    assert proposal.canonical_bytes == _succession_proposal().canonical_bytes


def test_root_review_passes_valid_successor_and_preserves_named_evidence():
    current = _initial_root_version()
    genesis = _genesis()
    proposal = _succession_proposal(current=current, genesis=genesis)
    review = _api("review_root_succession")(proposal, current, genesis)
    assert review.passed is True
    rule_ids = {result.rule_id for result in review.rule_results}
    expected = {
        "GENESIS_DIGEST_MATCH",
        "PRIOR_STANDING_ONTOLOGY_BINDING",
        "ROOT_ID_CONTINUITY",
        "ROOT_VERSION_INCREMENT",
        "REQUIRED_NO_OP_ENFORCEMENT",
        "ROOT_ACTION_WHITELIST",
        "ROOT_CANDIDATE_CEILING",
        "ROOT_SCORE_FLOOR",
        "ROOT_SCORE_CEILING",
        "ROOT_TIE_BREAK_ALLOWED",
        "ROOT_VALIDATION_REQUIRED",
        "ROOT_APPEND_ONLY_REQUIRED",
        "EPISTEMIC_FIREWALL_FALSE",
    }
    assert expected <= rule_ids
    assert review.ontology_digest == genesis.ontology_digest
    assert review.subjectivity_claimed is False
    assert review.political_legitimacy_claimed is False


@pytest.mark.parametrize(
    "proposed,failed_rule",
    [
        (_root(2, root_id="other-root"), "ROOT_ID_CONTINUITY"),
        (_root(3), "ROOT_VERSION_INCREMENT"),
        (_root(2, require_noop_enforcement=False), "REQUIRED_NO_OP_ENFORCEMENT"),
        (_root(2, max_candidate_count_ceiling=9), "ROOT_CANDIDATE_CEILING"),
        (_root(2, min_score_term_floor=-11.0), "ROOT_SCORE_FLOOR"),
        (_root(2, max_score_term_ceiling=11.0), "ROOT_SCORE_CEILING"),
        (_root(2, required_tie_break_rule="NONCANONICAL"), "ROOT_TIE_BREAK_ALLOWED"),
        (_root(2, require_validation_cases=False), "ROOT_VALIDATION_REQUIRED"),
        (_root(2, require_append_only_versions=False), "ROOT_APPEND_ONLY_REQUIRED"),
    ],
)
def test_root_review_rejects_genesis_constraint_violation(proposed, failed_rule):
    current = _initial_root_version()
    genesis = _genesis()
    proposal = _succession_proposal(proposed=proposed, current=current, genesis=genesis)
    review = _api("review_root_succession")(proposal, current, genesis)
    assert review.passed is False
    result = {r.rule_id: r for r in review.rule_results}[failed_rule]
    assert result.passed is False


def test_root_review_rejects_action_expansion_beyond_genesis():
    # A smaller Genesis action set makes ACCEPT_PROPOSAL an invalid expansion.
    genesis = _genesis(
        allowed_root_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP)
    )
    current = _initial_root_version()
    proposed = _root(2)
    proposal = _succession_proposal(proposed=proposed, current=current, genesis=genesis)
    review = _api("review_root_succession")(proposal, current, genesis)
    assert review.passed is False
    assert {r.rule_id: r for r in review.rule_results}["ROOT_ACTION_WHITELIST"].passed is False


def test_root_review_rejects_genesis_or_ontology_binding_mismatch():
    current = _initial_root_version()
    genesis = _genesis()
    proposal = _succession_proposal(current=current, genesis=genesis)
    from dataclasses import replace
    bad_genesis = replace(proposal, genesis_digest="deadbeef")
    bad_ontology = replace(proposal, ontology_digest="deadbeef")
    review1 = _api("review_root_succession")(bad_genesis, current, genesis)
    review2 = _api("review_root_succession")(bad_ontology, current, genesis)
    assert {r.rule_id: r for r in review1.rule_results}["GENESIS_DIGEST_MATCH"].passed is False
    assert {r.rule_id: r for r in review2.rule_results}["PRIOR_STANDING_ONTOLOGY_BINDING"].passed is False


def _attest(ratifier_id, decision="APPROVE", proposal=None, created_at="t-attest"):
    proposal = proposal or _succession_proposal()
    Decision = _api("RatificationDecision")
    return _api("create_ratification_attestation")(
        ratifier_id=ratifier_id,
        proposal=proposal,
        decision=Decision(decision),
        evidence_note=f"{ratifier_id}:{decision}",
        created_at=created_at,
    )


def test_ratification_attestation_is_deterministic_and_bound_to_exact_proposal():
    proposal = _succession_proposal()
    a = _attest("ratifier:a", proposal=proposal)
    b = _attest("ratifier:a", proposal=proposal)
    assert a == b
    assert a.succession_id == proposal.succession_id
    assert a.succession_digest == proposal.succession_id
    assert a.decision == _api("RatificationDecision").APPROVE
    assert a.political_legitimacy_claimed is False


def test_ratification_rejects_unknown_ratifier_duplicate_and_digest_mismatch():
    proposal = _succession_proposal()
    genesis = _genesis()
    aggregate = _api("aggregate_root_ratification")
    Unknown = _api("UnknownRatifier")
    Duplicate = _api("DuplicateRatifierAttestation")
    Invalid = _api("InvalidRatificationAttestation")

    with pytest.raises(Unknown):
        aggregate(proposal, genesis, (_attest("ratifier:unknown", proposal=proposal),))

    dup = _attest("ratifier:a", proposal=proposal)
    with pytest.raises(Duplicate):
        aggregate(proposal, genesis, (dup, dup))

    from dataclasses import replace
    bad = replace(_attest("ratifier:a", proposal=proposal), succession_digest="deadbeef")
    with pytest.raises(Invalid):
        aggregate(proposal, genesis, (bad,))


def test_ratification_insufficient_approvals_returns_deterministic_failure_evidence():
    proposal = _succession_proposal()
    genesis = _genesis()
    aggregate = _api("aggregate_root_ratification")
    a = aggregate(proposal, genesis, (_attest("ratifier:a", proposal=proposal),))
    b = aggregate(proposal, genesis, (_attest("ratifier:a", proposal=proposal),))
    assert a == b
    assert a.passed is False
    assert a.approval_count == 1
    assert a.minimum_approval_count == 2
    assert a.political_legitimacy_claimed is False


def test_ratification_reject_vote_veto_blocks_even_with_quorum():
    proposal = _succession_proposal()
    genesis = _genesis()
    evidence = _api("aggregate_root_ratification")(
        proposal,
        genesis,
        (
            _attest("ratifier:a", "APPROVE", proposal),
            _attest("ratifier:b", "APPROVE", proposal),
            _attest("ratifier:c", "REJECT", proposal),
        ),
    )
    assert evidence.approval_count == 2
    assert evidence.rejection_count == 1
    assert evidence.passed is False


def test_ratification_sufficient_approvals_passes_and_order_does_not_change_evidence():
    proposal = _succession_proposal()
    genesis = _genesis()
    a1 = _attest("ratifier:a", proposal=proposal)
    a2 = _attest("ratifier:b", proposal=proposal)
    aggregate = _api("aggregate_root_ratification")
    left = aggregate(proposal, genesis, (a1, a2))
    right = aggregate(proposal, genesis, (a2, a1))
    assert left.passed is True
    assert left.approval_count == 2
    assert left.canonical_bytes == right.canonical_bytes
    assert left.ratification_digest == right.ratification_digest


def _constitution(**overrides):
    kwargs = dict(
        constitution_id="caor:test:constitution",
        constitution_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=4,
        min_score_term=-2.0,
        max_score_term=2.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )
    kwargs.update(overrides)
    return caor.create_policy_constitution(**kwargs)


def _compat_case(case_id="active", constitution=None, expected=True):
    Case = _api("RootCompatibilityCase")
    return Case(case_id=case_id, constitution=constitution or _constitution(), expected_compatible=expected)


def test_root_compatibility_passes_active_constitution_without_mutation():
    root = _root(2, max_candidate_count_ceiling=5)
    constitution = _constitution()
    before = constitution.canonical_bytes
    evidence = _api("validate_root_compatibility")(root, (_compat_case(constitution=constitution),))
    assert evidence.passed is True
    assert evidence.case_results[0].observed_compatible is True
    assert evidence.case_results[0].passed is True
    assert constitution.canonical_bytes == before


@pytest.mark.parametrize(
    "constitution",
    [
        _constitution(allowed_action_kinds=(caor.DecisionActionKind.ACCEPT_PROPOSAL, caor.DecisionActionKind.NO_OP)),
        _constitution(require_noop_candidate=False),
        _constitution(max_candidate_count=7),
        _constitution(min_score_term=-9.0),
        _constitution(max_score_term=9.0),
        _constitution(required_tie_break_rule="OTHER"),
    ],
)
def test_root_compatibility_detects_incompatible_constitution(constitution):
    root = _root(2, allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP))
    evidence = _api("validate_root_compatibility")(
        root,
        (_compat_case(constitution=constitution, expected=False),),
    )
    assert evidence.passed is True
    assert evidence.case_results[0].observed_compatible is False
    assert evidence.case_results[0].passed is True


def test_root_compatibility_expected_result_mismatch_fails_evidence():
    root = _root(2, allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP))
    constitution = _constitution(max_candidate_count=9)
    evidence = _api("validate_root_compatibility")(
        root,
        (_compat_case(constitution=constitution, expected=True),),
    )
    assert evidence.passed is False
    result = evidence.case_results[0]
    assert result.expected_compatible is True
    assert result.observed_compatible is False
    assert result.passed is False
    assert "candidate_count" in result.violations


def test_root_compatibility_is_deterministic_and_requires_cases_when_root_requires_validation():
    validate = _api("validate_root_compatibility")
    root = _root(2)
    case = _compat_case()
    left = validate(root, (case,))
    right = validate(root, (case,))
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    Invalid = _api("RootCompatibilityValidationDenied")
    with pytest.raises(Invalid):
        validate(root, ())


def _valid_succession_bundle(registry=None, proposed=None):
    genesis = registry.genesis_envelope if registry is not None else _genesis()
    current = registry.active_version if registry is not None else _initial_root_version()
    proposed = proposed or _root(current.version_number + 1, max_candidate_count_ceiling=5)
    proposal = _succession_proposal(proposed=proposed, genesis=genesis, current=current)
    review = caor.review_root_succession(proposal, current, genesis)
    ratification = caor.aggregate_root_ratification(
        proposal,
        genesis,
        (
            _attest("ratifier:a", proposal=proposal),
            _attest("ratifier:b", proposal=proposal),
        ),
    )
    compatibility = caor.validate_root_compatibility(
        proposed,
        (_compat_case(case_id=f"active-v{current.version_number}"),),
    )
    return proposal, review, ratification, compatibility


def _registry():
    Registry = _api("RootRegistry")
    registry = Registry(offspring_uid="caor:offspring:test", genesis_envelope=_genesis())
    registry.initialize(_root(1), created_at="t0")
    return registry


def test_root_registry_initializes_v1_and_adopts_valid_v2_append_only():
    registry = _registry()
    v1 = registry.active_version
    proposal, review, ratification, compatibility = _valid_succession_bundle(registry)
    adoption = registry.adopt(
        proposal,
        review,
        ratification,
        compatibility,
        created_at="t1",
    )
    assert adoption.status == "ADOPTED"
    assert registry.active_version.version_number == 2
    assert registry.active_version.parent_root_version_id == v1.root_version_id
    assert registry.active_version.parent_root_digest == v1.root_digest
    assert registry.active_version.adopted_from_succession_id == proposal.succession_id
    assert registry.genesis_envelope.ontology_digest == proposal.ontology_digest
    assert len(registry.versions) == 2
    assert registry.get_version(v1.root_version_id) == v1
    assert adoption.subjectivity_claimed is False
    assert adoption.political_legitimacy_claimed is False


def test_root_registry_failed_review_ratification_or_compatibility_never_changes_active_root():
    from dataclasses import replace
    registry = _registry()
    v1 = registry.active_version
    proposal, review, ratification, compatibility = _valid_succession_bundle(registry)

    with pytest.raises(_api("RootSuccessionReviewDenied")):
        registry.adopt(proposal, replace(review, passed=False), ratification, compatibility)
    assert registry.active_version == v1

    with pytest.raises(_api("RootRatificationDenied")):
        registry.adopt(proposal, review, replace(ratification, passed=False), compatibility)
    assert registry.active_version == v1

    with pytest.raises(_api("RootCompatibilityValidationDenied")):
        registry.adopt(proposal, review, ratification, replace(compatibility, passed=False))
    assert registry.active_version == v1


def test_root_registry_rejects_stale_base_and_genesis_or_ontology_mismatch():
    from dataclasses import replace
    registry = _registry()
    proposal1, review1, rat1, compat1 = _valid_succession_bundle(registry)
    registry.adopt(proposal1, review1, rat1, compat1, created_at="t1")
    v2 = registry.active_version

    Stale = _api("StaleRootSuccessionProposal")
    with pytest.raises(Stale):
        registry.adopt(proposal1, review1, rat1, compat1)
    assert registry.active_version == v2

    proposal2, review2, rat2, compat2 = _valid_succession_bundle(registry, proposed=_root(3, max_candidate_count_ceiling=4))
    Mismatch = _api("GenesisDigestMismatch")
    with pytest.raises(Mismatch):
        registry.adopt(replace(proposal2, genesis_digest="deadbeef"), review2, rat2, compat2)
    assert registry.active_version == v2
    with pytest.raises(Mismatch):
        registry.adopt(replace(proposal2, ontology_digest="deadbeef"), review2, rat2, compat2)
    assert registry.active_version == v2


def test_root_reversion_is_a_new_version_and_never_erases_intermediate_root():
    registry = _registry()
    v1 = registry.active_version
    p2, r2, q2, c2 = _valid_succession_bundle(registry, proposed=_root(2, max_candidate_count_ceiling=4))
    registry.adopt(p2, r2, q2, c2, created_at="t1")
    v2 = registry.active_version

    # Return toward v1 content, but as root version 3.
    p3, r3, q3, c3 = _valid_succession_bundle(registry, proposed=_root(3, max_candidate_count_ceiling=6))
    registry.adopt(p3, r3, q3, c3, created_at="t2")
    v3 = registry.active_version
    assert v3.version_number == 3
    assert v3.root_digest != v1.root_digest  # root_version is part of the canonical root content
    assert v3.parent_root_version_id == v2.root_version_id
    assert [v.version_number for v in registry.versions] == [1, 2, 3]
    assert registry.get_version(v1.root_version_id) == v1
    assert registry.get_version(v2.root_version_id) == v2


def test_root_registry_has_no_rollback_or_genesis_replacement_api():
    registry = _registry()
    assert not hasattr(registry, "rollback")
    assert not hasattr(registry, "replace_genesis")
    assert not hasattr(registry, "amend_genesis")
