import json
import pytest

from caor.contributions import normalize_contributions
from caor.errors import SourceUIDReuseDenied
from caor.models import Contribution, ContributionCategory, ParentContributionBundle, SourceKind
from caor.synthesis import SynthesisPolicy, synthesize_offspring


def manifest():
    bundles = (
        ParentContributionBundle(
            source_id="human:H",
            source_kind=SourceKind.HUMAN_PROFILE,
            contributions=(Contribution(ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", "high", 0.6, "synthetic"),),
            provenance={"type": "synthetic-human"},
        ),
        ParentContributionBundle(
            source_id="ai:A",
            source_kind=SourceKind.AI_ENTITY,
            contributions=(Contribution(ContributionCategory.VALUE_TRAIT, "ai:A", "a1", "care", "high", 0.4, "synthetic"),),
            provenance={"type": "synthetic-ai"},
        ),
    )
    return normalize_contributions(bundles)


def test_synthesis_creates_independent_roots_and_namespace():
    m = manifest()
    ois = synthesize_offspring(m, "seed-1")

    assert ois.offspring_uid not in m.source_ids
    assert ois.identity_root not in m.source_ids
    assert ois.memory_root not in m.source_ids
    assert all(not ois.state_namespace.startswith(source + ":") for source in m.source_ids)
    assert ois.generation_event == "OFFSPRING"
    assert ois.manifest_digest == m.digest
    assert set(ois.parent_contributions) == set(m.source_ids)


def test_same_manifest_and_seed_produces_byte_identical_ois():
    m = manifest()
    first = synthesize_offspring(m, "same-seed")
    second = synthesize_offspring(m, "same-seed")

    assert first.canonical_bytes == second.canonical_bytes
    assert json.loads(first.canonical_bytes) == json.loads(second.canonical_bytes)


def test_different_seed_changes_identity_root():
    m = manifest()
    first = synthesize_offspring(m, "seed-a")
    second = synthesize_offspring(m, "seed-b")

    assert first.identity_root != second.identity_root
    assert first.memory_root != second.memory_root
    assert first.lineage_id != second.lineage_id


def test_source_uid_reuse_is_rejected():
    m = manifest()
    with pytest.raises(SourceUIDReuseDenied):
        synthesize_offspring(m, "seed", SynthesisPolicy(offspring_uid="ai:A"))
