import pytest

from caor.contributions import normalize_contributions
from caor.entity import OffspringEntity
from caor.errors import ProtectedCoreWriteDenied
from caor.models import Contribution, ContributionCategory, ParentContributionBundle, SourceKind
from caor.synthesis import synthesize_offspring


def make_entity():
    m = normalize_contributions((
        ParentContributionBundle(
            source_id="ai:parent",
            source_kind=SourceKind.AI_ENTITY,
            contributions=(Contribution(ContributionCategory.VALUE_TRAIT, "ai:parent", "p1", "care", True, 1.0, "fixture"),),
            provenance={},
        ),
    ))
    return OffspringEntity(synthesize_offspring(m, "child-seed"))


def test_parent_direct_core_write_is_denied():
    entity = make_entity()
    original = entity.ois.identity_root

    with pytest.raises(ProtectedCoreWriteDenied):
        entity.direct_core_write("ai:parent", "identity_root", "replacement")

    assert entity.ois.identity_root == original


def test_parent_update_is_proposal_only():
    entity = make_entity()

    proposal = entity.propose_update("ai:parent", "preferences", "music", "jazz")

    assert proposal.status == "PENDING"
    assert proposal.source_id == "ai:parent"
    assert entity.mutable_state["preferences"] == {}


def test_child_can_mutate_allowed_region_without_changing_protected_core():
    entity = make_entity()
    original_core = entity.protected_core_snapshot()

    entity.self_update("preferences", "music", "jazz")

    assert entity.mutable_state["preferences"]["music"] == "jazz"
    assert entity.protected_core_snapshot() == original_core
