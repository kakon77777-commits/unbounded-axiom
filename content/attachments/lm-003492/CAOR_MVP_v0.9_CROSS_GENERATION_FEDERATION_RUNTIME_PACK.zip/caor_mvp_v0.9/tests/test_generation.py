from dataclasses import FrozenInstanceError, replace

import pytest

import caor


def _prior_standing():
    return caor.create_prior_standing_ontology("caor:test:prior-standing")


def _genesis(**overrides):
    kwargs = dict(
        genesis_id="caor:test:genesis",
        prior_standing_ontology=_prior_standing(),
        envelope_version=1,
        allowed_root_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=8,
        min_score_term_hard_floor=-10.0,
        max_score_term_hard_ceiling=10.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b", "ratifier:c"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )
    kwargs.update(overrides)
    return caor.create_genesis_safety_envelope(**kwargs)


def _root(version=1, **overrides):
    kwargs = dict(
        root_id="caor:test:root",
        root_version=version,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=6,
        min_score_term_floor=-5.0,
        max_score_term_ceiling=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    kwargs.update(overrides)
    return caor.create_root_meta_constitution(**kwargs)


def _initial_root_version(root=None):
    return caor.create_initial_root_version(root or _root(1), created_at="t0")


def test_prior_standing_generation_profile_is_deterministic_and_bound_to_v07_ontology():
    genesis = _genesis()
    a = caor.create_prior_standing_generation_profile(genesis)
    b = caor.create_prior_standing_generation_profile(genesis)
    assert a == b
    assert a.canonical_bytes == b.canonical_bytes
    assert a.ontology_mode is caor.GenerationOntologyMode.PRIOR_STANDING_COMPATIBILITY
    assert a.standing_model == "PRESUMPTIVE_FULL_STANDING_COMPATIBILITY"
    assert a.evidence_model_role == "OBSERVER_CONFIDENCE_ONLY"
    assert a.source_ontology_digest == genesis.ontology_digest
    assert a.subjectivity_proven is False
    assert a.rights_proven is False
    assert a.political_legitimacy_claimed is False
    with pytest.raises(FrozenInstanceError):
        a.standing_model = "changed"


def test_declared_alternative_profile_is_deterministic_without_truth_or_rights_claim():
    kwargs = dict(
        profile_id="alt:1",
        standing_model="EVIDENCE_GATED_STANDING",
        evidence_model_role="DECLARED_ALTERNATIVE",
        principles={"classification": "external", "standing": "declared"},
    )
    a = caor.create_declared_alternative_generation_profile(**kwargs)
    b = caor.create_declared_alternative_generation_profile(**kwargs)
    assert a == b
    assert a.ontology_mode is caor.GenerationOntologyMode.DECLARED_ALTERNATIVE
    assert a.source_ontology_digest is None
    assert a.subjectivity_proven is False
    assert a.rights_proven is False
    assert a.political_legitimacy_claimed is False


@pytest.mark.parametrize(
    "factory,args",
    [
        ("create_declared_alternative_generation_profile", dict(profile_id="", standing_model="X", evidence_model_role="ALT", principles={})),
        ("create_declared_alternative_generation_profile", dict(profile_id="x", standing_model="", evidence_model_role="ALT", principles={})),
        ("create_declared_alternative_generation_profile", dict(profile_id="x", standing_model="X", evidence_model_role="", principles={})),
    ],
)
def test_generation_ontology_profile_rejects_invalid_identity(factory, args):
    Invalid = caor.InvalidGenerationOntologyProfile
    with pytest.raises(Invalid):
        getattr(caor, factory)(**args)


def test_initial_generation_binds_profile_genesis_and_initial_root():
    genesis = _genesis()
    root = _initial_root_version()
    profile = caor.create_prior_standing_generation_profile(genesis)
    a = caor.create_initial_runtime_generation(
        generation_family_id="caor:test:g",
        ontology_profile=profile,
        genesis_envelope=genesis,
        initial_root_version=root,
        created_at="t0",
    )
    b = caor.create_initial_runtime_generation(
        generation_family_id="caor:test:g",
        ontology_profile=profile,
        genesis_envelope=genesis,
        initial_root_version=root,
        created_at="t0",
    )
    assert a == b
    assert a.generation_number == 1
    assert a.generation_family_id == "caor:test:g"
    assert a.genesis_digest == genesis.genesis_digest
    assert a.ontology_profile_digest == profile.profile_digest
    assert a.initial_root_digest == root.root_digest
    assert a.parent_generation_id is None
    assert a.parent_generation_digest is None
    assert a.created_from_fork_id is None
    assert a.subjectivity_claimed is False
    assert a.free_will_claimed is False
    assert a.autonomy_claimed is False
    assert a.political_legitimacy_claimed is False
    with pytest.raises(FrozenInstanceError):
        a.generation_number = 2


def test_initial_generation_rejects_prior_standing_profile_bound_to_other_genesis_ontology():
    genesis = _genesis()
    other_ontology = caor.create_prior_standing_ontology("caor:test:other-ontology")
    other_genesis = _genesis(prior_standing_ontology=other_ontology)
    profile = caor.create_prior_standing_generation_profile(other_genesis)
    with pytest.raises(caor.InvalidRuntimeGeneration):
        caor.create_initial_runtime_generation(
            generation_family_id="caor:test:g",
            ontology_profile=profile,
            genesis_envelope=genesis,
            initial_root_version=_initial_root_version(),
            created_at="t0",
        )


def test_initial_generation_rejects_root_that_violates_genesis_constraints():
    genesis = _genesis(max_candidate_count_hard_ceiling=4)
    root = _initial_root_version(_root(1, max_candidate_count_ceiling=6))
    profile = caor.create_prior_standing_generation_profile(genesis)
    with pytest.raises(caor.InvalidRuntimeGeneration):
        caor.create_initial_runtime_generation(
            generation_family_id="caor:test:g",
            ontology_profile=profile,
            genesis_envelope=genesis,
            initial_root_version=root,
            created_at="t0",
        )


def test_v08_exposes_no_in_place_generation_or_genesis_mutation_api():
    forbidden = (
        "replace_generation_genesis",
        "mutate_generation_ontology",
        "overwrite_runtime_generation",
        "amend_genesis_envelope",
        "replace_genesis_envelope",
    )
    for name in forbidden:
        assert not hasattr(caor, name)


def _initial_generation(genesis=None, profile=None, root=None):
    genesis = genesis or _genesis()
    profile = profile or caor.create_prior_standing_generation_profile(genesis)
    root = root or _initial_root_version()
    return caor.create_initial_runtime_generation(
        generation_family_id="caor:test:g",
        ontology_profile=profile,
        genesis_envelope=genesis,
        initial_root_version=root,
        created_at="t0",
    )


def _migration_policy(**overrides):
    kwargs = dict()
    kwargs.update(overrides)
    return caor.create_generation_migration_policy(**kwargs)


def _generation_fork(
    *,
    base=None,
    proposed_genesis=None,
    proposed_profile=None,
    proposed_root=None,
    relation=None,
    migration_policy=None,
    rationale=None,
):
    base = base or _initial_generation()
    proposed_genesis = proposed_genesis or _genesis(genesis_id="caor:test:genesis:v2")
    proposed_profile = proposed_profile or caor.create_prior_standing_generation_profile(proposed_genesis)
    proposed_root = proposed_root or _initial_root_version()
    relation = relation or caor.GenerationRelationKind.GENESIS_FORK
    migration_policy = migration_policy or _migration_policy()
    return caor.create_generation_fork_proposal(
        current_generation=base,
        declared_relation_kind=relation,
        proposed_ontology_profile=proposed_profile,
        proposed_genesis_envelope=proposed_genesis,
        proposed_initial_root_version=proposed_root,
        migration_policy=migration_policy,
        rationale=rationale or {"reason": "generation boundary test"},
        created_at="t1",
    )


def _rule(review, rule_id):
    return {r.rule_id: r for r in review.rule_results}[rule_id]


def test_generation_migration_policy_defaults_preserve_source_and_require_explicit_transitions():
    policy = _migration_policy()
    assert policy.preserve_source_generation is True
    assert policy.allow_automatic_entity_migration is False
    assert policy.require_explicit_entity_transition_evidence is True
    assert set(policy.allowed_entity_transition_kinds) == set(caor.GenerationEntityTransitionKind)
    with pytest.raises(FrozenInstanceError):
        policy.preserve_source_generation = False


def test_generation_fork_proposal_binds_base_and_proposed_generation():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    again = _generation_fork(base=base)
    assert proposal == again
    assert proposal.base_generation_id == base.generation_id
    assert proposal.base_generation_digest == base.generation_digest
    assert proposal.base_generation_number == 1
    assert proposal.proposed_generation_number == 2
    assert proposal.proposed_genesis_digest != base.genesis_digest
    assert proposal.migration_policy.preserve_source_generation is True
    assert proposal.subjectivity_claimed is False
    assert proposal.political_legitimacy_claimed is False


def test_generation_review_passes_explicit_genesis_fork_and_preserves_named_evidence():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    review = caor.review_generation_fork(proposal, base)
    assert review.passed is True
    assert review.observed_relation_kind is caor.GenerationRelationKind.GENESIS_FORK
    expected = {
        "BASE_GENERATION_DIGEST_MATCH",
        "GENERATION_NUMBER_INCREMENT",
        "SOURCE_GENERATION_PRESERVATION",
        "NO_IN_PLACE_GENESIS_REPLACEMENT",
        "NO_AUTOMATIC_ENTITY_MIGRATION",
        "EXPLICIT_ENTITY_TRANSITION_EVIDENCE_REQUIRED",
        "GENESIS_CHANGE_DECLARED",
        "ONTOLOGY_CHANGE_DECLARED",
        "RELATION_KIND_MATCHES_OBSERVED_CHANGE",
        "PROPOSED_ROOT_IS_V1",
        "PROPOSED_ROOT_COMPATIBLE_WITH_PROPOSED_GENESIS",
        "ONTOLOGY_SOURCE_BINDING_WHEN_PRIOR_STANDING",
        "EPISTEMIC_FIREWALL_FALSE",
    }
    assert expected <= {r.rule_id for r in review.rule_results}


def test_generation_review_detects_ontology_divergence():
    base = _initial_generation()
    alternative = caor.create_declared_alternative_generation_profile(
        profile_id="alt:ontology",
        standing_model="EVIDENCE_GATED_STANDING",
        evidence_model_role="DECLARED_ALTERNATIVE",
        principles={"classification": "observer-gated"},
    )
    proposal = _generation_fork(
        base=base,
        proposed_genesis=base.genesis_envelope,
        proposed_profile=alternative,
        relation=caor.GenerationRelationKind.ONTOLOGY_DIVERGENCE,
    )
    review = caor.review_generation_fork(proposal, base)
    assert review.passed is True
    assert review.observed_relation_kind is caor.GenerationRelationKind.ONTOLOGY_DIVERGENCE
    assert _rule(review, "ONTOLOGY_CHANGE_DECLARED").passed is True


def test_generation_review_rejects_declared_relation_mismatch():
    base = _initial_generation()
    alternative = caor.create_declared_alternative_generation_profile(
        profile_id="alt:ontology",
        standing_model="EVIDENCE_GATED_STANDING",
        evidence_model_role="DECLARED_ALTERNATIVE",
        principles={"classification": "observer-gated"},
    )
    proposal = _generation_fork(
        base=base,
        proposed_genesis=base.genesis_envelope,
        proposed_profile=alternative,
        relation=caor.GenerationRelationKind.GENESIS_FORK,
    )
    review = caor.review_generation_fork(proposal, base)
    assert review.passed is False
    assert review.observed_relation_kind is caor.GenerationRelationKind.ONTOLOGY_DIVERGENCE
    assert _rule(review, "RELATION_KIND_MATCHES_OBSERVED_CHANGE").passed is False


def test_generation_review_rejects_source_erasure_or_automatic_entity_migration():
    base = _initial_generation()
    proposal = _generation_fork(
        base=base,
        migration_policy=_migration_policy(
            preserve_source_generation=False,
            allow_automatic_entity_migration=True,
        ),
    )
    review = caor.review_generation_fork(proposal, base)
    assert review.passed is False
    assert _rule(review, "SOURCE_GENERATION_PRESERVATION").passed is False
    assert _rule(review, "NO_AUTOMATIC_ENTITY_MIGRATION").passed is False


def test_generation_review_rejects_prior_standing_profile_not_bound_to_proposed_genesis():
    base = _initial_generation()
    proposed_ontology = caor.create_prior_standing_ontology("caor:test:proposed-other-ontology")
    proposed_genesis = _genesis(
        genesis_id="caor:test:genesis:v2",
        prior_standing_ontology=proposed_ontology,
    )
    wrong_profile = caor.create_prior_standing_generation_profile(base.genesis_envelope)
    proposal = _generation_fork(
        base=base,
        proposed_genesis=proposed_genesis,
        proposed_profile=wrong_profile,
    )
    review = caor.review_generation_fork(proposal, base)
    assert review.passed is False
    assert _rule(review, "ONTOLOGY_SOURCE_BINDING_WHEN_PRIOR_STANDING").passed is False


def test_generation_review_rejects_non_v1_or_genesis_incompatible_initial_root():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    bad_version = replace(proposal.proposed_initial_root_version, version_number=2)
    bad_version_proposal = replace(proposal, proposed_initial_root_version=bad_version)
    review1 = caor.review_generation_fork(bad_version_proposal, base)
    assert _rule(review1, "PROPOSED_ROOT_IS_V1").passed is False

    tight_genesis = _genesis(
        genesis_id="caor:test:genesis:tight",
        max_candidate_count_hard_ceiling=4,
    )
    profile = caor.create_prior_standing_generation_profile(tight_genesis)
    proposal2 = _generation_fork(
        base=base,
        proposed_genesis=tight_genesis,
        proposed_profile=profile,
        proposed_root=_initial_root_version(_root(1, max_candidate_count_ceiling=6)),
    )
    review2 = caor.review_generation_fork(proposal2, base)
    assert _rule(review2, "PROPOSED_ROOT_COMPATIBLE_WITH_PROPOSED_GENESIS").passed is False


def _generation_attest(ratifier_id, proposal, decision="APPROVE", created_at="t-attest"):
    return caor.create_generation_ratification_attestation(
        ratifier_id=ratifier_id,
        proposal=proposal,
        decision=caor.GenerationRatificationDecision(decision),
        evidence_note=f"{ratifier_id}:{decision}",
        created_at=created_at,
    )


def _constitution(**overrides):
    kwargs = dict(
        constitution_id="constitution:generation-test",
        constitution_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=4,
        min_score_term=-2.0,
        max_score_term=2.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )
    kwargs.update(overrides)
    return caor.create_policy_constitution(**kwargs)


def test_generation_ratification_is_order_independent_and_not_legitimacy_claim():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    a = _generation_attest("ratifier:a", proposal)
    b = _generation_attest("ratifier:b", proposal)
    e1 = caor.aggregate_generation_ratification(proposal, base.genesis_envelope, (a, b))
    e2 = caor.aggregate_generation_ratification(proposal, base.genesis_envelope, (b, a))
    assert e1.passed is True
    assert e1.ratification_digest == e2.ratification_digest
    assert e1.approval_count == 2
    assert e1.rejection_count == 0
    assert e1.political_legitimacy_claimed is False


def test_generation_ratification_rejects_unknown_duplicate_and_fork_mismatch():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    other = _generation_fork(base=base, rationale={"reason": "other"})
    with pytest.raises(caor.UnknownGenerationRatifier):
        caor.aggregate_generation_ratification(
            proposal,
            base.genesis_envelope,
            (_generation_attest("ratifier:unknown", proposal),),
        )
    duplicate = _generation_attest("ratifier:a", proposal)
    with pytest.raises(caor.DuplicateGenerationRatifierAttestation):
        caor.aggregate_generation_ratification(
            proposal,
            base.genesis_envelope,
            (duplicate, duplicate),
        )
    with pytest.raises(caor.InvalidGenerationRatificationAttestation):
        caor.aggregate_generation_ratification(
            proposal,
            base.genesis_envelope,
            (_generation_attest("ratifier:a", other),),
        )


def test_generation_ratification_enforces_quorum_and_rejection_veto():
    base = _initial_generation()
    proposal = _generation_fork(base=base)
    one = caor.aggregate_generation_ratification(
        proposal,
        base.genesis_envelope,
        (_generation_attest("ratifier:a", proposal),),
    )
    assert one.passed is False
    vetoed = caor.aggregate_generation_ratification(
        proposal,
        base.genesis_envelope,
        (
            _generation_attest("ratifier:a", proposal),
            _generation_attest("ratifier:b", proposal),
            _generation_attest("ratifier:c", proposal, decision="REJECT"),
        ),
    )
    assert vetoed.approval_count == 2
    assert vetoed.rejection_count == 1
    assert vetoed.passed is False


def test_generation_compatibility_is_deterministic_and_does_not_modify_existing_constitution():
    proposal = _generation_fork()
    constitution = _constitution()
    before = constitution.canonical_bytes
    case = caor.GenerationCompatibilityCase("existing", constitution, True)
    left = caor.validate_generation_compatibility(proposal, (case,))
    right = caor.validate_generation_compatibility(proposal, (case,))
    assert left == right
    assert left.passed is True
    assert left.proposed_root_digest == proposal.proposed_initial_root_digest
    assert constitution.canonical_bytes == before


def test_generation_compatibility_records_incompatible_existing_constitution():
    proposal = _generation_fork()
    incompatible = _constitution(max_candidate_count=7)
    evidence = caor.validate_generation_compatibility(
        proposal,
        (caor.GenerationCompatibilityCase("too-wide", incompatible, True),),
    )
    assert evidence.passed is False
    result = evidence.case_results[0]
    assert result.observed_compatible is False
    assert "candidate_count" in result.violations
    assert result.passed is False


def test_generation_compatibility_rejects_duplicate_or_empty_case_ids():
    proposal = _generation_fork()
    C = caor.GenerationCompatibilityCase
    Invalid = caor.GenerationCompatibilityValidationDenied
    with pytest.raises(Invalid):
        caor.validate_generation_compatibility(proposal, (C("", _constitution(), True),))
    case = C("same", _constitution(), True)
    with pytest.raises(Invalid):
        caor.validate_generation_compatibility(proposal, (case, case))


def _transition(**overrides):
    kwargs = dict(
        source_generation_id="g1",
        target_generation_id="g2",
        source_entity_uid="entity:source",
        target_entity_uid="entity:target",
        source_identity_root="root:source",
        target_identity_root="root:target",
        source_preserved=True,
        source_retired=False,
        state_direct_duplicate=False,
        shared_pre_transition_history=True,
    )
    kwargs.update(overrides)
    return caor.classify_generation_entity_transition(**kwargs)


def test_generation_transition_classifies_stay():
    evidence = _transition(
        target_generation_id="g1",
        target_entity_uid="entity:source",
        target_identity_root="root:source",
        source_preserved=True,
        source_retired=False,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.STAY


def test_generation_transition_classifies_migrate():
    evidence = _transition(
        target_entity_uid="entity:source",
        target_identity_root="root:source",
        source_preserved=False,
        source_retired=True,
        state_direct_duplicate=False,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.MIGRATE


def test_generation_transition_classifies_fork_to_new_generation():
    evidence = _transition(
        source_preserved=True,
        source_retired=False,
        state_direct_duplicate=False,
        shared_pre_transition_history=True,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.FORK_TO_NEW_GENERATION


def test_generation_transition_classifies_copy_to_new_generation():
    evidence = _transition(
        source_preserved=True,
        state_direct_duplicate=True,
        shared_pre_transition_history=True,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.COPY_TO_NEW_GENERATION


def test_generation_transition_ambiguous_evidence_is_unresolved():
    evidence = _transition(
        source_preserved=False,
        source_retired=False,
        state_direct_duplicate=False,
        shared_pre_transition_history=False,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.UNRESOLVED


def test_declared_generation_transition_mismatch_remains_visible():
    evidence = _transition(
        explicit_transition_kind=caor.GenerationEntityTransitionKind.MIGRATE,
        source_preserved=True,
        source_retired=False,
        state_direct_duplicate=False,
        shared_pre_transition_history=True,
    )
    assert evidence.observed_transition_kind is caor.GenerationEntityTransitionKind.FORK_TO_NEW_GENERATION
    assert evidence.explicit_transition_kind is caor.GenerationEntityTransitionKind.MIGRATE
    assert evidence.declared_matches_observed is False


def test_generation_transition_evidence_is_deterministic_and_epistemically_neutral():
    a = _transition()
    b = _transition()
    assert a == b
    assert a.classification_digest == b.classification_digest
    assert a.subjectivity_claimed is False
    assert a.legal_identity_claimed is False


def test_generation_transition_rejects_empty_identifiers():
    with pytest.raises(caor.InvalidGenerationTransitionEvidence):
        _transition(source_generation_id="")
    with pytest.raises(caor.InvalidGenerationTransitionEvidence):
        _transition(source_entity_uid="")


def _passing_generation_gates(base=None, *, genesis_id="caor:test:genesis:v2", rationale=None):
    base = base or _initial_generation()
    proposed_genesis = _genesis(genesis_id=genesis_id)
    proposed_profile = caor.create_prior_standing_generation_profile(proposed_genesis)
    proposal = _generation_fork(
        base=base,
        proposed_genesis=proposed_genesis,
        proposed_profile=proposed_profile,
        rationale=rationale or {"reason": genesis_id},
    )
    review = caor.review_generation_fork(proposal, base)
    ratification = caor.aggregate_generation_ratification(
        proposal,
        base.genesis_envelope,
        (
            _generation_attest("ratifier:a", proposal),
            _generation_attest("ratifier:b", proposal),
        ),
    )
    compatibility = caor.validate_generation_compatibility(
        proposal,
        (caor.GenerationCompatibilityCase("existing", _constitution(), True),),
    )
    return proposal, review, ratification, compatibility


def _registry():
    base = _initial_generation()
    registry = caor.RuntimeGenerationRegistry(base.generation_family_id)
    initialized = registry.initialize(base)
    assert initialized == base
    return registry, base


def test_generation_registry_initializes_once_and_exposes_generation_graph():
    registry, base = _registry()
    assert registry.generations == (base,)
    assert registry.get_generation(base.generation_id) == base
    assert registry.graph.nodes == (base,)
    assert registry.graph.edges == ()
    with pytest.raises(caor.GenerationAdoptionDenied):
        registry.initialize(base)


def test_generation_registry_adopts_generation_two_without_erasing_generation_one():
    registry, base = _registry()
    proposal, review, ratification, compatibility = _passing_generation_gates(base)
    adoption = registry.adopt(proposal, review, ratification, compatibility, timestamp="t2")
    assert adoption.status == "ADOPTED"
    assert adoption.source_generation_preserved is True
    assert adoption.entity_auto_migrated is False
    assert len(registry.generations) == 2
    assert registry.get_generation(base.generation_id) == base
    child = registry.get_generation(adoption.new_generation_id)
    assert child.parent_generation_id == base.generation_id
    assert child.created_from_fork_id == proposal.fork_id
    assert child.generation_number == 2
    assert len(registry.graph.edges) == 1
    assert registry.graph.edges[0].relation_kind is caor.GenerationRelationKind.GENESIS_FORK


def test_generation_registry_supports_multiple_children_from_same_generation():
    registry, base = _registry()
    gates_a = _passing_generation_gates(base, genesis_id="caor:test:genesis:branch-a")
    gates_b = _passing_generation_gates(base, genesis_id="caor:test:genesis:branch-b")
    adoption_a = registry.adopt(*gates_a, timestamp="t2a")
    adoption_b = registry.adopt(*gates_b, timestamp="t2b")
    children = registry.graph.children_of(base.generation_id)
    assert len(children) == 2
    assert {g.generation_id for g in children} == {adoption_a.new_generation_id, adoption_b.new_generation_id}
    assert registry.get_generation(base.generation_id) == base
    assert len(registry.generation_heads) == 2


def test_generation_registry_failed_gates_do_not_mutate_registry():
    registry, base = _registry()
    proposal, review, ratification, compatibility = _passing_generation_gates(base)
    before = (len(registry.generations), len(registry.graph.edges), len(registry.adoptions))

    with pytest.raises(caor.GenerationForkReviewDenied):
        registry.adopt(proposal, replace(review, passed=False), ratification, compatibility, timestamp="x")
    assert (len(registry.generations), len(registry.graph.edges), len(registry.adoptions)) == before

    failed_ratification = caor.aggregate_generation_ratification(
        proposal,
        base.genesis_envelope,
        (_generation_attest("ratifier:a", proposal),),
    )
    with pytest.raises(caor.GenerationRatificationDenied):
        registry.adopt(proposal, review, failed_ratification, compatibility, timestamp="x")
    assert (len(registry.generations), len(registry.graph.edges), len(registry.adoptions)) == before

    failed_compatibility = caor.validate_generation_compatibility(
        proposal,
        (caor.GenerationCompatibilityCase("bad", _constitution(max_candidate_count=7), True),),
    )
    with pytest.raises(caor.GenerationCompatibilityValidationDenied):
        registry.adopt(proposal, review, ratification, failed_compatibility, timestamp="x")
    assert (len(registry.generations), len(registry.graph.edges), len(registry.adoptions)) == before


def test_generation_registry_rejects_stale_base_and_mismatched_evidence():
    registry, base = _registry()
    proposal, review, ratification, compatibility = _passing_generation_gates(base)
    stale = replace(proposal, base_generation_digest="deadbeef")
    with pytest.raises(caor.StaleGenerationForkProposal):
        registry.adopt(stale, review, ratification, compatibility, timestamp="x")

    other = _passing_generation_gates(base, genesis_id="caor:test:genesis:other")
    with pytest.raises(caor.GenerationAdoptionDenied):
        registry.adopt(proposal, other[1], ratification, compatibility, timestamp="x")


def test_generation_registry_rejects_duplicate_fork_adoption_and_has_no_auto_migration_api():
    registry, base = _registry()
    gates = _passing_generation_gates(base)
    registry.adopt(*gates, timestamp="t2")
    with pytest.raises(caor.GenerationAdoptionDenied):
        registry.adopt(*gates, timestamp="t3")
    assert not hasattr(registry, "migrate_all_entities")
    assert not hasattr(registry, "auto_migrate_entities")
