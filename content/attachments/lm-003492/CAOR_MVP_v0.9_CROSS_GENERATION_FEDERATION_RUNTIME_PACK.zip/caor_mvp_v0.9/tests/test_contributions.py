import pytest

from caor.contributions import normalize_contributions
from caor.errors import DuplicateContributionID, InvalidContributionBundle, InvalidWeight, MissingSourceID
from caor.models import Contribution, ContributionCategory, ParentContributionBundle, SourceKind


def contribution(source_id: str, cid: str, weight: float = 1.0) -> Contribution:
    return Contribution(
        category=ContributionCategory.VALUE_TRAIT,
        source_id=source_id,
        contribution_id=cid,
        name="curiosity",
        value={"level": "high"},
        weight=weight,
        provenance_note="synthetic fixture",
    )


def bundle(source_id: str, cid: str = "c1", weight: float = 1.0) -> ParentContributionBundle:
    return ParentContributionBundle(
        source_id=source_id,
        source_kind=SourceKind.AI_ENTITY,
        contributions=(contribution(source_id, cid, weight),),
        provenance={"fixture": True},
    )


def test_manifest_is_deterministic_and_preserves_provenance():
    bundles = (bundle("ai:A", "a1", 0.75), bundle("ai:B", "b1", 0.25))

    first = normalize_contributions(bundles)
    second = normalize_contributions(tuple(reversed(bundles)))

    assert first.digest == second.digest
    assert first.canonical_bytes == second.canonical_bytes
    assert {item.source_id for item in first.contributions} == {"ai:A", "ai:B"}
    assert all(item.provenance_note == "synthetic fixture" for item in first.contributions)


def test_invalid_weight_is_rejected():
    with pytest.raises(InvalidWeight):
        normalize_contributions((bundle("ai:A", "bad", 1.1),))


def test_duplicate_contribution_id_is_rejected_even_across_sources():
    with pytest.raises(DuplicateContributionID):
        normalize_contributions((bundle("ai:A", "dup"), bundle("ai:B", "dup")))


def test_missing_source_id_is_rejected():
    with pytest.raises(MissingSourceID):
        normalize_contributions((bundle("", "x"),))


def test_manifest_preserves_source_kinds():
    bundles = (
        ParentContributionBundle(
            source_id="human:H",
            source_kind=SourceKind.HUMAN_PROFILE,
            contributions=(contribution("human:H", "h-kind"),),
            provenance={},
        ),
        ParentContributionBundle(
            source_id="ai:A",
            source_kind=SourceKind.AI_ENTITY,
            contributions=(contribution("ai:A", "a-kind"),),
            provenance={},
        ),
    )
    manifest = normalize_contributions(bundles)
    assert dict(manifest.source_kinds) == {
        "ai:A": "AI_ENTITY",
        "human:H": "HUMAN_PROFILE",
    }


def test_empty_source_set_is_rejected():
    with pytest.raises(InvalidContributionBundle):
        normalize_contributions(())
