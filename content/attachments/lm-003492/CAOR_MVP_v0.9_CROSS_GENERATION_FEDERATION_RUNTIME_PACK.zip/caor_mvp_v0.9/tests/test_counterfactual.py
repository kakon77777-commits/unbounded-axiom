import caor
import pytest


def make_manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", 0.2, 0.75, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "human:H", "h2", "logic", 0.4, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "ai:A", "a1", "curiosity", 0.8, 0.25, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a2", "logic", 0.9, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
    ))


def action(kind, region, key, value, external_id=None, timestamp="t1"):
    return caor.CounterfactualAction(
        action_kind=kind,
        region=region,
        key=key,
        value=value,
        external_id=external_id,
        timestamp=timestamp,
        evidence={"fixture": True},
    )


def test_same_origin_and_same_branch_spec_produces_byte_identical_trajectory():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "counterfactual-seed")
    spec = caor.CounterfactualBranchSpec(
        branch_label="research-path",
        actions=(
            action(caor.CounterfactualActionKind.SELF_UPDATE, "preferences", "curiosity", 0.95),
            action(caor.CounterfactualActionKind.ENVIRONMENT_EVENT, "skills", "logic", 0.7, "env:lab", "t2"),
        ),
        feasibility_note="caller-specified feasible scenario",
    )

    left = caor.run_counterfactual_branch(ois, manifest, spec)
    right = caor.run_counterfactual_branch(ois, manifest, spec)

    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert left.branch_id == right.branch_id
    assert left.event_count == 2
    assert [event.event_kind.value for event in left.events] == ["SELF_UPDATE", "ENVIRONMENT_EVENT"]


def test_source_proposal_action_is_proposed_then_explicitly_accepted_by_branch_entity():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "proposal-branch")
    spec = caor.CounterfactualBranchSpec(
        branch_label="accept-human-proposal",
        actions=(
            action(caor.CounterfactualActionKind.SOURCE_PROPOSAL, "notes", "tradition", "kept", "human:H"),
        ),
    )

    trajectory = caor.run_counterfactual_branch(ois, manifest, spec)

    assert trajectory.event_count == 1
    assert trajectory.events[0].event_kind.value == "ACCEPT_PROPOSAL"
    assert trajectory.events[0].evidence["proposal_source_id"] == "human:H"
    assert trajectory.final_projected_state["notes"]["tradition"] == "kept"


def test_unknown_source_proposal_is_rejected():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "bad-proposal")
    spec = caor.CounterfactualBranchSpec(
        branch_label="invalid",
        actions=(
            action(caor.CounterfactualActionKind.SOURCE_PROPOSAL, "notes", "x", 1, "unknown:source"),
        ),
    )

    with pytest.raises(caor.InvalidContributionBundle):
        caor.run_counterfactual_branch(ois, manifest, spec)


def test_environment_action_requires_external_id():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "bad-env")
    spec = caor.CounterfactualBranchSpec(
        branch_label="invalid-env",
        actions=(action(caor.CounterfactualActionKind.ENVIRONMENT_EVENT, "notes", "weather", "rain"),),
    )

    with pytest.raises(caor.InvalidCounterfactualAction):
        caor.run_counterfactual_branch(ois, manifest, spec)


def test_running_one_branch_does_not_contaminate_another_branch_from_same_origin():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "isolation-seed")
    left_spec = caor.CounterfactualBranchSpec(
        "left",
        (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "path", "left"),),
    )
    right_spec = caor.CounterfactualBranchSpec(
        "right",
        (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "path", "right"),),
    )

    left = caor.run_counterfactual_branch(ois, manifest, left_spec)
    right = caor.run_counterfactual_branch(ois, manifest, right_spec)

    assert left.final_projected_state["notes"]["path"] == "left"
    assert right.final_projected_state["notes"]["path"] == "right"
    assert left.final_state_digest != right.final_state_digest
    assert ois.canonical_bytes == caor.synthesize_offspring(manifest, "isolation-seed").canonical_bytes


def test_identical_trajectories_compare_at_zero_distance():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "compare-equal")
    spec = caor.CounterfactualBranchSpec(
        "same",
        (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "path", "same"),),
    )
    left = caor.run_counterfactual_branch(ois, manifest, spec)
    right = caor.run_counterfactual_branch(ois, manifest, spec)

    comparison = caor.compare_counterfactual_trajectories(left, right)

    assert comparison.state_distance == 0.0
    assert comparison.changed_keys == ()


def test_divergent_trajectories_have_positive_distance_and_changed_key_evidence():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "compare-different")
    left = caor.run_counterfactual_branch(
        ois,
        manifest,
        caor.CounterfactualBranchSpec("left", (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "path", "left"),)),
    )
    right = caor.run_counterfactual_branch(
        ois,
        manifest,
        caor.CounterfactualBranchSpec("right", (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "path", "right"),)),
    )

    comparison = caor.compare_counterfactual_trajectories(left, right)

    assert comparison.state_distance > 0.0
    assert "notes.path" in comparison.changed_keys
    assert comparison.left_final_state_digest == left.final_state_digest
    assert comparison.right_final_state_digest == right.final_state_digest


def test_counterfactual_evidence_bundle_is_deterministic_and_does_not_claim_free_will_or_subjectivity():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "bundle-seed")
    specs = (
        caor.CounterfactualBranchSpec("baseline", ()),
        caor.CounterfactualBranchSpec(
            "research",
            (action(caor.CounterfactualActionKind.SELF_UPDATE, "skills", "logic", 0.99),),
        ),
        caor.CounterfactualBranchSpec(
            "art",
            (action(caor.CounterfactualActionKind.ENVIRONMENT_EVENT, "notes", "project", "art", "env:studio"),),
        ),
    )

    left = caor.build_counterfactual_evidence(ois, manifest, specs)
    right = caor.build_counterfactual_evidence(ois, manifest, specs)

    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert left.branch_count == 3
    assert left.unique_final_state_count == 3
    assert len(left.pairwise_comparisons) == 3
    assert left.alternative_trajectories_observed is True
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False


def test_duplicate_branch_labels_are_rejected_in_aggregate_evidence():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "duplicate-label")
    specs = (
        caor.CounterfactualBranchSpec("same", ()),
        caor.CounterfactualBranchSpec("same", (action(caor.CounterfactualActionKind.SELF_UPDATE, "notes", "x", 1),)),
    )

    with pytest.raises(caor.InvalidCounterfactualBranch):
        caor.build_counterfactual_evidence(ois, manifest, specs)
