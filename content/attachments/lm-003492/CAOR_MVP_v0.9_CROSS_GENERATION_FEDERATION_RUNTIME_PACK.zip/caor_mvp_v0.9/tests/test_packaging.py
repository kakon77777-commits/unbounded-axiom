from pathlib import Path
import os
import subprocess
import sys


def test_clean_offline_venv_can_install_and_import_package(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    smoke = subprocess.run(
        [str(python), "-c", "import caor; print(caor.__name__)"],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "caor"


def test_project_and_build_backend_versions_match_v09():
    root = Path(__file__).resolve().parents[1]
    assert 'version = "0.9.0"' in (root / "pyproject.toml").read_text(encoding="utf-8")
    assert 'VERSION = "0.9.0"' in (root / "caor_build_backend.py").read_text(encoding="utf-8")


def test_clean_offline_venv_can_build_development_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-development"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = r'''import caor
m = caor.normalize_contributions((
    caor.ParentContributionBundle(
        source_id="ai:A",
        source_kind=caor.SourceKind.AI_ENTITY,
        contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "ai:A", "a1", "care", 0.4, 1.0, "smoke"),),
        provenance={},
    ),
))
e = caor.OffspringEntity(caor.synthesize_offspring(m, "installed-v02"))
e.self_update("preferences", "care", 0.9, timestamp="t1")
b = caor.build_development_evidence(e, m)
assert b.event_count == 1
assert b.subjectivity_claimed is False
assert len(b.divergence_timeline) == 2
print("v0.2-ok")'''
    smoke = subprocess.run(
        [str(python), "-c", script],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.2-ok"


def test_clean_offline_venv_can_build_counterfactual_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-counterfactual"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = '''import caor
m = caor.normalize_contributions((
    caor.ParentContributionBundle(
        source_id="ai:A",
        source_kind=caor.SourceKind.AI_ENTITY,
        contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "ai:A", "a1", "care", 0.4, 1.0, "smoke"),),
        provenance={},
    ),
))
ois = caor.synthesize_offspring(m, "installed-v03")
specs = (
    caor.CounterfactualBranchSpec("baseline", ()),
    caor.CounterfactualBranchSpec("changed", (
        caor.CounterfactualAction(caor.CounterfactualActionKind.SELF_UPDATE, "preferences", "care", 0.9),
    )),
)
b = caor.build_counterfactual_evidence(ois, m, specs)
assert b.branch_count == 2
assert b.unique_final_state_count == 2
assert b.alternative_trajectories_observed is True
assert b.subjectivity_claimed is False
assert b.free_will_claimed is False
assert b.autonomy_claimed is False
print("v0.3-ok")'''
    smoke = subprocess.run(
        [str(python), "-c", script],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.3-ok"


def test_clean_offline_venv_can_build_policy_selection_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-policy"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = """import caor
m = caor.normalize_contributions((
    caor.ParentContributionBundle(
        source_id='ai:A',
        source_kind=caor.SourceKind.AI_ENTITY,
        contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, 'ai:A', 'a1', 'care', 0.6, 1.0, 'smoke'),),
        provenance={},
    ),
))
ois = caor.synthesize_offspring(m, 'installed-v04')
e = caor.OffspringEntity(ois)
context = caor.build_decision_context(ois, m, e.development_events, {'opportunity': 'care'})
policy = caor.DecisionPolicy('smoke-policy', (
    caor.DecisionCandidate(
        'care',
        caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region='notes', key='path', value='care'),
        hard_conditions=(caor.DecisionCondition(caor.DecisionSignalKind.ENVIRONMENT, 'opportunity', caor.DecisionOperator.EQ, 'care'),),
    ),
    caor.DecisionCandidate('wait', caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
))
selection = caor.select_policy_candidate(policy, context)
result = caor.apply_policy_selection(e, selection, timestamp='t1')
assert selection.selected_candidate_id == 'care'
assert result.action_applied is True
assert e.mutable_state['notes']['path'] == 'care'
assert selection.subjectivity_claimed is False
assert selection.free_will_claimed is False
assert selection.autonomy_claimed is False
print('v0.4-ok')"""
    smoke = subprocess.run(
        [str(python), "-c", script],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.4-ok"



def test_clean_offline_venv_can_build_constitutional_policy_evolution_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-policy-evolution"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = """import caor
m = caor.normalize_contributions((
    caor.ParentContributionBundle(
        source_id='ai:A',
        source_kind=caor.SourceKind.AI_ENTITY,
        contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, 'ai:A', 'a1', 'care', 0.6, 1.0, 'smoke'),),
        provenance={},
    ),
))
ois = caor.synthesize_offspring(m, 'installed-v05')
e = caor.OffspringEntity(ois)
e.self_update('notes', 'x', 1, timestamp='t1')
e.self_update('notes', 'y', 2, timestamp='t2')
ctx = caor.build_decision_context(ois, m, e.development_events, {})
base = caor.DecisionPolicy('base', (caor.DecisionCandidate('wait', caor.DecisionAction(caor.DecisionActionKind.NO_OP)),))
registry = caor.PolicyRegistry(ois.offspring_uid)
v1 = registry.initialize(base, created_at='t0')
evolved = caor.DecisionPolicy('evolved', (
    caor.DecisionCandidate('reflect', caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region='notes', key='reflection', value=True)),
    caor.DecisionCandidate('wait', caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
))
template = caor.PolicyEvolutionTemplate('template', (caor.DecisionCondition(caor.DecisionSignalKind.HISTORY_COUNT, 'SELF_UPDATE', caor.DecisionOperator.GTE, 2),), evolved, {'smoke': True})
proposal = caor.generate_policy_change_proposal(ois.offspring_uid, v1, ctx, template)
constitution = caor.create_policy_constitution('constitution', 1, (caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.ACCEPT_PROPOSAL, caor.DecisionActionKind.NO_OP), True, 32, -1000.0, 1000.0, 'LEXICAL_CANDIDATE_ID')
review = caor.review_policy_proposal(proposal, constitution)
validations = caor.validate_proposed_policy(proposal, (caor.PolicyValidationCase('case', ctx, expected_candidate_id='reflect'),))
v2 = registry.adopt(proposal, review, validations, timestamp='t3')
assert v2.version_number == 2
assert registry.active_version.policy.policy_id == 'evolved'
assert registry.adoptions[-1].subjectivity_claimed is False
assert registry.adoptions[-1].free_will_claimed is False
assert registry.adoptions[-1].autonomy_claimed is False
print('v0.5-ok')"""
    smoke = subprocess.run(
        [str(python), "-c", script],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.5-ok"


def test_clean_offline_venv_can_build_meta_constitutional_governance_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-meta-constitution"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = """import caor
m = caor.normalize_contributions((
    caor.ParentContributionBundle(
        source_id='ai:A',
        source_kind=caor.SourceKind.AI_ENTITY,
        contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, 'ai:A', 'a1', 'care', 0.6, 1.0, 'smoke'),),
        provenance={},
    ),
))
ois = caor.synthesize_offspring(m, 'installed-v06')
ctx = caor.build_decision_context(ois, m, (), {})
root = caor.create_root_meta_constitution('root', 1, (caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.ACCEPT_PROPOSAL, caor.DecisionActionKind.NO_OP), True, 64, -1000.0, 1000.0, 'LEXICAL_CANDIDATE_ID', True, True)
base = caor.create_policy_constitution('constitution', 1, (caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.ACCEPT_PROPOSAL, caor.DecisionActionKind.NO_OP), True, 32, -100.0, 100.0, 'LEXICAL_CANDIDATE_ID')
registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
v1 = registry.initialize(base, created_at='t0')
proposed = caor.create_policy_constitution('constitution', 2, (caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.ACCEPT_PROPOSAL, caor.DecisionActionKind.NO_OP), True, 40, -100.0, 100.0, 'LEXICAL_CANDIDATE_ID')
amendment = caor.generate_constitution_amendment_proposal(ois.offspring_uid, v1, root, ctx, caor.ConstitutionAmendmentTemplate('amend', (), proposed, {}))
review = caor.review_constitution_amendment(amendment, v1, root)
base_policy = caor.DecisionPolicy('base-policy', (caor.DecisionCandidate('wait', caor.DecisionAction(caor.DecisionActionKind.NO_OP)),))
pv = caor.create_initial_policy_version(base_policy, created_at='t0')
policy_proposal = caor.generate_policy_change_proposal(ois.offspring_uid, pv, ctx, caor.PolicyEvolutionTemplate('policy-template', (), base_policy, {}))
validations = caor.validate_proposed_constitution(amendment, (caor.ConstitutionValidationCase('case', policy_proposal, True),))
v2 = registry.adopt(amendment, review, validations, timestamp='t1')
assert v2.version_number == 2
assert review.passed is True
assert all(item.passed for item in validations)
assert registry.root_meta.root_digest == root.root_digest
assert registry.adoptions[-1].subjectivity_claimed is False
assert registry.adoptions[-1].free_will_claimed is False
assert registry.adoptions[-1].autonomy_claimed is False
print('v0.6-ok')"""
    smoke = subprocess.run(
        [str(python), "-c", script],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.6-ok"


def test_clean_offline_venv_can_build_root_succession_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-root-succession"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path,
        env=env,
        text=True,
        capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = """import caor
ontology = caor.create_prior_standing_ontology('caor:installed:prior')
genesis = caor.create_genesis_safety_envelope(
    genesis_id='caor:installed:genesis', prior_standing_ontology=ontology, envelope_version=1,
    allowed_root_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
    require_noop_enforcement=True, max_candidate_count_hard_ceiling=8,
    min_score_term_hard_floor=-10.0, max_score_term_hard_ceiling=10.0,
    allowed_tie_break_rules=('LEXICAL_CANDIDATE_ID',), required_ratifier_ids=('r1','r2'),
    minimum_approval_count=2, reject_vote_is_veto=True, require_compatibility_cases=True,
    require_append_only_root_versions=True)
def mkroot(v, maxc):
    return caor.create_root_meta_constitution(
        root_id='caor:installed:root', root_version=v,
        allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_enforcement=True, max_candidate_count_ceiling=maxc,
        min_score_term_floor=-5.0, max_score_term_ceiling=5.0,
        required_tie_break_rule='LEXICAL_CANDIDATE_ID', require_validation_cases=True,
        require_append_only_versions=True)
registry = caor.RootRegistry('caor:offspring:installed', genesis)
registry.initialize(mkroot(1,6), created_at='t0')
proposal = caor.create_root_succession_proposal(current_version=registry.active_version,
    genesis_envelope=genesis, proposed_root_meta=mkroot(2,5), rationale={'installed': True}, created_at='t1')
review = caor.review_root_succession(proposal, registry.active_version, genesis)
a1 = caor.create_ratification_attestation(ratifier_id='r1', proposal=proposal, decision=caor.RatificationDecision.APPROVE)
a2 = caor.create_ratification_attestation(ratifier_id='r2', proposal=proposal, decision=caor.RatificationDecision.APPROVE)
rat = caor.aggregate_root_ratification(proposal, genesis, (a1,a2))
constitution = caor.create_policy_constitution(constitution_id='c', constitution_version=1,
    allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
    require_noop_candidate=True, max_candidate_count=4, min_score_term=-2.0, max_score_term=2.0,
    required_tie_break_rule='LEXICAL_CANDIDATE_ID')
compat = caor.validate_root_compatibility(mkroot(2,5), (caor.RootCompatibilityCase('active', constitution, True),))
adoption = registry.adopt(proposal, review, rat, compat, created_at='t2')
assert registry.active_version.version_number == 2
assert adoption.status == 'ADOPTED'
assert adoption.ontology_digest == ontology.ontology_digest
assert ontology.subjectivity_proven is False
assert ontology.rights_proven is False
assert adoption.political_legitimacy_claimed is False
print('v0.7-ok')"""
    smoke = subprocess.run(
        [str(python), "-c", script], cwd=tmp_path, env=env, text=True, capture_output=True
    )
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.7-ok"


def test_clean_offline_venv_can_build_generation_fork_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-generation-fork"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"

    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path, env=env, text=True, capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = """import caor
ontology = caor.create_prior_standing_ontology('installed:v08:ontology')
def genesis(gid):
    return caor.create_genesis_safety_envelope(
        genesis_id=gid, prior_standing_ontology=ontology, envelope_version=1,
        allowed_root_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_enforcement=True, max_candidate_count_hard_ceiling=8,
        min_score_term_hard_floor=-10.0, max_score_term_hard_ceiling=10.0,
        allowed_tie_break_rules=('LEXICAL_CANDIDATE_ID',), required_ratifier_ids=('r1','r2'),
        minimum_approval_count=2, reject_vote_is_veto=True, require_compatibility_cases=True,
        require_append_only_root_versions=True)
def rootv():
    r = caor.create_root_meta_constitution(
        root_id='root:v08', root_version=1,
        allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_enforcement=True, max_candidate_count_ceiling=6,
        min_score_term_floor=-5.0, max_score_term_ceiling=5.0,
        required_tie_break_rule='LEXICAL_CANDIDATE_ID', require_validation_cases=True,
        require_append_only_versions=True)
    return caor.create_initial_root_version(r, created_at='t0')
g1g = genesis('g:1')
g1 = caor.create_initial_runtime_generation(generation_family_id='family:v08', ontology_profile=caor.create_prior_standing_generation_profile(g1g), genesis_envelope=g1g, initial_root_version=rootv(), created_at='t0')
registry = caor.RuntimeGenerationRegistry('family:v08'); registry.initialize(g1)
g2g = genesis('g:2')
proposal = caor.create_generation_fork_proposal(current_generation=g1, declared_relation_kind=caor.GenerationRelationKind.GENESIS_FORK, proposed_ontology_profile=caor.create_prior_standing_generation_profile(g2g), proposed_genesis_envelope=g2g, proposed_initial_root_version=rootv(), migration_policy=caor.create_generation_migration_policy(), rationale={'installed': True}, created_at='t1')
review = caor.review_generation_fork(proposal, g1)
a1 = caor.create_generation_ratification_attestation(ratifier_id='r1', proposal=proposal, decision=caor.GenerationRatificationDecision.APPROVE)
a2 = caor.create_generation_ratification_attestation(ratifier_id='r2', proposal=proposal, decision=caor.GenerationRatificationDecision.APPROVE)
rat = caor.aggregate_generation_ratification(proposal, g1g, (a1,a2))
constitution = caor.create_policy_constitution('c', 1, (caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP), True, 4, -2.0, 2.0, 'LEXICAL_CANDIDATE_ID')
compat = caor.validate_generation_compatibility(proposal, (caor.GenerationCompatibilityCase('c', constitution, True),))
adoption = registry.adopt(proposal, review, rat, compat, timestamp='t2')
assert adoption.status == 'ADOPTED'
assert adoption.entity_auto_migrated is False
assert len(registry.generations) == 2
assert registry.get_generation(g1.generation_id) == g1
assert caor.__version__ == '0.9.0'
print('v0.8-ok')"""
    smoke = subprocess.run([str(python), "-c", script], cwd=tmp_path, env=env, text=True, capture_output=True)
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.8-ok"


def test_clean_offline_venv_can_build_cross_generation_federation_evidence(tmp_path):
    root = Path(__file__).resolve().parents[1]
    venv = tmp_path / "venv-federation"
    subprocess.run([sys.executable, "-m", "venv", str(venv)], check=True)
    python = venv / "bin" / "python"
    env = dict(os.environ)
    env["PIP_NO_INDEX"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    install = subprocess.run(
        [str(python), "-m", "pip", "install", "--no-build-isolation", str(root)],
        cwd=tmp_path, env=env, text=True, capture_output=True,
    )
    assert install.returncode == 0, install.stdout + install.stderr

    script = '''import caor
assert caor.__version__ == "0.9.0"
def ontology(tag):
    return caor.create_prior_standing_ontology("installed:v09:ontology:" + tag)
def genesis(tag):
    return caor.create_genesis_safety_envelope(
        genesis_id="installed:v09:genesis:" + tag, prior_standing_ontology=ontology(tag), envelope_version=1,
        allowed_root_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_enforcement=True, max_candidate_count_hard_ceiling=8,
        min_score_term_hard_floor=-10.0, max_score_term_hard_ceiling=10.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",), required_ratifier_ids=("r1","r2"),
        minimum_approval_count=2, reject_vote_is_veto=True, require_compatibility_cases=True,
        require_append_only_root_versions=True)
def rootv(tag):
    root = caor.create_root_meta_constitution(
        root_id="installed:v09:root:" + tag, root_version=1,
        allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE, caor.DecisionActionKind.NO_OP),
        require_noop_enforcement=True, max_candidate_count_ceiling=6,
        min_score_term_floor=-5.0, max_score_term_ceiling=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID", require_validation_cases=True,
        require_append_only_versions=True)
    return caor.create_initial_root_version(root, created_at="t0")
def generation(tag, alt=False):
    g = genesis(tag)
    profile = (caor.create_declared_alternative_generation_profile(
        profile_id="installed:v09:alt:" + tag, standing_model="OTHER_STANDING_MODEL",
        evidence_model_role="DECLARED_ALTERNATIVE", principles={"local":"true"})
        if alt else caor.create_prior_standing_generation_profile(g))
    return caor.create_initial_runtime_generation(
        generation_family_id="installed:v09:family:" + tag, ontology_profile=profile,
        genesis_envelope=g, initial_root_version=rootv(tag), created_at="t0")
ga, gb = generation("a"), generation("b", True)
disclosure = caor.create_boundary_disclosure_policy(
    allowed_data_scopes=("MESSAGE",), retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY)
proposal = caor.create_boundary_contract_proposal(
    generation_a=ga, generation_b=gb, allowed_capabilities=("MESSAGE",),
    allowed_authorities=(caor.BoundaryAuthorityKind.READ,), disclosure_policy=disclosure, created_at="t1")
a = caor.create_boundary_authorization_attestation(
    proposal=proposal, generation=ga, decision=caor.BoundaryAuthorizationDecision.AUTHORIZE)
b = caor.create_boundary_authorization_attestation(
    proposal=proposal, generation=gb, decision=caor.BoundaryAuthorizationDecision.AUTHORIZE)
auth = caor.aggregate_boundary_authorization(proposal=proposal, attestations=(a,b))
contract = caor.activate_boundary_contract(proposal, auth, activated_at="t2")
registry = caor.BoundaryContractRegistry(); registry.register(contract)
request = caor.create_cross_generation_request(
    contract=contract, source_generation=ga, target_generation=gb, actor_id="entity:x",
    capability="MESSAGE", authority=caor.BoundaryAuthorityKind.READ, data_scope="MESSAGE",
    payload_digest="sha256:x")
evidence = caor.evaluate_cross_generation_request(registry, request)
assert evidence.decision is caor.CrossGenerationInteractionDecision.ALLOWED
assert ga.ontology_profile_digest != gb.ontology_profile_digest
assert evidence.ontology_assimilation_performed is False
assert evidence.identity_rewrite_performed is False
assert evidence.protected_write_performed is False
assert evidence.subjective_consent_proven is False
print("v0.9-ok")'''
    smoke = subprocess.run([str(python), "-c", script], cwd=tmp_path, env=env, text=True, capture_output=True)
    assert smoke.returncode == 0, smoke.stdout + smoke.stderr
    assert smoke.stdout.strip() == "v0.9-ok"
