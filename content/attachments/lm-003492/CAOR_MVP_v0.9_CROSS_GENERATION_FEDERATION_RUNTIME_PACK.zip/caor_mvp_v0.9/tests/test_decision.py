import caor
import pytest


def make_manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", 0.2, 0.75, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "human:H", "h2", "logic", 0.4, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "ai:A", "a1", "curiosity", 0.8, 0.25, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a2", "logic", 0.9, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
    ))


def cond(signal, path, operator, expected=None):
    return caor.DecisionCondition(signal, path, operator, expected)


def score(condition, true_score, false_score=0.0):
    return caor.DecisionScoreTerm(condition, true_score, false_score)


def self_action(region, key, value):
    return caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region=region, key=key, value=value)


def noop_action():
    return caor.DecisionAction(caor.DecisionActionKind.NO_OP)


def policy(*candidates, policy_id="policy:test"):
    return caor.DecisionPolicy(policy_id=policy_id, candidates=tuple(candidates))


def test_same_context_and_policy_produce_byte_identical_selection_evidence():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-same")
    entity = caor.OffspringEntity(ois)
    p = policy(
        caor.DecisionCandidate(
            "research",
            self_action("notes", "path", "research"),
            hard_conditions=(cond(caor.DecisionSignalKind.ENVIRONMENT, "opportunity", caor.DecisionOperator.EQ, "research"),),
            score_terms=(score(cond(caor.DecisionSignalKind.STATE, "skills.logic", caor.DecisionOperator.GTE, 0.6), 2.0),),
        ),
        caor.DecisionCandidate("wait", noop_action(), score_terms=()),
    )

    left_context = caor.build_decision_context(ois, manifest, entity.development_events, {"opportunity": "research"})
    right_context = caor.build_decision_context(ois, manifest, entity.development_events, {"opportunity": "research"})
    left = caor.select_policy_candidate(p, left_context)
    right = caor.select_policy_candidate(p, right_context)

    assert left_context == right_context
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert left.selection_digest == right.selection_digest
    assert left.selected_candidate_id == "research"
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False


def test_environment_signal_changes_eligible_selected_candidate():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-env")
    entity = caor.OffspringEntity(ois)
    p = policy(
        caor.DecisionCandidate(
            "creative",
            self_action("notes", "path", "creative"),
            hard_conditions=(cond(caor.DecisionSignalKind.ENVIRONMENT, "opportunity", caor.DecisionOperator.EQ, "creative"),),
        ),
        caor.DecisionCandidate(
            "research",
            self_action("notes", "path", "research"),
            hard_conditions=(cond(caor.DecisionSignalKind.ENVIRONMENT, "opportunity", caor.DecisionOperator.EQ, "research"),),
        ),
        caor.DecisionCandidate("wait", noop_action()),
    )

    research = caor.select_policy_candidate(
        p, caor.build_decision_context(ois, manifest, entity.development_events, {"opportunity": "research"})
    )
    creative = caor.select_policy_candidate(
        p, caor.build_decision_context(ois, manifest, entity.development_events, {"opportunity": "creative"})
    )

    assert research.selected_candidate_id == "research"
    assert creative.selected_candidate_id == "creative"


def test_projected_state_signal_changes_selection_after_development_event():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-state")
    entity = caor.OffspringEntity(ois)
    p = policy(
        caor.DecisionCandidate(
            "high-curiosity",
            self_action("notes", "mode", "explore"),
            hard_conditions=(cond(caor.DecisionSignalKind.STATE, "preferences.curiosity", caor.DecisionOperator.GTE, 0.5),),
            score_terms=(score(cond(caor.DecisionSignalKind.STATE, "preferences.curiosity", caor.DecisionOperator.GTE, 0.8), 2.0),),
        ),
        caor.DecisionCandidate("wait", noop_action(), score_terms=(score(cond(caor.DecisionSignalKind.STATE, "preferences.curiosity", caor.DecisionOperator.LT, 0.5), 1.0),)),
    )

    before = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))
    entity.self_update("preferences", "curiosity", 0.9, timestamp="t1")
    after = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))

    assert before.selected_candidate_id == "wait"
    assert after.selected_candidate_id == "high-curiosity"


def test_history_count_signal_changes_selection_after_self_update():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-history")
    entity = caor.OffspringEntity(ois)
    p = policy(
        caor.DecisionCandidate(
            "reflect",
            self_action("notes", "reflection", True),
            hard_conditions=(cond(caor.DecisionSignalKind.HISTORY_COUNT, "SELF_UPDATE", caor.DecisionOperator.GTE, 1),),
        ),
        caor.DecisionCandidate("wait", noop_action()),
    )

    before = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))
    entity.self_update("notes", "first", "event", timestamp="t1")
    after = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))

    assert before.selected_candidate_id == "wait"
    assert after.selected_candidate_id == "reflect"
    assert after.context.history_event_counts["SELF_UPDATE"] == 1
    assert after.context.history_total == 1


def test_hard_conditions_exclude_candidate_and_lexical_id_breaks_equal_score_tie():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-tie")
    context = caor.build_decision_context(ois, manifest, (), {"enabled": True})
    p = policy(
        caor.DecisionCandidate(
            "blocked",
            noop_action(),
            hard_conditions=(cond(caor.DecisionSignalKind.ENVIRONMENT, "enabled", caor.DecisionOperator.EQ, False),),
            score_terms=(score(cond(caor.DecisionSignalKind.ENVIRONMENT, "enabled", caor.DecisionOperator.EQ, True), 99.0),),
        ),
        caor.DecisionCandidate("beta", noop_action()),
        caor.DecisionCandidate("alpha", noop_action()),
    )

    selection = caor.select_policy_candidate(p, context)
    evaluations = {item.candidate_id: item for item in selection.candidate_evaluations}

    assert evaluations["blocked"].eligible is False
    assert selection.selected_candidate_id == "alpha"
    assert selection.tie_break_rule == "LEXICAL_CANDIDATE_ID"


def test_no_eligible_candidate_raises_explicit_error():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-none")
    context = caor.build_decision_context(ois, manifest, (), {"enabled": False})
    p = policy(
        caor.DecisionCandidate(
            "only",
            noop_action(),
            hard_conditions=(cond(caor.DecisionSignalKind.ENVIRONMENT, "enabled", caor.DecisionOperator.EQ, True),),
        )
    )

    with pytest.raises(caor.NoEligibleDecisionCandidate):
        caor.select_policy_candidate(p, context)


def test_self_update_policy_application_records_selection_provenance():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-apply")
    entity = caor.OffspringEntity(ois)
    p = policy(caor.DecisionCandidate("research", self_action("notes", "path", "research")))
    selection = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))

    result = caor.apply_policy_selection(entity, selection, timestamp="t1")

    assert result.action_applied is True
    assert result.development_event.event_kind is caor.DevelopmentEventKind.SELF_UPDATE
    assert result.development_event.evidence["policy_selection_digest"] == selection.selection_digest
    assert result.development_event.evidence["policy_id"] == "policy:test"
    assert result.development_event.evidence["candidate_id"] == "research"
    assert entity.mutable_state["notes"]["path"] == "research"
    assert result.post_development_digest == entity.development_digest


def test_policy_can_accept_pending_parent_proposal_without_direct_parent_write():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-proposal")
    entity = caor.OffspringEntity(ois)
    proposal = entity.propose_update("human:H", "notes", "tradition", "kept")
    p = policy(
        caor.DecisionCandidate(
            "accept-parent-proposal",
            caor.DecisionAction(caor.DecisionActionKind.ACCEPT_PROPOSAL, proposal_id=proposal.proposal_id),
        )
    )
    selection = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {"proposal_status": "PENDING"}))

    result = caor.apply_policy_selection(entity, selection, timestamp="t2")

    assert entity.proposal_status(proposal.proposal_id) == "ACCEPTED"
    assert entity.mutable_state["notes"]["tradition"] == "kept"
    assert result.development_event.event_kind is caor.DevelopmentEventKind.ACCEPT_PROPOSAL
    assert result.development_event.evidence["proposal_source_id"] == "human:H"
    assert result.development_event.evidence["policy_selection_digest"] == selection.selection_digest


def test_noop_selection_returns_evidence_without_mutating_development_ledger():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-noop")
    entity = caor.OffspringEntity(ois)
    before = entity.development_digest
    p = policy(caor.DecisionCandidate("wait", noop_action()))
    selection = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))

    result = caor.apply_policy_selection(entity, selection, timestamp="t1")

    assert result.action_applied is False
    assert result.development_event is None
    assert entity.development_digest == before
    assert result.post_development_digest == before


def test_stale_selection_context_is_rejected_after_entity_changes():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-stale")
    entity = caor.OffspringEntity(ois)
    p = policy(caor.DecisionCandidate("path", self_action("notes", "path", "chosen")))
    selection = caor.select_policy_candidate(p, caor.build_decision_context(ois, manifest, entity.development_events, {}))
    entity.self_update("notes", "intervening", True, timestamp="t0")

    with pytest.raises(caor.StaleDecisionContext):
        caor.apply_policy_selection(entity, selection, timestamp="t1")


def test_rebuilt_context_from_same_event_history_reproduces_selection_byte_for_byte():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "decision-replay")
    entity = caor.OffspringEntity(ois)
    entity.self_update("preferences", "curiosity", 0.9, timestamp="t1")
    events = entity.development_events
    env = {"challenge": 0.8}
    p = policy(
        caor.DecisionCandidate(
            "challenge",
            self_action("notes", "mode", "challenge"),
            score_terms=(
                score(cond(caor.DecisionSignalKind.STATE, "preferences.curiosity", caor.DecisionOperator.GTE, 0.8), 1.0),
                score(cond(caor.DecisionSignalKind.ENVIRONMENT, "challenge", caor.DecisionOperator.GTE, 0.5), 2.0),
                score(cond(caor.DecisionSignalKind.HISTORY_TOTAL, "", caor.DecisionOperator.GTE, 1), 1.0),
            ),
        ),
        caor.DecisionCandidate("wait", noop_action()),
    )

    left_context = caor.build_decision_context(ois, manifest, events, env)
    right_context = caor.build_decision_context(ois, manifest, tuple(events), dict(env))
    left = caor.select_policy_candidate(p, left_context)
    right = caor.select_policy_candidate(p, right_context)

    assert left_context.canonical_bytes == right_context.canonical_bytes
    assert left.canonical_bytes == right.canonical_bytes
    assert left.selected_candidate_id == "challenge"
