import caor


def test_public_api_exposes_core_reference_runtime_symbols():
    expected = {
        "SourceKind",
        "ContributionCategory",
        "Contribution",
        "ParentContributionBundle",
        "ContributionManifest",
        "OffspringIdentitySpecification",
        "normalize_contributions",
        "SynthesisPolicy",
        "synthesize_offspring",
        "OffspringEntity",
        "LineageEventType",
        "LineageGraph",
        "ClassificationEvidence",
        "classify_event",
    }
    assert expected <= set(dir(caor))


def test_public_api_exposes_v02_development_and_divergence_symbols():
    expected = {
        "DevelopmentEventKind",
        "DevelopmentEvent",
        "DevelopmentLedger",
        "InvalidDevelopmentEvent",
        "replay_mutable_state",
        "DivergenceSnapshot",
        "DevelopmentEvidenceBundle",
        "source_baselines",
        "origin_state_projection",
        "development_value_distance",
        "compute_divergence_snapshot",
        "compute_divergence_timeline",
        "build_development_evidence",
    }
    assert expected <= set(dir(caor))


def test_public_api_exposes_v03_counterfactual_symbols():
    expected = {
        "CounterfactualActionKind",
        "CounterfactualAction",
        "CounterfactualBranchSpec",
        "CounterfactualTrajectory",
        "CounterfactualBranchComparison",
        "CounterfactualEvidenceBundle",
        "InvalidCounterfactualAction",
        "InvalidCounterfactualBranch",
        "run_counterfactual_branch",
        "compare_counterfactual_trajectories",
        "build_counterfactual_evidence",
    }
    assert expected <= set(dir(caor))


def test_public_api_exposes_v04_policy_selection_symbols():
    expected = {
        "DecisionActionKind",
        "DecisionSignalKind",
        "DecisionOperator",
        "DecisionAction",
        "DecisionCondition",
        "DecisionScoreTerm",
        "DecisionCandidate",
        "DecisionPolicy",
        "DecisionContext",
        "PolicySelectionEvidence",
        "PolicyExecutionResult",
        "InvalidDecisionPolicy",
        "InvalidDecisionCondition",
        "NoEligibleDecisionCandidate",
        "StaleDecisionContext",
        "build_decision_context",
        "select_policy_candidate",
        "apply_policy_selection",
    }
    assert expected <= set(dir(caor))
