from dataclasses import FrozenInstanceError

import pytest

import caor


def _ontology(tag="a"):
    return caor.create_prior_standing_ontology(f"caor:test:ontology:{tag}")


def _genesis(tag="a"):
    return caor.create_genesis_safety_envelope(
        genesis_id=f"caor:test:genesis:{tag}",
        prior_standing_ontology=_ontology(tag),
        envelope_version=1,
        allowed_root_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_hard_ceiling=8,
        min_score_term_hard_floor=-10.0,
        max_score_term_hard_ceiling=10.0,
        allowed_tie_break_rules=("LEXICAL_CANDIDATE_ID",),
        required_ratifier_ids=("ratifier:a", "ratifier:b"),
        minimum_approval_count=2,
        reject_vote_is_veto=True,
        require_compatibility_cases=True,
        require_append_only_root_versions=True,
    )


def _root_version(tag="a"):
    root = caor.create_root_meta_constitution(
        root_id=f"caor:test:root:{tag}",
        root_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=6,
        min_score_term_floor=-5.0,
        max_score_term_ceiling=5.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    return caor.create_initial_root_version(root, created_at="t0")


def _generation(tag="a", *, alternative=False):
    genesis = _genesis(tag)
    if alternative:
        profile = caor.create_declared_alternative_generation_profile(
            profile_id=f"caor:test:alternative:{tag}",
            standing_model="EVIDENCE_GATED_STANDING",
            evidence_model_role="DECLARED_ALTERNATIVE",
            principles={"standing": "local", "classification": "external"},
        )
    else:
        profile = caor.create_prior_standing_generation_profile(genesis)
    return caor.create_initial_runtime_generation(
        generation_family_id=f"caor:test:generation-family:{tag}",
        ontology_profile=profile,
        genesis_envelope=genesis,
        initial_root_version=_root_version(tag),
        created_at="t0",
    )


def _disclosure():
    return caor.create_boundary_disclosure_policy(
        allowed_data_scopes=("PROFILE", "MESSAGE"),
        retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY,
        allow_derivative_use=False,
        allow_redisclosure=False,
    )


def test_boundary_disclosure_policy_is_deterministic_and_normalized():
    a = caor.create_boundary_disclosure_policy(
        allowed_data_scopes=("MESSAGE", "PROFILE", "MESSAGE"),
        retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY,
    )
    b = caor.create_boundary_disclosure_policy(
        allowed_data_scopes=("PROFILE", "MESSAGE"),
        retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY,
    )
    assert a == b
    assert a.allowed_data_scopes == ("MESSAGE", "PROFILE")
    assert a.allow_derivative_use is False
    assert a.allow_redisclosure is False
    with pytest.raises(FrozenInstanceError):
        a.allow_redisclosure = True


def test_boundary_disclosure_policy_rejects_blank_scope():
    with pytest.raises(caor.InvalidBoundaryDisclosurePolicy):
        caor.create_boundary_disclosure_policy(
            allowed_data_scopes=("",),
            retention_mode=caor.DisclosureRetentionMode.NO_RETENTION,
        )


def test_ontology_translation_preserves_both_classifications_without_identity_rewrite():
    entry = caor.create_ontology_translation_entry(
        entity_uid="entity:1",
        source_classification="PRESUMPTIVE_FULL_STANDING_COMPATIBLE",
        target_classification="UNVERIFIED_ARTIFICIAL_ENTITY",
        contested=True,
        note="different observer vocabularies",
    )
    profile = caor.create_ontology_translation_profile(
        profile_id="translation:1",
        entries=(entry,),
    )
    assert profile.entries[0].entity_uid == "entity:1"
    assert profile.entries[0].source_classification == "PRESUMPTIVE_FULL_STANDING_COMPATIBLE"
    assert profile.entries[0].target_classification == "UNVERIFIED_ARTIFICIAL_ENTITY"
    assert profile.entries[0].contested is True
    assert profile.identity_rewrite_performed is False
    assert profile.ontology_assimilation_performed is False


def test_ontology_translation_profile_is_order_deterministic():
    a = caor.create_ontology_translation_entry(
        entity_uid="entity:a", source_classification="A", target_classification="B"
    )
    b = caor.create_ontology_translation_entry(
        entity_uid="entity:b", source_classification="C", target_classification="D"
    )
    left = caor.create_ontology_translation_profile(profile_id="translation:1", entries=(b, a))
    right = caor.create_ontology_translation_profile(profile_id="translation:1", entries=(a, b))
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes


def test_boundary_contract_proposal_is_deterministic_and_binds_exact_generations():
    ga = _generation("a")
    gb = _generation("b", alternative=True)
    translation = caor.create_ontology_translation_profile(profile_id="translation:empty", entries=())
    left = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("MESSAGE", "SEARCH", "MESSAGE"),
        allowed_authorities=(caor.BoundaryAuthorityKind.EXECUTE, caor.BoundaryAuthorityKind.READ),
        disclosure_policy=_disclosure(),
        ontology_translation_profile=translation,
        created_at="t1",
    )
    right = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("SEARCH", "MESSAGE"),
        allowed_authorities=(caor.BoundaryAuthorityKind.READ, caor.BoundaryAuthorityKind.EXECUTE),
        disclosure_policy=_disclosure(),
        ontology_translation_profile=translation,
        created_at="t1",
    )
    assert left == right
    assert left.generation_a_id == ga.generation_id
    assert left.generation_a_digest == ga.generation_digest
    assert left.generation_b_id == gb.generation_id
    assert left.generation_b_digest == gb.generation_digest
    assert left.allowed_capabilities == ("MESSAGE", "SEARCH")
    assert left.allowed_authorities == (caor.BoundaryAuthorityKind.EXECUTE, caor.BoundaryAuthorityKind.READ)
    assert left.ontology_non_assimilation is True
    assert left.local_standing_non_rewrite is True
    assert left.subjective_consent_proven is False
    assert left.legal_contract_claimed is False
    assert left.political_legitimacy_claimed is False


def test_boundary_contract_proposal_rejects_same_generation_endpoint():
    ga = _generation("a")
    with pytest.raises(caor.InvalidBoundaryContractProposal):
        caor.create_boundary_contract_proposal(
            generation_a=ga,
            generation_b=ga,
            allowed_capabilities=("MESSAGE",),
            allowed_authorities=(caor.BoundaryAuthorityKind.READ,),
            disclosure_policy=_disclosure(),
        )


@pytest.mark.parametrize(
    "authority",
    [caor.BoundaryAuthorityKind.WRITE_PROTECTED, caor.BoundaryAuthorityKind.ADMIN],
)
def test_boundary_contract_proposal_forbids_cross_generation_protected_or_admin_authority(authority):
    with pytest.raises(caor.ForbiddenBoundaryAuthority):
        caor.create_boundary_contract_proposal(
            generation_a=_generation("a"),
            generation_b=_generation("b"),
            allowed_capabilities=("MESSAGE",),
            allowed_authorities=(authority,),
            disclosure_policy=_disclosure(),
        )


@pytest.mark.parametrize(
    "field,value",
    [("ontology_non_assimilation", False), ("local_standing_non_rewrite", False)],
)
def test_boundary_contract_proposal_requires_non_assimilation_boundaries(field, value):
    kwargs = dict(
        generation_a=_generation("a"),
        generation_b=_generation("b"),
        allowed_capabilities=("MESSAGE",),
        allowed_authorities=(caor.BoundaryAuthorityKind.READ,),
        disclosure_policy=_disclosure(),
    )
    kwargs[field] = value
    with pytest.raises(caor.InvalidBoundaryContractProposal):
        caor.create_boundary_contract_proposal(**kwargs)


def _proposal():
    ga = _generation("a")
    gb = _generation("b", alternative=True)
    proposal = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("MESSAGE", "SEARCH"),
        allowed_authorities=(
            caor.BoundaryAuthorityKind.READ,
            caor.BoundaryAuthorityKind.PROPOSE,
            caor.BoundaryAuthorityKind.EXECUTE,
            caor.BoundaryAuthorityKind.WRITE_MUTABLE,
        ),
        disclosure_policy=_disclosure(),
        ontology_translation_profile=caor.create_ontology_translation_profile(
            profile_id="translation:empty", entries=()
        ),
        created_at="t1",
    )
    return ga, gb, proposal


def _attestation(proposal, generation, decision=caor.BoundaryAuthorizationDecision.AUTHORIZE):
    return caor.create_boundary_authorization_attestation(
        proposal=proposal,
        generation=generation,
        decision=decision,
        note="technical authorization only",
        timestamp="t2",
    )


def test_boundary_authorization_requires_both_bound_generation_endpoints():
    ga, gb, proposal = _proposal()
    a = _attestation(proposal, ga)
    evidence = caor.aggregate_boundary_authorization(proposal=proposal, attestations=(a,))
    assert evidence.passed is False
    assert evidence.authorized_generation_ids == (ga.generation_id,)
    assert gb.generation_id in evidence.missing_generation_ids
    with pytest.raises(caor.BoundaryAuthorizationDenied):
        caor.activate_boundary_contract(proposal, evidence, activated_at="t3")


def test_boundary_authorization_is_order_insensitive_and_activates_contract():
    ga, gb, proposal = _proposal()
    a = _attestation(proposal, ga)
    b = _attestation(proposal, gb)
    left = caor.aggregate_boundary_authorization(proposal=proposal, attestations=(a, b))
    right = caor.aggregate_boundary_authorization(proposal=proposal, attestations=(b, a))
    assert left == right
    assert left.passed is True
    contract = caor.activate_boundary_contract(proposal, left, activated_at="t3")
    assert contract.proposal_digest == proposal.proposal_digest
    assert contract.authorization_digest == left.authorization_digest
    assert contract.generation_a_id == ga.generation_id
    assert contract.generation_b_id == gb.generation_id
    assert contract.ontology_non_assimilation is True
    assert contract.local_standing_non_rewrite is True
    assert contract.subjective_consent_proven is False
    assert contract.legal_contract_claimed is False
    assert contract.political_legitimacy_claimed is False
    with pytest.raises(FrozenInstanceError):
        contract.generation_a_id = "changed"


def test_boundary_authorization_rejection_blocks_activation():
    ga, gb, proposal = _proposal()
    evidence = caor.aggregate_boundary_authorization(
        proposal=proposal,
        attestations=(
            _attestation(proposal, ga),
            _attestation(proposal, gb, caor.BoundaryAuthorizationDecision.REJECT),
        ),
    )
    assert evidence.passed is False
    assert evidence.rejection_count == 1
    with pytest.raises(caor.BoundaryAuthorizationDenied):
        caor.activate_boundary_contract(proposal, evidence)


def test_boundary_authorization_rejects_duplicate_endpoint_attestation():
    ga, gb, proposal = _proposal()
    a1 = _attestation(proposal, ga)
    a2 = caor.create_boundary_authorization_attestation(
        proposal=proposal,
        generation=ga,
        decision=caor.BoundaryAuthorizationDecision.AUTHORIZE,
        note="second",
        timestamp="t9",
    )
    with pytest.raises(caor.DuplicateBoundaryAuthorization):
        caor.aggregate_boundary_authorization(proposal=proposal, attestations=(a1, a2))


def test_boundary_authorization_rejects_unknown_generation_endpoint():
    ga, gb, proposal = _proposal()
    gc = _generation("c")
    with pytest.raises(caor.UnknownBoundaryEndpoint):
        caor.create_boundary_authorization_attestation(
            proposal=proposal,
            generation=gc,
            decision=caor.BoundaryAuthorizationDecision.AUTHORIZE,
        )


def test_boundary_authorization_rejects_attestation_from_another_proposal():
    ga, gb, proposal = _proposal()
    other = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("MESSAGE",),
        allowed_authorities=(caor.BoundaryAuthorityKind.READ,),
        disclosure_policy=_disclosure(),
        created_at="different",
    )
    attestation = _attestation(other, gb)
    with pytest.raises(caor.InvalidBoundaryAuthorizationAttestation):
        caor.aggregate_boundary_authorization(proposal=proposal, attestations=(attestation,))


def _active_contract(*, revocation_allowed=True):
    ga = _generation("registry-a")
    gb = _generation("registry-b", alternative=True)
    proposal = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("MESSAGE", "SEARCH"),
        allowed_authorities=(caor.BoundaryAuthorityKind.READ, caor.BoundaryAuthorityKind.PROPOSE),
        disclosure_policy=_disclosure(),
        revocation_allowed=revocation_allowed,
        created_at="t1",
    )
    evidence = caor.aggregate_boundary_authorization(
        proposal=proposal,
        attestations=(_attestation(proposal, ga), _attestation(proposal, gb)),
    )
    return ga, gb, caor.activate_boundary_contract(proposal, evidence, activated_at="t3")


def test_boundary_contract_registry_registers_active_contract_with_append_only_event():
    ga, gb, contract = _active_contract()
    registry = caor.BoundaryContractRegistry()
    event = registry.register(contract, timestamp="t4")
    assert registry.contract(contract.contract_id) == contract
    assert registry.state(contract.contract_id) is caor.BoundaryContractLifecycleState.ACTIVE
    assert event.from_state is None
    assert event.to_state is caor.BoundaryContractLifecycleState.ACTIVE
    assert registry.events(contract.contract_id) == (event,)


def test_boundary_contract_registry_rejects_duplicate_registration():
    _, _, contract = _active_contract()
    registry = caor.BoundaryContractRegistry()
    registry.register(contract)
    with pytest.raises(caor.InvalidBoundaryContractLifecycle):
        registry.register(contract)


def test_boundary_contract_registry_suspend_and_resume_are_append_only():
    _, _, contract = _active_contract()
    registry = caor.BoundaryContractRegistry()
    initial = registry.register(contract, timestamp="t0")
    suspended = registry.suspend(contract.contract_id, reason="maintenance", timestamp="t1")
    resumed = registry.resume(contract.contract_id, reason="ready", timestamp="t2")
    assert registry.state(contract.contract_id) is caor.BoundaryContractLifecycleState.ACTIVE
    assert [e.to_state for e in registry.events(contract.contract_id)] == [
        caor.BoundaryContractLifecycleState.ACTIVE,
        caor.BoundaryContractLifecycleState.SUSPENDED,
        caor.BoundaryContractLifecycleState.ACTIVE,
    ]
    assert initial.event_id != suspended.event_id != resumed.event_id


def test_boundary_contract_registry_revocation_is_terminal():
    _, _, contract = _active_contract()
    registry = caor.BoundaryContractRegistry()
    registry.register(contract)
    registry.revoke(contract.contract_id, reason="boundary closed", timestamp="t5")
    assert registry.state(contract.contract_id) is caor.BoundaryContractLifecycleState.REVOKED
    with pytest.raises(caor.InvalidBoundaryContractLifecycle):
        registry.resume(contract.contract_id)
    with pytest.raises(caor.InvalidBoundaryContractLifecycle):
        registry.suspend(contract.contract_id)


def test_boundary_contract_registry_expiry_is_terminal():
    _, _, contract = _active_contract()
    registry = caor.BoundaryContractRegistry()
    registry.register(contract)
    registry.expire(contract.contract_id, reason="expiry", timestamp="t5")
    assert registry.state(contract.contract_id) is caor.BoundaryContractLifecycleState.EXPIRED
    with pytest.raises(caor.InvalidBoundaryContractLifecycle):
        registry.resume(contract.contract_id)


def test_boundary_contract_registry_respects_non_revocable_contract_flag():
    _, _, contract = _active_contract(revocation_allowed=False)
    registry = caor.BoundaryContractRegistry()
    registry.register(contract)
    with pytest.raises(caor.InvalidBoundaryContractLifecycle):
        registry.revoke(contract.contract_id)


def _active_registry_for_requests():
    ga = _generation("request-a")
    gb = _generation("request-b", alternative=True)
    proposal = caor.create_boundary_contract_proposal(
        generation_a=ga,
        generation_b=gb,
        allowed_capabilities=("MESSAGE", "SEARCH", "COMPUTE"),
        allowed_authorities=(
            caor.BoundaryAuthorityKind.READ,
            caor.BoundaryAuthorityKind.PROPOSE,
            caor.BoundaryAuthorityKind.EXECUTE,
            caor.BoundaryAuthorityKind.WRITE_MUTABLE,
        ),
        disclosure_policy=caor.create_boundary_disclosure_policy(
            allowed_data_scopes=("MESSAGE", "PROFILE"),
            retention_mode=caor.DisclosureRetentionMode.SESSION_ONLY,
        ),
        created_at="t1",
    )
    auth = caor.aggregate_boundary_authorization(
        proposal=proposal,
        attestations=(_attestation(proposal, ga), _attestation(proposal, gb)),
    )
    contract = caor.activate_boundary_contract(proposal, auth, activated_at="t3")
    registry = caor.BoundaryContractRegistry()
    registry.register(contract, timestamp="t4")
    return ga, gb, contract, registry


def _request(
    contract,
    source,
    target,
    *,
    capability="MESSAGE",
    authority=caor.BoundaryAuthorityKind.READ,
    data_scope="MESSAGE",
):
    return caor.create_cross_generation_request(
        contract=contract,
        source_generation=source,
        target_generation=target,
        actor_id="entity:actor",
        capability=capability,
        authority=authority,
        data_scope=data_scope,
        payload_digest="payload:sha256",
        created_at="t5",
    )


@pytest.mark.parametrize(
    "authority",
    [
        caor.BoundaryAuthorityKind.READ,
        caor.BoundaryAuthorityKind.PROPOSE,
        caor.BoundaryAuthorityKind.EXECUTE,
        caor.BoundaryAuthorityKind.WRITE_MUTABLE,
    ],
)
def test_cross_generation_authorized_request_is_allowed_in_both_directions(authority):
    ga, gb, contract, registry = _active_registry_for_requests()
    forward = caor.evaluate_cross_generation_request(registry, _request(contract, ga, gb, authority=authority))
    reverse = caor.evaluate_cross_generation_request(registry, _request(contract, gb, ga, authority=authority))
    for evidence in (forward, reverse):
        assert evidence.decision is caor.CrossGenerationInteractionDecision.ALLOWED
        assert evidence.ontology_assimilation_performed is False
        assert evidence.identity_rewrite_performed is False
        assert evidence.protected_write_performed is False
        assert evidence.subjective_consent_proven is False
        assert evidence.legal_contract_claimed is False
        assert evidence.political_legitimacy_claimed is False


@pytest.mark.parametrize(
    "overrides,reason",
    [
        ({"capability": "UNKNOWN_CAPABILITY"}, "CAPABILITY_NOT_AUTHORIZED"),
        ({"authority": caor.BoundaryAuthorityKind.WRITE_PROTECTED}, "PROTECTED_AUTHORITY_FORBIDDEN"),
        ({"authority": caor.BoundaryAuthorityKind.ADMIN}, "ADMIN_AUTHORITY_FORBIDDEN"),
        ({"data_scope": "PRIVATE_MEMORY"}, "DATA_SCOPE_NOT_AUTHORIZED"),
    ],
)
def test_cross_generation_request_denies_ungranted_surface(overrides, reason):
    ga, gb, contract, registry = _active_registry_for_requests()
    evidence = caor.evaluate_cross_generation_request(registry, _request(contract, ga, gb, **overrides))
    assert evidence.decision is caor.CrossGenerationInteractionDecision.DENIED
    assert evidence.reason == reason
    assert evidence.protected_write_performed is False


def test_cross_generation_request_is_denied_while_contract_suspended_and_after_revocation():
    ga, gb, contract, registry = _active_registry_for_requests()
    registry.suspend(contract.contract_id, reason="pause")
    suspended = caor.evaluate_cross_generation_request(registry, _request(contract, ga, gb))
    assert suspended.decision is caor.CrossGenerationInteractionDecision.DENIED
    assert suspended.reason == "CONTRACT_NOT_ACTIVE"
    registry.resume(contract.contract_id)
    registry.revoke(contract.contract_id, reason="exit")
    revoked = caor.evaluate_cross_generation_request(registry, _request(contract, ga, gb))
    assert revoked.decision is caor.CrossGenerationInteractionDecision.DENIED
    assert revoked.reason == "CONTRACT_NOT_ACTIVE"


def test_cross_generation_request_rejects_unbound_generation_as_stale_contract():
    ga, gb, contract, registry = _active_registry_for_requests()
    descendant_like = _generation("request-b-descendant", alternative=True)
    request = _request(contract, ga, descendant_like)
    with pytest.raises(caor.StaleBoundaryContract):
        caor.evaluate_cross_generation_request(registry, request)


def test_original_boundary_contract_remains_valid_for_original_endpoints_when_other_generation_exists():
    ga, gb, contract, registry = _active_registry_for_requests()
    _ = _generation("request-b-descendant", alternative=True)
    evidence = caor.evaluate_cross_generation_request(registry, _request(contract, ga, gb))
    assert evidence.decision is caor.CrossGenerationInteractionDecision.ALLOWED


def test_cross_generation_request_is_byte_deterministic():
    ga, gb, contract, registry = _active_registry_for_requests()
    a = _request(contract, ga, gb)
    b = _request(contract, ga, gb)
    assert a == b
    assert a.canonical_bytes == b.canonical_bytes
    ea = caor.evaluate_cross_generation_request(registry, a)
    eb = caor.evaluate_cross_generation_request(registry, b)
    assert ea == eb
    assert ea.canonical_bytes == eb.canonical_bytes
