from dataclasses import FrozenInstanceError

import pytest
import caor


def noop_policy(policy_id="policy:base"):
    return caor.DecisionPolicy(
        policy_id=policy_id,
        candidates=(
            caor.DecisionCandidate(
                candidate_id="wait",
                action=caor.DecisionAction(caor.DecisionActionKind.NO_OP),
            ),
        ),
    )


def test_policy_digest_is_deterministic_and_public():
    policy = noop_policy()

    left = caor.decision_policy_digest(policy)
    right = caor.decision_policy_digest(noop_policy())

    assert left == right
    assert len(left) == 64


def test_initial_policy_version_is_immutable_and_deterministic():
    policy = noop_policy()

    left = caor.create_initial_policy_version(policy, created_at="t0")
    right = caor.create_initial_policy_version(noop_policy(), created_at="t0")

    assert isinstance(left, caor.PolicyVersion)
    assert left == right
    assert left.version_number == 1
    assert left.parent_version_id is None
    assert left.parent_policy_digest is None
    assert left.adopted_from_proposal_id is None
    assert left.policy_digest == caor.decision_policy_digest(policy)
    assert left.canonical_bytes == right.canonical_bytes
    with pytest.raises(FrozenInstanceError):
        left.version_number = 99


def make_manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", 0.4, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a1", "logic", 0.8, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
    ))


def evolved_policy():
    return caor.DecisionPolicy(
        policy_id="policy:evolved",
        candidates=(
            caor.DecisionCandidate(
                "reflect",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="reflection", value=True),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def history_trigger_template():
    return caor.PolicyEvolutionTemplate(
        template_id="template:reflect-after-two-updates",
        trigger_conditions=(
            caor.DecisionCondition(
                caor.DecisionSignalKind.HISTORY_COUNT,
                "SELF_UPDATE",
                caor.DecisionOperator.GTE,
                2,
            ),
        ),
        proposed_policy=evolved_policy(),
        rationale={"reason": "reflect after repeated self updates"},
    )


def test_policy_change_proposal_is_not_emitted_before_trigger_matches():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "evolution-trigger-before")
    entity = caor.OffspringEntity(ois)
    version = caor.create_initial_policy_version(noop_policy(), created_at="t0")
    context = caor.build_decision_context(ois, manifest, entity.development_events, {})

    proposal = caor.generate_policy_change_proposal(
        ois.offspring_uid,
        version,
        context,
        history_trigger_template(),
    )

    assert proposal is None


def test_history_trigger_emits_byte_deterministic_policy_change_proposal_with_firewall_flags():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "evolution-trigger-after")
    entity = caor.OffspringEntity(ois)
    entity.self_update("notes", "a", 1, timestamp="t1")
    entity.self_update("notes", "b", 2, timestamp="t2")
    version = caor.create_initial_policy_version(noop_policy(), created_at="t0")
    context = caor.build_decision_context(ois, manifest, entity.development_events, {"phase": "growth"})
    template = history_trigger_template()

    left = caor.generate_policy_change_proposal(ois.offspring_uid, version, context, template)
    right = caor.generate_policy_change_proposal(ois.offspring_uid, version, context, history_trigger_template())

    assert isinstance(left, caor.PolicyChangeProposal)
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert left.base_version_id == version.version_id
    assert left.base_policy_digest == version.policy_digest
    assert left.context_digest == context.context_digest
    assert left.development_digest == context.development_digest
    assert left.proposed_policy_digest == caor.decision_policy_digest(template.proposed_policy)
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False


def proposal_for_policy(proposed_policy):
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "constitution-proposal")
    version = caor.create_initial_policy_version(noop_policy(), created_at="t0")
    context = caor.build_decision_context(ois, manifest, (), {})
    template = caor.PolicyEvolutionTemplate(
        template_id="template:constitution",
        trigger_conditions=(),
        proposed_policy=proposed_policy,
        rationale={"reason": "constitution test"},
    )
    return caor.generate_policy_change_proposal(ois.offspring_uid, version, context, template)


def default_constitution(**overrides):
    values = dict(
        constitution_id="constitution:caor-v0.5",
        constitution_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=32,
        min_score_term=-1000.0,
        max_score_term=1000.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )
    values.update(overrides)
    return caor.create_policy_constitution(**values)


def test_constitutional_review_passes_valid_proposal_and_is_byte_deterministic():
    proposal = proposal_for_policy(evolved_policy())
    constitution = default_constitution()

    left = caor.review_policy_proposal(proposal, constitution)
    right = caor.review_policy_proposal(proposal, default_constitution())

    assert isinstance(left, caor.ConstitutionalReviewEvidence)
    assert left.passed is True
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert all(result.passed for result in left.rule_results)
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False


def test_constitution_rejects_policy_without_required_noop_candidate():
    proposal = proposal_for_policy(
        caor.DecisionPolicy(
            policy_id="policy:no-noop",
            candidates=(
                caor.DecisionCandidate(
                    "change",
                    caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="x", value=1),
                ),
            ),
        )
    )

    review = caor.review_policy_proposal(proposal, default_constitution())
    rules = {result.rule_id: result for result in review.rule_results}

    assert review.passed is False
    assert rules["REQUIRED_NO_OP"].passed is False


def test_constitution_rejects_candidate_count_and_score_bounds_and_forbidden_action():
    candidates = tuple(
        caor.DecisionCandidate(f"c{i}", caor.DecisionAction(caor.DecisionActionKind.NO_OP))
        for i in range(3)
    )
    too_many = proposal_for_policy(caor.DecisionPolicy("policy:too-many", candidates))
    review_many = caor.review_policy_proposal(too_many, default_constitution(max_candidate_count=2))
    rules_many = {result.rule_id: result for result in review_many.rule_results}
    assert rules_many["MAX_CANDIDATE_COUNT"].passed is False

    score_policy = caor.DecisionPolicy(
        "policy:score-out-of-range",
        (
            caor.DecisionCandidate(
                "change",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="x", value=1),
                score_terms=(
                    caor.DecisionScoreTerm(
                        caor.DecisionCondition(caor.DecisionSignalKind.HISTORY_TOTAL, "", caor.DecisionOperator.GTE, 0),
                        50.0,
                        -50.0,
                    ),
                ),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )
    review_score = caor.review_policy_proposal(proposal_for_policy(score_policy), default_constitution(min_score_term=-10, max_score_term=10))
    rules_score = {result.rule_id: result for result in review_score.rule_results}
    assert rules_score["SCORE_BOUNDS"].passed is False

    review_action = caor.review_policy_proposal(
        proposal_for_policy(evolved_policy()),
        default_constitution(allowed_action_kinds=(caor.DecisionActionKind.NO_OP,)),
    )
    rules_action = {result.rule_id: result for result in review_action.rule_results}
    assert rules_action["ALLOWED_ACTION_KINDS"].passed is False


def proposal_for_context(offspring_uid, version, context, proposed_policy, template_id="template:adopt"):
    template = caor.PolicyEvolutionTemplate(
        template_id=template_id,
        trigger_conditions=(),
        proposed_policy=proposed_policy,
        rationale={"reason": template_id},
    )
    return caor.generate_policy_change_proposal(offspring_uid, version, context, template)


def test_validation_cases_are_deterministic_and_can_assert_expected_candidate():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "validation-deterministic")
    version = caor.create_initial_policy_version(noop_policy(), created_at="t0")
    context = caor.build_decision_context(ois, manifest, (), {})
    proposal = proposal_for_context(ois.offspring_uid, version, context, evolved_policy())
    case = caor.PolicyValidationCase("case:reflect", context, expected_candidate_id="reflect")

    left = caor.validate_proposed_policy(proposal, (case,))
    right = caor.validate_proposed_policy(proposal, (case,))

    assert left == right
    assert left[0].passed is True
    assert left[0].selected_candidate_id == "reflect"
    assert left[0].selection_digest
    assert left[0].canonical_bytes == right[0].canonical_bytes


def test_validation_expected_candidate_mismatch_is_evidence_failure_not_policy_mutation():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "validation-mismatch")
    version = caor.create_initial_policy_version(noop_policy(), created_at="t0")
    context = caor.build_decision_context(ois, manifest, (), {})
    proposal = proposal_for_context(ois.offspring_uid, version, context, evolved_policy())

    evidence = caor.validate_proposed_policy(
        proposal,
        (caor.PolicyValidationCase("case:mismatch", context, expected_candidate_id="wait"),),
    )[0]

    assert evidence.passed is False
    assert evidence.selected_candidate_id == "reflect"
    assert evidence.error_type == "EXPECTED_CANDIDATE_MISMATCH"


def test_successful_adoption_creates_new_immutable_version_and_preserves_old_version():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "adopt-success")
    context = caor.build_decision_context(ois, manifest, (), {})
    registry = caor.PolicyRegistry(ois.offspring_uid)
    v1 = registry.initialize(noop_policy(), created_at="t0")
    proposal = proposal_for_context(ois.offspring_uid, v1, context, evolved_policy())
    review = caor.review_policy_proposal(proposal, default_constitution())
    validations = caor.validate_proposed_policy(
        proposal,
        (caor.PolicyValidationCase("case:reflect", context, expected_candidate_id="reflect"),),
    )

    registry.record_proposal(proposal)
    registry.record_review(review)
    v2 = registry.adopt(proposal, review, validations, timestamp="t1")

    assert registry.active_version == v2
    assert v2.version_number == 2
    assert v2.parent_version_id == v1.version_id
    assert v2.parent_policy_digest == v1.policy_digest
    assert v2.adopted_from_proposal_id == proposal.proposal_id
    assert registry.get_version(v1.version_id) == v1
    assert registry.get_version(v1.version_id).canonical_bytes == v1.canonical_bytes
    assert len(registry.versions) == 2
    assert registry.adoptions[-1].status == "ADOPTED"
    assert registry.adoptions[-1].subjectivity_claimed is False
    assert registry.adoptions[-1].free_will_claimed is False
    assert registry.adoptions[-1].autonomy_claimed is False


def test_failed_constitution_or_validation_leaves_active_policy_unchanged():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "adopt-denied")
    context = caor.build_decision_context(ois, manifest, (), {})
    registry = caor.PolicyRegistry(ois.offspring_uid)
    v1 = registry.initialize(noop_policy(), created_at="t0")

    no_noop = caor.DecisionPolicy(
        "policy:no-noop-adopt",
        (
            caor.DecisionCandidate(
                "change",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="x", value=1),
            ),
        ),
    )
    bad_proposal = proposal_for_context(ois.offspring_uid, v1, context, no_noop, "template:bad-constitution")
    bad_review = caor.review_policy_proposal(bad_proposal, default_constitution())
    bad_validations = caor.validate_proposed_policy(
        bad_proposal,
        (caor.PolicyValidationCase("case:change", context, expected_candidate_id="change"),),
    )
    with pytest.raises(caor.PolicyAdoptionDenied):
        registry.adopt(bad_proposal, bad_review, bad_validations, timestamp="t1")
    assert registry.active_version == v1
    assert len(registry.versions) == 1

    good_proposal = proposal_for_context(ois.offspring_uid, v1, context, evolved_policy(), "template:bad-validation")
    good_review = caor.review_policy_proposal(good_proposal, default_constitution())
    failed_validation = caor.validate_proposed_policy(
        good_proposal,
        (caor.PolicyValidationCase("case:wrong", context, expected_candidate_id="wait"),),
    )
    with pytest.raises(caor.PolicyAdoptionDenied):
        registry.adopt(good_proposal, good_review, failed_validation, timestamp="t1")
    assert registry.active_version == v1
    assert len(registry.versions) == 1


def test_stale_base_policy_proposal_cannot_be_adopted_after_active_version_changes():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "adopt-stale")
    context = caor.build_decision_context(ois, manifest, (), {})
    registry = caor.PolicyRegistry(ois.offspring_uid)
    v1 = registry.initialize(noop_policy(), created_at="t0")

    stale_proposal = proposal_for_context(ois.offspring_uid, v1, context, evolved_policy(), "template:stale")

    first_policy = caor.DecisionPolicy(
        "policy:first-adopt",
        (
            caor.DecisionCandidate("alpha", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )
    first_proposal = proposal_for_context(ois.offspring_uid, v1, context, first_policy, "template:first")
    first_review = caor.review_policy_proposal(first_proposal, default_constitution())
    first_validations = caor.validate_proposed_policy(
        first_proposal,
        (caor.PolicyValidationCase("case:first", context, expected_candidate_id="alpha"),),
    )
    v2 = registry.adopt(first_proposal, first_review, first_validations, timestamp="t1")
    assert registry.active_version == v2

    stale_review = caor.review_policy_proposal(stale_proposal, default_constitution())
    stale_validations = caor.validate_proposed_policy(
        stale_proposal,
        (caor.PolicyValidationCase("case:stale", context, expected_candidate_id="reflect"),),
    )
    with pytest.raises(caor.StalePolicyProposal):
        registry.adopt(stale_proposal, stale_review, stale_validations, timestamp="t2")
    assert registry.active_version == v2
    assert len(registry.versions) == 2


def test_reversion_to_prior_policy_content_creates_new_version_instead_of_mutating_history():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "reversion-version-lineage")
    context = caor.build_decision_context(ois, manifest, (), {})
    registry = caor.PolicyRegistry(ois.offspring_uid)
    v1 = registry.initialize(noop_policy(), created_at="t0")

    p2 = proposal_for_context(ois.offspring_uid, v1, context, evolved_policy(), "template:to-v2")
    r2 = caor.review_policy_proposal(p2, default_constitution())
    val2 = caor.validate_proposed_policy(
        p2,
        (caor.PolicyValidationCase("case:v2", context, expected_candidate_id="reflect"),),
    )
    v2 = registry.adopt(p2, r2, val2, timestamp="t1")

    p3 = proposal_for_context(ois.offspring_uid, v2, context, noop_policy(), "template:revert-to-v1-content")
    r3 = caor.review_policy_proposal(p3, default_constitution())
    val3 = caor.validate_proposed_policy(
        p3,
        (caor.PolicyValidationCase("case:v3", context, expected_candidate_id="wait"),),
    )
    v3 = registry.adopt(p3, r3, val3, timestamp="t2")

    assert v3.version_number == 3
    assert v3.version_id != v1.version_id
    assert v3.policy_digest == v1.policy_digest
    assert v3.parent_version_id == v2.version_id
    assert registry.get_version(v1.version_id) == v1
    assert registry.get_version(v2.version_id) == v2
    assert len(registry.versions) == 3
