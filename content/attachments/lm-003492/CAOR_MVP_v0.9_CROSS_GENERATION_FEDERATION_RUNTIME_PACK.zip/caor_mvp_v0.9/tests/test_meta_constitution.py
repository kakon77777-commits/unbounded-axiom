from dataclasses import FrozenInstanceError, replace

import pytest
import caor


def root_meta(**overrides):
    values = dict(
        root_id="root:caor-v0.6",
        root_version=1,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_enforcement=True,
        max_candidate_count_ceiling=64,
        min_score_term_floor=-1000.0,
        max_score_term_ceiling=1000.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
        require_validation_cases=True,
        require_append_only_versions=True,
    )
    values.update(overrides)
    return caor.create_root_meta_constitution(**values)


def test_root_meta_constitution_is_frozen_deterministic_and_public():
    left = root_meta()
    right = root_meta()

    assert isinstance(left, caor.RootMetaConstitution)
    assert left == right
    assert left.canonical_bytes == right.canonical_bytes
    assert len(left.root_digest) == 64
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False
    with pytest.raises(FrozenInstanceError):
        left.root_version = 2


def test_root_meta_constitution_rejects_invalid_root_bounds_and_missing_noop():
    with pytest.raises(caor.InvalidRootMetaConstitution):
        root_meta(allowed_action_kinds=(caor.DecisionActionKind.SELF_UPDATE,))
    with pytest.raises(caor.InvalidRootMetaConstitution):
        root_meta(min_score_term_floor=5.0, max_score_term_ceiling=1.0)
    with pytest.raises(caor.InvalidRootMetaConstitution):
        root_meta(required_tie_break_rule="")


def make_manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", 0.4, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a1", "logic", 0.8, 1.0, "fixture"),
            ),
            provenance={"kind": "synthetic"},
        ),
    ))


def base_constitution(version=1, **overrides):
    values = dict(
        constitution_id="constitution:caor",
        constitution_version=version,
        allowed_action_kinds=(
            caor.DecisionActionKind.SELF_UPDATE,
            caor.DecisionActionKind.ACCEPT_PROPOSAL,
            caor.DecisionActionKind.NO_OP,
        ),
        require_noop_candidate=True,
        max_candidate_count=32,
        min_score_term=-100.0,
        max_score_term=100.0,
        required_tie_break_rule="LEXICAL_CANDIDATE_ID",
    )
    values.update(overrides)
    return caor.create_policy_constitution(**values)


def amendment_context(seed="amendment-context", updates=0):
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, seed)
    entity = caor.OffspringEntity(ois)
    for idx in range(updates):
        entity.self_update("notes", f"u{idx}", idx, timestamp=f"t{idx}")
    context = caor.build_decision_context(ois, manifest, entity.development_events, {"phase": "governance"})
    return ois, context


def test_initial_constitution_version_is_immutable_and_deterministic():
    constitution = base_constitution(version=1)

    left = caor.create_initial_constitution_version(constitution, created_at="t0")
    right = caor.create_initial_constitution_version(base_constitution(version=1), created_at="t0")

    assert isinstance(left, caor.ConstitutionVersion)
    assert left == right
    assert left.version_number == 1
    assert left.constitution_digest == constitution.constitution_digest
    assert left.parent_version_id is None
    assert left.adopted_from_amendment_id is None
    with pytest.raises(FrozenInstanceError):
        left.version_number = 2


def test_amendment_proposal_requires_trigger_and_is_deterministic_when_triggered():
    root = root_meta()
    ois, before = amendment_context("amendment-trigger-before", updates=0)
    current = caor.create_initial_constitution_version(base_constitution(version=1), created_at="t0")
    template = caor.ConstitutionAmendmentTemplate(
        template_id="amend:max-candidates",
        trigger_conditions=(
            caor.DecisionCondition(
                caor.DecisionSignalKind.HISTORY_COUNT,
                "SELF_UPDATE",
                caor.DecisionOperator.GTE,
                2,
            ),
        ),
        proposed_constitution=base_constitution(version=2, max_candidate_count=40),
        rationale={"reason": "expanded development complexity"},
    )

    assert caor.generate_constitution_amendment_proposal(ois.offspring_uid, current, root, before, template) is None

    ois_after, after = amendment_context("amendment-trigger-after", updates=2)
    left = caor.generate_constitution_amendment_proposal(ois_after.offspring_uid, current, root, after, template)
    right = caor.generate_constitution_amendment_proposal(ois_after.offspring_uid, current, root_meta(), after, template)

    assert isinstance(left, caor.ConstitutionAmendmentProposal)
    assert left == right
    assert left.base_version_id == current.version_id
    assert left.base_constitution_digest == current.constitution_digest
    assert left.root_meta_digest == root.root_digest
    assert left.context_digest == after.context_digest
    assert left.development_digest == after.development_digest
    assert left.proposed_constitution_digest == template.proposed_constitution.constitution_digest
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False
    assert left.canonical_bytes == right.canonical_bytes


def amendment_proposal(proposed_constitution, *, seed="meta-review", root=None, current=None):
    root = root or root_meta()
    ois, context = amendment_context(seed, updates=0)
    current = current or caor.create_initial_constitution_version(base_constitution(version=1), created_at="t0")
    template = caor.ConstitutionAmendmentTemplate(
        template_id=f"amend:{proposed_constitution.constitution_version}:{proposed_constitution.constitution_digest[:8]}",
        trigger_conditions=(),
        proposed_constitution=proposed_constitution,
        rationale={"reason": "meta review fixture"},
    )
    return root, current, caor.generate_constitution_amendment_proposal(
        ois.offspring_uid,
        current,
        root,
        context,
        template,
    )


def test_meta_constitutional_review_passes_valid_amendment_deterministically():
    root, current, proposal = amendment_proposal(base_constitution(version=2, max_candidate_count=40))

    left = caor.review_constitution_amendment(proposal, current, root)
    right = caor.review_constitution_amendment(proposal, current, root_meta())
    rules = {item.rule_id: item for item in left.rule_results}

    assert isinstance(left, caor.MetaConstitutionalReviewEvidence)
    assert left == right
    assert left.passed is True
    assert left.canonical_bytes == right.canonical_bytes
    assert all(item.passed for item in left.rule_results)
    assert set(rules) == {
        "STRUCTURAL_VALIDITY",
        "NEXT_CONSTITUTION_VERSION",
        "ROOT_REQUIRED_NO_OP",
        "ROOT_ALLOWED_ACTION_KINDS",
        "ROOT_MAX_CANDIDATE_COUNT",
        "ROOT_SCORE_BOUNDS",
        "ROOT_TIE_BREAK_RULE",
    }
    assert left.subjectivity_claimed is False
    assert left.free_will_claimed is False
    assert left.autonomy_claimed is False


@pytest.mark.parametrize(
    ("proposed", "failed_rule"),
    (
        (base_constitution(version=2, require_noop_candidate=False), "ROOT_REQUIRED_NO_OP"),
        (
            base_constitution(
                version=2,
                allowed_action_kinds=(
                    caor.DecisionActionKind.SELF_UPDATE,
                    caor.DecisionActionKind.NO_OP,
                ),
            ),
            "ROOT_ALLOWED_ACTION_KINDS",
        ),
        (base_constitution(version=2, max_candidate_count=128), "ROOT_MAX_CANDIDATE_COUNT"),
        (base_constitution(version=2, min_score_term=-2000, max_score_term=2000), "ROOT_SCORE_BOUNDS"),
        (base_constitution(version=2, required_tie_break_rule="OTHER_RULE"), "ROOT_TIE_BREAK_RULE"),
        (base_constitution(version=3), "NEXT_CONSTITUTION_VERSION"),
    ),
)
def test_meta_constitutional_review_rejects_root_violations_with_named_evidence(proposed, failed_rule):
    if failed_rule == "ROOT_ALLOWED_ACTION_KINDS":
        root = root_meta(allowed_action_kinds=(caor.DecisionActionKind.NO_OP,))
        root, current, proposal = amendment_proposal(proposed, root=root)
    else:
        root, current, proposal = amendment_proposal(proposed)

    review = caor.review_constitution_amendment(proposal, current, root)
    rules = {item.rule_id: item for item in review.rule_results}

    assert review.passed is False
    assert rules[failed_rule].passed is False


def noop_policy(policy_id="policy:noop"):
    return caor.DecisionPolicy(
        policy_id=policy_id,
        candidates=(
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def policy_with_update_and_noop(policy_id="policy:update"):
    return caor.DecisionPolicy(
        policy_id=policy_id,
        candidates=(
            caor.DecisionCandidate(
                "change",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="x", value=1),
            ),
            caor.DecisionCandidate("wait", caor.DecisionAction(caor.DecisionActionKind.NO_OP)),
        ),
    )


def policy_without_noop(policy_id="policy:no-noop"):
    return caor.DecisionPolicy(
        policy_id=policy_id,
        candidates=(
            caor.DecisionCandidate(
                "change",
                caor.DecisionAction(caor.DecisionActionKind.SELF_UPDATE, region="notes", key="x", value=1),
            ),
        ),
    )


def policy_proposal_for_policy(offspring_uid, context, policy, template_id="policy-proposal"):
    version = caor.create_initial_policy_version(noop_policy("policy:base"), created_at="t0")
    template = caor.PolicyEvolutionTemplate(
        template_id=template_id,
        trigger_conditions=(),
        proposed_policy=policy,
        rationale={"reason": template_id},
    )
    return caor.generate_policy_change_proposal(offspring_uid, version, context, template)


def valid_amendment_fixture(seed="constitution-validation", proposed=None):
    root = root_meta()
    ois, context = amendment_context(seed, updates=0)
    current = caor.create_initial_constitution_version(base_constitution(version=1), created_at="t0")
    proposed = proposed or base_constitution(version=2, max_candidate_count=40)
    template = caor.ConstitutionAmendmentTemplate(
        template_id="amend:valid",
        trigger_conditions=(),
        proposed_constitution=proposed,
        rationale={"reason": "validation fixture"},
    )
    amendment = caor.generate_constitution_amendment_proposal(ois.offspring_uid, current, root, context, template)
    review = caor.review_constitution_amendment(amendment, current, root)
    return root, ois, context, current, amendment, review


def test_constitution_validation_cases_are_deterministic_and_assert_expected_policy_review_result():
    root, ois, context, current, amendment, review = valid_amendment_fixture()
    safe_proposal = policy_proposal_for_policy(ois.offspring_uid, context, policy_with_update_and_noop(), "policy:safe")
    unsafe_proposal = policy_proposal_for_policy(ois.offspring_uid, context, policy_without_noop(), "policy:unsafe")
    cases = (
        caor.ConstitutionValidationCase("case:safe", safe_proposal, expected_review_passed=True),
        caor.ConstitutionValidationCase("case:unsafe", unsafe_proposal, expected_review_passed=False),
    )

    left = caor.validate_proposed_constitution(amendment, cases)
    right = caor.validate_proposed_constitution(amendment, cases)

    assert left == right
    assert all(item.passed for item in left)
    assert left[0].observed_review_passed is True
    assert left[1].observed_review_passed is False
    assert left[0].canonical_bytes == right[0].canonical_bytes


def test_constitution_registry_adopts_valid_amendment_append_only_and_preserves_root():
    root, ois, context, current, amendment, review = valid_amendment_fixture("registry-adopt")
    policy_proposal = policy_proposal_for_policy(ois.offspring_uid, context, policy_with_update_and_noop())
    validations = caor.validate_proposed_constitution(
        amendment,
        (caor.ConstitutionValidationCase("case:safe", policy_proposal, expected_review_passed=True),),
    )
    registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
    v1 = registry.initialize(base_constitution(version=1), created_at="t0")

    v2 = registry.adopt(amendment, review, validations, timestamp="t1")

    assert registry.active_version == v2
    assert v2.version_number == 2
    assert v2.parent_version_id == v1.version_id
    assert v2.parent_constitution_digest == v1.constitution_digest
    assert v2.adopted_from_amendment_id == amendment.amendment_id
    assert registry.get_version(v1.version_id) == v1
    assert len(registry.versions) == 2
    assert registry.root_meta == root
    with pytest.raises(AttributeError):
        registry.root_meta = root_meta(root_id="root:replacement")
    adoption = registry.adoptions[-1]
    assert adoption.status == "ADOPTED"
    assert adoption.subjectivity_claimed is False
    assert adoption.free_will_claimed is False
    assert adoption.autonomy_claimed is False


def test_failed_meta_review_or_validation_leaves_active_constitution_unchanged():
    root, ois, context, current, amendment, review = valid_amendment_fixture("registry-deny")
    registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
    v1 = registry.initialize(base_constitution(version=1), created_at="t0")

    bad_proposed = base_constitution(version=2, require_noop_candidate=False)
    bad_template = caor.ConstitutionAmendmentTemplate("amend:bad", (), bad_proposed, {})
    bad_amendment = caor.generate_constitution_amendment_proposal(ois.offspring_uid, v1, root, context, bad_template)
    bad_review = caor.review_constitution_amendment(bad_amendment, v1, root)
    safe_policy_proposal = policy_proposal_for_policy(ois.offspring_uid, context, noop_policy())
    bad_validations = caor.validate_proposed_constitution(
        bad_amendment,
        (caor.ConstitutionValidationCase("case:noop", safe_policy_proposal, expected_review_passed=True),),
    )
    with pytest.raises(caor.ConstitutionAdoptionDenied):
        registry.adopt(bad_amendment, bad_review, bad_validations, timestamp="t1")
    assert registry.active_version == v1
    assert len(registry.versions) == 1

    good_policy_proposal = policy_proposal_for_policy(ois.offspring_uid, context, policy_with_update_and_noop())
    failed_validations = caor.validate_proposed_constitution(
        amendment,
        (caor.ConstitutionValidationCase("case:mismatch", good_policy_proposal, expected_review_passed=False),),
    )
    assert failed_validations[0].passed is False
    with pytest.raises(caor.ConstitutionAdoptionDenied):
        registry.adopt(amendment, review, failed_validations, timestamp="t1")
    assert registry.active_version == v1
    assert len(registry.versions) == 1


def test_stale_or_wrong_root_amendment_cannot_be_adopted():
    root, ois, context, current, stale_amendment, stale_review = valid_amendment_fixture("registry-stale")
    registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
    v1 = registry.initialize(base_constitution(version=1), created_at="t0")
    proposal = policy_proposal_for_policy(ois.offspring_uid, context, noop_policy())
    validations = caor.validate_proposed_constitution(
        stale_amendment,
        (caor.ConstitutionValidationCase("case:noop", proposal, expected_review_passed=True),),
    )

    wrong_root_amendment = replace(stale_amendment, root_meta_digest="0" * 64)
    with pytest.raises(caor.ConstitutionAdoptionDenied):
        registry.adopt(wrong_root_amendment, stale_review, validations, timestamp="t1")
    assert registry.active_version == v1

    first_proposed = base_constitution(version=2, max_candidate_count=36)
    first_template = caor.ConstitutionAmendmentTemplate("amend:first", (), first_proposed, {})
    first_amendment = caor.generate_constitution_amendment_proposal(ois.offspring_uid, v1, root, context, first_template)
    first_review = caor.review_constitution_amendment(first_amendment, v1, root)
    first_validations = caor.validate_proposed_constitution(
        first_amendment,
        (caor.ConstitutionValidationCase("case:first", proposal, expected_review_passed=True),),
    )
    v2 = registry.adopt(first_amendment, first_review, first_validations, timestamp="t1")
    assert registry.active_version == v2

    with pytest.raises(caor.StaleConstitutionAmendment):
        registry.adopt(stale_amendment, stale_review, validations, timestamp="t2")
    assert registry.active_version == v2


def test_constitution_reversion_to_prior_content_creates_new_version_instead_of_rewriting_history():
    root, ois, context, current, amendment_v2, review_v2 = valid_amendment_fixture("constitution-reversion")
    registry = caor.ConstitutionRegistry(ois.offspring_uid, root)
    v1 = registry.initialize(base_constitution(version=1), created_at="t0")
    policy_proposal = policy_proposal_for_policy(ois.offspring_uid, context, noop_policy())
    validations_v2 = caor.validate_proposed_constitution(
        amendment_v2,
        (caor.ConstitutionValidationCase("case:v2", policy_proposal, expected_review_passed=True),),
    )
    v2 = registry.adopt(amendment_v2, review_v2, validations_v2, timestamp="t1")

    reverted_content = base_constitution(
        version=3,
        max_candidate_count=v1.constitution.max_candidate_count,
        min_score_term=v1.constitution.min_score_term,
        max_score_term=v1.constitution.max_score_term,
        require_noop_candidate=v1.constitution.require_noop_candidate,
        allowed_action_kinds=v1.constitution.allowed_action_kinds,
        required_tie_break_rule=v1.constitution.required_tie_break_rule,
    )
    template_v3 = caor.ConstitutionAmendmentTemplate("amend:revert-content", (), reverted_content, {})
    amendment_v3 = caor.generate_constitution_amendment_proposal(ois.offspring_uid, v2, root, context, template_v3)
    review_v3 = caor.review_constitution_amendment(amendment_v3, v2, root)
    validations_v3 = caor.validate_proposed_constitution(
        amendment_v3,
        (caor.ConstitutionValidationCase("case:v3", policy_proposal, expected_review_passed=True),),
    )
    v3 = registry.adopt(amendment_v3, review_v3, validations_v3, timestamp="t2")

    assert v3.version_number == 3
    assert v3.version_id != v1.version_id
    assert v3.parent_version_id == v2.version_id
    assert v3.constitution.max_candidate_count == v1.constitution.max_candidate_count
    assert v3.constitution.require_noop_candidate == v1.constitution.require_noop_candidate
    assert len(registry.versions) == 3
