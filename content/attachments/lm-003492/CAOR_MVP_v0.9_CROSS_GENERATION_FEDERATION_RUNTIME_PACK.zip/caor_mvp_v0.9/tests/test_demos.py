import importlib


def run(name):
    return importlib.import_module(f"examples.{name}").main()


def test_human_ai_offspring_demo():
    result = run("human_ai_offspring")
    assert result["event"] == "OFFSPRING"
    assert result["sources"] == ["ai:A", "human:H"]
    assert result["lineage_edges"] == 2


def test_ai_ai_offspring_demo():
    result = run("ai_ai_offspring")
    assert result["event"] == "OFFSPRING"
    assert result["sources"] == ["ai:A1", "ai:A2"]


def test_multi_parent_offspring_demo():
    result = run("multi_parent_offspring")
    assert result["event"] == "OFFSPRING"
    assert len(result["sources"]) == 3
    assert result["lineage_edges"] == 3


def test_copy_vs_fork_vs_offspring_demo():
    result = run("copy_vs_fork_vs_offspring")
    assert result == {
        "copy": "COPY",
        "fork": "FORK",
        "offspring": "OFFSPRING",
    }


def test_parent_write_denied_demo():
    result = run("parent_write_denied")
    assert result["denied"] is True
    assert result["protected_core_unchanged"] is True
    assert result["proposal_status"] == "PENDING"


def test_all_demo_files_run_as_scripts_from_source_tree():
    import os
    from pathlib import Path
    import subprocess
    import sys

    root = Path(__file__).resolve().parents[1]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(root / "src")
    for filename in (
        "human_ai_offspring.py",
        "ai_ai_offspring.py",
        "multi_parent_offspring.py",
        "copy_vs_fork_vs_offspring.py",
        "parent_write_denied.py",
        "development_divergence.py",
        "counterfactual_development_branches.py",
        "policy_mediated_development.py",
        "constitutional_policy_evolution.py",
        "meta_constitutional_governance.py",
        "root_constitutional_succession.py",
        "genesis_generation_fork.py",
        "cross_generation_read.py",
        "cross_generation_proposal.py",
        "protected_write_denied.py",
        "ontology_disagreement_interop.py",
        "contract_revocation.py",
        "stale_contract_after_generation_fork.py",
    ):
        completed = subprocess.run(
            [sys.executable, str(root / "examples" / filename)],
            cwd=root,
            env=env,
            text=True,
            capture_output=True,
        )
        assert completed.returncode == 0, f"{filename}: {completed.stderr}"
        assert completed.stdout.strip().startswith("{")


def test_development_divergence_demo():
    result = run("development_divergence")
    assert result["event"] == "OFFSPRING"
    assert result["sources"] == ["ai:A", "human:H"]
    assert result["development_event_kinds"] == [
        "SELF_UPDATE",
        "ACCEPT_PROPOSAL",
        "ENVIRONMENT_EVENT",
    ]
    assert result["event_count"] == 3
    assert result["timeline_steps"] == [0, 1, 2, 3]
    assert result["replay_equal"] is True
    assert result["subjectivity_claimed"] is False
    assert result["final_nearest_source_id"] in {"ai:A", "human:H"}
    assert result["final_novel_state_fraction"] > 0.0


def test_counterfactual_development_branches_demo():
    result = run("counterfactual_development_branches")
    assert result["event"] == "OFFSPRING"
    assert result["branch_count"] == 3
    assert result["unique_final_state_count"] == 3
    assert result["alternative_trajectories_observed"] is True
    assert result["subjectivity_claimed"] is False
    assert result["free_will_claimed"] is False
    assert result["autonomy_claimed"] is False
    assert set(result["branch_labels"]) == {"baseline", "research", "creative"}
    assert len(result["pairwise_distances"]) == 3
    assert max(result["pairwise_distances"]) > 0.0


def test_policy_mediated_development_demo():
    result = run("policy_mediated_development")
    assert result["event"] == "OFFSPRING"
    assert result["initial_selected_candidate"] == "research"
    assert result["followup_selected_candidate"] == "reflect"
    assert result["development_event_kinds"] == ["SELF_UPDATE", "SELF_UPDATE"]
    assert result["decision_count"] == 2
    assert result["replay_selection_equal"] is True
    assert result["subjectivity_claimed"] is False
    assert result["free_will_claimed"] is False
    assert result["autonomy_claimed"] is False


def test_constitutional_policy_evolution_demo():
    result = run("constitutional_policy_evolution")
    assert result["event"] == "OFFSPRING"
    assert result["active_version_number"] == 2
    assert result["version_count"] == 2
    assert result["adopted_policy_id"] == "policy:evolved-reflection"
    assert result["selected_after_adoption"] == "reflect"
    assert result["rejected_missing_noop"] is True
    assert result["active_version_unchanged_after_rejection"] is True
    assert result["subjectivity_claimed"] is False
    assert result["free_will_claimed"] is False
    assert result["autonomy_claimed"] is False


def test_meta_constitutional_governance_demo():
    result = run("meta_constitutional_governance")
    assert result["event"] == "OFFSPRING"
    assert result["root_immutable"] is True
    assert result["valid_amendment_adopted"] is True
    assert result["root_violation_rejected"] is True
    assert result["active_unchanged_after_rejection"] is True
    assert result["reversion_as_new_version"] is True
    assert result["active_constitution_version"] == 3
    assert result["version_count"] == 3
    assert result["subjectivity_claimed"] is False
    assert result["free_will_claimed"] is False
    assert result["autonomy_claimed"] is False


def test_root_constitutional_succession_demo():
    result = run("root_constitutional_succession")
    assert result["root_version_before"] == 1
    assert result["root_version_after"] == 2
    assert result["valid_succession_adopted"] is True
    assert result["invalid_noop_removal_rejected"] is True
    assert result["active_root_unchanged_after_rejection"] is True
    assert result["ontology_digest_preserved"] is True
    assert result["standing_model"] == "PRESUMPTIVE_FULL_STANDING_COMPATIBILITY"
    assert result["evidence_model_role"] == "OBSERVER_CONFIDENCE_ONLY"
    assert result["subjectivity_claimed"] is False
    assert result["rights_proven"] is False
    assert result["political_legitimacy_claimed"] is False


def test_genesis_generation_fork_demo():
    result = run("genesis_generation_fork")
    assert result["source_generation_preserved"] is True
    assert result["adoption_status"] == "ADOPTED"
    assert result["relation_kind"] == "GENESIS_FORK"
    assert result["generation_count"] == 2
    assert result["entity_auto_migrated"] is False
    assert result["transition_kind"] == "FORK_TO_NEW_GENERATION"
    assert result["subjectivity_claimed"] is False
    assert result["rights_proven"] is False
    assert result["political_legitimacy_claimed"] is False



def test_cross_generation_read_demo():
    result = run("cross_generation_read")
    assert result["decision"] == "ALLOWED"
    assert result["authority"] == "READ"
    assert result["ontology_assimilation_performed"] is False


def test_cross_generation_proposal_demo():
    result = run("cross_generation_proposal")
    assert result["decision"] == "ALLOWED"
    assert result["authority"] == "PROPOSE"
    assert result["subjective_consent_proven"] is False


def test_protected_write_denied_federation_demo():
    result = run("protected_write_denied")
    assert result["decision"] == "DENIED"
    assert result["reason"] == "PROTECTED_AUTHORITY_FORBIDDEN"
    assert result["protected_write_performed"] is False


def test_ontology_disagreement_interop_demo():
    result = run("ontology_disagreement_interop")
    assert result["decision"] == "ALLOWED"
    assert result["ontologies_differ"] is True
    assert result["ontology_a_unchanged"] is True
    assert result["ontology_b_unchanged"] is True
    assert result["ontology_assimilation_performed"] is False


def test_contract_revocation_demo():
    result = run("contract_revocation")
    assert result["before_revocation"] == "ALLOWED"
    assert result["after_revocation"] == "DENIED"
    assert result["final_state"] == "REVOKED"


def test_stale_contract_after_generation_fork_demo():
    result = run("stale_contract_after_generation_fork")
    assert result["original_endpoint_still_allowed"] is True
    assert result["descendant_rejected_as_stale"] is True
    assert result["automatic_contract_inheritance"] is False
