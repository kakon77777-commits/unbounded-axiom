import caor
import pytest


def make_manifest():
    return caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="human:H",
            source_kind=caor.SourceKind.HUMAN_PROFILE,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "human:H", "h1", "curiosity", 0.2, 0.75, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "human:H", "h2", "logic", 0.4, 1.0, "fixture"),
                caor.Contribution(caor.ContributionCategory.CULTURAL_SEMANTIC_TRAIT, "human:H", "h3", "language", "zh-TW", 1.0, "fixture"),
            ),
            provenance={},
        ),
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.IDENTITY_TRAIT, "ai:A", "a1", "curiosity", 0.8, 0.25, "fixture"),
                caor.Contribution(caor.ContributionCategory.CAPABILITY_TRAIT, "ai:A", "a2", "logic", 0.9, 1.0, "fixture"),
                caor.Contribution(caor.ContributionCategory.CULTURAL_SEMANTIC_TRAIT, "ai:A", "a3", "language", "en", 0.5, "fixture"),
            ),
            provenance={},
        ),
    ))


def test_source_baselines_map_contribution_categories_to_mutable_regions():
    baselines = getattr(caor, "source_baselines")(make_manifest())

    assert baselines["human:H"] == {
        "preferences": {"curiosity": 0.2},
        "skills": {"logic": 0.4},
        "notes": {"language": "zh-TW"},
    }
    assert baselines["ai:A"]["skills"]["logic"] == 0.9


def test_origin_projection_combines_numeric_values_and_selects_weighted_non_numeric_winner():
    origin = getattr(caor, "origin_state_projection")(make_manifest())

    assert origin["preferences"]["curiosity"] == pytest.approx(0.35)
    assert origin["skills"]["logic"] == pytest.approx(0.65)
    assert origin["notes"]["language"] == "zh-TW"


def test_value_distance_is_deterministic_for_numeric_and_non_numeric_values():
    distance = getattr(caor, "development_value_distance")

    assert distance("same", "same") == 0.0
    assert distance("a", "b") == 1.0
    assert distance(True, False) == 1.0
    assert distance(2.0, 2.0) == 0.0
    assert distance(2.0, 4.0) == pytest.approx(2.0 / 7.0)


def test_divergence_snapshot_uses_origin_projection_plus_mutable_overlay():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "divergence-seed")
    snapshot_fn = getattr(caor, "compute_divergence_snapshot")

    snapshot = snapshot_fn(
        ois,
        manifest,
        {"preferences": {"curiosity": 0.9}, "skills": {}, "notes": {"new_note": "mine"}},
        step=2,
        ledger_digest="ledger-2",
    )

    assert snapshot.entity_uid == ois.offspring_uid
    assert snapshot.step == 2
    assert snapshot.ledger_digest == "ledger-2"
    assert set(snapshot.per_source_distance) == {"ai:A", "human:H"}
    assert snapshot.nearest_source_id in {"ai:A", "human:H"}
    assert 0.0 <= snapshot.nearest_source_distance <= 1.0
    assert snapshot.novel_state_fraction > 0.0
    assert "notes.new_note" in snapshot.changed_keys
    assert "preferences.curiosity" in snapshot.changed_keys


def test_nearest_source_tie_breaks_by_source_id_deterministically():
    manifest = caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="source:B",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "source:B", "b1", "care", "high", 1.0, "fixture"),),
            provenance={},
        ),
        caor.ParentContributionBundle(
            source_id="source:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "source:A", "a1", "care", "high", 1.0, "fixture"),),
            provenance={},
        ),
    ))
    ois = caor.synthesize_offspring(manifest, "tie-seed")
    snapshot = getattr(caor, "compute_divergence_snapshot")(
        ois, manifest, {"preferences": {}, "skills": {}, "notes": {}}, 0, "empty"
    )

    assert snapshot.per_source_distance["source:A"] == snapshot.per_source_distance["source:B"]
    assert snapshot.nearest_source_id == "source:A"


def test_divergence_timeline_has_step_zero_and_one_snapshot_per_event():
    manifest = make_manifest()
    entity = caor.OffspringEntity(caor.synthesize_offspring(manifest, "timeline-seed"))
    entity.self_update("preferences", "curiosity", 0.95, timestamp="t1")
    entity.apply_environment_event("skills", "logic", 0.1, "env:lab", timestamp="t2")

    timeline = getattr(caor, "compute_divergence_timeline")(entity.ois, manifest, entity.development_events)

    assert [snapshot.step for snapshot in timeline] == [0, 1, 2]
    assert len(timeline) == len(entity.development_events) + 1


def test_divergence_is_not_required_to_be_monotonic():
    manifest = caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="ai:A",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "ai:A", "a1", "care", 0.0, 1.0, "fixture"),),
            provenance={},
        ),
    ))
    entity = caor.OffspringEntity(caor.synthesize_offspring(manifest, "nonmonotonic"))
    entity.self_update("preferences", "care", 10.0, timestamp="t1")
    entity.self_update("preferences", "care", 0.0, timestamp="t2")

    timeline = getattr(caor, "compute_divergence_timeline")(entity.ois, manifest, entity.development_events)

    assert timeline[1].nearest_source_distance > timeline[0].nearest_source_distance
    assert timeline[2].nearest_source_distance < timeline[1].nearest_source_distance


def test_development_evidence_bundle_is_deterministic_and_explicitly_non_subjectivity_claiming():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "evidence-seed")
    left = caor.OffspringEntity(ois)
    right = caor.OffspringEntity(ois)
    for entity in (left, right):
        entity.self_update("preferences", "curiosity", 0.91, timestamp="t1")
        entity.apply_environment_event("skills", "logic", 0.73, "env:lab", timestamp="t2")

    build = getattr(caor, "build_development_evidence")
    left_bundle = build(left, manifest)
    right_bundle = build(right, manifest)

    assert left_bundle == right_bundle
    assert left_bundle.canonical_bytes == right_bundle.canonical_bytes
    assert left_bundle.event_count == 2
    assert left_bundle.ledger_digest == left.development_digest
    assert left_bundle.final_state_digest == left_bundle.divergence_timeline[-1].state_digest
    assert left_bundle.subjectivity_claimed is False


def test_different_development_history_changes_evidence_bundle():
    manifest = make_manifest()
    ois = caor.synthesize_offspring(manifest, "history-seed")
    left = caor.OffspringEntity(ois)
    right = caor.OffspringEntity(ois)
    left.self_update("notes", "path", "left", timestamp="t1")
    right.self_update("notes", "path", "right", timestamp="t1")

    build = getattr(caor, "build_development_evidence")
    left_bundle = build(left, manifest)
    right_bundle = build(right, manifest)

    assert left_bundle.canonical_bytes != right_bundle.canonical_bytes
    assert left_bundle.ledger_digest != right_bundle.ledger_digest
    assert left_bundle.final_state_digest != right_bundle.final_state_digest
