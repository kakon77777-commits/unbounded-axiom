import pytest

from caor.classifier import ClassificationEvidence, classify_event
from caor.errors import AmbiguousClassification, UnsupportedEvent
from caor.lineage import LineageEventType


def test_classifies_restore():
    evidence = ClassificationEvidence(source_count=1, explicit_checkpoint_restore=True, checkpoint_reference=True)
    assert classify_event(evidence) is LineageEventType.RESTORE


def test_classifies_migration():
    evidence = ClassificationEvidence(
        source_count=1,
        substrate_change=True,
        no_parallel_identity=True,
        continuity_preserved=True,
        state_transfer=True,
        source_retired_or_quiesced=True,
    )
    assert classify_event(evidence) is LineageEventType.MIGRATION


def test_classifies_update():
    evidence = ClassificationEvidence(source_count=1, same_lineage=True, new_branch=False, allowed_mutation=True)
    assert classify_event(evidence) is LineageEventType.UPDATE


def test_classifies_copy():
    evidence = ClassificationEvidence(source_count=1, direct_duplicate=True, synthesis_manifest=False)
    assert classify_event(evidence) is LineageEventType.COPY


def test_classifies_fork():
    evidence = ClassificationEvidence(source_count=1, new_branch=True, shared_pre_fork_history=True, synthesis_manifest=False)
    assert classify_event(evidence) is LineageEventType.FORK


def test_classifies_merge():
    evidence = ClassificationEvidence(source_count=2, explicit_merge=True, merge_sources=True)
    assert classify_event(evidence) is LineageEventType.MERGE


def test_classifies_offspring_only_when_all_positive_invariants_are_present():
    evidence = ClassificationEvidence(
        source_count=2,
        synthesis_manifest=True,
        new_identity_root=True,
        new_memory_root=True,
        new_state_namespace=True,
        new_lineage_id=True,
        independent_development_policy=True,
        source_uid_reuse=False,
    )
    assert classify_event(evidence) is LineageEventType.OFFSPRING


def test_partial_offspring_evidence_is_not_a_fallback():
    evidence = ClassificationEvidence(
        source_count=2,
        synthesis_manifest=True,
        new_identity_root=True,
        new_memory_root=True,
        new_state_namespace=False,
        new_lineage_id=True,
        independent_development_policy=True,
    )
    with pytest.raises(UnsupportedEvent):
        classify_event(evidence)


def test_conflicting_explicit_restore_and_merge_is_ambiguous():
    evidence = ClassificationEvidence(
        source_count=2,
        explicit_checkpoint_restore=True,
        checkpoint_reference=True,
        explicit_merge=True,
        merge_sources=True,
    )
    with pytest.raises(AmbiguousClassification):
        classify_event(evidence)


def test_direct_duplicate_and_new_branch_is_ambiguous():
    evidence = ClassificationEvidence(
        source_count=1,
        direct_duplicate=True,
        new_branch=True,
        shared_pre_fork_history=True,
    )
    with pytest.raises(AmbiguousClassification):
        classify_event(evidence)
