import caor
import pytest


def make_ois():
    manifest = caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="ai:parent",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(
                    caor.ContributionCategory.VALUE_TRAIT,
                    "ai:parent",
                    "value-1",
                    "curiosity",
                    "high",
                    1.0,
                    "fixture",
                ),
            ),
            provenance={"fixture": True},
        ),
    ))
    return caor.synthesize_offspring(manifest, "development-seed")


def test_development_ledger_appends_deterministic_event():
    Ledger = getattr(caor, "DevelopmentLedger")
    Kind = getattr(caor, "DevelopmentEventKind")

    left = Ledger()
    right = Ledger()
    for ledger in (left, right):
        event = ledger.append(
            actor_id="caor:offspring:test",
            event_kind=Kind.SELF_UPDATE,
            region="preferences",
            key="music",
            value="jazz",
            previous_value=None,
            timestamp="t1",
            evidence={"reason": "self"},
        )
        assert event.event_index == 0
        assert event.event_kind is Kind.SELF_UPDATE

    assert left.events == right.events
    assert left.canonical_bytes() == right.canonical_bytes()
    assert left.digest == right.digest


def test_development_ledger_rejects_index_gap():
    Event = getattr(caor, "DevelopmentEvent")
    Kind = getattr(caor, "DevelopmentEventKind")
    Ledger = getattr(caor, "DevelopmentLedger")
    Error = getattr(caor, "InvalidDevelopmentEvent")

    ledger = Ledger()
    event = Event(
        event_id="manual-gap",
        event_index=1,
        actor_id="child",
        event_kind=Kind.SELF_UPDATE,
        region="preferences",
        key="music",
        value="jazz",
        previous_value=None,
        source_event_id=None,
        timestamp="t1",
        evidence={},
    )
    with pytest.raises(Error):
        ledger.add_event(event)


def test_development_ledger_rejects_event_id_collision():
    Event = getattr(caor, "DevelopmentEvent")
    Kind = getattr(caor, "DevelopmentEventKind")
    Ledger = getattr(caor, "DevelopmentLedger")
    Error = getattr(caor, "InvalidDevelopmentEvent")

    ledger = Ledger()
    first = Event("same-id", 0, "child", Kind.SELF_UPDATE, "preferences", "music", "jazz", None, None, "t1", {})
    second = Event("same-id", 1, "child", Kind.SELF_UPDATE, "preferences", "music", "rock", "jazz", None, "t2", {})
    ledger.add_event(first)
    with pytest.raises(Error):
        ledger.add_event(second)


def test_replay_mutable_state_reconstructs_event_sequence():
    Ledger = getattr(caor, "DevelopmentLedger")
    Kind = getattr(caor, "DevelopmentEventKind")
    replay = getattr(caor, "replay_mutable_state")
    ois = make_ois()
    ledger = Ledger()

    ledger.append("child", Kind.SELF_UPDATE, "preferences", "music", "jazz", None, timestamp="t1")
    ledger.append("env:school", Kind.ENVIRONMENT_EVENT, "skills", "logic", 0.7, None, timestamp="t2")
    ledger.append("child", Kind.SELF_UPDATE, "preferences", "music", "classical", "jazz", timestamp="t3")

    replayed = replay(ois, ledger.events)
    assert replayed == {
        "preferences": {"music": "classical"},
        "skills": {"logic": 0.7},
        "notes": {},
    }


def test_replay_rejects_non_contiguous_event_sequence():
    Event = getattr(caor, "DevelopmentEvent")
    Kind = getattr(caor, "DevelopmentEventKind")
    replay = getattr(caor, "replay_mutable_state")
    Error = getattr(caor, "InvalidDevelopmentEvent")
    ois = make_ois()

    events = (
        Event("e0", 0, "child", Kind.SELF_UPDATE, "preferences", "music", "jazz", None, None, "t1", {}),
        Event("e2", 2, "child", Kind.SELF_UPDATE, "preferences", "music", "rock", "jazz", None, "t2", {}),
    )
    with pytest.raises(Error):
        replay(ois, events)


def make_entity():
    manifest = caor.normalize_contributions((
        caor.ParentContributionBundle(
            source_id="ai:parent",
            source_kind=caor.SourceKind.AI_ENTITY,
            contributions=(
                caor.Contribution(caor.ContributionCategory.VALUE_TRAIT, "ai:parent", "p1", "care", True, 1.0, "fixture"),
            ),
            provenance={},
        ),
    ))
    return caor.OffspringEntity(caor.synthesize_offspring(manifest, "entity-development"))


def test_self_update_appends_one_development_event():
    entity = make_entity()
    before_core = entity.protected_core_snapshot()

    event = entity.self_update("preferences", "music", "jazz", timestamp="t1")

    assert event.event_kind is caor.DevelopmentEventKind.SELF_UPDATE
    assert event.actor_id == entity.ois.offspring_uid
    assert event.previous_value is None
    assert entity.mutable_state["preferences"]["music"] == "jazz"
    assert entity.development_events == (event,)
    assert entity.protected_core_snapshot() == before_core


def test_accept_proposal_is_explicit_traceable_and_does_not_rewrite_original_record():
    entity = make_entity()
    proposal = entity.propose_update("ai:parent", "preferences", "music", "jazz")

    event = entity.accept_proposal(proposal.proposal_id, timestamp="t2")

    assert proposal.status == "PENDING"
    assert entity.proposal_status(proposal.proposal_id) == "ACCEPTED"
    assert event.event_kind is caor.DevelopmentEventKind.ACCEPT_PROPOSAL
    assert event.source_event_id == proposal.proposal_id
    assert event.actor_id == entity.ois.offspring_uid
    assert event.evidence["proposal_source_id"] == "ai:parent"
    assert entity.mutable_state["preferences"]["music"] == "jazz"


def test_proposal_cannot_be_accepted_twice():
    entity = make_entity()
    proposal = entity.propose_update("ai:parent", "preferences", "music", "jazz")
    entity.accept_proposal(proposal.proposal_id)

    with pytest.raises(caor.InvalidDevelopmentEvent):
        entity.accept_proposal(proposal.proposal_id)


def test_environment_event_has_distinct_kind_and_environment_provenance():
    entity = make_entity()

    event = entity.apply_environment_event(
        "skills",
        "logic",
        0.8,
        environment_id="env:school",
        timestamp="t3",
        evidence={"lesson": "proof-1"},
    )

    assert event.event_kind is caor.DevelopmentEventKind.ENVIRONMENT_EVENT
    assert event.actor_id == "env:school"
    assert event.evidence == {"lesson": "proof-1"}
    assert entity.mutable_state["skills"]["logic"] == 0.8


def test_live_state_matches_replay_after_mixed_development_events():
    entity = make_entity()
    proposal = entity.propose_update("ai:parent", "preferences", "music", "jazz")
    entity.self_update("notes", "self-note", "first", timestamp="t1")
    entity.accept_proposal(proposal.proposal_id, timestamp="t2")
    entity.apply_environment_event("skills", "logic", 0.8, "env:school", timestamp="t3")

    replayed = caor.replay_mutable_state(entity.ois, entity.development_events)
    assert caor.canonical_json_bytes(replayed) == caor.canonical_json_bytes(entity.mutable_state)
