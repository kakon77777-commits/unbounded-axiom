# CAOR MVP v0.3 Release Notes

## Release

**CAOR MVP v0.3 — Counterfactual Development Branching Runtime**

## New

- `CounterfactualActionKind`
- `CounterfactualAction`
- `CounterfactualBranchSpec`
- `CounterfactualTrajectory`
- `CounterfactualBranchComparison`
- `CounterfactualEvidenceBundle`
- `run_counterfactual_branch`
- `compare_counterfactual_trajectories`
- `build_counterfactual_evidence`
- executable `counterfactual_development_branches.py` demo

## Preserved

- v0.1 initialization and classifier semantics
- v0.2 append-only DevelopmentLedger
- protected-core write boundaries
- origin projection and source baseline divergence semantics

## Canonical v0.3 statement

$$
\boxed{
\text{Same Origin}
+
\text{Different Supplied Event Sequences}
\rightarrow
\text{Distinct Replayable Trajectories}.
}
$$

This release does not claim consciousness, subjectivity, autonomy, or free will.
