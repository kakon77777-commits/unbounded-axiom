# CAOR MVP v0.6.0 — Release Notes

## Theme

**Meta-Constitutional Governance Runtime**

v0.6 adds a fixed root layer above v0.5's policy constitution so ordinary constitution changes cannot silently delete root-bounded invariants.

## Added

- immutable `RootMetaConstitution`;
- deterministic root digest and canonical evidence;
- immutable `ConstitutionVersion` lineage;
- context/history-conditioned `ConstitutionAmendmentProposal`;
- named `MetaConstitutionalReviewEvidence`;
- root-enforced NO_OP requirement;
- root action-kind, candidate-count, score-bound, and tie-break constraints;
- deterministic `ConstitutionValidationCase` evidence;
- append-only `ConstitutionRegistry`;
- stale amendment and root-digest guards;
- reversion-as-new-version behavior;
- executable `meta_constitutional_governance.py` demo;
- defensive disclosure Clauses 63–76.

## Scope Firewall

v0.6 does not claim that amendment generation or adoption proves autonomy, free will, consciousness, political legitimacy, legal constitutional authority, or moral agency.

## Compatibility

All v0.1–v0.5 APIs and event semantics remain intact.
