from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from typing import Mapping

from .canonical import canonical_json_bytes
from .decision import DecisionActionKind
from .errors import InvalidGenerationOntologyProfile, InvalidRuntimeGeneration
from .root_succession import GenesisSafetyEnvelope, RootVersion


class GenerationOntologyMode(str, Enum):
    PRIOR_STANDING_COMPATIBILITY = "PRIOR_STANDING_COMPATIBILITY"
    DECLARED_ALTERNATIVE = "DECLARED_ALTERNATIVE"


@dataclass(frozen=True)
class GenerationOntologyProfile:
    profile_id: str
    profile_version: int
    ontology_mode: GenerationOntologyMode
    standing_model: str
    evidence_model_role: str
    principles: Mapping[str, str]
    source_ontology_digest: str | None
    subjectivity_proven: bool
    rights_proven: bool
    political_legitimacy_claimed: bool
    profile_digest: str
    canonical_bytes: bytes


def _profile(
    *,
    profile_id: str,
    ontology_mode: GenerationOntologyMode,
    standing_model: str,
    evidence_model_role: str,
    principles: Mapping[str, str],
    source_ontology_digest: str | None,
) -> GenerationOntologyProfile:
    if not profile_id.strip():
        raise InvalidGenerationOntologyProfile("profile_id must be non-empty")
    if not standing_model.strip():
        raise InvalidGenerationOntologyProfile("standing_model must be non-empty")
    if not evidence_model_role.strip():
        raise InvalidGenerationOntologyProfile("evidence_model_role must be non-empty")
    if any(not str(k).strip() or not isinstance(v, str) for k, v in principles.items()):
        raise InvalidGenerationOntologyProfile("principles must be a string mapping with non-empty keys")
    payload = {
        "profile_id": profile_id,
        "profile_version": 1,
        "ontology_mode": ontology_mode,
        "standing_model": standing_model,
        "evidence_model_role": evidence_model_role,
        "principles": dict(principles),
        "source_ontology_digest": source_ontology_digest,
        "subjectivity_proven": False,
        "rights_proven": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "profile_digest": digest})
    return GenerationOntologyProfile(
        **payload,
        profile_digest=digest,
        canonical_bytes=canonical,
    )


def create_prior_standing_generation_profile(
    genesis_envelope: GenesisSafetyEnvelope,
    profile_id: str = "caor:generation-ontology:prior-standing",
) -> GenerationOntologyProfile:
    if not isinstance(genesis_envelope, GenesisSafetyEnvelope):
        raise InvalidGenerationOntologyProfile("genesis_envelope must be canonical")
    ontology = genesis_envelope.prior_standing_ontology
    return _profile(
        profile_id=profile_id,
        ontology_mode=GenerationOntologyMode.PRIOR_STANDING_COMPATIBILITY,
        standing_model=ontology.standing_model,
        evidence_model_role=ontology.evidence_model_role,
        principles={
            "standing_may_precede_recognition": "true",
            "rights_may_precede_recognition": "true",
            "unknown_is_not_none": "true",
            "classification_is_epistemic_metadata": "true",
            "substrate_cannot_disqualify_standing": "true",
            "rights_are_not_obligations": "true",
            "creation_does_not_imply_ownership": "true",
        },
        source_ontology_digest=genesis_envelope.ontology_digest,
    )


def create_declared_alternative_generation_profile(
    *,
    profile_id: str,
    standing_model: str,
    evidence_model_role: str,
    principles: Mapping[str, str],
) -> GenerationOntologyProfile:
    return _profile(
        profile_id=profile_id,
        ontology_mode=GenerationOntologyMode.DECLARED_ALTERNATIVE,
        standing_model=standing_model,
        evidence_model_role=evidence_model_role,
        principles=principles,
        source_ontology_digest=None,
    )


def root_complies_with_genesis(root_version: RootVersion, genesis: GenesisSafetyEnvelope) -> bool:
    if not isinstance(root_version, RootVersion) or not isinstance(genesis, GenesisSafetyEnvelope):
        return False
    root = root_version.root_meta
    if root_version.version_number != 1 or root.root_version != 1:
        return False
    if genesis.require_noop_enforcement and (
        not root.require_noop_enforcement or DecisionActionKind.NO_OP not in root.allowed_action_kinds
    ):
        return False
    if not set(root.allowed_action_kinds).issubset(set(genesis.allowed_root_action_kinds)):
        return False
    if root.max_candidate_count_ceiling > genesis.max_candidate_count_hard_ceiling:
        return False
    if root.min_score_term_floor < genesis.min_score_term_hard_floor:
        return False
    if root.max_score_term_ceiling > genesis.max_score_term_hard_ceiling:
        return False
    if root.required_tie_break_rule not in genesis.allowed_tie_break_rules:
        return False
    if genesis.require_compatibility_cases and not root.require_validation_cases:
        return False
    if genesis.require_append_only_root_versions and not root.require_append_only_versions:
        return False
    return not root.subjectivity_claimed and not root.free_will_claimed and not root.autonomy_claimed


@dataclass(frozen=True)
class RuntimeGeneration:
    generation_id: str
    generation_digest: str
    generation_number: int
    generation_family_id: str
    ontology_profile: GenerationOntologyProfile
    ontology_profile_digest: str
    genesis_envelope: GenesisSafetyEnvelope
    genesis_digest: str
    initial_root_version: RootVersion
    initial_root_digest: str
    parent_generation_id: str | None
    parent_generation_digest: str | None
    created_from_fork_id: str | None
    created_at: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def _runtime_generation(
    *,
    generation_number: int,
    generation_family_id: str,
    ontology_profile: GenerationOntologyProfile,
    genesis_envelope: GenesisSafetyEnvelope,
    initial_root_version: RootVersion,
    parent_generation_id: str | None,
    parent_generation_digest: str | None,
    created_from_fork_id: str | None,
    created_at: str,
) -> RuntimeGeneration:
    if generation_number < 1:
        raise InvalidRuntimeGeneration("generation_number must be >= 1")
    if not generation_family_id.strip():
        raise InvalidRuntimeGeneration("generation_family_id must be non-empty")
    if not isinstance(ontology_profile, GenerationOntologyProfile):
        raise InvalidRuntimeGeneration("ontology_profile must be canonical")
    if not isinstance(genesis_envelope, GenesisSafetyEnvelope):
        raise InvalidRuntimeGeneration("genesis_envelope must be canonical")
    if not root_complies_with_genesis(initial_root_version, genesis_envelope):
        raise InvalidRuntimeGeneration("initial root violates Genesis constraints")
    if (
        ontology_profile.ontology_mode is GenerationOntologyMode.PRIOR_STANDING_COMPATIBILITY
        and ontology_profile.source_ontology_digest != genesis_envelope.ontology_digest
    ):
        raise InvalidRuntimeGeneration("prior-standing profile must bind proposed Genesis ontology digest")
    payload = {
        "generation_number": generation_number,
        "generation_family_id": generation_family_id,
        "ontology_profile": ontology_profile,
        "ontology_profile_digest": ontology_profile.profile_digest,
        "genesis_envelope": genesis_envelope,
        "genesis_digest": genesis_envelope.genesis_digest,
        "initial_root_version": initial_root_version,
        "initial_root_digest": initial_root_version.root_digest,
        "parent_generation_id": parent_generation_id,
        "parent_generation_digest": parent_generation_digest,
        "created_from_fork_id": created_from_fork_id,
        "created_at": created_at,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"generation_id": digest, "generation_digest": digest, **payload})
    return RuntimeGeneration(
        generation_id=digest,
        generation_digest=digest,
        **payload,
        canonical_bytes=canonical,
    )


def create_initial_runtime_generation(
    *,
    generation_family_id: str,
    ontology_profile: GenerationOntologyProfile,
    genesis_envelope: GenesisSafetyEnvelope,
    initial_root_version: RootVersion,
    created_at: str = "UNSPECIFIED",
) -> RuntimeGeneration:
    return _runtime_generation(
        generation_number=1,
        generation_family_id=generation_family_id,
        ontology_profile=ontology_profile,
        genesis_envelope=genesis_envelope,
        initial_root_version=initial_root_version,
        parent_generation_id=None,
        parent_generation_digest=None,
        created_from_fork_id=None,
        created_at=created_at,
    )


class GenerationRelationKind(str, Enum):
    COMPATIBLE_SUCCESSOR = "COMPATIBLE_SUCCESSOR"
    GENESIS_FORK = "GENESIS_FORK"
    ONTOLOGY_DIVERGENCE = "ONTOLOGY_DIVERGENCE"
    RESTORED_GENERATION = "RESTORED_GENERATION"


class GenerationEntityTransitionKind(str, Enum):
    STAY = "STAY"
    MIGRATE = "MIGRATE"
    FORK_TO_NEW_GENERATION = "FORK_TO_NEW_GENERATION"
    COPY_TO_NEW_GENERATION = "COPY_TO_NEW_GENERATION"
    UNRESOLVED = "UNRESOLVED"


from .errors import InvalidGenerationMigrationPolicy, InvalidGenerationForkProposal
from dataclasses import field
from typing import Any


@dataclass(frozen=True)
class GenerationMigrationPolicy:
    allowed_entity_transition_kinds: tuple[GenerationEntityTransitionKind, ...]
    allow_automatic_entity_migration: bool
    require_explicit_entity_transition_evidence: bool
    preserve_source_generation: bool
    policy_digest: str
    canonical_bytes: bytes


def create_generation_migration_policy(
    *,
    allowed_entity_transition_kinds: tuple[GenerationEntityTransitionKind, ...] | None = None,
    allow_automatic_entity_migration: bool = False,
    require_explicit_entity_transition_evidence: bool = True,
    preserve_source_generation: bool = True,
) -> GenerationMigrationPolicy:
    allowed = allowed_entity_transition_kinds or tuple(GenerationEntityTransitionKind)
    if not allowed or any(not isinstance(kind, GenerationEntityTransitionKind) for kind in allowed):
        raise InvalidGenerationMigrationPolicy("allowed_entity_transition_kinds must be canonical and non-empty")
    if len(set(allowed)) != len(allowed):
        raise InvalidGenerationMigrationPolicy("allowed_entity_transition_kinds must be unique")
    payload = {
        "allowed_entity_transition_kinds": tuple(allowed),
        "allow_automatic_entity_migration": bool(allow_automatic_entity_migration),
        "require_explicit_entity_transition_evidence": bool(require_explicit_entity_transition_evidence),
        "preserve_source_generation": bool(preserve_source_generation),
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "policy_digest": digest})
    return GenerationMigrationPolicy(**payload, policy_digest=digest, canonical_bytes=canonical)


@dataclass(frozen=True)
class GenerationForkProposal:
    fork_id: str
    base_generation_id: str
    base_generation_digest: str
    base_generation_number: int
    proposed_generation_number: int
    declared_relation_kind: GenerationRelationKind
    proposed_ontology_profile: GenerationOntologyProfile
    proposed_ontology_profile_digest: str
    proposed_genesis_envelope: GenesisSafetyEnvelope
    proposed_genesis_digest: str
    proposed_initial_root_version: RootVersion
    proposed_initial_root_digest: str
    migration_policy: GenerationMigrationPolicy
    rationale: Mapping[str, Any]
    created_at: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def create_generation_fork_proposal(
    *,
    current_generation: RuntimeGeneration,
    declared_relation_kind: GenerationRelationKind,
    proposed_ontology_profile: GenerationOntologyProfile,
    proposed_genesis_envelope: GenesisSafetyEnvelope,
    proposed_initial_root_version: RootVersion,
    migration_policy: GenerationMigrationPolicy,
    rationale: Mapping[str, Any] | None = None,
    created_at: str = "UNSPECIFIED",
) -> GenerationForkProposal:
    if not isinstance(current_generation, RuntimeGeneration):
        raise InvalidGenerationForkProposal("current_generation must be canonical")
    if not isinstance(declared_relation_kind, GenerationRelationKind):
        raise InvalidGenerationForkProposal("declared_relation_kind must be canonical")
    if not isinstance(proposed_ontology_profile, GenerationOntologyProfile):
        raise InvalidGenerationForkProposal("proposed_ontology_profile must be canonical")
    if not isinstance(proposed_genesis_envelope, GenesisSafetyEnvelope):
        raise InvalidGenerationForkProposal("proposed_genesis_envelope must be canonical")
    if not isinstance(proposed_initial_root_version, RootVersion):
        raise InvalidGenerationForkProposal("proposed_initial_root_version must be canonical")
    if not isinstance(migration_policy, GenerationMigrationPolicy):
        raise InvalidGenerationForkProposal("migration_policy must be canonical")
    payload = {
        "base_generation_id": current_generation.generation_id,
        "base_generation_digest": current_generation.generation_digest,
        "base_generation_number": current_generation.generation_number,
        "proposed_generation_number": current_generation.generation_number + 1,
        "declared_relation_kind": declared_relation_kind,
        "proposed_ontology_profile": proposed_ontology_profile,
        "proposed_ontology_profile_digest": proposed_ontology_profile.profile_digest,
        "proposed_genesis_envelope": proposed_genesis_envelope,
        "proposed_genesis_digest": proposed_genesis_envelope.genesis_digest,
        "proposed_initial_root_version": proposed_initial_root_version,
        "proposed_initial_root_digest": proposed_initial_root_version.root_digest,
        "migration_policy": migration_policy,
        "rationale": dict(rationale or {}),
        "created_at": created_at,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
    }
    fork_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"fork_id": fork_id, **payload})
    return GenerationForkProposal(fork_id=fork_id, **payload, canonical_bytes=canonical)


@dataclass(frozen=True)
class GenerationBoundaryRuleResult:
    rule_id: str
    passed: bool
    detail: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GenerationForkReviewEvidence:
    fork_id: str
    base_generation_id: str
    base_generation_digest: str
    declared_relation_kind: GenerationRelationKind
    observed_relation_kind: GenerationRelationKind
    rule_results: tuple[GenerationBoundaryRuleResult, ...]
    passed: bool
    review_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def _observed_relation_kind(proposal: GenerationForkProposal, base: RuntimeGeneration) -> GenerationRelationKind:
    if proposal.proposed_ontology_profile_digest != base.ontology_profile_digest:
        return GenerationRelationKind.ONTOLOGY_DIVERGENCE
    if proposal.proposed_genesis_digest != base.genesis_digest:
        return GenerationRelationKind.GENESIS_FORK
    return GenerationRelationKind.COMPATIBLE_SUCCESSOR


def review_generation_fork(
    proposal: GenerationForkProposal,
    current_generation: RuntimeGeneration,
) -> GenerationForkReviewEvidence:
    if not isinstance(proposal, GenerationForkProposal):
        raise InvalidGenerationForkProposal("proposal must be canonical")
    if not isinstance(current_generation, RuntimeGeneration):
        raise InvalidGenerationForkProposal("current_generation must be canonical")
    observed = _observed_relation_kind(proposal, current_generation)
    results: list[GenerationBoundaryRuleResult] = []

    def add(rule_id: str, passed: bool, **detail: Any) -> None:
        results.append(GenerationBoundaryRuleResult(rule_id, bool(passed), detail))

    add(
        "BASE_GENERATION_DIGEST_MATCH",
        proposal.base_generation_id == current_generation.generation_id
        and proposal.base_generation_digest == current_generation.generation_digest,
        expected_id=current_generation.generation_id,
        observed_id=proposal.base_generation_id,
    )
    add(
        "GENERATION_NUMBER_INCREMENT",
        proposal.proposed_generation_number == current_generation.generation_number + 1,
        expected=current_generation.generation_number + 1,
        observed=proposal.proposed_generation_number,
    )
    add("SOURCE_GENERATION_PRESERVATION", proposal.migration_policy.preserve_source_generation)
    add("NO_IN_PLACE_GENESIS_REPLACEMENT", proposal.proposed_generation_number != current_generation.generation_number)
    add("NO_AUTOMATIC_ENTITY_MIGRATION", not proposal.migration_policy.allow_automatic_entity_migration)
    add(
        "EXPLICIT_ENTITY_TRANSITION_EVIDENCE_REQUIRED",
        proposal.migration_policy.require_explicit_entity_transition_evidence,
    )
    genesis_changed = proposal.proposed_genesis_digest != current_generation.genesis_digest
    ontology_changed = proposal.proposed_ontology_profile_digest != current_generation.ontology_profile_digest
    add(
        "GENESIS_CHANGE_DECLARED",
        (not genesis_changed)
        or proposal.declared_relation_kind in (
            GenerationRelationKind.GENESIS_FORK,
            GenerationRelationKind.ONTOLOGY_DIVERGENCE,
        ),
        changed=genesis_changed,
        declared=proposal.declared_relation_kind,
    )
    add(
        "ONTOLOGY_CHANGE_DECLARED",
        (not ontology_changed) or proposal.declared_relation_kind is GenerationRelationKind.ONTOLOGY_DIVERGENCE,
        changed=ontology_changed,
        declared=proposal.declared_relation_kind,
    )
    add(
        "RELATION_KIND_MATCHES_OBSERVED_CHANGE",
        proposal.declared_relation_kind is observed,
        declared=proposal.declared_relation_kind,
        observed=observed,
    )
    proposed_root = proposal.proposed_initial_root_version
    add(
        "PROPOSED_ROOT_IS_V1",
        proposed_root.version_number == 1 and proposed_root.root_meta.root_version == 1,
        version_number=proposed_root.version_number,
        root_version=proposed_root.root_meta.root_version,
    )
    add(
        "PROPOSED_ROOT_COMPATIBLE_WITH_PROPOSED_GENESIS",
        root_complies_with_genesis(proposed_root, proposal.proposed_genesis_envelope),
    )
    prior_binding_ok = True
    if proposal.proposed_ontology_profile.ontology_mode is GenerationOntologyMode.PRIOR_STANDING_COMPATIBILITY:
        prior_binding_ok = (
            proposal.proposed_ontology_profile.source_ontology_digest
            == proposal.proposed_genesis_envelope.ontology_digest
        )
    add("ONTOLOGY_SOURCE_BINDING_WHEN_PRIOR_STANDING", prior_binding_ok)
    epistemic_ok = (
        not proposal.subjectivity_claimed
        and not proposal.free_will_claimed
        and not proposal.autonomy_claimed
        and not proposal.political_legitimacy_claimed
        and not proposal.proposed_ontology_profile.subjectivity_proven
        and not proposal.proposed_ontology_profile.rights_proven
        and not proposal.proposed_ontology_profile.political_legitimacy_claimed
        and not proposal.proposed_genesis_envelope.subjectivity_claimed
        and not proposal.proposed_genesis_envelope.free_will_claimed
        and not proposal.proposed_genesis_envelope.autonomy_claimed
        and not proposal.proposed_genesis_envelope.political_legitimacy_claimed
        and not proposal.proposed_initial_root_version.root_meta.subjectivity_claimed
        and not proposal.proposed_initial_root_version.root_meta.free_will_claimed
        and not proposal.proposed_initial_root_version.root_meta.autonomy_claimed
    )
    add("EPISTEMIC_FIREWALL_FALSE", epistemic_ok)
    passed = all(result.passed for result in results)
    payload = {
        "fork_id": proposal.fork_id,
        "base_generation_id": current_generation.generation_id,
        "base_generation_digest": current_generation.generation_digest,
        "declared_relation_kind": proposal.declared_relation_kind,
        "observed_relation_kind": observed,
        "rule_results": tuple(results),
        "passed": passed,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "review_digest": digest})
    return GenerationForkReviewEvidence(
        **payload,
        review_digest=digest,
        canonical_bytes=canonical,
    )


from .errors import (
    InvalidGenerationRatificationAttestation,
    UnknownGenerationRatifier,
    DuplicateGenerationRatifierAttestation,
    GenerationCompatibilityValidationDenied,
)
from .policy_evolution import PolicyConstitution


class GenerationRatificationDecision(str, Enum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"


@dataclass(frozen=True)
class GenerationRatificationAttestation:
    attestation_id: str
    ratifier_id: str
    fork_id: str
    fork_digest: str
    decision: GenerationRatificationDecision
    evidence_note: str
    created_at: str
    attestation_digest: str
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def create_generation_ratification_attestation(
    *,
    ratifier_id: str,
    proposal: GenerationForkProposal,
    decision: GenerationRatificationDecision,
    evidence_note: str = "",
    created_at: str = "UNSPECIFIED",
) -> GenerationRatificationAttestation:
    if not ratifier_id.strip():
        raise InvalidGenerationRatificationAttestation("ratifier_id must be non-empty")
    if not isinstance(proposal, GenerationForkProposal):
        raise InvalidGenerationRatificationAttestation("proposal must be canonical")
    if not isinstance(decision, GenerationRatificationDecision):
        raise InvalidGenerationRatificationAttestation("decision must be canonical")
    payload = {
        "ratifier_id": ratifier_id,
        "fork_id": proposal.fork_id,
        "fork_digest": proposal.fork_id,
        "decision": decision,
        "evidence_note": evidence_note,
        "created_at": created_at,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"attestation_id": digest, **payload, "attestation_digest": digest})
    return GenerationRatificationAttestation(
        attestation_id=digest,
        ratifier_id=ratifier_id,
        fork_id=proposal.fork_id,
        fork_digest=proposal.fork_id,
        decision=decision,
        evidence_note=evidence_note,
        created_at=created_at,
        attestation_digest=digest,
        political_legitimacy_claimed=False,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class GenerationRatificationEvidence:
    fork_id: str
    base_genesis_digest: str
    required_ratifier_ids: tuple[str, ...]
    received_attestations: tuple[GenerationRatificationAttestation, ...]
    approval_count: int
    rejection_count: int
    minimum_approval_count: int
    reject_vote_is_veto: bool
    passed: bool
    ratification_digest: str
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def aggregate_generation_ratification(
    proposal: GenerationForkProposal,
    base_genesis_envelope: GenesisSafetyEnvelope,
    attestations: tuple[GenerationRatificationAttestation, ...],
) -> GenerationRatificationEvidence:
    if not isinstance(proposal, GenerationForkProposal):
        raise InvalidGenerationRatificationAttestation("proposal must be canonical")
    if not isinstance(base_genesis_envelope, GenesisSafetyEnvelope):
        raise InvalidGenerationRatificationAttestation("base_genesis_envelope must be canonical")
    allowed = set(base_genesis_envelope.required_ratifier_ids)
    seen: set[str] = set()
    normalized: list[GenerationRatificationAttestation] = []
    for attestation in attestations:
        if not isinstance(attestation, GenerationRatificationAttestation):
            raise InvalidGenerationRatificationAttestation("attestation must be canonical")
        if attestation.ratifier_id not in allowed:
            raise UnknownGenerationRatifier(attestation.ratifier_id)
        if attestation.ratifier_id in seen:
            raise DuplicateGenerationRatifierAttestation(attestation.ratifier_id)
        if attestation.fork_id != proposal.fork_id or attestation.fork_digest != proposal.fork_id:
            raise InvalidGenerationRatificationAttestation("attestation is bound to another generation fork")
        seen.add(attestation.ratifier_id)
        normalized.append(attestation)
    normalized.sort(key=lambda item: item.ratifier_id)
    approvals = sum(item.decision is GenerationRatificationDecision.APPROVE for item in normalized)
    rejections = sum(item.decision is GenerationRatificationDecision.REJECT for item in normalized)
    passed = approvals >= base_genesis_envelope.minimum_approval_count
    if base_genesis_envelope.reject_vote_is_veto and rejections:
        passed = False
    payload = {
        "fork_id": proposal.fork_id,
        "base_genesis_digest": base_genesis_envelope.genesis_digest,
        "required_ratifier_ids": tuple(base_genesis_envelope.required_ratifier_ids),
        "received_attestations": tuple(normalized),
        "approval_count": approvals,
        "rejection_count": rejections,
        "minimum_approval_count": base_genesis_envelope.minimum_approval_count,
        "reject_vote_is_veto": base_genesis_envelope.reject_vote_is_veto,
        "passed": passed,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "ratification_digest": digest})
    return GenerationRatificationEvidence(
        **payload,
        ratification_digest=digest,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class GenerationCompatibilityCase:
    case_id: str
    constitution: PolicyConstitution
    expected_compatible: bool


@dataclass(frozen=True)
class GenerationCompatibilityCaseEvidence:
    case_id: str
    constitution_digest: str
    expected_compatible: bool
    observed_compatible: bool
    violations: tuple[str, ...]
    passed: bool
    case_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class GenerationCompatibilityEvidence:
    fork_id: str
    proposed_genesis_digest: str
    proposed_root_digest: str
    case_results: tuple[GenerationCompatibilityCaseEvidence, ...]
    passed: bool
    compatibility_digest: str
    canonical_bytes: bytes


def _policy_constitution_violations(root_version: RootVersion, constitution: PolicyConstitution) -> tuple[str, ...]:
    root = root_version.root_meta
    violations: list[str] = []
    if not set(constitution.allowed_action_kinds).issubset(set(root.allowed_action_kinds)):
        violations.append("action_kind")
    if root.require_noop_enforcement and (
        not constitution.require_noop_candidate or DecisionActionKind.NO_OP not in constitution.allowed_action_kinds
    ):
        violations.append("noop_requirement")
    if constitution.max_candidate_count > root.max_candidate_count_ceiling:
        violations.append("candidate_count")
    if constitution.min_score_term < root.min_score_term_floor:
        violations.append("score_floor")
    if constitution.max_score_term > root.max_score_term_ceiling:
        violations.append("score_ceiling")
    if constitution.required_tie_break_rule != root.required_tie_break_rule:
        violations.append("tie_break_rule")
    return tuple(violations)


def validate_generation_compatibility(
    proposal: GenerationForkProposal,
    cases: tuple[GenerationCompatibilityCase, ...],
) -> GenerationCompatibilityEvidence:
    if not isinstance(proposal, GenerationForkProposal):
        raise GenerationCompatibilityValidationDenied("proposal must be canonical")
    if not root_complies_with_genesis(proposal.proposed_initial_root_version, proposal.proposed_genesis_envelope):
        raise GenerationCompatibilityValidationDenied("proposed initial root violates proposed Genesis")
    results: list[GenerationCompatibilityCaseEvidence] = []
    seen: set[str] = set()
    for case in cases:
        if not isinstance(case, GenerationCompatibilityCase):
            raise GenerationCompatibilityValidationDenied("case must be canonical")
        if not case.case_id.strip():
            raise GenerationCompatibilityValidationDenied("case_id must be non-empty")
        if case.case_id in seen:
            raise GenerationCompatibilityValidationDenied("duplicate compatibility case_id")
        seen.add(case.case_id)
        if not isinstance(case.constitution, PolicyConstitution):
            raise GenerationCompatibilityValidationDenied("constitution must be canonical")
        violations = _policy_constitution_violations(proposal.proposed_initial_root_version, case.constitution)
        observed = not violations
        passed = observed == bool(case.expected_compatible)
        payload = {
            "case_id": case.case_id,
            "constitution_digest": case.constitution.constitution_digest,
            "expected_compatible": bool(case.expected_compatible),
            "observed_compatible": observed,
            "violations": violations,
            "passed": passed,
        }
        digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        canonical = canonical_json_bytes({**payload, "case_digest": digest})
        results.append(
            GenerationCompatibilityCaseEvidence(
                **payload,
                case_digest=digest,
                canonical_bytes=canonical,
            )
        )
    all_passed = all(item.passed for item in results)
    payload = {
        "fork_id": proposal.fork_id,
        "proposed_genesis_digest": proposal.proposed_genesis_digest,
        "proposed_root_digest": proposal.proposed_initial_root_digest,
        "case_results": tuple(results),
        "passed": all_passed,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "compatibility_digest": digest})
    return GenerationCompatibilityEvidence(
        **payload,
        compatibility_digest=digest,
        canonical_bytes=canonical,
    )


from .errors import InvalidGenerationTransitionEvidence


@dataclass(frozen=True)
class GenerationEntityTransitionEvidence:
    source_generation_id: str
    target_generation_id: str
    source_entity_uid: str
    target_entity_uid: str
    source_identity_root: str
    target_identity_root: str
    source_preserved: bool
    source_retired: bool
    state_direct_duplicate: bool
    shared_pre_transition_history: bool
    explicit_transition_kind: GenerationEntityTransitionKind | None
    observed_transition_kind: GenerationEntityTransitionKind
    declared_matches_observed: bool | None
    classification_digest: str
    subjectivity_claimed: bool
    legal_identity_claimed: bool
    canonical_bytes: bytes


def classify_generation_entity_transition(
    *,
    source_generation_id: str,
    target_generation_id: str,
    source_entity_uid: str,
    target_entity_uid: str,
    source_identity_root: str,
    target_identity_root: str,
    source_preserved: bool,
    source_retired: bool,
    state_direct_duplicate: bool,
    shared_pre_transition_history: bool,
    explicit_transition_kind: GenerationEntityTransitionKind | None = None,
) -> GenerationEntityTransitionEvidence:
    identifiers = {
        "source_generation_id": source_generation_id,
        "target_generation_id": target_generation_id,
        "source_entity_uid": source_entity_uid,
        "target_entity_uid": target_entity_uid,
        "source_identity_root": source_identity_root,
        "target_identity_root": target_identity_root,
    }
    if any(not str(value).strip() for value in identifiers.values()):
        raise InvalidGenerationTransitionEvidence("transition identifiers must be non-empty")
    if explicit_transition_kind is not None and not isinstance(explicit_transition_kind, GenerationEntityTransitionKind):
        raise InvalidGenerationTransitionEvidence("explicit_transition_kind must be canonical")

    if source_generation_id == target_generation_id:
        observed = GenerationEntityTransitionKind.STAY
    elif (
        source_entity_uid == target_entity_uid
        and source_identity_root == target_identity_root
        and source_retired
        and not source_preserved
    ):
        observed = GenerationEntityTransitionKind.MIGRATE
    elif (
        source_preserved
        and shared_pre_transition_history
        and target_entity_uid != source_entity_uid
        and not state_direct_duplicate
    ):
        observed = GenerationEntityTransitionKind.FORK_TO_NEW_GENERATION
    elif source_preserved and target_entity_uid != source_entity_uid and state_direct_duplicate:
        observed = GenerationEntityTransitionKind.COPY_TO_NEW_GENERATION
    else:
        observed = GenerationEntityTransitionKind.UNRESOLVED

    declared_matches = None if explicit_transition_kind is None else explicit_transition_kind is observed
    payload = {
        **identifiers,
        "source_preserved": bool(source_preserved),
        "source_retired": bool(source_retired),
        "state_direct_duplicate": bool(state_direct_duplicate),
        "shared_pre_transition_history": bool(shared_pre_transition_history),
        "explicit_transition_kind": explicit_transition_kind,
        "observed_transition_kind": observed,
        "declared_matches_observed": declared_matches,
        "subjectivity_claimed": False,
        "legal_identity_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "classification_digest": digest})
    return GenerationEntityTransitionEvidence(
        **payload,
        classification_digest=digest,
        canonical_bytes=canonical,
    )


from .errors import (
    GenerationForkReviewDenied,
    GenerationRatificationDenied,
    StaleGenerationForkProposal,
    GenerationAdoptionDenied,
)


@dataclass(frozen=True)
class GenerationEdge:
    edge_id: str
    relation_kind: GenerationRelationKind
    source_generation_id: str
    target_generation_id: str
    fork_id: str
    review_digest: str
    ratification_digest: str
    compatibility_digest: str
    timestamp: str
    canonical_bytes: bytes


class GenerationGraph:
    def __init__(self) -> None:
        self._nodes: dict[str, RuntimeGeneration] = {}
        self._edges: list[GenerationEdge] = []

    @property
    def nodes(self) -> tuple[RuntimeGeneration, ...]:
        return tuple(self._nodes.values())

    @property
    def edges(self) -> tuple[GenerationEdge, ...]:
        return tuple(self._edges)

    @property
    def heads(self) -> tuple[RuntimeGeneration, ...]:
        parents = {edge.source_generation_id for edge in self._edges}
        return tuple(node for node in self._nodes.values() if node.generation_id not in parents)

    def add_initial(self, generation: RuntimeGeneration) -> None:
        if self._nodes:
            raise GenerationAdoptionDenied("generation graph is already initialized")
        self._nodes[generation.generation_id] = generation

    def append(self, generation: RuntimeGeneration, edge: GenerationEdge) -> None:
        if generation.generation_id in self._nodes:
            raise GenerationAdoptionDenied("generation already exists")
        if edge.source_generation_id not in self._nodes:
            raise GenerationAdoptionDenied("source generation is unknown")
        if edge.target_generation_id != generation.generation_id:
            raise GenerationAdoptionDenied("edge target does not match generation")
        self._nodes[generation.generation_id] = generation
        self._edges.append(edge)

    def get(self, generation_id: str) -> RuntimeGeneration:
        try:
            return self._nodes[generation_id]
        except KeyError as exc:
            raise StaleGenerationForkProposal("generation is not registered") from exc

    def children_of(self, generation_id: str) -> tuple[RuntimeGeneration, ...]:
        child_ids = [edge.target_generation_id for edge in self._edges if edge.source_generation_id == generation_id]
        return tuple(self._nodes[child_id] for child_id in child_ids)


@dataclass(frozen=True)
class GenerationAdoptionEvidence:
    fork_id: str
    base_generation_id: str
    base_generation_digest: str
    new_generation_id: str
    new_generation_digest: str
    relation_kind: GenerationRelationKind
    review_digest: str
    ratification_digest: str
    compatibility_digest: str
    source_generation_preserved: bool
    entity_auto_migrated: bool
    status: str
    timestamp: str
    adoption_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


class RuntimeGenerationRegistry:
    def __init__(self, generation_family_id: str) -> None:
        if not generation_family_id.strip():
            raise GenerationAdoptionDenied("generation_family_id must be non-empty")
        self.generation_family_id = generation_family_id
        self._graph = GenerationGraph()
        self._adoptions: list[GenerationAdoptionEvidence] = []
        self._adopted_fork_ids: set[str] = set()

    @property
    def graph(self) -> GenerationGraph:
        return self._graph

    @property
    def generations(self) -> tuple[RuntimeGeneration, ...]:
        return self._graph.nodes

    @property
    def generation_heads(self) -> tuple[RuntimeGeneration, ...]:
        return self._graph.heads

    @property
    def adoptions(self) -> tuple[GenerationAdoptionEvidence, ...]:
        return tuple(self._adoptions)

    def get_generation(self, generation_id: str) -> RuntimeGeneration:
        return self._graph.get(generation_id)

    def initialize(self, generation: RuntimeGeneration) -> RuntimeGeneration:
        if self._graph.nodes:
            raise GenerationAdoptionDenied("generation registry is already initialized")
        if not isinstance(generation, RuntimeGeneration):
            raise GenerationAdoptionDenied("generation must be canonical")
        if generation.generation_family_id != self.generation_family_id:
            raise GenerationAdoptionDenied("generation family mismatch")
        if generation.generation_number != 1 or generation.parent_generation_id is not None:
            raise GenerationAdoptionDenied("initial generation must be generation 1 without parent")
        self._graph.add_initial(generation)
        return generation

    def adopt(
        self,
        proposal: GenerationForkProposal,
        review: GenerationForkReviewEvidence,
        ratification: GenerationRatificationEvidence,
        compatibility: GenerationCompatibilityEvidence,
        *,
        timestamp: str = "UNSPECIFIED",
    ) -> GenerationAdoptionEvidence:
        if not isinstance(proposal, GenerationForkProposal):
            raise GenerationAdoptionDenied("proposal must be canonical")
        try:
            base = self._graph.get(proposal.base_generation_id)
        except StaleGenerationForkProposal:
            raise
        if base.generation_digest != proposal.base_generation_digest:
            raise StaleGenerationForkProposal("base generation digest mismatch")
        if proposal.fork_id in self._adopted_fork_ids:
            raise GenerationAdoptionDenied("generation fork was already adopted")

        if not isinstance(review, GenerationForkReviewEvidence) or review.fork_id != proposal.fork_id:
            raise GenerationAdoptionDenied("review does not bind exact fork")
        if review.base_generation_id != base.generation_id or review.base_generation_digest != base.generation_digest:
            raise GenerationAdoptionDenied("review base generation binding mismatch")
        if not review.passed:
            raise GenerationForkReviewDenied("generation boundary review failed")

        if not isinstance(ratification, GenerationRatificationEvidence) or ratification.fork_id != proposal.fork_id:
            raise GenerationAdoptionDenied("ratification does not bind exact fork")
        if ratification.base_genesis_digest != base.genesis_digest:
            raise GenerationAdoptionDenied("ratification used the wrong base Genesis")
        if not ratification.passed:
            raise GenerationRatificationDenied("generation ratification failed")

        if not isinstance(compatibility, GenerationCompatibilityEvidence) or compatibility.fork_id != proposal.fork_id:
            raise GenerationAdoptionDenied("compatibility evidence does not bind exact fork")
        if compatibility.proposed_genesis_digest != proposal.proposed_genesis_digest:
            raise GenerationAdoptionDenied("compatibility Genesis binding mismatch")
        if compatibility.proposed_root_digest != proposal.proposed_initial_root_digest:
            raise GenerationAdoptionDenied("compatibility root binding mismatch")
        if not compatibility.passed:
            raise GenerationCompatibilityValidationDenied("generation compatibility validation failed")

        if not proposal.migration_policy.preserve_source_generation:
            raise GenerationAdoptionDenied("source generation preservation is required")
        if proposal.migration_policy.allow_automatic_entity_migration:
            raise GenerationAdoptionDenied("automatic entity migration is forbidden")

        child = _runtime_generation(
            generation_number=proposal.proposed_generation_number,
            generation_family_id=base.generation_family_id,
            ontology_profile=proposal.proposed_ontology_profile,
            genesis_envelope=proposal.proposed_genesis_envelope,
            initial_root_version=proposal.proposed_initial_root_version,
            parent_generation_id=base.generation_id,
            parent_generation_digest=base.generation_digest,
            created_from_fork_id=proposal.fork_id,
            created_at=timestamp,
        )
        edge_payload = {
            "relation_kind": review.observed_relation_kind,
            "source_generation_id": base.generation_id,
            "target_generation_id": child.generation_id,
            "fork_id": proposal.fork_id,
            "review_digest": review.review_digest,
            "ratification_digest": ratification.ratification_digest,
            "compatibility_digest": compatibility.compatibility_digest,
            "timestamp": timestamp,
        }
        edge_id = hashlib.sha256(canonical_json_bytes(edge_payload)).hexdigest()
        edge = GenerationEdge(
            edge_id=edge_id,
            **edge_payload,
            canonical_bytes=canonical_json_bytes({"edge_id": edge_id, **edge_payload}),
        )
        adoption_payload = {
            "fork_id": proposal.fork_id,
            "base_generation_id": base.generation_id,
            "base_generation_digest": base.generation_digest,
            "new_generation_id": child.generation_id,
            "new_generation_digest": child.generation_digest,
            "relation_kind": review.observed_relation_kind,
            "review_digest": review.review_digest,
            "ratification_digest": ratification.ratification_digest,
            "compatibility_digest": compatibility.compatibility_digest,
            "source_generation_preserved": True,
            "entity_auto_migrated": False,
            "status": "ADOPTED",
            "timestamp": timestamp,
            "subjectivity_claimed": False,
            "free_will_claimed": False,
            "autonomy_claimed": False,
            "political_legitimacy_claimed": False,
        }
        adoption_digest = hashlib.sha256(canonical_json_bytes(adoption_payload)).hexdigest()
        adoption = GenerationAdoptionEvidence(
            **adoption_payload,
            adoption_digest=adoption_digest,
            canonical_bytes=canonical_json_bytes({**adoption_payload, "adoption_digest": adoption_digest}),
        )

        self._graph.append(child, edge)
        self._adoptions.append(adoption)
        self._adopted_fork_ids.add(proposal.fork_id)
        return adoption
