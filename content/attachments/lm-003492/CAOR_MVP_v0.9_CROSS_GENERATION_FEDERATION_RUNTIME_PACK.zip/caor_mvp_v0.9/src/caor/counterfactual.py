from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from enum import Enum
import hashlib
from itertools import combinations
from typing import Any, Mapping, Sequence

from .canonical import canonical_json_bytes
from .divergence import (
    DivergenceSnapshot,
    compute_divergence_timeline,
    development_value_distance,
    origin_state_projection,
)
from .entity import OffspringEntity
from .errors import (
    InvalidContributionBundle,
    InvalidCounterfactualAction,
    InvalidCounterfactualBranch,
    ManifestIntegrityError,
)
from .models import ContributionManifest, OffspringIdentitySpecification


class CounterfactualActionKind(str, Enum):
    SELF_UPDATE = "SELF_UPDATE"
    ENVIRONMENT_EVENT = "ENVIRONMENT_EVENT"
    SOURCE_PROPOSAL = "SOURCE_PROPOSAL"


@dataclass(frozen=True)
class CounterfactualAction:
    action_kind: CounterfactualActionKind
    region: str
    key: str
    value: Any
    external_id: str | None = None
    timestamp: str = "UNSPECIFIED"
    evidence: Mapping[str, Any] | None = None


@dataclass(frozen=True)
class CounterfactualBranchSpec:
    branch_label: str
    actions: tuple[CounterfactualAction, ...]
    feasibility_note: str = "caller-specified scenario"


@dataclass(frozen=True)
class CounterfactualTrajectory:
    offspring_uid: str
    branch_id: str
    branch_label: str
    spec_digest: str
    event_count: int
    ledger_digest: str
    final_state_digest: str
    final_projected_state: Mapping[str, Mapping[str, Any]]
    events: tuple[Any, ...]
    divergence_timeline: tuple[DivergenceSnapshot, ...]
    canonical_bytes: bytes


@dataclass(frozen=True)
class CounterfactualBranchComparison:
    left_branch_id: str
    right_branch_id: str
    left_branch_label: str
    right_branch_label: str
    left_final_state_digest: str
    right_final_state_digest: str
    state_distance: float
    changed_keys: tuple[str, ...]
    canonical_bytes: bytes


@dataclass(frozen=True)
class CounterfactualEvidenceBundle:
    offspring_uid: str
    manifest_digest: str
    ois_digest: str
    branch_count: int
    unique_trajectory_count: int
    unique_final_state_count: int
    alternative_trajectories_observed: bool
    trajectories: tuple[CounterfactualTrajectory, ...]
    pairwise_comparisons: tuple[CounterfactualBranchComparison, ...]
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def _validate_origin(ois: OffspringIdentitySpecification, manifest: ContributionManifest) -> None:
    if ois.manifest_digest != manifest.digest:
        raise ManifestIntegrityError("OIS manifest digest does not match contribution manifest")


def _spec_digest(ois: OffspringIdentitySpecification, manifest: ContributionManifest, spec: CounterfactualBranchSpec) -> str:
    if not spec.branch_label.strip():
        raise InvalidCounterfactualBranch("branch_label must be non-empty")
    payload = {
        "offspring_uid": ois.offspring_uid,
        "manifest_digest": manifest.digest,
        "branch_spec": spec,
    }
    return hashlib.sha256(canonical_json_bytes(payload)).hexdigest()


def _project_final_state(
    manifest: ContributionManifest,
    mutable_state: Mapping[str, Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    projected = deepcopy(origin_state_projection(manifest))
    for region, values in mutable_state.items():
        projected.setdefault(region, {})
        for key, value in values.items():
            projected[region][key] = value
    return projected


def _apply_action(entity: OffspringEntity, action: CounterfactualAction) -> None:
    if not isinstance(action.action_kind, CounterfactualActionKind):
        raise InvalidCounterfactualAction(f"noncanonical counterfactual action: {action.action_kind}")
    evidence = dict(action.evidence or {})
    if action.action_kind is CounterfactualActionKind.SELF_UPDATE:
        if action.external_id is not None:
            raise InvalidCounterfactualAction("SELF_UPDATE does not accept external_id")
        entity.self_update(
            action.region,
            action.key,
            action.value,
            timestamp=action.timestamp,
            evidence=evidence,
        )
        return
    if action.action_kind is CounterfactualActionKind.ENVIRONMENT_EVENT:
        if not action.external_id:
            raise InvalidCounterfactualAction("ENVIRONMENT_EVENT requires external_id")
        entity.apply_environment_event(
            action.region,
            action.key,
            action.value,
            action.external_id,
            timestamp=action.timestamp,
            evidence=evidence,
        )
        return
    if action.action_kind is CounterfactualActionKind.SOURCE_PROPOSAL:
        if not action.external_id:
            raise InvalidCounterfactualAction("SOURCE_PROPOSAL requires external_id")
        if action.external_id not in entity.ois.parent_contributions:
            raise InvalidContributionBundle(f"{action.external_id} is not a source contributor")
        proposal = entity.propose_update(
            action.external_id,
            action.region,
            action.key,
            action.value,
        )
        entity.accept_proposal(proposal.proposal_id, timestamp=action.timestamp)
        return
    raise InvalidCounterfactualAction(f"unsupported counterfactual action: {action.action_kind}")


def run_counterfactual_branch(
    ois: OffspringIdentitySpecification,
    manifest: ContributionManifest,
    spec: CounterfactualBranchSpec,
) -> CounterfactualTrajectory:
    _validate_origin(ois, manifest)
    spec_digest = _spec_digest(ois, manifest, spec)
    branch_id = hashlib.sha256(
        canonical_json_bytes({
            "kind": "counterfactual-development-branch",
            "offspring_uid": ois.offspring_uid,
            "spec_digest": spec_digest,
        })
    ).hexdigest()

    entity = OffspringEntity(ois)
    for action in spec.actions:
        _apply_action(entity, action)

    timeline = compute_divergence_timeline(ois, manifest, entity.development_events)
    final_projected_state = _project_final_state(manifest, entity.mutable_state)
    final_state_digest = hashlib.sha256(canonical_json_bytes(final_projected_state)).hexdigest()
    payload = {
        "offspring_uid": ois.offspring_uid,
        "branch_id": branch_id,
        "branch_label": spec.branch_label,
        "spec_digest": spec_digest,
        "event_count": len(entity.development_events),
        "ledger_digest": entity.development_digest,
        "final_state_digest": final_state_digest,
        "final_projected_state": final_projected_state,
        "events": entity.development_events,
        "divergence_timeline": timeline,
    }
    canonical = canonical_json_bytes(payload)
    return CounterfactualTrajectory(
        offspring_uid=ois.offspring_uid,
        branch_id=branch_id,
        branch_label=spec.branch_label,
        spec_digest=spec_digest,
        event_count=len(entity.development_events),
        ledger_digest=entity.development_digest,
        final_state_digest=final_state_digest,
        final_projected_state=final_projected_state,
        events=entity.development_events,
        divergence_timeline=timeline,
        canonical_bytes=canonical,
    )


def _flatten(state: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for region in sorted(state):
        for key in sorted(state[region]):
            result[f"{region}.{key}"] = state[region][key]
    return result


def compare_counterfactual_trajectories(
    left: CounterfactualTrajectory,
    right: CounterfactualTrajectory,
) -> CounterfactualBranchComparison:
    if left.offspring_uid != right.offspring_uid:
        raise InvalidCounterfactualBranch("trajectories must share the same offspring origin")
    left_flat = _flatten(left.final_projected_state)
    right_flat = _flatten(right.final_projected_state)
    keys = sorted(set(left_flat) | set(right_flat))
    changed: list[str] = []
    distances: list[float] = []
    missing = object()
    for key in keys:
        left_value = left_flat.get(key, missing)
        right_value = right_flat.get(key, missing)
        if left_value is missing or right_value is missing:
            distance = 1.0
        else:
            distance = development_value_distance(left_value, right_value)
        distances.append(distance)
        if distance != 0.0:
            changed.append(key)
    state_distance = sum(distances) / len(distances) if distances else 0.0
    payload = {
        "left_branch_id": left.branch_id,
        "right_branch_id": right.branch_id,
        "left_branch_label": left.branch_label,
        "right_branch_label": right.branch_label,
        "left_final_state_digest": left.final_state_digest,
        "right_final_state_digest": right.final_state_digest,
        "state_distance": state_distance,
        "changed_keys": tuple(changed),
    }
    canonical = canonical_json_bytes(payload)
    return CounterfactualBranchComparison(
        left_branch_id=left.branch_id,
        right_branch_id=right.branch_id,
        left_branch_label=left.branch_label,
        right_branch_label=right.branch_label,
        left_final_state_digest=left.final_state_digest,
        right_final_state_digest=right.final_state_digest,
        state_distance=state_distance,
        changed_keys=tuple(changed),
        canonical_bytes=canonical,
    )


def build_counterfactual_evidence(
    ois: OffspringIdentitySpecification,
    manifest: ContributionManifest,
    specs: Sequence[CounterfactualBranchSpec],
) -> CounterfactualEvidenceBundle:
    _validate_origin(ois, manifest)
    labels = [spec.branch_label for spec in specs]
    if len(labels) != len(set(labels)):
        raise InvalidCounterfactualBranch("branch labels must be unique")
    trajectories = tuple(run_counterfactual_branch(ois, manifest, spec) for spec in specs)
    comparisons = tuple(
        compare_counterfactual_trajectories(left, right)
        for left, right in combinations(trajectories, 2)
    )
    unique_trajectory_count = len({trajectory.ledger_digest for trajectory in trajectories})
    unique_final_state_count = len({trajectory.final_state_digest for trajectory in trajectories})
    alternative_trajectories_observed = unique_trajectory_count > 1
    ois_digest = hashlib.sha256(ois.canonical_bytes).hexdigest()
    payload = {
        "offspring_uid": ois.offspring_uid,
        "manifest_digest": manifest.digest,
        "ois_digest": ois_digest,
        "branch_count": len(trajectories),
        "unique_trajectory_count": unique_trajectory_count,
        "unique_final_state_count": unique_final_state_count,
        "alternative_trajectories_observed": alternative_trajectories_observed,
        "trajectories": trajectories,
        "pairwise_comparisons": comparisons,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    canonical = canonical_json_bytes(payload)
    return CounterfactualEvidenceBundle(
        offspring_uid=ois.offspring_uid,
        manifest_digest=manifest.digest,
        ois_digest=ois_digest,
        branch_count=len(trajectories),
        unique_trajectory_count=unique_trajectory_count,
        unique_final_state_count=unique_final_state_count,
        alternative_trajectories_observed=alternative_trajectories_observed,
        trajectories=trajectories,
        pairwise_comparisons=comparisons,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )
