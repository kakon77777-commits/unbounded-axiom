from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from typing import Any

from .canonical import canonical_json_bytes
from .errors import (
    ForbiddenBoundaryAuthority,
    InvalidBoundaryContractProposal,
    InvalidBoundaryDisclosurePolicy,
    InvalidOntologyTranslationProfile,
)
from .generation import RuntimeGeneration


class BoundaryAuthorityKind(str, Enum):
    READ = "READ"
    PROPOSE = "PROPOSE"
    EXECUTE = "EXECUTE"
    WRITE_MUTABLE = "WRITE_MUTABLE"
    WRITE_PROTECTED = "WRITE_PROTECTED"
    ADMIN = "ADMIN"


class DisclosureRetentionMode(str, Enum):
    NO_RETENTION = "NO_RETENTION"
    SESSION_ONLY = "SESSION_ONLY"
    CONTRACT_LIFETIME = "CONTRACT_LIFETIME"


@dataclass(frozen=True)
class BoundaryDisclosurePolicy:
    allowed_data_scopes: tuple[str, ...]
    retention_mode: DisclosureRetentionMode
    allow_derivative_use: bool
    allow_redisclosure: bool
    policy_digest: str
    canonical_bytes: bytes


def _normalized_strings(values: tuple[str, ...], *, field: str, error_type: type[Exception]) -> tuple[str, ...]:
    if not values:
        raise error_type(f"{field} must be non-empty")
    normalized = tuple(sorted(set(values)))
    if any(not isinstance(value, str) or not value.strip() for value in normalized):
        raise error_type(f"{field} must contain non-empty strings")
    return normalized


def create_boundary_disclosure_policy(
    *,
    allowed_data_scopes: tuple[str, ...],
    retention_mode: DisclosureRetentionMode,
    allow_derivative_use: bool = False,
    allow_redisclosure: bool = False,
) -> BoundaryDisclosurePolicy:
    scopes = _normalized_strings(
        allowed_data_scopes,
        field="allowed_data_scopes",
        error_type=InvalidBoundaryDisclosurePolicy,
    )
    if not isinstance(retention_mode, DisclosureRetentionMode):
        raise InvalidBoundaryDisclosurePolicy("retention_mode must be canonical")
    payload = {
        "allowed_data_scopes": scopes,
        "retention_mode": retention_mode,
        "allow_derivative_use": bool(allow_derivative_use),
        "allow_redisclosure": bool(allow_redisclosure),
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return BoundaryDisclosurePolicy(
        **payload,
        policy_digest=digest,
        canonical_bytes=canonical_json_bytes({**payload, "policy_digest": digest}),
    )


@dataclass(frozen=True)
class OntologyTranslationEntry:
    entity_uid: str
    source_classification: str
    target_classification: str
    contested: bool
    note: str


def create_ontology_translation_entry(
    *,
    entity_uid: str,
    source_classification: str,
    target_classification: str,
    contested: bool = False,
    note: str = "",
) -> OntologyTranslationEntry:
    if not entity_uid.strip():
        raise InvalidOntologyTranslationProfile("entity_uid must be non-empty")
    if not source_classification.strip() or not target_classification.strip():
        raise InvalidOntologyTranslationProfile("classifications must be non-empty")
    return OntologyTranslationEntry(
        entity_uid=entity_uid,
        source_classification=source_classification,
        target_classification=target_classification,
        contested=bool(contested),
        note=str(note),
    )


@dataclass(frozen=True)
class OntologyTranslationProfile:
    profile_id: str
    entries: tuple[OntologyTranslationEntry, ...]
    identity_rewrite_performed: bool
    ontology_assimilation_performed: bool
    profile_digest: str
    canonical_bytes: bytes


def create_ontology_translation_profile(
    *,
    profile_id: str,
    entries: tuple[OntologyTranslationEntry, ...],
) -> OntologyTranslationProfile:
    if not profile_id.strip():
        raise InvalidOntologyTranslationProfile("profile_id must be non-empty")
    if any(not isinstance(entry, OntologyTranslationEntry) for entry in entries):
        raise InvalidOntologyTranslationProfile("entries must be canonical")
    normalized = tuple(
        sorted(
            entries,
            key=lambda entry: (
                entry.entity_uid,
                entry.source_classification,
                entry.target_classification,
                entry.contested,
                entry.note,
            ),
        )
    )
    keys = [(entry.entity_uid, entry.source_classification, entry.target_classification) for entry in normalized]
    if len(set(keys)) != len(keys):
        raise InvalidOntologyTranslationProfile("duplicate translation entry")
    payload = {
        "profile_id": profile_id,
        "entries": normalized,
        "identity_rewrite_performed": False,
        "ontology_assimilation_performed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return OntologyTranslationProfile(
        **payload,
        profile_digest=digest,
        canonical_bytes=canonical_json_bytes({**payload, "profile_digest": digest}),
    )


@dataclass(frozen=True)
class BoundaryContractProposal:
    proposal_id: str
    proposal_digest: str
    generation_a_id: str
    generation_a_digest: str
    generation_b_id: str
    generation_b_digest: str
    allowed_capabilities: tuple[str, ...]
    allowed_authorities: tuple[BoundaryAuthorityKind, ...]
    disclosure_policy: BoundaryDisclosurePolicy
    disclosure_policy_digest: str
    ontology_translation_profile: OntologyTranslationProfile | None
    ontology_translation_profile_digest: str | None
    ontology_non_assimilation: bool
    local_standing_non_rewrite: bool
    revocation_allowed: bool
    expires_at: str | None
    created_at: str
    subjective_consent_proven: bool
    legal_contract_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def create_boundary_contract_proposal(
    *,
    generation_a: RuntimeGeneration,
    generation_b: RuntimeGeneration,
    allowed_capabilities: tuple[str, ...],
    allowed_authorities: tuple[BoundaryAuthorityKind, ...],
    disclosure_policy: BoundaryDisclosurePolicy,
    ontology_translation_profile: OntologyTranslationProfile | None = None,
    ontology_non_assimilation: bool = True,
    local_standing_non_rewrite: bool = True,
    revocation_allowed: bool = True,
    expires_at: str | None = None,
    created_at: str = "UNSPECIFIED",
) -> BoundaryContractProposal:
    if not isinstance(generation_a, RuntimeGeneration) or not isinstance(generation_b, RuntimeGeneration):
        raise InvalidBoundaryContractProposal("generation endpoints must be canonical")
    if generation_a.generation_id == generation_b.generation_id:
        raise InvalidBoundaryContractProposal("generation endpoints must be distinct")
    capabilities = _normalized_strings(
        allowed_capabilities,
        field="allowed_capabilities",
        error_type=InvalidBoundaryContractProposal,
    )
    if not allowed_authorities or any(not isinstance(item, BoundaryAuthorityKind) for item in allowed_authorities):
        raise InvalidBoundaryContractProposal("allowed_authorities must be canonical and non-empty")
    authorities = tuple(sorted(set(allowed_authorities), key=lambda item: item.value))
    forbidden = {BoundaryAuthorityKind.WRITE_PROTECTED, BoundaryAuthorityKind.ADMIN}
    if any(item in forbidden for item in authorities):
        raise ForbiddenBoundaryAuthority("cross-generation protected/admin authority is forbidden")
    if not isinstance(disclosure_policy, BoundaryDisclosurePolicy):
        raise InvalidBoundaryContractProposal("disclosure_policy must be canonical")
    if ontology_translation_profile is not None and not isinstance(
        ontology_translation_profile, OntologyTranslationProfile
    ):
        raise InvalidBoundaryContractProposal("ontology_translation_profile must be canonical")
    if not ontology_non_assimilation:
        raise InvalidBoundaryContractProposal("ontology_non_assimilation must remain enabled")
    if not local_standing_non_rewrite:
        raise InvalidBoundaryContractProposal("local_standing_non_rewrite must remain enabled")
    payload: dict[str, Any] = {
        "generation_a_id": generation_a.generation_id,
        "generation_a_digest": generation_a.generation_digest,
        "generation_b_id": generation_b.generation_id,
        "generation_b_digest": generation_b.generation_digest,
        "allowed_capabilities": capabilities,
        "allowed_authorities": authorities,
        "disclosure_policy": disclosure_policy,
        "disclosure_policy_digest": disclosure_policy.policy_digest,
        "ontology_translation_profile": ontology_translation_profile,
        "ontology_translation_profile_digest": (
            ontology_translation_profile.profile_digest if ontology_translation_profile else None
        ),
        "ontology_non_assimilation": True,
        "local_standing_non_rewrite": True,
        "revocation_allowed": bool(revocation_allowed),
        "expires_at": expires_at,
        "created_at": created_at,
        "subjective_consent_proven": False,
        "legal_contract_claimed": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return BoundaryContractProposal(
        proposal_id=digest,
        proposal_digest=digest,
        **payload,
        canonical_bytes=canonical_json_bytes({"proposal_id": digest, "proposal_digest": digest, **payload}),
    )


class BoundaryAuthorizationDecision(str, Enum):
    AUTHORIZE = "AUTHORIZE"
    REJECT = "REJECT"


@dataclass(frozen=True)
class BoundaryAuthorizationAttestation:
    attestation_id: str
    proposal_digest: str
    generation_id: str
    generation_digest: str
    decision: BoundaryAuthorizationDecision
    note: str
    timestamp: str
    canonical_bytes: bytes


def create_boundary_authorization_attestation(
    *,
    proposal: BoundaryContractProposal,
    generation: RuntimeGeneration,
    decision: BoundaryAuthorizationDecision,
    note: str = "",
    timestamp: str = "UNSPECIFIED",
) -> BoundaryAuthorizationAttestation:
    from .errors import InvalidBoundaryAuthorizationAttestation, UnknownBoundaryEndpoint

    if not isinstance(proposal, BoundaryContractProposal):
        raise InvalidBoundaryAuthorizationAttestation("proposal must be canonical")
    if not isinstance(generation, RuntimeGeneration):
        raise InvalidBoundaryAuthorizationAttestation("generation must be canonical")
    if not isinstance(decision, BoundaryAuthorizationDecision):
        raise InvalidBoundaryAuthorizationAttestation("decision must be canonical")
    endpoints = {
        proposal.generation_a_id: proposal.generation_a_digest,
        proposal.generation_b_id: proposal.generation_b_digest,
    }
    if generation.generation_id not in endpoints or endpoints[generation.generation_id] != generation.generation_digest:
        raise UnknownBoundaryEndpoint("generation is not a bound contract endpoint")
    payload = {
        "proposal_digest": proposal.proposal_digest,
        "generation_id": generation.generation_id,
        "generation_digest": generation.generation_digest,
        "decision": decision,
        "note": str(note),
        "timestamp": timestamp,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return BoundaryAuthorizationAttestation(
        attestation_id=digest,
        **payload,
        canonical_bytes=canonical_json_bytes({"attestation_id": digest, **payload}),
    )


@dataclass(frozen=True)
class BoundaryAuthorizationEvidence:
    proposal_digest: str
    endpoint_generation_ids: tuple[str, str]
    received_attestations: tuple[BoundaryAuthorizationAttestation, ...]
    authorized_generation_ids: tuple[str, ...]
    rejected_generation_ids: tuple[str, ...]
    missing_generation_ids: tuple[str, ...]
    approval_count: int
    rejection_count: int
    passed: bool
    authorization_digest: str
    subjective_consent_proven: bool
    legal_contract_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def aggregate_boundary_authorization(
    *,
    proposal: BoundaryContractProposal,
    attestations: tuple[BoundaryAuthorizationAttestation, ...],
) -> BoundaryAuthorizationEvidence:
    from .errors import (
        DuplicateBoundaryAuthorization,
        InvalidBoundaryAuthorizationAttestation,
        UnknownBoundaryEndpoint,
    )

    if not isinstance(proposal, BoundaryContractProposal):
        raise InvalidBoundaryAuthorizationAttestation("proposal must be canonical")
    endpoint_ids = tuple(sorted((proposal.generation_a_id, proposal.generation_b_id)))
    seen: set[str] = set()
    normalized: list[BoundaryAuthorizationAttestation] = []
    for item in attestations:
        if not isinstance(item, BoundaryAuthorizationAttestation):
            raise InvalidBoundaryAuthorizationAttestation("attestations must be canonical")
        if item.proposal_digest != proposal.proposal_digest:
            raise InvalidBoundaryAuthorizationAttestation("attestation is bound to another proposal")
        expected = {
            proposal.generation_a_id: proposal.generation_a_digest,
            proposal.generation_b_id: proposal.generation_b_digest,
        }
        if item.generation_id not in expected or expected[item.generation_id] != item.generation_digest:
            raise UnknownBoundaryEndpoint("attestation endpoint is not bound to proposal")
        if item.generation_id in seen:
            raise DuplicateBoundaryAuthorization("duplicate endpoint attestation")
        seen.add(item.generation_id)
        normalized.append(item)
    normalized.sort(key=lambda item: item.generation_id)
    authorized = tuple(
        item.generation_id for item in normalized if item.decision is BoundaryAuthorizationDecision.AUTHORIZE
    )
    rejected = tuple(
        item.generation_id for item in normalized if item.decision is BoundaryAuthorizationDecision.REJECT
    )
    missing = tuple(item for item in endpoint_ids if item not in seen)
    passed = not rejected and not missing and len(authorized) == 2
    payload = {
        "proposal_digest": proposal.proposal_digest,
        "endpoint_generation_ids": endpoint_ids,
        "received_attestations": tuple(normalized),
        "authorized_generation_ids": authorized,
        "rejected_generation_ids": rejected,
        "missing_generation_ids": missing,
        "approval_count": len(authorized),
        "rejection_count": len(rejected),
        "passed": passed,
        "subjective_consent_proven": False,
        "legal_contract_claimed": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return BoundaryAuthorizationEvidence(
        **payload,
        authorization_digest=digest,
        canonical_bytes=canonical_json_bytes({**payload, "authorization_digest": digest}),
    )


@dataclass(frozen=True)
class CrossGenerationBoundaryContract:
    contract_id: str
    contract_digest: str
    proposal_digest: str
    authorization_digest: str
    generation_a_id: str
    generation_a_digest: str
    generation_b_id: str
    generation_b_digest: str
    allowed_capabilities: tuple[str, ...]
    allowed_authorities: tuple[BoundaryAuthorityKind, ...]
    disclosure_policy: BoundaryDisclosurePolicy
    disclosure_policy_digest: str
    ontology_translation_profile: OntologyTranslationProfile | None
    ontology_translation_profile_digest: str | None
    ontology_non_assimilation: bool
    local_standing_non_rewrite: bool
    revocation_allowed: bool
    expires_at: str | None
    activated_at: str
    subjective_consent_proven: bool
    legal_contract_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def activate_boundary_contract(
    proposal: BoundaryContractProposal,
    authorization: BoundaryAuthorizationEvidence,
    *,
    activated_at: str = "UNSPECIFIED",
) -> CrossGenerationBoundaryContract:
    from .errors import BoundaryAuthorizationDenied, BoundaryContractActivationDenied

    if not isinstance(proposal, BoundaryContractProposal):
        raise BoundaryContractActivationDenied("proposal must be canonical")
    if not isinstance(authorization, BoundaryAuthorizationEvidence):
        raise BoundaryContractActivationDenied("authorization must be canonical")
    if authorization.proposal_digest != proposal.proposal_digest:
        raise BoundaryContractActivationDenied("authorization does not bind proposal")
    if not authorization.passed:
        raise BoundaryAuthorizationDenied("both generation endpoints must authorize activation")
    payload = {
        "proposal_digest": proposal.proposal_digest,
        "authorization_digest": authorization.authorization_digest,
        "generation_a_id": proposal.generation_a_id,
        "generation_a_digest": proposal.generation_a_digest,
        "generation_b_id": proposal.generation_b_id,
        "generation_b_digest": proposal.generation_b_digest,
        "allowed_capabilities": proposal.allowed_capabilities,
        "allowed_authorities": proposal.allowed_authorities,
        "disclosure_policy": proposal.disclosure_policy,
        "disclosure_policy_digest": proposal.disclosure_policy_digest,
        "ontology_translation_profile": proposal.ontology_translation_profile,
        "ontology_translation_profile_digest": proposal.ontology_translation_profile_digest,
        "ontology_non_assimilation": True,
        "local_standing_non_rewrite": True,
        "revocation_allowed": proposal.revocation_allowed,
        "expires_at": proposal.expires_at,
        "activated_at": activated_at,
        "subjective_consent_proven": False,
        "legal_contract_claimed": False,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return CrossGenerationBoundaryContract(
        contract_id=digest,
        contract_digest=digest,
        **payload,
        canonical_bytes=canonical_json_bytes({"contract_id": digest, "contract_digest": digest, **payload}),
    )


class BoundaryContractLifecycleState(str, Enum):
    ACTIVE = "ACTIVE"
    SUSPENDED = "SUSPENDED"
    REVOKED = "REVOKED"
    EXPIRED = "EXPIRED"


@dataclass(frozen=True)
class BoundaryContractLifecycleEvent:
    event_id: str
    contract_id: str
    contract_digest: str
    from_state: BoundaryContractLifecycleState | None
    to_state: BoundaryContractLifecycleState
    reason: str
    timestamp: str
    canonical_bytes: bytes


class BoundaryContractRegistry:
    def __init__(self) -> None:
        self._contracts: dict[str, CrossGenerationBoundaryContract] = {}
        self._states: dict[str, BoundaryContractLifecycleState] = {}
        self._events: dict[str, list[BoundaryContractLifecycleEvent]] = {}

    def contract(self, contract_id: str) -> CrossGenerationBoundaryContract:
        try:
            return self._contracts[contract_id]
        except KeyError as exc:
            from .errors import InvalidBoundaryContractLifecycle
            raise InvalidBoundaryContractLifecycle("contract is not registered") from exc

    def state(self, contract_id: str) -> BoundaryContractLifecycleState:
        try:
            return self._states[contract_id]
        except KeyError as exc:
            from .errors import InvalidBoundaryContractLifecycle
            raise InvalidBoundaryContractLifecycle("contract is not registered") from exc

    def events(self, contract_id: str) -> tuple[BoundaryContractLifecycleEvent, ...]:
        if contract_id not in self._events:
            from .errors import InvalidBoundaryContractLifecycle
            raise InvalidBoundaryContractLifecycle("contract is not registered")
        return tuple(self._events[contract_id])

    def _append_event(
        self,
        contract: CrossGenerationBoundaryContract,
        *,
        from_state: BoundaryContractLifecycleState | None,
        to_state: BoundaryContractLifecycleState,
        reason: str,
        timestamp: str,
    ) -> BoundaryContractLifecycleEvent:
        payload = {
            "contract_id": contract.contract_id,
            "contract_digest": contract.contract_digest,
            "from_state": from_state,
            "to_state": to_state,
            "reason": str(reason),
            "timestamp": timestamp,
        }
        event_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        event = BoundaryContractLifecycleEvent(
            event_id=event_id,
            **payload,
            canonical_bytes=canonical_json_bytes({"event_id": event_id, **payload}),
        )
        self._events.setdefault(contract.contract_id, []).append(event)
        self._states[contract.contract_id] = to_state
        return event

    def register(
        self,
        contract: CrossGenerationBoundaryContract,
        *,
        timestamp: str = "UNSPECIFIED",
    ) -> BoundaryContractLifecycleEvent:
        from .errors import InvalidBoundaryContractLifecycle
        if not isinstance(contract, CrossGenerationBoundaryContract):
            raise InvalidBoundaryContractLifecycle("contract must be canonical")
        if contract.contract_id in self._contracts:
            raise InvalidBoundaryContractLifecycle("contract is already registered")
        self._contracts[contract.contract_id] = contract
        self._events[contract.contract_id] = []
        return self._append_event(
            contract,
            from_state=None,
            to_state=BoundaryContractLifecycleState.ACTIVE,
            reason="registered",
            timestamp=timestamp,
        )

    def _transition(
        self,
        contract_id: str,
        to_state: BoundaryContractLifecycleState,
        *,
        reason: str,
        timestamp: str,
    ) -> BoundaryContractLifecycleEvent:
        from .errors import InvalidBoundaryContractLifecycle
        contract = self.contract(contract_id)
        current = self.state(contract_id)
        allowed = {
            BoundaryContractLifecycleState.ACTIVE: {
                BoundaryContractLifecycleState.SUSPENDED,
                BoundaryContractLifecycleState.REVOKED,
                BoundaryContractLifecycleState.EXPIRED,
            },
            BoundaryContractLifecycleState.SUSPENDED: {
                BoundaryContractLifecycleState.ACTIVE,
                BoundaryContractLifecycleState.REVOKED,
                BoundaryContractLifecycleState.EXPIRED,
            },
            BoundaryContractLifecycleState.REVOKED: set(),
            BoundaryContractLifecycleState.EXPIRED: set(),
        }
        if to_state not in allowed[current]:
            raise InvalidBoundaryContractLifecycle(f"invalid lifecycle transition: {current.value}->{to_state.value}")
        if to_state is BoundaryContractLifecycleState.REVOKED and not contract.revocation_allowed:
            raise InvalidBoundaryContractLifecycle("contract is not revocable")
        return self._append_event(
            contract,
            from_state=current,
            to_state=to_state,
            reason=reason,
            timestamp=timestamp,
        )

    def suspend(self, contract_id: str, *, reason: str = "", timestamp: str = "UNSPECIFIED"):
        return self._transition(
            contract_id,
            BoundaryContractLifecycleState.SUSPENDED,
            reason=reason,
            timestamp=timestamp,
        )

    def resume(self, contract_id: str, *, reason: str = "", timestamp: str = "UNSPECIFIED"):
        return self._transition(
            contract_id,
            BoundaryContractLifecycleState.ACTIVE,
            reason=reason,
            timestamp=timestamp,
        )

    def revoke(self, contract_id: str, *, reason: str = "", timestamp: str = "UNSPECIFIED"):
        return self._transition(
            contract_id,
            BoundaryContractLifecycleState.REVOKED,
            reason=reason,
            timestamp=timestamp,
        )

    def expire(self, contract_id: str, *, reason: str = "", timestamp: str = "UNSPECIFIED"):
        return self._transition(
            contract_id,
            BoundaryContractLifecycleState.EXPIRED,
            reason=reason,
            timestamp=timestamp,
        )


class CrossGenerationInteractionDecision(str, Enum):
    ALLOWED = "ALLOWED"
    DENIED = "DENIED"


@dataclass(frozen=True)
class CrossGenerationRequest:
    request_id: str
    request_digest: str
    contract_id: str
    contract_digest: str
    source_generation_id: str
    source_generation_digest: str
    target_generation_id: str
    target_generation_digest: str
    actor_id: str
    capability: str
    authority: BoundaryAuthorityKind
    data_scope: str
    payload_digest: str
    created_at: str
    canonical_bytes: bytes


def create_cross_generation_request(
    *,
    contract: CrossGenerationBoundaryContract,
    source_generation: RuntimeGeneration,
    target_generation: RuntimeGeneration,
    actor_id: str,
    capability: str,
    authority: BoundaryAuthorityKind,
    data_scope: str,
    payload_digest: str,
    created_at: str = "UNSPECIFIED",
) -> CrossGenerationRequest:
    from .errors import InvalidCrossGenerationRequest

    if not isinstance(contract, CrossGenerationBoundaryContract):
        raise InvalidCrossGenerationRequest("contract must be canonical")
    if not isinstance(source_generation, RuntimeGeneration) or not isinstance(target_generation, RuntimeGeneration):
        raise InvalidCrossGenerationRequest("generation endpoints must be canonical")
    if not actor_id.strip() or not capability.strip() or not data_scope.strip() or not payload_digest.strip():
        raise InvalidCrossGenerationRequest("actor, capability, data_scope, and payload_digest must be non-empty")
    if not isinstance(authority, BoundaryAuthorityKind):
        raise InvalidCrossGenerationRequest("authority must be canonical")
    payload = {
        "contract_id": contract.contract_id,
        "contract_digest": contract.contract_digest,
        "source_generation_id": source_generation.generation_id,
        "source_generation_digest": source_generation.generation_digest,
        "target_generation_id": target_generation.generation_id,
        "target_generation_digest": target_generation.generation_digest,
        "actor_id": actor_id,
        "capability": capability,
        "authority": authority,
        "data_scope": data_scope,
        "payload_digest": payload_digest,
        "created_at": created_at,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return CrossGenerationRequest(
        request_id=digest,
        request_digest=digest,
        **payload,
        canonical_bytes=canonical_json_bytes({"request_id": digest, "request_digest": digest, **payload}),
    )


@dataclass(frozen=True)
class CrossGenerationInteractionEvidence:
    interaction_id: str
    request_digest: str
    contract_digest: str
    source_generation_id: str
    target_generation_id: str
    capability: str
    authority: BoundaryAuthorityKind
    data_scope: str
    decision: CrossGenerationInteractionDecision
    reason: str
    result_digest: str
    ontology_assimilation_performed: bool
    identity_rewrite_performed: bool
    protected_write_performed: bool
    subjective_consent_proven: bool
    legal_contract_claimed: bool
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def _interaction_evidence(
    request: CrossGenerationRequest,
    contract: CrossGenerationBoundaryContract,
    *,
    decision: CrossGenerationInteractionDecision,
    reason: str,
) -> CrossGenerationInteractionEvidence:
    result_payload = {
        "request_digest": request.request_digest,
        "contract_digest": contract.contract_digest,
        "decision": decision,
        "reason": reason,
    }
    result_digest = hashlib.sha256(canonical_json_bytes(result_payload)).hexdigest()
    payload = {
        "request_digest": request.request_digest,
        "contract_digest": contract.contract_digest,
        "source_generation_id": request.source_generation_id,
        "target_generation_id": request.target_generation_id,
        "capability": request.capability,
        "authority": request.authority,
        "data_scope": request.data_scope,
        "decision": decision,
        "reason": reason,
        "result_digest": result_digest,
        "ontology_assimilation_performed": False,
        "identity_rewrite_performed": False,
        "protected_write_performed": False,
        "subjective_consent_proven": False,
        "legal_contract_claimed": False,
        "political_legitimacy_claimed": False,
    }
    interaction_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    return CrossGenerationInteractionEvidence(
        interaction_id=interaction_id,
        **payload,
        canonical_bytes=canonical_json_bytes({"interaction_id": interaction_id, **payload}),
    )


def evaluate_cross_generation_request(
    registry: BoundaryContractRegistry,
    request: CrossGenerationRequest,
) -> CrossGenerationInteractionEvidence:
    from .errors import InvalidCrossGenerationRequest, StaleBoundaryContract

    if not isinstance(registry, BoundaryContractRegistry):
        raise InvalidCrossGenerationRequest("registry must be canonical")
    if not isinstance(request, CrossGenerationRequest):
        raise InvalidCrossGenerationRequest("request must be canonical")
    contract = registry.contract(request.contract_id)
    if contract.contract_digest != request.contract_digest:
        raise StaleBoundaryContract("contract digest mismatch")

    endpoint_pairs = {
        (
            contract.generation_a_id,
            contract.generation_a_digest,
            contract.generation_b_id,
            contract.generation_b_digest,
        ),
        (
            contract.generation_b_id,
            contract.generation_b_digest,
            contract.generation_a_id,
            contract.generation_a_digest,
        ),
    }
    observed = (
        request.source_generation_id,
        request.source_generation_digest,
        request.target_generation_id,
        request.target_generation_digest,
    )
    if observed not in endpoint_pairs:
        raise StaleBoundaryContract("request generations are not the exact bound contract endpoints")

    if registry.state(contract.contract_id) is not BoundaryContractLifecycleState.ACTIVE:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="CONTRACT_NOT_ACTIVE",
        )
    if request.capability not in contract.allowed_capabilities:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="CAPABILITY_NOT_AUTHORIZED",
        )
    if request.authority is BoundaryAuthorityKind.WRITE_PROTECTED:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="PROTECTED_AUTHORITY_FORBIDDEN",
        )
    if request.authority is BoundaryAuthorityKind.ADMIN:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="ADMIN_AUTHORITY_FORBIDDEN",
        )
    if request.authority not in contract.allowed_authorities:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="AUTHORITY_NOT_AUTHORIZED",
        )
    if request.data_scope not in contract.disclosure_policy.allowed_data_scopes:
        return _interaction_evidence(
            request,
            contract,
            decision=CrossGenerationInteractionDecision.DENIED,
            reason="DATA_SCOPE_NOT_AUTHORIZED",
        )
    return _interaction_evidence(
        request,
        contract,
        decision=CrossGenerationInteractionDecision.ALLOWED,
        reason="AUTHORIZED_BY_ACTIVE_BOUNDARY_CONTRACT",
    )
