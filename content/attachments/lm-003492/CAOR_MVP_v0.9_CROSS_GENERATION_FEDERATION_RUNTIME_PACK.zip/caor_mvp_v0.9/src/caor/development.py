from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from typing import Any, Mapping, Sequence

from .canonical import canonical_json_bytes
from .errors import InvalidDevelopmentEvent, ProtectedCoreWriteDenied
from .models import OffspringIdentitySpecification


class DevelopmentEventKind(str, Enum):
    SELF_UPDATE = "SELF_UPDATE"
    ACCEPT_PROPOSAL = "ACCEPT_PROPOSAL"
    ENVIRONMENT_EVENT = "ENVIRONMENT_EVENT"


@dataclass(frozen=True)
class DevelopmentEvent:
    event_id: str
    event_index: int
    actor_id: str
    event_kind: DevelopmentEventKind
    region: str
    key: str
    value: Any
    previous_value: Any
    source_event_id: str | None
    timestamp: str
    evidence: Mapping[str, Any]


class DevelopmentLedger:
    def __init__(self) -> None:
        self._events: list[DevelopmentEvent] = []
        self._by_id: dict[str, DevelopmentEvent] = {}

    @property
    def events(self) -> tuple[DevelopmentEvent, ...]:
        return tuple(self._events)

    def add_event(self, event: DevelopmentEvent) -> None:
        existing = self._by_id.get(event.event_id)
        if existing is not None:
            if existing != event:
                raise InvalidDevelopmentEvent(f"event ID collision: {event.event_id}")
            raise InvalidDevelopmentEvent(f"duplicate event: {event.event_id}")
        if event.event_index != len(self._events):
            raise InvalidDevelopmentEvent(
                f"expected event index {len(self._events)}, got {event.event_index}"
            )
        if not isinstance(event.event_kind, DevelopmentEventKind):
            raise InvalidDevelopmentEvent(f"noncanonical development event kind: {event.event_kind}")
        self._events.append(event)
        self._by_id[event.event_id] = event

    def append(
        self,
        actor_id: str,
        event_kind: DevelopmentEventKind,
        region: str,
        key: str,
        value: Any,
        previous_value: Any,
        source_event_id: str | None = None,
        timestamp: str = "UNSPECIFIED",
        evidence: Mapping[str, Any] | None = None,
    ) -> DevelopmentEvent:
        event_index = len(self._events)
        payload = {
            "event_index": event_index,
            "actor_id": actor_id,
            "event_kind": event_kind,
            "region": region,
            "key": key,
            "value": value,
            "previous_value": previous_value,
            "source_event_id": source_event_id,
            "timestamp": timestamp,
            "evidence": dict(evidence or {}),
        }
        event_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        event = DevelopmentEvent(
            event_id=event_id,
            event_index=event_index,
            actor_id=actor_id,
            event_kind=event_kind,
            region=region,
            key=key,
            value=value,
            previous_value=previous_value,
            source_event_id=source_event_id,
            timestamp=timestamp,
            evidence=dict(evidence or {}),
        )
        self.add_event(event)
        return event

    def canonical_bytes(self) -> bytes:
        return canonical_json_bytes({"events": self.events})

    @property
    def digest(self) -> str:
        return hashlib.sha256(self.canonical_bytes()).hexdigest()


def replay_mutable_state(
    ois: OffspringIdentitySpecification,
    events: Sequence[DevelopmentEvent],
) -> dict[str, dict[str, Any]]:
    state: dict[str, dict[str, Any]] = {region: {} for region in ois.mutable_regions}
    seen_ids: set[str] = set()
    for expected_index, event in enumerate(events):
        if event.event_index != expected_index:
            raise InvalidDevelopmentEvent(
                f"expected replay index {expected_index}, got {event.event_index}"
            )
        if event.event_id in seen_ids:
            raise InvalidDevelopmentEvent(f"duplicate replay event ID: {event.event_id}")
        seen_ids.add(event.event_id)
        if event.region not in state:
            raise ProtectedCoreWriteDenied(f"region is not mutable: {event.region}")
        state[event.region][event.key] = event.value
    return state
