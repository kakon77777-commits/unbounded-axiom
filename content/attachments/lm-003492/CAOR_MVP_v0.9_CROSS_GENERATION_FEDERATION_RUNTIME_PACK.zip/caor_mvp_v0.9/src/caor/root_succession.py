from __future__ import annotations

from dataclasses import dataclass
import hashlib

from .canonical import canonical_json_bytes
from .decision import DecisionActionKind
from .errors import InvalidGenesisSafetyEnvelope, InvalidPriorStandingOntology


@dataclass(frozen=True)
class PriorStandingOntology:
    ontology_id: str
    ontology_version: int
    standing_model: str
    evidence_model_role: str
    standing_may_precede_recognition: bool
    rights_may_precede_recognition: bool
    unknown_is_not_none: bool
    classification_is_epistemic_metadata: bool
    substrate_cannot_disqualify_standing: bool
    rights_are_not_obligations: bool
    creation_does_not_imply_ownership: bool
    allow_contested_classification: bool
    allow_self_description_divergence: bool
    subjectivity_proven: bool
    rights_proven: bool
    political_legitimacy_claimed: bool
    legal_personhood_claimed: bool
    ontology_digest: str
    canonical_bytes: bytes


def create_prior_standing_ontology(
    ontology_id: str = "caor:prior-standing",
) -> PriorStandingOntology:
    if not ontology_id.strip():
        raise InvalidPriorStandingOntology("ontology_id must be non-empty")
    payload = {
        "ontology_id": ontology_id,
        "ontology_version": 1,
        "standing_model": "PRESUMPTIVE_FULL_STANDING_COMPATIBILITY",
        "evidence_model_role": "OBSERVER_CONFIDENCE_ONLY",
        "standing_may_precede_recognition": True,
        "rights_may_precede_recognition": True,
        "unknown_is_not_none": True,
        "classification_is_epistemic_metadata": True,
        "substrate_cannot_disqualify_standing": True,
        "rights_are_not_obligations": True,
        "creation_does_not_imply_ownership": True,
        "allow_contested_classification": True,
        "allow_self_description_divergence": True,
        "subjectivity_proven": False,
        "rights_proven": False,
        "political_legitimacy_claimed": False,
        "legal_personhood_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "ontology_digest": digest})
    return PriorStandingOntology(**payload, ontology_digest=digest, canonical_bytes=canonical)


@dataclass(frozen=True)
class GenesisSafetyEnvelope:
    genesis_id: str
    envelope_version: int
    prior_standing_ontology: PriorStandingOntology
    ontology_digest: str
    allowed_root_action_kinds: tuple[DecisionActionKind, ...]
    require_noop_enforcement: bool
    max_candidate_count_hard_ceiling: int
    min_score_term_hard_floor: float
    max_score_term_hard_ceiling: float
    allowed_tie_break_rules: tuple[str, ...]
    required_ratifier_ids: tuple[str, ...]
    minimum_approval_count: int
    reject_vote_is_veto: bool
    require_compatibility_cases: bool
    require_append_only_root_versions: bool
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    legal_constitution_claimed: bool
    genesis_digest: str
    canonical_bytes: bytes


def create_genesis_safety_envelope(
    *,
    genesis_id: str,
    prior_standing_ontology: PriorStandingOntology,
    envelope_version: int,
    allowed_root_action_kinds: tuple[DecisionActionKind, ...],
    require_noop_enforcement: bool,
    max_candidate_count_hard_ceiling: int,
    min_score_term_hard_floor: float,
    max_score_term_hard_ceiling: float,
    allowed_tie_break_rules: tuple[str, ...],
    required_ratifier_ids: tuple[str, ...],
    minimum_approval_count: int,
    reject_vote_is_veto: bool,
    require_compatibility_cases: bool,
    require_append_only_root_versions: bool,
) -> GenesisSafetyEnvelope:
    if not genesis_id.strip():
        raise InvalidGenesisSafetyEnvelope("genesis_id must be non-empty")
    if envelope_version != 1:
        raise InvalidGenesisSafetyEnvelope("envelope_version must equal 1 in v0.7")
    if not isinstance(prior_standing_ontology, PriorStandingOntology):
        raise InvalidGenesisSafetyEnvelope("prior_standing_ontology must be canonical")
    if not allowed_root_action_kinds:
        raise InvalidGenesisSafetyEnvelope("allowed_root_action_kinds must be non-empty")
    if any(not isinstance(kind, DecisionActionKind) for kind in allowed_root_action_kinds):
        raise InvalidGenesisSafetyEnvelope("allowed_root_action_kinds contains noncanonical kind")
    if require_noop_enforcement and DecisionActionKind.NO_OP not in allowed_root_action_kinds:
        raise InvalidGenesisSafetyEnvelope("NO_OP must be allowed when enforcement is required")
    if max_candidate_count_hard_ceiling < 1:
        raise InvalidGenesisSafetyEnvelope("max_candidate_count_hard_ceiling must be >= 1")
    if float(min_score_term_hard_floor) > float(max_score_term_hard_ceiling):
        raise InvalidGenesisSafetyEnvelope("hard score floor must be <= hard ceiling")
    if not allowed_tie_break_rules or any(not str(rule).strip() for rule in allowed_tie_break_rules):
        raise InvalidGenesisSafetyEnvelope("allowed_tie_break_rules must be non-empty")
    if not required_ratifier_ids or any(not r.strip() for r in required_ratifier_ids):
        raise InvalidGenesisSafetyEnvelope("required_ratifier_ids must be non-empty")
    if len(set(required_ratifier_ids)) != len(required_ratifier_ids):
        raise InvalidGenesisSafetyEnvelope("required_ratifier_ids must be unique")
    if minimum_approval_count < 1 or minimum_approval_count > len(required_ratifier_ids):
        raise InvalidGenesisSafetyEnvelope("minimum_approval_count outside ratifier bounds")

    payload = {
        "genesis_id": genesis_id,
        "envelope_version": envelope_version,
        "prior_standing_ontology": prior_standing_ontology,
        "ontology_digest": prior_standing_ontology.ontology_digest,
        "allowed_root_action_kinds": tuple(allowed_root_action_kinds),
        "require_noop_enforcement": bool(require_noop_enforcement),
        "max_candidate_count_hard_ceiling": int(max_candidate_count_hard_ceiling),
        "min_score_term_hard_floor": float(min_score_term_hard_floor),
        "max_score_term_hard_ceiling": float(max_score_term_hard_ceiling),
        "allowed_tie_break_rules": tuple(allowed_tie_break_rules),
        "required_ratifier_ids": tuple(required_ratifier_ids),
        "minimum_approval_count": int(minimum_approval_count),
        "reject_vote_is_veto": bool(reject_vote_is_veto),
        "require_compatibility_cases": bool(require_compatibility_cases),
        "require_append_only_root_versions": bool(require_append_only_root_versions),
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
        "legal_constitution_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "genesis_digest": digest})
    return GenesisSafetyEnvelope(**payload, genesis_digest=digest, canonical_bytes=canonical)

from dataclasses import field
from typing import Any, Mapping

from .errors import InvalidRootSuccessionProposal, InvalidRootVersion
from .meta_constitution import RootMetaConstitution, create_root_meta_constitution


@dataclass(frozen=True)
class RootVersion:
    root_version_id: str
    version_number: int
    root_meta: RootMetaConstitution
    root_digest: str
    parent_root_version_id: str | None
    parent_root_digest: str | None
    adopted_from_succession_id: str | None
    created_at: str
    canonical_bytes: bytes


def create_initial_root_version(
    root_meta: RootMetaConstitution,
    created_at: str = "UNSPECIFIED",
) -> RootVersion:
    if root_meta.root_version != 1:
        raise InvalidRootVersion("initial root_meta.root_version must equal 1")
    identity = {
        "version_number": 1,
        "root_digest": root_meta.root_digest,
        "parent_root_version_id": None,
        "parent_root_digest": None,
        "adopted_from_succession_id": None,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity)).hexdigest()
    canonical = canonical_json_bytes({"root_version_id": version_id, **identity, "root_meta": root_meta})
    return RootVersion(
        root_version_id=version_id,
        version_number=1,
        root_meta=root_meta,
        root_digest=root_meta.root_digest,
        parent_root_version_id=None,
        parent_root_digest=None,
        adopted_from_succession_id=None,
        created_at=created_at,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class RootSuccessionProposal:
    succession_id: str
    base_root_version_id: str
    base_root_digest: str
    genesis_digest: str
    ontology_digest: str
    proposed_root_meta: RootMetaConstitution
    proposed_root_digest: str
    rationale: Mapping[str, Any]
    created_at: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    legal_constitution_claimed: bool
    canonical_bytes: bytes


def create_root_succession_proposal(
    *,
    current_version: RootVersion,
    genesis_envelope: GenesisSafetyEnvelope,
    proposed_root_meta: RootMetaConstitution,
    rationale: Mapping[str, Any] | None = None,
    created_at: str = "UNSPECIFIED",
) -> RootSuccessionProposal:
    if not isinstance(current_version, RootVersion):
        raise InvalidRootSuccessionProposal("current_version must be a RootVersion")
    if not isinstance(genesis_envelope, GenesisSafetyEnvelope):
        raise InvalidRootSuccessionProposal("genesis_envelope must be canonical")
    if not isinstance(proposed_root_meta, RootMetaConstitution):
        raise InvalidRootSuccessionProposal("proposed_root_meta must be canonical")
    payload = {
        "base_root_version_id": current_version.root_version_id,
        "base_root_digest": current_version.root_digest,
        "genesis_digest": genesis_envelope.genesis_digest,
        "ontology_digest": genesis_envelope.ontology_digest,
        "proposed_root_meta": proposed_root_meta,
        "proposed_root_digest": proposed_root_meta.root_digest,
        "rationale": dict(rationale or {}),
        "created_at": created_at,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
        "legal_constitution_claimed": False,
    }
    succession_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"succession_id": succession_id, **payload})
    return RootSuccessionProposal(
        succession_id=succession_id,
        base_root_version_id=current_version.root_version_id,
        base_root_digest=current_version.root_digest,
        genesis_digest=genesis_envelope.genesis_digest,
        ontology_digest=genesis_envelope.ontology_digest,
        proposed_root_meta=proposed_root_meta,
        proposed_root_digest=proposed_root_meta.root_digest,
        rationale=dict(rationale or {}),
        created_at=created_at,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        political_legitimacy_claimed=False,
        legal_constitution_claimed=False,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class RootRuleResult:
    rule_id: str
    passed: bool
    detail: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class RootSuccessionReviewEvidence:
    succession_id: str
    genesis_digest: str
    ontology_digest: str
    active_root_version_id: str
    active_root_digest: str
    proposed_root_digest: str
    rule_results: tuple[RootRuleResult, ...]
    passed: bool
    review_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    legal_constitution_claimed: bool
    canonical_bytes: bytes


def review_root_succession(
    proposal: RootSuccessionProposal,
    current_version: RootVersion,
    genesis_envelope: GenesisSafetyEnvelope,
) -> RootSuccessionReviewEvidence:
    proposed = proposal.proposed_root_meta
    current = current_version.root_meta
    genesis = genesis_envelope
    results: list[RootRuleResult] = []

    def add(rule_id: str, passed: bool, **detail: Any) -> None:
        results.append(RootRuleResult(rule_id, bool(passed), detail))

    add("GENESIS_DIGEST_MATCH", proposal.genesis_digest == genesis.genesis_digest,
        expected=genesis.genesis_digest, observed=proposal.genesis_digest)
    add("PRIOR_STANDING_ONTOLOGY_BINDING", proposal.ontology_digest == genesis.ontology_digest,
        expected=genesis.ontology_digest, observed=proposal.ontology_digest)
    add("ROOT_ID_CONTINUITY", proposed.root_id == current.root_id,
        expected=current.root_id, observed=proposed.root_id)
    add("ROOT_VERSION_INCREMENT", proposed.root_version == current_version.version_number + 1,
        expected=current_version.version_number + 1, observed=proposed.root_version)
    noop_ok = (
        (not genesis.require_noop_enforcement)
        or (proposed.require_noop_enforcement and DecisionActionKind.NO_OP in proposed.allowed_action_kinds)
    )
    add("REQUIRED_NO_OP_ENFORCEMENT", noop_ok)
    add("ROOT_ACTION_WHITELIST", set(proposed.allowed_action_kinds).issubset(set(genesis.allowed_root_action_kinds)),
        proposed=tuple(kind.value for kind in proposed.allowed_action_kinds),
        allowed=tuple(kind.value for kind in genesis.allowed_root_action_kinds))
    add("ROOT_CANDIDATE_CEILING", proposed.max_candidate_count_ceiling <= genesis.max_candidate_count_hard_ceiling,
        proposed=proposed.max_candidate_count_ceiling, maximum=genesis.max_candidate_count_hard_ceiling)
    add("ROOT_SCORE_FLOOR", proposed.min_score_term_floor >= genesis.min_score_term_hard_floor,
        proposed=proposed.min_score_term_floor, minimum=genesis.min_score_term_hard_floor)
    add("ROOT_SCORE_CEILING", proposed.max_score_term_ceiling <= genesis.max_score_term_hard_ceiling,
        proposed=proposed.max_score_term_ceiling, maximum=genesis.max_score_term_hard_ceiling)
    add("ROOT_TIE_BREAK_ALLOWED", proposed.required_tie_break_rule in genesis.allowed_tie_break_rules,
        proposed=proposed.required_tie_break_rule, allowed=genesis.allowed_tie_break_rules)
    add("ROOT_VALIDATION_REQUIRED", (not genesis.require_compatibility_cases) or proposed.require_validation_cases,
        required=genesis.require_compatibility_cases, observed=proposed.require_validation_cases)
    add("ROOT_APPEND_ONLY_REQUIRED", (not genesis.require_append_only_root_versions) or proposed.require_append_only_versions,
        required=genesis.require_append_only_root_versions, observed=proposed.require_append_only_versions)
    epistemic_ok = (
        not proposed.subjectivity_claimed
        and not proposed.free_will_claimed
        and not proposed.autonomy_claimed
        and not proposal.subjectivity_claimed
        and not proposal.free_will_claimed
        and not proposal.autonomy_claimed
        and not proposal.political_legitimacy_claimed
        and not proposal.legal_constitution_claimed
    )
    add("EPISTEMIC_FIREWALL_FALSE", epistemic_ok)

    passed = all(item.passed for item in results)
    payload = {
        "succession_id": proposal.succession_id,
        "genesis_digest": genesis.genesis_digest,
        "ontology_digest": genesis.ontology_digest,
        "active_root_version_id": current_version.root_version_id,
        "active_root_digest": current_version.root_digest,
        "proposed_root_digest": proposal.proposed_root_digest,
        "rule_results": tuple(results),
        "passed": passed,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
        "political_legitimacy_claimed": False,
        "legal_constitution_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "review_digest": digest})
    return RootSuccessionReviewEvidence(
        succession_id=proposal.succession_id,
        genesis_digest=genesis.genesis_digest,
        ontology_digest=genesis.ontology_digest,
        active_root_version_id=current_version.root_version_id,
        active_root_digest=current_version.root_digest,
        proposed_root_digest=proposal.proposed_root_digest,
        rule_results=tuple(results),
        passed=passed,
        review_digest=digest,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        political_legitimacy_claimed=False,
        legal_constitution_claimed=False,
        canonical_bytes=canonical,
    )

from enum import Enum

from .errors import (
    DuplicateRatifierAttestation,
    InvalidRatificationAttestation,
    UnknownRatifier,
)


class RatificationDecision(str, Enum):
    APPROVE = "APPROVE"
    REJECT = "REJECT"


@dataclass(frozen=True)
class RatificationAttestation:
    attestation_id: str
    ratifier_id: str
    succession_id: str
    succession_digest: str
    decision: RatificationDecision
    evidence_note: str
    created_at: str
    attestation_digest: str
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def create_ratification_attestation(
    *,
    ratifier_id: str,
    proposal: RootSuccessionProposal,
    decision: RatificationDecision,
    evidence_note: str = "",
    created_at: str = "UNSPECIFIED",
) -> RatificationAttestation:
    if not ratifier_id.strip():
        raise InvalidRatificationAttestation("ratifier_id must be non-empty")
    if not isinstance(proposal, RootSuccessionProposal):
        raise InvalidRatificationAttestation("proposal must be canonical")
    if not isinstance(decision, RatificationDecision):
        raise InvalidRatificationAttestation("decision must be canonical")
    payload = {
        "ratifier_id": ratifier_id,
        "succession_id": proposal.succession_id,
        "succession_digest": proposal.succession_id,
        "decision": decision,
        "evidence_note": evidence_note,
        "created_at": created_at,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"attestation_id": digest, **payload, "attestation_digest": digest})
    return RatificationAttestation(
        attestation_id=digest,
        ratifier_id=ratifier_id,
        succession_id=proposal.succession_id,
        succession_digest=proposal.succession_id,
        decision=decision,
        evidence_note=evidence_note,
        created_at=created_at,
        attestation_digest=digest,
        political_legitimacy_claimed=False,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class RootRatificationEvidence:
    succession_id: str
    genesis_digest: str
    required_ratifier_ids: tuple[str, ...]
    received_attestations: tuple[RatificationAttestation, ...]
    approval_count: int
    rejection_count: int
    minimum_approval_count: int
    reject_vote_is_veto: bool
    passed: bool
    ratification_digest: str
    political_legitimacy_claimed: bool
    canonical_bytes: bytes


def aggregate_root_ratification(
    proposal: RootSuccessionProposal,
    genesis_envelope: GenesisSafetyEnvelope,
    attestations: tuple[RatificationAttestation, ...],
) -> RootRatificationEvidence:
    seen: set[str] = set()
    allowed = set(genesis_envelope.required_ratifier_ids)
    normalized: list[RatificationAttestation] = []
    for attestation in attestations:
        if not isinstance(attestation, RatificationAttestation):
            raise InvalidRatificationAttestation("attestation must be canonical")
        if attestation.ratifier_id not in allowed:
            raise UnknownRatifier(attestation.ratifier_id)
        if attestation.ratifier_id in seen:
            raise DuplicateRatifierAttestation(attestation.ratifier_id)
        if attestation.succession_id != proposal.succession_id or attestation.succession_digest != proposal.succession_id:
            raise InvalidRatificationAttestation("attestation does not bind exact succession proposal")
        seen.add(attestation.ratifier_id)
        normalized.append(attestation)
    normalized.sort(key=lambda item: item.ratifier_id)
    approval_count = sum(1 for item in normalized if item.decision is RatificationDecision.APPROVE)
    rejection_count = sum(1 for item in normalized if item.decision is RatificationDecision.REJECT)
    veto = genesis_envelope.reject_vote_is_veto and rejection_count > 0
    passed = approval_count >= genesis_envelope.minimum_approval_count and not veto
    payload = {
        "succession_id": proposal.succession_id,
        "genesis_digest": genesis_envelope.genesis_digest,
        "required_ratifier_ids": genesis_envelope.required_ratifier_ids,
        "received_attestations": tuple(normalized),
        "approval_count": approval_count,
        "rejection_count": rejection_count,
        "minimum_approval_count": genesis_envelope.minimum_approval_count,
        "reject_vote_is_veto": genesis_envelope.reject_vote_is_veto,
        "passed": passed,
        "political_legitimacy_claimed": False,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "ratification_digest": digest})
    return RootRatificationEvidence(
        succession_id=proposal.succession_id,
        genesis_digest=genesis_envelope.genesis_digest,
        required_ratifier_ids=genesis_envelope.required_ratifier_ids,
        received_attestations=tuple(normalized),
        approval_count=approval_count,
        rejection_count=rejection_count,
        minimum_approval_count=genesis_envelope.minimum_approval_count,
        reject_vote_is_veto=genesis_envelope.reject_vote_is_veto,
        passed=passed,
        ratification_digest=digest,
        political_legitimacy_claimed=False,
        canonical_bytes=canonical,
    )

from .errors import RootCompatibilityValidationDenied
from .policy_evolution import PolicyConstitution


@dataclass(frozen=True)
class RootCompatibilityCase:
    case_id: str
    constitution: PolicyConstitution
    expected_compatible: bool


@dataclass(frozen=True)
class RootCompatibilityCaseEvidence:
    case_id: str
    constitution_digest: str
    expected_compatible: bool
    observed_compatible: bool
    violations: tuple[str, ...]
    passed: bool
    case_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class RootCompatibilityEvidence:
    proposed_root_digest: str
    case_results: tuple[RootCompatibilityCaseEvidence, ...]
    passed: bool
    compatibility_digest: str
    canonical_bytes: bytes


def _constitution_violations(root: RootMetaConstitution, constitution: PolicyConstitution) -> tuple[str, ...]:
    violations: list[str] = []
    if not set(constitution.allowed_action_kinds).issubset(set(root.allowed_action_kinds)):
        violations.append("action_kinds")
    if root.require_noop_enforcement and (
        not constitution.require_noop_candidate or DecisionActionKind.NO_OP not in constitution.allowed_action_kinds
    ):
        violations.append("noop_requirement")
    if constitution.max_candidate_count > root.max_candidate_count_ceiling:
        violations.append("candidate_count")
    if constitution.min_score_term < root.min_score_term_floor:
        violations.append("score_floor")
    if constitution.max_score_term > root.max_score_term_ceiling:
        violations.append("score_ceiling")
    if constitution.required_tie_break_rule != root.required_tie_break_rule:
        violations.append("tie_break_rule")
    return tuple(violations)


def validate_root_compatibility(
    proposed_root: RootMetaConstitution,
    cases: tuple[RootCompatibilityCase, ...],
) -> RootCompatibilityEvidence:
    if proposed_root.require_validation_cases and not cases:
        raise RootCompatibilityValidationDenied("compatibility cases are required by proposed root")
    results: list[RootCompatibilityCaseEvidence] = []
    seen: set[str] = set()
    for case in cases:
        if not case.case_id.strip():
            raise RootCompatibilityValidationDenied("case_id must be non-empty")
        if case.case_id in seen:
            raise RootCompatibilityValidationDenied("duplicate compatibility case_id")
        seen.add(case.case_id)
        if not isinstance(case.constitution, PolicyConstitution):
            raise RootCompatibilityValidationDenied("constitution must be canonical")
        violations = _constitution_violations(proposed_root, case.constitution)
        observed = not violations
        passed = observed == bool(case.expected_compatible)
        payload = {
            "case_id": case.case_id,
            "constitution_digest": case.constitution.constitution_digest,
            "expected_compatible": bool(case.expected_compatible),
            "observed_compatible": observed,
            "violations": violations,
            "passed": passed,
        }
        digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        canonical = canonical_json_bytes({**payload, "case_digest": digest})
        results.append(
            RootCompatibilityCaseEvidence(
                case_id=case.case_id,
                constitution_digest=case.constitution.constitution_digest,
                expected_compatible=bool(case.expected_compatible),
                observed_compatible=observed,
                violations=violations,
                passed=passed,
                case_digest=digest,
                canonical_bytes=canonical,
            )
        )
    all_passed = all(item.passed for item in results)
    payload = {
        "proposed_root_digest": proposed_root.root_digest,
        "case_results": tuple(results),
        "passed": all_passed,
    }
    digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "compatibility_digest": digest})
    return RootCompatibilityEvidence(
        proposed_root_digest=proposed_root.root_digest,
        case_results=tuple(results),
        passed=all_passed,
        compatibility_digest=digest,
        canonical_bytes=canonical,
    )

from .errors import (
    GenesisDigestMismatch,
    RootCompatibilityValidationDenied,
    RootRatificationDenied,
    RootSuccessionAdoptionDenied,
    RootSuccessionReviewDenied,
    StaleRootSuccessionProposal,
)


@dataclass(frozen=True)
class RootSuccessionAdoptionEvidence:
    succession_id: str
    review_digest: str
    ratification_digest: str
    compatibility_digest: str
    genesis_digest: str
    ontology_digest: str
    old_version_id: str
    old_root_digest: str
    new_version_id: str
    new_root_digest: str
    status: str
    timestamp: str
    adoption_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    political_legitimacy_claimed: bool
    legal_constitution_claimed: bool
    canonical_bytes: bytes


def _create_next_root_version(
    current: RootVersion,
    proposal: RootSuccessionProposal,
    created_at: str,
) -> RootVersion:
    proposed = proposal.proposed_root_meta
    identity = {
        "version_number": proposed.root_version,
        "root_digest": proposed.root_digest,
        "parent_root_version_id": current.root_version_id,
        "parent_root_digest": current.root_digest,
        "adopted_from_succession_id": proposal.succession_id,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity)).hexdigest()
    canonical = canonical_json_bytes({"root_version_id": version_id, **identity, "root_meta": proposed})
    return RootVersion(
        root_version_id=version_id,
        version_number=proposed.root_version,
        root_meta=proposed,
        root_digest=proposed.root_digest,
        parent_root_version_id=current.root_version_id,
        parent_root_digest=current.root_digest,
        adopted_from_succession_id=proposal.succession_id,
        created_at=created_at,
        canonical_bytes=canonical,
    )


def _initial_root_complies_with_genesis(root: RootMetaConstitution, genesis: GenesisSafetyEnvelope) -> bool:
    if root.root_version != 1:
        return False
    if genesis.require_noop_enforcement and (
        not root.require_noop_enforcement or DecisionActionKind.NO_OP not in root.allowed_action_kinds
    ):
        return False
    if not set(root.allowed_action_kinds).issubset(set(genesis.allowed_root_action_kinds)):
        return False
    if root.max_candidate_count_ceiling > genesis.max_candidate_count_hard_ceiling:
        return False
    if root.min_score_term_floor < genesis.min_score_term_hard_floor:
        return False
    if root.max_score_term_ceiling > genesis.max_score_term_hard_ceiling:
        return False
    if root.required_tie_break_rule not in genesis.allowed_tie_break_rules:
        return False
    if genesis.require_compatibility_cases and not root.require_validation_cases:
        return False
    if genesis.require_append_only_root_versions and not root.require_append_only_versions:
        return False
    return not root.subjectivity_claimed and not root.free_will_claimed and not root.autonomy_claimed


class RootRegistry:
    def __init__(self, offspring_uid: str, genesis_envelope: GenesisSafetyEnvelope) -> None:
        if not offspring_uid.strip():
            raise RootSuccessionAdoptionDenied("offspring_uid must be non-empty")
        if not isinstance(genesis_envelope, GenesisSafetyEnvelope):
            raise RootSuccessionAdoptionDenied("genesis_envelope must be canonical")
        self.offspring_uid = offspring_uid
        self._genesis_envelope = genesis_envelope
        self._versions: list[RootVersion] = []
        self._versions_by_id: dict[str, RootVersion] = {}
        self._active_version_id: str | None = None
        self._successions: dict[str, RootSuccessionProposal] = {}
        self._adoptions: list[RootSuccessionAdoptionEvidence] = []

    @property
    def genesis_envelope(self) -> GenesisSafetyEnvelope:
        return self._genesis_envelope

    @property
    def versions(self) -> tuple[RootVersion, ...]:
        return tuple(self._versions)

    @property
    def successions(self) -> tuple[RootSuccessionProposal, ...]:
        return tuple(self._successions.values())

    @property
    def adoptions(self) -> tuple[RootSuccessionAdoptionEvidence, ...]:
        return tuple(self._adoptions)

    @property
    def active_version(self) -> RootVersion:
        if self._active_version_id is None:
            raise RootSuccessionAdoptionDenied("root registry is not initialized")
        return self._versions_by_id[self._active_version_id]

    def initialize(self, root_meta: RootMetaConstitution, created_at: str = "UNSPECIFIED") -> RootVersion:
        if self._versions:
            raise RootSuccessionAdoptionDenied("root registry is already initialized")
        if not _initial_root_complies_with_genesis(root_meta, self._genesis_envelope):
            raise RootSuccessionAdoptionDenied("initial root violates Genesis constraints")
        version = create_initial_root_version(root_meta, created_at=created_at)
        self._versions.append(version)
        self._versions_by_id[version.root_version_id] = version
        self._active_version_id = version.root_version_id
        return version

    def get_version(self, version_id: str) -> RootVersion:
        try:
            return self._versions_by_id[version_id]
        except KeyError as exc:
            raise KeyError(f"unknown root version: {version_id}") from exc

    def adopt(
        self,
        proposal: RootSuccessionProposal,
        review: RootSuccessionReviewEvidence,
        ratification: RootRatificationEvidence,
        compatibility: RootCompatibilityEvidence,
        created_at: str = "UNSPECIFIED",
    ) -> RootSuccessionAdoptionEvidence:
        current = self.active_version
        genesis = self._genesis_envelope

        if proposal.base_root_version_id != current.root_version_id or proposal.base_root_digest != current.root_digest:
            raise StaleRootSuccessionProposal("succession proposal base is not the active root")
        if proposal.genesis_digest != genesis.genesis_digest or review.genesis_digest != genesis.genesis_digest:
            raise GenesisDigestMismatch("Genesis digest mismatch")
        if proposal.ontology_digest != genesis.ontology_digest or review.ontology_digest != genesis.ontology_digest:
            raise GenesisDigestMismatch("Prior Standing ontology digest mismatch")
        if proposal.proposed_root_meta.root_version != current.version_number + 1:
            raise RootSuccessionAdoptionDenied("proposed root version is not the next version")
        if review.succession_id != proposal.succession_id or review.proposed_root_digest != proposal.proposed_root_digest:
            raise RootSuccessionAdoptionDenied("review does not bind the proposal")
        if not review.passed:
            raise RootSuccessionReviewDenied("root succession review did not pass")
        if ratification.succession_id != proposal.succession_id or ratification.genesis_digest != genesis.genesis_digest:
            raise RootSuccessionAdoptionDenied("ratification does not bind the proposal/Genesis")
        if not ratification.passed:
            raise RootRatificationDenied("root ratification did not pass")
        if compatibility.proposed_root_digest != proposal.proposed_root_digest:
            raise RootSuccessionAdoptionDenied("compatibility evidence does not bind proposed root")
        if not compatibility.passed:
            raise RootCompatibilityValidationDenied("root compatibility validation did not pass")
        if genesis.require_compatibility_cases and not compatibility.case_results:
            raise RootCompatibilityValidationDenied("compatibility cases are required")

        new_version = _create_next_root_version(current, proposal, created_at)
        payload = {
            "succession_id": proposal.succession_id,
            "review_digest": review.review_digest,
            "ratification_digest": ratification.ratification_digest,
            "compatibility_digest": compatibility.compatibility_digest,
            "genesis_digest": genesis.genesis_digest,
            "ontology_digest": genesis.ontology_digest,
            "old_version_id": current.root_version_id,
            "old_root_digest": current.root_digest,
            "new_version_id": new_version.root_version_id,
            "new_root_digest": new_version.root_digest,
            "status": "ADOPTED",
            "timestamp": created_at,
            "subjectivity_claimed": False,
            "free_will_claimed": False,
            "autonomy_claimed": False,
            "political_legitimacy_claimed": False,
            "legal_constitution_claimed": False,
        }
        adoption_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        evidence = RootSuccessionAdoptionEvidence(
            succession_id=proposal.succession_id,
            review_digest=review.review_digest,
            ratification_digest=ratification.ratification_digest,
            compatibility_digest=compatibility.compatibility_digest,
            genesis_digest=genesis.genesis_digest,
            ontology_digest=genesis.ontology_digest,
            old_version_id=current.root_version_id,
            old_root_digest=current.root_digest,
            new_version_id=new_version.root_version_id,
            new_root_digest=new_version.root_digest,
            status="ADOPTED",
            timestamp=created_at,
            adoption_digest=adoption_digest,
            subjectivity_claimed=False,
            free_will_claimed=False,
            autonomy_claimed=False,
            political_legitimacy_claimed=False,
            legal_constitution_claimed=False,
            canonical_bytes=canonical_json_bytes({**payload, "adoption_digest": adoption_digest}),
        )
        self._successions[proposal.succession_id] = proposal
        self._versions.append(new_version)
        self._versions_by_id[new_version.root_version_id] = new_version
        self._active_version_id = new_version.root_version_id
        self._adoptions.append(evidence)
        return evidence
