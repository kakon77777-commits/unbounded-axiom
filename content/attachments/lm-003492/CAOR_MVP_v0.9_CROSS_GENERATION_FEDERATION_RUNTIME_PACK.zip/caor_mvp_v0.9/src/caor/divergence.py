from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import hashlib
from numbers import Real
from typing import Any, Mapping, Sequence

from .canonical import canonical_json_bytes
from .development import DevelopmentEvent, DevelopmentLedger, replay_mutable_state
from .models import Contribution, ContributionCategory, ContributionManifest, OffspringIdentitySpecification


CATEGORY_REGION = {
    ContributionCategory.IDENTITY_TRAIT: "preferences",
    ContributionCategory.VALUE_TRAIT: "preferences",
    ContributionCategory.COGNITIVE_TRAIT: "notes",
    ContributionCategory.MEMORY_SEED: "notes",
    ContributionCategory.CAPABILITY_TRAIT: "skills",
    ContributionCategory.CULTURAL_SEMANTIC_TRAIT: "notes",
    ContributionCategory.CONSTRAINT: "notes",
}


@dataclass(frozen=True)
class DivergenceSnapshot:
    entity_uid: str
    step: int
    ledger_digest: str
    state_digest: str
    per_source_distance: Mapping[str, float]
    nearest_source_id: str | None
    nearest_source_distance: float
    novel_state_fraction: float
    changed_keys: tuple[str, ...]


@dataclass(frozen=True)
class DevelopmentEvidenceBundle:
    offspring_uid: str
    manifest_digest: str
    ois_digest: str
    ledger_digest: str
    event_count: int
    final_state_digest: str
    divergence_timeline: tuple[DivergenceSnapshot, ...]
    subjectivity_claimed: bool
    canonical_bytes: bytes


def _empty_state() -> dict[str, dict[str, Any]]:
    return {"preferences": {}, "skills": {}, "notes": {}}


def _is_numeric(value: Any) -> bool:
    return isinstance(value, Real) and not isinstance(value, bool)


def _select_or_average(items: Sequence[Contribution]) -> Any:
    if len(items) == 1:
        return items[0].value
    if items and all(_is_numeric(item.value) for item in items):
        total_weight = sum(item.weight for item in items)
        if total_weight > 0:
            return sum(float(item.value) * item.weight for item in items) / total_weight
    winner = sorted(items, key=lambda item: (-item.weight, item.source_id, item.contribution_id))[0]
    return winner.value


def _group_projection(contributions: Sequence[Contribution]) -> dict[str, dict[str, Any]]:
    grouped: dict[tuple[str, str], list[Contribution]] = {}
    for item in contributions:
        region = CATEGORY_REGION[item.category]
        grouped.setdefault((region, item.name), []).append(item)
    result = _empty_state()
    for (region, key), items in sorted(grouped.items()):
        result[region][key] = _select_or_average(items)
    return result


def source_baselines(manifest: ContributionManifest) -> dict[str, dict[str, dict[str, Any]]]:
    by_source: dict[str, list[Contribution]] = {source_id: [] for source_id in manifest.source_ids}
    for item in manifest.contributions:
        by_source[item.source_id].append(item)
    return {
        source_id: _group_projection(tuple(by_source[source_id]))
        for source_id in sorted(by_source)
    }


def origin_state_projection(manifest: ContributionManifest) -> dict[str, dict[str, Any]]:
    return _group_projection(manifest.contributions)


def development_value_distance(left: Any, right: Any) -> float:
    if canonical_json_bytes(left) == canonical_json_bytes(right):
        return 0.0
    if _is_numeric(left) and _is_numeric(right):
        return abs(float(left) - float(right)) / (1.0 + abs(float(left)) + abs(float(right)))
    return 1.0


def _flatten(state: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    flattened: dict[str, Any] = {}
    for region in sorted(state):
        for key in sorted(state[region]):
            flattened[f"{region}.{key}"] = state[region][key]
    return flattened


def _overlay(origin: Mapping[str, Mapping[str, Any]], mutable_state: Mapping[str, Mapping[str, Any]]) -> dict[str, dict[str, Any]]:
    projected = deepcopy(origin)
    for region, values in mutable_state.items():
        projected.setdefault(region, {})
        for key, value in values.items():
            projected[region][key] = value
    return projected


def _state_distance(entity_state: Mapping[str, Mapping[str, Any]], source_state: Mapping[str, Mapping[str, Any]]) -> float:
    entity_flat = _flatten(entity_state)
    source_flat = _flatten(source_state)
    keys = sorted(set(entity_flat) | set(source_flat))
    if not keys:
        return 0.0
    distances = []
    missing = object()
    for key in keys:
        left = entity_flat.get(key, missing)
        right = source_flat.get(key, missing)
        if left is missing or right is missing:
            distances.append(1.0)
        else:
            distances.append(development_value_distance(left, right))
    return sum(distances) / len(distances)


def compute_divergence_snapshot(
    ois: OffspringIdentitySpecification,
    manifest: ContributionManifest,
    mutable_state: Mapping[str, Mapping[str, Any]],
    step: int,
    ledger_digest: str,
) -> DivergenceSnapshot:
    origin = origin_state_projection(manifest)
    projected = _overlay(origin, mutable_state)
    baselines = source_baselines(manifest)
    per_source = {
        source_id: _state_distance(projected, baselines[source_id])
        for source_id in sorted(baselines)
    }
    if per_source:
        nearest_source_id, nearest_distance = min(per_source.items(), key=lambda item: (item[1], item[0]))
    else:
        nearest_source_id, nearest_distance = None, 0.0

    origin_flat = _flatten(origin)
    projected_flat = _flatten(projected)
    changed = tuple(
        key for key in sorted(projected_flat)
        if key not in origin_flat or development_value_distance(projected_flat[key], origin_flat[key]) != 0.0
    )

    baseline_flats = {source_id: _flatten(state) for source_id, state in baselines.items()}
    if projected_flat:
        novel_count = 0
        for key, value in projected_flat.items():
            if not any(
                key in source_flat and development_value_distance(value, source_flat[key]) == 0.0
                for source_flat in baseline_flats.values()
            ):
                novel_count += 1
        novel_fraction = novel_count / len(projected_flat)
    else:
        novel_fraction = 0.0

    state_digest = hashlib.sha256(canonical_json_bytes(projected)).hexdigest()
    return DivergenceSnapshot(
        entity_uid=ois.offspring_uid,
        step=step,
        ledger_digest=ledger_digest,
        state_digest=state_digest,
        per_source_distance=per_source,
        nearest_source_id=nearest_source_id,
        nearest_source_distance=nearest_distance,
        novel_state_fraction=novel_fraction,
        changed_keys=changed,
    )


def compute_divergence_timeline(
    ois: OffspringIdentitySpecification,
    manifest: ContributionManifest,
    events: Sequence[DevelopmentEvent],
) -> tuple[DivergenceSnapshot, ...]:
    ledger = DevelopmentLedger()
    snapshots: list[DivergenceSnapshot] = [
        compute_divergence_snapshot(ois, manifest, _empty_state(), 0, ledger.digest)
    ]
    prefix: list[DevelopmentEvent] = []
    for event in events:
        ledger.add_event(event)
        prefix.append(event)
        overlay_state = replay_mutable_state(ois, tuple(prefix))
        snapshots.append(
            compute_divergence_snapshot(
                ois,
                manifest,
                overlay_state,
                len(prefix),
                ledger.digest,
            )
        )
    return tuple(snapshots)


def build_development_evidence(entity: Any, manifest: ContributionManifest) -> DevelopmentEvidenceBundle:
    timeline = compute_divergence_timeline(entity.ois, manifest, entity.development_events)
    final_state_digest = timeline[-1].state_digest
    ois_digest = hashlib.sha256(entity.ois.canonical_bytes).hexdigest()
    payload = {
        "offspring_uid": entity.ois.offspring_uid,
        "manifest_digest": manifest.digest,
        "ois_digest": ois_digest,
        "ledger_digest": entity.development_digest,
        "event_count": len(entity.development_events),
        "final_state_digest": final_state_digest,
        "divergence_timeline": timeline,
        "subjectivity_claimed": False,
    }
    canonical = canonical_json_bytes(payload)
    return DevelopmentEvidenceBundle(
        offspring_uid=entity.ois.offspring_uid,
        manifest_digest=manifest.digest,
        ois_digest=ois_digest,
        ledger_digest=entity.development_digest,
        event_count=len(entity.development_events),
        final_state_digest=final_state_digest,
        divergence_timeline=timeline,
        subjectivity_claimed=False,
        canonical_bytes=canonical,
    )
