from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from enum import Enum
import hashlib
import math
from typing import Any, Mapping, Sequence

from .canonical import canonical_json_bytes
from .development import DevelopmentEvent, DevelopmentEventKind, replay_mutable_state
from .divergence import origin_state_projection
from .entity import OffspringEntity
from .errors import (
    InvalidDecisionCondition,
    InvalidDecisionPolicy,
    ManifestIntegrityError,
    NoEligibleDecisionCandidate,
    StaleDecisionContext,
)
from .models import ContributionManifest, OffspringIdentitySpecification


class DecisionActionKind(str, Enum):
    SELF_UPDATE = "SELF_UPDATE"
    ACCEPT_PROPOSAL = "ACCEPT_PROPOSAL"
    NO_OP = "NO_OP"


class DecisionSignalKind(str, Enum):
    STATE = "STATE"
    ENVIRONMENT = "ENVIRONMENT"
    HISTORY_COUNT = "HISTORY_COUNT"
    HISTORY_TOTAL = "HISTORY_TOTAL"


class DecisionOperator(str, Enum):
    EQ = "EQ"
    NE = "NE"
    GT = "GT"
    GTE = "GTE"
    LT = "LT"
    LTE = "LTE"
    EXISTS = "EXISTS"
    NOT_EXISTS = "NOT_EXISTS"


@dataclass(frozen=True)
class DecisionAction:
    action_kind: DecisionActionKind
    region: str = ""
    key: str = ""
    value: Any = None
    proposal_id: str | None = None
    evidence: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DecisionCondition:
    signal_kind: DecisionSignalKind
    path: str
    operator: DecisionOperator
    expected: Any = None


@dataclass(frozen=True)
class DecisionScoreTerm:
    condition: DecisionCondition
    score_if_true: float
    score_if_false: float = 0.0


@dataclass(frozen=True)
class DecisionCandidate:
    candidate_id: str
    action: DecisionAction
    hard_conditions: tuple[DecisionCondition, ...] = ()
    score_terms: tuple[DecisionScoreTerm, ...] = ()


@dataclass(frozen=True)
class DecisionPolicy:
    policy_id: str
    candidates: tuple[DecisionCandidate, ...]
    tie_break_rule: str = "LEXICAL_CANDIDATE_ID"


@dataclass(frozen=True)
class DecisionContext:
    offspring_uid: str
    manifest_digest: str
    development_digest: str
    projected_state: Mapping[str, Mapping[str, Any]]
    history_event_counts: Mapping[str, int]
    history_total: int
    environment: Mapping[str, Any]
    context_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class ConditionEvaluation:
    condition: DecisionCondition
    observed: Any
    matched: bool


@dataclass(frozen=True)
class ScoreTermEvaluation:
    condition_result: ConditionEvaluation
    score_contribution: float


@dataclass(frozen=True)
class CandidateEvaluation:
    candidate_id: str
    eligible: bool
    score: float
    hard_results: tuple[ConditionEvaluation, ...]
    score_results: tuple[ScoreTermEvaluation, ...]


@dataclass(frozen=True)
class PolicySelectionEvidence:
    offspring_uid: str
    policy_id: str
    context: DecisionContext
    selected_candidate_id: str
    selected_action: DecisionAction
    candidate_evaluations: tuple[CandidateEvaluation, ...]
    tie_break_rule: str
    selection_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


@dataclass(frozen=True)
class PolicyExecutionResult:
    selection_digest: str
    selected_candidate_id: str
    action_applied: bool
    development_event: DevelopmentEvent | None
    pre_development_digest: str
    post_development_digest: str
    canonical_bytes: bytes


_MISSING = object()


def _events_digest(events: Sequence[DevelopmentEvent]) -> str:
    return hashlib.sha256(canonical_json_bytes({"events": tuple(events)})).hexdigest()


def _overlay_state(
    origin: Mapping[str, Mapping[str, Any]],
    mutable: Mapping[str, Mapping[str, Any]],
) -> dict[str, dict[str, Any]]:
    result = deepcopy(origin)
    for region, values in mutable.items():
        result.setdefault(region, {})
        for key, value in values.items():
            result[region][key] = value
    return result


def build_decision_context(
    ois: OffspringIdentitySpecification,
    manifest: ContributionManifest,
    development_events: Sequence[DevelopmentEvent],
    environment: Mapping[str, Any],
) -> DecisionContext:
    if ois.manifest_digest != manifest.digest:
        raise ManifestIntegrityError("OIS manifest digest does not match contribution manifest")
    mutable = replay_mutable_state(ois, tuple(development_events))
    projected = _overlay_state(origin_state_projection(manifest), mutable)
    counts = {kind.value: 0 for kind in DevelopmentEventKind}
    for event in development_events:
        counts[event.event_kind.value] = counts.get(event.event_kind.value, 0) + 1
    development_digest = _events_digest(development_events)
    payload = {
        "offspring_uid": ois.offspring_uid,
        "manifest_digest": manifest.digest,
        "development_digest": development_digest,
        "projected_state": projected,
        "history_event_counts": counts,
        "history_total": len(tuple(development_events)),
        "environment": dict(environment),
    }
    canonical = canonical_json_bytes(payload)
    digest = hashlib.sha256(canonical).hexdigest()
    return DecisionContext(
        offspring_uid=ois.offspring_uid,
        manifest_digest=manifest.digest,
        development_digest=development_digest,
        projected_state=projected,
        history_event_counts=counts,
        history_total=len(tuple(development_events)),
        environment=dict(environment),
        context_digest=digest,
        canonical_bytes=canonical,
    )


def _resolve_path(value: Any, path: str) -> Any:
    if path == "":
        return value
    current = value
    for segment in path.split("."):
        if isinstance(current, Mapping) and segment in current:
            current = current[segment]
        else:
            return _MISSING
    return current


def _resolve_signal(context: DecisionContext, condition: DecisionCondition) -> Any:
    if not isinstance(condition.signal_kind, DecisionSignalKind):
        raise InvalidDecisionCondition(f"noncanonical signal kind: {condition.signal_kind}")
    if condition.signal_kind is DecisionSignalKind.STATE:
        return _resolve_path(context.projected_state, condition.path)
    if condition.signal_kind is DecisionSignalKind.ENVIRONMENT:
        return _resolve_path(context.environment, condition.path)
    if condition.signal_kind is DecisionSignalKind.HISTORY_COUNT:
        return context.history_event_counts.get(condition.path, 0)
    if condition.signal_kind is DecisionSignalKind.HISTORY_TOTAL:
        return context.history_total
    raise InvalidDecisionCondition(f"unsupported signal kind: {condition.signal_kind}")


def _matches(observed: Any, operator: DecisionOperator, expected: Any) -> bool:
    if not isinstance(operator, DecisionOperator):
        raise InvalidDecisionCondition(f"noncanonical operator: {operator}")
    if operator is DecisionOperator.EXISTS:
        return observed is not _MISSING
    if operator is DecisionOperator.NOT_EXISTS:
        return observed is _MISSING
    if observed is _MISSING:
        return False
    if operator is DecisionOperator.EQ:
        return canonical_json_bytes(observed) == canonical_json_bytes(expected)
    if operator is DecisionOperator.NE:
        return canonical_json_bytes(observed) != canonical_json_bytes(expected)
    try:
        if operator is DecisionOperator.GT:
            return observed > expected
        if operator is DecisionOperator.GTE:
            return observed >= expected
        if operator is DecisionOperator.LT:
            return observed < expected
        if operator is DecisionOperator.LTE:
            return observed <= expected
    except TypeError:
        return False
    raise InvalidDecisionCondition(f"unsupported operator: {operator}")


def _evaluate_condition(context: DecisionContext, condition: DecisionCondition) -> ConditionEvaluation:
    observed = _resolve_signal(context, condition)
    matched = _matches(observed, condition.operator, condition.expected)
    evidence_observed = None if observed is _MISSING else observed
    return ConditionEvaluation(condition=condition, observed=evidence_observed, matched=matched)


def _validate_action(action: DecisionAction) -> None:
    if not isinstance(action.action_kind, DecisionActionKind):
        raise InvalidDecisionPolicy(f"noncanonical decision action: {action.action_kind}")
    if action.action_kind is DecisionActionKind.SELF_UPDATE:
        if not action.region or not action.key:
            raise InvalidDecisionPolicy("SELF_UPDATE requires region and key")
    elif action.action_kind is DecisionActionKind.ACCEPT_PROPOSAL:
        if not action.proposal_id:
            raise InvalidDecisionPolicy("ACCEPT_PROPOSAL requires proposal_id")
    elif action.action_kind is DecisionActionKind.NO_OP:
        return


def _validate_policy(policy: DecisionPolicy) -> None:
    if not policy.policy_id.strip():
        raise InvalidDecisionPolicy("policy_id must be non-empty")
    if policy.tie_break_rule != "LEXICAL_CANDIDATE_ID":
        raise InvalidDecisionPolicy(f"unsupported tie-break rule: {policy.tie_break_rule}")
    if not policy.candidates:
        raise InvalidDecisionPolicy("policy requires at least one candidate")
    ids = [candidate.candidate_id for candidate in policy.candidates]
    if any(not candidate_id.strip() for candidate_id in ids):
        raise InvalidDecisionPolicy("candidate_id must be non-empty")
    if len(ids) != len(set(ids)):
        raise InvalidDecisionPolicy("duplicate candidate_id")
    for candidate in policy.candidates:
        _validate_action(candidate.action)
        for term in candidate.score_terms:
            if not math.isfinite(float(term.score_if_true)) or not math.isfinite(float(term.score_if_false)):
                raise InvalidDecisionPolicy("score terms must be finite")


def select_policy_candidate(policy: DecisionPolicy, context: DecisionContext) -> PolicySelectionEvidence:
    _validate_policy(policy)
    evaluations: list[CandidateEvaluation] = []
    for candidate in sorted(policy.candidates, key=lambda item: item.candidate_id):
        hard_results = tuple(_evaluate_condition(context, item) for item in candidate.hard_conditions)
        eligible = all(item.matched for item in hard_results)
        score_results: list[ScoreTermEvaluation] = []
        total_score = 0.0
        if eligible:
            for term in candidate.score_terms:
                result = _evaluate_condition(context, term.condition)
                contribution = float(term.score_if_true if result.matched else term.score_if_false)
                score_results.append(ScoreTermEvaluation(result, contribution))
                total_score += contribution
        evaluations.append(
            CandidateEvaluation(
                candidate_id=candidate.candidate_id,
                eligible=eligible,
                score=total_score,
                hard_results=hard_results,
                score_results=tuple(score_results),
            )
        )

    eligible_evaluations = [item for item in evaluations if item.eligible]
    if not eligible_evaluations:
        raise NoEligibleDecisionCandidate(policy.policy_id)
    selected_eval = sorted(eligible_evaluations, key=lambda item: (-item.score, item.candidate_id))[0]
    selected_candidate = next(item for item in policy.candidates if item.candidate_id == selected_eval.candidate_id)
    payload = {
        "offspring_uid": context.offspring_uid,
        "policy_id": policy.policy_id,
        "context_digest": context.context_digest,
        "development_digest": context.development_digest,
        "selected_candidate_id": selected_candidate.candidate_id,
        "selected_action": selected_candidate.action,
        "candidate_evaluations": tuple(evaluations),
        "tie_break_rule": policy.tie_break_rule,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    evidence_without_digest = canonical_json_bytes(payload)
    selection_digest = hashlib.sha256(evidence_without_digest).hexdigest()
    canonical = canonical_json_bytes({**payload, "selection_digest": selection_digest})
    return PolicySelectionEvidence(
        offspring_uid=context.offspring_uid,
        policy_id=policy.policy_id,
        context=context,
        selected_candidate_id=selected_candidate.candidate_id,
        selected_action=selected_candidate.action,
        candidate_evaluations=tuple(evaluations),
        tie_break_rule=policy.tie_break_rule,
        selection_digest=selection_digest,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )


def apply_policy_selection(
    entity: OffspringEntity,
    selection: PolicySelectionEvidence,
    timestamp: str = "UNSPECIFIED",
) -> PolicyExecutionResult:
    if selection.offspring_uid != entity.ois.offspring_uid:
        raise StaleDecisionContext("selection belongs to a different offspring UID")
    pre_digest = entity.development_digest
    if pre_digest != selection.context.development_digest:
        raise StaleDecisionContext(
            f"selection context digest is stale: expected {selection.context.development_digest}, got {pre_digest}"
        )
    action = selection.selected_action
    evidence = dict(action.evidence)
    evidence.update({
        "policy_selection_digest": selection.selection_digest,
        "policy_id": selection.policy_id,
        "candidate_id": selection.selected_candidate_id,
        "decision_context_digest": selection.context.context_digest,
    })
    event: DevelopmentEvent | None
    if action.action_kind is DecisionActionKind.SELF_UPDATE:
        event = entity.self_update(
            action.region,
            action.key,
            action.value,
            timestamp=timestamp,
            evidence=evidence,
        )
    elif action.action_kind is DecisionActionKind.ACCEPT_PROPOSAL:
        event = entity.accept_proposal(
            action.proposal_id or "",
            timestamp=timestamp,
            evidence=evidence,
        )
    elif action.action_kind is DecisionActionKind.NO_OP:
        event = None
    else:
        raise InvalidDecisionPolicy(f"unsupported selected action: {action.action_kind}")
    post_digest = entity.development_digest
    payload = {
        "selection_digest": selection.selection_digest,
        "selected_candidate_id": selection.selected_candidate_id,
        "action_applied": event is not None,
        "development_event": event,
        "pre_development_digest": pre_digest,
        "post_development_digest": post_digest,
    }
    return PolicyExecutionResult(
        selection_digest=selection.selection_digest,
        selected_candidate_id=selection.selected_candidate_id,
        action_applied=event is not None,
        development_event=event,
        pre_development_digest=pre_digest,
        post_development_digest=post_digest,
        canonical_bytes=canonical_json_bytes(payload),
    )
