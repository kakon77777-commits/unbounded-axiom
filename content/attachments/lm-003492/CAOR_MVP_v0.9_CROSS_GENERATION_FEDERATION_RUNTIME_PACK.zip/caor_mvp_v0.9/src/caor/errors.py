class CAORError(Exception):
    """Base error for the CAOR reference runtime."""


class InvalidContributionBundle(CAORError):
    pass


class DuplicateContributionID(CAORError):
    pass


class InvalidWeight(CAORError):
    pass


class MissingSourceID(CAORError):
    pass


class SourceUIDReuseDenied(CAORError):
    pass


class ProtectedCoreWriteDenied(CAORError):
    pass


class InvalidLineageEvent(CAORError):
    pass


class AmbiguousClassification(CAORError):
    pass


class UnsupportedEvent(CAORError):
    pass


class ManifestIntegrityError(CAORError):
    pass


class InvalidDevelopmentEvent(CAORError):
    pass


class InvalidCounterfactualAction(CAORError):
    pass


class InvalidCounterfactualBranch(CAORError):
    pass


class InvalidDecisionPolicy(CAORError):
    pass


class InvalidDecisionCondition(CAORError):
    pass


class NoEligibleDecisionCandidate(CAORError):
    pass


class StaleDecisionContext(CAORError):
    pass


class InvalidPolicyConstitution(CAORError):
    pass


class PolicyAdoptionDenied(CAORError):
    pass


class StalePolicyProposal(CAORError):
    pass


class InvalidRootMetaConstitution(CAORError):
    pass


class ConstitutionAdoptionDenied(CAORError):
    pass


class StaleConstitutionAmendment(CAORError):
    pass

class InvalidPriorStandingOntology(CAORError):
    pass


class InvalidGenesisSafetyEnvelope(CAORError):
    pass


class InvalidRootVersion(CAORError):
    pass


class InvalidRootSuccessionProposal(CAORError):
    pass


class InvalidRatificationAttestation(CAORError):
    pass


class DuplicateRatifierAttestation(CAORError):
    pass


class UnknownRatifier(CAORError):
    pass


class RootSuccessionReviewDenied(CAORError):
    pass


class RootRatificationDenied(CAORError):
    pass


class RootCompatibilityValidationDenied(CAORError):
    pass


class RootSuccessionAdoptionDenied(CAORError):
    pass


class StaleRootSuccessionProposal(CAORError):
    pass


class GenesisDigestMismatch(CAORError):
    pass


class InvalidGenerationOntologyProfile(CAORError):
    pass


class InvalidRuntimeGeneration(CAORError):
    pass


class InvalidGenerationMigrationPolicy(CAORError):
    pass


class InvalidGenerationForkProposal(CAORError):
    pass


class InvalidGenerationRatificationAttestation(CAORError):
    pass


class UnknownGenerationRatifier(CAORError):
    pass


class DuplicateGenerationRatifierAttestation(CAORError):
    pass


class GenerationRatificationDenied(CAORError):
    pass


class GenerationCompatibilityValidationDenied(CAORError):
    pass


class InvalidGenerationTransitionEvidence(CAORError):
    pass


class GenerationForkReviewDenied(CAORError):
    pass


class StaleGenerationForkProposal(CAORError):
    pass


class GenerationAdoptionDenied(CAORError):
    pass

class InvalidBoundaryDisclosurePolicy(CAORError):
    pass


class InvalidOntologyTranslationProfile(CAORError):
    pass


class InvalidBoundaryContractProposal(CAORError):
    pass


class ForbiddenBoundaryAuthority(CAORError):
    pass

class InvalidBoundaryAuthorizationAttestation(CAORError):
    pass


class UnknownBoundaryEndpoint(CAORError):
    pass


class DuplicateBoundaryAuthorization(CAORError):
    pass


class BoundaryAuthorizationDenied(CAORError):
    pass


class BoundaryContractActivationDenied(CAORError):
    pass

class InvalidBoundaryContractLifecycle(CAORError):
    pass

class InvalidCrossGenerationRequest(CAORError):
    pass


class StaleBoundaryContract(CAORError):
    pass
