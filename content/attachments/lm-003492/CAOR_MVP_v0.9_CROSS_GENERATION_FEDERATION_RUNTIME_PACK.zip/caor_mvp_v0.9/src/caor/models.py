from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping, Tuple


class SourceKind(str, Enum):
    HUMAN_PROFILE = "HUMAN_PROFILE"
    AI_ENTITY = "AI_ENTITY"
    HYBRID_ENTITY = "HYBRID_ENTITY"
    SYNTHETIC_PROFILE = "SYNTHETIC_PROFILE"


class ContributionCategory(str, Enum):
    IDENTITY_TRAIT = "IDENTITY_TRAIT"
    VALUE_TRAIT = "VALUE_TRAIT"
    COGNITIVE_TRAIT = "COGNITIVE_TRAIT"
    MEMORY_SEED = "MEMORY_SEED"
    CAPABILITY_TRAIT = "CAPABILITY_TRAIT"
    CULTURAL_SEMANTIC_TRAIT = "CULTURAL_SEMANTIC_TRAIT"
    CONSTRAINT = "CONSTRAINT"


@dataclass(frozen=True)
class Contribution:
    category: ContributionCategory
    source_id: str
    contribution_id: str
    name: str
    value: Any
    weight: float
    provenance_note: str = ""


@dataclass(frozen=True)
class ParentContributionBundle:
    source_id: str
    source_kind: SourceKind
    contributions: Tuple[Contribution, ...]
    provenance: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ContributionManifest:
    source_ids: Tuple[str, ...]
    source_kinds: Tuple[Tuple[str, str], ...]
    contributions: Tuple[Contribution, ...]
    bundle_provenance: Tuple[Mapping[str, Any], ...]
    canonical_bytes: bytes
    digest: str

@dataclass(frozen=True)
class OffspringIdentitySpecification:
    offspring_uid: str
    identity_root: str
    memory_root: str
    state_namespace: str
    lineage_id: str
    generation_event: str
    manifest_digest: str
    parent_contributions: Tuple[str, ...]
    protected_core: Tuple[str, ...]
    mutable_regions: Tuple[str, ...]
    parent_write_policy: str
    provider_write_policy: str
    development_policy: Mapping[str, Any]
    created_at: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class ProposalRecord:
    proposal_id: str
    source_id: str
    region: str
    key: str
    value: Any
    status: str
