from __future__ import annotations

from dataclasses import dataclass, field
import hashlib

from .canonical import canonical_json_bytes
from .errors import (
    CAORError,
    InvalidDecisionPolicy,
    InvalidPolicyConstitution,
    PolicyAdoptionDenied,
    StalePolicyProposal,
)
from typing import Any, Mapping

from .decision import (
    ConditionEvaluation,
    DecisionActionKind,
    DecisionCondition,
    DecisionContext,
    DecisionPolicy,
    _evaluate_condition,
    _validate_policy,
    select_policy_candidate,
)


@dataclass(frozen=True)
class PolicyVersion:
    version_id: str
    version_number: int
    policy: DecisionPolicy
    policy_digest: str
    parent_version_id: str | None
    parent_policy_digest: str | None
    adopted_from_proposal_id: str | None
    created_at: str
    canonical_bytes: bytes


def decision_policy_digest(policy: DecisionPolicy) -> str:
    return hashlib.sha256(canonical_json_bytes(policy)).hexdigest()


def create_initial_policy_version(
    policy: DecisionPolicy,
    created_at: str = "UNSPECIFIED",
) -> PolicyVersion:
    policy_digest = decision_policy_digest(policy)
    identity_payload = {
        "version_number": 1,
        "policy_digest": policy_digest,
        "parent_version_id": None,
        "parent_policy_digest": None,
        "adopted_from_proposal_id": None,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity_payload)).hexdigest()
    payload = {
        "version_id": version_id,
        **identity_payload,
        "policy": policy,
    }
    canonical = canonical_json_bytes(payload)
    return PolicyVersion(
        version_id=version_id,
        version_number=1,
        policy=policy,
        policy_digest=policy_digest,
        parent_version_id=None,
        parent_policy_digest=None,
        adopted_from_proposal_id=None,
        created_at=created_at,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class PolicyEvolutionTemplate:
    template_id: str
    trigger_conditions: tuple[DecisionCondition, ...]
    proposed_policy: DecisionPolicy
    rationale: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PolicyChangeProposal:
    proposal_id: str
    offspring_uid: str
    template_id: str
    base_version_id: str
    base_policy_digest: str
    context_digest: str
    development_digest: str
    proposed_policy: DecisionPolicy
    proposed_policy_digest: str
    trigger_results: tuple[ConditionEvaluation, ...]
    rationale: Mapping[str, Any]
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def generate_policy_change_proposal(
    offspring_uid: str,
    current_version: PolicyVersion,
    context: DecisionContext,
    template: PolicyEvolutionTemplate,
) -> PolicyChangeProposal | None:
    if not template.template_id.strip():
        raise ValueError("template_id must be non-empty")
    trigger_results = tuple(_evaluate_condition(context, condition) for condition in template.trigger_conditions)
    if not all(result.matched for result in trigger_results):
        return None
    proposed_policy_digest = decision_policy_digest(template.proposed_policy)
    payload = {
        "offspring_uid": offspring_uid,
        "template_id": template.template_id,
        "base_version_id": current_version.version_id,
        "base_policy_digest": current_version.policy_digest,
        "context_digest": context.context_digest,
        "development_digest": context.development_digest,
        "proposed_policy": template.proposed_policy,
        "proposed_policy_digest": proposed_policy_digest,
        "trigger_results": trigger_results,
        "rationale": dict(template.rationale),
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    proposal_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"proposal_id": proposal_id, **payload})
    return PolicyChangeProposal(
        proposal_id=proposal_id,
        offspring_uid=offspring_uid,
        template_id=template.template_id,
        base_version_id=current_version.version_id,
        base_policy_digest=current_version.policy_digest,
        context_digest=context.context_digest,
        development_digest=context.development_digest,
        proposed_policy=template.proposed_policy,
        proposed_policy_digest=proposed_policy_digest,
        trigger_results=trigger_results,
        rationale=dict(template.rationale),
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class PolicyConstitution:
    constitution_id: str
    constitution_version: int
    allowed_action_kinds: tuple[DecisionActionKind, ...]
    require_noop_candidate: bool
    max_candidate_count: int
    min_score_term: float
    max_score_term: float
    required_tie_break_rule: str
    constitution_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class ConstitutionalRuleResult:
    rule_id: str
    passed: bool
    detail: Mapping[str, Any]


@dataclass(frozen=True)
class ConstitutionalReviewEvidence:
    proposal_id: str
    constitution_id: str
    constitution_digest: str
    rule_results: tuple[ConstitutionalRuleResult, ...]
    passed: bool
    review_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def create_policy_constitution(
    constitution_id: str,
    constitution_version: int,
    allowed_action_kinds: tuple[DecisionActionKind, ...],
    require_noop_candidate: bool,
    max_candidate_count: int,
    min_score_term: float,
    max_score_term: float,
    required_tie_break_rule: str,
) -> PolicyConstitution:
    if not constitution_id.strip():
        raise InvalidPolicyConstitution("constitution_id must be non-empty")
    if constitution_version < 1:
        raise InvalidPolicyConstitution("constitution_version must be >= 1")
    if not allowed_action_kinds:
        raise InvalidPolicyConstitution("allowed_action_kinds must be non-empty")
    if any(not isinstance(kind, DecisionActionKind) for kind in allowed_action_kinds):
        raise InvalidPolicyConstitution("allowed_action_kinds contains a noncanonical action kind")
    if max_candidate_count < 1:
        raise InvalidPolicyConstitution("max_candidate_count must be >= 1")
    if float(min_score_term) > float(max_score_term):
        raise InvalidPolicyConstitution("min_score_term must be <= max_score_term")
    if not required_tie_break_rule.strip():
        raise InvalidPolicyConstitution("required_tie_break_rule must be non-empty")
    payload = {
        "constitution_id": constitution_id,
        "constitution_version": constitution_version,
        "allowed_action_kinds": tuple(allowed_action_kinds),
        "require_noop_candidate": bool(require_noop_candidate),
        "max_candidate_count": max_candidate_count,
        "min_score_term": float(min_score_term),
        "max_score_term": float(max_score_term),
        "required_tie_break_rule": required_tie_break_rule,
    }
    canonical_without_digest = canonical_json_bytes(payload)
    digest = hashlib.sha256(canonical_without_digest).hexdigest()
    canonical = canonical_json_bytes({**payload, "constitution_digest": digest})
    return PolicyConstitution(
        constitution_id=constitution_id,
        constitution_version=constitution_version,
        allowed_action_kinds=tuple(allowed_action_kinds),
        require_noop_candidate=bool(require_noop_candidate),
        max_candidate_count=max_candidate_count,
        min_score_term=float(min_score_term),
        max_score_term=float(max_score_term),
        required_tie_break_rule=required_tie_break_rule,
        constitution_digest=digest,
        canonical_bytes=canonical,
    )


def review_policy_proposal(
    proposal: PolicyChangeProposal,
    constitution: PolicyConstitution,
) -> ConstitutionalReviewEvidence:
    policy = proposal.proposed_policy
    results: list[ConstitutionalRuleResult] = []

    try:
        _validate_policy(policy)
        structural_passed = True
        structural_detail = {"error": None}
    except InvalidDecisionPolicy as exc:
        structural_passed = False
        structural_detail = {"error": str(exc)}
    results.append(ConstitutionalRuleResult("STRUCTURAL_VALIDITY", structural_passed, structural_detail))

    tie_passed = policy.tie_break_rule == constitution.required_tie_break_rule
    results.append(ConstitutionalRuleResult(
        "REQUIRED_TIE_BREAK_RULE",
        tie_passed,
        {"required": constitution.required_tie_break_rule, "observed": policy.tie_break_rule},
    ))

    count_passed = len(policy.candidates) <= constitution.max_candidate_count
    results.append(ConstitutionalRuleResult(
        "MAX_CANDIDATE_COUNT",
        count_passed,
        {"maximum": constitution.max_candidate_count, "observed": len(policy.candidates)},
    ))

    has_noop = any(candidate.action.action_kind is DecisionActionKind.NO_OP for candidate in policy.candidates)
    noop_passed = (not constitution.require_noop_candidate) or has_noop
    results.append(ConstitutionalRuleResult(
        "REQUIRED_NO_OP",
        noop_passed,
        {"required": constitution.require_noop_candidate, "observed": has_noop},
    ))

    allowed = set(constitution.allowed_action_kinds)
    observed_action_kinds = tuple(candidate.action.action_kind for candidate in policy.candidates)
    actions_passed = all(kind in allowed for kind in observed_action_kinds)
    results.append(ConstitutionalRuleResult(
        "ALLOWED_ACTION_KINDS",
        actions_passed,
        {
            "allowed": tuple(sorted(kind.value for kind in allowed)),
            "observed": tuple(kind.value for kind in observed_action_kinds),
        },
    ))

    score_values: list[float] = []
    for candidate in policy.candidates:
        for term in candidate.score_terms:
            score_values.extend((float(term.score_if_true), float(term.score_if_false)))
    score_passed = all(
        constitution.min_score_term <= value <= constitution.max_score_term
        for value in score_values
    )
    results.append(ConstitutionalRuleResult(
        "SCORE_BOUNDS",
        score_passed,
        {
            "minimum": constitution.min_score_term,
            "maximum": constitution.max_score_term,
            "observed": tuple(score_values),
        },
    ))

    rule_results = tuple(results)
    passed = all(result.passed for result in rule_results)
    payload = {
        "proposal_id": proposal.proposal_id,
        "constitution_id": constitution.constitution_id,
        "constitution_digest": constitution.constitution_digest,
        "proposed_policy_digest": proposal.proposed_policy_digest,
        "rule_results": rule_results,
        "passed": passed,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    review_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "review_digest": review_digest})
    return ConstitutionalReviewEvidence(
        proposal_id=proposal.proposal_id,
        constitution_id=constitution.constitution_id,
        constitution_digest=constitution.constitution_digest,
        rule_results=rule_results,
        passed=passed,
        review_digest=review_digest,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class PolicyValidationCase:
    case_id: str
    context: DecisionContext
    expected_candidate_id: str | None = None


@dataclass(frozen=True)
class PolicyValidationEvidence:
    proposal_id: str
    case_id: str
    passed: bool
    selected_candidate_id: str | None
    selection_digest: str | None
    error_type: str | None
    error_message: str | None
    validation_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class PolicyAdoptionEvidence:
    proposal_id: str
    review_digest: str
    validation_digests: tuple[str, ...]
    old_version_id: str
    old_policy_digest: str
    new_version_id: str
    new_policy_digest: str
    status: str
    timestamp: str
    adoption_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def validate_proposed_policy(
    proposal: PolicyChangeProposal,
    cases: tuple[PolicyValidationCase, ...],
) -> tuple[PolicyValidationEvidence, ...]:
    evidence_items: list[PolicyValidationEvidence] = []
    for case in cases:
        if not case.case_id.strip():
            raise ValueError("validation case_id must be non-empty")
        selected_candidate_id: str | None = None
        selection_digest: str | None = None
        error_type: str | None = None
        error_message: str | None = None
        passed = False
        try:
            selection = select_policy_candidate(proposal.proposed_policy, case.context)
            selected_candidate_id = selection.selected_candidate_id
            selection_digest = selection.selection_digest
            if case.expected_candidate_id is not None and selected_candidate_id != case.expected_candidate_id:
                error_type = "EXPECTED_CANDIDATE_MISMATCH"
                error_message = (
                    f"expected {case.expected_candidate_id}, selected {selected_candidate_id}"
                )
            else:
                passed = True
        except CAORError as exc:
            error_type = type(exc).__name__
            error_message = str(exc)
        payload = {
            "proposal_id": proposal.proposal_id,
            "case_id": case.case_id,
            "context_digest": case.context.context_digest,
            "expected_candidate_id": case.expected_candidate_id,
            "selected_candidate_id": selected_candidate_id,
            "selection_digest": selection_digest,
            "passed": passed,
            "error_type": error_type,
            "error_message": error_message,
        }
        validation_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        canonical = canonical_json_bytes({**payload, "validation_digest": validation_digest})
        evidence_items.append(PolicyValidationEvidence(
            proposal_id=proposal.proposal_id,
            case_id=case.case_id,
            passed=passed,
            selected_candidate_id=selected_candidate_id,
            selection_digest=selection_digest,
            error_type=error_type,
            error_message=error_message,
            validation_digest=validation_digest,
            canonical_bytes=canonical,
        ))
    return tuple(evidence_items)


def _create_next_policy_version(
    current: PolicyVersion,
    proposal: PolicyChangeProposal,
    created_at: str,
) -> PolicyVersion:
    policy = proposal.proposed_policy
    policy_digest = decision_policy_digest(policy)
    version_number = current.version_number + 1
    identity_payload = {
        "version_number": version_number,
        "policy_digest": policy_digest,
        "parent_version_id": current.version_id,
        "parent_policy_digest": current.policy_digest,
        "adopted_from_proposal_id": proposal.proposal_id,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity_payload)).hexdigest()
    payload = {"version_id": version_id, **identity_payload, "policy": policy}
    canonical = canonical_json_bytes(payload)
    return PolicyVersion(
        version_id=version_id,
        version_number=version_number,
        policy=policy,
        policy_digest=policy_digest,
        parent_version_id=current.version_id,
        parent_policy_digest=current.policy_digest,
        adopted_from_proposal_id=proposal.proposal_id,
        created_at=created_at,
        canonical_bytes=canonical,
    )


class PolicyRegistry:
    def __init__(self, offspring_uid: str) -> None:
        if not offspring_uid.strip():
            raise ValueError("offspring_uid must be non-empty")
        self.offspring_uid = offspring_uid
        self._versions: list[PolicyVersion] = []
        self._versions_by_id: dict[str, PolicyVersion] = {}
        self._active_version_id: str | None = None
        self._proposals: dict[str, PolicyChangeProposal] = {}
        self._reviews: dict[str, ConstitutionalReviewEvidence] = {}
        self._adoptions: list[PolicyAdoptionEvidence] = []

    @property
    def versions(self) -> tuple[PolicyVersion, ...]:
        return tuple(self._versions)

    @property
    def active_version(self) -> PolicyVersion:
        if self._active_version_id is None:
            raise PolicyAdoptionDenied("policy registry is not initialized")
        return self._versions_by_id[self._active_version_id]

    @property
    def proposals(self) -> tuple[PolicyChangeProposal, ...]:
        return tuple(self._proposals.values())

    @property
    def reviews(self) -> tuple[ConstitutionalReviewEvidence, ...]:
        return tuple(self._reviews.values())

    @property
    def adoptions(self) -> tuple[PolicyAdoptionEvidence, ...]:
        return tuple(self._adoptions)

    def initialize(self, policy: DecisionPolicy, created_at: str = "UNSPECIFIED") -> PolicyVersion:
        if self._versions:
            raise PolicyAdoptionDenied("policy registry is already initialized")
        version = create_initial_policy_version(policy, created_at=created_at)
        self._versions.append(version)
        self._versions_by_id[version.version_id] = version
        self._active_version_id = version.version_id
        return version

    def get_version(self, version_id: str) -> PolicyVersion:
        try:
            return self._versions_by_id[version_id]
        except KeyError as exc:
            raise KeyError(f"unknown policy version: {version_id}") from exc

    def record_proposal(self, proposal: PolicyChangeProposal) -> None:
        if proposal.offspring_uid != self.offspring_uid:
            raise PolicyAdoptionDenied("proposal belongs to a different offspring UID")
        existing = self._proposals.get(proposal.proposal_id)
        if existing is not None and existing != proposal:
            raise PolicyAdoptionDenied("proposal ID collision")
        self._proposals[proposal.proposal_id] = proposal

    def record_review(self, review: ConstitutionalReviewEvidence) -> None:
        existing = self._reviews.get(review.review_digest)
        if existing is not None and existing != review:
            raise PolicyAdoptionDenied("review digest collision")
        self._reviews[review.review_digest] = review

    def adopt(
        self,
        proposal: PolicyChangeProposal,
        review: ConstitutionalReviewEvidence,
        validations: tuple[PolicyValidationEvidence, ...],
        timestamp: str = "UNSPECIFIED",
    ) -> PolicyVersion:
        current = self.active_version
        if proposal.offspring_uid != self.offspring_uid:
            raise PolicyAdoptionDenied("proposal belongs to a different offspring UID")
        if proposal.base_version_id != current.version_id or proposal.base_policy_digest != current.policy_digest:
            raise StalePolicyProposal(
                f"proposal base {proposal.base_version_id}/{proposal.base_policy_digest} is not active"
            )
        if proposal.proposed_policy_digest != decision_policy_digest(proposal.proposed_policy):
            raise PolicyAdoptionDenied("proposed policy digest mismatch")
        if review.proposal_id != proposal.proposal_id:
            raise PolicyAdoptionDenied("constitutional review belongs to a different proposal")
        if not review.passed:
            raise PolicyAdoptionDenied("constitutional review did not pass")
        if not validations:
            raise PolicyAdoptionDenied("at least one validation case is required")
        if any(item.proposal_id != proposal.proposal_id for item in validations):
            raise PolicyAdoptionDenied("validation evidence belongs to a different proposal")
        if not all(item.passed for item in validations):
            raise PolicyAdoptionDenied("one or more validation cases failed")

        self.record_proposal(proposal)
        self.record_review(review)
        new_version = _create_next_policy_version(current, proposal, timestamp)
        validation_digests = tuple(item.validation_digest for item in validations)
        adoption_payload = {
            "proposal_id": proposal.proposal_id,
            "review_digest": review.review_digest,
            "validation_digests": validation_digests,
            "old_version_id": current.version_id,
            "old_policy_digest": current.policy_digest,
            "new_version_id": new_version.version_id,
            "new_policy_digest": new_version.policy_digest,
            "status": "ADOPTED",
            "timestamp": timestamp,
            "subjectivity_claimed": False,
            "free_will_claimed": False,
            "autonomy_claimed": False,
        }
        adoption_digest = hashlib.sha256(canonical_json_bytes(adoption_payload)).hexdigest()
        adoption = PolicyAdoptionEvidence(
            proposal_id=proposal.proposal_id,
            review_digest=review.review_digest,
            validation_digests=validation_digests,
            old_version_id=current.version_id,
            old_policy_digest=current.policy_digest,
            new_version_id=new_version.version_id,
            new_policy_digest=new_version.policy_digest,
            status="ADOPTED",
            timestamp=timestamp,
            adoption_digest=adoption_digest,
            subjectivity_claimed=False,
            free_will_claimed=False,
            autonomy_claimed=False,
            canonical_bytes=canonical_json_bytes({**adoption_payload, "adoption_digest": adoption_digest}),
        )
        self._versions.append(new_version)
        self._versions_by_id[new_version.version_id] = new_version
        self._active_version_id = new_version.version_id
        self._adoptions.append(adoption)
        return new_version
