PROTECTED_CORE_FIELDS = (
    "offspring_uid",
    "identity_root",
    "memory_root",
    "lineage_id",
    "manifest_digest",
    "lineage_provenance",
    "generation_event",
)

MUTABLE_REGIONS = ("preferences", "skills", "notes")

DEFAULT_PARENT_WRITE_POLICY = "PROPOSAL_ONLY"
DEFAULT_PROVIDER_WRITE_POLICY = "ADMIN_BOUNDARY_ONLY"

DEFAULT_DEVELOPMENT_POLICY = {
    "mode": "INDEPENDENT_MUTABLE",
    "parent_proposals": "ALLOWED",
    "parent_direct_core_write": "DENIED",
    "provider_direct_core_write": "DENIED_EXCEPT_RECOVERY_METADATA",
    "self_updates": "ALLOWED_IN_MUTABLE_REGIONS",
}
