from __future__ import annotations

import hashlib
from typing import Sequence

from .canonical import canonical_json_bytes
from .errors import DuplicateContributionID, InvalidContributionBundle, InvalidWeight, MissingSourceID
from .models import Contribution, ContributionManifest, ParentContributionBundle


def normalize_contributions(bundles: Sequence[ParentContributionBundle]) -> ContributionManifest:
    if not bundles:
        raise InvalidContributionBundle("at least one source bundle is required")

    seen_ids: set[str] = set()
    normalized: list[Contribution] = []
    provenance_rows: list[dict] = []

    for bundle in bundles:
        if not bundle.source_id.strip():
            raise MissingSourceID("source_id must be non-empty")
        provenance_rows.append({"source_id": bundle.source_id, "provenance": dict(bundle.provenance)})
        for item in bundle.contributions:
            if item.source_id != bundle.source_id:
                raise InvalidContributionBundle("contribution source_id must match bundle source_id")
            if item.contribution_id in seen_ids:
                raise DuplicateContributionID(item.contribution_id)
            if not 0.0 <= item.weight <= 1.0:
                raise InvalidWeight(str(item.weight))
            seen_ids.add(item.contribution_id)
            normalized.append(item)

    normalized.sort(key=lambda item: (item.source_id, item.contribution_id, item.category.value, item.name))
    provenance_rows.sort(key=lambda row: row["source_id"])
    source_ids = tuple(sorted({bundle.source_id for bundle in bundles}))
    source_kinds = tuple(sorted((bundle.source_id, bundle.source_kind.value) for bundle in bundles))
    payload = {
        "source_ids": source_ids,
        "source_kinds": source_kinds,
        "contributions": tuple(normalized),
        "bundle_provenance": tuple(provenance_rows),
    }
    canonical = canonical_json_bytes(payload)
    digest = hashlib.sha256(canonical).hexdigest()
    return ContributionManifest(
        source_ids=source_ids,
        source_kinds=source_kinds,
        contributions=tuple(normalized),
        bundle_provenance=tuple(provenance_rows),
        canonical_bytes=canonical,
        digest=digest,
    )
