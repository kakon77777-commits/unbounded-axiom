from __future__ import annotations

from dataclasses import dataclass

from .errors import AmbiguousClassification, UnsupportedEvent
from .lineage import LineageEventType


@dataclass(frozen=True)
class ClassificationEvidence:
    source_count: int
    explicit_checkpoint_restore: bool = False
    checkpoint_reference: bool = False
    substrate_change: bool = False
    no_parallel_identity: bool = False
    continuity_preserved: bool = False
    state_transfer: bool = False
    source_retired_or_quiesced: bool = False
    same_lineage: bool = False
    new_branch: bool = False
    allowed_mutation: bool = False
    direct_duplicate: bool = False
    synthesis_manifest: bool = False
    shared_pre_fork_history: bool = False
    explicit_merge: bool = False
    merge_sources: bool = False
    new_identity_root: bool = False
    new_memory_root: bool = False
    new_state_namespace: bool = False
    new_lineage_id: bool = False
    independent_development_policy: bool = False
    source_uid_reuse: bool = False


def _validate_noncontradiction(e: ClassificationEvidence) -> None:
    if e.explicit_checkpoint_restore and e.explicit_merge:
        raise AmbiguousClassification("event cannot be both explicit RESTORE and explicit MERGE")
    if e.direct_duplicate and e.new_branch:
        raise AmbiguousClassification("direct duplicate and divergent branch evidence conflict")
    if e.source_count < 1:
        raise UnsupportedEvent("source_count must be at least 1")


def classify_event(evidence: ClassificationEvidence) -> LineageEventType:
    e = evidence
    _validate_noncontradiction(e)

    if e.explicit_checkpoint_restore and e.checkpoint_reference and e.source_count == 1:
        return LineageEventType.RESTORE

    if (
        e.substrate_change
        and e.no_parallel_identity
        and e.continuity_preserved
        and e.state_transfer
        and e.source_retired_or_quiesced
        and e.source_count == 1
    ):
        return LineageEventType.MIGRATION

    if e.same_lineage and not e.new_branch and e.allowed_mutation and e.source_count == 1:
        return LineageEventType.UPDATE

    if e.direct_duplicate and not e.synthesis_manifest and e.source_count == 1:
        return LineageEventType.COPY

    if e.source_count == 1 and e.new_branch and e.shared_pre_fork_history and not e.synthesis_manifest:
        return LineageEventType.FORK

    if e.source_count >= 2 and e.explicit_merge and e.merge_sources:
        return LineageEventType.MERGE

    offspring_invariants = (
        e.synthesis_manifest,
        e.new_identity_root,
        e.new_memory_root,
        e.new_state_namespace,
        e.new_lineage_id,
        e.independent_development_policy,
        not e.source_uid_reuse,
    )
    if all(offspring_invariants):
        return LineageEventType.OFFSPRING

    raise UnsupportedEvent(f"event evidence is not classifiable: {evidence!r}")
