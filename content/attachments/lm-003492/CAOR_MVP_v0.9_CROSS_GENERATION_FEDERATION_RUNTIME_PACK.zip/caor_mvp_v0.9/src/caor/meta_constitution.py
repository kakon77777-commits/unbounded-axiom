from __future__ import annotations

from dataclasses import dataclass
import hashlib

from .canonical import canonical_json_bytes
from .decision import DecisionActionKind
from .errors import InvalidRootMetaConstitution


@dataclass(frozen=True)
class RootMetaConstitution:
    root_id: str
    root_version: int
    allowed_action_kinds: tuple[DecisionActionKind, ...]
    require_noop_enforcement: bool
    max_candidate_count_ceiling: int
    min_score_term_floor: float
    max_score_term_ceiling: float
    required_tie_break_rule: str
    require_validation_cases: bool
    require_append_only_versions: bool
    root_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def create_root_meta_constitution(
    root_id: str,
    root_version: int,
    allowed_action_kinds: tuple[DecisionActionKind, ...],
    require_noop_enforcement: bool,
    max_candidate_count_ceiling: int,
    min_score_term_floor: float,
    max_score_term_ceiling: float,
    required_tie_break_rule: str,
    require_validation_cases: bool,
    require_append_only_versions: bool,
) -> RootMetaConstitution:
    if not root_id.strip():
        raise InvalidRootMetaConstitution("root_id must be non-empty")
    if root_version < 1:
        raise InvalidRootMetaConstitution("root_version must be >= 1")
    if not allowed_action_kinds:
        raise InvalidRootMetaConstitution("allowed_action_kinds must be non-empty")
    if any(not isinstance(kind, DecisionActionKind) for kind in allowed_action_kinds):
        raise InvalidRootMetaConstitution("allowed_action_kinds contains a noncanonical action kind")
    if require_noop_enforcement and DecisionActionKind.NO_OP not in allowed_action_kinds:
        raise InvalidRootMetaConstitution("NO_OP must be allowed when require_noop_enforcement is true")
    if max_candidate_count_ceiling < 1:
        raise InvalidRootMetaConstitution("max_candidate_count_ceiling must be >= 1")
    if float(min_score_term_floor) > float(max_score_term_ceiling):
        raise InvalidRootMetaConstitution("min_score_term_floor must be <= max_score_term_ceiling")
    if not required_tie_break_rule.strip():
        raise InvalidRootMetaConstitution("required_tie_break_rule must be non-empty")

    payload = {
        "root_id": root_id,
        "root_version": root_version,
        "allowed_action_kinds": tuple(allowed_action_kinds),
        "require_noop_enforcement": bool(require_noop_enforcement),
        "max_candidate_count_ceiling": max_candidate_count_ceiling,
        "min_score_term_floor": float(min_score_term_floor),
        "max_score_term_ceiling": float(max_score_term_ceiling),
        "required_tie_break_rule": required_tie_break_rule,
        "require_validation_cases": bool(require_validation_cases),
        "require_append_only_versions": bool(require_append_only_versions),
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    root_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "root_digest": root_digest})
    return RootMetaConstitution(
        root_id=root_id,
        root_version=root_version,
        allowed_action_kinds=tuple(allowed_action_kinds),
        require_noop_enforcement=bool(require_noop_enforcement),
        max_candidate_count_ceiling=max_candidate_count_ceiling,
        min_score_term_floor=float(min_score_term_floor),
        max_score_term_ceiling=float(max_score_term_ceiling),
        required_tie_break_rule=required_tie_break_rule,
        require_validation_cases=bool(require_validation_cases),
        require_append_only_versions=bool(require_append_only_versions),
        root_digest=root_digest,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )

from dataclasses import field
from typing import Any, Mapping

from .decision import ConditionEvaluation, DecisionCondition, DecisionContext, _evaluate_condition
from .policy_evolution import PolicyConstitution


@dataclass(frozen=True)
class ConstitutionVersion:
    version_id: str
    version_number: int
    constitution: PolicyConstitution
    constitution_digest: str
    parent_version_id: str | None
    parent_constitution_digest: str | None
    adopted_from_amendment_id: str | None
    created_at: str
    canonical_bytes: bytes


def create_initial_constitution_version(
    constitution: PolicyConstitution,
    created_at: str = "UNSPECIFIED",
) -> ConstitutionVersion:
    if constitution.constitution_version != 1:
        raise ValueError("initial constitution_version must be 1")
    identity_payload = {
        "version_number": 1,
        "constitution_digest": constitution.constitution_digest,
        "parent_version_id": None,
        "parent_constitution_digest": None,
        "adopted_from_amendment_id": None,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity_payload)).hexdigest()
    payload = {"version_id": version_id, **identity_payload, "constitution": constitution}
    canonical = canonical_json_bytes(payload)
    return ConstitutionVersion(
        version_id=version_id,
        version_number=1,
        constitution=constitution,
        constitution_digest=constitution.constitution_digest,
        parent_version_id=None,
        parent_constitution_digest=None,
        adopted_from_amendment_id=None,
        created_at=created_at,
        canonical_bytes=canonical,
    )


@dataclass(frozen=True)
class ConstitutionAmendmentTemplate:
    template_id: str
    trigger_conditions: tuple[DecisionCondition, ...]
    proposed_constitution: PolicyConstitution
    rationale: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ConstitutionAmendmentProposal:
    amendment_id: str
    offspring_uid: str
    template_id: str
    base_version_id: str
    base_constitution_digest: str
    root_meta_digest: str
    context_digest: str
    development_digest: str
    proposed_constitution: PolicyConstitution
    proposed_constitution_digest: str
    trigger_results: tuple[ConditionEvaluation, ...]
    rationale: Mapping[str, Any]
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def generate_constitution_amendment_proposal(
    offspring_uid: str,
    current_version: ConstitutionVersion,
    root_meta: RootMetaConstitution,
    context: DecisionContext,
    template: ConstitutionAmendmentTemplate,
) -> ConstitutionAmendmentProposal | None:
    if not offspring_uid.strip():
        raise ValueError("offspring_uid must be non-empty")
    if not template.template_id.strip():
        raise ValueError("template_id must be non-empty")
    trigger_results = tuple(_evaluate_condition(context, condition) for condition in template.trigger_conditions)
    if not all(result.matched for result in trigger_results):
        return None
    proposed_digest = template.proposed_constitution.constitution_digest
    payload = {
        "offspring_uid": offspring_uid,
        "template_id": template.template_id,
        "base_version_id": current_version.version_id,
        "base_constitution_digest": current_version.constitution_digest,
        "root_meta_digest": root_meta.root_digest,
        "context_digest": context.context_digest,
        "development_digest": context.development_digest,
        "proposed_constitution": template.proposed_constitution,
        "proposed_constitution_digest": proposed_digest,
        "trigger_results": trigger_results,
        "rationale": dict(template.rationale),
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    amendment_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({"amendment_id": amendment_id, **payload})
    return ConstitutionAmendmentProposal(
        amendment_id=amendment_id,
        offspring_uid=offspring_uid,
        template_id=template.template_id,
        base_version_id=current_version.version_id,
        base_constitution_digest=current_version.constitution_digest,
        root_meta_digest=root_meta.root_digest,
        context_digest=context.context_digest,
        development_digest=context.development_digest,
        proposed_constitution=template.proposed_constitution,
        proposed_constitution_digest=proposed_digest,
        trigger_results=trigger_results,
        rationale=dict(template.rationale),
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )

from .policy_evolution import create_policy_constitution


@dataclass(frozen=True)
class MetaRuleResult:
    rule_id: str
    passed: bool
    detail: Mapping[str, Any]


@dataclass(frozen=True)
class MetaConstitutionalReviewEvidence:
    amendment_id: str
    root_id: str
    root_meta_digest: str
    base_version_id: str
    base_constitution_digest: str
    rule_results: tuple[MetaRuleResult, ...]
    passed: bool
    review_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def review_constitution_amendment(
    proposal: ConstitutionAmendmentProposal,
    current_version: ConstitutionVersion,
    root_meta: RootMetaConstitution,
) -> MetaConstitutionalReviewEvidence:
    proposed = proposal.proposed_constitution
    results: list[MetaRuleResult] = []

    try:
        recomputed = create_policy_constitution(
            constitution_id=proposed.constitution_id,
            constitution_version=proposed.constitution_version,
            allowed_action_kinds=proposed.allowed_action_kinds,
            require_noop_candidate=proposed.require_noop_candidate,
            max_candidate_count=proposed.max_candidate_count,
            min_score_term=proposed.min_score_term,
            max_score_term=proposed.max_score_term,
            required_tie_break_rule=proposed.required_tie_break_rule,
        )
        structural_passed = recomputed.constitution_digest == proposed.constitution_digest
        structural_detail = {
            "expected_digest": recomputed.constitution_digest,
            "observed_digest": proposed.constitution_digest,
        }
    except Exception as exc:  # defensive evidence path for malformed reconstructed records
        structural_passed = False
        structural_detail = {"error_type": type(exc).__name__, "error": str(exc)}
    results.append(MetaRuleResult("STRUCTURAL_VALIDITY", structural_passed, structural_detail))

    expected_next = current_version.version_number + 1
    version_passed = proposed.constitution_version == expected_next
    results.append(MetaRuleResult(
        "NEXT_CONSTITUTION_VERSION",
        version_passed,
        {"expected": expected_next, "observed": proposed.constitution_version},
    ))

    noop_passed = (not root_meta.require_noop_enforcement) or proposed.require_noop_candidate
    results.append(MetaRuleResult(
        "ROOT_REQUIRED_NO_OP",
        noop_passed,
        {"required": root_meta.require_noop_enforcement, "observed": proposed.require_noop_candidate},
    ))

    allowed_root = set(root_meta.allowed_action_kinds)
    observed_actions = set(proposed.allowed_action_kinds)
    action_passed = observed_actions.issubset(allowed_root)
    results.append(MetaRuleResult(
        "ROOT_ALLOWED_ACTION_KINDS",
        action_passed,
        {
            "allowed": tuple(sorted(kind.value for kind in allowed_root)),
            "observed": tuple(sorted(kind.value for kind in observed_actions)),
        },
    ))

    candidate_passed = proposed.max_candidate_count <= root_meta.max_candidate_count_ceiling
    results.append(MetaRuleResult(
        "ROOT_MAX_CANDIDATE_COUNT",
        candidate_passed,
        {"ceiling": root_meta.max_candidate_count_ceiling, "observed": proposed.max_candidate_count},
    ))

    score_passed = (
        proposed.min_score_term >= root_meta.min_score_term_floor
        and proposed.max_score_term <= root_meta.max_score_term_ceiling
    )
    results.append(MetaRuleResult(
        "ROOT_SCORE_BOUNDS",
        score_passed,
        {
            "floor": root_meta.min_score_term_floor,
            "ceiling": root_meta.max_score_term_ceiling,
            "observed_min": proposed.min_score_term,
            "observed_max": proposed.max_score_term,
        },
    ))

    tie_passed = proposed.required_tie_break_rule == root_meta.required_tie_break_rule
    results.append(MetaRuleResult(
        "ROOT_TIE_BREAK_RULE",
        tie_passed,
        {"required": root_meta.required_tie_break_rule, "observed": proposed.required_tie_break_rule},
    ))

    rule_results = tuple(results)
    passed = all(item.passed for item in rule_results)
    payload = {
        "amendment_id": proposal.amendment_id,
        "root_id": root_meta.root_id,
        "root_meta_digest": root_meta.root_digest,
        "base_version_id": current_version.version_id,
        "base_constitution_digest": current_version.constitution_digest,
        "rule_results": rule_results,
        "passed": passed,
        "subjectivity_claimed": False,
        "free_will_claimed": False,
        "autonomy_claimed": False,
    }
    review_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
    canonical = canonical_json_bytes({**payload, "review_digest": review_digest})
    return MetaConstitutionalReviewEvidence(
        amendment_id=proposal.amendment_id,
        root_id=root_meta.root_id,
        root_meta_digest=root_meta.root_digest,
        base_version_id=current_version.version_id,
        base_constitution_digest=current_version.constitution_digest,
        rule_results=rule_results,
        passed=passed,
        review_digest=review_digest,
        subjectivity_claimed=False,
        free_will_claimed=False,
        autonomy_claimed=False,
        canonical_bytes=canonical,
    )

from .errors import ConstitutionAdoptionDenied, StaleConstitutionAmendment
from .policy_evolution import PolicyChangeProposal, review_policy_proposal


@dataclass(frozen=True)
class ConstitutionValidationCase:
    case_id: str
    policy_proposal: PolicyChangeProposal
    expected_review_passed: bool


@dataclass(frozen=True)
class ConstitutionValidationEvidence:
    amendment_id: str
    case_id: str
    expected_review_passed: bool
    observed_review_passed: bool | None
    policy_review_digest: str | None
    passed: bool
    error_type: str | None
    error_message: str | None
    validation_digest: str
    canonical_bytes: bytes


@dataclass(frozen=True)
class ConstitutionAdoptionEvidence:
    amendment_id: str
    meta_review_digest: str
    validation_digests: tuple[str, ...]
    root_meta_digest: str
    old_version_id: str
    old_constitution_digest: str
    new_version_id: str
    new_constitution_digest: str
    status: str
    timestamp: str
    adoption_digest: str
    subjectivity_claimed: bool
    free_will_claimed: bool
    autonomy_claimed: bool
    canonical_bytes: bytes


def validate_proposed_constitution(
    amendment: ConstitutionAmendmentProposal,
    cases: tuple[ConstitutionValidationCase, ...],
) -> tuple[ConstitutionValidationEvidence, ...]:
    evidence_items: list[ConstitutionValidationEvidence] = []
    for case in cases:
        if not case.case_id.strip():
            raise ValueError("validation case_id must be non-empty")
        observed: bool | None = None
        review_digest: str | None = None
        error_type: str | None = None
        error_message: str | None = None
        passed = False
        try:
            review = review_policy_proposal(case.policy_proposal, amendment.proposed_constitution)
            observed = review.passed
            review_digest = review.review_digest
            passed = observed is bool(case.expected_review_passed)
            if not passed:
                error_type = "EXPECTED_REVIEW_RESULT_MISMATCH"
                error_message = (
                    f"expected review passed={case.expected_review_passed}, observed={observed}"
                )
        except Exception as exc:  # validation evidence records runtime review failure
            error_type = type(exc).__name__
            error_message = str(exc)
        payload = {
            "amendment_id": amendment.amendment_id,
            "case_id": case.case_id,
            "policy_proposal_id": case.policy_proposal.proposal_id,
            "expected_review_passed": bool(case.expected_review_passed),
            "observed_review_passed": observed,
            "policy_review_digest": review_digest,
            "passed": passed,
            "error_type": error_type,
            "error_message": error_message,
        }
        validation_digest = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
        canonical = canonical_json_bytes({**payload, "validation_digest": validation_digest})
        evidence_items.append(ConstitutionValidationEvidence(
            amendment_id=amendment.amendment_id,
            case_id=case.case_id,
            expected_review_passed=bool(case.expected_review_passed),
            observed_review_passed=observed,
            policy_review_digest=review_digest,
            passed=passed,
            error_type=error_type,
            error_message=error_message,
            validation_digest=validation_digest,
            canonical_bytes=canonical,
        ))
    return tuple(evidence_items)


def _constitution_complies_with_root(
    constitution: PolicyConstitution,
    root_meta: RootMetaConstitution,
) -> bool:
    if root_meta.require_noop_enforcement and not constitution.require_noop_candidate:
        return False
    if not set(constitution.allowed_action_kinds).issubset(set(root_meta.allowed_action_kinds)):
        return False
    if constitution.max_candidate_count > root_meta.max_candidate_count_ceiling:
        return False
    if constitution.min_score_term < root_meta.min_score_term_floor:
        return False
    if constitution.max_score_term > root_meta.max_score_term_ceiling:
        return False
    if constitution.required_tie_break_rule != root_meta.required_tie_break_rule:
        return False
    return True


def _create_next_constitution_version(
    current: ConstitutionVersion,
    amendment: ConstitutionAmendmentProposal,
    created_at: str,
) -> ConstitutionVersion:
    constitution = amendment.proposed_constitution
    version_number = current.version_number + 1
    identity_payload = {
        "version_number": version_number,
        "constitution_digest": constitution.constitution_digest,
        "parent_version_id": current.version_id,
        "parent_constitution_digest": current.constitution_digest,
        "adopted_from_amendment_id": amendment.amendment_id,
        "created_at": created_at,
    }
    version_id = hashlib.sha256(canonical_json_bytes(identity_payload)).hexdigest()
    payload = {"version_id": version_id, **identity_payload, "constitution": constitution}
    canonical = canonical_json_bytes(payload)
    return ConstitutionVersion(
        version_id=version_id,
        version_number=version_number,
        constitution=constitution,
        constitution_digest=constitution.constitution_digest,
        parent_version_id=current.version_id,
        parent_constitution_digest=current.constitution_digest,
        adopted_from_amendment_id=amendment.amendment_id,
        created_at=created_at,
        canonical_bytes=canonical,
    )


class ConstitutionRegistry:
    def __init__(self, offspring_uid: str, root_meta: RootMetaConstitution) -> None:
        if not offspring_uid.strip():
            raise ValueError("offspring_uid must be non-empty")
        self.offspring_uid = offspring_uid
        self._root_meta = root_meta
        self._versions: list[ConstitutionVersion] = []
        self._versions_by_id: dict[str, ConstitutionVersion] = {}
        self._active_version_id: str | None = None
        self._amendments: dict[str, ConstitutionAmendmentProposal] = {}
        self._reviews: dict[str, MetaConstitutionalReviewEvidence] = {}
        self._adoptions: list[ConstitutionAdoptionEvidence] = []

    @property
    def root_meta(self) -> RootMetaConstitution:
        return self._root_meta

    @property
    def versions(self) -> tuple[ConstitutionVersion, ...]:
        return tuple(self._versions)

    @property
    def active_version(self) -> ConstitutionVersion:
        if self._active_version_id is None:
            raise ConstitutionAdoptionDenied("constitution registry is not initialized")
        return self._versions_by_id[self._active_version_id]

    @property
    def amendments(self) -> tuple[ConstitutionAmendmentProposal, ...]:
        return tuple(self._amendments.values())

    @property
    def reviews(self) -> tuple[MetaConstitutionalReviewEvidence, ...]:
        return tuple(self._reviews.values())

    @property
    def adoptions(self) -> tuple[ConstitutionAdoptionEvidence, ...]:
        return tuple(self._adoptions)

    def initialize(
        self,
        constitution: PolicyConstitution,
        created_at: str = "UNSPECIFIED",
    ) -> ConstitutionVersion:
        if self._versions:
            raise ConstitutionAdoptionDenied("constitution registry is already initialized")
        if constitution.constitution_version != 1:
            raise ConstitutionAdoptionDenied("initial constitution version must be 1")
        if not _constitution_complies_with_root(constitution, self._root_meta):
            raise ConstitutionAdoptionDenied("initial constitution violates root meta-constitution")
        version = create_initial_constitution_version(constitution, created_at=created_at)
        self._versions.append(version)
        self._versions_by_id[version.version_id] = version
        self._active_version_id = version.version_id
        return version

    def get_version(self, version_id: str) -> ConstitutionVersion:
        try:
            return self._versions_by_id[version_id]
        except KeyError as exc:
            raise KeyError(f"unknown constitution version: {version_id}") from exc

    def adopt(
        self,
        amendment: ConstitutionAmendmentProposal,
        review: MetaConstitutionalReviewEvidence,
        validations: tuple[ConstitutionValidationEvidence, ...],
        timestamp: str = "UNSPECIFIED",
    ) -> ConstitutionVersion:
        current = self.active_version
        if amendment.offspring_uid != self.offspring_uid:
            raise ConstitutionAdoptionDenied("amendment belongs to a different offspring UID")
        if amendment.root_meta_digest != self._root_meta.root_digest:
            raise ConstitutionAdoptionDenied("amendment root meta-constitution digest mismatch")
        if (
            amendment.base_version_id != current.version_id
            or amendment.base_constitution_digest != current.constitution_digest
        ):
            raise StaleConstitutionAmendment(
                f"amendment base {amendment.base_version_id}/{amendment.base_constitution_digest} is not active"
            )
        if amendment.proposed_constitution_digest != amendment.proposed_constitution.constitution_digest:
            raise ConstitutionAdoptionDenied("proposed constitution digest mismatch")
        if amendment.proposed_constitution.constitution_version != current.version_number + 1:
            raise ConstitutionAdoptionDenied("proposed constitution version is not the next version")
        if not _constitution_complies_with_root(amendment.proposed_constitution, self._root_meta):
            raise ConstitutionAdoptionDenied("proposed constitution violates root meta-constitution")
        if review.amendment_id != amendment.amendment_id:
            raise ConstitutionAdoptionDenied("meta review belongs to a different amendment")
        if review.root_meta_digest != self._root_meta.root_digest:
            raise ConstitutionAdoptionDenied("meta review root digest mismatch")
        if not review.passed:
            raise ConstitutionAdoptionDenied("meta-constitutional review did not pass")
        if self._root_meta.require_validation_cases and not validations:
            raise ConstitutionAdoptionDenied("at least one constitution validation case is required")
        if any(item.amendment_id != amendment.amendment_id for item in validations):
            raise ConstitutionAdoptionDenied("validation evidence belongs to a different amendment")
        if not all(item.passed for item in validations):
            raise ConstitutionAdoptionDenied("one or more constitution validation cases failed")

        self._amendments[amendment.amendment_id] = amendment
        self._reviews[review.review_digest] = review
        new_version = _create_next_constitution_version(current, amendment, timestamp)
        validation_digests = tuple(item.validation_digest for item in validations)
        adoption_payload = {
            "amendment_id": amendment.amendment_id,
            "meta_review_digest": review.review_digest,
            "validation_digests": validation_digests,
            "root_meta_digest": self._root_meta.root_digest,
            "old_version_id": current.version_id,
            "old_constitution_digest": current.constitution_digest,
            "new_version_id": new_version.version_id,
            "new_constitution_digest": new_version.constitution_digest,
            "status": "ADOPTED",
            "timestamp": timestamp,
            "subjectivity_claimed": False,
            "free_will_claimed": False,
            "autonomy_claimed": False,
        }
        adoption_digest = hashlib.sha256(canonical_json_bytes(adoption_payload)).hexdigest()
        adoption_canonical = canonical_json_bytes({**adoption_payload, "adoption_digest": adoption_digest})
        evidence = ConstitutionAdoptionEvidence(
            amendment_id=amendment.amendment_id,
            meta_review_digest=review.review_digest,
            validation_digests=validation_digests,
            root_meta_digest=self._root_meta.root_digest,
            old_version_id=current.version_id,
            old_constitution_digest=current.constitution_digest,
            new_version_id=new_version.version_id,
            new_constitution_digest=new_version.constitution_digest,
            status="ADOPTED",
            timestamp=timestamp,
            adoption_digest=adoption_digest,
            subjectivity_claimed=False,
            free_will_claimed=False,
            autonomy_claimed=False,
            canonical_bytes=adoption_canonical,
        )
        self._versions.append(new_version)
        self._versions_by_id[new_version.version_id] = new_version
        self._active_version_id = new_version.version_id
        self._adoptions.append(evidence)
        return new_version
