from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
import hashlib
from typing import Any, Mapping, Sequence

from .canonical import canonical_json_bytes
from .errors import InvalidLineageEvent
from .models import OffspringIdentitySpecification


class LineageEventType(str, Enum):
    UPDATE = "UPDATE"
    MIGRATION = "MIGRATION"
    RESTORE = "RESTORE"
    COPY = "COPY"
    FORK = "FORK"
    OFFSPRING = "OFFSPRING"
    MERGE = "MERGE"


@dataclass(frozen=True)
class LineageNode:
    entity_uid: str
    identity_root: str
    lineage_id: str
    entity_kind: str
    created_at: str


@dataclass(frozen=True)
class LineageEdge:
    event_id: str
    event_type: LineageEventType | str
    source_uids: tuple[str, ...]
    target_uids: tuple[str, ...]
    manifest_digest: str | None
    timestamp: str
    evidence: Mapping[str, Any]


class LineageGraph:
    def __init__(self) -> None:
        self._nodes: dict[str, LineageNode] = {}
        self._edges: dict[str, LineageEdge] = {}

    @property
    def nodes(self) -> tuple[LineageNode, ...]:
        return tuple(self._nodes[key] for key in sorted(self._nodes))

    @property
    def edges(self) -> tuple[LineageEdge, ...]:
        return tuple(self._edges[key] for key in sorted(self._edges))

    def add_node(self, node: LineageNode) -> None:
        existing = self._nodes.get(node.entity_uid)
        if existing is not None and existing != node:
            raise InvalidLineageEvent(f"node UID collision: {node.entity_uid}")
        self._nodes[node.entity_uid] = node

    def add_edge(self, edge: LineageEdge) -> None:
        if not isinstance(edge.event_type, LineageEventType):
            raise InvalidLineageEvent(f"noncanonical event type: {edge.event_type}")
        referenced = set(edge.source_uids) | set(edge.target_uids)
        missing = sorted(referenced - self._nodes.keys())
        if missing:
            raise InvalidLineageEvent(f"unknown lineage nodes: {missing}")
        existing = self._edges.get(edge.event_id)
        if existing is not None and existing != edge:
            raise InvalidLineageEvent(f"event ID collision: {edge.event_id}")
        self._edges[edge.event_id] = edge

    def record_offspring(
        self,
        sources: Sequence[str],
        offspring: OffspringIdentitySpecification,
        manifest_digest: str,
        evidence: Mapping[str, Any],
    ) -> tuple[LineageEdge, ...]:
        ordered_sources = tuple(sorted(set(sources)))
        for source_uid in ordered_sources:
            if source_uid not in self._nodes:
                self.add_node(LineageNode(
                    entity_uid=source_uid,
                    identity_root=f"external:{source_uid}",
                    lineage_id=f"external:{source_uid}",
                    entity_kind="SOURCE",
                    created_at="UNSPECIFIED",
                ))
        self.add_node(LineageNode(
            entity_uid=offspring.offspring_uid,
            identity_root=offspring.identity_root,
            lineage_id=offspring.lineage_id,
            entity_kind="OFFSPRING_COMPUTATIONAL_ENTITY",
            created_at=offspring.created_at,
        ))

        created: list[LineageEdge] = []
        for source_uid in ordered_sources:
            payload = {
                "event_type": LineageEventType.OFFSPRING.value,
                "source_uid": source_uid,
                "target_uid": offspring.offspring_uid,
                "manifest_digest": manifest_digest,
                "evidence": dict(evidence),
            }
            event_id = hashlib.sha256(canonical_json_bytes(payload)).hexdigest()
            edge = LineageEdge(
                event_id=event_id,
                event_type=LineageEventType.OFFSPRING,
                source_uids=(source_uid,),
                target_uids=(offspring.offspring_uid,),
                manifest_digest=manifest_digest,
                timestamp=offspring.created_at,
                evidence=dict(evidence),
            )
            self.add_edge(edge)
            created.append(edge)
        return tuple(created)

    def canonical_bytes(self) -> bytes:
        payload = {
            "nodes": self.nodes,
            "edges": self.edges,
        }
        return canonical_json_bytes(payload)
