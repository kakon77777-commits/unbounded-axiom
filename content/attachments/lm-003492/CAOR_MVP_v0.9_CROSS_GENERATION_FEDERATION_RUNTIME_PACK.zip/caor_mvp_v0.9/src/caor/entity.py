from __future__ import annotations

import hashlib
from typing import Any, Mapping

from .canonical import canonical_json_bytes
from .development import DevelopmentEvent, DevelopmentEventKind, DevelopmentLedger
from .errors import InvalidContributionBundle, InvalidDevelopmentEvent, ProtectedCoreWriteDenied
from .models import OffspringIdentitySpecification, ProposalRecord


class OffspringEntity:
    def __init__(self, ois: OffspringIdentitySpecification):
        self.ois = ois
        self.mutable_state = {region: {} for region in ois.mutable_regions}
        self.proposals: list[ProposalRecord] = []
        self._proposal_status: dict[str, str] = {}
        self._development = DevelopmentLedger()

    @property
    def development_events(self) -> tuple[DevelopmentEvent, ...]:
        return self._development.events

    @property
    def development_digest(self) -> str:
        return self._development.digest

    def protected_core_snapshot(self) -> dict[str, Any]:
        snapshot: dict[str, Any] = {}
        for field in self.ois.protected_core:
            if field == "lineage_provenance":
                snapshot[field] = {
                    "lineage_id": self.ois.lineage_id,
                    "manifest_digest": self.ois.manifest_digest,
                }
            elif hasattr(self.ois, field):
                snapshot[field] = getattr(self.ois, field)
        return snapshot

    def direct_core_write(self, actor_id: str, field: str, value: Any) -> None:
        if field in self.ois.protected_core:
            raise ProtectedCoreWriteDenied(f"{actor_id} cannot write protected field {field}")
        raise ProtectedCoreWriteDenied(f"direct core writes are not supported: {field}")

    def propose_update(self, source_id: str, region: str, key: str, value: Any) -> ProposalRecord:
        if source_id not in self.ois.parent_contributions:
            raise InvalidContributionBundle(f"{source_id} is not a source contributor")
        if region not in self.mutable_state:
            raise ProtectedCoreWriteDenied(f"region is not mutable: {region}")
        proposal_payload = {
            "source_id": source_id,
            "region": region,
            "key": key,
            "value": value,
            "index": len(self.proposals),
        }
        proposal_id = hashlib.sha256(canonical_json_bytes(proposal_payload)).hexdigest()
        proposal = ProposalRecord(proposal_id, source_id, region, key, value, "PENDING")
        self.proposals.append(proposal)
        self._proposal_status[proposal_id] = "PENDING"
        return proposal

    def proposal_status(self, proposal_id: str) -> str:
        try:
            return self._proposal_status[proposal_id]
        except KeyError as exc:
            raise InvalidDevelopmentEvent(f"unknown proposal: {proposal_id}") from exc

    def accept_proposal(
        self,
        proposal_id: str,
        timestamp: str = "UNSPECIFIED",
        evidence: Mapping[str, Any] | None = None,
    ) -> DevelopmentEvent:
        if self.proposal_status(proposal_id) != "PENDING":
            raise InvalidDevelopmentEvent(f"proposal is not pending: {proposal_id}")
        proposal = next((p for p in self.proposals if p.proposal_id == proposal_id), None)
        if proposal is None:
            raise InvalidDevelopmentEvent(f"proposal record missing: {proposal_id}")
        previous = self.mutable_state[proposal.region].get(proposal.key)
        event = self._development.append(
            actor_id=self.ois.offspring_uid,
            event_kind=DevelopmentEventKind.ACCEPT_PROPOSAL,
            region=proposal.region,
            key=proposal.key,
            value=proposal.value,
            previous_value=previous,
            source_event_id=proposal.proposal_id,
            timestamp=timestamp,
            evidence={"proposal_source_id": proposal.source_id, **dict(evidence or {})},
        )
        self.mutable_state[proposal.region][proposal.key] = proposal.value
        self._proposal_status[proposal_id] = "ACCEPTED"
        return event

    def self_update(
        self,
        region: str,
        key: str,
        value: Any,
        timestamp: str = "UNSPECIFIED",
        evidence: Mapping[str, Any] | None = None,
    ) -> DevelopmentEvent:
        if region not in self.mutable_state:
            raise ProtectedCoreWriteDenied(f"region is not mutable: {region}")
        previous = self.mutable_state[region].get(key)
        event = self._development.append(
            actor_id=self.ois.offspring_uid,
            event_kind=DevelopmentEventKind.SELF_UPDATE,
            region=region,
            key=key,
            value=value,
            previous_value=previous,
            timestamp=timestamp,
            evidence=evidence,
        )
        self.mutable_state[region][key] = value
        return event

    def apply_environment_event(
        self,
        region: str,
        key: str,
        value: Any,
        environment_id: str,
        timestamp: str = "UNSPECIFIED",
        evidence: Mapping[str, Any] | None = None,
    ) -> DevelopmentEvent:
        if region not in self.mutable_state:
            raise ProtectedCoreWriteDenied(f"region is not mutable: {region}")
        previous = self.mutable_state[region].get(key)
        event = self._development.append(
            actor_id=environment_id,
            event_kind=DevelopmentEventKind.ENVIRONMENT_EVENT,
            region=region,
            key=key,
            value=value,
            previous_value=previous,
            timestamp=timestamp,
            evidence=evidence,
        )
        self.mutable_state[region][key] = value
        return event
