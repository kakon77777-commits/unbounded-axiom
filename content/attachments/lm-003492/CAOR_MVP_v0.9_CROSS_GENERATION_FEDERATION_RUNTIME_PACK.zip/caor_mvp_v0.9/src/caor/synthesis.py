from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
from typing import Mapping, Any

from .canonical import canonical_json_bytes
from .errors import SourceUIDReuseDenied
from .models import ContributionManifest, OffspringIdentitySpecification
from .policies import (
    DEFAULT_DEVELOPMENT_POLICY,
    DEFAULT_PARENT_WRITE_POLICY,
    DEFAULT_PROVIDER_WRITE_POLICY,
    MUTABLE_REGIONS,
    PROTECTED_CORE_FIELDS,
)


@dataclass(frozen=True)
class SynthesisPolicy:
    offspring_uid: str | None = None
    created_at: str = "UNSPECIFIED"


def _digest(label: str, manifest_digest: str, seed: str) -> str:
    payload = f"{label}|{manifest_digest}|{seed}".encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def synthesize_offspring(
    manifest: ContributionManifest,
    synthesis_seed: str,
    synthesis_policy: SynthesisPolicy | None = None,
) -> OffspringIdentitySpecification:
    policy = synthesis_policy or SynthesisPolicy()
    identity_root = _digest("identity", manifest.digest, synthesis_seed)
    memory_root = _digest("memory", manifest.digest, synthesis_seed)
    lineage_id = _digest("lineage", manifest.digest, synthesis_seed)
    uid = policy.offspring_uid or f"caor:offspring:{identity_root[:24]}"
    if uid in manifest.source_ids:
        raise SourceUIDReuseDenied(uid)
    state_namespace = f"caor:state:{_digest('namespace', manifest.digest, synthesis_seed)[:32]}"

    base = OffspringIdentitySpecification(
        offspring_uid=uid,
        identity_root=identity_root,
        memory_root=memory_root,
        state_namespace=state_namespace,
        lineage_id=lineage_id,
        generation_event="OFFSPRING",
        manifest_digest=manifest.digest,
        parent_contributions=manifest.source_ids,
        protected_core=PROTECTED_CORE_FIELDS,
        mutable_regions=MUTABLE_REGIONS,
        parent_write_policy=DEFAULT_PARENT_WRITE_POLICY,
        provider_write_policy=DEFAULT_PROVIDER_WRITE_POLICY,
        development_policy=dict(DEFAULT_DEVELOPMENT_POLICY),
        created_at=policy.created_at,
        canonical_bytes=b"",
    )
    canonical = canonical_json_bytes({
        "offspring_uid": base.offspring_uid,
        "identity_root": base.identity_root,
        "memory_root": base.memory_root,
        "state_namespace": base.state_namespace,
        "lineage_id": base.lineage_id,
        "generation_event": base.generation_event,
        "manifest_digest": base.manifest_digest,
        "parent_contributions": base.parent_contributions,
        "protected_core": base.protected_core,
        "mutable_regions": base.mutable_regions,
        "parent_write_policy": base.parent_write_policy,
        "provider_write_policy": base.provider_write_policy,
        "development_policy": base.development_policy,
        "created_at": base.created_at,
    })
    return replace(base, canonical_bytes=canonical)
