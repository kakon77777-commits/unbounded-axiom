# CAOR MVP v0.8 Release Notes

## Genesis Generation Fork & Cross-Generation Migration Runtime

CAOR v0.8 turns the v0.7 architectural rule "Genesis changes create a new runtime generation" into executable reference semantics.

### Added

- immutable `GenerationOntologyProfile` records;
- explicit Prior Standing compatibility and declared-alternative ontology profiles;
- immutable `RuntimeGeneration` identity;
- `COMPATIBLE_SUCCESSOR`, `GENESIS_FORK`, and `ONTOLOGY_DIVERGENCE` review semantics;
- generation migration policy with automatic migration disabled by default;
- deterministic generation-boundary review evidence;
- generation-specific technical ratification attestations and aggregates;
- cross-generation `PolicyConstitution` compatibility evidence;
- entity transition classification: `STAY`, `MIGRATE`, `FORK_TO_NEW_GENERATION`, `COPY_TO_NEW_GENERATION`, `UNRESOLVED`;
- append-only `GenerationGraph` and `RuntimeGenerationRegistry`;
- branch coexistence from a common source generation;
- executable `genesis_generation_fork.py` reference demo;
- defensive-disclosure Clauses 99–116.

### Preserved boundaries

```text
Genesis change != in-place Genesis mutation
Generation adoption != automatic entity migration
Migration != fork != copy
Technical ratification != political legitimacy
Ontology declaration != subjectivity / rights proof
Succession != universal supersession
```

Runtime dependencies remain standard-library only.
