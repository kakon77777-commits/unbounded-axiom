"""Minimal standard-library PEP 517 backend for CAOR MVP v0.8.

This intentionally avoids setuptools so the defensive reference package can be
installed in an offline clean venv with no build-time dependency downloads.
"""

from __future__ import annotations

import base64
import hashlib
from pathlib import Path
import zipfile

NAME = "caor-mvp"
DIST_NAME = "caor_mvp"
VERSION = "0.9.0"
DIST_INFO = f"{DIST_NAME}-{VERSION}.dist-info"
WHEEL_NAME = f"{DIST_NAME}-{VERSION}-py3-none-any.whl"


def get_requires_for_build_wheel(config_settings=None):
    return []


def _metadata_text() -> str:
    return (
        "Metadata-Version: 2.1\n"
        f"Name: {NAME}\n"
        f"Version: {VERSION}\n"
        "Summary: Deterministic reference runtime for cross-substrate artificial offspring initialization, development, divergence, counterfactual branching, deterministic policy selection, constitutional policy evolution, root succession, runtime-generation forking, and lineage evidence\n"
        "Requires-Python: >=3.11\n"
        "\n"
    )


def _wheel_text() -> str:
    return (
        "Wheel-Version: 1.0\n"
        "Generator: caor-build-backend 0.8\n"
        "Root-Is-Purelib: true\n"
        "Tag: py3-none-any\n"
        "\n"
    )


def prepare_metadata_for_build_wheel(metadata_directory, config_settings=None):
    target = Path(metadata_directory) / DIST_INFO
    target.mkdir(parents=True, exist_ok=True)
    (target / "METADATA").write_text(_metadata_text(), encoding="utf-8")
    (target / "WHEEL").write_text(_wheel_text(), encoding="utf-8")
    return DIST_INFO


def _record_hash(data: bytes) -> str:
    digest = hashlib.sha256(data).digest()
    encoded = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return f"sha256={encoded}"


def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    project_root = Path(__file__).resolve().parent
    wheel_dir = Path(wheel_directory)
    wheel_dir.mkdir(parents=True, exist_ok=True)
    wheel_path = wheel_dir / WHEEL_NAME

    files: dict[str, bytes] = {}
    for source in sorted((project_root / "src" / "caor").glob("*.py")):
        files[f"caor/{source.name}"] = source.read_bytes()
    files[f"{DIST_INFO}/METADATA"] = _metadata_text().encode("utf-8")
    files[f"{DIST_INFO}/WHEEL"] = _wheel_text().encode("utf-8")

    record_lines = []
    for archive_name in sorted(files):
        data = files[archive_name]
        record_lines.append(f"{archive_name},{_record_hash(data)},{len(data)}")
    record_name = f"{DIST_INFO}/RECORD"
    record_lines.append(f"{record_name},,")
    files[record_name] = ("\n".join(record_lines) + "\n").encode("utf-8")

    with zipfile.ZipFile(wheel_path, "w", compression=zipfile.ZIP_DEFLATED) as wheel:
        for archive_name in sorted(files):
            wheel.writestr(archive_name, files[archive_name])

    return WHEEL_NAME
