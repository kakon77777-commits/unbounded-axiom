# IPM v0.2 XA-03 Reference Logger Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build and validate the model-provider-agnostic XA-03 telemetry and run-logging reference implementation defined by EML-IPM-XA-03 v0.1.

**Architecture:** One isolated Python package implements `RunSession`, append-only `EventLogger`, pluggable telemetry collectors, deterministic `MetricIntegrator`, schema validation, atomic `RunSink`, and abort recovery. Raw events/telemetry remain canonical; summaries are deterministic derivations. Unsupported physical quantities remain `null`.

**Tech Stack:** Python 3.11+ standard library; optional `psutil`; external `nvidia-smi`; `pytest` for tests.

**Spec:** `/mnt/data/IPM_v0.2_XA03_Telemetry_RunLogger_Design_Spec_v0.1.md`

## Global Constraints

- Core implementation uses Python 3.11+ standard library only.
- `psutil` is optional; absence must degrade cleanly.
- NVIDIA support uses external `nvidia-smi`; no NVIDIA Python package is required.
- Default telemetry interval is exactly `0.25` seconds; valid range is `0.05 <= interval <= 5.0`.
- Unknown/unavailable measurements are `null`, never numeric zero.
- Device-measured energy must never be labeled marginal or attributed energy.
- Duration/integration uses a monotonic clock, never wall timestamp differences.
- Raw `events.jsonl` and `telemetry.jsonl` are canonical sources; `summary.json` is derived.
- Run finalization is atomic using `.<run_id>.partial` followed by rename.
- A recovered incomplete run is `ABORTED`; recovery never synthesizes missing normal end events.
- XA-03 must not capture private chain-of-thought or model-provider secrets.

---

## File Structure

```text
IPM_v0.2_XA03_Reference_Logger_v0.1/
  README.md
  SPEC.md
  pyproject.toml

  ipm_xa03/
    __init__.py
    clock.py
    models.py
    events.py
    integrator.py
    schema.py
    sink.py
    session.py
    recovery.py

    collectors/
      __init__.py
      base.py
      null.py
      system.py
      nvidia_smi.py

  schemas/
    run_summary.schema.json
    event.schema.json
    telemetry.schema.json

  examples/
    basic_session.py
    instrumented_fake_run.py

  tests/
    test_clock_models.py
    test_events.py
    test_integrator_golden.py
    test_collectors.py
    test_schema_sink.py
    test_session_recovery.py

  fixtures/
    golden_events.jsonl
    golden_telemetry.jsonl

  validation_report.json
  manifest.json
```

---

### Task 1: Core Models, Clock, and Event Logger

**Files:**
- Create: `ipm_xa03/clock.py`
- Create: `ipm_xa03/models.py`
- Create: `ipm_xa03/events.py`
- Create: `tests/test_clock_models.py`
- Create: `tests/test_events.py`

**Interfaces:**
- Produces: `Clock`, `SystemClock`, `FakeClock`, `RunConfig`, `TelemetrySample`, `EventLogger`.
- `EventLogger.emit(event_type, *, span_id=None, attributes=None) -> dict`
- `EventLogger.start_span(event_type, *, span_id=None, attributes=None) -> str`
- `EventLogger.end_span(event_type, span_id, *, attributes=None) -> dict`

- [ ] **Step 1: Write failing clock/config tests**

```python
def test_fake_clock_advances_monotonically():
    clock = FakeClock(start_wall="2026-09-03T00:00:00+00:00")
    assert clock.monotonic() == 0.0
    clock.advance(1.25)
    assert clock.monotonic() == 1.25

def test_run_config_rejects_sampling_interval_below_50ms(tmp_path):
    with pytest.raises(ValueError):
        RunConfig(run_id="r", output_dir=tmp_path, telemetry_interval_s=0.01)
```

- [ ] **Step 2: Run tests and verify RED**

Run:

```bash
pytest tests/test_clock_models.py -q
```

Expected: import/module failure because core modules do not yet exist.

- [ ] **Step 3: Implement minimal clock/models**

Implement immutable or validation-focused dataclasses sufficient for the tests. `FakeClock.advance()` must reject negative movement.

- [ ] **Step 4: Verify GREEN**

Run:

```bash
pytest tests/test_clock_models.py -q
```

Expected: all tests pass.

- [ ] **Step 5: Write failing EventLogger tests**

Tests must prove:
- emitted event has `run_id`, wall `timestamp`, monotonic `t_monotonic_s`;
- event sequence is append-only;
- start/end events share `span_id`;
- an unmatched start remains unmatched rather than auto-completed.

- [ ] **Step 6: Run EventLogger tests and verify RED**

```bash
pytest tests/test_events.py -q
```

- [ ] **Step 7: Implement minimal EventLogger**

Write one JSON object per line, flush after every event, maintain an in-memory monotonically increasing event sequence only for IDs.

- [ ] **Step 8: Verify GREEN**

```bash
pytest tests/test_events.py -q
```

---

### Task 2: Collector Interface and Deterministic Collectors

**Files:**
- Create: `ipm_xa03/collectors/base.py`
- Create: `ipm_xa03/collectors/null.py`
- Create: `ipm_xa03/collectors/system.py`
- Create: `ipm_xa03/collectors/nvidia_smi.py`
- Create: `tests/test_collectors.py`

**Interfaces:**
- Produces: `CollectorCapabilities`, `TelemetryCollector`, `NullCollector`, `SystemCollector`, `NvidiaSmiCollector`.
- `sample() -> list[TelemetrySample]` so one collector can emit one sample per device.

- [ ] **Step 1: Write failing NullCollector tests**

```python
def test_null_collector_reports_no_physical_capabilities(fake_clock):
    c = NullCollector(fake_clock)
    assert c.capabilities().gpu_power is False
    samples = c.sample("run-1")
    assert len(samples) == 1
    assert samples[0].metrics == {}
```

- [ ] **Step 2: Verify RED**

```bash
pytest tests/test_collectors.py::test_null_collector_reports_no_physical_capabilities -q
```

- [ ] **Step 3: Implement base protocol + NullCollector**
- [ ] **Step 4: Verify GREEN**
- [ ] **Step 5: Add failing SystemCollector degradation test**

The test must simulate no `psutil` and assert no exception plus capability flags `False`.

- [ ] **Step 6: Implement SystemCollector with optional import**
- [ ] **Step 7: Add failing NVIDIA parser tests**

Feed a literal CSV line such as:

```text
GPU-abc, 0, RTX 3070, 84, 6144, 8192, 187.4, 71, 1815, 220
```

and assert typed/namespaced values.

- [ ] **Step 8: Implement NvidiaSmiCollector parser and command execution**
- [ ] **Step 9: Run full collector test file**

```bash
pytest tests/test_collectors.py -q
```

---

### Task 3: Deterministic Metric Integrator

**Files:**
- Create: `ipm_xa03/integrator.py`
- Create: `fixtures/golden_events.jsonl`
- Create: `fixtures/golden_telemetry.jsonl`
- Create: `tests/test_integrator_golden.py`

**Interfaces:**
- Produces: `integrate_run(config, events_path, telemetry_path) -> dict`
- Pure/deterministic: no wall clock access, no hardware access.

- [ ] **Step 1: Write golden telemetry fixture**

Canonical points:

```text
t=0 power=100W memory=10GB util=0.5
t=1 power=100W memory=12GB util=1.0
t=2 power=200W memory=12GB util=0.5
t=3 power=200W memory=8GB  util=0.0
```

Use decimal GB = `1_000_000_000` bytes in the fixture.

- [ ] **Step 2: Write failing golden integration test**

Assert:
- `device_energy_j == 450.0`
- `gpu_utilization_integral_s == 1.75`
- `gpu_peak_memory_bytes == 12_000_000_000`
- memory residency uses trapezoidal integration
- `device_energy_type == "device_measured"`

- [ ] **Step 3: Verify RED**

```bash
pytest tests/test_integrator_golden.py::test_golden_physical_integrals -q
```

- [ ] **Step 4: Implement trapezoidal integration grouped per collector/device**
- [ ] **Step 5: Verify GREEN**
- [ ] **Step 6: Write failing event-accounting test**

Fixture expectation:
- 3 invocations started/completed;
- 2 trajectories;
- 1 retry;
- 2 tools;
- 1 verifier;
- 4 candidates created;
- 1 selected;
- 3 discarded.

- [ ] **Step 7: Implement event accounting + incomplete spans**
- [ ] **Step 8: Add telemetry-gap test**

Given target interval `0.25`, a gap `>0.625s` increments `sample_gap_count`.

- [ ] **Step 9: Run integrator tests**

```bash
pytest tests/test_integrator_golden.py -q
```

---

### Task 4: Schema Validation and Atomic RunSink

**Files:**
- Create: `ipm_xa03/schema.py`
- Create: `ipm_xa03/sink.py`
- Create: `schemas/run_summary.schema.json`
- Create: `schemas/event.schema.json`
- Create: `schemas/telemetry.schema.json`
- Create: `tests/test_schema_sink.py`

**Interfaces:**
- Produces: `validate_summary(summary) -> list[str]`
- Produces: `RunSink.create_partial(run_id)`, `finalize_complete(summary)`, `finalize_aborted(summary)`

- [ ] **Step 1: Write failing schema tests**

Assert:
- negative wall time rejected;
- `device_energy_type="marginal"` rejected when only `device_energy_j` exists;
- `None` unknown physical values accepted;
- illegal run state rejected.

- [ ] **Step 2: Verify RED**
- [ ] **Step 3: Implement minimal standard-library validator**

The JSON Schema files document the contract; runtime validation may be explicit Python code to avoid mandatory `jsonschema`.

- [ ] **Step 4: Verify GREEN**
- [ ] **Step 5: Write failing atomic sink tests**

Assert:
- new run begins at `.<run_id>.partial`;
- successful finalize renames to `<run_id>`;
- exactly one `COMPLETE` marker;
- abort produces exactly one `ABORTED`;
- both markers can never coexist.

- [ ] **Step 6: Implement RunSink**
- [ ] **Step 7: Run schema/sink tests**

```bash
pytest tests/test_schema_sink.py -q
```

---

### Task 5: RunSession, Sampling Loop, and Abort Recovery

**Files:**
- Create: `ipm_xa03/session.py`
- Create: `ipm_xa03/recovery.py`
- Modify: `ipm_xa03/__init__.py`
- Create: `tests/test_session_recovery.py`

**Interfaces:**
- Produces public `RunSession`, `RunConfig`, `recover_partial_run(path)`.
- Context helpers: `model_invocation()`, `trajectory()`, `retry()`, `tool_call()`, `verifier()`.
- Candidate helpers: `candidate_created()`, `candidate_selected(id)`, `candidate_discarded(id)`.

- [ ] **Step 1: Write failing basic session test**

Use `FakeClock` + `NullCollector`; assert COMPLETE run files exist and physical unknowns are null.

- [ ] **Step 2: Verify RED**
- [ ] **Step 3: Implement minimal RunSession lifecycle and background sampler**
- [ ] **Step 4: Verify GREEN**
- [ ] **Step 5: Write failing abort test**

Raise an exception inside `with RunSession(...)`; assert:
- `ABORTED`;
- exception propagates;
- raw logs preserved.

- [ ] **Step 6: Implement abort finalization**
- [ ] **Step 7: Write failing stale-partial recovery test**

An unmatched invocation must remain incomplete; recovered summary reports `incomplete_span_count == 1`.

- [ ] **Step 8: Implement recovery without synthetic normal end events**
- [ ] **Step 9: Run session/recovery tests**

```bash
pytest tests/test_session_recovery.py -q
```

---

### Task 6: Examples, Packaging, and Full Verification

**Files:**
- Create: `README.md`
- Copy approved design to: `SPEC.md`
- Create: `examples/basic_session.py`
- Create: `examples/instrumented_fake_run.py`
- Create: `pyproject.toml`
- Create after testing: `validation_report.json`
- Create after testing: `manifest.json`

**Interfaces:**
- Package import: `from ipm_xa03 import RunSession, RunConfig`
- No model-provider dependency.

- [ ] **Step 1: Add failing public-import smoke test**

Add to an existing test:

```python
def test_public_api_imports():
    from ipm_xa03 import RunSession, RunConfig
```

- [ ] **Step 2: Verify RED if exports are missing**
- [ ] **Step 3: Add public exports, README, examples, packaging metadata**
- [ ] **Step 4: Run full test suite**

```bash
pytest -q
```

Expected: zero failures.

- [ ] **Step 5: Run optional local integrations**

```bash
pytest tests/test_collectors.py -q
```

NVIDIA / psutil tests may skip if unavailable; skips must be explicit.

- [ ] **Step 6: Run deterministic re-integration twice**

Hash the two canonical summaries; hashes must match.

- [ ] **Step 7: Generate `validation_report.json`**

Include:
- test command;
- pass/fail/skip counts;
- golden energy result;
- golden utilization result;
- golden peak memory;
- deterministic summary hash comparison;
- optional collector availability.

- [ ] **Step 8: Generate SHA-256 manifest**

Hash every released file except the self-referential manifest field itself.

- [ ] **Step 9: Build release ZIP**
- [ ] **Step 10: Verify ZIP contents and SHA-256**
- [ ] **Step 11: Re-run the complete tests on the exact release tree**

No completion claim is allowed until this fresh final run is green.

---

## Final Acceptance Checklist

- [ ] Golden energy = exactly `450.0 J` within declared float tolerance.
- [ ] Golden utilization integral = exactly `1.75 utilization-seconds`.
- [ ] Golden peak memory = `12_000_000_000` bytes.
- [ ] Event accounting fixture matches all expected counts.
- [ ] NullCollector keeps unsupported metrics `null`.
- [ ] Abort recovery preserves incomplete spans.
- [ ] Schema rejects negative durations and illegal state/type combinations.
- [ ] No unavailable physical metric becomes numeric zero.
- [ ] NVIDIA absence produces clean skip/degradation.
- [ ] psutil absence produces clean skip/degradation.
- [ ] Raw-trace reintegration is deterministic.
- [ ] Validation report exists.
- [ ] Manifest exists.
- [ ] Release ZIP hash exists.
- [ ] Final `pytest -q` on release tree returns zero failures.
