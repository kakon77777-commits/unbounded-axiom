from __future__ import annotations

import json
from pathlib import Path
from threading import Lock
from typing import Any
from uuid import uuid4

from .clock import Clock


class EventLogger:
    def __init__(self, run_id: str, path: Path | str, clock: Clock) -> None:
        self.run_id = run_id
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.clock = clock
        self._seq = 0
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                try:
                    row = json.loads(line)
                    self._seq = max(self._seq, int(row.get("sequence", 0)))
                except Exception:
                    continue
        self._fh = self.path.open("a", encoding="utf-8", newline="\n")
        self._lock = Lock()
        self._closed = False

    def _next_id(self) -> tuple[int, str]:
        self._seq += 1
        return self._seq, f"ev-{self._seq:08d}-{uuid4().hex[:8]}"

    def emit(
        self,
        event_type: str,
        *,
        span_id: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if self._closed:
            raise RuntimeError("EventLogger is closed")
        with self._lock:
            seq, event_id = self._next_id()
            event: dict[str, Any] = {
                "event_id": event_id,
                "sequence": seq,
                "run_id": self.run_id,
                "event_type": event_type,
                "t_monotonic_s": float(self.clock.monotonic()),
                "timestamp": self.clock.timestamp(),
                "attributes": attributes or {},
            }
            if span_id is not None:
                event["span_id"] = span_id
            self._fh.write(json.dumps(event, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")
            self._fh.flush()
            return event

    def start_span(
        self,
        event_type: str,
        *,
        span_id: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> str:
        sid = span_id or f"span-{uuid4().hex}"
        self.emit(f"{event_type}_start", span_id=sid, attributes=attributes)
        return sid

    def end_span(
        self,
        event_type: str,
        span_id: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self.emit(f"{event_type}_end", span_id=span_id, attributes=attributes)

    def close(self) -> None:
        if not self._closed:
            self._fh.flush()
            self._fh.close()
            self._closed = True
