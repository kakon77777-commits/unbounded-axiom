from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from .schema import validate_summary


def _write_json(path: Path, data: dict[str, Any]) -> None:
    text = json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n"
    path.write_text(text, encoding="utf-8", newline="\n")


class RunSink:
    def __init__(self, output_dir: Path | str, run_id: str) -> None:
        self.output_dir = Path(output_dir)
        self.run_id = run_id
        self.partial_dir = self.output_dir / f".{run_id}.partial"
        self.final_dir = self.output_dir / run_id

    @property
    def events_path(self) -> Path:
        return self.partial_dir / "events.jsonl"

    @property
    def telemetry_path(self) -> Path:
        return self.partial_dir / "telemetry.jsonl"

    @property
    def config_path(self) -> Path:
        return self.partial_dir / "config.json"

    def create_partial(self, config: dict[str, Any]) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        if self.final_dir.exists():
            raise FileExistsError(f"final run directory already exists: {self.final_dir}")
        if self.partial_dir.exists():
            raise FileExistsError(f"partial run directory already exists: {self.partial_dir}")
        self.partial_dir.mkdir(parents=False)
        _write_json(self.config_path, config)
        self.events_path.touch()
        self.telemetry_path.touch()
        return self.partial_dir

    def _finalize(self, summary: dict[str, Any], marker: str) -> Path:
        if not self.partial_dir.exists():
            raise FileNotFoundError(f"partial run directory does not exist: {self.partial_dir}")
        if self.final_dir.exists():
            raise FileExistsError(f"final run directory already exists: {self.final_dir}")
        if summary.get("run", {}).get("run_id") != self.run_id:
            raise ValueError("summary run_id does not match sink run_id")
        expected_state = "COMPLETE" if marker == "COMPLETE" else "ABORTED"
        if summary.get("run", {}).get("state") != expected_state:
            raise ValueError(f"summary state must be {expected_state}")
        errors = validate_summary(summary)
        if errors:
            raise ValueError("invalid summary: " + "; ".join(errors))
        _write_json(self.partial_dir / "summary.json", summary)
        _write_json(self.partial_dir / "validation.json", {"valid": True, "errors": []})
        for fname in ("config.json", "events.jsonl", "telemetry.jsonl", "summary.json", "validation.json"):
            path = self.partial_dir / fname
            with path.open("rb") as fh:
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass
        os.replace(self.partial_dir, self.final_dir)
        (self.final_dir / marker).write_text("\n", encoding="utf-8")
        other = self.final_dir / ("ABORTED" if marker == "COMPLETE" else "COMPLETE")
        if other.exists():
            other.unlink()
        return self.final_dir

    def finalize_complete(self, summary: dict[str, Any]) -> Path:
        return self._finalize(summary, "COMPLETE")

    def finalize_aborted(self, summary: dict[str, Any]) -> Path:
        return self._finalize(summary, "ABORTED")
