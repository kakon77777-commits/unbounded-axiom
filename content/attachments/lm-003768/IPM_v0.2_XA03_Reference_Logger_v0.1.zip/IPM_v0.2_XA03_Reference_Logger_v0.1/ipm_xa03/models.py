from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class RunConfig:
    run_id: str
    output_dir: Path | str
    telemetry_interval_s: float = 0.25
    collectors: tuple[str, ...] = field(default_factory=tuple)
    required_collectors: tuple[str, ...] = field(default_factory=tuple)
    physical_boundary: str = "unknown"
    allocated_gpu_indices: tuple[int, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.run_id:
            raise ValueError("run_id must be non-empty")
        if not (0.05 <= self.telemetry_interval_s <= 5.0):
            raise ValueError("telemetry_interval_s must be between 0.05 and 5.0 seconds")
        if not set(self.required_collectors).issubset(set(self.collectors)):
            raise ValueError("required_collectors must be a subset of collectors")
        object.__setattr__(self, "output_dir", Path(self.output_dir))


@dataclass(frozen=True)
class TelemetrySample:
    run_id: str
    collector: str
    t_monotonic_s: float
    timestamp: str
    metrics: dict[str, Any]
    availability: dict[str, bool]
    device_id: str | None = None
