from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

from .events import EventLogger
from .integrator import integrate_run
from .models import RunConfig
from .sink import RunSink


class _RecoveryClock:
    def __init__(self, t_monotonic_s: float) -> None:
        self._t = float(t_monotonic_s)

    def monotonic(self) -> float:
        return self._t

    def timestamp(self) -> str:
        return datetime.now(timezone.utc).isoformat()


def _read_events(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def recover_partial_run(partial_dir: Path | str) -> Path:
    partial = Path(partial_dir)
    if not partial.exists() or not partial.is_dir() or not partial.name.startswith(".") or not partial.name.endswith(".partial"):
        raise ValueError("path is not an XA-03 partial run directory")
    config_data = json.loads((partial / "config.json").read_text(encoding="utf-8"))
    run_id = str(config_data["run_id"])
    events_path = partial / "events.jsonl"
    telemetry_path = partial / "telemetry.jsonl"
    events = _read_events(events_path)
    last_t = max((float(e.get("t_monotonic_s", 0.0)) for e in events), default=0.0)
    logger = EventLogger(run_id, events_path, _RecoveryClock(last_t))
    logger.emit("recovery", attributes={
        "synthetic_metadata": True,
        "reason": "stale_partial_recovered",
        "does_not_close_existing_spans": True,
    })
    logger.close()
    cfg = RunConfig(
        run_id=run_id,
        output_dir=partial.parent,
        telemetry_interval_s=float(config_data.get("telemetry_interval_s", 0.25)),
        collectors=tuple(config_data.get("collectors", ())),
        required_collectors=tuple(config_data.get("required_collectors", ())),
        physical_boundary=str(config_data.get("physical_boundary", "unknown")),
        allocated_gpu_indices=tuple(config_data.get("allocated_gpu_indices", ())),
    )
    summary = integrate_run(cfg, events_path, telemetry_path)
    summary["run"]["state"] = "ABORTED"
    summary["provenance"] = {
        "xa03_version": "0.1",
        "recovered": True,
        "recovery_mode": "preserve_raw_no_synthetic_span_completion",
    }
    sink = RunSink(partial.parent, run_id)
    return sink.finalize_aborted(summary)
