from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

from .models import RunConfig


def _read_jsonl(path: Path | str) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def _trapezoid(points: Iterable[tuple[float, float]]) -> float | None:
    pts = sorted((float(t), float(v)) for t, v in points)
    if len(pts) < 2:
        return None
    total = 0.0
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t1 < t0:
            raise ValueError("telemetry timestamps must be monotonic after sorting")
        total += (t1 - t0) * (v0 + v1) / 2.0
    return total


def _numeric_points(rows: list[dict[str, Any]], key: str) -> list[tuple[float, float]]:
    out: list[tuple[float, float]] = []
    for row in rows:
        value = row.get("metrics", {}).get(key)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            out.append((float(row["t_monotonic_s"]), float(value)))
    return out


def _event_account(events: list[dict[str, Any]]) -> dict[str, Any]:
    prefix_names = {
        "model_invocation": "model_invocations",
        "trajectory": "trajectories",
        "retry": "retries",
        "tool_call": "tool_calls",
        "verifier": "verifier_passes",
    }
    out: dict[str, Any] = {}
    for prefix, plural in prefix_names.items():
        out[f"{plural}_started"] = sum(e.get("event_type") == f"{prefix}_start" for e in events)
        out[f"{plural}_completed"] = sum(e.get("event_type") == f"{prefix}_end" for e in events)

    out["candidates_created"] = sum(e.get("event_type") == "candidate_created" for e in events)
    out["candidates_selected"] = sum(e.get("event_type") == "candidate_selected" for e in events)
    out["candidates_discarded"] = sum(e.get("event_type") == "candidate_discarded" for e in events)
    out["failure_count"] = sum(e.get("event_type") == "failure" for e in events)

    starts: dict[tuple[str, str], int] = defaultdict(int)
    ends: dict[tuple[str, str], int] = defaultdict(int)
    active: dict[tuple[str, str], int] = defaultdict(int)
    end_before_start_count = 0
    for e in events:
        et = e.get("event_type", "")
        sid = e.get("span_id")
        if not sid:
            continue
        if et.endswith("_start"):
            key = (et[:-6], str(sid))
            starts[key] += 1
            active[key] += 1
        elif et.endswith("_end"):
            key = (et[:-4], str(sid))
            ends[key] += 1
            if active[key] <= 0:
                end_before_start_count += 1
            else:
                active[key] -= 1
    keys = set(starts) | set(ends)
    incomplete = 0
    duplicate_end = 0
    for key in keys:
        s = starts.get(key, 0)
        e = ends.get(key, 0)
        if s != e:
            incomplete += abs(s - e)
        if e > s:
            duplicate_end += e - s
    out["incomplete_span_count"] = incomplete
    out["duplicate_or_orphan_end_count"] = duplicate_end
    out["end_before_start_count"] = end_before_start_count

    instrumentation = [e for e in events if e.get("event_type") == "telemetry_instrumentation"]
    if instrumentation:
        attrs = instrumentation[-1].get("attributes", {})
        out["telemetry_sample_batches"] = int(attrs.get("sample_batches", 0))
        out["telemetry_sampling_wall_time_s"] = float(attrs.get("sampling_wall_time_s", 0.0))
    else:
        out["telemetry_sample_batches"] = 0
        out["telemetry_sampling_wall_time_s"] = 0.0

    starts_t = [float(e.get("t_monotonic_s", 0.0)) for e in events if e.get("event_type") == "run_start"]
    ends_t = [float(e.get("t_monotonic_s", 0.0)) for e in events if e.get("event_type") in {"run_end", "run_abort"}]
    if starts_t and ends_t:
        out["wall_time_s"] = max(0.0, max(ends_t) - min(starts_t))
    elif starts_t and events:
        out["wall_time_s"] = max(0.0, max(float(e.get("t_monotonic_s", 0.0)) for e in events) - min(starts_t))
    else:
        out["wall_time_s"] = 0.0
    return out


def integrate_run(config: RunConfig, events_path: Path | str, telemetry_path: Path | str) -> dict[str, Any]:
    events = _read_jsonl(events_path)
    telemetry = _read_jsonl(telemetry_path)
    execution = _event_account(events)

    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in telemetry:
        collector = str(row.get("collector", "unknown"))
        device = str(row.get("device_id") or row.get("metrics", {}).get("gpu.uuid") or "global")
        groups[(collector, device)].append(row)

    total_energy: float | None = None
    total_util_integral: float | None = None
    total_memory_residency: float | None = None
    per_device: list[dict[str, Any]] = []
    peak_memory_candidates: list[int] = []
    peak_power_candidates: list[float] = []
    peak_temp_candidates: list[float] = []
    power_observed_duration = 0.0

    for (collector, device), rows in sorted(groups.items()):
        rows = sorted(rows, key=lambda r: float(r.get("t_monotonic_s", 0.0)))
        ppoints = _numeric_points(rows, "gpu.power_w")
        upoints = _numeric_points(rows, "gpu.utilization_fraction")
        mpoints = _numeric_points(rows, "gpu.memory_used_bytes")
        tpoints = _numeric_points(rows, "gpu.temperature_c")
        energy = _trapezoid(ppoints)
        util_int = _trapezoid(upoints)
        mem_int = _trapezoid(mpoints)
        peak_mem = int(max((v for _, v in mpoints), default=0)) if mpoints else None
        peak_power = max((v for _, v in ppoints), default=None)
        peak_temp = max((v for _, v in tpoints), default=None)
        if energy is not None:
            total_energy = (total_energy or 0.0) + energy
            power_observed_duration += ppoints[-1][0] - ppoints[0][0]
        if util_int is not None:
            total_util_integral = (total_util_integral or 0.0) + util_int
        if mem_int is not None:
            total_memory_residency = (total_memory_residency or 0.0) + mem_int
        if peak_mem is not None:
            peak_memory_candidates.append(peak_mem)
        if peak_power is not None:
            peak_power_candidates.append(float(peak_power))
        if peak_temp is not None:
            peak_temp_candidates.append(float(peak_temp))
        per_device.append({
            "collector": collector,
            "device_id": device,
            "device_energy_j": energy,
            "gpu_utilization_integral_s": util_int,
            "gpu_peak_memory_bytes": peak_mem,
            "gpu_memory_residency_byte_s": mem_int,
            "gpu_peak_power_w": peak_power,
            "gpu_peak_temperature_c": peak_temp,
            "sample_count": len(rows),
        })

    # For the aggregate peak-memory field, v0.1 reports the maximum observed per-device peak.
    # Raw per-device values remain available to avoid implying synchronized multi-device summation.
    peak_memory = max(peak_memory_candidates) if peak_memory_candidates else None
    peak_power = max(peak_power_candidates) if peak_power_candidates else None
    peak_temp = max(peak_temp_candidates) if peak_temp_candidates else None
    mean_power = None
    if total_energy is not None and power_observed_duration > 0:
        mean_power = total_energy / power_observed_duration

    target = float(config.telemetry_interval_s)
    threshold = 2.5 * target
    gaps: list[float] = []
    for rows in groups.values():
        ts = sorted(float(r.get("t_monotonic_s", 0.0)) for r in rows)
        gaps.extend(b - a for a, b in zip(ts, ts[1:]) if b - a > threshold)
    largest_gap = max(gaps) if gaps else 0.0
    wall = float(execution.get("wall_time_s", 0.0))
    gap_excess = sum(max(0.0, gap - target) for gap in gaps)
    coverage = 1.0 if wall <= 0 else max(0.0, min(1.0, 1.0 - gap_excess / wall))

    system_rss_values = []
    cpu_time_values = []
    for row in telemetry:
        metrics = row.get("metrics", {})
        rss = metrics.get("system.process_rss_bytes")
        cpu = metrics.get("system.process_cpu_time_s")
        if isinstance(rss, (int, float)) and not isinstance(rss, bool):
            system_rss_values.append(int(rss))
        if isinstance(cpu, (int, float)) and not isinstance(cpu, bool):
            cpu_time_values.append(float(cpu))

    physical = {
        "device_energy_j": total_energy,
        "device_energy_type": "device_measured" if total_energy is not None else "unknown",
        "marginal_energy_j": None,
        "attributed_energy_j": None,
        "gpu_peak_memory_bytes": peak_memory,
        "gpu_memory_residency_byte_s": total_memory_residency,
        "gpu_utilization_integral_s": total_util_integral,
        "allocated_device_time_s": (wall * len(config.allocated_gpu_indices)) if config.allocated_gpu_indices else None,
        "gpu_peak_power_w": peak_power,
        "gpu_mean_power_w": mean_power,
        "gpu_peak_temperature_c": peak_temp,
        "system_peak_rss_bytes": max(system_rss_values) if system_rss_values else None,
        "system_cpu_time_s": (max(cpu_time_values) - min(cpu_time_values)) if len(cpu_time_values) >= 2 else None,
        "sample_count": len(telemetry),
        "sample_interval_target_s": target,
        "per_device": per_device,
    }

    state = "COMPLETE" if any(e.get("event_type") == "run_end" for e in events) else (
        "ABORTED" if any(e.get("event_type") == "run_abort" for e in events) else "INCOMPLETE"
    )

    return {
        "run": {"run_id": config.run_id, "state": state},
        "execution": execution,
        "physical": physical,
        "hidden_work": {
            "discarded_candidates": execution["candidates_discarded"],
            "discarded_cost": None,
        },
        "measurement": {
            "physical_boundary": config.physical_boundary,
            "energy_grade": "E-C" if total_energy is not None else "E-E",
            "cst_grade": "CST-C" if any(bool(row.get("metrics")) for row in telemetry) else "CST-D",
            "telemetry_complete": len(gaps) == 0,
            "sample_gap_count": len(gaps),
            "largest_gap_s": largest_gap,
            "coverage_fraction": coverage,
            "memory_peak_aggregation": "max_per_device_peak",
            "integration_method": "trapezoidal",
        },
        "provenance": {},
    }
