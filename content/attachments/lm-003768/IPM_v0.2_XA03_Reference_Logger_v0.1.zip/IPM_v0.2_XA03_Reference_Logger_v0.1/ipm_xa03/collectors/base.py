from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from ..models import TelemetrySample


@dataclass(frozen=True)
class CollectorCapabilities:
    wall_time: bool = True
    gpu_power: bool = False
    gpu_memory: bool = False
    gpu_utilization: bool = False
    cpu: bool = False
    process_memory: bool = False


class TelemetryCollector(Protocol):
    name: str
    required: bool

    def start(self, run_context=None) -> None: ...
    def sample(self, run_id: str) -> list[TelemetrySample]: ...
    def stop(self) -> None: ...
    def capabilities(self) -> CollectorCapabilities: ...
