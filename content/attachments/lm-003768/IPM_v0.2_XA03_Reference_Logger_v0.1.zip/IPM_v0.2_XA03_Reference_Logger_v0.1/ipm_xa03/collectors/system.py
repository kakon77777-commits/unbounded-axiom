from __future__ import annotations

import os

from ..clock import Clock
from ..models import TelemetrySample
from .base import CollectorCapabilities


class SystemCollector:
    name = "system"

    def __init__(self, clock: Clock, *, required: bool = False) -> None:
        self.clock = clock
        self.required = required
        try:
            import psutil  # type: ignore
        except ImportError:
            self._psutil = None
            self._process = None
        else:
            self._psutil = psutil
            self._process = psutil.Process(os.getpid())

    def start(self, run_context=None) -> None:
        return None

    def stop(self) -> None:
        return None

    def capabilities(self) -> CollectorCapabilities:
        ok = self._psutil is not None
        return CollectorCapabilities(cpu=ok, process_memory=ok)

    def sample(self, run_id: str) -> list[TelemetrySample]:
        if self._psutil is None or self._process is None:
            return [TelemetrySample(
                run_id=run_id,
                collector=self.name,
                t_monotonic_s=float(self.clock.monotonic()),
                timestamp=self.clock.timestamp(),
                metrics={},
                availability={"cpu": False, "process_memory": False},
            )]
        metrics = {}
        availability = {"cpu": True, "process_memory": True}
        try:
            cpu_times = self._process.cpu_times()
            metrics["system.process_cpu_time_s"] = float(cpu_times.user + cpu_times.system)
            metrics["system.cpu_utilization_fraction"] = float(self._psutil.cpu_percent(interval=None)) / 100.0
            metrics["system.process_rss_bytes"] = int(self._process.memory_info().rss)
            metrics["system.available_memory_bytes"] = int(self._psutil.virtual_memory().available)
        except Exception:
            metrics = {}
            availability = {"cpu": False, "process_memory": False}
        return [TelemetrySample(
            run_id=run_id,
            collector=self.name,
            t_monotonic_s=float(self.clock.monotonic()),
            timestamp=self.clock.timestamp(),
            metrics=metrics,
            availability=availability,
        )]
