from __future__ import annotations

import shutil
import subprocess

from ..clock import Clock
from ..models import TelemetrySample
from .base import CollectorCapabilities


QUERY_FIELDS = [
    "uuid",
    "index",
    "name",
    "utilization.gpu",
    "memory.used",
    "memory.total",
    "power.draw",
    "temperature.gpu",
    "clocks.gr",
    "power.limit",
]


def _num(value: str, caster=float):
    value = value.strip()
    if value.upper() in {"N/A", "NA", "NOT SUPPORTED", "[NOT SUPPORTED]", ""}:
        return None
    try:
        return caster(value)
    except (TypeError, ValueError):
        return None


def parse_nvidia_csv_line(line: str) -> dict[str, object]:
    parts = [p.strip() for p in line.split(",")]
    if len(parts) != 10:
        raise ValueError(f"expected 10 CSV fields, got {len(parts)}")
    uuid, index, name, util, mem_used, mem_total, power, temp, clock, power_limit = parts
    idx = _num(index, int)
    util_pct = _num(util, float)
    used_mib = _num(mem_used, float)
    total_mib = _num(mem_total, float)
    clock_mhz = _num(clock, float)
    return {
        "gpu.uuid": uuid or None,
        "gpu.index": idx,
        "gpu.name": name or None,
        "gpu.utilization_fraction": None if util_pct is None else util_pct / 100.0,
        "gpu.memory_used_bytes": None if used_mib is None else int(used_mib * 1024 * 1024),
        "gpu.memory_total_bytes": None if total_mib is None else int(total_mib * 1024 * 1024),
        "gpu.power_w": _num(power, float),
        "gpu.temperature_c": _num(temp, float),
        "gpu.graphics_clock_hz": None if clock_mhz is None else int(clock_mhz * 1_000_000),
        "gpu.power_limit_w": _num(power_limit, float),
    }


class NvidiaSmiCollector:
    name = "nvidia_smi"

    def __init__(self, clock: Clock, *, required: bool = False, executable: str = "nvidia-smi") -> None:
        self.clock = clock
        self.required = required
        self.executable = executable
        self.last_error: str | None = None

    def start(self, run_context=None) -> None:
        return None

    def stop(self) -> None:
        return None

    def capabilities(self) -> CollectorCapabilities:
        present = shutil.which(self.executable) is not None
        return CollectorCapabilities(
            gpu_power=present,
            gpu_memory=present,
            gpu_utilization=present,
        )

    def sample(self, run_id: str) -> list[TelemetrySample]:
        if shutil.which(self.executable) is None:
            self.last_error = f"{self.executable} not found"
            return [TelemetrySample(
                run_id=run_id,
                collector=self.name,
                t_monotonic_s=float(self.clock.monotonic()),
                timestamp=self.clock.timestamp(),
                metrics={},
                availability={"gpu": False},
            )]
        cmd = [
            self.executable,
            f"--query-gpu={','.join(QUERY_FIELDS)}",
            "--format=csv,noheader,nounits",
        ]
        try:
            cp = subprocess.run(cmd, text=True, capture_output=True, timeout=2, check=True)
            self.last_error = None
            lines = [line for line in cp.stdout.splitlines() if line.strip()]
            samples = []
            for line in lines:
                metrics = parse_nvidia_csv_line(line)
                device_id = metrics.get("gpu.uuid")
                availability = {
                    "gpu": True,
                    "gpu_power": metrics.get("gpu.power_w") is not None,
                    "gpu_memory": metrics.get("gpu.memory_used_bytes") is not None,
                    "gpu_utilization": metrics.get("gpu.utilization_fraction") is not None,
                }
                samples.append(TelemetrySample(
                    run_id=run_id,
                    collector=self.name,
                    t_monotonic_s=float(self.clock.monotonic()),
                    timestamp=self.clock.timestamp(),
                    metrics=metrics,
                    availability=availability,
                    device_id=str(device_id) if device_id is not None else None,
                ))
            return samples or [TelemetrySample(
                run_id=run_id, collector=self.name,
                t_monotonic_s=float(self.clock.monotonic()), timestamp=self.clock.timestamp(),
                metrics={}, availability={"gpu": False}
            )]
        except Exception as exc:
            self.last_error = f"{type(exc).__name__}: {exc}"
            return [TelemetrySample(
                run_id=run_id,
                collector=self.name,
                t_monotonic_s=float(self.clock.monotonic()),
                timestamp=self.clock.timestamp(),
                metrics={},
                availability={"gpu": False},
            )]
