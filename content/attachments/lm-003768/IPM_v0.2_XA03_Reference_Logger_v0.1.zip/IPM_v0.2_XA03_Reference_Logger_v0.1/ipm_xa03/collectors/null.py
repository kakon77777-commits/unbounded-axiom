from __future__ import annotations

from ..clock import Clock
from ..models import TelemetrySample
from .base import CollectorCapabilities


class NullCollector:
    name = "null"

    def __init__(self, clock: Clock, *, required: bool = False) -> None:
        self.clock = clock
        self.required = required

    def start(self, run_context=None) -> None:
        return None

    def stop(self) -> None:
        return None

    def capabilities(self) -> CollectorCapabilities:
        return CollectorCapabilities()

    def sample(self, run_id: str) -> list[TelemetrySample]:
        return [TelemetrySample(
            run_id=run_id,
            collector=self.name,
            t_monotonic_s=float(self.clock.monotonic()),
            timestamp=self.clock.timestamp(),
            metrics={},
            availability={"physical": False},
        )]
