from __future__ import annotations

from contextlib import contextmanager
from dataclasses import asdict
import json
from pathlib import Path
import platform
import sys
import threading
import time
from typing import Any, Iterator
from uuid import uuid4

from .clock import Clock, SystemClock
from .collectors import NullCollector, NvidiaSmiCollector, SystemCollector
from .events import EventLogger
from .integrator import integrate_run
from .models import RunConfig, TelemetrySample
from .sink import RunSink


class RunSession:
    def __init__(self, config: RunConfig, *, clock: Clock | None = None, collectors=None) -> None:
        self.config = config
        self.clock = clock or SystemClock()
        self.sink = RunSink(config.output_dir, config.run_id)
        self._collectors_override = collectors
        self._collectors = []
        self._event_logger: EventLogger | None = None
        self._telemetry_fh = None
        self._telemetry_lock = threading.Lock()
        self._stop_event = threading.Event()
        self._sampler_thread: threading.Thread | None = None
        self._sampler_error: Exception | None = None
        self._required_collector_error: Exception | None = None
        self._state = "CREATED"
        self._candidate_state: dict[str, str] = {}
        self._candidate_seq = 0
        self._sample_batches = 0
        self._sampling_wall_time_s = 0.0
        self._reported_collector_errors: set[tuple[str, str]] = set()

    @property
    def state(self) -> str:
        return self._state

    def _config_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.config.run_id,
            "output_dir": str(self.config.output_dir),
            "telemetry_interval_s": self.config.telemetry_interval_s,
            "collectors": list(self.config.collectors),
            "required_collectors": list(self.config.required_collectors),
            "physical_boundary": self.config.physical_boundary,
            "allocated_gpu_indices": list(self.config.allocated_gpu_indices),
        }

    def _build_collectors(self):
        if self._collectors_override is not None:
            return list(self._collectors_override)
        out = []
        for name in self.config.collectors:
            if name == "null":
                out.append(NullCollector(self.clock, required=name in self.config.required_collectors))
            elif name == "system":
                out.append(SystemCollector(self.clock, required=name in self.config.required_collectors))
            elif name == "nvidia_smi":
                out.append(NvidiaSmiCollector(self.clock, required=name in self.config.required_collectors))
            else:
                raise ValueError(f"unknown collector: {name}")
        if not out:
            out.append(NullCollector(self.clock))
        return out

    def __enter__(self) -> "RunSession":
        if self._state != "CREATED":
            raise RuntimeError(f"invalid RunSession transition from {self._state}")
        self.sink.create_partial(self._config_dict())
        self._event_logger = EventLogger(self.config.run_id, self.sink.events_path, self.clock)
        self._telemetry_fh = self.sink.telemetry_path.open("a", encoding="utf-8", newline="\n")
        self._collectors = self._build_collectors()
        for collector in self._collectors:
            collector.start({"run_id": self.config.run_id})
        self._state = "RUNNING"
        self._event_logger.emit("run_start")
        self._stop_event.clear()
        self._sampler_thread = threading.Thread(target=self._sampling_loop, name=f"ipm-xa03-{self.config.run_id}", daemon=True)
        self._sampler_thread.start()
        return self

    def _write_sample(self, sample: TelemetrySample) -> None:
        if self._telemetry_fh is None or self._telemetry_fh.closed:
            return
        row = asdict(sample)
        with self._telemetry_lock:
            self._telemetry_fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n")
            self._telemetry_fh.flush()

    def _sampling_loop(self) -> None:
        while not self._stop_event.is_set():
            batch_start = time.perf_counter()
            self._sample_batches += 1
            for collector in self._collectors:
                try:
                    samples = collector.sample(self.config.run_id)
                    for sample in samples:
                        self._write_sample(sample)
                    last_error = getattr(collector, "last_error", None)
                    if last_error:
                        key = (getattr(collector, "name", type(collector).__name__), str(last_error))
                        if key not in self._reported_collector_errors and self._event_logger is not None:
                            self._reported_collector_errors.add(key)
                            self._event_logger.emit("failure", attributes={
                                "class": "telemetry_degraded",
                                "collector": key[0],
                                "message": key[1],
                            })
                        if getattr(collector, "required", False):
                            self._required_collector_error = RuntimeError(str(last_error))
                            self._stop_event.set()
                            self._sampling_wall_time_s += time.perf_counter() - batch_start
                            return
                except Exception as exc:  # collectors should generally degrade, but preserve unexpected errors
                    self._sampler_error = exc
                    if getattr(collector, "required", False):
                        self._required_collector_error = exc
                        self._stop_event.set()
                    if self._event_logger is not None:
                        self._event_logger.emit("failure", attributes={
                            "class": "telemetry",
                            "collector": getattr(collector, "name", type(collector).__name__),
                            "error_type": type(exc).__name__,
                            "message": str(exc),
                        })
                    if self._required_collector_error is not None:
                        self._sampling_wall_time_s += time.perf_counter() - batch_start
                        return
            self._sampling_wall_time_s += time.perf_counter() - batch_start
            self._stop_event.wait(self.config.telemetry_interval_s)

    def _stop_collectors(self) -> None:
        self._stop_event.set()
        if self._sampler_thread is not None:
            self._sampler_thread.join(timeout=max(3.0, self.config.telemetry_interval_s * 4))
        for collector in self._collectors:
            try:
                collector.stop()
            except Exception as exc:
                if self._event_logger is not None:
                    self._event_logger.emit("failure", attributes={
                        "class": "telemetry_stop",
                        "collector": getattr(collector, "name", type(collector).__name__),
                        "error_type": type(exc).__name__,
                        "message": str(exc),
                    })

    def _provenance(self) -> dict[str, Any]:
        return {
            "xa03_version": "0.1",
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "implementation": platform.python_implementation(),
        }

    def _finalize(self, state: str) -> Path:
        assert self._event_logger is not None
        self._state = "FINALIZING" if state == "COMPLETE" else "ABORTING"
        self._stop_collectors()
        self._event_logger.emit("telemetry_instrumentation", attributes={
            "sample_batches": self._sample_batches,
            "sampling_wall_time_s": self._sampling_wall_time_s,
        })
        if state == "COMPLETE":
            self._event_logger.emit("run_end")
        else:
            # run_abort is an observed lifecycle event, unlike recovery of an already-crashed process.
            self._event_logger.emit("run_abort")
        self._event_logger.close()
        if self._telemetry_fh is not None:
            self._telemetry_fh.flush()
            self._telemetry_fh.close()
        summary = integrate_run(self.config, self.sink.events_path, self.sink.telemetry_path)
        summary["run"]["state"] = state
        summary["provenance"] = self._provenance()
        final = self.sink.finalize_complete(summary) if state == "COMPLETE" else self.sink.finalize_aborted(summary)
        self._state = state
        return final

    def __exit__(self, exc_type, exc, tb) -> bool:
        if self._state != "RUNNING":
            return False
        if exc is None:
            if self._required_collector_error is not None:
                self._finalize("ABORTED")
                raise RuntimeError("required telemetry collector failed") from self._required_collector_error
            self._finalize("COMPLETE")
            return False
        assert self._event_logger is not None
        self._event_logger.emit("failure", attributes={
            "class": "run_exception",
            "error_type": exc_type.__name__ if exc_type else type(exc).__name__,
            "message": str(exc),
        })
        self._finalize("ABORTED")
        return False

    @contextmanager
    def _span(self, kind: str, attributes: dict[str, Any] | None = None) -> Iterator[str]:
        if self._state != "RUNNING" or self._event_logger is None:
            raise RuntimeError("RunSession is not running")
        sid = self._event_logger.start_span(kind, attributes=attributes)
        try:
            yield sid
        except Exception as exc:
            self._event_logger.emit("failure", span_id=sid, attributes={
                "class": kind,
                "error_type": type(exc).__name__,
                "message": str(exc),
            })
            self._event_logger.end_span(kind, sid, attributes={"ok": False})
            raise
        else:
            self._event_logger.end_span(kind, sid, attributes={"ok": True})

    def model_invocation(self, **attributes):
        return self._span("model_invocation", attributes or None)

    def trajectory(self, **attributes):
        return self._span("trajectory", attributes or None)

    def retry(self, **attributes):
        return self._span("retry", attributes or None)

    def tool_call(self, *, tool_type: str | None = None, **attributes):
        attrs = dict(attributes)
        if tool_type is not None:
            attrs["tool_type"] = tool_type
        return self._span("tool_call", attrs or None)

    def verifier(self, **attributes):
        return self._span("verifier", attributes or None)

    def candidate_created(self, candidate_id: str | None = None, **attributes) -> str:
        if self._event_logger is None or self._state != "RUNNING":
            raise RuntimeError("RunSession is not running")
        self._candidate_seq += 1
        cid = candidate_id or f"candidate-{self._candidate_seq:06d}-{uuid4().hex[:8]}"
        if cid in self._candidate_state:
            raise ValueError(f"candidate already exists: {cid}")
        self._candidate_state[cid] = "created"
        attrs = {"candidate_id": cid, **attributes}
        self._event_logger.emit("candidate_created", attributes=attrs)
        return cid

    def candidate_selected(self, candidate_id: str, **attributes) -> None:
        if self._event_logger is None:
            raise RuntimeError("RunSession is not running")
        state = self._candidate_state.get(candidate_id)
        if state is None:
            raise ValueError(f"unknown candidate: {candidate_id}")
        if state == "discarded":
            raise ValueError("discarded candidate cannot be selected")
        if state == "selected":
            raise ValueError("candidate already selected")
        self._candidate_state[candidate_id] = "selected"
        self._event_logger.emit("candidate_selected", attributes={"candidate_id": candidate_id, **attributes})

    def candidate_discarded(self, candidate_id: str, **attributes) -> None:
        if self._event_logger is None:
            raise RuntimeError("RunSession is not running")
        state = self._candidate_state.get(candidate_id)
        if state is None:
            raise ValueError(f"unknown candidate: {candidate_id}")
        if state == "selected":
            raise ValueError("selected candidate cannot be discarded")
        if state == "discarded":
            raise ValueError("candidate already discarded")
        self._candidate_state[candidate_id] = "discarded"
        self._event_logger.emit("candidate_discarded", attributes={"candidate_id": candidate_id, **attributes})
