from __future__ import annotations

import math
from typing import Any


LEGAL_STATES = {"COMPLETE", "ABORTED", "INCOMPLETE"}
LEGAL_DEVICE_ENERGY_TYPES = {"unknown", "device_measured"}


def _nonnegative_or_none(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    return math.isfinite(float(value)) and float(value) >= 0.0


def validate_summary(summary: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    for key in ("run", "execution", "physical", "hidden_work", "measurement", "provenance"):
        if key not in summary or not isinstance(summary[key], dict):
            errors.append(f"missing or invalid top-level field: {key}")
    if errors:
        return errors

    run = summary["run"]
    state = run.get("state")
    if state not in LEGAL_STATES:
        errors.append(f"run.state is illegal: {state!r}")
    if not run.get("run_id"):
        errors.append("run.run_id must be non-empty")

    execution = summary["execution"]
    for plural in ("model_invocations", "trajectories", "retries", "tool_calls", "verifier_passes"):
        started = execution.get(f"{plural}_started")
        completed = execution.get(f"{plural}_completed")
        for label, value in (("started", started), ("completed", completed)):
            if value is not None and (isinstance(value, bool) or not isinstance(value, int) or value < 0):
                errors.append(f"execution.{plural}_{label} must be a nonnegative integer")
        if isinstance(started, int) and not isinstance(started, bool) and isinstance(completed, int) and not isinstance(completed, bool) and completed > started:
            errors.append(f"execution.{plural}_completed cannot exceed {plural}_started")
    wall = execution.get("wall_time_s")
    if not _nonnegative_or_none(wall) or wall is None:
        errors.append("execution.wall_time_s must be a finite nonnegative number")

    physical = summary["physical"]
    for field in (
        "device_energy_j", "marginal_energy_j", "attributed_energy_j",
        "gpu_peak_memory_bytes", "gpu_memory_residency_byte_s",
        "gpu_utilization_integral_s", "allocated_device_time_s",
        "gpu_peak_power_w", "gpu_mean_power_w", "gpu_peak_temperature_c",
        "system_peak_rss_bytes", "system_cpu_time_s",
    ):
        if field in physical and not _nonnegative_or_none(physical.get(field)):
            errors.append(f"physical.{field} must be null or finite nonnegative")

    et = physical.get("device_energy_type", "unknown")
    if et not in LEGAL_DEVICE_ENERGY_TYPES:
        errors.append(f"physical.device_energy_type is illegal: {et!r}")
    device_energy = physical.get("device_energy_j")
    if device_energy is None and et != "unknown":
        errors.append("physical.device_energy_type must be 'unknown' when device_energy_j is null")
    if device_energy is not None and et != "device_measured":
        errors.append("physical.device_energy_type must be 'device_measured' when device_energy_j is present")

    for field in ("marginal_energy_j", "attributed_energy_j"):
        # Values are allowed only as explicitly separate typed fields. The device energy type can never relabel them.
        if physical.get(field) is not None and et == field.removesuffix("_j"):
            errors.append(f"physical.device_energy_type cannot relabel {field}")

    hidden = summary["hidden_work"]
    dc = hidden.get("discarded_candidates", 0)
    if isinstance(dc, bool) or not isinstance(dc, int) or dc < 0:
        errors.append("hidden_work.discarded_candidates must be a nonnegative integer")
    return errors
