from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import time
from typing import Protocol


class Clock(Protocol):
    def monotonic(self) -> float: ...
    def timestamp(self) -> str: ...


class SystemClock:
    def __init__(self) -> None:
        self._origin = time.monotonic()

    def monotonic(self) -> float:
        return time.monotonic() - self._origin

    def timestamp(self) -> str:
        return datetime.now().astimezone().isoformat()


@dataclass
class FakeClock:
    start_wall: str
    _mono: float = 0.0

    def __post_init__(self) -> None:
        self._wall = datetime.fromisoformat(self.start_wall)
        if self._wall.tzinfo is None:
            self._wall = self._wall.replace(tzinfo=timezone.utc)

    def monotonic(self) -> float:
        return self._mono

    def timestamp(self) -> str:
        return (self._wall + timedelta(seconds=self._mono)).isoformat()

    def advance(self, seconds: float) -> None:
        if seconds < 0:
            raise ValueError("FakeClock cannot move backwards")
        self._mono += float(seconds)
