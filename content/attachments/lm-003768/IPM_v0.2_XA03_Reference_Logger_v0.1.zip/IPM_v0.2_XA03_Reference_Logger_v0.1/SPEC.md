# IPM v0.2 XA-03 — Telemetry & Run Logger Reference Specification

## EML-IPM-XA-03 v0.1 Design Specification

**Series:** Intelligence Physical Metrology (IPM)  
**Version:** v0.2 Experimental Measurement Protocol  
**Artifact ID:** EML-IPM-XA-03  
**Design Version:** v0.1  
**Author:** Neo.K with Aletheia（GPT-5.6 Sol）  
**Institution:** EveMissLab／一言諾科技有限公司  
**Date:** 2026-09-03  
**Status:** DESIGN APPROVED IN CHAT — WRITTEN SPEC FOR FINAL REVIEW  
**Implements:** XA-01 Protocol + XA-02 30-Task Pilot Pack  
**Next consumer:** XA-04 A0→A5 Model Runner

---

# 1. Goal

Build a deterministic, extensible telemetry and run-logging layer that records one IPM Experiment A run as an immutable measurement event.

The logger must answer:

1. How long did the run take?
2. How many model invocations, trajectories, retries, tool calls, verifier passes, and discarded candidates occurred?
3. Which hardware resources were occupied, and for how long?
4. What CPU / RAM / GPU / VRAM / power telemetry was observed?
5. What physical quantities can be legitimately derived from those observations?
6. Which quantities are unknown rather than merely estimated?
7. Can the same raw event trace deterministically reproduce the same summary?
8. Can a failed or interrupted run be recovered without inventing data?

The system is a measurement instrument, not a dashboard or orchestration framework.

---

# 2. Non-Goals

XA-03 v0.1 will NOT implement:

- a model provider SDK;
- the A0→A5 runner;
- a benchmark scheduler;
- a dashboard;
- Prometheus / Grafana;
- a database server;
- distributed cluster telemetry;
- data-center PUE;
- embodied/lifecycle energy;
- inferred Joules from token count;
- inferred marginal energy without an explicit matched baseline;
- private chain-of-thought capture.

These belong to later artifacts.

---

# 3. Core Design

XA-03 uses five independent components:

\[
\boxed{
RunSession
+
EventLogger
+
TelemetryCollector
+
MetricIntegrator
+
RunSink
}
\]

The canonical data flow is:

\[
\boxed{
RunStart
\rightarrow
Events + Telemetry(t)
\rightarrow
RunEnd
\rightarrow
Integration
\rightarrow
SchemaValidation
\rightarrow
ImmutableRunRecord
}
\]

No component may silently change the semantics of another component's data.

---

# 4. Component A — RunSession

`RunSession` owns the lifetime of exactly one benchmark run.

Responsibilities:

- generate or accept a canonical `run_id`;
- capture UTC wall-clock timestamp;
- capture a monotonic start clock;
- start configured telemetry collectors;
- expose event-logging methods;
- stop collectors on normal exit;
- stop collectors on exception;
- emit `run_end` or `run_abort`;
- trigger metric integration;
- trigger schema validation;
- atomically finalize the run directory.

`RunSession` must be usable as a Python context manager:

```python
with RunSession(config) as run:
    ...
```

A `RunSession` may only transition:

```text
CREATED
  -> RUNNING
      -> FINALIZING
          -> COMPLETE

RUNNING
  -> ABORTING
      -> ABORTED
```

Invalid transitions raise an error and are themselves logged when possible.

---

# 5. Clock Semantics

Two clocks are mandatory.

## 5.1 Wall Timestamp

Used for provenance:

```text
2026-09-03T01:12:34.123456+08:00
```

This may move because of system clock adjustment and therefore MUST NOT be used to integrate duration.

## 5.2 Monotonic Clock

Used for:

- wall duration;
- telemetry integration;
- event ordering;
- device-time;
- Joule integration.

Canonical internal time:

\[
\boxed{
t_i = \text{monotonic\_seconds since run start}
}
\]

Every event and telemetry sample must carry `t_monotonic_s`.

---

# 6. Component B — EventLogger

`EventLogger` records discrete execution events in append-only JSONL.

Canonical event classes:

```text
run_start
run_end
run_abort

model_invocation_start
model_invocation_end

trajectory_start
trajectory_end

retry_start
retry_end

tool_call_start
tool_call_end

verifier_start
verifier_end

candidate_created
candidate_selected
candidate_discarded

failure
note
```

Every event MUST contain:

```json
{
  "event_id": "uuid-or-monotonic-sequence",
  "run_id": "...",
  "event_type": "...",
  "t_monotonic_s": 1.234,
  "timestamp": "...",
  "attributes": {}
}
```

The logger MUST NOT require private reasoning text.

Operational metadata is sufficient.

---

# 7. Event Pairing Rules

Start/end events use `span_id`.

Example:

```json
{
  "event_type": "tool_call_start",
  "span_id": "tool-0003",
  "attributes": {
    "tool_type": "compiler"
  }
}
```

A matching end event uses the same `span_id`.

The integrator must detect:

- missing end;
- duplicate end;
- end-before-start;
- nested spans where forbidden.

Incomplete spans are preserved as incomplete rather than silently repaired.

---

# 8. Candidate / Discarded Work Accounting

Every generated complete candidate that can be independently selected must receive a `candidate_id`.

Events:

```text
candidate_created
candidate_selected
candidate_discarded
```

A selected candidate cannot simultaneously be marked discarded.

Discarded candidate count:

\[
\boxed{
N_{\mathrm{discarded}}
}
\]

must be derived from events rather than manually entered into the summary.

If candidate-level cost attribution is available, the summary may additionally report:

\[
\boxed{
C_{\mathrm{discarded}}
}
\]

Otherwise it remains `null`.

---

# 9. Component C — TelemetryCollector Interface

A collector samples one physical resource domain.

Canonical interface:

```python
class TelemetryCollector(Protocol):
    name: str

    def start(self, run_context) -> None: ...
    def sample(self) -> TelemetrySample: ...
    def stop(self) -> None: ...
    def capabilities(self) -> CollectorCapabilities: ...
```

Collectors MUST NOT fabricate unsupported metrics.

Unavailable values are `null` with explicit availability metadata.

---

# 10. TelemetrySample

Every sample uses a common envelope:

```json
{
  "run_id": "...",
  "collector": "nvidia_smi",
  "t_monotonic_s": 2.500,
  "timestamp": "...",
  "metrics": {},
  "availability": {}
}
```

Example metrics:

```json
{
  "gpu.utilization_fraction": 0.84,
  "gpu.memory_used_bytes": 11811160064,
  "gpu.power_w": 187.4,
  "gpu.temperature_c": 71.0,
  "gpu.graphics_clock_hz": 1815000000
}
```

Metric names must be namespaced.

---

# 11. Collector A — NullCollector

Purpose:

- API / black-box runs;
- deterministic tests;
- platforms without local telemetry.

It reports no physical measurements but preserves logger behavior.

Example capability:

```json
{
  "wall_time": true,
  "gpu_power": false,
  "gpu_memory": false,
  "cpu": false
}
```

Unknown telemetry MUST stay unknown.

---

# 12. Collector B — SystemCollector

Uses standard OS-accessible metrics where available.

v0.1 target metrics:

- process CPU time;
- system CPU utilization;
- process RSS;
- system available memory.

Preferred implementation dependency:

- `psutil` if installed.

If `psutil` is unavailable:

- collector declares degraded capabilities;
- logger continues;
- no installation is attempted automatically.

---

# 13. Collector C — NvidiaSmiCollector

Uses `nvidia-smi` command output.

v0.1 supported metrics, when exposed:

- GPU utilization;
- VRAM used;
- total VRAM;
- power draw;
- temperature;
- SM / graphics clock;
- power limit;
- device UUID / index.

The collector must not assume all NVIDIA GPUs expose all fields.

A query failure produces:

- a collector error event;
- `null` sample values;
- continued run logging unless `collector_required=true`.

---

# 14. GPU Device Identity

Every GPU sample must include a stable hardware identity when available:

```text
gpu.uuid
gpu.index
gpu.name
```

Metrics from two devices must never be silently aggregated before raw storage.

Per-device samples are preserved.

---

# 15. Sampling Interval

Canonical default:

\[
\boxed{
\Delta t = 0.25\text{ s}
}
\]

Configurable range for v0.1:

```text
0.05 s <= interval <= 5.0 s
```

Intervals below 50 ms are rejected in reference implementation to avoid the logger becoming a significant workload itself.

---

# 16. Telemetry Overhead

The measurement system consumes resources.

XA-03 must therefore record:

- collector sample count;
- collector wall time spent sampling;
- telemetry thread/process CPU time when available.

A future calibration can estimate:

\[
\boxed{
C_{\mathrm{instrument}}
}
\]

v0.1 does not subtract it automatically.

---

# 17. Component D — MetricIntegrator

The integrator reads raw events + raw telemetry after the run.

It MUST be deterministic.

It may compute only metrics justified by available raw data.

---

# 18. Wall Time

\[
\boxed{
T_{\mathrm{wall}}
=
t_{\mathrm{end}} - t_{\mathrm{start}}
}
\]

using monotonic time only.

---

# 19. Invocation Counts

Derived strictly from event pairs.

Summary fields:

```text
model_invocations_started
model_invocations_completed
trajectories_started
trajectories_completed
retries_started
retries_completed
tool_calls_started
tool_calls_completed
verifier_passes_started
verifier_passes_completed
```

A crash can therefore preserve attempted vs completed work.

---

# 20. Device-Time

For each device \(d\):

\[
\boxed{
V_{C,d}
=
\int_0^T a_d(t)\,dt
}
\]

where \(a_d(t)\) is an explicitly defined activity/occupancy function.

v0.1 MUST NOT equate raw GPU utilization percentage with exact device allocation.

Reference implementation reports two separate objects where possible:

1. **allocated_device_time_s** — if the run declares the device reserved for the whole run;
2. **utilization_integral_s**:

\[
\boxed{
\int u_d(t)\,dt
}
\]

where \(u_d(t)\in[0,1]\) is telemetry utilization.

These are not the same quantity.

---

# 21. Memory Peak

For device memory:

\[
\boxed{
M_{\mathrm{peak}}
=
\max_t M(t)
}
\]

computed per device and optionally summed only with explicit aggregation.

---

# 22. Memory Residency

If memory-used telemetry exists:

\[
\boxed{
V_M
=
\int_0^T M(t)\,dt
}
\]

using trapezoidal integration.

Unit:

```text
byte·second
```

The raw time series remains canonical.

---

# 23. Energy Integration

If measured device power exists:

\[
\boxed{
E_{\mathrm{device}}
=
\int_0^T P_{\mathrm{device}}(t)\,dt
}
\]

using trapezoidal integration.

Unit:

```text
Joule
```

Energy output type MUST be:

```text
device_measured
```

unless a stronger experimental design justifies another type.

---

# 24. Energy Type Safety

XA-03 MUST enforce:

```text
measured device power
    -> device_energy_j

matched controlled baseline
    -> may support marginal_energy_j

allocation rule + shared overhead
    -> may support attributed_energy_j
```

The following conversions are forbidden:

```text
tokens -> Joules
TDP -> measured Joules
GPU-hours -> measured Joules
price -> Joules
```

unless the field is explicitly named as an estimate and the estimator is declared.

---

# 25. Marginal Energy

The logger alone cannot infer marginal energy.

Therefore:

```json
"marginal_energy_j": null
```

by default.

It can be populated only by an analysis stage that has:

- a declared baseline;
- matched boundary;
- matched duration or controlled integration rule;
- declared subtraction methodology.

---

# 26. Component E — RunSink

Each run writes to a unique directory:

```text
runs/
  <run_id>/
    config.json
    events.jsonl
    telemetry.jsonl
    summary.json
    validation.json
    COMPLETE
```

On abort:

```text
runs/
  <run_id>/
    ...
    ABORTED
```

No run may contain both `COMPLETE` and `ABORTED`.

---

# 27. Atomic Finalization

During execution, use a temporary directory:

```text
.<run_id>.partial/
```

On successful finalization:

1. flush all files;
2. close collectors;
3. integrate metrics;
4. validate schema;
5. fsync where practical;
6. atomically rename to `<run_id>/`;
7. create `COMPLETE`.

If the process crashes before finalization, the partial directory remains available for recovery.

---

# 28. Crash Recovery

Reference recovery procedure:

1. detect stale `.partial` directory;
2. preserve raw files unchanged;
3. append a synthetic recovery metadata record, not a fake original event;
4. integrate only available intervals;
5. mark all incomplete spans;
6. output `ABORTED`.

Recovery must never invent:

- missing power samples;
- missing event ends;
- missing candidate costs.

---

# 29. Canonical Summary

`summary.json` contains derived data only.

Proposed top-level structure:

```json
{
  "run": {},
  "execution": {},
  "physical": {},
  "hidden_work": {},
  "measurement": {},
  "provenance": {}
}
```

Raw events and raw telemetry are the source of truth.

---

# 30. Execution Summary Fields

```text
wall_time_s

model_invocations_started
model_invocations_completed

trajectories_started
trajectories_completed

retries_started
retries_completed

tool_calls_started
tool_calls_completed

verifier_passes_started
verifier_passes_completed

candidates_created
candidates_selected
candidates_discarded

failure_count
```

---

# 31. Physical Summary Fields

```text
device_energy_j
device_energy_type

gpu_peak_memory_bytes
gpu_memory_residency_byte_s

gpu_utilization_integral_s
allocated_device_time_s

gpu_peak_power_w
gpu_mean_power_w
gpu_peak_temperature_c

system_peak_rss_bytes
system_cpu_time_s

sample_count
sample_interval_target_s
```

Unsupported values remain `null`.

---

# 32. Measurement Metadata

Every derived metric must carry enough metadata to identify:

- collector;
- availability;
- units;
- integration method;
- boundary;
- aggregation rule;
- data completeness.

At minimum:

```json
{
  "physical_boundary": "accelerator-only",
  "energy_grade": "E-C",
  "cst_grade": "CST-C",
  "telemetry_complete": true,
  "sample_gap_count": 0
}
```

---

# 33. Data Completeness

A telemetry gap is detected when:

\[
\boxed{
t_{i+1}-t_i > 2.5\Delta t_{\mathrm{target}}
}
\]

Default threshold is configurable.

Integrator reports:

```text
sample_gap_count
largest_gap_s
coverage_fraction
```

Energy and residency remain computed from observed samples but are marked incomplete when gaps violate policy.

---

# 34. Schema Validation

XA-03 defines a standalone run-record schema compatible with XA-01 concepts.

Schema validation checks:

- required top-level fields;
- nonnegative durations;
- legal energy types;
- legal run states;
- count consistency;
- COMPLETE/ABORTED exclusivity;
- nullability for unknown metrics.

Schema validation MUST NOT convert missing values to zero.

---

# 35. Zero vs Unknown

Canonical distinction:

```text
0
```

means a metric was measured or logically derived and equals zero.

```text
null
```

means unknown / unavailable / unsupported.

Therefore:

\[
\boxed{
Unknown \neq 0.
}
\]

---

# 36. Collector Failure Policy

Collector configuration supports:

```json
{
  "required": false
}
```

If `required=false`:

- log collector error;
- mark affected metrics unavailable;
- continue benchmark.

If `required=true`:

- abort run;
- preserve raw logs;
- mark failure class `telemetry_required_failure`.

---

# 37. Threading Model

v0.1 uses:

- benchmark code in main thread/process;
- telemetry sampling in one background thread per collector or a single scheduler thread.

No asynchronous framework dependency is required.

Thread shutdown must be bounded.

A collector that cannot stop within timeout is marked failed and cannot block run finalization forever.

---

# 38. Output Determinism

Given identical:

```text
events.jsonl
telemetry.jsonl
config.json
```

the integrator must produce byte-equivalent canonical `summary.json`, excluding explicitly nondeterministic provenance fields if any.

JSON output uses:

- UTF-8;
- sorted keys where canonicalized;
- stable float formatting policy;
- no NaN / Infinity.

---

# 39. Golden Deterministic Test

XA-03 must ship a fake clock and scripted fake collector.

Canonical fake trace:

```text
t=0s  power=100W  memory=10GB  util=0.5
t=1s  power=100W  memory=12GB  util=1.0
t=2s  power=200W  memory=12GB  util=0.5
t=3s  power=200W  memory=8GB   util=0.0
```

Expected trapezoidal energy:

\[
\boxed{
E
=
100(1)
+
150(1)
+
200(1)
=
450J
}
\]

Expected utilization integral:

\[
\boxed{
V_u
=
0.75
+
0.75
+
0.25
=
1.75\text{ utilization-seconds}
}
\]

Expected peak memory:

\[
\boxed{
12GB.
}
\]

This golden fixture is the primary deterministic integration test.

---

# 40. Event Accounting Test

Scripted events must include:

- 3 model invocations;
- 2 trajectories;
- 1 retry;
- 2 tool calls;
- 1 verifier pass;
- 4 candidates;
- 1 selected;
- 3 discarded.

Expected summary must match exactly.

---

# 41. Abort Recovery Test

Create a partial run with:

- run_start;
- one unmatched model invocation start;
- telemetry samples;
- no run_end.

Recovery must produce:

```text
ABORTED
model_invocations_started = 1
model_invocations_completed = 0
incomplete_span_count = 1
```

and must not synthesize a normal invocation end.

---

# 42. Unknown Metric Test

With `NullCollector`:

```text
wall_time_s -> valid
device_energy_j -> null
gpu_peak_memory_bytes -> null
```

The run must still validate successfully.

---

# 43. NVIDIA Integration Test

Optional, skipped when `nvidia-smi` is absent.

When present:

- collector initializes;
- device UUID/name returned;
- at least one sample recorded;
- nonnegative VRAM/power/utilization fields where supported;
- no assumption that power field is universally available.

This is an integration test, not a deterministic unit test.

---

# 44. SystemCollector Integration Test

Optional if `psutil` unavailable.

When present:

- process RSS is nonnegative;
- CPU time is nonnegative;
- collector can start/stop cleanly.

---

# 45. Logger Self-Interference Test

Run an empty 5-second session:

1. NullCollector only;
2. active collectors.

Report but do not automatically subtract:

```text
additional process CPU time
additional wall scheduling delay
sample count
```

This quantifies instrumentation burden.

---

# 46. Error Handling Principles

XA-03 follows:

\[
\boxed{
PreserveRawData
>
InventMissingData.
}
\]

and:

\[
\boxed{
PartialMeasurement
>
FalsePrecision.
}
\]

Any partial result must carry an incompleteness flag.

---

# 47. Provenance

`config.json` captures:

- XA-03 version;
- XA-01 protocol version;
- XA-02 task pack version if known;
- Python version;
- OS;
- hostname hash or anonymous machine ID;
- collector versions;
- hardware identifiers;
- command/config used to start the run.

No secret API keys may be written.

---

# 48. Privacy / Sensitive Data

The logger must not automatically dump:

- prompts;
- model responses;
- environment secrets;
- API headers;
- private chain-of-thought.

The caller may explicitly attach safe task/result identifiers separately.

---

# 49. File Layout of Reference Implementation

```text
xa03/
  README.md
  SPEC.md

  ipm_xa03/
    __init__.py
    clock.py
    models.py
    events.py
    session.py
    sink.py
    integrator.py
    schema.py

    collectors/
      __init__.py
      base.py
      null.py
      system.py
      nvidia_smi.py

  schemas/
    run_summary.schema.json
    event.schema.json
    telemetry.schema.json

  examples/
    basic_session.py
    instrumented_fake_run.py

  tests/
    test_clock.py
    test_events.py
    test_integrator_golden.py
    test_null_collector.py
    test_abort_recovery.py
    test_schema.py
    test_nvidia_optional.py
    test_system_optional.py

  fixtures/
    golden_events.jsonl
    golden_telemetry.jsonl

  validation_report.json
  manifest.json
```

Each file has one principal responsibility.

---

# 50. Public API v0.1

Primary entry point:

```python
from ipm_xa03 import RunSession, RunConfig
```

Example:

```python
config = RunConfig(
    run_id="IPM-XA-example-MATH-001-A0-01",
    output_dir="runs",
    telemetry_interval_s=0.25,
    collectors=["system", "nvidia_smi"],
)

with RunSession(config) as run:
    with run.model_invocation():
        with run.trajectory():
            answer = model_call()
```

Tool example:

```python
with run.tool_call(tool_type="compiler"):
    compile_result = run_compiler()
```

Candidate example:

```python
candidate_id = run.candidate_created()
run.candidate_discarded(candidate_id)
```

No provider SDK is embedded in XA-03.

---

# 51. Performance Constraints

Reference logger targets:

- event append operation: sub-millisecond typical local overhead;
- telemetry interval default: 250 ms;
- no busy-wait sampling;
- memory use bounded by streaming to JSONL rather than retaining full traces in RAM;
- final integration may stream large JSONL files.

These are engineering targets, not scientific assumptions.

---

# 52. Dependency Policy

Core:

- Python 3.11+;
- standard library only.

Optional:

- `psutil` for SystemCollector.

NVIDIA:

- external `nvidia-smi` executable;
- no Python NVIDIA package required for v0.1.

Test framework may use `pytest`.

No database dependency.

---

# 53. Scientific Boundary

XA-03 can directly support:

- wall time;
- execution counts;
- measured device power integration;
- GPU memory residency;
- approximate utilization integral;
- local process/system telemetry.

It does NOT by itself establish:

- full node energy;
- facility energy;
- marginal energy;
- attributed energy;
- semiconductor operation count;
- semantic work;
- intelligence quality.

Those belong to other IPM layers.

---

# 54. Measurement Grades Produced by XA-03

Typical local NVIDIA run:

```text
Energy: E-Grade C
CST: CST-Grade C/B depending on available hardware telemetry
Scaffolding: contributes execution trace evidence toward S-Grade C
```

XA-03 cannot claim S-Grade B controlled ablation by itself; XA-04 runner and XA analysis are required.

---

# 55. Canonical Invariants

\[
\boxed{
WallClockTimestamp
\neq
MonotonicDurationClock.
}
\]

\[
\boxed{
GPUUtilization
\neq
AllocatedDeviceTime.
}
\]

\[
\boxed{
TDP
\neq
MeasuredEnergy.
}
\]

\[
\boxed{
DeviceEnergy
\neq
MarginalEnergy.
}
\]

\[
\boxed{
Unknown
\neq
Zero.
}
\]

\[
\boxed{
Summary
\neq
RawTrace.
}
\]

\[
\boxed{
CollectorFailure
\neq
AutomaticMetricFabrication.
}
\]

\[
\boxed{
Recovery
\neq
SyntheticCompletion.
}
\]

\[
\boxed{
OperationalAccounting
\neq
PrivateReasoningDisclosure.
}
\]

---

# 56. Acceptance Criteria

XA-03 v0.1 is implementation-complete only if:

1. Golden 450 J integration test passes exactly within declared float tolerance.
2. Utilization integral golden value equals 1.75 utilization-seconds.
3. Peak memory fixture returns 12 GB.
4. Event accounting fixture matches every expected count.
5. NullCollector run validates with physical metrics `null`.
6. Abort recovery preserves incomplete spans.
7. Schema rejects illegal run state and negative durations.
8. No code path converts unavailable metrics to zero.
9. Optional NVIDIA test skips cleanly without hardware.
10. Optional SystemCollector test skips cleanly without `psutil`.
11. Re-integrating raw traces yields deterministic summary.
12. Validation report records all test outcomes.
13. Manifest hashes all released files.
14. ZIP package hash is computed after final verification.

---

# 57. Handoff to XA-04

XA-04 must consume XA-03 only through public interfaces.

XA-04 responsibilities:

- call models;
- implement A0–A5 scaffolding policies;
- invoke XA-02 evaluator;
- attach quality result;
- use XA-03 for measurement.

XA-03 must remain model-provider agnostic.

This boundary prevents telemetry code from becoming entangled with agent behavior.

---

# 58. Final Design Principle

\[
\boxed{
\textbf{
XA-03 does not decide what intelligence is.
It decides how to record, preserve, and type the physical execution evidence
without silently converting proxies into measurements.
}
}
\]

That is the correct role of the IPM telemetry layer.
