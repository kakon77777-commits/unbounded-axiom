import json

from ipm_xa03.clock import FakeClock
from ipm_xa03.events import EventLogger


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_emit_records_run_time_and_attributes(tmp_path):
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    path = tmp_path / "events.jsonl"
    logger = EventLogger("run-1", path, clock)
    ev = logger.emit("note", attributes={"x": 1})
    logger.close()
    rows = read_jsonl(path)
    assert rows == [ev]
    assert ev["run_id"] == "run-1"
    assert ev["event_type"] == "note"
    assert ev["t_monotonic_s"] == 0.0
    assert ev["timestamp"].startswith("2026-09-03T00:00:00")
    assert ev["attributes"] == {"x": 1}


def test_start_and_end_span_share_span_id(tmp_path):
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    logger = EventLogger("run-1", tmp_path / "events.jsonl", clock)
    span = logger.start_span("tool_call", attributes={"tool_type": "compiler"})
    clock.advance(0.5)
    logger.end_span("tool_call", span, attributes={"ok": True})
    logger.close()
    rows = read_jsonl(tmp_path / "events.jsonl")
    assert [r["event_type"] for r in rows] == ["tool_call_start", "tool_call_end"]
    assert rows[0]["span_id"] == rows[1]["span_id"] == span
    assert rows[1]["t_monotonic_s"] == 0.5


def test_unmatched_start_is_not_auto_completed(tmp_path):
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    logger = EventLogger("run-1", tmp_path / "events.jsonl", clock)
    logger.start_span("model_invocation")
    logger.close()
    rows = read_jsonl(tmp_path / "events.jsonl")
    assert [r["event_type"] for r in rows] == ["model_invocation_start"]


def test_events_have_strictly_increasing_sequence_ids(tmp_path):
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    logger = EventLogger("run-1", tmp_path / "events.jsonl", clock)
    a = logger.emit("note")
    b = logger.emit("note")
    logger.close()
    assert a["event_id"] != b["event_id"]
    assert a["sequence"] == 1
    assert b["sequence"] == 2

def test_reopened_logger_continues_existing_sequence(tmp_path):
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    path = tmp_path / "events.jsonl"
    a = EventLogger("run-1", path, clock)
    a.emit("note")
    a.close()
    b = EventLogger("run-1", path, clock)
    ev = b.emit("recovery")
    b.close()
    assert ev["sequence"] == 2
