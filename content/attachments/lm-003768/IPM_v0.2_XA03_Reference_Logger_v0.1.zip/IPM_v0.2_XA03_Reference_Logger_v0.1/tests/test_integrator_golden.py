import json
from pathlib import Path

import pytest

from ipm_xa03.integrator import integrate_run
from ipm_xa03.models import RunConfig

FIX = Path(__file__).resolve().parents[1] / "fixtures"


def test_golden_physical_integrals(tmp_path):
    cfg = RunConfig(run_id="golden", output_dir=tmp_path, telemetry_interval_s=1.0, physical_boundary="accelerator-only")
    summary = integrate_run(cfg, FIX / "golden_events.jsonl", FIX / "golden_telemetry.jsonl")
    p = summary["physical"]
    assert p["device_energy_j"] == pytest.approx(450.0)
    assert p["device_energy_type"] == "device_measured"
    assert p["gpu_utilization_integral_s"] == pytest.approx(1.75)
    assert p["gpu_peak_memory_bytes"] == 12_000_000_000
    assert p["gpu_memory_residency_byte_s"] == pytest.approx(33_000_000_000.0)
    assert p["gpu_peak_power_w"] == pytest.approx(200.0)
    assert p["gpu_mean_power_w"] == pytest.approx(150.0)
    assert p["gpu_peak_temperature_c"] == pytest.approx(70.0)
    assert summary["execution"]["wall_time_s"] == pytest.approx(3.0)


def test_golden_event_accounting(tmp_path):
    cfg = RunConfig(run_id="golden", output_dir=tmp_path, telemetry_interval_s=1.0)
    s = integrate_run(cfg, FIX / "golden_events.jsonl", FIX / "golden_telemetry.jsonl")
    e = s["execution"]
    assert e["model_invocations_started"] == 3
    assert e["model_invocations_completed"] == 3
    assert e["trajectories_started"] == 2
    assert e["trajectories_completed"] == 2
    assert e["retries_started"] == 1
    assert e["retries_completed"] == 1
    assert e["tool_calls_started"] == 2
    assert e["tool_calls_completed"] == 2
    assert e["verifier_passes_started"] == 1
    assert e["verifier_passes_completed"] == 1
    assert e["candidates_created"] == 4
    assert e["candidates_selected"] == 1
    assert e["candidates_discarded"] == 3
    assert e["incomplete_span_count"] == 0


def test_gap_detection_uses_2_5_times_target_interval(tmp_path):
    events = tmp_path / "events.jsonl"
    telem = tmp_path / "telem.jsonl"
    events.write_text(
        '\n'.join([
            json.dumps({"event_type":"run_start","t_monotonic_s":0.0}),
            json.dumps({"event_type":"run_end","t_monotonic_s":1.0}),
        ]) + '\n', encoding="utf-8")
    rows = [
        {"collector":"nvidia_smi","device_id":"g","t_monotonic_s":0.0,"metrics":{"gpu.power_w":100.0}},
        {"collector":"nvidia_smi","device_id":"g","t_monotonic_s":0.7,"metrics":{"gpu.power_w":100.0}},
    ]
    telem.write_text('\n'.join(json.dumps(r) for r in rows)+'\n', encoding="utf-8")
    cfg = RunConfig(run_id="r", output_dir=tmp_path, telemetry_interval_s=0.25)
    s = integrate_run(cfg, events, telem)
    assert s["measurement"]["sample_gap_count"] == 1
    assert s["measurement"]["largest_gap_s"] == pytest.approx(0.7)
    assert s["measurement"]["telemetry_complete"] is False

def test_allocated_device_time_uses_declared_reservation(tmp_path):
    cfg = RunConfig(
        run_id="golden", output_dir=tmp_path, telemetry_interval_s=1.0,
        physical_boundary="accelerator-only", allocated_gpu_indices=(0, 1)
    )
    s = integrate_run(cfg, FIX / "golden_events.jsonl", FIX / "golden_telemetry.jsonl")
    assert s["physical"]["allocated_device_time_s"] == pytest.approx(6.0)

def test_event_account_detects_end_before_start(tmp_path):
    events = tmp_path / "events.jsonl"
    telem = tmp_path / "telem.jsonl"
    rows = [
        {"event_type":"run_start","t_monotonic_s":0.0},
        {"event_type":"tool_call_end","span_id":"x","t_monotonic_s":0.1},
        {"event_type":"tool_call_start","span_id":"x","t_monotonic_s":0.2},
        {"event_type":"run_end","t_monotonic_s":0.3},
    ]
    events.write_text('\n'.join(json.dumps(r) for r in rows)+'\n', encoding="utf-8")
    telem.write_text('', encoding="utf-8")
    cfg = RunConfig(run_id="r", output_dir=tmp_path)
    s = integrate_run(cfg, events, telem)
    assert s["execution"]["end_before_start_count"] == 1
