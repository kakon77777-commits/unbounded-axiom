from pathlib import Path
import pytest

from ipm_xa03.clock import FakeClock
from ipm_xa03.models import RunConfig


def test_fake_clock_advances_monotonically():
    clock = FakeClock(start_wall="2026-09-03T00:00:00+00:00")
    assert clock.monotonic() == 0.0
    clock.advance(1.25)
    assert clock.monotonic() == 1.25


def test_fake_clock_rejects_negative_advance():
    clock = FakeClock(start_wall="2026-09-03T00:00:00+00:00")
    with pytest.raises(ValueError):
        clock.advance(-0.1)


def test_run_config_rejects_sampling_interval_below_50ms(tmp_path: Path):
    with pytest.raises(ValueError):
        RunConfig(run_id="r", output_dir=tmp_path, telemetry_interval_s=0.01)


def test_run_config_rejects_sampling_interval_above_5s(tmp_path: Path):
    with pytest.raises(ValueError):
        RunConfig(run_id="r", output_dir=tmp_path, telemetry_interval_s=5.01)

def test_required_collectors_must_be_declared_collectors(tmp_path: Path):
    with pytest.raises(ValueError):
        RunConfig(run_id="r", output_dir=tmp_path, collectors=("system",), required_collectors=("nvidia_smi",))
