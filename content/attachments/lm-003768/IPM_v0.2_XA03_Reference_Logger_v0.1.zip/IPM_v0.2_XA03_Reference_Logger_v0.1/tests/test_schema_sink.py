from pathlib import Path
import json
import pytest

from ipm_xa03.schema import validate_summary
from ipm_xa03.sink import RunSink


def valid_summary(run_id="r1", state="COMPLETE"):
    return {
        "run": {"run_id": run_id, "state": state},
        "execution": {"wall_time_s": 1.0},
        "physical": {
            "device_energy_j": None,
            "device_energy_type": "unknown",
            "marginal_energy_j": None,
            "attributed_energy_j": None,
            "gpu_peak_memory_bytes": None,
        },
        "hidden_work": {"discarded_candidates": 0, "discarded_cost": None},
        "measurement": {"physical_boundary": "unknown"},
        "provenance": {},
    }


def test_validate_summary_accepts_unknown_null_metrics():
    assert validate_summary(valid_summary()) == []


def test_validate_summary_rejects_negative_duration():
    s = valid_summary()
    s["execution"]["wall_time_s"] = -1
    errors = validate_summary(s)
    assert any("wall_time_s" in e for e in errors)


def test_validate_summary_rejects_illegal_state():
    s = valid_summary()
    s["run"]["state"] = "MAGICAL"
    assert any("state" in e for e in validate_summary(s))


def test_validate_summary_rejects_mislabeled_device_energy():
    s = valid_summary()
    s["physical"]["device_energy_j"] = 12.0
    s["physical"]["device_energy_type"] = "marginal"
    errors = validate_summary(s)
    assert any("device_energy_type" in e for e in errors)


def test_sink_uses_partial_then_atomic_complete(tmp_path):
    sink = RunSink(tmp_path, "run-1")
    partial = sink.create_partial({"x": 1})
    assert partial.name == ".run-1.partial"
    assert partial.exists()
    assert (partial / "config.json").exists()
    final = sink.finalize_complete(valid_summary("run-1"))
    assert final == tmp_path / "run-1"
    assert final.exists()
    assert not partial.exists()
    assert (final / "COMPLETE").exists()
    assert not (final / "ABORTED").exists()
    assert json.loads((final / "summary.json").read_text()) ["run"]["state"] == "COMPLETE"


def test_sink_abort_has_only_aborted_marker(tmp_path):
    sink = RunSink(tmp_path, "run-2")
    sink.create_partial({})
    s = valid_summary("run-2", "ABORTED")
    final = sink.finalize_aborted(s)
    assert (final / "ABORTED").exists()
    assert not (final / "COMPLETE").exists()


def test_sink_refuses_existing_final_dir(tmp_path):
    (tmp_path / "run-3").mkdir()
    sink = RunSink(tmp_path, "run-3")
    with pytest.raises(FileExistsError):
        sink.create_partial({})

def test_validate_summary_rejects_completed_count_above_started():
    s = valid_summary()
    s["execution"].update({"model_invocations_started":1,"model_invocations_completed":2})
    assert any("model_invocations_completed" in e for e in validate_summary(s))
