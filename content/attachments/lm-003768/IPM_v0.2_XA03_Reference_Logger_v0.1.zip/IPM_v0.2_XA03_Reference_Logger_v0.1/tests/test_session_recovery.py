import json
import time
from pathlib import Path

import pytest

from ipm_xa03 import RunConfig, RunSession
from ipm_xa03.clock import SystemClock
from ipm_xa03.collectors.null import NullCollector
from ipm_xa03.events import EventLogger
from ipm_xa03.recovery import recover_partial_run
from ipm_xa03.sink import RunSink


def test_basic_session_completes_and_keeps_unknown_physical_metrics_null(tmp_path):
    cfg = RunConfig(run_id="basic", output_dir=tmp_path, telemetry_interval_s=0.05, collectors=("null",))
    with RunSession(cfg) as run:
        with run.model_invocation():
            with run.trajectory():
                time.sleep(0.06)
        c1 = run.candidate_created()
        run.candidate_selected(c1)
    final = tmp_path / "basic"
    assert (final / "COMPLETE").exists()
    summary = json.loads((final / "summary.json").read_text(encoding="utf-8"))
    assert summary["run"]["state"] == "COMPLETE"
    assert summary["execution"]["model_invocations_completed"] == 1
    assert summary["execution"]["trajectories_completed"] == 1
    assert summary["physical"]["device_energy_j"] is None
    assert summary["physical"]["gpu_peak_memory_bytes"] is None
    assert summary["measurement"]["cst_grade"] == "CST-D"
    assert summary["execution"]["telemetry_sample_batches"] >= 1
    assert summary["execution"]["telemetry_sampling_wall_time_s"] >= 0.0


def test_exception_aborts_run_and_propagates(tmp_path):
    cfg = RunConfig(run_id="abort", output_dir=tmp_path, telemetry_interval_s=0.05, collectors=("null",))
    with pytest.raises(RuntimeError, match="boom"):
        with RunSession(cfg) as run:
            with run.model_invocation():
                raise RuntimeError("boom")
    final = tmp_path / "abort"
    assert (final / "ABORTED").exists()
    assert not (final / "COMPLETE").exists()
    summary = json.loads((final / "summary.json").read_text(encoding="utf-8"))
    assert summary["run"]["state"] == "ABORTED"
    assert summary["execution"]["model_invocations_started"] == 1
    # Context-manager span may end with an error attribute during normal exception unwinding.
    assert summary["execution"]["model_invocations_completed"] == 1
    assert summary["execution"]["failure_count"] >= 1


def test_candidate_cannot_be_selected_and_discarded(tmp_path):
    cfg = RunConfig(run_id="cand", output_dir=tmp_path, collectors=("null",))
    with RunSession(cfg) as run:
        cid = run.candidate_created()
        run.candidate_selected(cid)
        with pytest.raises(ValueError):
            run.candidate_discarded(cid)


def test_recovery_preserves_unmatched_span(tmp_path):
    sink = RunSink(tmp_path, "stale")
    partial = sink.create_partial({
        "run_id": "stale",
        "telemetry_interval_s": 0.25,
        "collectors": ["null"],
        "physical_boundary": "unknown",
        "allocated_gpu_indices": []
    })
    clock = SystemClock()
    ev = EventLogger("stale", partial / "events.jsonl", clock)
    ev.emit("run_start")
    ev.start_span("model_invocation", span_id="mi-stale")
    ev.close()
    (partial / "telemetry.jsonl").write_text("", encoding="utf-8")

    final = recover_partial_run(partial)
    assert final == tmp_path / "stale"
    assert (final / "ABORTED").exists()
    summary = json.loads((final / "summary.json").read_text(encoding="utf-8"))
    assert summary["execution"]["model_invocations_started"] == 1
    assert summary["execution"]["model_invocations_completed"] == 0
    assert summary["execution"]["incomplete_span_count"] == 1
    rows = [json.loads(x) for x in (final / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    assert not any(r["event_type"] == "model_invocation_end" for r in rows)
    assert any(r["event_type"] == "recovery" for r in rows)

class BrokenRequiredCollector:
    name = "broken"
    required = True
    def start(self, run_context=None): pass
    def stop(self): pass
    def capabilities(self): return None
    def sample(self, run_id):
        raise RuntimeError("collector exploded")


def test_required_collector_failure_aborts(tmp_path):
    cfg = RunConfig(run_id="required-fail", output_dir=tmp_path, telemetry_interval_s=0.05)
    with pytest.raises(RuntimeError, match="required telemetry collector failed"):
        with RunSession(cfg, collectors=[BrokenRequiredCollector()]):
            time.sleep(0.08)
    final = tmp_path / "required-fail"
    assert (final / "ABORTED").exists()
    summary = json.loads((final / "summary.json").read_text(encoding="utf-8"))
    assert summary["run"]["state"] == "ABORTED"
    assert summary["execution"]["failure_count"] >= 1


class DegradedCollector:
    name = "degraded"
    required = False
    last_error = "simulated query failure"
    def start(self, run_context=None): pass
    def stop(self): pass
    def capabilities(self): return None
    def sample(self, run_id): return []


def test_nonrequired_collector_degradation_logs_failure_but_completes(tmp_path):
    cfg = RunConfig(run_id="degraded", output_dir=tmp_path, telemetry_interval_s=0.05)
    with RunSession(cfg, collectors=[DegradedCollector()]):
        time.sleep(0.06)
    summary = json.loads((tmp_path/"degraded"/"summary.json").read_text(encoding="utf-8"))
    assert summary["run"]["state"] == "COMPLETE"
    assert summary["execution"]["failure_count"] >= 1

class UnavailableRequiredCollector:
    name = "unavailable-required"
    required = True
    last_error = "device telemetry unavailable"
    def start(self, run_context=None): pass
    def stop(self): pass
    def capabilities(self): return None
    def sample(self, run_id): return []


def test_required_collector_last_error_aborts(tmp_path):
    cfg = RunConfig(run_id="required-unavailable", output_dir=tmp_path, telemetry_interval_s=0.05)
    with pytest.raises(RuntimeError, match="required telemetry collector failed"):
        with RunSession(cfg, collectors=[UnavailableRequiredCollector()]):
            time.sleep(0.06)
    assert (tmp_path / "required-unavailable" / "ABORTED").exists()
