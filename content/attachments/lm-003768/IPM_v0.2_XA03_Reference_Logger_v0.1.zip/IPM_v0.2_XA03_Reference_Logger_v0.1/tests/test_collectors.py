import builtins
import types
import pytest

from ipm_xa03.clock import FakeClock
from ipm_xa03.collectors.null import NullCollector
from ipm_xa03.collectors.system import SystemCollector
from ipm_xa03.collectors.nvidia_smi import NvidiaSmiCollector, parse_nvidia_csv_line


def test_null_collector_reports_no_physical_capabilities():
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    c = NullCollector(clock)
    caps = c.capabilities()
    assert caps.gpu_power is False
    assert caps.gpu_memory is False
    assert caps.cpu is False
    samples = c.sample("run-1")
    assert len(samples) == 1
    assert samples[0].metrics == {}
    assert samples[0].availability["physical"] is False


def test_system_collector_degrades_when_psutil_missing(monkeypatch):
    real_import = builtins.__import__
    def fake_import(name, *args, **kwargs):
        if name == "psutil":
            raise ImportError("simulated")
        return real_import(name, *args, **kwargs)
    monkeypatch.setattr(builtins, "__import__", fake_import)
    clock = FakeClock("2026-09-03T00:00:00+00:00")
    c = SystemCollector(clock)
    assert c.capabilities().cpu is False
    sample = c.sample("run-1")[0]
    assert sample.metrics == {}
    assert sample.availability["cpu"] is False


def test_parse_nvidia_csv_line_types_metrics():
    row = "GPU-abc, 0, NVIDIA GeForce RTX 3070, 84, 6144, 8192, 187.4, 71, 1815, 220"
    parsed = parse_nvidia_csv_line(row)
    assert parsed["gpu.uuid"] == "GPU-abc"
    assert parsed["gpu.index"] == 0
    assert parsed["gpu.name"] == "NVIDIA GeForce RTX 3070"
    assert parsed["gpu.utilization_fraction"] == pytest.approx(0.84)
    assert parsed["gpu.memory_used_bytes"] == 6144 * 1024 * 1024
    assert parsed["gpu.memory_total_bytes"] == 8192 * 1024 * 1024
    assert parsed["gpu.power_w"] == pytest.approx(187.4)
    assert parsed["gpu.temperature_c"] == pytest.approx(71.0)
    assert parsed["gpu.graphics_clock_hz"] == 1815 * 1_000_000
    assert parsed["gpu.power_limit_w"] == pytest.approx(220.0)


def test_parse_nvidia_csv_line_allows_na(monkeypatch):
    row = "GPU-x, 1, X, N/A, 100, 200, N/A, 65, N/A, N/A"
    parsed = parse_nvidia_csv_line(row)
    assert parsed["gpu.utilization_fraction"] is None
    assert parsed["gpu.power_w"] is None
    assert parsed["gpu.graphics_clock_hz"] is None
    assert parsed["gpu.power_limit_w"] is None
