import shutil
import pytest

from ipm_xa03.clock import SystemClock
from ipm_xa03.collectors.nvidia_smi import NvidiaSmiCollector
from ipm_xa03.collectors.system import SystemCollector


def test_nvidia_smi_optional_real_probe():
    if shutil.which("nvidia-smi") is None:
        pytest.skip("nvidia-smi not available")
    c = NvidiaSmiCollector(SystemClock())
    samples = c.sample("probe")
    assert len(samples) >= 1
    if samples[0].availability.get("gpu"):
        assert samples[0].metrics.get("gpu.uuid")
        util = samples[0].metrics.get("gpu.utilization_fraction")
        assert util is None or util >= 0.0


def test_system_collector_optional_real_probe():
    c = SystemCollector(SystemClock())
    if not c.capabilities().cpu:
        pytest.skip("psutil not available")
    samples = c.sample("probe")
    assert len(samples) == 1
    metrics = samples[0].metrics
    assert metrics["system.process_cpu_time_s"] >= 0.0
    assert metrics["system.process_rss_bytes"] >= 0
