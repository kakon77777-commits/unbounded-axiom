from pathlib import Path
import json
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ipm_xa03.integrator import integrate_run
from ipm_xa03.models import RunConfig

root = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as td:
    cfg = RunConfig(run_id="golden", output_dir=td, telemetry_interval_s=1.0, physical_boundary="accelerator-only")
    summary = integrate_run(cfg, root / "fixtures/golden_events.jsonl", root / "fixtures/golden_telemetry.jsonl")
    print(json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True))
