from pathlib import Path
import sys
import tempfile
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from ipm_xa03 import RunConfig, RunSession

with tempfile.TemporaryDirectory() as td:
    cfg = RunConfig(
        run_id="xa03-basic-example",
        output_dir=td,
        telemetry_interval_s=0.05,
        collectors=("null",),
    )
    with RunSession(cfg) as run:
        with run.model_invocation():
            with run.trajectory():
                time.sleep(0.06)
        cid = run.candidate_created()
        run.candidate_selected(cid)
    print(Path(td, "xa03-basic-example", "summary.json").read_text(encoding="utf-8"))
