# IPM v0.2 XA-03 — Telemetry & Run Logger Reference Implementation

**Artifact:** EML-IPM-XA-03  
**Version:** v0.1  
**Role:** Model-provider-agnostic physical execution evidence layer for IPM Experiment A.

XA-03 records one benchmark run as append-only events + telemetry, then deterministically derives a typed summary. It does **not** decide model quality, run A0–A5 policies, or infer semantic work.

## Public API

```python
from ipm_xa03 import RunConfig, RunSession

config = RunConfig(
    run_id="IPM-XA-example-MATH-001-A0-01",
    output_dir="runs",
    telemetry_interval_s=0.25,
    collectors=("system", "nvidia_smi"),
    required_collectors=(),
    physical_boundary="accelerator-only",
    allocated_gpu_indices=(0,),
)

with RunSession(config) as run:
    with run.model_invocation():
        with run.trajectory():
            answer = "..."
```

Tool and verifier spans:

```python
with run.tool_call(tool_type="compiler"):
    ...

with run.verifier(verifier_type="formal"):
    ...
```

Candidate accounting:

```python
cid = run.candidate_created()
run.candidate_discarded(cid)
```

## Run layout

```text
runs/<run_id>/
  config.json
  events.jsonl
  telemetry.jsonl
  summary.json
  validation.json
  COMPLETE      # or ABORTED
```

Execution occurs first in `runs/.<run_id>.partial/` and finalizes atomically.

## Collectors

- `NullCollector` — legal black-box/API mode; physical measurements stay unknown.
- `SystemCollector` — optional `psutil` CPU/RSS telemetry.
- `NvidiaSmiCollector` — external `nvidia-smi` GPU/VRAM/power/temperature/clock telemetry.

Unavailable data are `null`, not zero.

## Energy type safety

Measured GPU power is integrated as:

```text
device_energy_j
energy type = device_measured
```

XA-03 does **not** relabel this as marginal energy. `marginal_energy_j` remains null unless a separate matched-baseline experiment justifies it.

Forbidden implicit conversions include:

```text
tokens -> Joules
TDP -> measured Joules
price -> Joules
GPU-hours -> measured Joules
```

## Deterministic golden fixture

The bundled telemetry trace is:

```text
t=0s  power=100W  memory=10GB  util=0.5
t=1s  power=100W  memory=12GB  util=1.0
t=2s  power=200W  memory=12GB  util=0.5
t=3s  power=200W  memory=8GB   util=0.0
```

Expected:

- energy = **450 J**
- utilization integral = **1.75 utilization·s**
- peak memory = **12,000,000,000 bytes**
- memory residency = **33,000,000,000 byte·s**

## Tests

```bash
python -m pytest -q
```

`nvidia-smi` integration skips cleanly when NVIDIA telemetry is unavailable. `SystemCollector` skips/degrades cleanly if `psutil` is unavailable.

## Recovery

Use:

```python
from ipm_xa03.recovery import recover_partial_run
recover_partial_run("runs/.stale-run.partial")
```

Recovery marks the run `ABORTED`, preserves incomplete spans, and never invents missing normal end events.

## Scientific boundary

XA-03 directly supports operational execution counts, wall time, local telemetry, device-power integration, memory residency, and utilization integrals. It does not by itself establish full-node/facility energy, semantic work, task quality, or intelligence.
