# IPM v0.2 XA-04 — A0→A5 Model Runner & Scaffold Orchestrator

**Architecture:** Policy-Driven State Machine  
**Artifact:** EML-IPM-XA-04  
**Version:** v0.1

XA-04 runs the same `TrialExecutor` under immutable A0→A5 `ConditionPolicy` objects. It treats XA-02 and XA-03 as external canonical dependencies rather than vendoring modified copies.

## Dependency paths

Set or pass paths to extracted canonical artifacts:

```text
IPM_XA02_ROOT=/path/to/IPM_v0.2_XA02_TaskPack_v0.1
IPM_XA03_ROOT=/path/to/IPM_v0.2_XA03_Reference_Logger_v0.1
```

The XA-04 `TaskPack` reads only `tasks_public.json`. Benchmark-private `reference_private.json` remains evaluator-private.

## Public API

```python
from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor, ScriptedProvider

pack = TaskPack(xa02_root)
evaluator = EvaluatorBridge(xa02_root)
executor = TrialExecutor(pack, evaluator, xa03_root=xa03_root, output_dir="results")
provider = ScriptedProvider(['{"answer":169}'], model_id="example")
result = executor.execute("MATH-003", "A0", provider)
```

## Canonical conditions

- A0 — native single pass
- A1 — extended single trajectory
- A2 — 8-sample exact-majority
- A3 — 8 samples + typed verifier
- A4 — A3 + bounded tool interaction
- A5 — bounded PLAN→ACT→OBSERVE→VERIFY→REVISE loop

## Tool action envelope

```json
{"action":"tool","tool":"calculator","input":{"expression":"17*17-120"}}
```

Final envelope:

```json
{"action":"final","content":"{\"answer\":169}"}
```

A tool action under A0–A3 is a protocol violation.

## Physical trace

All provider generations, trajectories, retries, tools, verifiers, and candidate lifecycle events are recorded through XA-03 public spans. Final XA-02 benchmark evaluation happens only after the XA-03 run is finalized, so scoring cost is not counted as the tested system's execution cost.

## CLI

```bash
python -m ipm_xa04.cli policy A0
python -m ipm_xa04.cli aggregate trial-a0.json trial-a5.json
```

A deterministic A0 scripted run:

```bash
python -m ipm_xa04.cli scripted-run \
  --xa02-root "$IPM_XA02_ROOT" \
  --xa03-root "$IPM_XA03_ROOT" \
  --output-dir ./out \
  --task MATH-003 --condition A0 \
  --outputs-json '["{\"answer\":169}"]'
```

## Security boundaries

- XA-02 private references are never read by the task loader.
- XA-02 CODE execution remains disabled unless explicitly enabled in `EvaluatorBridge` and externally sandboxed.
- `LocalCommandTool` and `LocalCommandProvider` execute explicitly configured commands; the caller owns OS/container isolation.
- API secrets are read from environment only and are not embedded in generation records.
- XA-04 does not request or capture private chain-of-thought.

## Tests

```bash
IPM_XA02_ROOT=/path/to/xa02 \
IPM_XA03_ROOT=/path/to/xa03 \
python -m pytest -q
```
