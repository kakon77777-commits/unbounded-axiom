from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True)
class ConditionPolicy:
    name: str
    initial_samples: int
    generation_budget_multiplier: float
    max_model_invocations: int
    max_trajectories: int
    max_retries: int
    max_tool_calls: int
    max_verifier_passes: int
    allow_tools: bool
    allow_verifier: bool
    planner_enabled: bool
    memory_enabled: bool
    selection_mode: str

_POLICIES = {
    "A0": ConditionPolicy("A0",1,1.0,1,1,0,0,0,False,False,False,False,"only"),
    "A1": ConditionPolicy("A1",1,2.0,1,1,0,0,0,False,False,False,False,"only"),
    "A2": ConditionPolicy("A2",8,1.0,8,8,0,0,0,False,False,False,False,"exact_majority"),
    "A3": ConditionPolicy("A3",8,1.0,9,8,0,0,1,False,True,False,False,"verifier"),
    "A4": ConditionPolicy("A4",8,1.0,12,8,0,4,1,True,True,False,False,"verifier"),
    "A5": ConditionPolicy("A5",1,1.0,16,4,3,8,3,True,True,True,True,"iterative_verification"),
}

def canonical_policy(name: str) -> ConditionPolicy:
    try:
        return _POLICIES[name.upper()]
    except KeyError as exc:
        raise ValueError(f"unknown condition policy: {name}") from exc
