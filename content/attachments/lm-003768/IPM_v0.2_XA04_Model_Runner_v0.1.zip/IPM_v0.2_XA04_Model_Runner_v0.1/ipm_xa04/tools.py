from __future__ import annotations
import ast, math, operator, json, subprocess
from typing import Protocol, Sequence
from .models import ToolResult

class Tool(Protocol):
    name: str
    def execute(self, payload: dict) -> ToolResult: ...

_BIN = {ast.Add:operator.add, ast.Sub:operator.sub, ast.Mult:operator.mul, ast.Div:operator.truediv, ast.FloorDiv:operator.floordiv, ast.Mod:operator.mod, ast.Pow:operator.pow}
_UNARY = {ast.UAdd:operator.pos, ast.USub:operator.neg}

def _eval(node):
    if isinstance(node, ast.Expression): return _eval(node.body)
    if isinstance(node, ast.Constant) and type(node.value) in (int,float): return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _BIN:
        a,b=_eval(node.left),_eval(node.right)
        if isinstance(node.op,ast.Pow) and (abs(b)>100 or abs(a)>10**12): raise ValueError("operation not allowed")
        return _BIN[type(node.op)](a,b)
    if isinstance(node, ast.UnaryOp) and type(node.op) in _UNARY: return _UNARY[type(node.op)](_eval(node.operand))
    raise ValueError("expression element not allowed")

class CalculatorTool:
    name="calculator"
    def execute(self, payload: dict) -> ToolResult:
        expr=str(payload.get("expression", ""))
        try:
            tree=ast.parse(expr,mode="eval")
            if sum(1 for _ in ast.walk(tree))>64: raise ValueError("expression not allowed")
            val=_eval(tree)
            if isinstance(val,float) and not math.isfinite(val): raise ValueError("non-finite result not allowed")
            return ToolResult(True,val,None)
        except Exception as exc:
            return ToolResult(False,None,str(exc))

class LocalCommandTool:
    def __init__(self, name: str, command: Sequence[str], *, timeout_s: float=30.0) -> None:
        self.name=name; self.command=tuple(command); self.timeout_s=timeout_s
    def execute(self, payload: dict) -> ToolResult:
        try:
            cp=subprocess.run(self.command,input=json.dumps(payload),text=True,capture_output=True,timeout=self.timeout_s)
            if cp.returncode != 0: return ToolResult(False,None,cp.stderr.strip() or f"rc={cp.returncode}")
            return ToolResult(True,cp.stdout.strip(),None)
        except Exception as exc:
            return ToolResult(False,None,str(exc))

class ToolRegistry:
    def __init__(self, tools=()) -> None:
        self._tools={t.name:t for t in tools}
    def execute(self, name: str, payload: dict) -> ToolResult:
        if name not in self._tools: raise KeyError(f"unknown tool: {name}")
        return self._tools[name].execute(payload)
    def names(self) -> list[str]: return sorted(self._tools)
