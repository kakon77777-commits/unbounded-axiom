from __future__ import annotations
import argparse, json
from dataclasses import asdict
from pathlib import Path
from .aggregator import aggregate_trials
from .dependencies import TaskPack
from .evaluator_bridge import EvaluatorBridge
from .executor import TrialExecutor
from .policies import canonical_policy
from .provider import ScriptedProvider


def _parser():
    p=argparse.ArgumentParser(prog="ipm-xa04")
    sub=p.add_subparsers(dest="cmd",required=True)
    pp=sub.add_parser("policy"); pp.add_argument("condition")
    pa=sub.add_parser("aggregate"); pa.add_argument("records",nargs="+")
    pr=sub.add_parser("scripted-run")
    pr.add_argument("--xa02-root",required=True); pr.add_argument("--xa03-root",required=True); pr.add_argument("--output-dir",required=True)
    pr.add_argument("--task",required=True); pr.add_argument("--condition",required=True); pr.add_argument("--model-id",default="scripted-model"); pr.add_argument("--replicate",type=int,default=1); pr.add_argument("--outputs-json",required=True)
    return p


def main(argv=None):
    a=_parser().parse_args(argv)
    if a.cmd=="policy":
        print(json.dumps(asdict(canonical_policy(a.condition)),ensure_ascii=False,sort_keys=True)); return 0
    if a.cmd=="aggregate":
        rows=[json.loads(Path(x).read_text(encoding="utf-8")) for x in a.records]
        print(json.dumps(aggregate_trials(rows),ensure_ascii=False,sort_keys=True)); return 0
    if a.cmd=="scripted-run":
        outputs=json.loads(a.outputs_json)
        if not isinstance(outputs,list): raise SystemExit("--outputs-json must be a JSON array")
        pack=TaskPack(a.xa02_root); ev=EvaluatorBridge(a.xa02_root); ex=TrialExecutor(pack,ev,xa03_root=a.xa03_root,output_dir=a.output_dir)
        provider=ScriptedProvider(outputs,model_id=a.model_id)
        result=ex.execute(a.task,a.condition,provider,replicate=a.replicate)
        print(json.dumps(asdict(result),ensure_ascii=False,sort_keys=True)); return 0
    return 2

if __name__=="__main__": raise SystemExit(main())
