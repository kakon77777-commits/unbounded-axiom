from __future__ import annotations
from dataclasses import dataclass
from .policies import ConditionPolicy

class BudgetExhausted(RuntimeError):
    def __init__(self, resource: str, limit: int) -> None:
        self.resource = resource
        self.limit = limit
        super().__init__(f"budget exhausted for {resource}: limit={limit}")

@dataclass(frozen=True)
class BudgetLimits:
    max_model_invocations: int
    max_trajectories: int
    max_retries: int
    max_tool_calls: int
    max_verifier_passes: int

class BudgetLedger:
    def __init__(self, policy: ConditionPolicy) -> None:
        self.limits = BudgetLimits(
            policy.max_model_invocations,
            policy.max_trajectories,
            policy.max_retries,
            policy.max_tool_calls,
            policy.max_verifier_passes,
        )
        self._counts = {"model_invocations":0,"trajectories":0,"retries":0,"tool_calls":0,"verifier_passes":0}

    def _consume(self, key: str, limit: int) -> None:
        if self._counts[key] >= limit:
            raise BudgetExhausted(key, limit)
        self._counts[key] += 1

    def consume_model_invocation(self): self._consume("model_invocations", self.limits.max_model_invocations)
    def consume_trajectory(self): self._consume("trajectories", self.limits.max_trajectories)
    def consume_retry(self): self._consume("retries", self.limits.max_retries)
    def consume_tool_call(self): self._consume("tool_calls", self.limits.max_tool_calls)
    def consume_verifier_pass(self): self._consume("verifier_passes", self.limits.max_verifier_passes)
    def snapshot(self) -> dict[str,int]: return dict(self._counts)
