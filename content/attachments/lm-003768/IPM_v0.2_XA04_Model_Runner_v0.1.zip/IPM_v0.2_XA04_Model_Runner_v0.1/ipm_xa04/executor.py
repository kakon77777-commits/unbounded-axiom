from __future__ import annotations
from collections import Counter
from dataclasses import asdict
import hashlib, json, re
from pathlib import Path
from typing import Any

from .budget import BudgetLedger, BudgetExhausted
from .dependencies import TaskPack, load_xa03
from .evaluator_bridge import EvaluatorBridge, EvaluatorFailure
from .models import Candidate, GenerationRequest, GenerationResult, TrialResult, VerificationResult
from .policies import canonical_policy, ConditionPolicy
from .tools import ToolRegistry
from .verifier import SameModelVerifier, VerifierFailure

class PolicyViolation(RuntimeError): pass
class ProviderFailure(RuntimeError): pass
class ToolFailure(RuntimeError): pass
class ProtocolFailure(RuntimeError): pass


def _safe_id(s: str) -> str:
    s=re.sub(r"[^A-Za-z0-9_.-]+","_",s)
    return s[:80] or "model"


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _parse_action(text: str) -> tuple[str, Any]:
    raw=text.strip()
    try:
        d=json.loads(raw)
    except Exception:
        return "final", text
    if isinstance(d,dict) and d.get("action")=="tool":
        return "tool", d
    if isinstance(d,dict) and d.get("action")=="final":
        return "final", str(d.get("content",""))
    return "final", text


class TrialExecutor:
    def __init__(self, taskpack: TaskPack, evaluator: EvaluatorBridge, *, xa03_root: str | Path, output_dir: str | Path) -> None:
        self.taskpack=taskpack; self.evaluator=evaluator; self.xa03_root=Path(xa03_root); self.output_dir=Path(output_dir)
        self.runs_dir=self.output_dir/"xa03_runs"; self.results_dir=self.output_dir/"trial_results"
        self.runs_dir.mkdir(parents=True,exist_ok=True); self.results_dir.mkdir(parents=True,exist_ok=True)
        self.RunConfig,self.RunSession=load_xa03(self.xa03_root)

    def _invoke(self, run, ledger: BudgetLedger, provider, task: dict, policy: ConditionPolicy, prompt: str, *, role: str) -> GenerationResult:
        ledger.consume_model_invocation()
        req=GenerationRequest(prompt=prompt,role=role,condition=policy.name,task_id=task["id"],generation_budget_multiplier=policy.generation_budget_multiplier,metadata={"family":task.get("family")})
        try:
            with run.model_invocation(role=role, provider_id=getattr(provider,"provider_id","unknown"), model_id=getattr(provider,"model_id","unknown")):
                return provider.generate(req)
        except (BudgetExhausted, PolicyViolation):
            raise
        except Exception as exc:
            raise ProviderFailure(str(exc)) from exc

    def _trajectory(self, run, ledger: BudgetLedger, provider, task: dict, policy: ConditionPolicy, tools: ToolRegistry, *, trajectory_index: int, memory: list[str] | None=None) -> str:
        ledger.consume_trajectory()
        base=task.get("prompt","")
        notes=list(memory or [])
        with run.trajectory(condition=policy.name, trajectory_index=trajectory_index):
            while True:
                prompt=base
                if notes:
                    prompt += "\n\nExternal trial-local observations:\n" + "\n".join(notes)
                res=self._invoke(run,ledger,provider,task,policy,prompt,role="generator")
                kind,payload=_parse_action(res.text)
                if kind=="final":
                    return payload
                if not policy.allow_tools:
                    raise PolicyViolation(f"{policy.name} does not allow tool actions")
                tool_name=str(payload.get("tool","")); tool_input=payload.get("input",{})
                if not isinstance(tool_input,dict): raise ProtocolFailure("tool input must be an object")
                ledger.consume_tool_call()
                try:
                    with run.tool_call(tool_type=tool_name):
                        tr=tools.execute(tool_name,tool_input)
                except KeyError as exc:
                    raise ToolFailure(str(exc)) from exc
                if not tr.ok:
                    raise ToolFailure(tr.error or f"tool failed: {tool_name}")
                observation=json.dumps(tr.output,ensure_ascii=False) if not isinstance(tr.output,str) else tr.output
                notes.append(f"Tool `{tool_name}` observation: {observation}")

    def _candidate(self, run, text: str, idx: int) -> Candidate:
        cid=run.candidate_created(trajectory_index=idx)
        return Candidate(cid,text,idx)

    def _majority(self, candidates: list[Candidate]) -> Candidate:
        counts=Counter(c.text.strip() for c in candidates)
        best=max(counts.values())
        for c in candidates:
            if counts[c.text.strip()]==best: return c
        raise AssertionError

    def _invoke_verifier_model(self, run, ledger, provider, task, policy, prompt):
        return self._invoke(run,ledger,provider,task,policy,prompt,role="verifier")

    def _verify(self, run, ledger, provider, task, policy, verifier, candidates: list[Candidate]) -> VerificationResult:
        if verifier is None: raise ProtocolFailure(f"{policy.name} requires a verifier")
        ledger.consume_verifier_pass()
        with run.verifier(verifier_type=getattr(verifier,"verifier_type","unknown")):
            inv=lambda prompt:self._invoke_verifier_model(run,ledger,provider,task,policy,prompt)
            try:
                vr=verifier.select(task,candidates,invoke_model=inv)
            except VerifierFailure: raise
            except Exception as exc: raise VerifierFailure(str(exc)) from exc
        if vr.selected_candidate_id not in {c.candidate_id for c in candidates}:
            raise VerifierFailure(f"unknown candidate selected: {vr.selected_candidate_id}")
        return vr

    def _mark_selection(self, run, candidates: list[Candidate], selected_id: str) -> Candidate:
        selected=None
        for c in candidates:
            if c.candidate_id==selected_id:
                run.candidate_selected(c.candidate_id); selected=c
            else:
                run.candidate_discarded(c.candidate_id)
        if selected is None: raise ProtocolFailure("selected candidate missing")
        return selected

    def _summary(self, trial_id: str) -> tuple[Path, dict, str]:
        run_dir=self.runs_dir/trial_id; sp=run_dir/"summary.json"
        summary=json.loads(sp.read_text(encoding="utf-8"))
        return run_dir,summary,_sha256(sp)

    def _persist(self, result: TrialResult) -> None:
        d=asdict(result)
        p=self.results_dir/f"{result.trial_id}.json"
        p.write_text(json.dumps(d,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

    def execute(self, task_id: str, condition: str, provider, *, replicate: int=1, verifier=None, tools: ToolRegistry | None=None, collectors: tuple[str,...]=("null",), physical_boundary: str="unknown", skip_evaluation: bool=False) -> TrialResult:
        task=dict(self.taskpack.get(task_id)); policy=canonical_policy(condition); tools=tools or ToolRegistry([]); ledger=BudgetLedger(policy)
        model_id=getattr(provider,"model_id","unknown"); provider_id=getattr(provider,"provider_id","unknown")
        trial_id=f"IPM-XA-{_safe_id(model_id)}-{task_id}-{policy.name}-{replicate:02d}"
        cfg=self.RunConfig(run_id=trial_id,output_dir=self.runs_dir,collectors=collectors,physical_boundary=physical_boundary)
        selected: Candidate | None=None; failure=None
        try:
            with self.RunSession(cfg) as run:
                if policy.planner_enabled:
                    plan_res=self._invoke(run,ledger,provider,task,policy,"Create a concise external action plan for this task. Do not provide hidden chain-of-thought.\n\n"+task.get("prompt",""),role="planner")
                    memory=["External plan: "+plan_res.text] if policy.memory_enabled else []
                else:
                    memory=[]

                if policy.selection_mode=="iterative_verification":
                    attempt=0
                    retrying=False
                    while True:
                        if retrying:
                            ledger.consume_retry()
                            retry_cm=run.retry(retry_index=attempt)
                        else:
                            from contextlib import nullcontext
                            retry_cm=nullcontext()
                        with retry_cm:
                            text=self._trajectory(run,ledger,provider,task,policy,tools,trajectory_index=attempt,memory=memory)
                            cand=self._candidate(run,text,attempt)
                            vr=self._verify(run,ledger,provider,task,policy,verifier,[cand]) if policy.allow_verifier else VerificationResult(cand.candidate_id,True,"")
                        if vr.accepted:
                            run.candidate_selected(cand.candidate_id); selected=cand; break
                        if ledger.snapshot()["retries"] >= policy.max_retries:
                            run.candidate_selected(cand.candidate_id); selected=cand; break
                        run.candidate_discarded(cand.candidate_id)
                        if policy.memory_enabled and vr.feedback:
                            memory.append("Verifier feedback: "+vr.feedback)
                        attempt += 1
                        retrying=True
                else:
                    candidates=[]
                    for idx in range(policy.initial_samples):
                        text=self._trajectory(run,ledger,provider,task,policy,tools,trajectory_index=idx,memory=None)
                        candidates.append(self._candidate(run,text,idx))
                    if policy.selection_mode=="only":
                        selected=candidates[0]; run.candidate_selected(selected.candidate_id)
                    elif policy.selection_mode=="exact_majority":
                        selected=self._majority(candidates); self._mark_selection(run,candidates,selected.candidate_id)
                    elif policy.selection_mode=="verifier":
                        vr=self._verify(run,ledger,provider,task,policy,verifier,candidates)
                        selected=self._mark_selection(run,candidates,vr.selected_candidate_id)
                    else:
                        raise ProtocolFailure(f"unsupported selection mode: {policy.selection_mode}")
        except Exception as exc:
            failure={"type":type(exc).__name__,"message":str(exc)}
            run_dir,summary,sha=self._summary(trial_id)
            result=TrialResult(trial_id,task_id,policy.name,replicate,provider_id,model_id,None,None,None,str(run_dir),sha,summary,failure)
            self._persist(result); return result

        run_dir,summary,sha=self._summary(trial_id)
        quality=None
        if not skip_evaluation and selected is not None:
            try: quality=self.evaluator.evaluate(task_id,selected.text)
            except Exception as exc:
                failure={"type":type(exc).__name__,"message":str(exc)}
        result=TrialResult(trial_id,task_id,policy.name,replicate,provider_id,model_id,selected.candidate_id if selected else None,selected.text if selected else None,quality,str(run_dir),sha,summary,failure)
        self._persist(result); return result
