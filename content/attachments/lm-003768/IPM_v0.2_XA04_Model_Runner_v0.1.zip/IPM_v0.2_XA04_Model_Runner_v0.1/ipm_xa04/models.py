from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

@dataclass(frozen=True)
class GenerationRequest:
    prompt: str
    role: str
    condition: str
    task_id: str
    generation_budget_multiplier: float = 1.0
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class GenerationResult:
    text: str
    request_id: str | None = None
    usage: dict[str, Any] | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

@dataclass(frozen=True)
class Candidate:
    candidate_id: str
    text: str
    trajectory_index: int

@dataclass(frozen=True)
class QualityRecord:
    task_id: str
    hard_gate: bool
    scalar_value: float | None
    vector: dict[str, Any]
    details: dict[str, Any]
    failure_class: str

@dataclass(frozen=True)
class VerificationResult:
    selected_candidate_id: str
    accepted: bool = True
    feedback: str = ""
    score: float | None = None

@dataclass(frozen=True)
class ToolResult:
    ok: bool
    output: Any = None
    error: str | None = None

@dataclass(frozen=True)
class TrialResult:
    trial_id: str
    task_id: str
    condition: str
    replicate: int
    provider_id: str
    model_id: str
    selected_candidate_id: str | None
    candidate_text: str | None
    quality: QualityRecord | None
    xa03_run_dir: str
    xa03_summary_sha256: str | None
    xa03_summary: dict[str, Any] | None
    failure: dict[str, Any] | None = None
