from __future__ import annotations
import json
from typing import Protocol, Callable, Sequence
from .models import Candidate, GenerationResult, VerificationResult

class VerifierFailure(RuntimeError): pass

class Verifier(Protocol):
    verifier_type: str
    def select(self, task: dict, candidates: Sequence[Candidate], invoke_model=None) -> VerificationResult: ...

class ScriptedVerifier:
    verifier_type="scripted"
    def __init__(self, results: Sequence[VerificationResult]): self._results=list(results); self._i=0
    def select(self, task: dict, candidates: Sequence[Candidate], invoke_model=None) -> VerificationResult:
        if self._i>=len(self._results): raise VerifierFailure("scripted verifier exhausted")
        r=self._results[self._i]; self._i+=1
        ids={c.candidate_id for c in candidates}
        if r.selected_candidate_id not in ids: raise VerifierFailure(f"unknown candidate selected: {r.selected_candidate_id}")
        return r

class SameModelVerifier:
    verifier_type="same_model"
    def select(self, task: dict, candidates: Sequence[Candidate], invoke_model=None) -> VerificationResult:
        if invoke_model is None: raise VerifierFailure("same-model verifier requires invoke_model")
        lines=["Select the best candidate for the task. Return only JSON with selected_candidate_id, accepted, feedback.", f"Task: {task.get('prompt','')}"]
        for c in candidates: lines.append(f"[{c.candidate_id}] {c.text}")
        res=invoke_model("\n".join(lines))
        try:
            d=json.loads(res.text.strip())
            cid=d["selected_candidate_id"]
            ids={c.candidate_id for c in candidates}
            if cid not in ids: raise VerifierFailure(f"unknown candidate selected: {cid}")
            return VerificationResult(cid,bool(d.get("accepted",True)),str(d.get("feedback","")),d.get("score"))
        except VerifierFailure: raise
        except Exception as exc: raise VerifierFailure(f"invalid verifier output: {exc}") from exc
