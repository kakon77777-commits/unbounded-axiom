from __future__ import annotations
import json, os, subprocess
from typing import Protocol, Sequence
from urllib.request import Request, urlopen
from .models import GenerationRequest, GenerationResult

class ProviderAdapter(Protocol):
    provider_id: str
    model_id: str
    def generate(self, request: GenerationRequest) -> GenerationResult: ...

class ScriptedProvider:
    def __init__(self, outputs: Sequence[str | GenerationResult], *, provider_id: str="scripted", model_id: str="scripted-model") -> None:
        self.provider_id=provider_id; self.model_id=model_id
        self._outputs=list(outputs); self.requests: list[GenerationRequest]=[]; self._index=0
    def generate(self, request: GenerationRequest) -> GenerationResult:
        self.requests.append(request)
        if self._index >= len(self._outputs):
            raise RuntimeError("scripted provider exhausted")
        out=self._outputs[self._index]; self._index+=1
        return out if isinstance(out, GenerationResult) else GenerationResult(str(out), request_id=f"scripted-{self._index:04d}")

class LocalCommandProvider:
    def __init__(self, command: Sequence[str], *, model_id: str, provider_id: str="local_command", timeout_s: float=60.0) -> None:
        self.command=tuple(command); self.model_id=model_id; self.provider_id=provider_id; self.timeout_s=timeout_s
    def generate(self, request: GenerationRequest) -> GenerationResult:
        cp=subprocess.run(self.command,input=request.prompt,text=True,capture_output=True,timeout=self.timeout_s)
        if cp.returncode != 0:
            raise RuntimeError(f"local provider failed rc={cp.returncode}: {cp.stderr.strip()}")
        return GenerationResult(cp.stdout)

class OpenAICompatibleProvider:
    def __init__(self, *, base_url: str, model_id: str, api_key_env: str, provider_id: str="openai_compatible", timeout_s: float=60.0) -> None:
        self.base_url=base_url.rstrip("/"); self.model_id=model_id; self.api_key_env=api_key_env; self.provider_id=provider_id; self.timeout_s=timeout_s
    def generate(self, request: GenerationRequest) -> GenerationResult:
        key=os.environ.get(self.api_key_env)
        if not key:
            raise RuntimeError(f"missing API key environment variable: {self.api_key_env}")
        payload={"model":self.model_id,"messages":[{"role":"user","content":request.prompt}]}
        body=json.dumps(payload).encode("utf-8")
        req=Request(self.base_url+"/v1/chat/completions",data=body,headers={"Content-Type":"application/json","Authorization":f"Bearer {key}"},method="POST")
        with urlopen(req,timeout=self.timeout_s) as resp:
            data=json.loads(resp.read().decode("utf-8"))
        try:
            text=data["choices"][0]["message"]["content"]
        except Exception as exc:
            raise RuntimeError("invalid OpenAI-compatible response") from exc
        return GenerationResult(text=text, request_id=data.get("id"), usage=data.get("usage"))
