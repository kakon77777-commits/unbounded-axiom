from __future__ import annotations
from dataclasses import asdict, is_dataclass
from statistics import mean, median

_ORDER=["A0","A1","A2","A3","A4","A5"]

def _dict(x):
    if is_dataclass(x): return asdict(x)
    return x

def _avg(vals):
    vals=[v for v in vals if v is not None]
    return mean(vals) if vals else None

def aggregate_trials(records):
    rows=[_dict(r) for r in records]
    out={"conditions":{},"ssr":None,"sdr":None,"scm":{"wall_time_s":None,"device_energy_j":None,"allocated_device_time_s":None},"marginal_yield":{}}
    for cond in _ORDER:
        rs=[r for r in rows if r.get("condition")==cond]
        if not rs: continue
        qs=[]; hard=[]; walls=[]; energies=[]; devtimes=[]
        for r in rs:
            q=r.get("quality")
            if is_dataclass(q): q=asdict(q)
            if q is not None:
                qs.append(q.get("scalar_value")); hard.append(bool(q.get("hard_gate")))
            s=r.get("xa03_summary") or {}
            walls.append((s.get("execution") or {}).get("wall_time_s"))
            p=s.get("physical") or {}
            energies.append(p.get("device_energy_j")); devtimes.append(p.get("allocated_device_time_s"))
        qvals=[q for q in qs if q is not None]
        out["conditions"][cond]={
            "n":len(rs),"quality_n":len(qvals),"quality_mean":_avg(qvals),"quality_median":median(qvals) if qvals else None,
            "success_rate":mean(hard) if hard else None,"wall_time_mean":_avg(walls),"device_energy_mean":_avg(energies),"allocated_device_time_mean":_avg(devtimes)
        }
    a0=out["conditions"].get("A0"); a5=out["conditions"].get("A5")
    if a0 and a5 and a0["quality_mean"] is not None and a5["quality_mean"] not in (None,0):
        out["ssr"]=a0["quality_mean"]/a5["quality_mean"]; out["sdr"]=1-out["ssr"]
    pairs=[("wall_time_s","wall_time_mean"),("device_energy_j","device_energy_mean"),("allocated_device_time_s","allocated_device_time_mean")]
    if a0 and a5:
        for k,field in pairs:
            x,y=a0.get(field),a5.get(field)
            if x is not None and y is not None and x>0: out["scm"][k]=y/x
    for x,y in zip(_ORDER,_ORDER[1:]):
        a=out["conditions"].get(x); b=out["conditions"].get(y)
        if not a or not b: continue
        q0,q1=a.get("quality_mean"),b.get("quality_mean")
        d={}
        for k,field in pairs:
            c0,c1=a.get(field),b.get(field)
            if None in (q0,q1,c0,c1) or c1<=c0: d[k]=None
            else: d[k]=(q1-q0)/(c1-c0)
        out["marginal_yield"][f"{x}->{y}"]=d
    return out
