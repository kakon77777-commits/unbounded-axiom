from __future__ import annotations
import json
from pathlib import Path

class TaskPack:
    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        public = self.root / "tasks_public.json"
        data = json.loads(public.read_text(encoding="utf-8"))
        self._tasks = {t["id"]: t for t in data.get("tasks", [])}

    def get(self, task_id: str) -> dict:
        try:
            return self._tasks[task_id]
        except KeyError as exc:
            raise KeyError(f"unknown task: {task_id}") from exc

    def task_ids(self) -> list[str]:
        return sorted(self._tasks)

def load_xa03(xa03_root: str | Path):
    import importlib, sys
    root = str(Path(xa03_root))
    if root not in sys.path:
        sys.path.insert(0, root)
    mod = importlib.import_module("ipm_xa03")
    return mod.RunConfig, mod.RunSession
