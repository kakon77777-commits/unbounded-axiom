from __future__ import annotations
import json, os, subprocess, sys, tempfile
from pathlib import Path
from .models import QualityRecord

class EvaluatorFailure(RuntimeError):
    pass

class EvaluatorBridge:
    def __init__(self, xa02_root: str | Path, *, allow_code_execution: bool=False, timeout_s: float=20.0) -> None:
        self.root=Path(xa02_root); self.script=self.root/"evaluate.py"; self.allow_code_execution=allow_code_execution; self.timeout_s=timeout_s
        if not self.script.exists(): raise FileNotFoundError(self.script)

    def evaluate(self, task_id: str, candidate_text: str) -> QualityRecord:
        suffix=".py" if task_id.startswith("CODE-") else ".txt"
        with tempfile.NamedTemporaryFile("w",encoding="utf-8",suffix=suffix,delete=False) as fh:
            fh.write(candidate_text); path=Path(fh.name)
        env=os.environ.copy()
        if self.allow_code_execution: env["IPM_ALLOW_CODE_EXEC"]="1"
        else: env.pop("IPM_ALLOW_CODE_EXEC",None)
        try:
            cp=subprocess.run([sys.executable,str(self.script),task_id,str(path)],text=True,capture_output=True,timeout=self.timeout_s,env=env)
            if cp.returncode != 0: raise EvaluatorFailure(cp.stderr.strip() or f"evaluator rc={cp.returncode}")
            data=json.loads(cp.stdout)
            return QualityRecord(task_id=data["task_id"],hard_gate=bool(data["hard_gate"]),scalar_value=data.get("scalar_value"),vector=data.get("vector",{}),details=data.get("details",{}),failure_class=data.get("failure_class","none"))
        except EvaluatorFailure:
            raise
        except Exception as exc:
            raise EvaluatorFailure(str(exc)) from exc
        finally:
            try:path.unlink()
            except FileNotFoundError:pass
