from __future__ import annotations
import os, json, tempfile
from pathlib import Path
from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor, ScriptedProvider

xa02=Path(os.environ["IPM_XA02_ROOT"]); xa03=Path(os.environ["IPM_XA03_ROOT"])
out=Path(os.environ.get("IPM_XA04_OUT", tempfile.mkdtemp(prefix="ipm-xa04-example-")))
ex=TrialExecutor(TaskPack(xa02),EvaluatorBridge(xa02),xa03_root=xa03,output_dir=out)
r=ex.execute("MATH-003","A0",ScriptedProvider(['{"answer":169}'],model_id="example"))
print(json.dumps({"trial_id":r.trial_id,"quality":r.quality.scalar_value,"run_state":r.xa03_summary["run"]["state"]},sort_keys=True))
