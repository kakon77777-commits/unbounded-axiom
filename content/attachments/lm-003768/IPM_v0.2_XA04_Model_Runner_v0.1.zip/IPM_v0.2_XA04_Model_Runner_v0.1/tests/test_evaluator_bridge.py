import json
import os
from pathlib import Path

import pytest

from ipm_xa04.evaluator_bridge import EvaluatorBridge
from ipm_xa04.models import Candidate, GenerationResult, VerificationResult
from ipm_xa04.verifier import ScriptedVerifier, SameModelVerifier, VerifierFailure


def xa02_root():
    p = os.environ.get("IPM_XA02_ROOT")
    if not p:
        pytest.skip("IPM_XA02_ROOT not configured")
    return Path(p)


def test_xa02_math_evaluator_bridge_returns_perfect_score_for_known_correct_candidate():
    bridge = EvaluatorBridge(xa02_root())
    q = bridge.evaluate("MATH-003", '{"answer":169}')
    assert q.task_id == "MATH-003"
    assert q.hard_gate is True
    assert q.scalar_value == 1.0
    assert q.failure_class == "none"


def test_evaluator_bridge_does_not_enable_code_execution_by_default():
    bridge = EvaluatorBridge(xa02_root())
    q = bridge.evaluate("CODE-001", "def normalize_whitespace(s): return 'x'")
    assert q.hard_gate is False
    assert q.scalar_value == 0.0
    assert q.vector.get("execution_allowed") == 0


def candidates():
    return [
        Candidate("c1", "wrong", 0),
        Candidate("c2", "right", 1),
    ]


def test_scripted_verifier_selects_known_candidate_and_rejects_unknown():
    v = ScriptedVerifier([VerificationResult("c2", accepted=True, feedback="ok")])
    r = v.select({"id":"T"}, candidates())
    assert r.selected_candidate_id == "c2"

    bad = ScriptedVerifier([VerificationResult("missing")])
    with pytest.raises(VerifierFailure):
        bad.select({"id":"T"}, candidates())


def test_same_model_verifier_parses_selection_json_and_rejects_unknown_id():
    seen=[]
    def invoke(prompt):
        seen.append(prompt)
        return GenerationResult('{"selected_candidate_id":"c2","accepted":true,"feedback":"best"}')
    v = SameModelVerifier()
    r = v.select({"id":"T","prompt":"task"}, candidates(), invoke_model=invoke)
    assert r.selected_candidate_id == "c2"
    assert r.accepted is True
    assert "c1" in seen[0] and "c2" in seen[0]

    def bad_invoke(prompt):
        return GenerationResult('{"selected_candidate_id":"x","accepted":true}')
    with pytest.raises(VerifierFailure):
        v.select({"id":"T"}, candidates(), invoke_model=bad_invoke)
