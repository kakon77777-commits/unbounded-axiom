import pytest
from ipm_xa04.aggregator import aggregate_trials


def rec(cond,q,wall,energy=None,device_time=None,success=True):
    return {
        "condition":cond,
        "quality":{"scalar_value":q,"hard_gate":success} if q is not None else None,
        "xa03_summary":{
            "execution":{"wall_time_s":wall},
            "physical":{"device_energy_j":energy,"allocated_device_time_s":device_time}
        }
    }


def test_aggregator_computes_condition_means_ssr_sdr_scm_and_marginal_yield():
    rows=[
        rec("A0",0.5,2.0,10.0,2.0), rec("A0",0.7,2.0,14.0,2.0),
        rec("A1",0.7,3.0,15.0,3.0),
        rec("A2",0.8,4.0,16.0,4.0),
        rec("A3",0.9,5.0,18.0,5.0),
        rec("A4",0.95,7.0,21.0,7.0),
        rec("A5",1.0,8.0,24.0,8.0),
    ]
    a=aggregate_trials(rows)
    assert a["conditions"]["A0"]["quality_mean"] == pytest.approx(0.6)
    assert a["conditions"]["A0"]["n"] == 2
    assert a["ssr"] == pytest.approx(0.6)
    assert a["sdr"] == pytest.approx(0.4)
    assert a["scm"]["wall_time_s"] == pytest.approx(4.0)
    assert a["scm"]["device_energy_j"] == pytest.approx(2.0)
    # A0 -> A1: delta Q=.1, delta wall=1
    assert a["marginal_yield"]["A0->A1"]["wall_time_s"] == pytest.approx(0.1)


def test_unknown_energy_stays_null_and_is_not_zero_filled():
    rows=[rec("A0",0.5,1.0,None), rec("A5",1.0,2.0,None)]
    a=aggregate_trials(rows)
    assert a["conditions"]["A0"]["device_energy_mean"] is None
    assert a["conditions"]["A5"]["device_energy_mean"] is None
    assert a["scm"]["device_energy_j"] is None


def test_failed_or_unscored_trials_are_counted_but_not_fabricated_into_quality():
    rows=[rec("A0",None,1.0,None,False), rec("A0",0.8,1.2,None,True), rec("A5",1.0,2.0,None,True)]
    a=aggregate_trials(rows)
    assert a["conditions"]["A0"]["n"] == 2
    assert a["conditions"]["A0"]["quality_n"] == 1
    assert a["conditions"]["A0"]["quality_mean"] == pytest.approx(0.8)
