def test_public_api_exports_core_runner_types():
    from ipm_xa04 import TrialExecutor, TaskPack, ScriptedProvider, canonical_policy, aggregate_trials
    assert TrialExecutor and TaskPack and ScriptedProvider and canonical_policy and aggregate_trials
