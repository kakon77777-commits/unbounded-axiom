import json
from pathlib import Path

from ipm_xa04.cli import main


def test_policy_cli_prints_canonical_json(capsys):
    rc=main(["policy","A0"])
    assert rc==0
    d=json.loads(capsys.readouterr().out)
    assert d["name"]=="A0"
    assert d["max_model_invocations"]==1
    assert d["allow_tools"] is False


def test_aggregate_cli_reads_trial_record_files(tmp_path,capsys):
    a={"condition":"A0","quality":{"scalar_value":0.5,"hard_gate":True},"xa03_summary":{"execution":{"wall_time_s":1.0},"physical":{"device_energy_j":None,"allocated_device_time_s":None}}}
    b={"condition":"A5","quality":{"scalar_value":1.0,"hard_gate":True},"xa03_summary":{"execution":{"wall_time_s":2.0},"physical":{"device_energy_j":None,"allocated_device_time_s":None}}}
    p1=tmp_path/"a.json"; p2=tmp_path/"b.json"; p1.write_text(json.dumps(a)); p2.write_text(json.dumps(b))
    rc=main(["aggregate",str(p1),str(p2)])
    assert rc==0
    d=json.loads(capsys.readouterr().out)
    assert d["ssr"]==0.5 and d["sdr"]==0.5

def test_scripted_run_cli_executes_a0_with_canonical_dependencies(tmp_path,capsys,monkeypatch):
    xa02=__import__('os').environ.get('IPM_XA02_ROOT')
    xa03=__import__('os').environ.get('IPM_XA03_ROOT')
    if not xa02 or not xa03:
        __import__('pytest').skip('canonical dependencies not configured')
    outputs=json.dumps(['{"answer":169}'])
    rc=main([
        'scripted-run','--xa02-root',xa02,'--xa03-root',xa03,'--output-dir',str(tmp_path),
        '--task','MATH-003','--condition','A0','--model-id','cli-fake','--outputs-json',outputs
    ])
    assert rc==0
    d=json.loads(capsys.readouterr().out)
    assert d['condition']=='A0'
    assert d['quality']['scalar_value']==1.0
