import dataclasses
import pytest

from ipm_xa04.policies import canonical_policy
from ipm_xa04.budget import BudgetLedger, BudgetExhausted


def test_canonical_policy_matrix_and_immutability():
    a0 = canonical_policy("A0")
    a1 = canonical_policy("A1")
    a2 = canonical_policy("A2")
    a3 = canonical_policy("A3")
    a4 = canonical_policy("A4")
    a5 = canonical_policy("A5")

    assert (a0.initial_samples, a0.generation_budget_multiplier, a0.max_model_invocations, a0.max_trajectories) == (1, 1.0, 1, 1)
    assert not a0.allow_tools and not a0.allow_verifier and not a0.planner_enabled and not a0.memory_enabled
    assert a1.generation_budget_multiplier == 2.0 and a1.max_model_invocations == 1 and a1.max_trajectories == 1
    assert a2.initial_samples == 8 and a2.selection_mode == "exact_majority" and a2.max_model_invocations == 8
    assert a3.initial_samples == 8 and a3.allow_verifier and a3.max_verifier_passes == 1 and a3.max_model_invocations == 9
    assert a4.allow_tools and a4.allow_verifier and a4.max_tool_calls == 4 and a4.max_model_invocations == 12
    assert a5.initial_samples == 1 and a5.max_model_invocations == 16 and a5.max_trajectories == 4
    assert a5.max_retries == 3 and a5.max_tool_calls == 8 and a5.max_verifier_passes == 3
    assert a5.planner_enabled and a5.memory_enabled and a5.selection_mode == "iterative_verification"

    with pytest.raises(dataclasses.FrozenInstanceError):
        a0.max_model_invocations = 99


def test_budget_ledger_enforces_typed_limits():
    p = canonical_policy("A0")
    ledger = BudgetLedger(p)
    ledger.consume_model_invocation()
    with pytest.raises(BudgetExhausted) as exc:
        ledger.consume_model_invocation()
    assert exc.value.resource == "model_invocations"

    with pytest.raises(BudgetExhausted):
        ledger.consume_tool_call()
    with pytest.raises(BudgetExhausted):
        ledger.consume_retry()
    with pytest.raises(BudgetExhausted):
        ledger.consume_verifier_pass()


def test_budget_ledger_counts_and_cannot_mutate_limits():
    p = canonical_policy("A5")
    ledger = BudgetLedger(p)
    ledger.consume_model_invocation()
    ledger.consume_trajectory()
    ledger.consume_retry()
    ledger.consume_tool_call()
    ledger.consume_verifier_pass()
    s = ledger.snapshot()
    assert s["model_invocations"] == 1
    assert s["trajectories"] == 1
    assert s["retries"] == 1
    assert s["tool_calls"] == 1
    assert s["verifier_passes"] == 1
    with pytest.raises(dataclasses.FrozenInstanceError):
        ledger.limits.max_tool_calls = 100
