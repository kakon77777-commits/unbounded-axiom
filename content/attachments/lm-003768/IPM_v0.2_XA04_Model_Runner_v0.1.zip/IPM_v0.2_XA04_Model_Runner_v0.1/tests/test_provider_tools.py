import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

from ipm_xa04.dependencies import TaskPack
from ipm_xa04.models import GenerationRequest, GenerationResult
from ipm_xa04.provider import ScriptedProvider, LocalCommandProvider, OpenAICompatibleProvider
from ipm_xa04.tools import CalculatorTool, ToolRegistry


def req(prompt="hello"):
    return GenerationRequest(prompt=prompt, role="generator", condition="A0", task_id="MATH-003")


def test_taskpack_uses_public_file_only(tmp_path):
    (tmp_path / "tasks_public.json").write_text(json.dumps({"tasks":[{"id":"T1","family":"math","prompt":"public"}]}), encoding="utf-8")
    # No private reference file exists at all.
    pack = TaskPack(tmp_path)
    assert pack.get("T1")["prompt"] == "public"
    assert pack.task_ids() == ["T1"]


def test_scripted_provider_returns_outputs_and_captures_requests():
    p = ScriptedProvider(["one", "two"], provider_id="fake", model_id="m")
    assert p.generate(req("a")).text == "one"
    assert p.generate(req("b")).text == "two"
    assert [r.prompt for r in p.requests] == ["a", "b"]
    with pytest.raises(RuntimeError):
        p.generate(req("c"))


def test_local_command_provider_round_trip(tmp_path):
    script = tmp_path / "echo.py"
    script.write_text("import sys; print('OUT:' + sys.stdin.read())", encoding="utf-8")
    p = LocalCommandProvider([sys.executable, str(script)], model_id="local-test")
    r = p.generate(req("abc"))
    assert r.text.strip() == "OUT:abc"


class _Handler(BaseHTTPRequestHandler):
    captured = None
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(n)
        type(self).captured = {"path": self.path, "auth": self.headers.get("Authorization"), "body": json.loads(body)}
        payload = json.dumps({"id":"r1","choices":[{"message":{"content":"server answer"}}],"usage":{"total_tokens":7}}).encode()
        self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(payload))); self.end_headers(); self.wfile.write(payload)
    def log_message(self, fmt, *args):
        pass


def test_openai_compatible_provider_uses_env_secret_without_embedding_it_in_request_object(monkeypatch):
    server = HTTPServer(("127.0.0.1", 0), _Handler)
    th = threading.Thread(target=server.serve_forever, daemon=True); th.start()
    monkeypatch.setenv("XA04_TEST_KEY", "super-secret-key")
    try:
        p = OpenAICompatibleProvider(base_url=f"http://127.0.0.1:{server.server_port}", model_id="test-model", api_key_env="XA04_TEST_KEY")
        request = req("hello api")
        result = p.generate(request)
        assert result.text == "server answer"
        assert _Handler.captured["path"] == "/v1/chat/completions"
        assert _Handler.captured["auth"] == "Bearer super-secret-key"
        assert _Handler.captured["body"]["model"] == "test-model"
        assert _Handler.captured["body"]["messages"][0]["content"] == "hello api"
        assert "super-secret-key" not in repr(request)
        assert "super-secret-key" not in repr(result)
    finally:
        server.shutdown(); server.server_close()


def test_calculator_tool_allows_arithmetic_and_rejects_code_execution():
    t = CalculatorTool()
    assert t.execute({"expression":"17*17-120"}).output == 169
    assert t.execute({"expression":"2**8 + 3"}).output == 259
    bad = t.execute({"expression":"__import__('os').system('echo nope')"})
    assert bad.ok is False
    assert "not allowed" in bad.error.lower()
    bad2 = t.execute({"expression":"abs(-3)"})
    assert bad2.ok is False


def test_tool_registry_rejects_unknown_tool():
    reg = ToolRegistry([CalculatorTool()])
    assert reg.execute("calculator", {"expression":"1+2"}).output == 3
    with pytest.raises(KeyError):
        reg.execute("missing", {})
