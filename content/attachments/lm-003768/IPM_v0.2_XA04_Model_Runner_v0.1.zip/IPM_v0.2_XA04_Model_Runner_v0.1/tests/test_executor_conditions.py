import json
import os
from pathlib import Path

import pytest

from ipm_xa04.dependencies import TaskPack
from ipm_xa04.evaluator_bridge import EvaluatorBridge
from ipm_xa04.executor import TrialExecutor, PolicyViolation
from ipm_xa04.models import VerificationResult, ToolResult
from ipm_xa04.provider import ScriptedProvider
from ipm_xa04.tools import CalculatorTool, ToolRegistry


def dep(name):
    p=os.environ.get(name)
    if not p: pytest.skip(f"{name} not configured")
    return Path(p)


def make_executor(tmp_path):
    xa02=dep("IPM_XA02_ROOT"); xa03=dep("IPM_XA03_ROOT")
    return TrialExecutor(TaskPack(xa02), EvaluatorBridge(xa02), xa03_root=xa03, output_dir=tmp_path)


class IndexVerifier:
    verifier_type="index_scripted"
    def __init__(self, indices, accepted=None, feedback=None):
        self.indices=list(indices); self.accepted=list(accepted or [True]*len(self.indices)); self.feedback=list(feedback or [""]*len(self.indices)); self.i=0
    def select(self, task, candidates, invoke_model=None):
        idx=self.indices[self.i]; acc=self.accepted[self.i]; fb=self.feedback[self.i]; self.i+=1
        return VerificationResult(candidates[idx].candidate_id, accepted=acc, feedback=fb)


class CountingCalculator(CalculatorTool):
    def __init__(self): self.calls=0
    def execute(self,payload): self.calls+=1; return super().execute(payload)


def exec_counts(result):
    return result.xa03_summary["execution"]


def test_a0_one_invocation_one_trajectory_and_quality(tmp_path):
    ex=make_executor(tmp_path)
    p=ScriptedProvider(['{"answer":169}'],model_id="fake")
    r=ex.execute("MATH-003","A0",p,replicate=1)
    assert r.failure is None and r.quality.scalar_value==1.0
    e=exec_counts(r)
    assert e["model_invocations_started"]==1
    assert e["trajectories_started"]==1
    assert e["candidates_created"]==1 and e["candidates_selected"]==1 and e["candidates_discarded"]==0
    assert len(p.requests)==1 and p.requests[0].generation_budget_multiplier==1.0


def test_a1_changes_only_generation_budget_multiplier_structurally(tmp_path):
    ex=make_executor(tmp_path)
    p=ScriptedProvider(['{"answer":169}'],model_id="fake")
    r=ex.execute("MATH-003","A1",p)
    e=exec_counts(r)
    assert e["model_invocations_started"]==1 and e["trajectories_started"]==1
    assert p.requests[0].generation_budget_multiplier==2.0


def test_a2_eight_candidates_exact_majority_and_seven_discarded(tmp_path):
    ex=make_executor(tmp_path)
    outs=['{"answer":169}']*5 + ['{"answer":168}']*3
    p=ScriptedProvider(outs,model_id="fake")
    r=ex.execute("MATH-003","A2",p)
    assert r.quality.scalar_value==1.0
    e=exec_counts(r)
    assert e["model_invocations_started"]==8 and e["trajectories_started"]==8
    assert e["candidates_created"]==8 and e["candidates_selected"]==1 and e["candidates_discarded"]==7
    assert r.candidate_text=='{"answer":169}'


def test_a0_tool_action_is_protocol_violation_and_tool_is_not_executed(tmp_path):
    ex=make_executor(tmp_path)
    tool=CountingCalculator(); reg=ToolRegistry([tool])
    p=ScriptedProvider([json.dumps({"action":"tool","tool":"calculator","input":{"expression":"1+2"}})],model_id="fake")
    r=ex.execute("MATH-003","A0",p,tools=reg)
    assert r.failure["type"]=="PolicyViolation"
    assert tool.calls==0
    assert r.xa03_summary["run"]["state"]=="ABORTED"
    assert r.xa03_summary["execution"]["tool_calls_started"]==0


def test_a3_verifier_selects_specified_candidate(tmp_path):
    ex=make_executor(tmp_path)
    outs=[f'{{"answer":{160+i}}}' for i in range(8)]
    outs[3]='{"answer":169}'
    p=ScriptedProvider(outs,model_id="fake")
    v=IndexVerifier([3])
    r=ex.execute("MATH-003","A3",p,verifier=v)
    assert r.quality.scalar_value==1.0 and r.candidate_text=='{"answer":169}'
    e=exec_counts(r)
    assert e["model_invocations_started"]==8 and e["trajectories_started"]==8
    assert e["verifier_passes_started"]==1
    assert e["candidates_created"]==8 and e["candidates_discarded"]==7


def test_a4_tool_loop_records_tool_and_returns_correct_candidate(tmp_path):
    ex=make_executor(tmp_path)
    tool=CountingCalculator(); reg=ToolRegistry([tool])
    first=json.dumps({"action":"tool","tool":"calculator","input":{"expression":"17*17-120"}})
    final=json.dumps({"action":"final","content":"{\"answer\":169}"})
    # First trajectory consumes tool action + final; seven other trajectories are wrong.
    outs=[first, final] + ['{"answer":168}']*7
    p=ScriptedProvider(outs,model_id="fake")
    v=IndexVerifier([0])
    r=ex.execute("MATH-003","A4",p,verifier=v,tools=reg)
    assert tool.calls==1 and r.quality.scalar_value==1.0
    e=exec_counts(r)
    assert e["model_invocations_started"]==9 and e["trajectories_started"]==8
    assert e["tool_calls_started"]==1 and e["verifier_passes_started"]==1


def test_a5_planner_retry_rejected_first_then_accepts_second(tmp_path):
    ex=make_executor(tmp_path)
    # planner, first candidate, retry candidate
    p=ScriptedProvider(["brief external plan", '{"answer":168}', '{"answer":169}'],model_id="fake")
    v=IndexVerifier([0,0], accepted=[False,True], feedback=["wrong","ok"])
    r=ex.execute("MATH-003","A5",p,verifier=v,tools=ToolRegistry([]))
    assert r.failure is None and r.quality.scalar_value==1.0
    assert r.candidate_text=='{"answer":169}'
    e=exec_counts(r)
    assert e["model_invocations_started"]==3
    assert e["trajectories_started"]==2
    assert e["retries_started"]==1
    assert e["verifier_passes_started"]==2
    assert e["candidates_created"]==2 and e["candidates_discarded"]==1 and e["candidates_selected"]==1
    assert p.requests[0].role=="planner"


def test_private_sentinel_never_reaches_provider_requests(tmp_path):
    # Build a tiny task pack with a private sentinel file next to public data.
    packdir=tmp_path/"pack"; packdir.mkdir()
    (packdir/"tasks_public.json").write_text(json.dumps({"tasks":[{"id":"T1","family":"math","prompt":"PUBLIC TASK"}]}),encoding="utf-8")
    sentinel="XA02_PRIVATE_SENTINEL_DO_NOT_LEAK"
    (packdir/"reference_private.json").write_text(json.dumps({"secret":sentinel}),encoding="utf-8")
    # Use real evaluator bridge separately from canonical XA02 because T1 is not in it; run failure before evaluation is okay if provider requests can be inspected.
    ex=TrialExecutor(TaskPack(packdir), EvaluatorBridge(dep("IPM_XA02_ROOT")), xa03_root=dep("IPM_XA03_ROOT"), output_dir=tmp_path/"runs")
    p=ScriptedProvider(['{"answer":1}'],model_id="fake")
    r=ex.execute("T1","A0",p,skip_evaluation=True)
    joined="\n".join(x.prompt for x in p.requests)
    assert sentinel not in joined

def test_a5_retry_span_wraps_the_actual_retry_attempt(tmp_path):
    ex=make_executor(tmp_path)
    p=ScriptedProvider(["plan", '{"answer":168}', '{"answer":169}'],model_id="retry-span")
    v=IndexVerifier([0,0], accepted=[False,True], feedback=["wrong","ok"])
    r=ex.execute("MATH-003","A5",p,verifier=v,tools=ToolRegistry([]))
    events=[json.loads(line) for line in (Path(r.xa03_run_dir)/"events.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    types=[e["event_type"] for e in events]
    retry_start=types.index("retry_start")
    retry_end=types.index("retry_end")
    trajectory_starts=[i for i,t in enumerate(types) if t=="trajectory_start"]
    verifier_ends=[i for i,t in enumerate(types) if t=="verifier_end"]
    assert retry_start < trajectory_starts[1] < verifier_ends[1] < retry_end
