# IPM v0.2 XA-04 Model Runner Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Implement the XA-04 Policy-Driven State Machine that runs XA-02 tasks under A0→A5 policies while recording execution through XA-03 and scoring final candidates through XA-02.

**Architecture:** One `TrialExecutor` consumes immutable `ConditionPolicy` objects. Providers, tools, verifiers, XA-02 evaluation, and XA-03 telemetry are isolated behind interfaces. XA-02/XA-03 remain external canonical dependencies.

**Tech Stack:** Python 3.11+ standard library; pytest for tests; canonical XA-02 and XA-03 artifacts supplied by path.

**Spec:** `/mnt/data/IPM_v0.2_XA04_ModelRunner_Design_Spec_v0.1.md`

## Global Constraints

- Use one TrialExecutor for all A0→A5 conditions.
- ConditionPolicy objects are immutable.
- No XA-02 private reference file is read by TaskPack.
- All provider/tool/verifier execution occurs inside XA-03 public spans.
- Final XA-02 evaluation occurs after XA-03 run finalization.
- Unknown physical cost remains null.
- Core package uses Python standard library only.
- No model-provider SDK is mandatory.
- No private chain-of-thought capture.
- No self-extension of scaffold budgets.

---

### Task 1 — Models, Policies, Budget Ledger

**Files:** `ipm_xa04/models.py`, `policies.py`, `budget.py`, `tests/test_budget_policies.py`

**Produces:** `GenerationRequest`, `GenerationResult`, `Candidate`, `TrialResult`, `ConditionPolicy`, `canonical_policy(name)`, `BudgetLedger`.

- [ ] Write tests asserting exact A0→A5 policy fields and frozen dataclasses.
- [ ] Run and verify RED.
- [ ] Implement minimal models/policies.
- [ ] Verify GREEN.
- [ ] Write budget tests for invocation/tool/retry/verifier exhaustion and immutable limits.
- [ ] Verify RED.
- [ ] Implement `BudgetLedger`.
- [ ] Verify GREEN.

### Task 2 — Dependency Loader, Providers, Tools

**Files:** `dependencies.py`, `provider.py`, `tools.py`, `tests/test_provider_tools.py`

**Produces:** `TaskPack`, `ProviderAdapter`, `ScriptedProvider`, `LocalCommandProvider`, `OpenAICompatibleProvider`, `ToolRegistry`, `CalculatorTool`, `LocalCommandTool`.

- [ ] Write TaskPack test with private sentinel and prove public loader never reads private file.
- [ ] Verify RED.
- [ ] Implement TaskPack public-only loader.
- [ ] Verify GREEN.
- [ ] Write ScriptedProvider request-capture test.
- [ ] Implement provider protocol + ScriptedProvider.
- [ ] Add LocalCommandProvider test using a temporary Python echo command.
- [ ] Implement LocalCommandProvider.
- [ ] Add local HTTP-server test for OpenAI-compatible adapter payload/secret boundary.
- [ ] Implement standard-library HTTP adapter.
- [ ] Write CalculatorTool AST whitelist tests including rejection of names/calls.
- [ ] Implement CalculatorTool and ToolRegistry.
- [ ] Verify full file GREEN.

### Task 3 — Evaluator Bridge and Verifiers

**Files:** `evaluator_bridge.py`, `verifier.py`, `tests/test_evaluator_bridge.py`

**Produces:** `EvaluatorBridge`, `QualityRecord`, `Verifier`, `ScriptedVerifier`, `SameModelVerifier`.

- [ ] Write failing XA-02 MATH-003 evaluator bridge test expecting scalar 1.0 for `{"answer":169}`.
- [ ] Implement subprocess evaluator bridge without reading private references.
- [ ] Verify GREEN.
- [ ] Write ScriptedVerifier known-candidate and unknown-candidate tests.
- [ ] Implement ScriptedVerifier.
- [ ] Write SameModelVerifier JSON selection parsing test.
- [ ] Implement SameModelVerifier using injected model-invocation callable.
- [ ] Verify GREEN.

### Task 4 — TrialExecutor A0/A1/A2

**Files:** `executor.py`, `tests/test_executor_conditions.py`

**Produces:** `TrialExecutor.execute(...)`.

- [ ] Write A0 failing test using ScriptedProvider and XA-03 NullCollector.
- [ ] Assert one invocation, one trajectory, one candidate, one selected, evaluator quality.
- [ ] Implement minimal A0 execution.
- [ ] Verify GREEN.
- [ ] Write A1 failing test asserting provider request multiplier exactly 2.0 and counts same as A0.
- [ ] Implement A1 through policy only.
- [ ] Verify GREEN.
- [ ] Write A2 failing test with eight scripted outputs and exact-majority selection.
- [ ] Assert 8 invocations, 8 trajectories, 8 created, 1 selected, 7 discarded.
- [ ] Implement multi-sample + deterministic majority.
- [ ] Verify GREEN.
- [ ] Write A0 tool-action violation test and prove tool registry execute count stays zero.
- [ ] Implement policy violation handling.
- [ ] Verify GREEN.

### Task 5 — TrialExecutor A3/A4/A5

**Files:** `executor.py`, `tests/test_executor_conditions.py`

- [ ] Write A3 failing test: 8 candidates + scripted verifier selects specified candidate.
- [ ] Implement verifier selection with XA-03 verifier span and budget.
- [ ] Verify GREEN.
- [ ] Write A4 failing test: first response requests calculator; second response finalizes correct answer.
- [ ] Implement structured action parser + tool observation loop.
- [ ] Verify GREEN.
- [ ] Write A5 failing test: planner, rejected first candidate, one retry, accepted second.
- [ ] Implement trial-local memory + retry state machine.
- [ ] Verify GREEN.
- [ ] Add budget-exhaustion test.
- [ ] Verify typed failure behavior.
- [ ] Add private sentinel scan across all captured provider requests.
- [ ] Verify no leakage.

### Task 6 — Aggregator and Trial Result Persistence

**Files:** `aggregator.py`, `tests/test_aggregator.py`

**Produces:** `aggregate_trials(records)`.

- [ ] Write golden fixture tests for condition means, SSR, SDR, SCM, marginal yield.
- [ ] Include null-energy records and assert energy SCM stays null.
- [ ] Implement aggregator.
- [ ] Verify GREEN.
- [ ] Test trial result SHA pointer to XA-03 summary and no mutation of finalized XA-03 directory.

### Task 7 — CLI, Examples, Release Verification

**Files:** `cli.py`, `__init__.py`, `README.md`, `pyproject.toml`, `examples/scripted_smoke.py`, `tests/test_cli.py`, `validation_report.json`, `manifest.json`

- [ ] Write CLI smoke test for scripted single trial.
- [ ] Implement CLI dependency paths and run arguments.
- [ ] Verify GREEN.
- [ ] Add example that runs deterministic A0→A5 with external XA-02/XA-03 paths.
- [ ] Run complete `pytest -q`.
- [ ] Run example.
- [ ] Generate validation report with condition/accounting assertions.
- [ ] Generate manifest hashes.
- [ ] Build ZIP.
- [ ] Extract ZIP cleanly and re-run full tests against canonical dependency paths.
- [ ] Validate internal manifest file hashes.
- [ ] Compute final package SHA-256.
- [ ] Only after fresh clean-package verification, declare XA-04 complete.
