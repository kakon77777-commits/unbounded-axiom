# IPM v0.2 XA-04 — A0→A5 Model Runner & Scaffold Orchestrator

## EML-IPM-XA-04 v0.1 Design Specification

**Architecture:** Policy-Driven State Machine  
**Series:** Intelligence Physical Metrology (IPM)  
**Version:** v0.2 Experimental Measurement Protocol  
**Artifact ID:** EML-IPM-XA-04  
**Design Version:** v0.1  
**Author:** Neo.K with Aletheia（GPT-5.6 Sol）  
**Institution:** EveMissLab／一言諾科技有限公司  
**Date:** 2026-09-03  
**Status:** APPROVED ARCHITECTURE — FROZEN FOR IMPLEMENTATION  
**Canonical Dependencies:** XA-01 Protocol, XA-02 Task Pack/Evaluator, XA-03 Telemetry & Run Logger

---

# 1. Core Principle

XA-04 uses one execution engine and changes only the scaffold policy:

\[
\boxed{
Executor_{A0}=Executor_{A1}=\cdots=Executor_{A5}
}
\]

while:

\[
\boxed{
Policy_{A0}\neq Policy_{A1}\neq\cdots\neq Policy_{A5}.
}
\]

Therefore A0→A5 differences are explicit experimental treatments rather than separate hand-written agent implementations.

---

# 2. Architecture

\[
\boxed{
Task
\rightarrow
ConditionPolicy
\rightarrow
TrialExecutor
\rightarrow
ProviderAdapter
}
\]

Every model/tool/verifier action is wrapped by XA-03:

\[
\boxed{
TrialExecutor
\rightarrow
XA03\ RunSession.
}
\]

Final benchmark evaluation happens after physical execution finalization:

\[
\boxed{
SelectedCandidate
\rightarrow
XA02\ EvaluatorBridge
\rightarrow
QualityRecord.
}
\]

Aggregate analysis is read-only:

\[
\boxed{
TrialRecords
\rightarrow
ResultAggregator
\rightarrow
SSR,SDR,SCM,Y_{S,k}.
}
\]

Five primary subsystems:

1. `ProviderAdapter`
2. `ConditionPolicy`
3. `BudgetLedger`
4. `TrialExecutor`
5. `EvaluatorBridge + ResultAggregator`

Tools/verifiers are injected services, not separate runners.

---

# 3. External Dependency Rule

XA-04 MUST NOT vendor modified copies of XA-02 or XA-03.

Configuration supplies canonical dependency paths:

```text
xa02_root/
  tasks_public.json
  evaluate.py
  reference_private.json  # evaluator-private; runner never reads it

xa03_root/
  ipm_xa03/
```

XA-04 may import XA-03 public API:

```python
from ipm_xa03 import RunConfig, RunSession
```

XA-04 may invoke XA-02 only through:

```text
python evaluate.py TASK_ID candidate_file
```

The task loader reads `tasks_public.json` only.

---

# 4. Trial Identity

The minimum experiment unit is:

\[
\boxed{
Trial=(Task,Model,Condition,Replicate).
}
\]

Canonical trial ID:

```text
IPM-XA-{model}-{task}-{condition}-{replicate}
```

Every trial starts with fresh:

- provider conversation state;
- policy state;
- memory state;
- budget ledger;
- XA-03 run session.

Cross-condition state reuse is forbidden.

---

# 5. ProviderAdapter

Canonical protocol:

```python
class ProviderAdapter(Protocol):
    provider_id: str
    model_id: str

    def generate(self, request: GenerationRequest) -> GenerationResult:
        ...
```

`GenerationRequest` contains only experiment-visible data:

```text
prompt
role
condition
task_id
generation_budget_multiplier
metadata
```

It MUST NOT contain XA-02 private references.

`GenerationResult`:

```text
text
request_id
usage
metadata
```

v0.1 adapters:

- `ScriptedProvider` — deterministic validation fixture;
- `LocalCommandProvider` — prompt via stdin, result via stdout;
- `OpenAICompatibleProvider` — standard-library HTTP client, secret read from environment and never logged.

XA-04 does not depend on a specific commercial model provider.

---

# 6. ConditionPolicy

A policy is immutable configuration.

Canonical fields:

```text
name
initial_samples
generation_budget_multiplier
max_model_invocations
max_trajectories
max_retries
max_tool_calls
max_verifier_passes
allow_tools
allow_verifier
planner_enabled
memory_enabled
selection_mode
```

---

# 7. Canonical A0→A5 Policy Table

## A0 — Native Single Pass

```text
initial_samples = 1
budget_multiplier = 1.0
max_model_invocations = 1
max_trajectories = 1
max_retries = 0
max_tool_calls = 0
max_verifier_passes = 0
allow_tools = false
allow_verifier = false
planner = false
memory = false
selection = only
```

## A1 — Extended Single Trajectory

Same as A0 except:

```text
budget_multiplier = 2.0
```

Still:

\[
\boxed{
G=1,\quad L_{external}=0.
}
\]

## A2 — Multi-Sample

```text
initial_samples = 8
max_model_invocations = 8
max_trajectories = 8
selection = exact_majority
```

No tools, retry, verifier, planner, or memory.

## A3 — Verifier

```text
initial_samples = 8
max_model_invocations = 9
max_trajectories = 8
max_verifier_passes = 1
allow_verifier = true
selection = verifier
```

A same-model verifier may consume the ninth invocation.

## A4 — Tool / Environment

```text
initial_samples = 8
max_model_invocations = 12
max_trajectories = 8
max_tool_calls = 4
max_verifier_passes = 1
allow_tools = true
allow_verifier = true
selection = verifier
```

Tool interaction occurs inside a trajectory.

## A5 — Full Agentic

```text
initial_samples = 1
max_model_invocations = 16
max_trajectories = 4
max_retries = 3
max_tool_calls = 8
max_verifier_passes = 3
allow_tools = true
allow_verifier = true
planner = true
memory = true
selection = iterative_verification
```

A5 is bounded. Self-extension of budget is forbidden.

---

# 8. BudgetLedger

Every scaffold-consuming action must consume a typed budget before execution:

```python
ledger.consume_model_invocation()
ledger.consume_trajectory()
ledger.consume_retry()
ledger.consume_tool_call()
ledger.consume_verifier_pass()
```

Exhaustion raises typed `BudgetExhausted`.

No policy or provider may mutate limits after trial start.

\[
\boxed{
AgentSelfBudgetExtension=Forbidden.
}
\]

---

# 9. Candidate Model

Every complete candidate receives a candidate ID through XA-03:

```python
cid = run.candidate_created(...)
```

Exactly one final candidate is selected if the trial reaches a normal result.

Every other completed candidate is marked discarded.

\[
\boxed{
Created = Selected + Discarded
}
\]

for normally completed selection stages.

---

# 10. Tool Action Protocol

A4/A5 may emit explicit tool actions:

```json
{
  "action": "tool",
  "tool": "calculator",
  "input": {
    "expression": "17*17-120"
  }
}
```

Final response envelope:

```json
{
  "action": "final",
  "content": "{\"answer\":169}"
}
```

A non-envelope response is treated as a final candidate.

If A0–A3 emits a tool action:

\[
\boxed{
PolicyViolation.
}
\]

It MUST NOT be silently treated as a normal answer.

---

# 11. Tools

Canonical protocol:

```python
class Tool(Protocol):
    name: str
    def execute(self, payload: dict) -> ToolResult: ...
```

v0.1 production tools:

- `CalculatorTool` — AST-whitelisted arithmetic only;
- `LocalCommandTool` — explicit external sandbox/command boundary for future code test runners or constraint tools.

XA-04 does not expose XA-02 hidden evaluator as a normal model tool.

---

# 12. Verifier

Canonical protocol:

```python
class Verifier(Protocol):
    verifier_type: str
    def select(self, task, candidates, invoke_model=None) -> VerificationResult:
        ...
```

v0.1:

- `SameModelVerifier`
- `ScriptedVerifier` for deterministic validation

The benchmark evaluator is not automatically used as an oracle verifier.

If future work intentionally uses benchmark-oracle selection, it requires a different typed verifier and explicit protocol version.

---

# 13. SameModelVerifier

The verifier receives candidate IDs + candidate texts and returns:

```json
{
  "selected_candidate_id": "candidate-...",
  "accepted": true,
  "feedback": "..."
}
```

The verifier invocation:

- consumes model-invocation budget;
- occurs inside `run.verifier(...)`;
- also occurs inside `run.model_invocation(role="verifier")`.

Verifier output that selects an unknown candidate is a protocol error.

---

# 14. A2 Exact-Majority Selection

Normalize only outer whitespace:

```python
text.strip()
```

Do not semantic-normalize or parse answers before majority voting.

The most frequent exact normalized output wins.

Tie-break:

\[
\boxed{
earliest\ generated\ candidate.
}
\]

This rule is deterministic.

---

# 15. A4 Tool Loop

Within a trajectory:

```text
GENERATE
  -> TOOL_ACTION?
      -> consume tool budget
      -> run.tool_call(...)
      -> execute tool
      -> append observation
      -> GENERATE
  -> FINAL
```

Tool observations are explicit external information and retained in trial-local memory only.

---

# 16. A5 State Machine

Canonical states:

\[
\boxed{
PLAN
\rightarrow
ACT
\rightarrow
OBSERVE
\rightarrow
VERIFY
\rightarrow
REVISE
}
\]

Operational flow:

1. Optional planner invocation.
2. Generate one candidate trajectory, with tool loop permitted.
3. Verify candidate.
4. If accepted: select.
5. If rejected and retry remains: discard, store verifier feedback, enter `run.retry`, start a fresh trajectory, regenerate.
6. If retry budget ends: select the last produced candidate as the system output, with `accepted=false` metadata.
7. If a hard budget is exceeded before any candidate exists: trial aborts with typed failure.

Memory is trial-local only.

---

# 17. Planner Boundary

Planner invocation asks only for a concise external action plan.

XA-04 does not require or record private chain-of-thought.

Planner output may be stored as ordinary model output because it is explicitly generated for the orchestration system.

---

# 18. EvaluatorBridge

Post-run evaluation:

```python
EvaluatorBridge.evaluate(task_id, candidate_text) -> QualityRecord
```

It writes candidate text to a temporary file and invokes XA-02 evaluator as a subprocess.

For CODE tasks, `allow_code_execution=false` by default.

Enabling code evaluation requires an explicit sandbox policy outside XA-04.

The evaluator runs **after** XA-03 physical run finalization so benchmark scoring cost is not counted as model/system execution cost.

---

# 19. Private Reference Isolation

The runner's task loader opens:

```text
tasks_public.json
```

only.

It never opens:

```text
reference_private.json
_private_reference_solutions.py
```

Hard validation fixture places a sentinel in private reference data:

```text
XA02_PRIVATE_SENTINEL_DO_NOT_LEAK
```

No `GenerationRequest.prompt`, tool observation, verifier prompt, or stored trial memory may contain that sentinel.

\[
\boxed{
PrivateReferenceLeakage
\Rightarrow
ProtocolFailure.
}
\]

---

# 20. XA-03 Trace Boundary

Every action must map to XA-03:

| XA-04 action | XA-03 trace |
|---|---|
| provider generation | `model_invocation` |
| candidate trajectory | `trajectory` |
| retry | `retry` |
| tool | `tool_call` |
| verifier | `verifier` |
| candidate produced | `candidate_created` |
| final candidate | `candidate_selected` |
| rejected/unselected | `candidate_discarded` |

XA-04 must not access XA-03 private event logger internals.

---

# 21. Trial Result

XA-04 writes a separate result record after XA-03 finalization:

```json
{
  "trial_id": "...",
  "task_id": "...",
  "condition": "A3",
  "replicate": 1,
  "model": {},
  "selected_candidate_id": "...",
  "candidate_text": "...",
  "quality": {},
  "xa03_run_dir": "...",
  "xa03_summary_sha256": "...",
  "failure": null
}
```

XA-03 finalized run directories remain untouched.

---

# 22. Aggregator

Aggregator is read-only and accepts trial-result records.

For each condition, it reports:

```text
n
quality_mean
quality_median
success_rate
wall_time_mean
device_energy_mean
allocated_device_time_mean
```

Unknown physical values remain null if unavailable.

---

# 23. SSR / SDR

Using condition means:

\[
\boxed{
SSR=
\frac{
\bar Q_{A0}
}{
\bar Q_{A5}
}
}
\]

when \(\bar Q_{A5}>0\).

\[
\boxed{
SDR=1-SSR.
}
\]

If denominator is zero or unavailable, result is null.

---

# 24. SCM

For physical axis \(j\):

\[
\boxed{
SCM_j=
\frac{
\bar C_{A5,j}
}{
\bar C_{A0,j}
}
}
\]

only when both sides are measured and A0 denominator is positive.

Unknown is null, not zero.

---

# 25. Marginal Yield

For adjacent stages:

\[
\boxed{
Y_{S,k,j}
=
\frac{
\bar Q_{k+1}-\bar Q_k
}{
\bar C_{k+1,j}-\bar C_{k,j}
}
}
\]

If the physical denominator is zero, negative, or unknown, that projection is null rather than fabricated.

---

# 26. Smoke Matrix Before Full Pilot

Before 900 trials/model:

\[
3\ tasks
\times
6\ conditions
\times
2\ replicates
=
36\ trials.
\]

Use one task from each XA-02 family.

Only after smoke validation should the complete:

\[
30\times6\times5=900
\]

matrix be attempted.

---

# 27. Deterministic Validation Matrix

`ScriptedProvider` and `ScriptedVerifier` must make condition behavior provable.

Required tests:

### A0
Single correct/wrong output; exactly one invocation, one trajectory.

### A1
Same structural counts as A0; generation budget multiplier is exactly 2.0.

### A2
Eight candidates; exact-majority selection; seven candidates discarded.

### A3
Eight candidates; scripted verifier selects a specified candidate; verifier count is one.

### A4
Provider requests calculator; tool returns observation; provider emits final answer; tool count is one.

### A5
Planner runs; first candidate rejected; one retry; second accepted; first candidate discarded and second selected.

---

# 28. Hard Negative Tests

## N1 — A0 Tool Violation

If A0 provider emits a tool action:

```text
PolicyViolation
```

and the run must not execute the tool.

## N2 — Private Reference Leakage

Private sentinel must never occur in any provider request.

## N3 — Budget Mutation

Attempt to modify frozen policy/budget limit fails.

## N4 — Unknown Candidate Verification

Verifier selecting an unknown candidate raises protocol failure.

## N5 — Cross-Condition State

A fresh trial must not inherit memory or provider conversation state from a previous condition.

---

# 29. Failure Types

Canonical XA-04 failures:

```text
PolicyViolation
BudgetExhausted
ProviderFailure
ToolFailure
VerifierFailure
EvaluatorFailure
DependencyFailure
ProtocolFailure
```

The raw XA-03 run may be COMPLETE or ABORTED depending on where failure occurs.

XA-04 result record preserves typed failure.

---

# 30. Release Layout

```text
IPM_v0.2_XA04_Model_Runner_v0.1/
  README.md
  SPEC.md
  IMPLEMENTATION_PLAN.md
  pyproject.toml

  ipm_xa04/
    __init__.py
    models.py
    dependencies.py
    provider.py
    policies.py
    budget.py
    tools.py
    verifier.py
    evaluator_bridge.py
    executor.py
    aggregator.py
    cli.py

  tests/
    test_budget_policies.py
    test_provider_tools.py
    test_evaluator_bridge.py
    test_executor_conditions.py
    test_aggregator.py
    test_cli.py

  fixtures/
    ...

  examples/
    scripted_smoke.py

  validation_report.json
  manifest.json
```

XA-02 and XA-03 are referenced dependencies, not vendored source.

---

# 31. Acceptance Criteria

XA-04 v0.1 is complete only if:

1. A0–A5 canonical policies match this spec.
2. All six deterministic condition tests pass.
3. A0 tool violation test proves tool execution did not occur.
4. Private sentinel leakage test passes.
5. Budget limits are immutable and enforced.
6. XA-03 execution counts match deterministic expectations.
7. XA-02 MATH evaluator bridge returns score 1.0 for a known correct candidate.
8. Evaluator cost occurs outside XA-03 physical run.
9. Aggregator produces correct SSR/SDR/SCM on golden fixture.
10. Unknown physical cost remains null.
11. Trial records point to immutable XA-03 run summaries.
12. Release examples run.
13. Full test suite passes on clean release extraction.
14. Manifest validates every released file.
15. ZIP SHA-256 is computed after final verification.

---

# 32. Canonical Principle

\[
\boxed{
\textbf{
Same execution engine,
different scaffold policy;
every added capability and cost must leave a typed operational trace.
}
}
\]
