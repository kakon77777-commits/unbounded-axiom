import json, shutil
from pathlib import Path
from ipm_xa06.verify_gate import verify_gate

SRC=Path('/mnt/data/IPM_v0.2_XA05_36Trial_SmokeGate_v0.1/canonical_smoke_run')

def fixture(tmp_path, engineering=False):
    p=tmp_path/'pilot'; shutil.copytree(SRC,p)
    (p/'pilot_run_summary.json').write_text(json.dumps({
      'engineering_validation_only':engineering,
      'status':'ENGINEERING_VALIDATION_COMPLETE' if engineering else 'REAL_MODEL_RUN_COMPLETE_UNVERIFIED',
      'trial_count':36,'real_model_pilot_complete':False
    }))
    # Flat XA-06-style audit with no private leak.
    (p/'provider_audit.json').write_text(json.dumps([{'trial_id':'x','private_sentinel_detected':False}]))
    return p

def test_gate_passes_complete_36_real_fixture_without_direction_requirement(tmp_path):
    p=fixture(tmp_path,False)
    g=verify_gate(p)
    assert g['gate_pass'] is True
    assert g['status']=='REAL_MODEL_PILOT_COMPLETE'
    assert g['trial_count']==36
    assert g['quality_available_rate']==1.0
    assert g['summary_hash_match_rate']==1.0
    assert g['private_leak_count']==0
    assert g['unauthorized_tool_execution_count']==0
    assert g['accounting_mismatch_count']==0


def test_engineering_fixture_can_pass_gate_but_never_be_promoted(tmp_path):
    p=fixture(tmp_path,True)
    g=verify_gate(p)
    assert g['gate_pass'] is True
    assert g['status']=='ENGINEERING_VALIDATION_PASS'
    assert g['real_model_pilot_complete'] is False


def test_missing_trial_fails_gate(tmp_path):
    p=fixture(tmp_path,False)
    next((p/'trial_results').glob('*.json')).unlink()
    g=verify_gate(p)
    assert g['gate_pass'] is False
    assert g['status']=='REAL_MODEL_PILOT_FAILED'
    assert g['trial_count']==35


def test_unauthorized_a0_tool_execution_fails_gate(tmp_path):
    p=fixture(tmp_path,False)
    tf=next((p/'trial_results').glob('*-A0-*.json')); tr=json.loads(tf.read_text())
    local=p/'xa03_runs'/tr['trial_id']; sp=local/'summary.json'; s=json.loads(sp.read_text()); s['execution']['tool_calls_started']=1; s['execution']['tool_calls_completed']=1; sp.write_text(json.dumps(s,sort_keys=True))
    import hashlib; tr['xa03_summary_sha256']=hashlib.sha256(sp.read_bytes()).hexdigest(); tf.write_text(json.dumps(tr))
    g=verify_gate(p)
    assert g['unauthorized_tool_execution_count']==1
    assert g['gate_pass'] is False


def test_local_relocated_run_is_preferred_over_historical_absolute_path(tmp_path):
    p=fixture(tmp_path,False)
    tf=next((p/'trial_results').glob('*.json')); tr=json.loads(tf.read_text()); tr['xa03_run_dir']='/definitely/not/here'; tf.write_text(json.dumps(tr))
    g=verify_gate(p)
    assert g['summary_hash_match_rate']==1.0

def test_code_evaluation_disabled_is_quality_unavailable_not_zero_quality(tmp_path):
    p=fixture(tmp_path,False)
    for tf in (p/'trial_results').glob('*CODE-001*.json'):
        tr=json.loads(tf.read_text())
        tr['quality']={'task_id':'CODE-001','hard_gate':False,'scalar_value':0.0,'vector':{'execution_allowed':0},'details':{'error':'disabled'},'failure_class':'runtime'}
        tf.write_text(json.dumps(tr))
    g=verify_gate(p)
    assert abs(g['quality_available_rate']-(24/36))<1e-12
    assert g['gate_pass'] is False
