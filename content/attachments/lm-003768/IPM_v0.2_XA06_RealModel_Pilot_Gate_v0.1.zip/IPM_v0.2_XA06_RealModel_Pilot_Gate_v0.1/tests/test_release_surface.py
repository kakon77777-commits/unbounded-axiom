import json
from pathlib import Path
import pytest
from ipm_xa06.cli import main
from ipm_xa06.config import PilotConfig

ROOT=Path(__file__).resolve().parents[1]

def test_example_configs_are_ready_only_and_canonical_matrix():
    for name in ['config.local_openai_compatible.example.json','config.local_command.example.json','config.cloud_openai_compatible.example.json']:
        data=json.loads((ROOT/'examples'/name).read_text())
        assert data['status']=='READY_FOR_REAL_MODEL'
        assert data['experiment']['tasks']==['MATH-003','CODE-001','CON-003']
        assert data['experiment']['conditions']==['A0','A1','A2','A3','A4','A5']
        assert data['experiment']['replicates']==2
        assert data.get('real_model_pilot_complete') is None


def test_cli_status_reports_ready_not_complete(tmp_path,capsys):
    data=json.loads((ROOT/'examples'/'config.local_command.example.json').read_text())
    # Replace placeholders with canonical roots and harmless command.
    data['dependencies']={
      'xa02_root':'/mnt/data/IPM_v0.2_XA04_deps_v0.1/xa02/IPM_v0.2_XA02_TaskPack_v0.1',
      'xa03_root':'/mnt/data/IPM_v0.2_XA04_deps_v0.1/xa03/IPM_v0.2_XA03_Reference_Logger_v0.1',
      'xa04_root':'/mnt/data/IPM_v0.2_XA04_Model_Runner_v0.1'}
    data['provider']['command']=['echo']
    data['output_dir']=str(tmp_path/'out')
    p=tmp_path/'c.json'; p.write_text(json.dumps(data))
    assert main(['status','--config',str(p)])==0
    out=json.loads(capsys.readouterr().out)
    assert out['status']=='READY_FOR_REAL_MODEL'
    assert out['real_model_pilot_complete'] is False
