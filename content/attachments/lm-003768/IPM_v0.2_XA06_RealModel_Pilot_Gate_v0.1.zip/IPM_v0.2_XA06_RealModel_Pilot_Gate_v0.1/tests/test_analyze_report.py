import json, shutil
from pathlib import Path
from ipm_xa06.analyze import analyze_pilot
from ipm_xa06.report import render_report

SRC=Path('/mnt/data/IPM_v0.2_XA05_36Trial_SmokeGate_v0.1/canonical_smoke_run')
XA04=Path('/mnt/data/IPM_v0.2_XA04_Model_Runner_v0.1')

def fixture(tmp_path, engineering=False):
    p=tmp_path/'pilot'; shutil.copytree(SRC,p)
    (p/'pilot_run_summary.json').write_text(json.dumps({'engineering_validation_only':engineering,'trial_count':36}))
    return p


def test_analysis_builds_expected_outputs_and_preserves_null_energy(tmp_path):
    p=fixture(tmp_path,False)
    report=analyze_pilot(p,xa04_root=XA04)
    assert abs(report['aggregate']['ssr']-0.3)<1e-12
    assert abs(report['aggregate']['sdr']-0.7)<1e-12
    assert report['aggregate']['scm']['device_energy_j'] is None
    assert report['protocol_compliance_rate']==1.0
    for name in ['aggregate.json','trial_index.csv','condition_summary.csv','physical_summary.csv','protocol_compliance.csv','pilot_report.md']:
        assert (p/name).exists()


def test_report_marks_engineering_fixture_as_non_empirical(tmp_path):
    p=fixture(tmp_path,True)
    report=analyze_pilot(p,xa04_root=XA04)
    text=render_report(report)
    assert 'ENGINEERING VALIDATION' in text
    assert 'not a real-model scientific result' in text
    assert 'population-level' in text

def test_analysis_does_not_count_disabled_code_evaluator_as_quality(tmp_path):
    p=fixture(tmp_path,False)
    for tf in (p/'trial_results').glob('*CODE-001*.json'):
        tr=json.loads(tf.read_text())
        tr['quality']={'task_id':'CODE-001','hard_gate':False,'scalar_value':0.0,'vector':{'execution_allowed':0},'details':{},'failure_class':'runtime'}
        tf.write_text(json.dumps(tr))
    report=analyze_pilot(p,xa04_root=XA04)
    assert abs(report['quality_available_rate']-(24/36))<1e-12
