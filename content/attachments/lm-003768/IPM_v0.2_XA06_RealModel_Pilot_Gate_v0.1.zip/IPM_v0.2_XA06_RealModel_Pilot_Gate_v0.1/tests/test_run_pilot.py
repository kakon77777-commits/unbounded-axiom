from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from ipm_xa06.config import PilotConfig
from ipm_xa06.run_real_pilot import run_pilot

TASKS=('MATH-003','CODE-001','CON-003')
CONDS=('A0','A1','A2','A3','A4','A5')


def cfg(tmp_path):
    return PilotConfig.from_dict({
      'status':'READY_FOR_REAL_MODEL',
      'dependencies':{'xa02_root':'/x2','xa03_root':'/x3','xa04_root':'/x4'},
      'provider':{'mode':'local_command','provider_id':'fake','model_id':'realish','command':['echo'], 'base_max_tokens':100},
      'telemetry':{'collectors':['null'],'physical_boundary':'test'},
      'evaluation':{'allow_code_evaluation':False},
      'experiment':{'tasks':list(TASKS),'conditions':list(CONDS),'replicates':2},
      'output_dir':str(tmp_path/'out')
    },base_dir=tmp_path,validate_paths=False)


class FakeProvider:
    provider_id='fake'; model_id='realish'
    def __init__(self, serial): self.serial=serial; self.audit_records=[]


class FakeExecutor:
    def __init__(self): self.calls=[]
    def execute(self,task_id,condition,provider,**kw):
        self.calls.append((task_id,condition,kw['replicate'],provider.serial,kw.get('verifier'),kw.get('tools'),kw.get('collectors')))
        tid=f"IPM-XA-realish-{task_id}-{condition}-{kw['replicate']:02d}"
        return SimpleNamespace(trial_id=tid,task_id=task_id,condition=condition,replicate=kw['replicate'],failure=None,quality=None,xa03_run_dir=f"/fake/{tid}")


def test_run_pilot_builds_exact_36_matrix_with_fresh_provider_per_trial(tmp_path):
    c=cfg(tmp_path); ex=FakeExecutor(); serial={'n':0}
    def pf(_cfg, **context):
        serial['n']+=1; return FakeProvider(serial['n'])
    summary=run_pilot(c,provider_factory=pf,executor=ex,engineering_validation_only=True)
    assert summary['trial_count']==36
    expected={(t,a,r) for r in (1,2) for t in TASKS for a in CONDS}
    actual={(t,a,r) for t,a,r,_,_,_,_ in ex.calls}
    assert actual==expected
    assert len({s for *_,s,__,___,____ in ex.calls})==36
    assert summary['status']=='ENGINEERING_VALIDATION_COMPLETE'
    assert summary['real_model_pilot_complete'] is False
    assert (c.output_dir/'pilot'/'pilot_run_summary.json').exists()


def test_verifier_and_tool_wiring_follow_conditions(tmp_path):
    c=cfg(tmp_path); ex=FakeExecutor(); n={'v':0}
    def pf(_cfg,**ctx): n['v']+=1; return FakeProvider(n['v'])
    run_pilot(c,provider_factory=pf,executor=ex,engineering_validation_only=True)
    for task,cond,rep,serial,verifier,tools,collectors in ex.calls:
        if cond in {'A3','A4','A5'}: assert verifier is not None
        else: assert verifier is None
        assert tools is not None
        assert tuple(collectors)==('null',)
