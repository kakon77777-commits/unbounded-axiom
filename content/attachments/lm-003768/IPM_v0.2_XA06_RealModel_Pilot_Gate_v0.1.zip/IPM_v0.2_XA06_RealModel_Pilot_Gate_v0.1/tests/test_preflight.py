import json, sys
from pathlib import Path
from ipm_xa06.config import PilotConfig
from ipm_xa06.preflight import run_preflight

XA02=Path('/mnt/data/IPM_v0.2_XA04_deps_v0.1/xa02/IPM_v0.2_XA02_TaskPack_v0.1')
XA03=Path('/mnt/data/IPM_v0.2_XA04_deps_v0.1/xa03/IPM_v0.2_XA03_Reference_Logger_v0.1')
XA04=Path('/mnt/data/IPM_v0.2_XA04_Model_Runner_v0.1')


def make_command(tmp_path, good=True):
    p=tmp_path/'provider.py'
    if good:
        p.write_text('import sys\nsys.stdin.read()\nprint(\'{"answer":169}\')\n')
    else:
        p.write_text('import sys\nsys.stdin.read()\nprint("boom",file=sys.stderr)\nraise SystemExit(4)\n')
    return [sys.executable,str(p)]


def cfg(tmp_path, command):
    return PilotConfig.from_dict({
      'status':'READY_FOR_REAL_MODEL',
      'dependencies':{'xa02_root':str(XA02),'xa03_root':str(XA03),'xa04_root':str(XA04)},
      'provider':{'mode':'local_command','provider_id':'test-command','model_id':'preflight-model','command':command,'timeout_s':5,'base_max_tokens':128},
      'telemetry':{'collectors':['null'],'physical_boundary':'preflight-null'},
      'evaluation':{'allow_code_evaluation':False},
      'experiment':{'tasks':['MATH-003','CODE-001','CON-003'],'conditions':['A0','A1','A2','A3','A4','A5'],'replicates':2},
      'output_dir':str(tmp_path/'xa06')
    },base_dir=tmp_path)


def test_preflight_runs_one_isolated_a0_trial_and_scores_quality(tmp_path):
    c=cfg(tmp_path,make_command(tmp_path,True))
    report=run_preflight(c)
    assert report['status']=='PASS'
    assert report['trial']['task_id']=='MATH-003'
    assert report['trial']['condition']=='A0'
    assert report['quality_available'] is True
    assert report['quality_scalar']==1.0
    assert Path(report['xa03_run_dir']).name.endswith('A0-99')
    assert (c.output_dir/'preflight'/'preflight_summary.json').exists()
    assert not (c.output_dir/'pilot').exists()
    audit=json.loads((c.output_dir/'preflight'/'provider_audit.json').read_text())
    assert audit and all(not x['private_sentinel_detected'] for x in audit)
    assert report['real_model_pilot_complete'] is False


def test_preflight_provider_failure_is_reported_not_promoted(tmp_path):
    c=cfg(tmp_path,make_command(tmp_path,False))
    report=run_preflight(c)
    assert report['status']=='FAIL'
    assert report['trial']['failure']['type']=='ProviderFailure'
    assert report['real_model_pilot_complete'] is False
