import json, os, threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import pytest

from ipm_xa06.config import PilotConfig, ConfigError
from ipm_xa06.providers import build_provider, HarnessedProvider


def base_config(tmp_path):
    return {
        "status": "READY_FOR_REAL_MODEL",
        "dependencies": {
            "xa02_root": "/xa02",
            "xa03_root": "/xa03",
            "xa04_root": "/xa04"
        },
        "provider": {
            "mode": "openai_compatible",
            "provider_id": "local-http",
            "model_id": "test-model",
            "base_url": "http://127.0.0.1:9999",
            "auth_mode": "none",
            "timeout_s": 5,
            "base_max_tokens": 100,
            "token_budget_field": "max_tokens",
            "temperature": 0.2,
            "top_p": 0.9,
            "seed": 7
        },
        "telemetry": {"collectors": ["null"], "physical_boundary": "test"},
        "evaluation": {"allow_code_evaluation": False},
        "experiment": {
            "tasks": ["MATH-003", "CODE-001", "CON-003"],
            "conditions": ["A0","A1","A2","A3","A4","A5"],
            "replicates": 2
        },
        "output_dir": str(tmp_path / "out")
    }


def test_config_rejects_wrong_matrix(tmp_path):
    data=base_config(tmp_path)
    data["experiment"]["replicates"]=3
    with pytest.raises(ConfigError):
        PilotConfig.from_dict(data, base_dir=tmp_path, validate_paths=False)


def test_config_redaction_never_contains_secret_value(tmp_path, monkeypatch):
    data=base_config(tmp_path)
    data["provider"]["auth_mode"]="bearer_env"
    data["provider"]["api_key_env"]="XA06_SECRET"
    monkeypatch.setenv("XA06_SECRET", "super-secret-value")
    cfg=PilotConfig.from_dict(data, base_dir=tmp_path, validate_paths=False)
    rendered=json.dumps(cfg.redacted_dict())
    assert "super-secret-value" not in rendered
    assert "XA06_SECRET" in rendered


def test_missing_bearer_environment_is_rejected(tmp_path, monkeypatch):
    data=base_config(tmp_path)
    data["provider"]["auth_mode"]="bearer_env"
    data["provider"]["api_key_env"]="XA06_MISSING"
    monkeypatch.delenv("XA06_MISSING", raising=False)
    cfg=PilotConfig.from_dict(data, base_dir=tmp_path, validate_paths=False)
    with pytest.raises(ConfigError):
        cfg.validate_runtime_environment()


class CaptureHandler(BaseHTTPRequestHandler):
    captured=[]
    def do_POST(self):
        n=int(self.headers.get("Content-Length","0"))
        body=json.loads(self.rfile.read(n))
        type(self).captured.append({"path":self.path,"body":body,"authorization":self.headers.get("Authorization")})
        payload={"id":"resp-1","choices":[{"message":{"content":"{\\\"answer\\\":169}"}}],"usage":{"completion_tokens":4}}
        raw=json.dumps(payload).encode()
        self.send_response(200); self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
    def log_message(self, *args):
        pass


@pytest.fixture
def local_server():
    CaptureHandler.captured=[]
    srv=HTTPServer(("127.0.0.1",0),CaptureHandler)
    t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
    try:
        yield f"http://127.0.0.1:{srv.server_port}"
    finally:
        srv.shutdown(); t.join(timeout=2)


def test_http_provider_propagates_a1_budget_and_decoding(tmp_path, local_server):
    data=base_config(tmp_path); data["provider"]["base_url"]=local_server
    cfg=PilotConfig.from_dict(data, base_dir=tmp_path, validate_paths=False)
    provider=build_provider(cfg.provider)
    from ipm_xa04.models import GenerationRequest
    provider.generate(GenerationRequest("p","generator","A1","MATH-003",2.0,{}))
    body=CaptureHandler.captured[-1]["body"]
    assert body["max_tokens"] == 200
    assert body["temperature"] == 0.2
    assert body["top_p"] == 0.9
    assert body["seed"] == 7


def test_harness_injects_tool_contract_only_for_a4_a5(tmp_path, local_server):
    data=base_config(tmp_path); data["provider"]["base_url"]=local_server
    cfg=PilotConfig.from_dict(data, base_dir=tmp_path, validate_paths=False)
    from ipm_xa04.models import GenerationRequest
    base=build_provider(cfg.provider); p=HarnessedProvider(base)
    p.generate(GenerationRequest("original","generator","A3","MATH-003",1.0,{}))
    p.generate(GenerationRequest("original","generator","A4","MATH-003",1.0,{}))
    assert CaptureHandler.captured[-2]["body"]["messages"][0]["content"] == "original"
    a4=CaptureHandler.captured[-1]["body"]["messages"][0]["content"]
    assert "calculator" in a4
    assert '"action":"tool"' in a4.replace(" ","")
    assert p.audit_records[-1]["private_sentinel_detected"] is False
