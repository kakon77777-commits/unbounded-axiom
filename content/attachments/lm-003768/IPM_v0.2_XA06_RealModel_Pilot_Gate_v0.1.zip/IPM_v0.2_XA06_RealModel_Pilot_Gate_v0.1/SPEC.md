# IPM v0.2 XA-06 — Real-Model Pilot Gate

## EML-IPM-XA-06 v0.1 Design Specification

**Status:** FROZEN FOR IMPLEMENTATION  
**Architecture:** Real-model pilot wrapper over canonical XA-02/XA-03/XA-04  
**Scientific status before external run:** `READY_FOR_REAL_MODEL`, never `REAL_MODEL_PILOT_COMPLETE`

## 1. Goal

Run the first real-model IPM Experiment-A pilot without changing the validated instrument. The pilot matrix is:

\[
\boxed{3\ tasks\times 6\ conditions\times2\ replicates=36\ trials/model.}
\]

Canonical tasks: `MATH-003`, `CODE-001`, `CON-003`. Canonical conditions: `A0..A5`.

XA-06 adds provider configuration, preflight, launch, gate verification, and reporting. It MUST NOT change XA-04 policies, XA-02 evaluators, or XA-03 telemetry semantics.

## 2. Status Semantics

- `READY_FOR_REAL_MODEL`: package, config, preflight logic, matrix launcher, gate verifier, and analysis passed deterministic/integration verification, but no external real model pilot is claimed.
- `REAL_MODEL_PILOT_COMPLETE`: allowed only when a run directory contains 36 terminal real-model trials and XA-06 gate passes.
- `REAL_MODEL_PILOT_FAILED`: real-model execution occurred but the engineering gate failed.

Synthetic/mock runs are always labeled `engineering_validation_only=true` and can never promote status to `REAL_MODEL_PILOT_COMPLETE`.

## 3. Provider Modes

Supported modes:

1. `openai_compatible` — recommended local-first HTTP endpoint, implemented by an XA-06 provider that conforms to the XA-04 `ProviderAdapter` interface and forwards decoding/budget controls.
2. `local_command` — canonical-style stdin/stdout command adapter; generation-budget control capability must be declared.
3. `cloud_openai_compatible` — same HTTP adapter semantics, but telemetry defaults should be null/runner-local unless provider exposes physical telemetry externally.

XA-06 MUST propagate `generation_budget_multiplier` into the real HTTP request token budget. Otherwise A1 is marked `budget_control_valid=false` and cannot be interpreted as an extended-single-trajectory treatment. Temperature, top-p, optional seed, and base token budget are frozen in config and recorded.

No provider SDK is mandatory. Secrets are referenced only by environment variable name.

## 4. Dependency Boundary

Config supplies canonical roots:

- `xa02_root`: must contain `tasks_public.json` and `evaluate.py`.
- `xa03_root`: must expose importable `ipm_xa03`.
- `xa04_root`: must expose importable `ipm_xa04`.

XA-06 never reads `reference_private.json`. XA-02 evaluator may read its own private references internally as designed.

## 5. Preflight

Preflight MUST run before the 36-trial pilot unless explicitly bypassed with a recorded override.

Checks:

1. dependency files/imports;
2. required public tasks exist;
3. provider configuration and required secret environment variable;
4. provider can return one response;
5. one `MATH-003/A0` trial executes through XA-04 and XA-03 in an isolated `preflight/` output tree;
6. XA-02 evaluator produces a `QualityRecord` if the model obeys output contract;
7. configured telemetry collectors can initialize/degrade according to XA-03 rules;
8. private sentinel is absent from captured/known experiment-visible request material;
9. output directory is writable.

Preflight success means the instrument can begin the pilot; it does not imply the model is good.

## 6. Model-State Isolation

Each `(task, condition, replicate)` gets a fresh provider adapter instance and fresh XA-04 trial state. No conversation history is carried across trials.

\[
\boxed{CrossTrialStateReuse=ProtocolViolation.}
\]

Stateless HTTP/command adapters satisfy this by construction in v0.1.

## 7. Real-Model Matrix

Order is deterministic by default:

```text
replicate 1:
  MATH-003 A0..A5
  CODE-001 A0..A5
  CON-003 A0..A5
replicate 2:
  MATH-003 A0..A5
  CODE-001 A0..A5
  CON-003 A0..A5
```

Optional randomized order may be added in later protocol versions; v0.1 prefers deterministic operational debugging.

## 8. Verifier and Tools

A3/A4/A5 use canonical XA-04 `SameModelVerifier`.

A4/A5 tool registry v0.1 contains `CalculatorTool` only by default. The task pack's code and constraint evaluator are NOT exposed as oracle tools.

Because XA-04 intentionally keeps the executor provider-agnostic, XA-06 wraps generator requests in A4/A5 with a minimal **tool-availability harness instruction** describing the calculator action envelope. This instruction is part of the A4/A5 scaffold treatment and is included in the request audit. A0-A3 receive no tool instruction.

If a model emits an unauthorized tool action in A0-A3, canonical XA-04 returns typed failure.

## 9. Code Evaluation Safety

XA-02 CODE evaluation executes generated code only if explicitly enabled. XA-06 config field:

```json
"allow_code_evaluation": false
```

is the safe default.

A pilot that wants real CODE-001 scoring must enable it only inside an appropriate OS/container sandbox. If disabled, CODE quality may be unavailable/evaluator-failed; that is reported rather than silently converted to zero.

## 10. Telemetry Profiles

Recommended local profile:

```json
"collectors": ["system", "nvidia_smi"],
"physical_boundary": "local-runner-plus-visible-accelerator"
```

Cloud/API profile:

```json
"collectors": ["null"],
"physical_boundary": "remote-provider-physical-cost-unknown"
```

Measured GPU energy is `device_energy_j`, not marginal energy.

## 11. Gate Metrics

Gate checks are engineering-validity checks, not hypotheses about scaffold direction.

Required:

- exactly 36 expected trial identities present;
- every trial has a terminal XA-04 result record;
- every result points to a corresponding XA-03 run directory and summary hash matches;
- 0 private-reference sentinel leak in request audit/config/public task material;
- 0 cross-condition duplicate trial IDs;
- normal-selection candidate accounting satisfies `created = selected + discarded`;
- execution counts are nonnegative and internally coherent;
- unauthorized A0-A3 tool execution count is 0;
- evaluator-quality availability rate is reported;
- output-contract compliance rate is reported;
- telemetry completeness/availability is reported, never fabricated;
- unknown physical metrics remain null;
- aggregate A0-A5 table is produced;
- SSR/SDR/SCM have no required direction.

Gate target:

- `terminal_trial_rate == 1.0`;
- `summary_hash_match_rate == 1.0`;
- `private_leak_count == 0`;
- `unauthorized_tool_execution_count == 0`;
- `accounting_mismatch_count == 0`;
- `quality_available_rate >= 0.95` for a `PASS` gate.

A lower quality-availability rate yields `FAIL` or `WARN` according to report, but raw trials are preserved.

## 12. Protocol Compliance

Per trial, report:

- final candidate exists;
- evaluator produced quality;
- task output contract heuristically satisfied;
- verifier/tool protocol failures;
- provider/runtime failures.

`ProtocolComplianceRate` is separate from task quality.

## 13. Analysis

Produce:

- `trial_index.csv`;
- `condition_summary.csv`;
- `physical_summary.csv`;
- `protocol_compliance.csv`;
- `aggregate.json`;
- `gate_summary.json`;
- `pilot_report.md`.

Report task-family/condition means but do not infer population-level intelligence from 3 tasks × 2 replicates.

## 14. Preflight/Pilot Separation

Preflight output lives under `preflight/`; pilot under `pilot/`. Preflight trial is excluded from 36-trial aggregate and must never collide with pilot trial paths.

## 15. Canonical CLI

```bash
python -m ipm_xa06.preflight --config config.json
python -m ipm_xa06.run_real_pilot --config config.json
python -m ipm_xa06.verify_gate --config config.json --run-dir <pilot-dir>
python -m ipm_xa06.analyze --config config.json --run-dir <pilot-dir>
```

One convenience entry point may execute preflight then pilot:

```bash
python -m ipm_xa06.cli run --config config.json
```

## 16. Release Status

The release package produced in an environment without a configured real provider MUST end with:

```text
READY_FOR_REAL_MODEL
```

and must contain no synthetic file labeled as a real-model result.

## 17. Canonical Principle

\[
\boxed{\textbf{No real model run, no real model claim.}}
\]

XA-06 is the gate that turns validated IPM instrumentation into empirical data without confusing readiness with observation.
