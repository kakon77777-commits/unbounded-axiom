# IPM v0.2 XA-06 Real-Model Pilot Gate Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans and superpowers:test-driven-development task-by-task.

**Goal:** Build a clean release that can preflight and execute 36 real-model XA trials through canonical XA-02/XA-03/XA-04, verify engineering validity, and analyze results without claiming data that was never measured.

**Architecture:** XA-06 is a thin orchestration/gate layer. It creates fresh canonical XA-04 providers per trial, invokes `TrialExecutor`, then validates and reports the resulting XA-03/XA-04 artifacts. It does not alter the canonical instrument.

**Tech Stack:** Python 3.11+ standard library, pytest; external canonical XA-02/XA-03/XA-04 roots.

**Spec:** `SPEC.md`

## Global Constraints

- Status is `READY_FOR_REAL_MODEL` until an actual 36-trial external provider run passes gate.
- No synthetic/mock result may be labeled real-model data.
- Task IDs are exactly MATH-003, CODE-001, CON-003.
- Conditions are exactly A0..A5; replicates exactly 1..2 for canonical XA-06.
- Provider instance is fresh per trial.
- XA-02 private references are never loaded by XA-06.
- A3/A4/A5 use canonical XA-04 SameModelVerifier.
- A4/A5 expose CalculatorTool only by default.
- Unknown physical cost remains null.

### Task 1 — Config and Provider Factory

Create `config.py`, `providers.py`, and tests. Test invalid provider mode, missing dependency roots, missing API-key env name/value, safe config redaction, fresh provider instances, decoding freeze, and that A1 `generation_budget_multiplier=2.0` doubles the HTTP token budget. Add A4/A5 tool-harness injection tests while A0-A3 remain unmodified. Implement only after RED.

### Task 2 — Preflight

Create `preflight.py` and tests. Test dependency checks, output-dir writability, one isolated MATH-003/A0 XA trial, status/result structure, and failed provider behavior. Never promote to real-pilot complete.

### Task 3 — 36-Trial Launcher

Create `run_real_pilot.py` and tests. Test exact 36 identities using deterministic test provider factory, fresh provider per trial, SameModelVerifier wiring for A3-A5, CalculatorTool wiring for A4-A5, separation of preflight/pilot output, and no synthetic-real status confusion.

### Task 4 — Gate Verifier

Create `verify_gate.py` and tests. Test exact identity set, terminal record rate, summary SHA verification, candidate accounting, unauthorized tool gate, quality-availability threshold, null physical values, and relocation-safe run-path resolution.

### Task 5 — Analysis/Reports

Create `analyze.py`, `report.py`, tests. Generate aggregate JSON and four CSV/Markdown outputs. Test SSR/SDR direction is not gated, null SCM propagation, protocol-compliance rate, and report interpretation boundary.

### Task 6 — CLI, Config Examples, Packaging

Create `cli.py`, README, local HTTP/command/cloud example configs, pyproject, validation report, manifest. Run full tests, local mock HTTP preflight integration, local command preflight integration, clean extraction tests, manifest verification, compileall, and compute ZIP SHA-256.

### Final Gate

Release status must be `READY_FOR_REAL_MODEL`. A separate real-run command is documented; no `REAL_MODEL_PILOT_COMPLETE` file/status is produced during package self-test.
