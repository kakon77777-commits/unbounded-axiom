from __future__ import annotations
from dataclasses import asdict
from pathlib import Path
import argparse, json, tempfile
from .config import PilotConfig, ConfigError
from .providers import build_harnessed_provider


def _write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")


def run_preflight(cfg: PilotConfig, *, provider_factory=build_harnessed_provider) -> dict:
    cfg.validate_dependency_paths(); cfg.validate_runtime_environment(); cfg.activate_dependencies()
    out=cfg.output_dir/"preflight"; out.mkdir(parents=True,exist_ok=True)
    # explicit writability check
    probe=out/".write_probe"; probe.write_text("ok",encoding="utf-8"); probe.unlink()
    _write_json(out/"config_redacted.json",cfg.redacted_dict())
    from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor
    pack=TaskPack(cfg.dependencies.xa02_root)
    for tid in cfg.experiment.tasks: pack.get(tid)
    evaluator=EvaluatorBridge(cfg.dependencies.xa02_root,allow_code_execution=cfg.evaluation.allow_code_evaluation)
    executor=TrialExecutor(pack,evaluator,xa03_root=cfg.dependencies.xa03_root,output_dir=out)
    provider=provider_factory(cfg.provider)
    result=executor.execute("MATH-003","A0",provider,replicate=99,collectors=cfg.telemetry.collectors,physical_boundary=cfg.telemetry.physical_boundary)
    audit=list(getattr(provider,"audit_records",[])); _write_json(out/"provider_audit.json",audit)
    q=result.quality
    status="PASS" if result.failure is None and q is not None and q.scalar_value is not None else "FAIL"
    report={
        "kind":"real_model_preflight",
        "status":status,
        "ready_for_real_model":status=="PASS",
        "real_model_pilot_complete":False,
        "quality_available":q is not None and q.scalar_value is not None,
        "quality_scalar":q.scalar_value if q is not None else None,
        "private_sentinel_leaks":sum(1 for x in audit if x.get("private_sentinel_detected")),
        "trial":asdict(result),
        "xa03_run_dir":result.xa03_run_dir,
        "provider_budget_control_valid":cfg.provider.mode in {"openai_compatible","cloud_openai_compatible"} or cfg.provider.budget_control_validated,
        "telemetry_collectors":list(cfg.telemetry.collectors),
        "physical_boundary":cfg.telemetry.physical_boundary,
    }
    if report["private_sentinel_leaks"]: report["status"]="FAIL"; report["ready_for_real_model"]=False
    _write_json(out/"preflight_summary.json",report)
    return report


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); a=ap.parse_args(argv)
    try: report=run_preflight(PilotConfig.from_file(a.config))
    except Exception as exc:
        print(json.dumps({"status":"FAIL","error_type":type(exc).__name__,"error":str(exc)},ensure_ascii=False)); return 2
    print(json.dumps(report,ensure_ascii=False,sort_keys=True)); return 0 if report["status"]=="PASS" else 1

if __name__=="__main__": raise SystemExit(main())
