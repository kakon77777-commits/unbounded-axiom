from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any
import json, os, sys

TASKS=("MATH-003","CODE-001","CON-003")
CONDITIONS=("A0","A1","A2","A3","A4","A5")

class ConfigError(ValueError): pass

def _resolve(base: Path, value: str) -> Path:
    p=Path(value)
    return p if p.is_absolute() else (base/p).resolve()

@dataclass(frozen=True)
class DependenciesConfig:
    xa02_root: Path
    xa03_root: Path
    xa04_root: Path

@dataclass(frozen=True)
class ProviderConfig:
    mode: str
    provider_id: str
    model_id: str
    timeout_s: float=120.0
    base_url: str|None=None
    auth_mode: str="none"
    api_key_env: str|None=None
    base_max_tokens: int=1024
    token_budget_field: str="max_tokens"
    temperature: float|None=0.2
    top_p: float|None=1.0
    seed: int|None=None
    command: tuple[str,...]=()
    extra_body: dict[str,Any]|None=None
    budget_control_validated: bool=False

@dataclass(frozen=True)
class TelemetryConfig:
    collectors: tuple[str,...]
    physical_boundary: str

@dataclass(frozen=True)
class EvaluationConfig:
    allow_code_evaluation: bool=False

@dataclass(frozen=True)
class ExperimentConfig:
    tasks: tuple[str,...]=TASKS
    conditions: tuple[str,...]=CONDITIONS
    replicates: int=2

@dataclass(frozen=True)
class PilotConfig:
    status: str
    dependencies: DependenciesConfig
    provider: ProviderConfig
    telemetry: TelemetryConfig
    evaluation: EvaluationConfig
    experiment: ExperimentConfig
    output_dir: Path
    source_path: Path|None=None

    @classmethod
    def from_file(cls, path: str|Path, *, validate_paths: bool=True) -> "PilotConfig":
        p=Path(path).resolve()
        return cls.from_dict(json.loads(p.read_text(encoding="utf-8")), base_dir=p.parent, validate_paths=validate_paths, source_path=p)

    @classmethod
    def from_dict(cls, data: dict, *, base_dir: str|Path, validate_paths: bool=True, source_path: Path|None=None) -> "PilotConfig":
        base=Path(base_dir).resolve()
        if data.get("status","READY_FOR_REAL_MODEL") != "READY_FOR_REAL_MODEL":
            raise ConfigError("config status must be READY_FOR_REAL_MODEL")
        d=data.get("dependencies") or {}
        try:
            deps=DependenciesConfig(*[_resolve(base,d[k]) for k in ("xa02_root","xa03_root","xa04_root")])
        except KeyError as exc: raise ConfigError(f"missing dependency path: {exc.args[0]}") from exc
        p=data.get("provider") or {}; mode=p.get("mode")
        if mode not in {"openai_compatible","cloud_openai_compatible","local_command"}:
            raise ConfigError(f"unsupported provider mode: {mode}")
        cmd=tuple(str(x) for x in p.get("command",()))
        pc=ProviderConfig(
            mode=mode,provider_id=str(p.get("provider_id") or mode),model_id=str(p.get("model_id") or ""),timeout_s=float(p.get("timeout_s",120)),
            base_url=p.get("base_url"),auth_mode=str(p.get("auth_mode","none")),api_key_env=p.get("api_key_env"),
            base_max_tokens=int(p.get("base_max_tokens",1024)),token_budget_field=str(p.get("token_budget_field","max_tokens")),
            temperature=p.get("temperature",0.2),top_p=p.get("top_p",1.0),seed=p.get("seed"),command=cmd,extra_body=dict(p.get("extra_body") or {}),budget_control_validated=bool(p.get("budget_control_validated",False))
        )
        if not pc.model_id: raise ConfigError("provider.model_id is required")
        if pc.mode in {"openai_compatible","cloud_openai_compatible"} and not pc.base_url: raise ConfigError("provider.base_url is required for HTTP mode")
        if pc.auth_mode not in {"none","bearer_env"}: raise ConfigError("provider.auth_mode must be none or bearer_env")
        if pc.auth_mode=="bearer_env" and not pc.api_key_env: raise ConfigError("provider.api_key_env is required for bearer_env")
        if pc.base_max_tokens <= 0: raise ConfigError("base_max_tokens must be positive")
        if pc.mode=="local_command" and not pc.command: raise ConfigError("provider.command is required for local_command")
        t=data.get("telemetry") or {}; tc=TelemetryConfig(tuple(t.get("collectors") or ["null"]),str(t.get("physical_boundary","unknown")))
        e=data.get("evaluation") or {}; ec=EvaluationConfig(bool(e.get("allow_code_evaluation",False)))
        x=data.get("experiment") or {}; xc=ExperimentConfig(tuple(x.get("tasks") or TASKS),tuple(x.get("conditions") or CONDITIONS),int(x.get("replicates",2)))
        if xc.tasks != TASKS: raise ConfigError(f"XA-06 canonical tasks must be {TASKS}")
        if xc.conditions != CONDITIONS: raise ConfigError(f"XA-06 canonical conditions must be {CONDITIONS}")
        if xc.replicates != 2: raise ConfigError("XA-06 canonical replicates must equal 2")
        out=_resolve(base,str(data.get("output_dir","xa06_output")))
        obj=cls("READY_FOR_REAL_MODEL",deps,pc,tc,ec,xc,out,source_path)
        if validate_paths: obj.validate_dependency_paths()
        return obj

    def validate_dependency_paths(self) -> None:
        req=[self.dependencies.xa02_root/"tasks_public.json",self.dependencies.xa02_root/"evaluate.py",self.dependencies.xa03_root/"ipm_xa03",self.dependencies.xa04_root/"ipm_xa04"]
        missing=[str(p) for p in req if not p.exists()]
        if missing: raise ConfigError("missing canonical dependency paths: "+", ".join(missing))

    def validate_runtime_environment(self) -> None:
        if self.provider.auth_mode=="bearer_env" and not os.environ.get(str(self.provider.api_key_env)):
            raise ConfigError(f"missing provider secret environment variable: {self.provider.api_key_env}")

    def activate_dependencies(self) -> None:
        for p in (self.dependencies.xa04_root,self.dependencies.xa03_root):
            s=str(p)
            if s not in sys.path: sys.path.insert(0,s)

    def redacted_dict(self) -> dict:
        def enc(v):
            if isinstance(v,Path): return str(v)
            if isinstance(v,tuple): return [enc(x) for x in v]
            if isinstance(v,dict): return {k:enc(x) for k,x in v.items()}
            return v
        d=enc(asdict(self)); d.pop("source_path",None)
        return d
