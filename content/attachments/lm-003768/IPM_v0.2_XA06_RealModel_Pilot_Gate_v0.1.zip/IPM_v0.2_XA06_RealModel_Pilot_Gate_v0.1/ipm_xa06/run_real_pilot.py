from __future__ import annotations
from pathlib import Path
from dataclasses import asdict, is_dataclass
import argparse, json
from .config import PilotConfig
from .providers import build_harnessed_provider


def _write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

def _result_index(r):
    q=getattr(r,"quality",None)
    return {"trial_id":r.trial_id,"task_id":r.task_id,"condition":r.condition,"replicate":r.replicate,"failure":getattr(r,"failure",None),"quality_available":bool(q is not None and getattr(q,"scalar_value",None) is not None),"xa03_run_dir":str(getattr(r,"xa03_run_dir",""))}

def _default_provider_factory(pc, **context): return build_harnessed_provider(pc)

def run_pilot(cfg: PilotConfig, *, provider_factory=_default_provider_factory, executor=None, engineering_validation_only: bool=False) -> dict:
    if executor is None:
        cfg.validate_dependency_paths(); cfg.validate_runtime_environment(); cfg.activate_dependencies()
        from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor
        pack=TaskPack(cfg.dependencies.xa02_root)
        evaluator=EvaluatorBridge(cfg.dependencies.xa02_root,allow_code_execution=cfg.evaluation.allow_code_evaluation)
        executor=TrialExecutor(pack,evaluator,xa03_root=cfg.dependencies.xa03_root,output_dir=cfg.output_dir/"pilot")
    else:
        # Test/engineering injection only; production CLI never supplies this.
        cfg.activate_dependencies() if cfg.dependencies.xa04_root.exists() else None
    from ipm_xa04 import SameModelVerifier, CalculatorTool, ToolRegistry
    pilot=cfg.output_dir/"pilot"; pilot.mkdir(parents=True,exist_ok=True)
    existing=pilot/"trial_results"
    if not engineering_validation_only and existing.exists() and any(existing.glob("*.json")):
        raise RuntimeError(f"pilot output already contains trial results: {existing}")
    _write_json(pilot/"config_redacted.json",cfg.redacted_dict())
    results=[]; audits=[]; provider_instances=[]
    for rep in range(1,cfg.experiment.replicates+1):
        for task_id in cfg.experiment.tasks:
            for condition in cfg.experiment.conditions:
                provider=provider_factory(cfg.provider,task_id=task_id,condition=condition,replicate=rep)
                provider_instances.append(provider)
                verifier=SameModelVerifier() if condition in {"A3","A4","A5"} else None
                tools=ToolRegistry([CalculatorTool()])
                r=executor.execute(task_id,condition,provider,replicate=rep,verifier=verifier,tools=tools,collectors=cfg.telemetry.collectors,physical_boundary=cfg.telemetry.physical_boundary)
                results.append(r)
                for rec in getattr(provider,"audit_records",[]): audits.append({"trial_id":r.trial_id,**rec})
    _write_json(pilot/"provider_audit.json",audits)
    index=[_result_index(r) for r in results]; _write_json(pilot/"matrix_index.json",index)
    failures=sum(1 for r in results if getattr(r,"failure",None) is not None)
    status="ENGINEERING_VALIDATION_COMPLETE" if engineering_validation_only else "REAL_MODEL_RUN_COMPLETE_UNVERIFIED"
    summary={"kind":"engineering_validation_only" if engineering_validation_only else "real_model_pilot_run","status":status,"engineering_validation_only":engineering_validation_only,"real_model_pilot_complete":False,"trial_count":len(results),"failure_count":failures,"fresh_provider_instances":len({id(p) for p in provider_instances}),"expected_trial_count":36,"provider_id":cfg.provider.provider_id,"model_id":cfg.provider.model_id,"tasks":list(cfg.experiment.tasks),"conditions":list(cfg.experiment.conditions),"replicates":cfg.experiment.replicates,"pilot_dir":str(pilot)}
    _write_json(pilot/"pilot_run_summary.json",summary)
    return summary


def main(argv=None) -> int:
    ap=argparse.ArgumentParser(); ap.add_argument("--config",required=True); a=ap.parse_args(argv)
    try: s=run_pilot(PilotConfig.from_file(a.config))
    except Exception as exc:
        print(json.dumps({"status":"FAIL","error_type":type(exc).__name__,"error":str(exc)},ensure_ascii=False)); return 2
    print(json.dumps(s,ensure_ascii=False,sort_keys=True)); return 0
if __name__=="__main__": raise SystemExit(main())
