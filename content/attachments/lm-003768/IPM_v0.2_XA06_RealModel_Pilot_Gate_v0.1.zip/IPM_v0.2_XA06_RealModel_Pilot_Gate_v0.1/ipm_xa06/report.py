from __future__ import annotations

def _fmt(v, digits=6):
    if v is None: return "null"
    if isinstance(v,float): return f"{v:.{digits}f}"
    return str(v)

def render_report(report: dict) -> str:
    eng=bool(report.get("engineering_validation_only"))
    title="# IPM v0.2 XA-06 — Real-Model Pilot Report"
    boundary=("> **ENGINEERING VALIDATION — not a real-model scientific result.**" if eng else "> **REAL-MODEL PILOT — exploratory only; not a population-level intelligence benchmark.**")
    if eng: boundary += "\n> This dataset is not a real-model scientific result and exists only to validate the XA-06 analysis path."
    a=report.get("aggregate",{})
    lines=[title,"",boundary,"","## Summary","",
           f"- Trials: **{report.get('trial_count')}**",
           f"- Protocol compliance rate: **{_fmt(report.get('protocol_compliance_rate'))}**",
           f"- Quality available rate: **{_fmt(report.get('quality_available_rate'))}**",
           f"- SSR: **{_fmt(a.get('ssr'))}**",
           f"- SDR: **{_fmt(a.get('sdr'))}**",
           f"- Device-energy SCM: **{_fmt((a.get('scm') or {}).get('device_energy_j'))}**","",
           "## Condition Summary","","| Condition | n | Mean quality | Mean wall time (s) | Mean device energy (J) |","|---|---:|---:|---:|---:|"]
    for cond in ("A0","A1","A2","A3","A4","A5"):
        row=(a.get("conditions") or {}).get(cond,{})
        lines.append(f"| {cond} | {row.get('n','')} | {_fmt(row.get('quality_mean'))} | {_fmt(row.get('wall_time_mean'))} | {_fmt(row.get('device_energy_mean'))} |")
    lines += ["","## Interpretation Boundary","",
              "XA-06 contains only three tasks and two replicates per condition. It is a real-model instrument gate and exploratory pilot, not a population-level estimate of intelligence.",
              "No gate rule requires scaffolding to improve quality. A3/A5 may be worse than A2/A0 and still constitute valid empirical observations.",
              "Unknown physical quantities remain null; device-measured energy is not marginal energy.",""]
    return "\n".join(lines)
