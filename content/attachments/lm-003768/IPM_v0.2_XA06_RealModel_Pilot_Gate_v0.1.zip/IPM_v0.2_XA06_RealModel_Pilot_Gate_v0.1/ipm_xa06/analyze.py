from __future__ import annotations
from pathlib import Path
import argparse, ast, csv, json, sys
from statistics import mean
from .report import render_report

CONDS=("A0","A1","A2","A3","A4","A5")

def _load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def _avg(vals):
    vals=[v for v in vals if v is not None]
    return mean(vals) if vals else None

def _quality_available(tr:dict) -> bool:
    q=tr.get("quality")
    if q is None or q.get("scalar_value") is None: return False
    if str(tr.get("task_id","")).startswith("CODE-") and (q.get("vector") or {}).get("execution_allowed")==0: return False
    return True

def _contract_ok(tr:dict) -> bool:
    text=tr.get("candidate_text")
    if not isinstance(text,str) or not text.strip(): return False
    tid=tr.get("task_id","")
    if tid.startswith("MATH-") or tid.startswith("CON-"):
        try: return isinstance(json.loads(text.strip()),dict)
        except Exception: return False
    if tid=="CODE-001":
        try:
            tree=ast.parse(text)
            return any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name=="normalize_whitespace" for n in tree.body)
        except Exception: return False
    return True

def analyze_pilot(run_dir: str|Path, *, xa04_root: str|Path) -> dict:
    root=Path(run_dir); xa04=Path(xa04_root)
    s=str(xa04)
    if s not in sys.path: sys.path.insert(0,s)
    from ipm_xa04.aggregator import aggregate_trials
    files=sorted((root/"trial_results").glob("*.json")); records=[_load(p) for p in files]
    # Do not let "code execution not authorized" masquerade as measured zero quality.
    sanitized=[]
    for r in records:
        x=dict(r)
        if not _quality_available(r): x["quality"]=None
        sanitized.append(x)
    aggregate=aggregate_trials(sanitized)
    meta=_load(root/"pilot_run_summary.json") if (root/"pilot_run_summary.json").exists() else {}
    compliance=[]; qn=0
    trial_rows=[]
    for r in records:
        q=r.get("quality"); qavail=_quality_available(r)
        qn+=int(qavail); cok=_contract_ok(r)
        compliance.append(cok)
        ssum=r.get("xa03_summary") or {}; exe=ssum.get("execution") or {}; phy=ssum.get("physical") or {}; mea=ssum.get("measurement") or {}
        trial_rows.append({"trial_id":r.get("trial_id"),"task_id":r.get("task_id"),"condition":r.get("condition"),"replicate":r.get("replicate"),"failure_type":(r.get("failure") or {}).get("type"),"quality":q.get("scalar_value") if q else None,"hard_gate":q.get("hard_gate") if q else None,"output_contract_compliant":cok,"wall_time_s":exe.get("wall_time_s"),"device_energy_j":phy.get("device_energy_j"),"gpu_peak_memory_bytes":phy.get("gpu_peak_memory_bytes"),"gpu_memory_residency_byte_s":phy.get("gpu_memory_residency_byte_s"),"gpu_utilization_integral_s":phy.get("gpu_utilization_integral_s"),"telemetry_complete":mea.get("telemetry_complete")})
    n=len(records); report={"kind":"engineering_validation_only" if meta.get("engineering_validation_only") else "real_model_pilot_exploratory","engineering_validation_only":bool(meta.get("engineering_validation_only")),"trial_count":n,"protocol_compliance_rate":sum(compliance)/n if n else 0.0,"quality_available_rate":qn/n if n else 0.0,"aggregate":aggregate}
    # condition physical extension
    physical={}
    for c in CONDS:
        rs=[x for x in trial_rows if x["condition"]==c]
        physical[c]={"n":len(rs),"wall_time_mean":_avg([x["wall_time_s"] for x in rs]),"device_energy_n":sum(x["device_energy_j"] is not None for x in rs),"device_energy_mean":_avg([x["device_energy_j"] for x in rs]),"gpu_peak_memory_mean":_avg([x["gpu_peak_memory_bytes"] for x in rs]),"gpu_memory_residency_mean":_avg([x["gpu_memory_residency_byte_s"] for x in rs]),"gpu_utilization_integral_mean":_avg([x["gpu_utilization_integral_s"] for x in rs]),"telemetry_complete_rate":_avg([1.0 if x["telemetry_complete"] else 0.0 if x["telemetry_complete"] is False else None for x in rs])}
    report["physical_by_condition"]=physical
    (root/"aggregate.json").write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")
    def write_csv(name,rows,fields):
        with (root/name).open("w",newline="",encoding="utf-8") as f:
            w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    write_csv("trial_index.csv",trial_rows,list(trial_rows[0].keys()) if trial_rows else ["trial_id"])
    cond_rows=[]
    for c in CONDS:
        a=(aggregate.get("conditions") or {}).get(c,{})
        cond_rows.append({"condition":c,"n":a.get("n"),"quality_mean":a.get("quality_mean"),"quality_median":a.get("quality_median"),"success_rate":a.get("success_rate"),"wall_time_mean":a.get("wall_time_mean"),"device_energy_mean":a.get("device_energy_mean"),"allocated_device_time_mean":a.get("allocated_device_time_mean")})
    write_csv("condition_summary.csv",cond_rows,list(cond_rows[0]))
    phys_rows=[{"condition":c,**physical[c]} for c in CONDS]; write_csv("physical_summary.csv",phys_rows,list(phys_rows[0]))
    comp_rows=[{"trial_id":x["trial_id"],"task_id":x["task_id"],"condition":x["condition"],"replicate":x["replicate"],"output_contract_compliant":x["output_contract_compliant"],"quality_available":x["quality"] is not None,"failure_type":x["failure_type"]} for x in trial_rows]
    write_csv("protocol_compliance.csv",comp_rows,list(comp_rows[0]) if comp_rows else ["trial_id"])
    (root/"pilot_report.md").write_text(render_report(report),encoding="utf-8")
    return report

def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument("--run-dir",required=True); ap.add_argument("--config",required=True); a=ap.parse_args(argv)
    from .config import PilotConfig
    cfg=PilotConfig.from_file(a.config); r=analyze_pilot(a.run_dir,xa04_root=cfg.dependencies.xa04_root); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0
if __name__=="__main__": raise SystemExit(main())
