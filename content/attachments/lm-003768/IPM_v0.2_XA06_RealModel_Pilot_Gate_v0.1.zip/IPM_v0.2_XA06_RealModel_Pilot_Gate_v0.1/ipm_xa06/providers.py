from __future__ import annotations
from dataclasses import replace
from typing import Any
from urllib.request import Request, urlopen
import hashlib, json, os, subprocess
from .config import ProviderConfig, ConfigError

SENTINEL="XA02_PRIVATE_SENTINEL_DO_NOT_LEAK"
TOOL_INSTRUCTION='''\n\n[XA-06 TOOL HARNESS]\nFor this condition, the calculator tool is available. If you need it, return ONLY JSON in this form: {"action":"tool","tool":"calculator","input":{"expression":"1+2"}}. After a tool observation, continue solving and return the task's requested final output. You may also answer directly without using the tool.\n'''

class ConfiguredHTTPProvider:
    def __init__(self, cfg: ProviderConfig):
        self.cfg=cfg; self.provider_id=cfg.provider_id; self.model_id=cfg.model_id
    def generate(self, request):
        from ipm_xa04.models import GenerationResult
        payload=dict(self.cfg.extra_body or {})
        # Controlled experiment fields win over arbitrary extra_body values.
        payload.update({"model":self.model_id,"messages":[{"role":"user","content":request.prompt}]})
        payload[self.cfg.token_budget_field]=max(1,int(round(self.cfg.base_max_tokens*request.generation_budget_multiplier)))
        if self.cfg.temperature is not None: payload["temperature"]=self.cfg.temperature
        if self.cfg.top_p is not None: payload["top_p"]=self.cfg.top_p
        if self.cfg.seed is not None: payload["seed"]=self.cfg.seed
        headers={"Content-Type":"application/json"}
        if self.cfg.auth_mode=="bearer_env":
            key=os.environ.get(str(self.cfg.api_key_env))
            if not key: raise RuntimeError(f"missing API key environment variable: {self.cfg.api_key_env}")
            headers["Authorization"]="Bearer "+key
        req=Request(self.cfg.base_url.rstrip("/")+"/v1/chat/completions",data=json.dumps(payload).encode(),headers=headers,method="POST")
        with urlopen(req,timeout=self.cfg.timeout_s) as resp: data=json.loads(resp.read().decode())
        try: text=data["choices"][0]["message"]["content"]
        except Exception as exc: raise RuntimeError("invalid OpenAI-compatible response") from exc
        return GenerationResult(str(text),request_id=data.get("id"),usage=data.get("usage"),metadata={"budget_tokens":payload[self.cfg.token_budget_field]})

class ConfiguredLocalCommandProvider:
    def __init__(self,cfg:ProviderConfig): self.cfg=cfg; self.provider_id=cfg.provider_id; self.model_id=cfg.model_id
    def generate(self,request):
        from ipm_xa04.models import GenerationResult
        env=os.environ.copy(); env.update({"IPM_CONDITION":request.condition,"IPM_TASK_ID":request.task_id,"IPM_ROLE":request.role,"IPM_GENERATION_BUDGET_MULTIPLIER":str(request.generation_budget_multiplier),"IPM_BASE_MAX_TOKENS":str(self.cfg.base_max_tokens)})
        cp=subprocess.run(self.cfg.command,input=request.prompt,text=True,capture_output=True,timeout=self.cfg.timeout_s,env=env)
        if cp.returncode!=0: raise RuntimeError(f"local provider failed rc={cp.returncode}: {cp.stderr.strip()}")
        return GenerationResult(cp.stdout,metadata={"budget_control_valid":bool(self.cfg.budget_control_validated),"budget_multiplier_exposed_via_env":True})

class HarnessedProvider:
    def __init__(self,base):
        self.base=base; self.provider_id=base.provider_id; self.model_id=base.model_id; self.audit_records=[]
    def generate(self,request):
        prompt=request.prompt
        injected=False
        if request.role=="generator" and request.condition in {"A4","A5"}:
            prompt=prompt+TOOL_INSTRUCTION; injected=True
        forwarded=replace(request,prompt=prompt)
        audit={"role":request.role,"condition":request.condition,"task_id":request.task_id,"generation_budget_multiplier":request.generation_budget_multiplier,"prompt_sha256":hashlib.sha256(prompt.encode()).hexdigest(),"tool_harness_injected":injected,"private_sentinel_detected":SENTINEL in prompt}
        try:
            res=self.base.generate(forwarded); audit["ok"]=True; audit["request_id"]=getattr(res,"request_id",None); return res
        except Exception as exc:
            audit["ok"]=False; audit["error_type"]=type(exc).__name__; raise
        finally:
            self.audit_records.append(audit)


def build_provider(cfg: ProviderConfig):
    if cfg.mode in {"openai_compatible","cloud_openai_compatible"}: return ConfiguredHTTPProvider(cfg)
    if cfg.mode=="local_command": return ConfiguredLocalCommandProvider(cfg)
    raise ConfigError(f"unsupported provider mode: {cfg.mode}")

def build_harnessed_provider(cfg: ProviderConfig): return HarnessedProvider(build_provider(cfg))
