from __future__ import annotations
from pathlib import Path
import argparse, hashlib, json

TASKS=("MATH-003","CODE-001","CON-003")
CONDS=("A0","A1","A2","A3","A4","A5")

def _sha(p:Path): return hashlib.sha256(p.read_bytes()).hexdigest()
def _load(p:Path): return json.loads(p.read_text(encoding="utf-8"))

def expected_identities(): return {(t,c,r) for r in (1,2) for t in TASKS for c in CONDS}

def _quality_available(tr: dict) -> bool:
    q=tr.get("quality")
    if q is None or q.get("scalar_value") is None: return False
    if str(tr.get("task_id","")).startswith("CODE-") and (q.get("vector") or {}).get("execution_allowed")==0: return False
    return True

def _audit_leaks(path:Path):
    if not path.exists(): return 0
    rows=_load(path); n=0
    for row in rows:
        if row.get("private_sentinel_detected"): n+=1
        for req in row.get("requests",[]):
            if req.get("private_sentinel_detected") or "XA02_PRIVATE_SENTINEL_DO_NOT_LEAK" in str(req.get("prompt","")): n+=1
    return n

def verify_gate(run_dir: str|Path, *, write: bool=True) -> dict:
    root=Path(run_dir)
    trial_files=sorted((root/"trial_results").glob("*.json")) if (root/"trial_results").exists() else []
    pilot_meta=_load(root/"pilot_run_summary.json") if (root/"pilot_run_summary.json").exists() else {}
    actual_ids=[]; hash_matches=0; terminal=0; quality_n=0; account_mismatch=[]; unauthorized=[]; energy_measured=0; telemetry_complete=0; failures=0
    summaries=[]
    for tf in trial_files:
        tr=_load(tf); actual_ids.append((tr.get("task_id"),tr.get("condition"),tr.get("replicate")))
        if tr.get("failure") is not None: failures+=1
        local=root/"xa03_runs"/str(tr.get("trial_id"))
        rd=local if local.exists() else Path(str(tr.get("xa03_run_dir","")))
        sp=rd/"summary.json"
        if not sp.exists():
            account_mismatch.append({"trial_id":tr.get("trial_id"),"type":"missing_summary"}); continue
        if _sha(sp)==tr.get("xa03_summary_sha256"): hash_matches+=1
        s=_load(sp); summaries.append(s)
        if (s.get("run") or {}).get("state") in {"COMPLETE","ABORTED"}: terminal+=1
        q=tr.get("quality")
        if _quality_available(tr): quality_n+=1
        e=s.get("execution") or {}
        pairs=[("model_invocations_started","model_invocations_completed"),("trajectories_started","trajectories_completed"),("retries_started","retries_completed"),("tool_calls_started","tool_calls_completed"),("verifier_passes_started","verifier_passes_completed")]
        bad=False
        for a,b in pairs:
            x,y=e.get(a),e.get(b)
            if not isinstance(x,(int,float)) or not isinstance(y,(int,float)) or x<0 or y<0 or y>x: bad=True
        created=e.get("candidates_created",0); selected=e.get("candidates_selected",0); discarded=e.get("candidates_discarded",0)
        if any(not isinstance(v,(int,float)) or v<0 for v in (created,selected,discarded)): bad=True
        if tr.get("failure") is None and tr.get("selected_candidate_id") is not None and created != selected+discarded: bad=True
        if bad: account_mismatch.append({"trial_id":tr.get("trial_id"),"type":"execution_accounting"})
        if tr.get("condition") in {"A0","A1","A2","A3"} and e.get("tool_calls_started",0)>0: unauthorized.append(tr.get("trial_id"))
        p=s.get("physical") or {}; m=s.get("measurement") or {}
        if p.get("device_energy_j") is not None: energy_measured+=1
        if m.get("telemetry_complete") is True: telemetry_complete+=1
    expected=expected_identities(); actual=set(actual_ids)
    n=len(trial_files); quality_rate=quality_n/n if n else 0.0; hash_rate=hash_matches/n if n else 0.0; terminal_rate=terminal/n if n else 0.0
    leak_count=_audit_leaks(root/"provider_audit.json")
    checks={
      "exact_trial_identity_set": n==36 and actual==expected and len(actual_ids)==len(actual),
      "terminal_trial_rate": terminal_rate==1.0,
      "summary_hash_match_rate": hash_rate==1.0,
      "private_leak_count": leak_count==0,
      "unauthorized_tool_execution_count": len(unauthorized)==0,
      "accounting_mismatch_count": len(account_mismatch)==0,
      "quality_available_rate": quality_rate>=0.95,
    }
    gate_pass=all(checks.values())
    engineering=bool(pilot_meta.get("engineering_validation_only"))
    if engineering: status="ENGINEERING_VALIDATION_PASS" if gate_pass else "ENGINEERING_VALIDATION_FAIL"
    else: status="REAL_MODEL_PILOT_COMPLETE" if gate_pass else "REAL_MODEL_PILOT_FAILED"
    report={
      "status":status,"gate_pass":gate_pass,"real_model_pilot_complete":bool(gate_pass and not engineering),"engineering_validation_only":engineering,
      "trial_count":n,"expected_trial_count":36,"distinct_identity_count":len(actual),"missing_identities":[list(x) for x in sorted(expected-actual)],"unexpected_identities":[list(x) for x in sorted(actual-expected)],
      "terminal_trial_rate":terminal_rate,"summary_hash_match_rate":hash_rate,"quality_available_rate":quality_rate,"quality_available_count":quality_n,
      "private_leak_count":leak_count,"unauthorized_tool_execution_count":len(unauthorized),"unauthorized_tool_trials":unauthorized,"accounting_mismatch_count":len(account_mismatch),"accounting_mismatches":account_mismatch,
      "trial_failure_count":failures,"device_energy_measured_trial_count":energy_measured,"telemetry_complete_trial_count":telemetry_complete,
      "checks":checks,
      "interpretation_boundary":"XA-06 is a 3-task real-model pilot gate, not a population-level intelligence benchmark. SSR/SDR/SCM direction is not a gate criterion."
    }
    if write: (root/"gate_summary.json").write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")
    return report

def main(argv=None):
    ap=argparse.ArgumentParser(); ap.add_argument("--run-dir",required=True); ap.add_argument("--config"); a=ap.parse_args(argv)
    r=verify_gate(a.run_dir); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0 if r["gate_pass"] else 1
if __name__=="__main__": raise SystemExit(main())
