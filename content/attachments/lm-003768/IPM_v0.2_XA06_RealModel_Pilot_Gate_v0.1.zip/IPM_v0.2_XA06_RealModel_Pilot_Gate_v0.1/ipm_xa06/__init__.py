"""IPM XA-06 real-model pilot gate."""
from .config import PilotConfig, ConfigError

__all__ = ["PilotConfig", "ConfigError"]
