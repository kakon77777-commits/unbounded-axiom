from __future__ import annotations
import argparse, json
from pathlib import Path
from .config import PilotConfig

def main(argv=None):
    ap=argparse.ArgumentParser(prog="ipm-xa06"); sub=ap.add_subparsers(dest="cmd",required=True)
    for name in ("status","preflight","run","verify","analyze"):
        p=sub.add_parser(name); p.add_argument("--config",required=True)
        if name in {"verify","analyze"}: p.add_argument("--run-dir")
    a=ap.parse_args(argv); cfg=PilotConfig.from_file(a.config)
    if a.cmd=="status":
        out={"status":"READY_FOR_REAL_MODEL","real_model_pilot_complete":False,"model_id":cfg.provider.model_id,"provider_mode":cfg.provider.mode,"canonical_trial_count":36,"budget_control_valid":cfg.provider.mode in {"openai_compatible","cloud_openai_compatible"} or cfg.provider.budget_control_validated}
        print(json.dumps(out,ensure_ascii=False,sort_keys=True)); return 0
    if a.cmd=="preflight":
        from .preflight import run_preflight
        r=run_preflight(cfg); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0 if r["status"]=="PASS" else 1
    run_dir=Path(getattr(a,"run_dir",None) or (cfg.output_dir/"pilot"))
    if a.cmd=="verify":
        from .verify_gate import verify_gate
        r=verify_gate(run_dir); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0 if r["gate_pass"] else 1
    if a.cmd=="analyze":
        from .analyze import analyze_pilot
        r=analyze_pilot(run_dir,xa04_root=cfg.dependencies.xa04_root); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0
    if a.cmd=="run":
        from .preflight import run_preflight
        from .run_real_pilot import run_pilot
        from .verify_gate import verify_gate
        from .analyze import analyze_pilot
        pre=run_preflight(cfg)
        if pre["status"]!="PASS": print(json.dumps({"status":"PREFLIGHT_FAILED","preflight":pre},ensure_ascii=False)); return 1
        run=run_pilot(cfg); gate=verify_gate(cfg.output_dir/"pilot"); analysis=analyze_pilot(cfg.output_dir/"pilot",xa04_root=cfg.dependencies.xa04_root)
        out={"status":gate["status"],"preflight":pre["status"],"run":run,"gate":gate,"analysis_file":str(cfg.output_dir/"pilot"/"aggregate.json")}
        print(json.dumps(out,ensure_ascii=False,sort_keys=True)); return 0 if gate["gate_pass"] else 1
    return 2

if __name__=="__main__": raise SystemExit(main())
