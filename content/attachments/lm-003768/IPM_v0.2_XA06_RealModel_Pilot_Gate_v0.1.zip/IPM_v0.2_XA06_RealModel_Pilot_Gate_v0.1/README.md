# IPM v0.2 XA-06 — Real-Model Pilot Gate

**Release status: `READY_FOR_REAL_MODEL`**

XA-06 is the first IPM artifact intended to place a real model inside the validated XA-01→XA-04 instrument. This package contains no claimed real-model pilot result.

## Canonical matrix

`MATH-003`, `CODE-001`, `CON-003` × `A0..A5` × 2 replicates = **36 trials/model**.

## Recommended local-first path

Use an OpenAI-compatible server on the same machine as the visible accelerator when possible. Copy and edit:

```text
examples/config.local_openai_compatible.example.json
```

The `base_url` is the server root before `/v1/chat/completions` (for example `http://127.0.0.1:1234`). XA-06 forwards the A0/A1 generation-budget multiplier into the configured token-budget field, and freezes temperature/top-p/seed from config.

### 1. Preflight

```bash
python -m ipm_xa06.cli preflight --config my_xa06_config.json
```

This runs one isolated `MATH-003/A0` trial through the real provider, XA-03, and XA-02 evaluator.

### 2. Full 36-trial pilot

```bash
python -m ipm_xa06.cli run --config my_xa06_config.json
```

The command performs preflight first. It then runs the matrix, verifies the gate, and writes analysis outputs.

### 3. Re-verify / re-analyze

```bash
python -m ipm_xa06.cli verify --config my_xa06_config.json
python -m ipm_xa06.cli analyze --config my_xa06_config.json
```

## Local command provider

`local_command` receives the prompt on stdin. XA-06 exports these environment variables to the child process:

- `IPM_CONDITION`
- `IPM_TASK_ID`
- `IPM_ROLE`
- `IPM_GENERATION_BUDGET_MULTIPLIER`
- `IPM_BASE_MAX_TOKENS`

Set `budget_control_validated=true` only if your command wrapper actually enforces the multiplier. Otherwise A1 remains operationally runnable but cannot be interpreted as a validated 2× generation-budget treatment.

## Tool harness

For A4/A5 generator requests XA-06 appends the calculator action contract. A0-A3 receive no tool instruction. This is part of the scaffold treatment, not hidden model information.

## Code-evaluation safety

`allow_code_evaluation` defaults to `false`. XA-02 will not execute generated Python unless explicitly authorized. XA-06 treats `execution_allowed=0` as **quality unavailable**, not as measured zero code quality.

Only enable code evaluation inside an appropriate OS/container sandbox. The evaluator's subprocess timeout is not a complete sandbox.

## Physical telemetry

Recommended local config:

```json
{"collectors":["system","nvidia_smi"],"physical_boundary":"local-runner-plus-visible-accelerator"}
```

This may provide device power/VRAM/utilization telemetry. `device_energy_j` is measured device energy, **not marginal energy**. On a remote/cloud provider use `NullCollector` unless the provider supplies independently grounded physical telemetry.

## Gate meaning

A real pilot may produce `REAL_MODEL_PILOT_COMPLETE` only after 36 real-provider terminal trials pass the engineering gate. The gate does **not** require scaffolding to improve quality.

Valid real outcomes include:

- A0 = A5;
- A3 < A2;
- A5 < A0;
- SSR = 1;
- tool/verifier degradation.

XA-06 is still only a three-task, two-replicate pilot. It is not a population-level intelligence benchmark.

## Canonical dependencies

XA-06 expects external canonical XA-02, XA-03, and XA-04 roots and does not vendor modified copies.

## Core rule

> **No real model run, no real model claim.**
