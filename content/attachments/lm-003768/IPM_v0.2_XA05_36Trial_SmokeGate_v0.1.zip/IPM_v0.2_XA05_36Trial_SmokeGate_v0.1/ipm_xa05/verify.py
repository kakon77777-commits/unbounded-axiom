from __future__ import annotations
from pathlib import Path
import hashlib, json

SENTINEL="XA02_PRIVATE_SENTINEL_DO_NOT_LEAK"
EXPECTED_TOTALS={"model":180,"trajectory":168,"retry":6,"tool":6,"verifier":24,"created":168,"selected":36,"discarded":132}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_canonical_output(root: str|Path) -> dict:
    root=Path(root)
    report=json.loads((root/"smoke_report.json").read_text(encoding="utf-8"))
    gate=json.loads((root/"gate_summary.json").read_text(encoding="utf-8"))
    trial_files=sorted((root/"trial_results").glob("*.json"))
    run_dirs=sorted(p for p in (root/"xa03_runs").iterdir() if p.is_dir())
    mismatches=[]; noncomplete=[]; energy_nonnull=[]
    for tf in trial_files:
        tr=json.loads(tf.read_text(encoding="utf-8"))
        # Canonical output may have been moved/extracted. Prefer the run stored inside
        # the artifact being verified; only fall back to the historical absolute path
        # when no local run directory exists. This prevents clean-package checks from
        # accidentally validating an older source tree.
        local_run_dir=root/"xa03_runs"/tr["trial_id"]
        run_dir=local_run_dir if local_run_dir.exists() else Path(tr["xa03_run_dir"])
        sp=run_dir/"summary.json"
        if not sp.exists() or _sha(sp)!=tr.get("xa03_summary_sha256"):
            mismatches.append(tr["trial_id"]); continue
        summary=json.loads(sp.read_text(encoding="utf-8"))
        if summary["run"]["state"]!="COMPLETE": noncomplete.append(tr["trial_id"])
        if summary["physical"].get("device_energy_j") is not None: energy_nonnull.append(tr["trial_id"])
    audit=json.loads((root/"request_audit.json").read_text(encoding="utf-8"))
    leaks=[]
    for row in audit:
        for req in row.get("requests",[]):
            if SENTINEL in req.get("prompt",""): leaks.append(row.get("trial_id"))
    checks={
      "trial_count": report.get("trial_count")==36 and gate.get("trial_count")==36,
      "trial_results": len(trial_files)==36,
      "xa03_runs": len(run_dirs)==36,
      "all_complete": not noncomplete and gate.get("all_trials_complete") is True,
      "no_hash_mismatch": not mismatches,
      "null_energy": not energy_nonnull and gate.get("energy_scm") is None,
      "accounting": report.get("execution_totals")==EXPECTED_TOTALS and gate.get("execution_totals")==EXPECTED_TOTALS,
      "candidate_identity": EXPECTED_TOTALS["created"]==EXPECTED_TOTALS["selected"]+EXPECTED_TOTALS["discarded"],
      "no_leaks": not leaks and gate.get("private_sentinel_leaks")==0,
      "synthetic_boundary": report.get("scientific_interpretation_allowed") is False and gate.get("scientific_interpretation_allowed") is False,
      "ssr_sdr": abs(report["aggregate"]["ssr"]-0.3)<1e-12 and abs(report["aggregate"]["sdr"]-0.7)<1e-12,
    }
    return {
      "ok":all(checks.values()),"checks":checks,"trial_results":len(trial_files),"xa03_runs":len(run_dirs),
      "summary_hash_mismatches":mismatches,"noncomplete_runs":noncomplete,"energy_nonnull_runs":energy_nonnull,"private_sentinel_leaks":leaks
    }
