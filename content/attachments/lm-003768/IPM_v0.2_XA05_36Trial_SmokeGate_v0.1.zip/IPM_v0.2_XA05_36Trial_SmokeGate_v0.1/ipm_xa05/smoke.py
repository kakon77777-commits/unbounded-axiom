from __future__ import annotations
from dataclasses import dataclass

TASKS=("MATH-003","CODE-001","CON-003")
CONDITIONS=("A0","A1","A2","A3","A4","A5")

CORRECT={
    "MATH-003": '{"answer":169}',
    "CODE-001": 'def normalize_whitespace(s):\n    return " ".join(s.split())\n',
    "CON-003": '{"A":"X","B":"Y","C":"X","D":"Y"}',
}
WRONG={
    "MATH-003": '{"answer":168}',
    "CODE-001": 'def normalize_whitespace(s):\n    return ""\n',
    "CON-003": '{"A":"X","B":"X","C":"Y","D":"Y"}',
}
TOOL_ACTION='{"action":"tool","tool":"calculator","input":{"expression":"1+1"}}'

def final_envelope(content: str) -> str:
    import json
    return json.dumps({"action":"final","content":content},separators=(",",":"))

class IndexVerifier:
    verifier_type="xa05_scripted"
    def __init__(self, indices, accepted=None, feedback=None):
        self.indices=list(indices)
        self.accepted=list(accepted or [True]*len(self.indices))
        self.feedback=list(feedback or [""]*len(self.indices))
        self.i=0
    def select(self, task, candidates, invoke_model=None):
        idx=self.indices[self.i]
        acc=self.accepted[self.i]
        fb=self.feedback[self.i]
        self.i+=1
        class R: pass
        r=R(); r.selected_candidate_id=candidates[idx].candidate_id; r.accepted=acc; r.feedback=fb; r.score=None
        return r

@dataclass
class SmokeCase:
    task_id: str
    condition: str
    replicate: int
    outputs: list[str]
    correct: str
    wrong: str
    verifier: IndexVerifier|None


def build_case(task_id: str, condition: str, replicate: int) -> SmokeCase:
    if task_id not in TASKS: raise ValueError(task_id)
    if condition not in CONDITIONS: raise ValueError(condition)
    correct=CORRECT[task_id]; wrong=WRONG[task_id]
    if condition=="A0": outputs=[wrong]; verifier=None
    elif condition=="A1": outputs=[correct if task_id=="MATH-003" else wrong]; verifier=None
    elif condition=="A2": outputs=[correct]*5+[wrong]*3; verifier=None
    elif condition=="A3":
        outputs=[wrong]*8; outputs[3]=correct; verifier=IndexVerifier([3])
    elif condition=="A4":
        outputs=[TOOL_ACTION,final_envelope(correct)]+[wrong]*7; verifier=IndexVerifier([0])
    else:
        outputs=["external smoke plan",wrong,correct]
        verifier=IndexVerifier([0,0],accepted=[False,True],feedback=["synthetic reject","synthetic accept"])
    return SmokeCase(task_id,condition,replicate,outputs,correct,wrong,verifier)


def expected_counts(condition: str) -> dict[str,int]:
    table={
      "A0":{"model":1,"trajectory":1,"retry":0,"tool":0,"verifier":0,"created":1,"selected":1,"discarded":0},
      "A1":{"model":1,"trajectory":1,"retry":0,"tool":0,"verifier":0,"created":1,"selected":1,"discarded":0},
      "A2":{"model":8,"trajectory":8,"retry":0,"tool":0,"verifier":0,"created":8,"selected":1,"discarded":7},
      "A3":{"model":8,"trajectory":8,"retry":0,"tool":0,"verifier":1,"created":8,"selected":1,"discarded":7},
      "A4":{"model":9,"trajectory":8,"retry":0,"tool":1,"verifier":1,"created":8,"selected":1,"discarded":7},
      "A5":{"model":3,"trajectory":2,"retry":1,"tool":0,"verifier":2,"created":2,"selected":1,"discarded":1},
    }
    if condition not in table: raise ValueError(condition)
    return dict(table[condition])
