from __future__ import annotations


def _fmt(v, digits=6):
    if v is None: return "null"
    if isinstance(v,float): return f"{v:.{digits}f}"
    return str(v)


def render_markdown(report: dict) -> str:
    a=report["aggregate"]; t=report["execution_totals"]
    lines=[
      "# IPM v0.2 XA-05 — 36-Trial End-to-End Smoke Gate Report",
      "",
      "> **SYNTHETIC ENGINEERING SMOKE — NOT a model-intelligence result.**",
      "> Scripted provider outputs were intentionally constructed to test accounting, evaluation, telemetry boundaries, and aggregation.",
      "",
      "## Gate Summary",
      "",
      f"- Trials: **{report['trial_count']}**",
      f"- Trial failures: **{report['failures']}**",
      f"- Accounting mismatches: **{len(report['accounting_mismatches'])}**",
      f"- Private-reference sentinel leaks: **{len(report['private_sentinel_leaks'])}**",
      f"- SSR: **{_fmt(a.get('ssr'))}**",
      f"- SDR: **{_fmt(a.get('sdr'))}**",
      f"- Device-energy SCM: **{_fmt(a.get('scm',{}).get('device_energy_j'))}** (expected null under NullCollector)",
      "",
      "## Execution Accounting",
      "",
      "| Metric | Total |",
      "|---|---:|",
    ]
    labels=[("Model invocations","model"),("Trajectories","trajectory"),("Retries","retry"),("Tool calls","tool"),("Verifier passes","verifier"),("Candidates created","created"),("Candidates selected","selected"),("Candidates discarded","discarded")]
    for label,key in labels: lines.append(f"| {label} | {t[key]} |")
    lines += ["",f"Candidate identity check: **{t['created']} = {t['selected']} + {t['discarded']}**.","","## Condition Summary","","| Condition | n | Mean quality | Mean wall time (s) |","|---|---:|---:|---:|"]
    for c in report["conditions"]:
        row=a["conditions"].get(c,{})
        lines.append(f"| {c} | {row.get('n','')} | {_fmt(row.get('quality_mean'))} | {_fmt(row.get('wall_time_mean'))} |")
    lines += ["","## Interpretation Boundary","","The synthetic quality curve was predesigned as an engineering oracle. It demonstrates that the pipeline can reconstruct the expected A0→A5 quality structure; it is **not evidence that any real model has SSR=0.30 or SDR=0.70**.","","Energy remains unknown/null because XA-05 intentionally uses XA-03 `NullCollector`. This verifies `Unknown != 0` and prevents synthetic smoke data from masquerading as physical measurement.",""]
    return "\n".join(lines)
