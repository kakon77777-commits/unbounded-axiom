from __future__ import annotations
from pathlib import Path
import json, sys
from dataclasses import asdict

from .smoke import TASKS, CONDITIONS, build_case, expected_counts

SENTINEL="XA02_PRIVATE_SENTINEL_DO_NOT_LEAK"


def _load_xa04(root: Path):
    s=str(root)
    if s not in sys.path: sys.path.insert(0,s)
    from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor, ScriptedProvider
    from ipm_xa04.tools import CalculatorTool, ToolRegistry
    from ipm_xa04.aggregator import aggregate_trials
    return TaskPack,EvaluatorBridge,TrialExecutor,ScriptedProvider,CalculatorTool,ToolRegistry,aggregate_trials


def run_matrix(xa02_root: Path, xa03_root: Path, xa04_root: Path, output_dir: Path, *, replicates: int=2):
    TaskPack,EvaluatorBridge,TrialExecutor,ScriptedProvider,CalculatorTool,ToolRegistry,_=_load_xa04(Path(xa04_root))
    output_dir=Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
    pack=TaskPack(xa02_root)
    evaluator=EvaluatorBridge(xa02_root,allow_code_execution=True)
    executor=TrialExecutor(pack,evaluator,xa03_root=xa03_root,output_dir=output_dir)
    records=[]; audits=[]
    for rep in range(1,replicates+1):
        for task_id in TASKS:
            for cond in CONDITIONS:
                case=build_case(task_id,cond,rep)
                provider=ScriptedProvider(case.outputs,provider_id="xa05-scripted",model_id="xa05-scripted")
                tools=ToolRegistry([CalculatorTool()])
                r=executor.execute(task_id,cond,provider,replicate=rep,verifier=case.verifier,tools=tools,collectors=("null",),physical_boundary="synthetic-smoke-null")
                records.append(r)
                audits.append({
                    "trial_id":r.trial_id,"task_id":task_id,"condition":cond,"replicate":rep,
                    "requests":[{"prompt":q.prompt,"role":q.role,"condition":q.condition,"task_id":q.task_id,"generation_budget_multiplier":q.generation_budget_multiplier} for q in provider.requests]
                })
    (output_dir/"request_audit.json").write_text(json.dumps(audits,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    return records


def _check_counts(record):
    e=record.xa03_summary["execution"]
    exp=expected_counts(record.condition)
    actual={
      "model":e["model_invocations_started"],"trajectory":e["trajectories_started"],"retry":e["retries_started"],
      "tool":e["tool_calls_started"],"verifier":e["verifier_passes_started"],"created":e["candidates_created"],
      "selected":e["candidates_selected"],"discarded":e["candidates_discarded"]
    }
    return actual, exp


def summarize_and_verify(records, *, xa02_root: Path):
    if not records: raise ValueError("no records")
    xa04_root=Path(__file__).resolve().parents[2] if False else None
    # aggregate_trials was imported when run_matrix loaded XA04. Import the already-loaded module here.
    from ipm_xa04.aggregator import aggregate_trials
    aggregate=aggregate_trials(records)
    mismatches=[]
    for r in records:
        actual,exp=_check_counts(r)
        if actual!=exp: mismatches.append({"trial_id":r.trial_id,"actual":actual,"expected":exp})
    failures=sum(1 for r in records if r.failure is not None)
    totals={"model":0,"trajectory":0,"retry":0,"tool":0,"verifier":0,"created":0,"selected":0,"discarded":0}
    for r in records:
        actual,_=_check_counts(r)
        for k,v in actual.items(): totals[k]+=v
    # Derive output directory from canonical XA03 run directory: <out>/xa03_runs/<trial>.
    out=Path(records[0].xa03_run_dir).parent.parent
    audit_path=out/"request_audit.json"
    leaks=[]
    if audit_path.exists():
        audits=json.loads(audit_path.read_text(encoding="utf-8"))
        for a in audits:
            for q in a["requests"]:
                if SENTINEL in q["prompt"]:
                    leaks.append({"trial_id":a["trial_id"],"role":q["role"]})
    return {
      "kind":"synthetic_engineering_smoke_only",
      "scientific_interpretation_allowed":False,
      "trial_count":len(records),"failures":failures,"accounting_mismatches":mismatches,"private_sentinel_leaks":leaks,
      "execution_totals":totals,
      "aggregate":aggregate,
      "tasks":list(TASKS),"conditions":list(CONDITIONS),
      "quality_design":{"A0":0.3,"A1":(1+0.4+0.5)/3,"A2":1.0,"A3":1.0,"A4":1.0,"A5":1.0},
      "energy_expected":"unknown/null because NullCollector is used"
    }
