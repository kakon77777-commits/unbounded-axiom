# IPM v0.2 XA-05 — 36-Trial End-to-End Smoke Gate

**Artifact:** EML-IPM-XA-05  
**Version:** v0.1  
**Status:** synthetic engineering smoke gate

> **This package does NOT contain a real-model intelligence experiment.**
> `ScriptedProvider` outputs are deliberately constructed so the expected quality curve is known in advance. The purpose is to verify the complete XA-01→XA-02→XA-03→XA-04 pipeline before spending real model compute.

## Matrix

- Tasks: `MATH-003`, `CODE-001`, `CON-003`
- Conditions: `A0` through `A5`
- Replicates: 2
- Total: **36 trials**

## Designed synthetic quality oracle

- A0: 0.300000 mean quality
- A1: 0.633333 mean quality
- A2: 1.000000
- A3: 1.000000
- A4: 1.000000
- A5: 1.000000

Thus the engineering oracle is:

- SSR = 0.300000
- SDR = 0.700000

These values are test fixtures, **not scientific estimates**.

## Canonical output

`canonical_smoke_run/` contains:

- 36 XA-04 trial-result JSON files
- 36 finalized XA-03 run directories with raw events/telemetry/summaries
- request audit
- aggregate JSON + Markdown report
- condition summary CSV
- trial index CSV
- gate summary JSON

The smoke run intentionally uses XA-03 `NullCollector`. Therefore device energy and allocated device time remain `null`; this validates the IPM rule `Unknown != 0`.

## External canonical dependencies

XA-05 does not vendor XA-02, XA-03, or XA-04. To rerun tests set:

```bash
export IPM_XA02_ROOT=/path/to/IPM_v0.2_XA02_TaskPack_v0.1
export IPM_XA03_ROOT=/path/to/IPM_v0.2_XA03_Reference_Logger_v0.1
export IPM_XA04_ROOT=/path/to/IPM_v0.2_XA04_Model_Runner_v0.1
PYTHONPATH=. python -m pytest -q
```

Canonical dependency package hashes used for this smoke run:

- XA-02: `424950d34dc54180ebe048b172285615a964e783d6a326166bee9a3bf7d78e4c`
- XA-03: `a5ababbd50e8726ec211fa1e1ae27406548e5345168dabc47bc84968d0b21baa`
- XA-04: `14f602676aeeb162c5a72e1c2f66763d9f96bcc07c31dd5ba7e5133b61e9ad18`

## Verification

```bash
PYTHONPATH=. python - <<'PY'
from ipm_xa05.verify import verify_canonical_output
print(verify_canonical_output('canonical_smoke_run'))
PY
```

The verifier prefers the local packaged XA-03 run directories over historical absolute paths, preventing a clean-package test from accidentally validating the source workspace.
