# IPM v0.2 XA-05 36-Trial End-to-End Smoke Gate Plan

**Goal:** Run 3 canonical XA-02 tasks × A0–A5 × 2 replicates through XA-04 + XA-03 + XA-02 and verify the whole experimental pipeline before any real-model pilot.

**Important:** All provider outputs are scripted synthetic fixtures. Results validate engineering/accounting only and MUST NOT be interpreted as model intelligence measurements.

## Tasks
1. RED/GREEN: case builder returns valid scripted provider/verifier/tool fixtures for each task/condition.
2. RED/GREEN: execute exactly 36 trials and persist trial results.
3. RED/GREEN: verify per-condition XA-03 accounting invariants and no private-reference leakage.
4. RED/GREEN: aggregate quality/physical summaries and verify SSR/SDR/null-energy behavior.
5. Produce smoke report, manifest, clean ZIP, then re-run verification from extracted package.
