# IPM v0.2 XA-05 — 36-Trial End-to-End Smoke Gate Report

> **SYNTHETIC ENGINEERING SMOKE — NOT a model-intelligence result.**
> Scripted provider outputs were intentionally constructed to test accounting, evaluation, telemetry boundaries, and aggregation.

## Gate Summary

- Trials: **36**
- Trial failures: **0**
- Accounting mismatches: **0**
- Private-reference sentinel leaks: **0**
- SSR: **0.300000**
- SDR: **0.700000**
- Device-energy SCM: **null** (expected null under NullCollector)

## Execution Accounting

| Metric | Total |
|---|---:|
| Model invocations | 180 |
| Trajectories | 168 |
| Retries | 6 |
| Tool calls | 6 |
| Verifier passes | 24 |
| Candidates created | 168 |
| Candidates selected | 36 |
| Candidates discarded | 132 |

Candidate identity check: **168 = 36 + 132**.

## Condition Summary

| Condition | n | Mean quality | Mean wall time (s) |
|---|---:|---:|---:|
| A0 | 6 | 0.300000 | 0.000822 |
| A1 | 6 | 0.633333 | 0.000670 |
| A2 | 6 | 1.000000 | 0.001680 |
| A3 | 6 | 1.000000 | 0.001649 |
| A4 | 6 | 1.000000 | 0.001607 |
| A5 | 6 | 1.000000 | 0.001241 |

## Interpretation Boundary

The synthetic quality curve was predesigned as an engineering oracle. It demonstrates that the pipeline can reconstruct the expected A0→A5 quality structure; it is **not evidence that any real model has SSR=0.30 or SDR=0.70**.

Energy remains unknown/null because XA-05 intentionally uses XA-03 `NullCollector`. This verifies `Unknown != 0` and prevents synthetic smoke data from masquerading as physical measurement.
