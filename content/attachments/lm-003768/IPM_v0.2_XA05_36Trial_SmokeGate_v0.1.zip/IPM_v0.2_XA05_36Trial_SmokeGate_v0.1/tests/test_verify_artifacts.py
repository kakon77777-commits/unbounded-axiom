from pathlib import Path
from ipm_xa05.verify import verify_canonical_output


def test_generated_canonical_smoke_output_verifies():
    root=Path(__file__).resolve().parents[1]/"canonical_smoke_run"
    result=verify_canonical_output(root)
    assert result["ok"] is True
    assert result["trial_results"]==36
    assert result["xa03_runs"]==36
    assert result["summary_hash_mismatches"]==[]


def test_verifier_prefers_relocated_local_run_over_stored_absolute_path(tmp_path):
    import shutil, json
    source=Path(__file__).resolve().parents[1]/"canonical_smoke_run"
    relocated=tmp_path/"smoke"
    shutil.copytree(source,relocated)
    trial=next((relocated/"trial_results").glob("*.json"))
    tr=json.loads(trial.read_text(encoding="utf-8"))
    local_summary=relocated/"xa03_runs"/tr["trial_id"]/"summary.json"
    local_summary.write_text("{}\n",encoding="utf-8")
    result=verify_canonical_output(relocated)
    assert result["ok"] is False
    assert tr["trial_id"] in result["summary_hash_mismatches"]
