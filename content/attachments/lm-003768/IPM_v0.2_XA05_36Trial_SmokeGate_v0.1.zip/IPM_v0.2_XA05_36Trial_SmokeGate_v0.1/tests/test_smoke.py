from pathlib import Path
import json

from ipm_xa05.smoke import TASKS, CONDITIONS, build_case, expected_counts


def test_matrix_definition_is_3_by_6_by_2():
    assert TASKS == ("MATH-003", "CODE-001", "CON-003")
    assert CONDITIONS == ("A0", "A1", "A2", "A3", "A4", "A5")
    assert len(TASKS) * len(CONDITIONS) * 2 == 36


def test_a0_and_a1_are_single_trajectory_cases():
    for task in TASKS:
        a0 = build_case(task, "A0", 1)
        a1 = build_case(task, "A1", 1)
        assert len(a0.outputs) == 1
        assert len(a1.outputs) == 1
        assert a0.verifier is None and a1.verifier is None


def test_a2_has_eight_outputs_and_majority_correct():
    for task in TASKS:
        case = build_case(task, "A2", 1)
        assert len(case.outputs) == 8
        assert case.outputs.count(case.correct) == 5


def test_a4_exercises_exactly_one_tool_loop_before_eight_candidates():
    for task in TASKS:
        case = build_case(task, "A4", 1)
        assert case.outputs[0].startswith('{"action":"tool"')
        assert case.outputs[1].startswith('{"action":"final"')
        assert len(case.outputs) == 9
        assert case.verifier is not None


def test_a5_scripts_plan_reject_retry_accept():
    for task in TASKS:
        case = build_case(task, "A5", 1)
        assert len(case.outputs) == 3
        assert case.verifier is not None
        assert case.verifier.accepted == [False, True]


def test_expected_accounting_is_canonical():
    assert expected_counts("A0") == {"model":1,"trajectory":1,"retry":0,"tool":0,"verifier":0,"created":1,"selected":1,"discarded":0}
    assert expected_counts("A2")["model"] == 8
    assert expected_counts("A2")["discarded"] == 7
    assert expected_counts("A4")["model"] == 9
    assert expected_counts("A4")["tool"] == 1
    assert expected_counts("A5") == {"model":3,"trajectory":2,"retry":1,"tool":0,"verifier":2,"created":2,"selected":1,"discarded":1}
