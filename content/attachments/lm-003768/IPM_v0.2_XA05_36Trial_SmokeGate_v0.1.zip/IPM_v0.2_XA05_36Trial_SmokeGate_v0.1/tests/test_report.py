from ipm_xa05.report import render_markdown


def test_report_prominently_marks_synthetic_and_includes_core_metrics():
    report={
      "kind":"synthetic_engineering_smoke_only",
      "scientific_interpretation_allowed":False,
      "trial_count":36,"failures":0,"accounting_mismatches":[],"private_sentinel_leaks":[],
      "execution_totals":{"model":180,"trajectory":168,"retry":6,"tool":6,"verifier":24,"created":168,"selected":36,"discarded":132},
      "aggregate":{"conditions":{"A0":{"quality_mean":0.3,"wall_time_mean":0.1},"A5":{"quality_mean":1.0,"wall_time_mean":0.2}},"ssr":0.3,"sdr":0.7,"scm":{"wall_time_s":2.0,"device_energy_j":None,"allocated_device_time_s":None},"marginal_yield":{}},
      "tasks":["MATH-003","CODE-001","CON-003"],"conditions":["A0","A1","A2","A3","A4","A5"],
      "quality_design":{},"energy_expected":"unknown/null because NullCollector is used"
    }
    md=render_markdown(report)
    assert "SYNTHETIC ENGINEERING SMOKE" in md
    assert "NOT a model-intelligence result" in md
    assert "SSR" in md and "0.300000" in md
    assert "180" in md and "132" in md
