from pathlib import Path
import os
import pytest

from ipm_xa05.runner import run_matrix, summarize_and_verify


def deps():
    xa02=os.environ.get("IPM_XA02_ROOT")
    xa03=os.environ.get("IPM_XA03_ROOT")
    xa04=os.environ.get("IPM_XA04_ROOT")
    if not all((xa02,xa03,xa04)):
        pytest.skip("XA02/XA03/XA04 roots not configured")
    return Path(xa02),Path(xa03),Path(xa04)


@pytest.fixture(scope="module")
def matrix36(tmp_path_factory):
    xa02,xa03,xa04=deps()
    out=tmp_path_factory.mktemp("xa05-matrix")
    records=run_matrix(xa02,xa03,xa04,out,replicates=2)
    report=summarize_and_verify(records, xa02_root=xa02)
    return records,report


def test_36_trial_matrix_runs_end_to_end_and_aggregates(matrix36):
    records,report=matrix36
    assert len(records)==36
    assert report["trial_count"]==36
    assert report["failures"]==0
    assert report["accounting_mismatches"]==[]
    assert report["private_sentinel_leaks"]==[]
    assert report["execution_totals"] == {
        "model":180,"trajectory":168,"retry":6,"tool":6,"verifier":24,
        "created":168,"selected":36,"discarded":132
    }
    assert report["execution_totals"]["created"] == report["execution_totals"]["selected"] + report["execution_totals"]["discarded"]
    expected={"A0":0.3,"A1":(1+0.4+0.5)/3,"A2":1.0,"A3":1.0,"A4":1.0,"A5":1.0}
    for c,q in expected.items():
        assert report["aggregate"]["conditions"][c]["quality_mean"] == pytest.approx(q)
    assert report["aggregate"]["ssr"] == pytest.approx(0.3)
    assert report["aggregate"]["sdr"] == pytest.approx(0.7)
    assert report["aggregate"]["scm"]["device_energy_j"] is None
    assert report["aggregate"]["scm"]["allocated_device_time_s"] is None


def test_every_trial_uses_null_physical_energy_and_finalized_run(matrix36):
    records,_=matrix36
    for r in records:
        assert r.failure is None
        assert r.xa03_summary["run"]["state"]=="COMPLETE"
        assert r.xa03_summary["physical"]["device_energy_j"] is None
