# EML-IPM-XA-02 — 30-Task Pilot Pack & Reference Evaluators

Version: v0.1  
Tasks: 30 = 10 math + 10 code + 10 constraint.

## Separation
- `tasks_public.json`: safe to give to tested systems.
- `reference_private.json`: hidden answers/tests; **never** put in model context.
- `evaluate.py`: deterministic evaluator.
- `_private_reference_solutions.py`: self-test references only.
- `validation_report.json`: 30/30 package self-test.
- `manifest.json`: file hashes.

## Candidate output
Math/constraint: one JSON object only.  
Code: Python source only.

## Code-execution safety
Generated code is untrusted. `evaluate.py` refuses CODE evaluation unless `IPM_ALLOW_CODE_EXEC=1`.
Its subprocess timeout is NOT a complete sandbox. Use a real container/OS sandbox for benchmark runs.

## Purpose
This is not a general intelligence benchmark. It is a controlled instrument for measuring A0→A5 scaffolding response under IPM v0.2 Experiment A.
