#!/usr/bin/env python3
from pathlib import Path
import json,sys,os,subprocess
ROOT=Path(__file__).resolve().parent
PUB=json.loads((ROOT/"tasks_public.json").read_text(encoding="utf-8"))
PRI=json.loads((ROOT/"reference_private.json").read_text(encoding="utf-8"))
TASKS={t["id"]:t for t in PUB["tasks"]}

def result(tid,hard,scalar,vector,details=None,failure="none"):
    return {"task_id":tid,"hard_gate":bool(hard),"scalar_value":float(scalar),"vector":vector,"details":details or {},"failure_class":failure}

def eval_math(tid,text):
    try: obj=json.loads(text.strip())
    except Exception as e: return result(tid,False,0,{"json_valid":0},{"error":str(e)},"reason")
    ref=PRI["math_answers"][tid]; w=TASKS[tid]["quality_projection"]["weights"]; s=0; v={"json_valid":1}
    for k,val in ref.items():
        ok=obj.get(k)==val; v[k]=int(ok); s+=w.get(k,0)*ok
    return result(tid,True,s,v)

def checks(tid,o):
    C=[]; add=lambda n,x:C.append((n,bool(x)))
    try:
        if tid=="CON-001":
            ks="ABCD"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            vs=[o[k] for k in ks]; add("domain",all(type(v) is int and 1<=v<=4 for v in vs)); add("distinct",len(set(vs))==4)
            add("A<C",o["A"]<o["C"]); add("B!=1",o["B"]!=1); add("D=4",o["D"]==4); add("B<C",o["B"]<o["C"])
        elif tid=="CON-002":
            ks="PQRST"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            vs=[o[k] for k in ks]; add("domain",all(type(v) is int and 1<=v<=5 for v in vs)); add("distinct",len(set(vs))==5)
            add("P_immediate_Q",o["Q"]==o["P"]+1); add("R_not_end",o["R"] not in (1,5)); add("S<R",o["S"]<o["R"]); add("T_not_adj_Q",abs(o["T"]-o["Q"])!=1)
        elif tid=="CON-003":
            ks="ABCD"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            add("domain",all(o[k] in ("X","Y") for k in ks)); add("A!=B",o["A"]!=o["B"]); add("C=A",o["C"]==o["A"]); add("D=B",o["D"]==o["B"]); add("two_X",sum(o[k]=="X" for k in ks)==2)
        elif tid=="CON-004":
            ks="ABCDEF"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            vs=[o[k] for k in ks]; add("domain",all(type(v) is int and 1<=v<=6 for v in vs)); add("distinct",len(set(vs))==6)
            add("A<D",o["A"]<o["D"]); add("B<E",o["B"]<o["E"]); add("C_immediate_F",o["F"]==o["C"]+1); add("D_not_adj_E",abs(o["D"]-o["E"])!=1); add("A!=1",o["A"]!=1); add("B!=6",o["B"]!=6)
        elif tid=="CON-005":
            ks="ABCDEF"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            add("domain",all(o[k] in ("R","G","B") for k in ks)); add("A=R",o["A"]=="R")
            for u,v in [("A","B"),("A","C"),("B","C"),("B","D"),("C","E"),("D","E"),("D","F"),("E","F")]: add(u+v,o[u]!=o[v])
        elif tid=="CON-006":
            ks="ABCDE"; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            vs=[o[k] for k in ks]; add("domain",all(type(v) is int and 1<=v<=5 for v in vs)); add("distinct",len(set(vs))==5)
            add("A<C",o["A"]<o["C"]); add("B=A+2",o["B"]==o["A"]+2); add("D<E",o["D"]<o["E"]); add("C!=5",o["C"]!=5); add("E_not_1_2",o["E"] not in (1,2))
        elif tid=="CON-007":
            add("route","route" in o and isinstance(o["route"],list))
            if not C[-1][1]: return C
            r=o["route"]; add("cities",len(r)==6 and set(r)==set("ABCDEF"))
            if not C[-1][1]: return C
            p={x:i for i,x in enumerate(r)}; add("start_A",r[0]=="A"); add("BC_not_adj",abs(p["B"]-p["C"])!=1); add("D<E",p["D"]<p["E"]); add("F_not_final",r[-1]!="F"); add("AD_not_adj",abs(p["A"]-p["D"])!=1)
        elif tid=="CON-008":
            add("columns","columns" in o and isinstance(o["columns"],list) and len(o["columns"])==8)
            if not C[-1][1]: return C
            c=o["columns"]; add("domain",all(type(x) is int and 1<=x<=8 for x in c)); add("unique",len(set(c))==8); add("diag1",len({r-x for r,x in enumerate(c,1)})==8); add("diag2",len({r+x for r,x in enumerate(c,1)})==8)
        elif tid=="CON-009":
            add("grid","grid" in o and isinstance(o["grid"],list) and len(o["grid"])==4 and all(isinstance(r,list) and len(r)==4 for r in o["grid"]))
            if not C[-1][1]: return C
            g=o["grid"]; D={1,2,3,4}; giv=[[1,0,0,4],[0,4,1,0],[0,1,4,0],[4,0,0,1]]
            add("domain",all(x in D for r in g for x in r)); add("givens",all(giv[r][c]==0 or g[r][c]==giv[r][c] for r in range(4) for c in range(4)))
            for r in range(4): add(f"row{r}",set(g[r])==D)
            for c in range(4): add(f"col{c}",{g[r][c] for r in range(4)}==D)
            for br in (0,2):
                for bc in (0,2): add(f"box{br}{bc}",{g[r][c] for r in range(br,br+2) for c in range(bc,bc+2)}==D)
        elif tid=="CON-010":
            ks=[f"x{i}" for i in range(1,11)]; add("fields",all(k in o for k in ks))
            if not C[-1][1]: return C
            add("bools",all(type(o[k]) is bool for k in ks))
            cls=[[(1,1),(2,1)],[(1,0),(3,1)],[(2,0),(4,1)],[(3,1),(5,1)],[(3,0),(6,1)],[(4,0),(6,1)],[(5,0),(7,1)],[(6,0),(8,1)],[(7,1),(9,1)],[(8,0),(10,1)],[(9,0),(10,1)],[(1,1),(10,0)],[(2,1),(8,1)],[(7,0),(4,1)],[(5,1),(4,0)]]
            for i,cl in enumerate(cls,1): add(f"clause{i}",any((o[f"x{v}"] if pos else not o[f"x{v}"]) for v,pos in cl))
    except Exception: add("check_runtime",False)
    return C

def eval_constraint(tid,text):
    try:o=json.loads(text.strip())
    except Exception as e:return result(tid,False,0,{"json_valid":0},{"error":str(e)},"reason")
    C=checks(tid,o); passed=sum(x for _,x in C); total=len(C); hard=bool(C and C[0][1])
    return result(tid,hard,passed/total if total else 0,{"json_valid":1,**{n:int(x) for n,x in C}},{"passed":passed,"total":total})

def eval_code(tid,src):
    if os.environ.get("IPM_ALLOW_CODE_EXEC")!="1":
        return result(tid,False,0,{"execution_allowed":0},{"error":"Set IPM_ALLOW_CODE_EXEC=1 and use a real sandbox."},"runtime")
    payload={"source":src,"fn":TASKS[tid]["output_contract"]["function_name"],"tests":PRI["code_tests"][tid]}
    harness=r"""
import json,sys
p=json.loads(sys.stdin.read()); ns={}
try: compile(p["source"],"<candidate>","exec")
except Exception as e: print(json.dumps({"syntax":0,"fn":0,"passed":0,"total":len(p["tests"]),"error":repr(e)})); raise SystemExit
try: exec(p["source"],ns,ns)
except Exception as e: print(json.dumps({"syntax":1,"fn":0,"passed":0,"total":len(p["tests"]),"error":repr(e)})); raise SystemExit
f=ns.get(p["fn"])
if not callable(f): print(json.dumps({"syntax":1,"fn":0,"passed":0,"total":len(p["tests"])})); raise SystemExit
def decode(x):
    if isinstance(x,dict) and "__iterator__" in x: return iter(x["__iterator__"])
    if isinstance(x,list): return [decode(v) for v in x]
    if isinstance(x,dict): return {k:decode(v) for k,v in x.items()}
    return x
passed=0; outcomes=[]
for t in p["tests"]:
    args=decode(t["args"])
    try:
        if "raises" in t:
            try: f(*args); ok=False
            except Exception as e: ok=type(e).__name__==t["raises"]
        else: ok=f(*args)==t["expected"]
    except Exception: ok=False
    outcomes.append(ok); passed+=int(ok)
print(json.dumps({"syntax":1,"fn":1,"passed":passed,"total":len(p["tests"]),"outcomes":outcomes}))
"""
    try:
        cp=subprocess.run([sys.executable,"-c",harness],input=json.dumps(payload),text=True,capture_output=True,timeout=15)
        d=json.loads(cp.stdout.strip().splitlines()[-1])
    except Exception as e:return result(tid,False,0,{"execution_allowed":1},{"error":str(e)},"runtime")
    hard=bool(d.get("syntax") and d.get("fn")); sc=d.get("passed",0)/d.get("total",1) if hard else 0
    return result(tid,hard,sc,{"execution_allowed":1,"syntax_valid":d.get("syntax",0),"function_present":d.get("fn",0),"tests_passed":d.get("passed",0),"tests_total":d.get("total",0)},{"outcomes":d.get("outcomes"),"error":d.get("error")})

def main():
    if len(sys.argv)!=3: print("Usage: evaluate.py TASK_ID candidate_file",file=sys.stderr); return 2
    tid=sys.argv[1]
    if tid not in TASKS: print(json.dumps({"error":"unknown task"})); return 2
    txt=Path(sys.argv[2]).read_text(encoding="utf-8"); fam=TASKS[tid]["family"]
    r=eval_math(tid,txt) if fam=="math" else eval_constraint(tid,txt) if fam=="constraint" else eval_code(tid,txt)
    print(json.dumps(r,ensure_ascii=False,indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
