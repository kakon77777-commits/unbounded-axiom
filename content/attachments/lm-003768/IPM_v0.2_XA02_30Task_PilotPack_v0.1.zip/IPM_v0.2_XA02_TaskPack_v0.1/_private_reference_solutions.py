
from collections import Counter,OrderedDict,deque
import heapq
def normalize_whitespace(s): return " ".join(s.split())
def chunked(seq,n):
    if n<=0: raise ValueError
    out=[]; cur=[]
    for x in seq:
        cur.append(x)
        if len(cur)==n: out.append(cur); cur=[]
    if cur: out.append(cur)
    return out
def first_unique(s):
    c=Counter(s); return next((x for x in s if c[x]==1),None)
def merge_intervals(intervals):
    out=[]
    for a,b in sorted(intervals):
        if not out or a>out[-1][1]: out.append([a,b])
        else: out[-1][1]=max(out[-1][1],b)
    return out
def top_k_frequent(items,k):
    if k<=0:return []
    c=Counter(items); return [x for x,_ in sorted(c.items(),key=lambda kv:(-kv[1],kv[0]))[:k]]
def balanced_brackets(text):
    mp={')':'(',']':'[','}':'{'}; st=[]
    for x in text:
        if x in '([{': st.append(x)
        elif x in mp:
            if not st or st.pop()!=mp[x]: return False
    return not st
def rotate_matrix(matrix):
    if not matrix or not matrix[0]: return []
    return [list(x) for x in zip(*matrix[::-1])]
def shortest_path_length(grid,start,end):
    R=len(grid); C=len(grid[0])
    for r,c in (start,end):
        if not(0<=r<R and 0<=c<C) or grid[r][c]==1:return None
    q=deque([(start[0],start[1],0)]); seen={tuple(start)}
    while q:
        r,c,d=q.popleft()
        if (r,c)==tuple(end):return d
        for dr,dc in ((1,0),(-1,0),(0,1),(0,-1)):
            a,b=r+dr,c+dc
            if 0<=a<R and 0<=b<C and grid[a][b]==0 and (a,b) not in seen:
                seen.add((a,b)); q.append((a,b,d+1))
    return None
def stable_toposort(nodes,edges):
    ns=set(nodes); ind={x:0 for x in ns}; ad={x:[] for x in ns}
    for u,v in edges:
        if u not in ns or v not in ns: raise ValueError
        ad[u].append(v); ind[v]+=1
    h=[x for x in ns if ind[x]==0]; heapq.heapify(h); out=[]
    while h:
        u=heapq.heappop(h); out.append(u)
        for v in ad[u]:
            ind[v]-=1
            if ind[v]==0: heapq.heappush(h,v)
    if len(out)!=len(ns):raise ValueError
    return out
def lru_simulate(capacity,requests):
    if capacity<=0: raise ValueError
    d=OrderedDict(); hits=miss=0; ev=[]
    for x in requests:
        if x in d: hits+=1; d.move_to_end(x)
        else:
            miss+=1
            if len(d)>=capacity: ev.append(d.popitem(last=False)[0])
            d[x]=None
    return {"hits":hits,"misses":miss,"evicted":ev,"cache":list(d)}
