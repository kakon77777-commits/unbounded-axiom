# XA-06L — Import the real-model result back into ChatGPT

After `seal-results.ps1` succeeds, upload **the sealed result ZIP**, not the entire software folder.

Expected filename:

```text
XA06_REAL_<model-id>_<UTC-timestamp>.zip
```

A canonical complete bundle contains:

```text
REAL_MODEL_PILOT_COMPLETE
manifest.json
redaction_provenance.json
gate_summary.json
pilot_state.json
trial_results/
xa03_runs/
```

It normally also contains XA-06 analysis surfaces such as:

```text
aggregate.json
pilot_report.md
condition_summary.csv
trial_index.csv
physical_summary.csv
protocol_compliance.csv
provider_audit.json
```

## What ChatGPT can analyze from it

The first empirical IPM analysis can reconstruct:

- `Q_A0 ... Q_A5`;
- SSR / SDR;
- scaffold cost multipliers where physical values exist;
- marginal scaffolding yields;
- wall-time response curve;
- device-energy response curve for measured local hardware;
- VRAM / memory-residency behavior;
- invocation / trajectory / retry / tool / verifier counts;
- selected vs discarded candidate work;
- protocol-compliance failures;
- task-family differences across math, code, and constraint tasks.

## Important

`REAL_MODEL_PILOT_INCOMPLETE` is still useful data. Upload it too if a gate failed; the failure may reveal a real instrument/model interaction that should be fixed before XA-07.

Do not manually edit trial results before uploading. The bundle manifest and state hashes are there specifically so analysis can distinguish original measurements from altered files.
