# XA-06L Local Real-Model Execution Handoff Pack Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Windows-friendly, cross-platform-tested handoff package that configures, preflights, runs/resumes, gates, seals, and packages the XA-06 36-trial real-model pilot.

**Architecture:** Thin PowerShell wrappers invoke a standard-library Python core. The Python core never reimplements XA-06 trial semantics; it orchestrates XA-06 commands, verifies state/hashes, and seals only verified real-provider results.

**Tech Stack:** Python 3.11+ standard library, pytest, PowerShell wrappers.

**Spec:** `SPEC.md`

## Global Constraints

- `REAL_MODEL_PILOT_COMPLETE` may only be created after 36 valid real-provider trials pass the gate.
- Scripted/synthetic providers can never create a real-model COMPLETE seal.
- Resume never overwrites hash-verified completed trials unless `--force`.
- API secret values are never serialized.
- PowerShell wrappers contain no scientific logic or hardcoded absolute paths.
- Core package uses standard library only.
- XA-02/03/04/06 remain external canonical dependencies.

---

### Task 1 — Matrix and Config

**Files:** `ipm_xa06l/models.py`, `matrix.py`, `config.py`, `tests/test_matrix_config.py`

- [ ] Write failing test for exactly 36 unique canonical matrix points.
- [ ] Verify RED.
- [ ] Implement matrix generator.
- [ ] Verify GREEN.
- [ ] Write failing config redaction/secret-reference tests.
- [ ] Implement config loading, validation, redaction.
- [ ] Verify GREEN.

### Task 2 — Preflight

**Files:** `preflight.py`, `tests/test_preflight.py`

- [ ] Write failing provider-failure blocking test.
- [ ] Implement typed PASS/FAIL/WARN checks.
- [ ] Write optional NVIDIA warning test.
- [ ] Implement executable/dependency/output-root checks.
- [ ] Add injected XA-06 preflight runner interface for deterministic testing.
- [ ] Verify GREEN.

### Task 3 — Pilot State and Resume

**Files:** `state.py`, `runner.py`, `tests/test_resume.py`

- [ ] Write failing verified-complete skip test.
- [ ] Implement state reconciliation with SHA-256.
- [ ] Write failing hash-mismatch invalidation test.
- [ ] Implement INVALID transition.
- [ ] Write force-rerun protection test.
- [ ] Implement explicit force behavior.
- [ ] Write interruption preservation test.
- [ ] Verify GREEN.

### Task 4 — Gate and Seal

**Files:** `gate.py`, `seal.py`, `tests/test_gate_seal.py`

- [ ] Write failing scripted-provider COMPLETE prohibition test.
- [ ] Implement provider provenance gate.
- [ ] Write failing 35/36 trial test.
- [ ] Implement exact matrix gate.
- [ ] Write 36-real-fixture COMPLETE test.
- [ ] Implement seal markers.
- [ ] Write secret-exclusion and manifest-integrity tests.
- [ ] Implement result ZIP builder.
- [ ] Verify GREEN.

### Task 5 — CLI and PowerShell

**Files:** `cli.py`, `configure.ps1`, `preflight.ps1`, `run-pilot.ps1`, `resume-pilot.ps1`, `seal-results.ps1`, `tests/test_cli_wrappers.py`

- [ ] Write CLI dispatch tests.
- [ ] Implement configure/preflight/run/resume/seal commands.
- [ ] Write wrapper static tests for relative package root and absence of hardcoded absolute paths.
- [ ] Implement thin wrappers.
- [ ] Verify GREEN.

### Task 6 — Documentation and Final Verification

**Files:** `README.md`, `IMPORT_BACK.md`, examples, `validation_report.json`, `manifest.json`

- [ ] Add local OpenAI-compatible example config.
- [ ] Add local-command example config.
- [ ] Add cloud example config.
- [ ] Run full pytest.
- [ ] Run synthetic engineering self-test and prove no REAL complete seal.
- [ ] Create a 36-real-fixture offline gate test and prove COMPLETE seal logic.
- [ ] Generate validation report.
- [ ] Generate manifest.
- [ ] Build ZIP.
- [ ] Clean-extract ZIP.
- [ ] Re-run tests from extraction.
- [ ] Validate manifest hashes.
- [ ] Compile Python tree.
- [ ] If `pwsh` exists, parse/execute wrapper help path; otherwise report PowerShell runtime unavailable and rely on static wrapper tests.
- [ ] Compute final package SHA-256.
- [ ] Declare software `FINAL_VERIFIED`, while experiment remains `NOT_RUN`.
