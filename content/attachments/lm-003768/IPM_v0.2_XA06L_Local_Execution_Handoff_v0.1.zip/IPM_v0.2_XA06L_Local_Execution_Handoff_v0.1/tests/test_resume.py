import json
from pathlib import Path
import pytest

from ipm_xa06l.matrix import canonical_matrix
from ipm_xa06l.state import PilotState, sha256_file
from ipm_xa06l.runner import run_points


def make_complete(state, point, root):
    tr = root / f"{point.key}.trial.json"
    sm = root / f"{point.key}.summary.json"
    tr.write_text(json.dumps({"task_id":point.task_id,"condition":point.condition,"replicate":point.replicate}),encoding="utf-8")
    sm.write_text(json.dumps({"run":{"state":"COMPLETE"}}),encoding="utf-8")
    state.mark_complete(point, tr, sm)
    state.save()
    return tr, sm


def test_resume_skips_hash_verified_completed_trial(tmp_path):
    state=PilotState.create(tmp_path/"pilot_state.json")
    p=canonical_matrix()[0]
    make_complete(state,p,tmp_path)
    calls=[]
    run_points([p],state,trial_launcher=lambda point: calls.append(point) or (_ for _ in ()).throw(RuntimeError("must not run")),resume=True)
    assert calls==[]
    assert state.get(p)["status"]=="COMPLETE"


def test_resume_marks_hash_mismatch_invalid_and_does_not_rerun_without_force(tmp_path):
    state=PilotState.create(tmp_path/"pilot_state.json")
    p=canonical_matrix()[0]
    tr,sm=make_complete(state,p,tmp_path)
    tr.write_text("tampered",encoding="utf-8")
    calls=[]
    run_points([p],state,trial_launcher=lambda point: calls.append(point),resume=True,force=False)
    assert calls==[]
    assert state.get(p)["status"]=="INVALID"


def test_force_reruns_invalid_point_and_replaces_state_with_new_hashes(tmp_path):
    state=PilotState.create(tmp_path/"pilot_state.json")
    p=canonical_matrix()[0]
    tr,sm=make_complete(state,p,tmp_path)
    sm.write_text("tampered",encoding="utf-8")
    new_tr=tmp_path/"new.trial.json"; new_sm=tmp_path/"new.summary.json"
    def launch(point):
        new_tr.write_text(json.dumps({"task_id":point.task_id,"condition":point.condition,"replicate":point.replicate}),encoding="utf-8")
        new_sm.write_text(json.dumps({"run":{"state":"COMPLETE"}}),encoding="utf-8")
        return {"trial_result_path":str(new_tr),"xa03_summary_path":str(new_sm)}
    run_points([p],state,trial_launcher=launch,resume=True,force=True)
    rec=state.get(p)
    assert rec["status"]=="COMPLETE"
    assert rec["trial_result_sha256"]==sha256_file(new_tr)
    assert rec["xa03_summary_sha256"]==sha256_file(new_sm)


def test_interruption_preserves_finished_trial_and_running_point_becomes_failed(tmp_path):
    state=PilotState.create(tmp_path/"pilot_state.json")
    p1,p2=canonical_matrix()[:2]
    tr=tmp_path/"ok.trial.json"; sm=tmp_path/"ok.summary.json"
    calls=[]
    def launch(point):
        calls.append(point.key)
        if point==p1:
            tr.write_text(json.dumps({"task_id":point.task_id,"condition":point.condition,"replicate":point.replicate}),encoding="utf-8")
            sm.write_text(json.dumps({"run":{"state":"COMPLETE"}}),encoding="utf-8")
            return {"trial_result_path":str(tr),"xa03_summary_path":str(sm)}
        raise KeyboardInterrupt()
    with pytest.raises(KeyboardInterrupt):
        run_points([p1,p2],state,trial_launcher=launch,resume=False)
    loaded=PilotState.load(tmp_path/"pilot_state.json")
    assert loaded.get(p1)["status"]=="COMPLETE"
    assert loaded.get(p2)["status"]=="FAILED"
    assert loaded.get(p2)["failure"]=="KeyboardInterrupt"

def test_force_rerun_calls_launcher_archive_hook_before_execution(tmp_path):
    state=PilotState.create(tmp_path/'pilot_state.json')
    p=canonical_matrix()[0]
    tr,sm=make_complete(state,p,tmp_path)
    sm.write_text('tampered',encoding='utf-8')
    order=[]
    class Launcher:
        def prepare_for_rerun(self, point): order.append(('prepare',point.key))
        def __call__(self, point):
            order.append(('run',point.key))
            tr2=tmp_path/'rerun.trial.json'; sm2=tmp_path/'rerun.summary.json'
            tr2.write_text(json.dumps({'task_id':point.task_id,'condition':point.condition,'replicate':point.replicate}),encoding='utf-8')
            sm2.write_text(json.dumps({'run':{'state':'COMPLETE'}}),encoding='utf-8')
            return {'trial_result_path':str(tr2),'xa03_summary_path':str(sm2)}
    run_points([p],state,trial_launcher=Launcher(),resume=True,force=True)
    assert order[0][0]=='prepare' and order[1][0]=='run'

def test_verify_complete_resolves_relative_paths_against_state_file(tmp_path):
    state=PilotState.create(tmp_path/'pilot_state.json')
    p=canonical_matrix()[0]
    tr_dir=tmp_path/'trial_results'; sm_dir=tmp_path/'xa03_runs'/'trial'; tr_dir.mkdir(); sm_dir.mkdir(parents=True)
    tr=tr_dir/'t.json'; sm=sm_dir/'summary.json'
    tr.write_text(json.dumps({'task_id':p.task_id,'condition':p.condition,'replicate':p.replicate}),encoding='utf-8')
    sm.write_text(json.dumps({'run':{'state':'COMPLETE'}}),encoding='utf-8')
    state.data['points'][p.key]={
        'status':'COMPLETE','task_id':p.task_id,'condition':p.condition,'replicate':p.replicate,
        'trial_result_path':'trial_results/t.json','xa03_summary_path':'xa03_runs/trial/summary.json',
        'trial_result_sha256':sha256_file(tr),'xa03_summary_sha256':sha256_file(sm)
    }
    state.save()
    ok,reason=state.verify_complete(p)
    assert ok is True and reason=='ok'
