import json
from pathlib import Path
import pytest

from ipm_xa06l.matrix import canonical_matrix
from ipm_xa06l.config import build_config, redact_config, save_config, load_config


def test_canonical_matrix_has_exactly_36_unique_points():
    points = canonical_matrix()
    assert len(points) == 36
    ids = {(p.task_id, p.condition, p.replicate) for p in points}
    assert len(ids) == 36
    assert {p.task_id for p in points} == {"MATH-003", "CODE-001", "CON-003"}
    assert {p.condition for p in points} == {"A0", "A1", "A2", "A3", "A4", "A5"}
    assert {p.replicate for p in points} == {1, 2}


def test_config_serializes_secret_reference_not_secret_value(tmp_path, monkeypatch):
    monkeypatch.setenv("SECRET_X", "super-secret-value")
    cfg = build_config(
        provider_mode="local_openai_compatible",
        model_id="local-model",
        endpoint="http://127.0.0.1:1234/v1/chat/completions",
        api_key_env="SECRET_X",
        xa02_root="/xa02",
        xa03_root="/xa03",
        xa04_root="/xa04",
        xa06_root="/xa06",
        output_root=str(tmp_path / "runs"),
    )
    path = tmp_path / "xa06.real.json"
    save_config(cfg, path)
    raw = path.read_text(encoding="utf-8")
    assert "super-secret-value" not in raw
    assert "SECRET_X" in raw
    loaded = load_config(path)
    assert loaded["provider"]["api_key_env"] == "SECRET_X"


def test_redaction_removes_accidental_secret_fields():
    cfg = {"provider": {"api_key_env": "SECRET_X", "api_key": "should-not-survive", "token": "also-secret"}}
    redacted = redact_config(cfg)
    text = json.dumps(redacted)
    assert "should-not-survive" not in text
    assert "also-secret" not in text
    assert redacted["provider"]["api_key_env"] == "SECRET_X"

def test_generated_config_is_directly_readable_by_xa06_pilot_config(tmp_path):
    import sys
    xa06_root = Path('/mnt/data/IPM_v0.2_XA06_RealModel_Pilot_Gate_v0.1')
    sys.path.insert(0, str(xa06_root))
    try:
        from ipm_xa06.config import PilotConfig
        cfg = build_config(
            provider_mode='local_openai_compatible', model_id='m', endpoint='http://127.0.0.1:1234', api_key_env=None,
            xa02_root='/xa02', xa03_root='/xa03', xa04_root='/xa04', xa06_root=str(xa06_root), output_root=str(tmp_path/'out')
        )
        path = tmp_path/'xa06.real.json'; save_config(cfg,path)
        parsed = PilotConfig.from_file(path, validate_paths=False)
        assert parsed.provider.mode == 'openai_compatible'
        assert parsed.provider.model_id == 'm'
        assert parsed.output_dir == (tmp_path/'out').resolve()
    finally:
        sys.path.remove(str(xa06_root))

def test_config_can_explicitly_enable_code_evaluation_for_sandboxed_pilot(tmp_path):
    import sys
    xa06_root = Path('/mnt/data/IPM_v0.2_XA06_RealModel_Pilot_Gate_v0.1')
    sys.path.insert(0, str(xa06_root))
    try:
        from ipm_xa06.config import PilotConfig
        cfg=build_config(provider_mode='local_command',model_id='m',command=['model-cli'],
            xa02_root='/xa02',xa03_root='/xa03',xa04_root='/xa04',xa06_root=str(xa06_root),output_root=str(tmp_path/'out'),
            allow_code_evaluation=True)
        path=tmp_path/'cfg.json'; save_config(cfg,path)
        parsed=PilotConfig.from_file(path,validate_paths=False)
        assert parsed.evaluation.allow_code_evaluation is True
    finally:
        sys.path.remove(str(xa06_root))

def test_load_config_resolves_relative_dependency_and_output_paths_against_config_file(tmp_path, monkeypatch):
    cfg=build_config(provider_mode='local_command',model_id='m',command=['model'],
        xa02_root='../xa02',xa03_root='../xa03',xa04_root='../xa04',xa06_root='../xa06',output_root='./runs')
    config_dir=tmp_path/'pack'; config_dir.mkdir()
    path=config_dir/'xa06.real.json'; save_config(cfg,path)
    elsewhere=tmp_path/'elsewhere'; elsewhere.mkdir(); monkeypatch.chdir(elsewhere)
    loaded=load_config(path)
    assert loaded['output_root']==str((config_dir/'runs').resolve())
    assert loaded['dependencies']['xa02_root']==str((config_dir/'../xa02').resolve())
    assert loaded['dependencies']['xa06_root']==str((config_dir/'../xa06').resolve())
