from pathlib import Path
import json
import pytest

from ipm_xa06l.cli import main, run_command
from ipm_xa06l.config import build_config, save_config


def test_configure_cli_writes_xa06_compatible_config(tmp_path):
    cfg=tmp_path/'xa06.real.json'
    rc=main([
        'configure','--output',str(cfg),'--provider-mode','local_openai_compatible','--model-id','m',
        '--endpoint','http://127.0.0.1:1234','--xa02-root','/xa02','--xa03-root','/xa03','--xa04-root','/xa04','--xa06-root','/xa06','--output-root',str(tmp_path/'runs')
    ])
    assert rc==0 and cfg.exists()
    d=json.loads(cfg.read_text(encoding='utf-8'))
    assert d['provider']['mode']=='openai_compatible'
    assert d['provider_mode']=='local_openai_compatible'


def test_run_command_refuses_without_passing_preflight(tmp_path):
    cfg=tmp_path/'cfg.json'
    data=build_config(provider_mode='local_command',model_id='m',command=['model'],
        xa02_root='/xa02',xa03_root='/xa03',xa04_root='/xa04',xa06_root='/xa06',output_root=str(tmp_path/'runs'))
    save_config(data,cfg)
    with pytest.raises(RuntimeError,match='preflight'):
        run_command(cfg, unsafe_preflight=False, launcher_factory=lambda p: None)


def test_powershell_wrappers_are_thin_relative_launchers():
    root=Path(__file__).resolve().parents[1]
    names=['configure.ps1','preflight.ps1','run-pilot.ps1','resume-pilot.ps1','seal-results.ps1']
    for name in names:
        text=(root/name).read_text(encoding='utf-8')
        assert '$PSScriptRoot' in text
        assert 'ipm_xa06l.cli' in text
        assert '/mnt/data' not in text
        assert 'C:\\' not in text
        assert 'Invoke-WebRequest' not in text
