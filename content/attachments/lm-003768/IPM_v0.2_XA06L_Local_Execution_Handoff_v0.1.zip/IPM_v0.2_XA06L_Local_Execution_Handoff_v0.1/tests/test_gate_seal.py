import json, zipfile, hashlib
from pathlib import Path

from ipm_xa06l.matrix import canonical_matrix
from ipm_xa06l.state import PilotState
from ipm_xa06l.gate import evaluate_handoff_gate
from ipm_xa06l.seal import seal_results


def complete_state(tmp_path, *, count=36, provider_mode="local_openai_compatible"):
    state=PilotState.create(tmp_path/"pilot_state.json")
    for point in canonical_matrix()[:count]:
        rd=tmp_path/"xa03_runs"/point.key; rd.mkdir(parents=True)
        sm=rd/"summary.json"; sm.write_text(json.dumps({"run":{"state":"COMPLETE"},"execution":{}}),encoding="utf-8")
        tr=tmp_path/"trial_results"/f"{point.key}.json"; tr.parent.mkdir(exist_ok=True)
        trial_id=f"IPM-XA-fixture-{point.task_id}-{point.condition}-{point.replicate:02d}"
        tr.write_text(json.dumps({
            "trial_id":trial_id,"task_id":point.task_id,"condition":point.condition,"replicate":point.replicate,
            "provider_mode":provider_mode,"failure":None,"quality":{"scalar_value":1.0,"vector":{}},
            "selected_candidate_id":"c1","xa03_run_dir":str(rd),"xa03_summary_sha256":hashlib.sha256(sm.read_bytes()).hexdigest()
        }),encoding="utf-8")
        # state stores canonical hashes; gate's XA06 probe is injected in unit tests
        state.mark_complete(point,tr,sm)
    state.save(); return state


def pass_probe(run_dir, config):
    return {"gate_pass":True,"real_model_pilot_complete":True,"status":"REAL_MODEL_PILOT_COMPLETE","trial_count":36}


def test_scripted_provider_can_never_pass_real_model_gate(tmp_path):
    state=complete_state(tmp_path,provider_mode="scripted")
    report=evaluate_handoff_gate({"provider_mode":"scripted"},state,preflight={"launch_allowed":True},xa06_gate_probe=pass_probe)
    assert report["gate_pass"] is False
    assert report["real_model_pilot_complete"] is False
    assert report["checks"]["real_provider_mode"] is False


def test_missing_one_trial_can_never_pass(tmp_path):
    state=complete_state(tmp_path,count=35)
    report=evaluate_handoff_gate({"provider_mode":"local_command"},state,preflight={"launch_allowed":True},xa06_gate_probe=pass_probe)
    assert report["gate_pass"] is False
    assert report["checks"]["exact_36_verified_complete"] is False


def test_36_verified_real_points_and_xa06_gate_can_pass(tmp_path):
    state=complete_state(tmp_path,count=36)
    report=evaluate_handoff_gate({"provider_mode":"local_command"},state,preflight={"launch_allowed":True},xa06_gate_probe=pass_probe)
    assert report["gate_pass"] is True
    assert report["real_model_pilot_complete"] is True


def test_unsafe_preflight_override_prevents_canonical_complete(tmp_path):
    state=complete_state(tmp_path,count=36)
    report=evaluate_handoff_gate({"provider_mode":"local_command"},state,preflight={"launch_allowed":True,"unsafe_override":True},xa06_gate_probe=pass_probe)
    assert report["gate_pass"] is False
    assert report["checks"]["safe_preflight"] is False


def test_sealed_bundle_excludes_secrets_and_hashes_files(tmp_path, monkeypatch):
    state=complete_state(tmp_path,count=36)
    pre={"launch_allowed":True,"status":"PASS"}
    config={"provider_mode":"local_command","provider":{"model_id":"m","api_key_env":"SECRET_ENV","api_key":"NEVER-SERIALIZE"},"output_root":str(tmp_path)}
    gate=evaluate_handoff_gate(config,state,preflight=pre,xa06_gate_probe=pass_probe)
    bundle=seal_results(config=config,state=state,preflight=pre,gate_report=gate,output_dir=tmp_path/"sealed")
    assert bundle["complete"] is True
    assert Path(bundle["zip_path"]).exists()
    with zipfile.ZipFile(bundle["zip_path"]) as z:
        names=set(z.namelist())
        assert any(n.endswith("REAL_MODEL_PILOT_COMPLETE") for n in names)
        texts="\n".join(z.read(n).decode("utf-8",errors="ignore") for n in names if n.endswith((".json",".md",".csv")))
        assert "NEVER-SERIALIZE" not in texts
        manifest_name=next(n for n in names if n.endswith("manifest.json"))
        manifest=json.loads(z.read(manifest_name))
        assert len(manifest["files"]) > 0


def test_sealed_bundle_relocates_xa03_runs_by_actual_trial_id(tmp_path):
    state=complete_state(tmp_path,count=36)
    pre={"launch_allowed":True,"status":"PASS"}
    config={"provider_mode":"local_command","provider":{"model_id":"m"},"output_root":str(tmp_path)}
    gate=evaluate_handoff_gate(config,state,preflight=pre,xa06_gate_probe=pass_probe)
    bundle=seal_results(config=config,state=state,preflight=pre,gate_report=gate,output_dir=tmp_path/"sealed")
    with zipfile.ZipFile(bundle["zip_path"]) as z:
        names=set(z.namelist())
        assert any("/xa03_runs/IPM-XA-fixture-MATH-003-A0-01/summary.json" in n for n in names)
        assert not any("/xa03_runs/MATH-003__A0__r1/summary.json" in n for n in names)

def test_sealed_bundle_uses_relative_paths_and_relocatable_state(tmp_path):
    state=complete_state(tmp_path,count=36)
    pre={'launch_allowed':True,'status':'PASS'}
    config={'provider_mode':'local_command','provider':{'model_id':'m'},'output_root':str(tmp_path)}
    gate=evaluate_handoff_gate(config,state,preflight=pre,xa06_gate_probe=pass_probe)
    bundle=seal_results(config=config,state=state,preflight=pre,gate_report=gate,output_dir=tmp_path/'sealed')
    extract=tmp_path/'extract'
    with zipfile.ZipFile(bundle['zip_path']) as z: z.extractall(extract)
    root=next(extract.iterdir())
    all_text='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.json','.md','.csv'})
    assert str(tmp_path) not in all_text
    sealed_state=PilotState.load(root/'pilot_state.json')
    p=canonical_matrix()[0]
    ok,reason=sealed_state.verify_complete(p)
    assert ok is True, reason
    rec=json.loads(next((root/'trial_results').glob('*.json')).read_text(encoding='utf-8'))
    assert rec['xa03_run_dir'].startswith('xa03_runs/')
