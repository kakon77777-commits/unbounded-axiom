from pathlib import Path

from ipm_xa06l.preflight import run_preflight


def base_config(tmp_path, telemetry_required=False):
    deps = {}
    for name in ("xa02_root","xa03_root","xa04_root","xa06_root"):
        p = tmp_path / name
        p.mkdir()
        deps[name] = str(p)
    return {
        "provider_mode":"local_openai_compatible",
        "provider":{"model_id":"m","endpoint":"http://local","api_key_env":None},
        "dependencies":deps,
        "telemetry":{"required":telemetry_required},
        "output_root":str(tmp_path/"out"),
    }


def test_provider_failure_blocks_launch(tmp_path):
    cfg = base_config(tmp_path)
    report = run_preflight(
        cfg,
        provider_probe=lambda c: (False, "connection refused"),
        trial_probe=lambda c: (True, {"quality":1.0}),
        executable_probe=lambda name: None,
    )
    assert report["status"] == "FAIL"
    assert report["launch_allowed"] is False
    provider = next(x for x in report["checks"] if x["name"]=="provider_connectivity")
    assert provider["status"] == "FAIL"


def test_missing_nvidia_is_warning_when_optional(tmp_path):
    cfg = base_config(tmp_path, telemetry_required=False)
    report = run_preflight(
        cfg,
        provider_probe=lambda c: (True, "model ok"),
        trial_probe=lambda c: (True, {"quality":1.0}),
        executable_probe=lambda name: None,
    )
    nvidia = next(x for x in report["checks"] if x["name"]=="nvidia_smi")
    assert nvidia["status"] == "WARN"
    assert report["launch_allowed"] is True
    assert report["status"] == "PASS_WITH_WARNINGS"


def test_missing_nvidia_blocks_when_required(tmp_path):
    cfg = base_config(tmp_path, telemetry_required=True)
    report = run_preflight(
        cfg,
        provider_probe=lambda c: (True, "model ok"),
        trial_probe=lambda c: (True, {"quality":1.0}),
        executable_probe=lambda name: None,
    )
    nvidia = next(x for x in report["checks"] if x["name"]=="nvidia_smi")
    assert nvidia["status"] == "FAIL"
    assert report["launch_allowed"] is False


def test_failed_isolated_trial_blocks_launch(tmp_path):
    cfg = base_config(tmp_path)
    report = run_preflight(
        cfg,
        provider_probe=lambda c: (True, "model ok"),
        trial_probe=lambda c: (False, {"failure":"EvaluatorFailure"}),
        executable_probe=lambda name: "/usr/bin/nvidia-smi",
    )
    trial = next(x for x in report["checks"] if x["name"]=="isolated_math003_a0")
    assert trial["status"] == "FAIL"
    assert report["launch_allowed"] is False
