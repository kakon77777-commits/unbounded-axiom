import json, sys
from pathlib import Path

from ipm_xa06l.config import build_config, save_config
from ipm_xa06l.matrix import MatrixPoint
from ipm_xa06l.integration import production_preflight, RealPointLauncher

XA02='/mnt/data/IPM_v0.2_XA02_TaskPack_v0.1'
XA03='/mnt/data/IPM_v0.2_XA03_Reference_Logger_v0.1'
XA04='/mnt/data/IPM_v0.2_XA04_Model_Runner_v0.1'
XA06='/mnt/data/IPM_v0.2_XA06_RealModel_Pilot_Gate_v0.1'


def make_config(tmp_path):
    script=tmp_path/'provider.py'
    script.write_text('import sys\n_ = sys.stdin.read()\nprint(\'{"answer":169}\')\n',encoding='utf-8')
    cfg=build_config(
        provider_mode='local_command',model_id='integration-fake-local-command',command=[sys.executable,str(script)],
        xa02_root=XA02,xa03_root=XA03,xa04_root=XA04,xa06_root=XA06,
        output_root=str(tmp_path/'out'),base_max_tokens=256,temperature=0.0,top_p=1.0,seed=1,
    )
    # This fake command demonstrably honors condition via env only for test purposes.
    cfg['provider']['budget_control_validated']=True
    path=tmp_path/'xa06.real.json'; save_config(cfg,path); return path


def test_production_preflight_runs_real_dependency_chain_for_math003_a0(tmp_path):
    config_path=make_config(tmp_path)
    report=production_preflight(config_path, executable_probe=lambda name: None)
    assert report['launch_allowed'] is True
    assert report['status']=='PASS_WITH_WARNINGS'
    trial=next(x for x in report['checks'] if x['name']=='isolated_math003_a0')
    assert trial['status']=='PASS'
    assert trial['detail']['quality']==1.0


def test_real_point_launcher_executes_one_a0_and_returns_persisted_paths(tmp_path):
    config_path=make_config(tmp_path)
    launcher=RealPointLauncher(config_path)
    out=launcher(MatrixPoint('MATH-003','A0',1))
    tr=Path(out['trial_result_path']); sm=Path(out['xa03_summary_path'])
    assert tr.exists() and sm.exists()
    rec=json.loads(tr.read_text(encoding='utf-8'))
    assert rec['task_id']=='MATH-003' and rec['condition']=='A0' and rec['replicate']==1
    assert rec['quality']['scalar_value']==1.0
    summary=json.loads(sm.read_text(encoding='utf-8'))
    assert summary['run']['state']=='COMPLETE'
    audit=Path(launcher.pilot_dir/'provider_audit.json')
    assert audit.exists()

def test_real_point_launcher_archives_existing_trial_before_rerun(tmp_path):
    config_path=make_config(tmp_path)
    launcher=RealPointLauncher(config_path)
    p=MatrixPoint('MATH-003','A0',1)
    first=launcher(p)
    assert Path(first['trial_result_path']).exists()
    launcher.prepare_for_rerun(p)
    assert not Path(first['trial_result_path']).exists()
    archived=list((launcher.pilot_dir/'rerun_archive').rglob('*.json'))
    assert archived
    second=launcher(p)
    assert Path(second['trial_result_path']).exists()
