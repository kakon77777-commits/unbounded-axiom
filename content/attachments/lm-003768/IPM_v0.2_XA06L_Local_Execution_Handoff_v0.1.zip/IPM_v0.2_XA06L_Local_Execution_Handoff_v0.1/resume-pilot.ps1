$ErrorActionPreference = 'Stop'
$Root = $PSScriptRoot
$Python = if ($env:IPM_PYTHON) { $env:IPM_PYTHON } else { 'python' }
if ($env:PYTHONPATH) { $env:PYTHONPATH = "$Root;$env:PYTHONPATH" } else { $env:PYTHONPATH = $Root }
& $Python -m ipm_xa06l.cli resume --config (Join-Path $Root 'xa06.real.json') @args
exit $LASTEXITCODE
