# IPM v0.2 XA-06L — Local Real-Model Execution Handoff Pack

**Artifact:** EML-IPM-XA-06L v0.1  
**Role:** Windows/local handoff from `XA-06 READY_FOR_REAL_MODEL` to a sealed 36-trial real-model result bundle.

## The important status distinction

This software can be fully verified without running your model:

```text
Software: FINAL_VERIFIED
Experiment: NOT_RUN
```

Only a real, non-scripted 36-trial run that passes the XA-06 gate may create:

```text
REAL_MODEL_PILOT_COMPLETE
```

`READY_FOR_REAL_MODEL` is not the same as `REAL_MODEL_PILOT_COMPLETE`.

## What it automates

```text
configure -> preflight -> run/resume -> verify/analyze -> seal -> upload result ZIP
```

The canonical matrix remains:

```text
MATH-003 / CODE-001 / CON-003
× A0 A1 A2 A3 A4 A5
× replicates 1 2
= 36 trials
```

XA-06L does not change any A0→A5 policy. Each point is executed through the XA-06 provider harness and XA-04 `TrialExecutor`; XA-03 records the operational/physical trace and XA-02 scores the result.

## Recommended folder layout on Windows

Unpack the canonical artifacts as siblings:

```text
IPM-local/
  IPM_v0.2_XA02_TaskPack_v0.1/
  IPM_v0.2_XA03_Reference_Logger_v0.1/
  IPM_v0.2_XA04_Model_Runner_v0.1/
  IPM_v0.2_XA06_RealModel_Pilot_Gate_v0.1/
  IPM_v0.2_XA06L_Local_Execution_Handoff_v0.1/
```

All relative paths in `xa06.real.json` are interpreted relative to that config file, not the current PowerShell working directory.

## Windows quick start — local OpenAI-compatible server

From the XA-06L folder:

```powershell
.\configure.ps1
```

Choose:

```text
local_openai_compatible
```

Typical base URL:

```text
http://127.0.0.1:1234
```

Enter the exact model ID exposed by your server.

Then:

```powershell
.\preflight.ps1
```

Preflight performs a real provider call plus one isolated `MATH-003/A0` trial through XA-04 → XA-03 → XA-02.

If it passes:

```powershell
.\run-pilot.ps1
```

If interrupted:

```powershell
.\resume-pilot.ps1
```

After all matrix points are terminal:

```powershell
.\seal-results.ps1
```

The result ZIP appears under:

```text
<output_root>/sealed/
```

Upload that `XA06_REAL_<model>_<timestamp>.zip` back to ChatGPT for IPM analysis.

## Resume behavior

`pilot_state.json` stores SHA-256 for each completed trial result and XA-03 summary.

A point is skipped only if:

- trial result exists;
- summary exists;
- both hashes still match;
- task/condition/replicate identity matches;
- XA-03 state is COMPLETE.

If a supposedly complete point was modified it becomes `INVALID` and is **not** overwritten automatically.

To intentionally rerun an invalid/completed point:

```powershell
.\resume-pilot.ps1 --force
```

The previous trial result/XA-03 run is archived before the same `trial_id` is reused.

## CODE-001 and sandboxing

XA-02 deliberately refuses to execute generated Python by default.

Under the current XA-06 gate, leaving CODE evaluation unavailable means 12/36 code trials do not have measured quality, so the ≥95% quality-availability gate cannot reach canonical COMPLETE.

If you want a `REAL_MODEL_PILOT_COMPLETE` seal **including CODE-001 quality**, run the entire experiment inside an external disposable sandbox/VM/container suitable for executing untrusted generated Python, then configure with:

```powershell
.\configure.ps1 --allow-code-evaluation
```

This flag only tells XA-02 to execute its hidden tests. **XA-06L itself is not a security sandbox.** Do not enable this on a host where untrusted generated code should not run.

If you keep code execution disabled, the pilot is still useful for engineering and partial measurement, but sealing will correctly produce `REAL_MODEL_PILOT_INCOMPLETE` under the current canonical gate.

## Local-command mode

Use this when your model is exposed through a CLI/wrapper that accepts the prompt on stdin and emits only the model response on stdout.

XA-06 exposes these environment variables to the command:

```text
IPM_CONDITION
IPM_TASK_ID
IPM_ROLE
IPM_GENERATION_BUDGET_MULTIPLIER
IPM_BASE_MAX_TOKENS
```

For scientific A0/A1 comparison, only set `--budget-control-validated` if your wrapper genuinely uses the budget multiplier/base-token information to change inference budget. Otherwise XA-06 correctly treats A1 budget control as unvalidated.

## Cloud mode

Cloud OpenAI-compatible APIs can be used for scaffolding-response measurement. API secrets are referenced only by environment-variable name.

Example:

```powershell
$env:MODEL_API_KEY = '...'
```

The secret value is not serialized into `xa06.real.json` or the result bundle.

Cloud runs may have:

```text
device_energy_j = null
```

This is correct. API price/token count is not converted into Joules.

## NVIDIA telemetry

For local GPU runs, preflight checks `nvidia-smi`.

- telemetry optional + no `nvidia-smi` → WARN
- telemetry required + no `nvidia-smi` → FAIL

XA-03 type rules remain intact:

```text
DeviceEnergy != MarginalEnergy
Unknown != 0
GPUUtilization != AllocatedDeviceTime
```

## CLI equivalents

PowerShell wrappers are deliberately thin. The same core works directly:

```bash
python -m ipm_xa06l.cli configure ...
python -m ipm_xa06l.cli preflight --config xa06.real.json
python -m ipm_xa06l.cli run --config xa06.real.json
python -m ipm_xa06l.cli resume --config xa06.real.json
python -m ipm_xa06l.cli seal --config xa06.real.json
python -m ipm_xa06l.cli status --config xa06.real.json
```

Use `IPM_PYTHON` to select a Python executable in PowerShell:

```powershell
$env:IPM_PYTHON = 'C:\Python313\python.exe'
```

## Result-bundle privacy / relocation

During sealing:

- API secret values are excluded;
- dependency/output absolute paths are redacted;
- trial `xa03_run_dir` becomes bundle-relative;
- sealed `pilot_state.json` uses bundle-relative paths and new sealed hashes;
- XA-03 `events.jsonl`, `telemetry.jsonl`, and `summary.json` remain unchanged;
- XA-03 `config.json.output_dir` is path-redacted with provenance recorded in `redaction_provenance.json`.

The returned ZIP can therefore be moved to another machine and reverified without using historical absolute paths.

## Status / failure semantics

A null or negative scientific result is not an engineering failure.

Valid real results can include:

```text
SSR = 1
A3 < A2
A5 < A0
```

The XA-06L gate checks record integrity and protocol validity. It does not require scaffolding to help.

## Files

- `SPEC.md` — frozen design.
- `IMPLEMENTATION_PLAN.md` — TDD execution plan.
- `ipm_xa06l/` — cross-platform core.
- `*.ps1` — Windows thin wrappers.
- `examples/` — provider configurations.
- `IMPORT_BACK.md` — what to upload after the real run.
- `validation_report.json` — software verification evidence.
- `manifest.json` — release file hashes.
