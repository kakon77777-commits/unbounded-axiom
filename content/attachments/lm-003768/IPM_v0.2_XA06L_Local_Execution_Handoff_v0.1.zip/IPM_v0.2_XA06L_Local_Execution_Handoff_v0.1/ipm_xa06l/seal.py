from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from copy import deepcopy
import hashlib, json, re, shutil, zipfile
from .config import redact_config


def _sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024),b''): h.update(c)
    return h.hexdigest()

def _write_json(path: Path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

def _safe_name(s: str) -> str:
    x=re.sub(r"[^A-Za-z0-9._-]+","_",s).strip("_.")
    return x or "model"

def _portable_config(config: dict) -> dict:
    d=redact_config(deepcopy(config))
    if "dependencies" in d:
        d["dependencies"]={k:f"<external:{k}>" for k in d["dependencies"]}
    if "output_root" in d: d["output_root"]="."
    if "output_dir" in d: d["output_dir"]="."
    if "pilot_run_dir" in d: d["pilot_run_dir"]="."
    p=d.get("provider") or {}
    if p.get("command"):
        p["command"]=["<redacted-local-command>"]
    return d

def _sanitize_xa03_config(path: Path, provenance: list[dict]) -> None:
    if not path.exists(): return
    before=_sha(path)
    try: data=json.loads(path.read_text(encoding="utf-8"))
    except Exception: return
    if "output_dir" in data:
        data["output_dir"]="<bundle-relative-xa03-root>"
        _write_json(path,data)
        provenance.append({"file":str(path.name),"kind":"path_redaction","source_sha256":before,"sealed_sha256":_sha(path),"fields":["output_dir"]})

def _sanitize_pilot_meta(path: Path, provenance: list[dict]) -> None:
    if not path.exists(): return
    before=_sha(path)
    try:data=json.loads(path.read_text(encoding="utf-8"))
    except Exception:return
    changed=[]
    for key in ("pilot_dir","output_dir","output_root"):
        if key in data:
            data[key]="."
            changed.append(key)
    if changed:
        _write_json(path,data); provenance.append({"file":path.name,"kind":"path_redaction","source_sha256":before,"sealed_sha256":_sha(path),"fields":changed})

def seal_results(*, config: dict, state, preflight: dict, gate_report: dict, output_dir: str|Path) -> dict:
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    model_id=config.get("provider",{}).get("model_id","model")
    stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    bundle_name=f"XA06_REAL_{_safe_name(model_id)}_{stamp}"
    stage=out/bundle_name
    if stage.exists(): shutil.rmtree(stage)
    stage.mkdir()
    provenance=[]
    _write_json(stage/"xa06.real.redacted.json",_portable_config(config))
    _write_json(stage/"preflight.json",preflight)
    _write_json(stage/"gate_summary.json",gate_report)
    tr_dir=stage/"trial_results"; xr_dir=stage/"xa03_runs"; tr_dir.mkdir(); xr_dir.mkdir()
    portable_state=deepcopy(state.data)
    for key,rec in sorted(state.data.get("points",{}).items()):
        if rec.get("status")!="COMPLETE": continue
        tr=Path(rec["trial_result_path"]); sm=Path(rec["xa03_summary_path"])
        if not tr.is_absolute(): tr=(state.path.parent/tr).resolve()
        if not sm.is_absolute(): sm=(state.path.parent/sm).resolve()
        trial_data=json.loads(tr.read_text(encoding="utf-8"))
        trial_id=str(trial_data.get("trial_id") or key)
        source_trial_sha=_sha(tr)
        trial_data["xa03_run_dir"]=f"xa03_runs/{trial_id}"
        sealed_tr=tr_dir/tr.name
        _write_json(sealed_tr,trial_data)
        if _sha(sealed_tr)!=source_trial_sha:
            provenance.append({"file":f"trial_results/{tr.name}","kind":"path_redaction","source_sha256":source_trial_sha,"sealed_sha256":_sha(sealed_tr),"fields":["xa03_run_dir"]})
        run_source=sm.parent; dest=xr_dir/trial_id
        shutil.copytree(run_source,dest)
        _sanitize_xa03_config(dest/"config.json",provenance)
        sealed_sm=dest/"summary.json"
        pr=portable_state["points"][key]
        pr["trial_result_path"]=f"trial_results/{tr.name}"
        pr["xa03_summary_path"]=f"xa03_runs/{trial_id}/summary.json"
        pr["trial_result_sha256"]=_sha(sealed_tr)
        pr["xa03_summary_sha256"]=_sha(sealed_sm)
    _write_json(stage/"pilot_state.json",portable_state)
    # Copy analysis and gate-relevant surfaces; sanitize only path-bearing metadata.
    candidates=[state.path.parent, Path(config.get("pilot_run_dir",""))] if config.get("pilot_run_dir") else [state.path.parent]
    names=("aggregate.json","analysis.json","pilot_report.md","condition_summary.csv","trial_index.csv","physical_summary.csv","protocol_compliance.csv","provider_audit.json","pilot_run_summary.json","matrix_index.json")
    for base in candidates:
        if not base or not Path(base).exists(): continue
        for name in names:
            p=Path(base)/name
            if p.exists() and not (stage/name).exists(): shutil.copy2(p,stage/name)
    _sanitize_pilot_meta(stage/"pilot_run_summary.json",provenance)
    marker="REAL_MODEL_PILOT_COMPLETE" if gate_report.get("gate_pass") else "REAL_MODEL_PILOT_INCOMPLETE"
    (stage/marker).write_text(marker+"\n",encoding="utf-8")
    _write_json(stage/"redaction_provenance.json",provenance)
    files={}
    for p in sorted(stage.rglob('*')):
        if p.is_file() and p.name!="manifest.json": files[p.relative_to(stage).as_posix()]=_sha(p)
    _write_json(stage/"manifest.json",{"artifact":"XA06L-result-bundle-v0.1","complete":bool(gate_report.get("gate_pass")),"files":files,"redaction_provenance":"redaction_provenance.json"})
    zip_path=out/f"{bundle_name}.zip"
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(stage.rglob('*')):
            if p.is_file(): z.write(p,f"{bundle_name}/{p.relative_to(stage).as_posix()}")
    return {"complete":bool(gate_report.get("gate_pass")),"bundle_dir":str(stage),"zip_path":str(zip_path),"zip_sha256":_sha(zip_path)}
