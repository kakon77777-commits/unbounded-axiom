from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import json, shutil, sys, tempfile, re, time
from .config import load_config
from .preflight import run_preflight


def _load_xa06_config(config_path: str|Path):
    config_path=Path(config_path).resolve()
    raw=load_config(config_path)
    xa06_root=Path(raw["dependencies"]["xa06_root"]).resolve()
    if str(xa06_root) not in sys.path: sys.path.insert(0,str(xa06_root))
    from ipm_xa06.config import PilotConfig
    cfg=PilotConfig.from_file(config_path)
    cfg.validate_runtime_environment(); cfg.activate_dependencies()
    return raw,cfg

def _build_executor(cfg, output_dir: Path):
    from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor
    pack=TaskPack(cfg.dependencies.xa02_root)
    evaluator=EvaluatorBridge(cfg.dependencies.xa02_root,allow_code_execution=cfg.evaluation.allow_code_evaluation)
    return TrialExecutor(pack,evaluator,xa03_root=cfg.dependencies.xa03_root,output_dir=output_dir)

def _provider_probe(config_path: Path):
    raw,cfg=_load_xa06_config(config_path)
    from ipm_xa06.providers import build_harnessed_provider
    from ipm_xa04.models import GenerationRequest
    p=build_harnessed_provider(cfg.provider)
    req=GenerationRequest(prompt="XA-06L connectivity probe. Return a short response.",role="generator",condition="A0",task_id="PREFLIGHT",generation_budget_multiplier=1.0)
    res=p.generate(req)
    return True,{"model_id":cfg.provider.model_id,"provider_id":cfg.provider.provider_id,"response_nonempty":bool(str(res.text).strip())}

def _trial_probe(config_path: Path):
    raw,cfg=_load_xa06_config(config_path)
    from ipm_xa06.providers import build_harnessed_provider
    from ipm_xa04 import ToolRegistry
    out_root=Path(raw["output_root"]); out_root.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="xa06l-preflight-",dir=out_root) as td:
        executor=_build_executor(cfg,Path(td)/"pilot")
        provider=build_harnessed_provider(cfg.provider)
        r=executor.execute("MATH-003","A0",provider,replicate=99,tools=ToolRegistry([]),collectors=("null",),physical_boundary="preflight-client")
        q=getattr(r,"quality",None)
        ok=(getattr(r,"failure",None) is None and q is not None and getattr(q,"scalar_value",None) is not None)
        return ok,{"trial_id":r.trial_id,"quality":getattr(q,"scalar_value",None),"failure":getattr(r,"failure",None)}

def production_preflight(config_path: str|Path, *, executable_probe=shutil.which) -> dict:
    p=Path(config_path).resolve(); raw=load_config(p)
    return run_preflight(raw,provider_probe=lambda c:_provider_probe(p),trial_probe=lambda c:_trial_probe(p),executable_probe=executable_probe)

def _write_json(path: Path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

class RealPointLauncher:
    def __init__(self, config_path: str|Path):
        self.config_path=Path(config_path).resolve()
        self.raw,self.cfg=_load_xa06_config(self.config_path)
        from ipm_xa04 import TaskPack, EvaluatorBridge, TrialExecutor
        self.pilot_dir=self.cfg.output_dir/"pilot"
        self.executor=_build_executor(self.cfg,self.pilot_dir)
        self.audit_path=self.pilot_dir/"provider_audit.json"

    def _append_audits(self, trial_id: str, provider) -> None:
        rows=[]
        if self.audit_path.exists():
            try: rows=json.loads(self.audit_path.read_text(encoding="utf-8"))
            except Exception: rows=[]
        for rec in getattr(provider,"audit_records",[]): rows.append({"trial_id":trial_id,**rec})
        _write_json(self.audit_path,rows)

    def _trial_id(self, point):
        safe=re.sub(r"[^A-Za-z0-9_.-]+","_",self.cfg.provider.model_id)[:80] or "model"
        return f"IPM-XA-{safe}-{point.task_id}-{point.condition}-{point.replicate:02d}"

    def prepare_for_rerun(self, point):
        trial_id=self._trial_id(point)
        archive=self.pilot_dir/"rerun_archive"/(point.key+"-"+str(time.time_ns()))
        moved=False
        for src in (self.pilot_dir/"trial_results"/f"{trial_id}.json", self.pilot_dir/"xa03_runs"/trial_id, self.pilot_dir/"xa03_runs"/f".{trial_id}.partial"):
            if src.exists():
                archive.mkdir(parents=True,exist_ok=True)
                shutil.move(str(src),str(archive/src.name)); moved=True
        return moved

    def __call__(self, point):
        from ipm_xa06.providers import build_harnessed_provider
        from ipm_xa04 import SameModelVerifier, CalculatorTool, ToolRegistry
        provider=build_harnessed_provider(self.cfg.provider)
        verifier=SameModelVerifier() if point.condition in {"A3","A4","A5"} else None
        tools=ToolRegistry([CalculatorTool()])
        r=self.executor.execute(point.task_id,point.condition,provider,replicate=point.replicate,verifier=verifier,tools=tools,collectors=self.cfg.telemetry.collectors,physical_boundary=self.cfg.telemetry.physical_boundary)
        self._append_audits(r.trial_id,provider)
        tr=self.pilot_dir/"trial_results"/f"{r.trial_id}.json"
        sm=self.pilot_dir/"xa03_runs"/r.trial_id/"summary.json"
        return {"trial_result_path":str(tr),"xa03_summary_path":str(sm),"trial_id":r.trial_id,"failure":r.failure}

    def write_pilot_metadata(self, state) -> None:
        complete=sum(1 for rec in state.data.get("points",{}).values() if rec.get("status")=="COMPLETE")
        failed=sum(1 for rec in state.data.get("points",{}).values() if rec.get("status") in {"FAILED","INVALID"})
        _write_json(self.pilot_dir/"pilot_run_summary.json",{
            "kind":"real_model_pilot_run","status":"REAL_MODEL_RUN_COMPLETE_UNVERIFIED" if complete==36 else "REAL_MODEL_RUN_PARTIAL",
            "engineering_validation_only":False,"real_model_pilot_complete":False,"trial_count":complete,"failure_count":failed,
            "expected_trial_count":36,"provider_id":self.cfg.provider.provider_id,"model_id":self.cfg.provider.model_id,
            "tasks":["MATH-003","CODE-001","CON-003"],"conditions":["A0","A1","A2","A3","A4","A5"],"replicates":2,"pilot_dir":str(self.pilot_dir)
        })
