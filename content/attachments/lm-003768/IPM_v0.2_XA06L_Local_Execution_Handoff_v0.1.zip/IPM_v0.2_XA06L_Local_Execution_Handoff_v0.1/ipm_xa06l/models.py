from __future__ import annotations
from dataclasses import dataclass

@dataclass(frozen=True, slots=True)
class MatrixPoint:
    task_id: str
    condition: str
    replicate: int

    @property
    def key(self) -> str:
        return f"{self.task_id}__{self.condition}__r{self.replicate}"
