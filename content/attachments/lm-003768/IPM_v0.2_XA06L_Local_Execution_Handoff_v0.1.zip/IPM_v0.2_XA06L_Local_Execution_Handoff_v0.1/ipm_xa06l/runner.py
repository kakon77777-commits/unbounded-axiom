from __future__ import annotations


def run_points(points, state, *, trial_launcher, resume: bool=True, force: bool=False, progress=None):
    total=len(points)
    for idx, point in enumerate(points,1):
        rec=state.get(point)
        if resume and rec.get("status")=="COMPLETE":
            ok, reason=state.verify_complete(point)
            if ok and not force:
                if progress: progress(idx,total,point,"SKIP")
                continue
            if not ok:
                state.mark_invalid(point,reason); state.save()
                if not force:
                    if progress: progress(idx,total,point,"INVALID")
                    continue
        elif rec.get("status")=="INVALID" and not force:
            if progress: progress(idx,total,point,"INVALID")
            continue
        current_status=state.get(point).get("status")
        if hasattr(trial_launcher,"prepare_for_rerun") and (current_status=="FAILED" or (force and current_status in {"COMPLETE","INVALID"})):
            trial_launcher.prepare_for_rerun(point)
        state.mark_running(point); state.save()
        if progress: progress(idx,total,point,"RUNNING")
        try:
            result=trial_launcher(point)
            if not isinstance(result,dict) or not result.get("trial_result_path") or not result.get("xa03_summary_path"):
                raise RuntimeError("trial launcher must return trial_result_path and xa03_summary_path")
            state.mark_complete(point,result["trial_result_path"],result["xa03_summary_path"]); state.save()
            if progress: progress(idx,total,point,"COMPLETE")
        except KeyboardInterrupt:
            state.mark_failed(point,"KeyboardInterrupt"); state.save()
            raise
        except Exception as e:
            state.mark_failed(point,type(e).__name__); state.save()
            if progress: progress(idx,total,point,"FAILED")
    return state
