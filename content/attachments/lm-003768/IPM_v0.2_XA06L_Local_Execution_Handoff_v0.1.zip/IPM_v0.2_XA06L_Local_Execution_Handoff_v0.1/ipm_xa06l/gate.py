from __future__ import annotations
from pathlib import Path
import importlib.util, sys
from .matrix import canonical_matrix

REAL_PROVIDER_MODES={"local_openai_compatible","local_command","cloud_openai_compatible"}

def _default_xa06_gate(run_dir: Path, config: dict) -> dict:
    root=Path(config["dependencies"]["xa06_root"])
    mod_path=root/"ipm_xa06"/"verify_gate.py"
    if not mod_path.exists():
        return {"gate_pass":False,"real_model_pilot_complete":False,"status":"DEPENDENCY_FAILURE","error":"XA06 verify_gate.py not found"}
    # Import package with root on sys.path so relative imports are safe if needed.
    old=list(sys.path); sys.path.insert(0,str(root))
    try:
        from ipm_xa06.verify_gate import verify_gate
        return verify_gate(run_dir,write=False)
    finally:
        sys.path[:]=old

def evaluate_handoff_gate(config: dict, state, *, preflight: dict, xa06_gate_probe=None) -> dict:
    points=canonical_matrix()
    verified=[]; invalid=[]
    for p in points:
        ok, reason=state.verify_complete(p)
        if ok: verified.append(p.key)
        else: invalid.append({"point":p.key,"reason":reason})
    mode=config.get("provider_mode") or config.get("provider",{}).get("mode")
    real_mode=mode in REAL_PROVIDER_MODES
    safe_preflight=bool(preflight.get("launch_allowed")) and not bool(preflight.get("unsafe_override"))
    exact=len(verified)==36 and not invalid
    run_dir=Path(config.get("pilot_run_dir") or (Path(config.get("output_root",state.path.parent))/"pilot"))
    probe=xa06_gate_probe or _default_xa06_gate
    xa06_report=probe(run_dir,config) if exact else {"gate_pass":False,"real_model_pilot_complete":False,"status":"NOT_READY"}
    xa06_pass=bool(xa06_report.get("gate_pass"))
    checks={
        "exact_36_verified_complete":exact,
        "real_provider_mode":real_mode,
        "safe_preflight":safe_preflight,
        "xa06_gate_pass":xa06_pass,
    }
    gate_pass=all(checks.values())
    return {
        "schema_version":"XA06L-gate-v0.1",
        "status":"REAL_MODEL_PILOT_COMPLETE" if gate_pass else "REAL_MODEL_PILOT_INCOMPLETE",
        "gate_pass":gate_pass,
        "real_model_pilot_complete":gate_pass,
        "provider_mode":mode,
        "verified_complete_count":len(verified),
        "invalid_or_missing":invalid,
        "checks":checks,
        "xa06_gate":xa06_report,
    }
