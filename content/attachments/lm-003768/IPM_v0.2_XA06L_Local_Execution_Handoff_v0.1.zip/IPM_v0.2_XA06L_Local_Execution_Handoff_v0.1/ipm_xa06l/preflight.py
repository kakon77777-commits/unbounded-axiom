from __future__ import annotations
from pathlib import Path
import os, sys, shutil, tempfile


def _check(name, status, detail, required=True):
    return {"name":name,"status":status,"detail":detail,"required":required}


def run_preflight(config: dict, *, provider_probe, trial_probe, executable_probe=shutil.which) -> dict:
    checks=[]
    checks.append(_check("python_version", "PASS" if sys.version_info >= (3,11) else "FAIL", sys.version.split()[0]))
    for key, raw in config.get("dependencies",{}).items():
        p=Path(raw)
        checks.append(_check(key, "PASS" if p.exists() else "FAIL", str(p)))
    out=Path(config["output_root"])
    try:
        out.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=out, prefix=".xa06l-write-", delete=True) as f:
            f.write(b"ok"); f.flush()
        checks.append(_check("output_root_write", "PASS", str(out)))
    except Exception as e:
        checks.append(_check("output_root_write", "FAIL", repr(e)))
    try:
        ok, detail = provider_probe(config)
    except Exception as e:
        ok, detail = False, repr(e)
    checks.append(_check("provider_connectivity", "PASS" if ok else "FAIL", detail))

    nvidia = executable_probe("nvidia-smi")
    required_gpu = bool(config.get("telemetry",{}).get("required",False))
    if nvidia:
        checks.append(_check("nvidia_smi","PASS",str(nvidia),required=required_gpu))
    else:
        checks.append(_check("nvidia_smi","FAIL" if required_gpu else "WARN","not found",required=required_gpu))

    try:
        ok, detail = trial_probe(config)
    except Exception as e:
        ok, detail = False, {"exception":repr(e)}
    checks.append(_check("isolated_math003_a0", "PASS" if ok else "FAIL", detail))

    hard_fail = any(c["status"]=="FAIL" and c.get("required",True) for c in checks)
    warns = any(c["status"]=="WARN" for c in checks)
    return {
        "schema_version":"XA06L-preflight-v0.1",
        "status":"FAIL" if hard_fail else ("PASS_WITH_WARNINGS" if warns else "PASS"),
        "launch_allowed":not hard_fail,
        "checks":checks,
    }
