from __future__ import annotations
from .models import MatrixPoint

TASKS = ("MATH-003", "CODE-001", "CON-003")
CONDITIONS = ("A0", "A1", "A2", "A3", "A4", "A5")
REPLICATES = (1, 2)

def canonical_matrix() -> list[MatrixPoint]:
    return [MatrixPoint(t, c, r) for t in TASKS for c in CONDITIONS for r in REPLICATES]
