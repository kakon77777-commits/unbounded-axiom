from __future__ import annotations
from pathlib import Path
import argparse, json, sys
from .config import build_config, save_config, load_config
from .integration import production_preflight, RealPointLauncher
from .matrix import canonical_matrix
from .state import PilotState
from .runner import run_points
from .gate import evaluate_handoff_gate
from .seal import seal_results


def _write_json(path: Path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+"\n",encoding="utf-8")

def _read_raw(path: str|Path) -> dict:
    return load_config(path)

def _out_root(raw: dict) -> Path:
    return Path(raw.get("output_root") or raw.get("output_dir") or "xa06_real_pilot_output").resolve()

def _preflight_path(raw: dict) -> Path: return _out_root(raw)/"preflight.json"
def _state_path(raw: dict) -> Path: return _out_root(raw)/"pilot_state.json"

def configure_command(args) -> Path:
    def prompt(label, default=None):
        s=input(f"{label}" + (f" [{default}]" if default is not None else "") + ": ").strip()
        return s if s else default
    if args.interactive:
        args.provider_mode=prompt("Provider mode (local_openai_compatible/local_command/cloud_openai_compatible)",args.provider_mode or "local_openai_compatible")
        args.model_id=prompt("Model ID",args.model_id or "")
        if args.provider_mode!="local_command": args.endpoint=prompt("Endpoint/base URL",args.endpoint or "http://127.0.0.1:1234")
        else:
            cmd=prompt("Local command",None); args.command=cmd.split() if cmd else []
        args.xa02_root=prompt("XA-02 root",args.xa02_root or "../IPM_v0.2_XA02_TaskPack_v0.1")
        args.xa03_root=prompt("XA-03 root",args.xa03_root or "../IPM_v0.2_XA03_Reference_Logger_v0.1")
        args.xa04_root=prompt("XA-04 root",args.xa04_root or "../IPM_v0.2_XA04_Model_Runner_v0.1")
        args.xa06_root=prompt("XA-06 root",args.xa06_root or "../IPM_v0.2_XA06_RealModel_Pilot_Gate_v0.1")
        args.output_root=prompt("Pilot output root",args.output_root or "./xa06_real_pilot_output")
    required=("provider_mode","model_id","xa02_root","xa03_root","xa04_root","xa06_root","output_root")
    missing=[x for x in required if not getattr(args,x,None)]
    if missing: raise ValueError("missing configure arguments: "+", ".join(missing))
    cfg=build_config(provider_mode=args.provider_mode,model_id=args.model_id,endpoint=args.endpoint,command=args.command,api_key_env=args.api_key_env,
                     xa02_root=args.xa02_root,xa03_root=args.xa03_root,xa04_root=args.xa04_root,xa06_root=args.xa06_root,output_root=args.output_root,
                     base_max_tokens=args.base_max_tokens,temperature=args.temperature,top_p=args.top_p,seed=args.seed,telemetry_required=args.telemetry_required,allow_code_evaluation=args.allow_code_evaluation)
    if args.provider_mode=="local_command" and args.budget_control_validated:
        cfg["provider"]["budget_control_validated"]=True
    return save_config(cfg,args.output)

def preflight_command(config_path: str|Path) -> dict:
    raw=load_config(config_path); report=production_preflight(config_path); _write_json(_preflight_path(raw),report); return report

def _load_preflight(raw: dict, unsafe_preflight: bool) -> dict:
    p=_preflight_path(raw)
    if not p.exists():
        if not unsafe_preflight: raise RuntimeError("preflight.json is missing; run preflight first")
        pre={"status":"UNSAFE_OVERRIDE","launch_allowed":True,"unsafe_override":True,"checks":[]}; _write_json(p,pre); return pre
    pre=json.loads(p.read_text(encoding="utf-8"))
    if not pre.get("launch_allowed"):
        if not unsafe_preflight: raise RuntimeError("preflight did not pass; launch refused")
        pre["unsafe_override"]=True; pre["launch_allowed"]=True; _write_json(p,pre)
    return pre

def _progress(i,total,p,status):
    print(f"[{i:02d}/{total:02d}] {p.task_id} {p.condition} replicate {p.replicate} — {status}",flush=True)

def _state_counts(state):
    vals=[r.get("status","PENDING") for r in state.data.get("points",{}).values()]
    return {k:vals.count(k) for k in ("COMPLETE","FAILED","PENDING","INVALID","RUNNING")}

def run_command(config_path: str|Path, *, unsafe_preflight: bool=False, launcher_factory=RealPointLauncher) -> dict:
    raw=_read_raw(config_path); _load_preflight(raw,unsafe_preflight)
    sp=_state_path(raw)
    if sp.exists():
        old=PilotState.load(sp)
        if old.data.get("points"): raise RuntimeError("pilot_state.json already contains trial state; use resume instead")
        state=old
    else: state=PilotState.create(sp)
    launcher=launcher_factory(config_path)
    run_points(canonical_matrix(),state,trial_launcher=launcher,resume=False,force=False,progress=_progress)
    if hasattr(launcher,"write_pilot_metadata"): launcher.write_pilot_metadata(state)
    return {"status":"RUN_FINISHED","counts":_state_counts(state),"state_path":str(sp)}

def resume_command(config_path: str|Path, *, force: bool=False, unsafe_preflight: bool=False, launcher_factory=RealPointLauncher) -> dict:
    raw=_read_raw(config_path); _load_preflight(raw,unsafe_preflight)
    sp=_state_path(raw); state=PilotState.load(sp) if sp.exists() else PilotState.create(sp)
    launcher=launcher_factory(config_path)
    run_points(canonical_matrix(),state,trial_launcher=launcher,resume=True,force=force,progress=_progress)
    if hasattr(launcher,"write_pilot_metadata"): launcher.write_pilot_metadata(state)
    return {"status":"RESUME_FINISHED","counts":_state_counts(state),"state_path":str(sp)}

def _run_analysis(config_path: str|Path, raw: dict) -> dict:
    xa06=Path(raw["dependencies"]["xa06_root"]).resolve(); xa04=Path(raw["dependencies"]["xa04_root"]).resolve()
    if str(xa06) not in sys.path: sys.path.insert(0,str(xa06))
    from ipm_xa06.analyze import analyze_pilot
    return analyze_pilot(_out_root(raw)/"pilot",xa04_root=xa04)

def seal_command(config_path: str|Path) -> dict:
    raw=_read_raw(config_path); sp=_state_path(raw)
    if not sp.exists(): raise RuntimeError("pilot_state.json missing")
    pp=_preflight_path(raw)
    if not pp.exists(): raise RuntimeError("preflight.json missing")
    state=PilotState.load(sp); pre=json.loads(pp.read_text(encoding="utf-8"))
    gate_cfg=dict(raw); gate_cfg["pilot_run_dir"]=str(_out_root(raw)/"pilot")
    gate=evaluate_handoff_gate(gate_cfg,state,preflight=pre)
    pilot=_out_root(raw)/"pilot"; pilot.mkdir(parents=True,exist_ok=True); _write_json(pilot/"gate_summary.json",gate)
    try: analysis=_run_analysis(config_path,raw)
    except Exception as e:
        analysis={"status":"ANALYSIS_FAILED","error_type":type(e).__name__,"error":str(e)}; _write_json(pilot/"analysis.json",analysis)
        if gate.get("gate_pass"):
            gate["gate_pass"]=False; gate["real_model_pilot_complete"]=False; gate["status"]="REAL_MODEL_PILOT_INCOMPLETE"; gate["checks"]["analysis_completed"]=False; _write_json(pilot/"gate_summary.json",gate)
    return seal_results(config=gate_cfg,state=state,preflight=pre,gate_report=gate,output_dir=_out_root(raw)/"sealed")

def main(argv=None):
    ap=argparse.ArgumentParser(prog="ipm-xa06l"); sub=ap.add_subparsers(dest="cmd",required=True)
    c=sub.add_parser("configure"); c.add_argument("--interactive",action="store_true"); c.add_argument("--output",default="xa06.real.json")
    c.add_argument("--provider-mode",choices=["local_openai_compatible","local_command","cloud_openai_compatible"]); c.add_argument("--model-id"); c.add_argument("--endpoint"); c.add_argument("--command",nargs="+"); c.add_argument("--api-key-env")
    for n in ("xa02_root","xa03_root","xa04_root","xa06_root","output_root"): c.add_argument("--"+n.replace('_','-'),dest=n)
    c.add_argument("--base-max-tokens",type=int,default=1024); c.add_argument("--allow-code-evaluation",action="store_true"); c.add_argument("--temperature",type=float,default=0.2); c.add_argument("--top-p",type=float,default=1.0); c.add_argument("--seed",type=int,default=7); c.add_argument("--telemetry-required",action="store_true"); c.add_argument("--budget-control-validated",action="store_true")
    for name in ("preflight","run","resume","seal","status"):
        p=sub.add_parser(name); p.add_argument("--config",required=True)
        if name in {"run","resume"}: p.add_argument("--unsafe-preflight",action="store_true")
        if name=="resume": p.add_argument("--force",action="store_true")
    a=ap.parse_args(argv)
    try:
        if a.cmd=="configure": out=configure_command(a); print(json.dumps({"status":"CONFIG_WRITTEN","path":str(out)},ensure_ascii=False)); return 0
        if a.cmd=="preflight": r=preflight_command(a.config); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0 if r.get("launch_allowed") else 1
        if a.cmd=="run": r=run_command(a.config,unsafe_preflight=a.unsafe_preflight); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0
        if a.cmd=="resume": r=resume_command(a.config,force=a.force,unsafe_preflight=a.unsafe_preflight); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0
        if a.cmd=="seal": r=seal_command(a.config); print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0 if r.get("complete") else 1
        if a.cmd=="status":
            raw=_read_raw(a.config); sp=_state_path(raw); state=PilotState.load(sp) if sp.exists() else None
            r={"software_status":"READY_FOR_REAL_MODEL","real_model_pilot_complete":False,"matrix_points":36,"state_counts":_state_counts(state) if state else {"COMPLETE":0,"FAILED":0,"PENDING":36,"INVALID":0,"RUNNING":0}}
            print(json.dumps(r,ensure_ascii=False,sort_keys=True)); return 0
    except Exception as e:
        print(json.dumps({"status":"FAIL","error_type":type(e).__name__,"error":str(e)},ensure_ascii=False),file=sys.stderr); return 2
    return 2

if __name__=="__main__": raise SystemExit(main())
