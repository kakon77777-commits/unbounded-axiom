from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import json

_ALLOWED_MODES = {"local_openai_compatible", "local_command", "cloud_openai_compatible"}
_SECRET_KEYS = {"api_key", "token", "authorization", "password", "secret"}

def build_config(*, provider_mode: str, model_id: str, endpoint: str | None = None,
                 command: list[str] | None = None, api_key_env: str | None = None,
                 xa02_root: str, xa03_root: str, xa04_root: str, xa06_root: str,
                 output_root: str, base_max_tokens: int = 512, temperature: float = 0.0,
                 top_p: float = 1.0, seed: int | None = None,
                 telemetry_required: bool = False, allow_code_evaluation: bool = False) -> dict:
    if provider_mode not in _ALLOWED_MODES:
        raise ValueError(f"unsupported provider mode: {provider_mode}")
    if not model_id:
        raise ValueError("model_id is required")
    if base_max_tokens <= 0:
        raise ValueError("base_max_tokens must be positive")
    xa06_mode = {
        "local_openai_compatible": "openai_compatible",
        "cloud_openai_compatible": "cloud_openai_compatible",
        "local_command": "local_command",
    }[provider_mode]
    provider = {
        "mode": xa06_mode,
        "provider_id": provider_mode.replace("_", "-"),
        "model_id": model_id,
        "base_url": endpoint,
        "auth_mode": "bearer_env" if api_key_env else "none",
        "api_key_env": api_key_env,
        "base_max_tokens": int(base_max_tokens),
        "token_budget_field": "max_tokens",
        "temperature": float(temperature),
        "top_p": float(top_p),
        "seed": seed,
        "command": command or [],
        "extra_body": {},
        "budget_control_validated": bool(provider_mode != "local_command"),
    }
    return {
        "status": "READY_FOR_REAL_MODEL",
        "schema_version": "XA06L-v0.1",
        "provider_mode": provider_mode,
        "provider": provider,
        "dependencies": {
            "xa02_root": str(xa02_root),
            "xa03_root": str(xa03_root),
            "xa04_root": str(xa04_root),
            "xa06_root": str(xa06_root),
        },
        "experiment": {"tasks": ["MATH-003", "CODE-001", "CON-003"], "conditions": ["A0","A1","A2","A3","A4","A5"], "replicates": 2},
        "telemetry": {
            "required": bool(telemetry_required),
            "collectors": ["system", "nvidia_smi"] if provider_mode != "cloud_openai_compatible" else ["null"],
            "physical_boundary": "local-runner-plus-visible-accelerator" if provider_mode != "cloud_openai_compatible" else "cloud-api-client-only",
        },
        "evaluation": {"allow_code_evaluation": bool(allow_code_evaluation)},
        "output_dir": str(output_root),
        "output_root": str(output_root),
    }

def _redact(obj):
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            kl = k.lower()
            if kl in _SECRET_KEYS or ("secret" in kl and kl != "api_key_env"):
                continue
            out[k] = _redact(v)
        return out
    if isinstance(obj, list):
        return [_redact(v) for v in obj]
    return obj

def redact_config(config: dict) -> dict:
    return _redact(deepcopy(config))

def save_config(config: dict, path: str | Path) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    redacted = redact_config(config)
    p.write_text(json.dumps(redacted, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return p

def load_config(path: str | Path) -> dict:
    p = Path(path).resolve()
    base = p.parent
    data = json.loads(p.read_text(encoding="utf-8"))
    if data.get("provider_mode") not in _ALLOWED_MODES:
        raise ValueError("invalid provider_mode")
    deps=data.get("dependencies", {})
    for key in ("xa02_root","xa03_root","xa04_root","xa06_root"):
        if key not in deps:
            raise ValueError(f"missing dependency root: {key}")
        q=Path(str(deps[key]))
        deps[key]=str(q.resolve() if q.is_absolute() else (base/q).resolve())
    raw_out=data.get("output_root") or data.get("output_dir") or "./xa06_real_pilot_output"
    q=Path(str(raw_out)); resolved=str(q.resolve() if q.is_absolute() else (base/q).resolve())
    data["output_root"]=resolved
    data["output_dir"]=resolved
    return data
