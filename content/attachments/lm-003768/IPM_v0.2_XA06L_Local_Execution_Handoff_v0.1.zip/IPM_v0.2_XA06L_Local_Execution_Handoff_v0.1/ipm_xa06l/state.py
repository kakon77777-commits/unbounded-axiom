from __future__ import annotations
from pathlib import Path
import hashlib, json
from datetime import datetime, timezone


def sha256_file(path: str | Path) -> str:
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def _now():
    return datetime.now(timezone.utc).isoformat()

class PilotState:
    def __init__(self, path: Path, data: dict):
        self.path=Path(path); self.data=data

    @classmethod
    def create(cls, path: str|Path):
        p=Path(path)
        obj=cls(p,{"schema_version":"XA06L-state-v0.1","points":{}})
        obj.save(); return obj

    @classmethod
    def load(cls, path: str|Path):
        p=Path(path); return cls(p,json.loads(p.read_text(encoding='utf-8')))

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.path.with_suffix(self.path.suffix+'.tmp')
        tmp.write_text(json.dumps(self.data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        tmp.replace(self.path)

    def get(self, point):
        return self.data["points"].get(point.key,{"status":"PENDING"})

    def mark_running(self, point):
        self.data["points"][point.key]={"status":"RUNNING","task_id":point.task_id,"condition":point.condition,"replicate":point.replicate,"started_at":_now()}

    def mark_complete(self, point, trial_result_path, xa03_summary_path):
        tr=Path(trial_result_path); sm=Path(xa03_summary_path)
        self.data["points"][point.key]={
            "status":"COMPLETE","task_id":point.task_id,"condition":point.condition,"replicate":point.replicate,
            "trial_result_path":str(tr),"xa03_summary_path":str(sm),
            "trial_result_sha256":sha256_file(tr),"xa03_summary_sha256":sha256_file(sm),"completed_at":_now()
        }

    def mark_failed(self, point, failure):
        rec=self.get(point).copy(); rec.update({"status":"FAILED","task_id":point.task_id,"condition":point.condition,"replicate":point.replicate,"failure":failure,"failed_at":_now()})
        self.data["points"][point.key]=rec

    def mark_invalid(self, point, reason):
        rec=self.get(point).copy(); rec.update({"status":"INVALID","invalid_reason":reason,"invalidated_at":_now()})
        self.data["points"][point.key]=rec

    def verify_complete(self, point) -> tuple[bool,str]:
        rec=self.get(point)
        if rec.get("status")!="COMPLETE": return False,"not_complete"
        try:
            tr=Path(rec["trial_result_path"]); sm=Path(rec["xa03_summary_path"])
            if not tr.is_absolute(): tr=(self.path.parent/tr).resolve()
            if not sm.is_absolute(): sm=(self.path.parent/sm).resolve()
            if not tr.exists() or not sm.exists(): return False,"missing_file"
            if sha256_file(tr)!=rec.get("trial_result_sha256"): return False,"trial_result_hash_mismatch"
            if sha256_file(sm)!=rec.get("xa03_summary_sha256"): return False,"xa03_summary_hash_mismatch"
            data=json.loads(tr.read_text(encoding='utf-8'))
            if (data.get("task_id"),data.get("condition"),data.get("replicate")) != (point.task_id,point.condition,point.replicate):
                return False,"trial_identity_mismatch"
            summary=json.loads(sm.read_text(encoding='utf-8'))
            if summary.get("run",{}).get("state")!="COMPLETE": return False,"xa03_not_complete"
            return True,"ok"
        except Exception as e:
            return False,f"verification_error:{type(e).__name__}"
