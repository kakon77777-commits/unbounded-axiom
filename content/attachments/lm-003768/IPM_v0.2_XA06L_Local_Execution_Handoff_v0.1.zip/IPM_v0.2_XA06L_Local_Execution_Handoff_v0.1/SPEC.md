# IPM v0.2 XA-06L — Local Real-Model Execution Handoff Pack

## EML-IPM-XA-06L v0.1 Design Specification

**Series:** Intelligence Physical Metrology (IPM)  
**Artifact ID:** EML-IPM-XA-06L  
**Version:** v0.1  
**Date:** 2026-09-03  
**Status:** APPROVED DESIGN — FROZEN FOR IMPLEMENTATION  
**Purpose:** Minimize manual effort between XA-06 READY_FOR_REAL_MODEL and a canonical 36-trial real-model result bundle.

---

# 1. Goal

XA-06L turns the final local execution step into a deterministic workflow:

\[
\boxed{
Configure
\rightarrow
Preflight
\rightarrow
Run/Resume
\rightarrow
Gate
\rightarrow
Seal
\rightarrow
ImportBack
}
\]

It does **not** generate synthetic “real-model” results.

The only condition that may create:

```text
REAL_MODEL_PILOT_COMPLETE
```

is a real provider run with all required 36 matrix points present and gate-passing.

---

# 2. Architecture

PowerShell wrappers remain thin:

```text
configure.ps1
preflight.ps1
run-pilot.ps1
resume-pilot.ps1
seal-results.ps1
```

All substantive behavior lives in:

```text
ipm_xa06l/
```

This allows deterministic Linux/Python testing while preserving Windows-native usability.

---

# 3. Canonical Dependencies

XA-06L references, but does not vendor-modify:

- XA-02 task pack;
- XA-03 telemetry/logger;
- XA-04 runner;
- XA-06 real-model pilot gate.

The local configuration stores exact dependency root paths and expected package hashes where available.

---

# 4. Provider Modes

Supported:

```text
local_openai_compatible
local_command
cloud_openai_compatible
```

Preferred order for IPM physical measurement:

\[
\boxed{
LocalOpenAICompatible
\rightarrow
LocalCommand
\rightarrow
Cloud
}
\]

Cloud runs remain valid for scaffolding measurement but physical energy may remain `null`.

---

# 5. Local Configuration

Canonical generated file:

```text
xa06.real.json
```

Required fields:

```json
{
  "provider_mode": "local_openai_compatible",
  "provider": {},
  "dependencies": {},
  "pilot": {},
  "telemetry": {},
  "output_root": "..."
}
```

Secrets are referenced by environment variable name only.

API keys MUST NOT be stored in generated config.

---

# 6. Configure Command

Python core command:

```bash
python -m ipm_xa06l.cli configure ...
```

PowerShell wrapper:

```powershell
.\configure.ps1
```

Interactive PowerShell may prompt for:

- provider mode;
- endpoint/command;
- model ID;
- base max tokens;
- temperature;
- top-p;
- seed if supported;
- dependency roots;
- output root.

The Python core also supports noninteractive flags for automation.

---

# 7. Preflight

Preflight checks:

1. Python version.
2. Dependency roots exist.
3. XA-06 CLI/module import.
4. XA-02 public task/evaluator presence.
5. XA-03 public API import.
6. XA-04 public API import.
7. Output-root write access.
8. Provider connectivity.
9. Model ID response.
10. `nvidia-smi` availability for local GPU runs.
11. XA-03 telemetry availability/capabilities.
12. One isolated `MATH-003/A0` trial.
13. XA-02 evaluator produces a quality record.

Preflight output:

```text
preflight.json
```

with:

```text
PASS
FAIL
WARN
```

per check.

Failure of a required check prevents launch.

Absence of `nvidia-smi` is:
- `FAIL` only if telemetry is configured as required;
- otherwise `WARN`.

---

# 8. Pilot Matrix

Canonical matrix:

\[
3 \times 6 \times 2 = 36
\]

Tasks:

```text
MATH-003
CODE-001
CON-003
```

Conditions:

```text
A0 A1 A2 A3 A4 A5
```

Replicates:

```text
1 2
```

Matrix identity is deterministic.

---

# 9. Run State

XA-06L stores:

```text
pilot_state.json
```

Each matrix point is one of:

```text
PENDING
RUNNING
COMPLETE
FAILED
INVALID
```

A completed point records:

```text
trial_result_path
xa03_summary_path
trial_result_sha256
xa03_summary_sha256
completed_at
```

---

# 10. Resume Semantics

Resume performs verification before skipping a point.

A matrix point is considered resumable-as-complete only if:

1. trial result exists;
2. XA-03 summary exists;
3. saved hashes match current files;
4. trial identity matches expected task/condition/replicate;
5. terminal state is valid.

Otherwise the point is marked `INVALID`, never silently trusted.

By default:

\[
\boxed{
VerifiedComplete
\Rightarrow
DoNotOverwrite
}
\]

A completed trial can only be intentionally rerun with an explicit force flag.

---

# 11. Run Semantics

`run-pilot` requires a passing preflight.

If no passing `preflight.json` exists:

```text
launch refused
```

unless an explicit unsafe override is supplied. Unsafe override must be written into provenance and cannot produce canonical COMPLETE seal.

Each trial is launched through XA-06/XA-04, not reimplemented by XA-06L.

---

# 12. Progress

Console progress must show:

```text
[07/36] MATH-003 A3 replicate 1
```

and final counts:

```text
COMPLETE
FAILED
PENDING
INVALID
```

No progress dashboard/server is required.

---

# 13. Interruption

Keyboard interruption or process failure must preserve:

- all finished trials;
- current pilot state;
- XA-03 partial run state.

The next `resume-pilot` begins from verified matrix state.

---

# 14. Gate

Gate uses XA-06 verification logic where possible and adds handoff-level checks:

- exactly 36 expected matrix identities;
- no duplicate trial identity;
- all terminal;
- all real provider type;
- 0 private reference leaks;
- accounting consistency;
- XA-03 summary hashes match;
- quality availability rules respected;
- telemetry availability recorded;
- no unsafe-preflight override for canonical completion.

Gate does NOT require a particular SSR/SDR direction.

---

# 15. Real Provider Proof

XA-06L cannot prove philosophical “reality” of a model.

Operationally, canonical completion requires:

```text
provider_mode != scripted
```

and provider provenance from:

```text
local_openai_compatible
local_command
cloud_openai_compatible
```

Synthetic/scripted provider output can be used only for self-tests and must never receive the completion seal.

---

# 16. Seal

`seal-results` runs:

1. state reconciliation;
2. gate;
3. XA-06 analysis;
4. manifest generation;
5. result bundle creation;
6. result ZIP SHA-256.

Only gate pass creates:

```text
REAL_MODEL_PILOT_COMPLETE
```

Gate failure may create:

```text
REAL_MODEL_PILOT_INCOMPLETE
```

but never COMPLETE.

---

# 17. Result Bundle

Canonical bundle name:

```text
XA06_REAL_<sanitized-model-id>_<UTC-timestamp>.zip
```

Contents:

```text
result_bundle/
  xa06.real.redacted.json
  preflight.json
  pilot_state.json
  gate_summary.json
  analysis.json
  pilot_report.md
  condition_summary.csv
  trial_index.csv
  physical_summary.csv
  protocol_compliance.csv
  trial_results/
  xa03_runs/
  manifest.json
  REAL_MODEL_PILOT_COMPLETE
```

Secrets are excluded.

---

# 18. Import Back

`IMPORT_BACK.md` instructs the user to upload only the sealed result ZIP.

When returned to ChatGPT, canonical analysis begins from:

```text
gate_summary.json
analysis.json
trial_index.csv
condition_summary.csv
physical_summary.csv
raw trial/XA-03 traces as needed
```

---

# 19. PowerShell Wrappers

Wrappers:

```text
configure.ps1
preflight.ps1
run-pilot.ps1
resume-pilot.ps1
seal-results.ps1
```

Each wrapper:

- locates the package root relative to `$PSScriptRoot`;
- prepends package root to `PYTHONPATH`;
- invokes `python -m ipm_xa06l.cli ...`;
- returns Python exit code;
- contains no scientific logic.

---

# 20. Cross-Platform Core Commands

Equivalent commands:

```bash
python -m ipm_xa06l.cli configure
python -m ipm_xa06l.cli preflight --config xa06.real.json
python -m ipm_xa06l.cli run --config xa06.real.json
python -m ipm_xa06l.cli resume --config xa06.real.json
python -m ipm_xa06l.cli seal --config xa06.real.json
```

---

# 21. Safety

Generated model code remains untrusted.

XA-06L does not weaken XA-02 code-evaluation safety.

If CODE quality requires executable hidden tests, the user must configure an external sandbox policy.

No PowerShell wrapper automatically enables unsafe code execution.

---

# 22. Deterministic Tests

Required tests:

1. matrix has exactly 36 unique points;
2. config never serializes API secret value;
3. preflight blocks launch on provider failure;
4. preflight allows `nvidia-smi` warning when optional;
5. resume skips verified completed trials;
6. resume invalidates hash-mismatched trials;
7. force rerun requires explicit flag;
8. interrupted state survives;
9. scripted provider can never generate COMPLETE seal;
10. missing one trial can never generate COMPLETE seal;
11. 36 valid real-provider fixture trials can generate COMPLETE seal;
12. sealed bundle excludes secret values;
13. sealed bundle manifest hashes all included files;
14. PowerShell wrappers contain no hardcoded absolute paths.

---

# 23. Status Rule

The XA-06L software artifact itself may reach:

```text
FINAL_VERIFIED
```

without a real model.

The experiment may only reach:

```text
REAL_MODEL_PILOT_COMPLETE
```

after the actual 36 real-provider trials pass the gate.

\[
\boxed{
SoftwareVerified
\neq
ExperimentCompleted.
}
\]

---

# 24. Canonical Principle

\[
\boxed{
\textbf{
Automate the last mile completely,
but never automate away the distinction between
“ready to measure” and “actually measured.”
}
}
\]
