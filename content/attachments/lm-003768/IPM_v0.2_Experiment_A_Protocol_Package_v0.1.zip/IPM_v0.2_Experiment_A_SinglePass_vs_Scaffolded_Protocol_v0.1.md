# IPM v0.2 Experiment A：Single-Pass vs Scaffolded Controlled Measurement Protocol

## 單次智能與鷹架增益的受控實驗協定

**系列：** Intelligence Physical Metrology（IPM）  
**版本：** v0.2 Experimental Measurement Protocol  
**實驗代號：** EML-IPM-XA  
**文件編號：** EML-IPM-XA-01  
**協定版本：** v0.1  
**作者：** Neo.K with Aletheia（GPT-5.6 Sol）  
**機構：** EveMissLab／一言諾科技有限公司  
**日期：** 2026-09-02  
**狀態：** EXPERIMENTAL PROTOCOL — READY FOR PILOT  
**目的：** 將 IPM v0.1 Paper 01、05、06–09 的理論量正式轉化為可重現實驗

---

# 0. 實驗核心問題

本實驗只問一件事：

$$
\boxed{
\textbf{
同一個底層模型，在固定任務與固定資訊條件下，
從 native single-pass 一路增加 external scaffolding，
品質如何提升、物理成本如何增加？
}
}
$$

因此 Experiment A 的基本研究對象不是「模型分數」，而是一條 **Scaffolding Response Curve**：

$$
\boxed{
\mathcal R_S
=
\left\{
(
\mathfrak P_k,
\mathfrak Q_k
)
\right\}_{k=0}^{5}.
}
$$

其中：

- $\mathfrak P_k$：第 $k$ 級 scaffold 的 physical computation object；
- $\mathfrak Q_k$：第 $k$ 級 scaffold 的 quality object。

---

# 1. 主要假說

## H1 — Scaffolding Gain Exists

對至少部分非平凡任務：

$$
\boxed{
Q_{A5}>Q_{A0}.
}
$$

也就是 full scaffolded system 的品質高於 native single-pass。

---

## H2 — Scaffolding Gain Has Physical Cost

若：

$$
Q_{A5}>Q_{A0},
$$

則預期：

$$
\boxed{
E_{A5}\ge E_{A0},
\quad
V_{C,A5}\ge V_{C,A0},
\quad
T_{A5}\ge T_{A0}
}
$$

至少在一個或多個成本軸成立。

---

## H3 — Marginal Yield Is Non-Constant

不同 scaffold stage 的：

$$
\boxed{
Y_{S,k}
=
\frac{
Q_{k+1}-Q_k
}{
C_{k+1}-C_k
}
}
$$

不應假定相同。

某些 scaffold 可能有高邊際效益，某些則進入 diminishing returns。

---

## H4 — Native Capability and System Capability Are Distinguishable

若：

$$
SSR
=
\frac{Q_{A0}}{Q_{A5}}
<1
$$

且差異穩定可重現，則：

$$
\boxed{
ModelNativeCapability
\neq
SystemCapability
}
$$

具有實驗意義，而非純概念區分。

---

## H5 — Different Models Have Different Scaffolding Profiles

即使：

$$
Q_{A5}^{(M_1)}
\approx
Q_{A5}^{(M_2)},
$$

仍可能：

$$
SSR^{(M_1)}
\neq
SSR^{(M_2)},
$$

以及：

$$
SCM^{(M_1)}
\neq
SCM^{(M_2)}.
$$

因此相同最終品質不代表相同能力來源。

---

# 2. 第一階段不測什麼

Experiment A v0.1 **刻意不直接解決**：

1. $\mu_I$ 的最終 operational identification；
2. data-center 全生命週期能源；
3. 跨人腦／AI substrate comparison；
4. 高歧義藝術品質；
5. 完整 Shapley attribution；
6. 大規模 multi-agent society。

這些不是被否定，而是延後。

Experiment A 的第一目標是先證明：

$$
\boxed{
\text{Scaffolding response}
}
$$

可以被穩定量測。

---

# 3. 第一階段任務選型

v0.1 pilot 優先選擇三類：

$$
\boxed{
\mathcal T_A
=
(
T_{math},
T_{code},
T_{constraint}
).
}
$$

原因是它們具有高比例的 objective / structured quality。

---

# 4. Task Family M — Mathematics

建議先使用：

- elementary algebra；
- discrete mathematics；
- finite combinatorics；
- logic puzzles；
- proof completion；
- short theorem derivation。

避免第一輪直接使用：

- 開放數學猜想；
- 需要外部新文獻的研究問題；
- 無法可靠判定真值的創新證明。

---

# 5. Math Quality Object

至少包含：

$$
\boxed{
\mathbf Q_{math}
=
(
Q_{answer},
Q_{derivation},
Q_{goal},
Q_{scope},
Q_{assumption}
).
}
$$

Hard gate：

$$
\boxed{
G_H^{math}
=
AnswerCorrect
\land
NoFatalInvalidStep.
}
$$

---

# 6. Task Family C — Code

建議：

- function implementation；
- bug fixing；
- small algorithm；
- API-free local programming task；
- deterministic unit-testable transformation。

第一階段避免：

- dependency-heavy application；
- network-dependent code；
- GUI；
- long-lived agent repo tasks。

---

# 7. Code Quality Object

$$
\boxed{
\mathbf Q_{code}
=
(
Compile,
Tests,
HiddenTests,
ConstraintCoverage,
Robustness
).
}
$$

Hard gate 可設定：

$$
\boxed{
G_H^{code}
=
Parse
\land
Compile
}
$$

或者 task 明確要求 functional correctness 時：

$$
\boxed{
G_H^{code}
=
Compile
\land
CoreTests.
}
$$

---

# 8. Task Family K — Constraint / Structured Reasoning

例如：

- scheduling puzzle；
- graph constraints；
- finite planning；
- deduction grid；
- deterministic symbolic transformation。

這類任務好處是：

$$
\boxed{
ConstraintSatisfied
}
$$

容易被程式化驗證。

---

# 9. 第一階段 Task Set 建議

Pilot：

$$
\boxed{
N_{task}=30
}
$$

分配：

- 10 math；
- 10 code；
- 10 structured constraint。

正式 v0.2 Phase A：

$$
\boxed{
N_{task}=90\sim150
}
$$

再按難度分層。

---

# 10. Difficulty Stratification

每類任務分：

$$
\boxed{
D\in\{Easy,Medium,Hard\}.
}
$$

建議 pilot：

- Easy：3；
- Medium：4；
- Hard：3。

難度應依預先 pilot 或外部 baseline 定義，而不是依被測模型表現臨時改。

---

# 11. 核心控制變量

對同一模型與同一任務：

$$
\boxed{
Prompt,
InitialContext,
TemperatureFamily,
MaxOutputPolicy,
SystemInstruction,
ModelVersion
}
$$

必須固定或明確記錄。

---

# 12. 最重要控制：Initial Information Equality

若要比較 native reasoning 與 scaffold gain，

A0–A3 應盡量滿足：

$$
\boxed{
Information_{initial}^{A0}
=
Information_{initial}^{A1}
=
Information_{initial}^{A2}
=
Information_{initial}^{A3}.
}
$$

否則：

$$
\Delta Q
$$

可能只是資訊量差異。

---

# 13. A4 Tool Condition 是例外

A4/A5 可以取得新資訊。

但必須另外標記：

$$
\boxed{
InformationGain_{external}.
}
$$

後續可再做 information-matched control。

---

# 14. Experimental Scaffold Ladder

Experiment A 正式固定六級。

---

## A0 — Native Single Pass

條件：

- one model invocation；
- one generation trajectory；
- no external tools；
- no verifier；
- no retry；
- no best-of-N；
- no external memory；
- no post-hoc rewrite。

形式：

$$
\boxed{
U=1,\ G=1,\ I=1,\ L=0,\ R=1,\ S=0.
}
$$

這是 IPM 的 native baseline。

---

## A1 — Extended Single Trajectory

允許：

- 更長 reasoning budget；
- 更高 max output / internal compute budget；

但仍：

$$
\boxed{
L=0,
\quad
G=1.
}
$$

A1 的目的：

> 分辨「更長單一軌跡」與「真正 external scaffolding」的差異。

---

## A2 — Multi-Sample / Self-Consistency

允許：

$$
\boxed{
G=k,
\quad
k>1.
}
$$

例如：

- $k=4$；
- $k=8$；
- $k=16$。

但：

- 不使用外部工具；
- 不引入新世界資訊。

Selection 可使用 deterministic majority / predefined selector。

---

## A3 — Verifier / Critic

A2 候選之上加入：

$$
\boxed{
S_V=1.
}
$$

可使用：

- same-model verifier；
- independent verifier model；
- formal checker；
- test runner。

Verifier 類型必須標記。

---

## A4 — Tool / Environment

允許：

$$
\boxed{
S_T=1
\quad\text{or}\quad
S_E=1.
}
$$

例如：

- calculator；
- compiler；
- test runner；
- local database；
- search system。

第一階段建議優先使用 **deterministic local tools**，不要先使用 web，避免外部世界變動污染重現。

---

## A5 — Full Agentic Scaffold

允許：

- planner；
- memory；
- verifier；
- retry；
- tools；
- iterative feedback；
- explicit stopping rule。

即：

$$
\boxed{
\mathbf S
=
\mathbf S_F.
}
$$

但仍需要 budget cap。

---

# 15. Budget Cap

A5 不能允許無限 LOOP。

每個 task 必須設定：

$$
\boxed{
B_{\mathrm{max}}
}
$$

至少包括：

- max model invocations；
- max trajectories；
- max tool calls；
- max wall time；
- max token/output budget；
- optional energy cap。

---

# 16. 建議 Pilot Budget

### A0
- 1 invocation；
- 1 trajectory。

### A1
- 1 invocation；
- 1 trajectory；
- 2× A0 reasoning/output budget。

### A2
- 8 trajectories。

### A3
- 8 trajectories；
- 1 verifier pass per candidate 或 tournament selector。

### A4
- A3 + max 4 deterministic tool calls。

### A5
- max 16 model invocations；
- max 8 tool calls；
- max 3 retry cycles；
- explicit termination policy。

---

# 17. 這些 budget 不是 IPM 永久標準

它們只是：

$$
\boxed{
PilotReferenceBudget.
}
$$

正式研究必須另行 version。

---

# 18. 重複次數

因生成系統具 stochasticity，

每個：

$$
(model,task,condition)
$$

至少重複：

$$
\boxed{
n=5
}
$$

做 pilot。

---

# 19. 正式建議

$$
\boxed{
n=20
}
$$

如果成本允許。

高變異模型可增加到：

$$
n=30\sim50.
$$

---

# 20. Random Seed

若 provider/runtime 允許：

$$
\boxed{
Seed
}
$$

必須保存。

若不允許 seed，記錄：

- timestamp；
- temperature；
- top-p；
- sampling parameters。

---

# 21. Randomization

Task 順序應隨機化。

Condition 順序若可能產生 cross-run state contamination，應：

- 獨立 session；
- 清除 memory；
- 或使用新的 process。

---

# 22. 禁止 Cross-Condition Leakage

A5 不能看到：

> A0 剛才錯在哪。

除非該資訊是 A5 protocol 本身的一部分。

各 condition 必須從同一 initial task state 開始。

---

# 23. Quality Measurement

第一階段品質以：

$$
\boxed{
\mathfrak Q_F
+
\mathfrak Q_S
}
$$

為主。

盡量不依賴 human residual。

---

# 24. Scalar $Q^*$ 的使用

為了計算 SSR/SDR，

Experiment A 允許一個 task-specific scalar：

$$
\boxed{
Q^*
=
\Pi_Q(
\mathfrak Q
).
}
$$

但 projection 必須在 run 前預先固定。

---

# 25. 建議 Math Projection

例如：

$$
Q^*_{math}
=
0.6Q_{answer}
+
0.3Q_{derivation}
+
0.1Q_{scope}.
$$

但如果 final answer correctness 是 hard gate，

也可以使用 lexicographic rule：

1. final correctness；
2. derivation validity；
3. completeness。

---

# 26. 更推薦 Hard Gate + Vector

原始資料保留：

$$
\boxed{
\mathbf Q
}
$$

Scalar 只供：

- SSR；
- response curve；
- effect-size summary。

---

# 27. Code Projection

可用：

$$
\boxed{
Q^*_{code}
=
\frac{
N_{\mathrm{tests\ passed}}
}{
N_{\mathrm{tests}}
}
}
$$

前提是：

- tests 預先固定；
- hidden tests 不洩漏；
- test coverage 有說明。

---

# 28. Constraint Task Projection

若 $m$ 個 constraints：

$$
\boxed{
Q^*_{constraint}
=
\frac{
N_{\mathrm{satisfied}}
}{
m
}.
}
$$

若存在 fatal constraints：

先做 hard gate。

---

# 29. Physical Telemetry — Minimum Required

Experiment A v0.1 至少需要：

$$
\boxed{
T_{\mathrm{wall}},
E_{\mathrm{device}},
M_{\mathrm{peak}},
V_C
}
$$

---

# 30. Wall Time

精確記：

$$
\boxed{
T=t_f-t_0.
}
$$

每個 condition 都必須包含 hidden retries / verifier / tool 時間。

---

# 31. Device-Time

若本地：

$$
\boxed{
V_C
=
\int D(t)\,dt.
}
$$

簡化可用：

$$
GPUCount\times ActiveTime.
$$

---

# 32. Energy

第一階段接受：

### E-Grade C
GPU / CPU device telemetry。

例如：

$$
\boxed{
E_{\mathrm{device}}
=
\int P_{\mathrm{device}}(t)dt.
}
$$

---

# 33. 若 provider 為黑箱 API

無法取得真實 Joule 時：

$$
\boxed{
E=Unknown
}
$$

不要用 token cost 假裝 Joule。

---

# 34. API Model 仍可進 Experiment A

可先量：

- latency；
- invocation count；
- trajectories；
- token counts；
- quality；
- scaffolding structure。

但：

$$
Grade_E=E
$$

或 Unknown。

---

# 35. Memory

本地可量：

$$
\boxed{
M_{\mathrm{peak}}.
}
$$

若 profiler 可得，再加入：

$$
V_M
=
\int M_{\mathrm{resident}}dt.
$$

---

# 36. Memory Traffic

如果硬體 counter / profiler 支援，記：

$$
B_M.
$$

否則先標：

$$
Unknown.
$$

---

# 37. Tool Cost

Tool 執行本身也要記：

$$
\boxed{
\mathfrak P_{tool}.
}
$$

例如 compiler / local solver 的：

- CPU time；
- memory；
- energy，若可量。

---

# 38. Discarded Work

A2–A5 必須保存：

$$
\boxed{
N_{\mathrm{discarded}}.
}
$$

以及：

$$
\boxed{
C_{\mathrm{discarded}}.
}
$$

---

# 39. Selection Waste Ratio

若某成本軸可量：

$$
\boxed{
SWR_C
=
\frac{
C_{\mathrm{discarded}}
}{
C_{\mathrm{total}}
}.
}
$$

---

# 40. Core Metrics

Experiment A 的最低輸出：

### Quality Gain

$$
\boxed{
\Delta Q_k
=
Q_k-Q_0.
}
$$

---

# 41. Scaffolding Survival Ratio

以 A5 為 full reference：

$$
\boxed{
SSR
=
\frac{
Q_0
}{
Q_5
}.
}
$$

---

# 42. Scaffolding Dependence Ratio

$$
\boxed{
SDR
=
1-SSR.
}
$$

---

# 43. Scaffold Cost Multiplier

對每個成本軸：

$$
\boxed{
SCM_j
=
\frac{
C_{5,j}
}{
C_{0,j}
}.
}
$$

---

# 44. Marginal Yield

$$
\boxed{
Y_{k,j}
=
\frac{
Q_{k+1}-Q_k
}{
C_{k+1,j}-C_{k,j}
}.
}
$$

---

# 45. Response Curve

$$
\boxed{
Q_k
=
Q(
C_k,
S_k
).
}
$$

需畫：

- $Q$ vs wall time；
- $Q$ vs energy；
- $Q$ vs invocation count；
- $Q$ vs device-time。

---

# 46. Brute-Force Region

若：

$$
\Delta Q
<
\epsilon_Q
$$

但：

$$
\frac{\Delta C}{C}
>
\epsilon_C,
$$

標記為：

$$
\boxed{
BFRegion.
}
$$

---

# 47. Pilot Threshold 建議

不是自然常數，只是 exploratory：

$$
\epsilon_Q=0.01
$$

且：

$$
\epsilon_C=0.5.
$$

也就是成本增加超過 50%，品質增加不到 1 percentage point。

---

# 48. Statistics — 第一層

對每個 condition：

報：

- mean；
- median；
- standard deviation；
- bootstrap CI；
- success rate。

---

# 49. Paired Design

同一 task 在所有 conditions 都跑。

所以主比較應是：

$$
\boxed{
\text{paired within-task comparison}.
}
$$

---

# 50. 建議主效應量

對：

$$
Q_{A5}-Q_{A0}
$$

報：

- paired mean difference；
- bootstrap 95% CI；
- standardized paired effect size。

---

# 51. 非常重要：不要只報 p-value

IPM 更關心：

$$
\boxed{
\text{effect size}
+
\text{physical cost}.
}
$$

---

# 52. Difficulty Interaction

可分析：

$$
\boxed{
ScaffoldGain
\times
Difficulty.
}
$$

假說：

Hard tasks 可能有更大：

$$
SDR.
$$

---

# 53. Model Interaction

若比較多模型：

$$
\boxed{
ScaffoldGain
\times
Model.
}
$$

---

# 54. Scaffold Interaction — Pilot 版本

完整 factorial 很貴。

Pilot 先做以下核心 subset：

1. A0；
2. A2；
3. A3；
4. A2 + A3；
5. A4；
6. A5。

---

# 55. 用於檢查

$$
\boxed{
Interaction_{N,V}
}
$$

即 multi-sample × verifier synergy。

---

# 56. Full Factorial 留到 XA-02

不在第一份 protocol 中強制。

---

# 57. Stopping Criteria

單一 run 在以下任一條件成立時停止：

1. 成功達成 hard gate；
2. budget exhausted；
3. explicit unsatisfiable proof；
4. repeated state cycle；
5. max wall time；
6. safety/runtime failure。

---

# 58. Agent 不能自行無限擴 budget

所以：

$$
\boxed{
SelfExtensionOfBudget=Forbidden.
}
$$

---

# 59. Failure Classification

每次失敗至少分：

$$
\boxed{
F=
(
F_{reason},
F_{knowledge},
F_{tool},
F_{verify},
F_{runtime},
F_{budget}
).
}
$$

---

# 60. Reasoning Failure

有充分資訊但推理錯。

---

# 61. Knowledge Failure

initial context 缺少必要資訊。

---

# 62. Tool Failure

選錯工具／工具執行失敗／誤讀工具結果。

---

# 63. Verification Failure

候選中有正解但 selector 選錯。

---

# 64. Runtime Failure

timeout、OOM、API failure。

---

# 65. Budget Failure

仍可能解出但 budget 用完。

---

# 66. 這個分類能避免把所有錯誤都叫 hallucination

---

# 67. Information-Matched Control

對 A4/A5 的後續子實驗：

把它們取得的 external evidence 預先提供給 A0′。

---

# 68. 比較：

$$
\boxed{
Q_{A0'}
}
$$

與：

$$
\boxed{
Q_{A4}.
}
$$

---

# 69. 若：

$$
Q_{A0'}\approx Q_{A4},
$$

tool gain 主要是：

$$
\boxed{
InformationAcquisition.
}
$$

---

# 70. 若：

$$
Q_{A4}\gg Q_{A0'},
$$

表示 iterative tool use / query reformulation / evidence selection 有額外價值。

---

# 71. Same-Model vs Independent Verifier

A3 應至少區分：

$$
\boxed{
VerifierType
\in
\{
SameModel,
IndependentModel,
Formal
\}.
}
$$

---

# 72. Same-model verifier

成本低、控制簡單，但 errors 可能 correlated。

---

# 73. Independent verifier

可以提供 diversity，但引入另一模型能力。

---

# 74. Formal verifier

最客觀，但只有部分任務可用。

---

# 75. 所以 verifier 不能只寫：

> enabled。

必須 typed。

---

# 76. Model Configuration Freeze

每個 experiment series 應鎖：

- exact model ID；
- model revision/date；
- quantization；
- decoding config；
- runtime version。

---

# 77. 若雲端 provider 偷換底層版本

需標：

$$
\boxed{
ModelVersionUncontrolled=1.
}
$$

---

# 78. Hardware Freeze

本地實驗固定：

- GPU；
- CPU；
- RAM；
- driver；
- power mode；
- thermal policy。

---

# 79. Thermal Drift

長時間 run 可能產生：

$$
\boxed{
ThermalThrottling.
}
$$

所以應保存：

- device temperature；
- clock；
- power limit。

---

# 80. Warm-up

正式測量前至少跑：

$$
\boxed{
N_{warmup}=1\sim3
}
$$

不納入主樣本。

---

# 81. Cold / Warm Cache

若 memory/cache state 影響很大，

要指定：

$$
\boxed{
CachePolicy.
}
$$

---

# 82. 第一階段建議

優先 warm model weights，

但 task state clean。

也就是：

- model 已載入；
- task-specific cache / conversation 清空。

---

# 83. Run Record

每一筆 run 必須有：

$$
\boxed{
RunID.
}
$$

建議：

```text
IPM-XA-{model}-{task}-{condition}-{replicate}
```

---

# 84. 最小 Run Schema

```yaml
ipm_version: "0.2"
experiment: "XA"
protocol_version: "0.1"

run:
  id:
  timestamp:
  replicate:

task:
  id:
  family:
  difficulty:
  specification_version:

model:
  provider:
  model_id:
  revision:
  decoding:

condition:
  level: A0 | A1 | A2 | A3 | A4 | A5
  trajectories:
  retries:
  tool_budget:
  verifier_type:
  planner:
  memory:

quality:
  hard_gate:
  vector:
  scalar_projection:
  scalar_value:
  uncertainty:
  grade:

physical:
  wall_time_s:
  device_time_s:
  energy_j:
  energy_type:
  memory_peak_bytes:
  memory_residency_byte_s:
  memory_traffic_bytes:
  interconnect_bytes:
  boundary:
  grade:

hidden_work:
  discarded_candidates:
  discarded_cost:

failure:
  class:
  notes:
```

---

# 85. Pilot Acceptance Criteria

Experiment A pilot 可視為成功，如果：

1. 30 個 tasks 全部能在 A0–A5 產生合法 run record；
2. 至少 95% runs 有完整 wall time；
3. 本地 run 至少 90% 有 device telemetry；
4. quality scoring 可自動重現；
5. 相同 raw record 重算 SSR/SDR 得相同結果；
6. 所有 discarded work 能被 accounting；
7. 無 condition leakage。

---

# 86. Scientific Success 與 Engineering Success 分開

Engineering success：

> protocol 能不能穩定跑？

Scientific success：

> H1–H5 是否得到支持？

兩者不能混。

---

# 87. Protocol 可能成功，而 H1 被否證

如果：

$$
Q_{A0}\approx Q_{A5}
$$

反而是一個有價值結果。

---

# 88. 所以：

$$
\boxed{
NullResult
\neq
ExperimentFailure.
}
$$

---

# 89. Pilot Rejection Conditions

若：

- A0 和 A5 initial information 不一致但未標記；
- hidden retry 無法 contabilize；
- quality evaluator 在 condition 間變動；
- A5 無 budget cap；
- run state 污染後續 condition；
- physical boundary 不一致；

則該批資料不進正式 analysis。

---

# 90. 第一階段輸出表

每個 model 至少輸出：

| Condition | Quality | Pass Rate | Wall Time | Device-Time | Energy | Peak Memory | Trajectories | Retries | Tool Calls |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| A0 | | | | | | | 1 | 0 | 0 |
| A1 | | | | | | | 1 | 0 | 0 |
| A2 | | | | | | | 8 | 0 | 0 |
| A3 | | | | | | | 8 | 0 | 0 |
| A4 | | | | | | | | | |
| A5 | | | | | | | | | |

---

# 91. 第二張表：Scaffolding Profile

| Metric | Value |
|---|---:|
| $SSR$ | |
| $SDR$ | |
| $SCM_T$ | |
| $SCM_E$ | |
| $SCM_{V_C}$ | |
| $SWR$ | |
| Best marginal stage | |
| First brute-force stage | |

---

# 92. 必要圖表

### Figure A

$$
Q
\text{ vs }
Condition.
$$

### Figure B

$$
Q
\text{ vs }
T.
$$

### Figure C

$$
Q
\text{ vs }
E.
$$

### Figure D

$$
Q
\text{ vs }
V_C.
$$

### Figure E

$$
MarginalYield
\text{ by stage}.
$$

---

# 93. 如果有多模型

再畫：

$$
\boxed{
SSR
\text{ vs }
Q_{A5}.
}
$$

它能直接區分：

- full-system strong but scaffold dependent；
- native strong；
- weak overall。

---

# 94. 最有價值的 Quadrant

X 軸：

$$
SSR.
$$

Y 軸：

$$
Q_{A5}.
$$

---

# 95. 四象限

### High $Q_F$, High SSR
Native strong。

### High $Q_F$, Low SSR
Scaffold-dependent but strong system。

### Low $Q_F$, High SSR
Native limit high relative to own system，但 overall weak。

### Low $Q_F$, Low SSR
Native 與 scaffold 都不足。

---

# 96. 加入 SCM 後變三維

即可辨識：

> 高品質是否需要爆量 compute？

---

# 97. Experiment A 的最低結論格式

每個 model 不應只寫：

> A 比 B 強。

而應寫：

> 在 task family X、protocol v0.1、quality schema Y 下，
> model A 的 A0 quality 為 …，
> A5 quality 為 …，
> SSR 為 …，
> full-system cost multiplier 為 …，
> 主要 gain 發生在 A2→A3，
> 並在 A4→A5 進入低 marginal-yield region。

---

# 98. 這才是 IPM 語言

---

# 99. Experiment A 與 $\mu_I$ 的關係

XA v0.1 不要求先能精確量：

$$
N_{\mu}^{eff}.
$$

---

# 100. 先把：

$$
\boxed{
\mathfrak Q
\quad\text{與}\quad
\mathfrak P
}
$$

穩定測出。

---

# 101. 等 Experiment C 再插入語意中間層

之後可以回頭重算：

$$
\boxed{
Physical
\rightarrow
Semantic
\rightarrow
Quality.
}
$$

---

# 102. 這就是為什麼 XA 應是 v0.2 第一個實驗

它最容易先證明：

$$
\boxed{
SystemCapability
\neq
ModelNativeCapability
}
$$

是否真的有可穩定測量的 empirical structure。

---

# 103. Canonical XA Output Object

本文最終定義：

$$
\boxed{
\mathfrak X_A
=
(
ProtocolVersion,
TaskSet,
ModelConfig,
\{
(\mathfrak Q_k,\mathfrak P_k)
\}_{k=0}^{5},
SSR,
SDR,
\mathbf{SCM},
\mathbf Y_S,
\mathfrak P_{\mathrm{waste}},
FailureProfile,
MeasurementGrades
).
}
$$

---

# 104. XA v0.1 完成條件

本 protocol 被視為 canonical-ready，需滿足：

1. schema fixed；
2. budget fixed；
3. task set versioned；
4. quality projection pre-registered；
5. physical boundary fixed；
6. run records reproducible；
7. analysis script deterministic；
8. results include nulls and failures；
9. hidden work accounted；
10. protocol version sealed。

---

# 105. 下一個文件

Experiment A protocol 之後，不應立刻寫新的理論 paper。

下一個 canonical engineering artifact 應是：

## EML-IPM-XA-02
**Experiment A Task Pack & Reference Evaluators**

包含：

- 30-task pilot pack；
- math evaluator；
- code evaluator；
- constraint evaluator；
- task metadata；
- hard-gate definitions；
- projection rules；
- expected-answer / hidden-test separation。

再下一份才是：

## EML-IPM-XA-03
**Telemetry & Run Logger Reference Specification**

包含：

- wall time；
- GPU telemetry；
- memory；
- energy；
- invocation / retry / tool accounting；
- discarded-work accounting。

---

# 106. Experiment A v0.1 最終命題

$$
\boxed{
\textbf{
不要再問「這個 Agent 有幾分」；
先固定同一個模型與同一組任務，
從 A0 到 A5 一層層增加鷹架，
同時量品質與物理成本，
再觀察真正的 scaffolding response curve。
}
}
$$

如果這條曲線不存在，

Paper 09 的一部分理論就應被削弱。

如果它穩定存在，

那麼：

$$
\boxed{
\text{native intelligence}
\quad\text{與}\quad
\text{system intelligence}
}
$$

就第一次不再只是概念區分，而成為可量測的實驗對象。

---

## Protocol Status

$$
\boxed{
\text{EML-IPM-XA-01 v0.1}
=
\text{READY FOR PILOT}.
}
$$
