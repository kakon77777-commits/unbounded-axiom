from __future__ import annotations

from dataclasses import dataclass, fields
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path
from typing import Any


OPERATIONS = ("trust_primary", "verify_independent")
_OPERATION_SET = set(OPERATIONS)
_EVIDENCE_KINDS = {"on_policy", "counterfactual", "transferred"}
_FORBIDDEN_FEATURE_KEYS = {
    "world_id",
    "world_kind",
    "source_world",
    "true_context",
    "hidden_context",
    "context",
    "current_truth",
    "future_truth",
    "oracle_action",
}


def _bucket01(value: float) -> str:
    value = float(value)
    if value < 0.34:
        return "LOW"
    if value < 0.67:
        return "MID"
    return "HIGH"


def _bucket_signed(value: float) -> str:
    value = float(value)
    if value < -0.25:
        return "NEG"
    if value > 0.25:
        return "POS"
    return "NEUTRAL"


@dataclass(frozen=True, slots=True)
class GeneralizedCognitiveFeatures:
    uncertainty: float
    primary_trust: float
    verifier_trust: float
    primary_value_prior: float
    verify_value_prior: float
    progress_fraction: float
    observation_available: bool
    risk_if_wrong: float
    evidence_conflict: bool
    observation_cost_fraction: float

    @classmethod
    def from_mapping(cls, payload: dict[str, Any]) -> "GeneralizedCognitiveFeatures":
        keys = set(payload)
        forbidden = keys & _FORBIDDEN_FEATURE_KEYS
        if forbidden:
            raise ValueError(f"forbidden generalized feature keys: {sorted(forbidden)}")
        expected = {field.name for field in fields(cls)}
        unknown = keys - expected
        missing = expected - keys
        if unknown:
            raise ValueError(f"unknown generalized feature keys: {sorted(unknown)}")
        if missing:
            raise ValueError(f"missing generalized feature keys: {sorted(missing)}")
        obj = cls(
            uncertainty=float(payload["uncertainty"]),
            primary_trust=float(payload["primary_trust"]),
            verifier_trust=float(payload["verifier_trust"]),
            primary_value_prior=float(payload["primary_value_prior"]),
            verify_value_prior=float(payload["verify_value_prior"]),
            progress_fraction=float(payload["progress_fraction"]),
            observation_available=bool(payload["observation_available"]),
            risk_if_wrong=float(payload["risk_if_wrong"]),
            evidence_conflict=bool(payload["evidence_conflict"]),
            observation_cost_fraction=float(payload["observation_cost_fraction"]),
        )
        obj._validate()
        return obj

    def _validate(self) -> None:
        for name in (
            "uncertainty",
            "primary_trust",
            "verifier_trust",
            "progress_fraction",
            "risk_if_wrong",
            "observation_cost_fraction",
        ):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
        for name in ("primary_value_prior", "verify_value_prior"):
            value = float(getattr(self, name))
            if not -1.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between -1 and 1")

    def to_dict(self) -> dict[str, Any]:
        return {
            "uncertainty": float(self.uncertainty),
            "primary_trust": float(self.primary_trust),
            "verifier_trust": float(self.verifier_trust),
            "primary_value_prior": float(self.primary_value_prior),
            "verify_value_prior": float(self.verify_value_prior),
            "progress_fraction": float(self.progress_fraction),
            "observation_available": bool(self.observation_available),
            "risk_if_wrong": float(self.risk_if_wrong),
            "evidence_conflict": bool(self.evidence_conflict),
            "observation_cost_fraction": float(self.observation_cost_fraction),
        }

    def bucket_key(self) -> str:
        parts = (
            f"u={_bucket01(self.uncertainty)}",
            f"pt={_bucket01(self.primary_trust)}",
            f"vt={_bucket01(self.verifier_trust)}",
            f"pv={_bucket_signed(self.primary_value_prior)}",
            f"vv={_bucket_signed(self.verify_value_prior)}",
            f"prog={_bucket01(self.progress_fraction)}",
            f"obs={int(self.observation_available)}",
            f"risk={_bucket01(self.risk_if_wrong)}",
            f"conf={int(self.evidence_conflict)}",
            f"cost={_bucket01(self.observation_cost_fraction)}",
        )
        return "|".join(parts)


@dataclass(frozen=True, slots=True)
class GeneralizedCognitiveExperience:
    experience_id: str
    episode_id: str
    round_index: int
    source_world: str
    operation: str
    features: GeneralizedCognitiveFeatures
    realized_value: float
    observation_cost: float
    target_uncertainty: float
    evidence_kind: str

    def __post_init__(self) -> None:
        if self.operation not in _OPERATION_SET:
            raise ValueError(f"unsupported generalized operation {self.operation!r}")
        if int(self.round_index) < 0:
            raise ValueError("round_index must be non-negative")
        if float(self.observation_cost) < 0.0:
            raise ValueError("observation_cost must be non-negative")
        if not 0.0 <= float(self.target_uncertainty) <= 1.0:
            raise ValueError("target_uncertainty must be between 0 and 1")
        if self.evidence_kind not in _EVIDENCE_KINDS:
            raise ValueError(f"unsupported evidence_kind {self.evidence_kind!r}")
        if not str(self.source_world):
            raise ValueError("source_world must be non-empty")

    def to_dict(self) -> dict[str, Any]:
        return {
            "experience_id": self.experience_id,
            "episode_id": self.episode_id,
            "round_index": int(self.round_index),
            "source_world": self.source_world,
            "operation": self.operation,
            "features": self.features.to_dict(),
            "realized_value": float(self.realized_value),
            "observation_cost": float(self.observation_cost),
            "target_uncertainty": float(self.target_uncertainty),
            "evidence_kind": self.evidence_kind,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "GeneralizedCognitiveExperience":
        return cls(
            experience_id=str(payload["experience_id"]),
            episode_id=str(payload["episode_id"]),
            round_index=int(payload["round_index"]),
            source_world=str(payload["source_world"]),
            operation=str(payload["operation"]),
            features=GeneralizedCognitiveFeatures.from_mapping(dict(payload["features"])),
            realized_value=float(payload["realized_value"]),
            observation_cost=float(payload["observation_cost"]),
            target_uncertainty=float(payload["target_uncertainty"]),
            evidence_kind=str(payload["evidence_kind"]),
        )


@dataclass(slots=True)
class _Stats:
    count: int = 0
    weight: float = 0.0
    mean: float = 0.0
    target_uncertainty_mean: float = 0.0

    def update(self, value: float, target_uncertainty: float, weight: float) -> None:
        weight = float(weight)
        if weight <= 0.0:
            return
        new_weight = self.weight + weight
        self.mean += weight * (float(value) - self.mean) / new_weight
        self.target_uncertainty_mean += weight * (float(target_uncertainty) - self.target_uncertainty_mean) / new_weight
        self.weight = new_weight
        self.count += 1

    def to_dict(self) -> dict[str, float | int]:
        return {
            "count": int(self.count),
            "weight": float(self.weight),
            "mean": float(self.mean),
            "target_uncertainty_mean": float(self.target_uncertainty_mean),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "_Stats":
        return cls(
            count=int(payload.get("count", 0)),
            weight=float(payload.get("weight", 0.0)),
            mean=float(payload.get("mean", 0.0)),
            target_uncertainty_mean=float(payload.get("target_uncertainty_mean", 0.0)),
        )


@dataclass(frozen=True, slots=True)
class GeneralizedValuePrediction:
    expected_value: float
    epistemic_uncertainty: float
    target_uncertainty: float
    combined_uncertainty: float
    evidence_weight: float


class CrossWorldMetaValueModel:
    MODEL_TYPE = "cross-world-meta-value-v0.9"

    def __init__(
        self,
        *,
        backoff_strength: float = 1.0,
        min_target_weight: float = 0.05,
    ) -> None:
        if float(backoff_strength) <= 0.0:
            raise ValueError("backoff_strength must be positive")
        if not 0.0 < float(min_target_weight) <= 1.0:
            raise ValueError("min_target_weight must be in (0, 1]")
        self.backoff_strength = float(backoff_strength)
        self.min_target_weight = float(min_target_weight)
        self._global: dict[str, _Stats] = {}
        self._buckets: dict[tuple[str, str], _Stats] = {}

    def _effective_weight(self, experience: GeneralizedCognitiveExperience, sample_weight: float) -> float:
        if float(sample_weight) <= 0.0:
            raise ValueError("sample_weight must be positive")
        confidence = max(1.0 - float(experience.target_uncertainty), self.min_target_weight)
        return float(sample_weight) * confidence

    def update(self, experience: GeneralizedCognitiveExperience, *, sample_weight: float = 1.0) -> GeneralizedValuePrediction:
        effective_weight = self._effective_weight(experience, sample_weight)
        operation = experience.operation
        self._global.setdefault(operation, _Stats()).update(
            experience.realized_value, experience.target_uncertainty, effective_weight
        )
        key = (operation, experience.features.bucket_key())
        self._buckets.setdefault(key, _Stats()).update(
            experience.realized_value, experience.target_uncertainty, effective_weight
        )
        return self.predict(operation, experience.features, fallback=experience.realized_value)

    def evidence_weight(self, operation: str, features: GeneralizedCognitiveFeatures | None = None) -> float:
        if operation not in _OPERATION_SET:
            raise ValueError(f"unsupported generalized operation {operation!r}")
        stats = self._global.get(operation) if features is None else self._buckets.get((operation, features.bucket_key()))
        return 0.0 if stats is None else float(stats.weight)

    def evidence_count(self, operation: str) -> int:
        if operation not in _OPERATION_SET:
            raise ValueError(f"unsupported generalized operation {operation!r}")
        stats = self._global.get(operation)
        return 0 if stats is None else int(stats.count)

    @staticmethod
    def _combined(epistemic: float, target: float) -> float:
        return min(max(1.0 - (1.0 - epistemic) * (1.0 - target), 0.0), 1.0)

    def predict(
        self,
        operation: str,
        features: GeneralizedCognitiveFeatures,
        *,
        fallback: float = 0.0,
    ) -> GeneralizedValuePrediction:
        if operation not in _OPERATION_SET:
            raise ValueError(f"unsupported generalized operation {operation!r}")
        global_stats = self._global.get(operation)
        global_value = float(fallback) if global_stats is None or global_stats.weight <= 0 else global_stats.mean
        global_target = 1.0 if global_stats is None or global_stats.weight <= 0 else global_stats.target_uncertainty_mean
        local = self._buckets.get((operation, features.bucket_key()))
        if local is None or local.weight <= 0:
            expected = global_value
            target_uncertainty = global_target
            local_weight = 0.0
        else:
            alpha = local.weight / (local.weight + self.backoff_strength)
            expected = alpha * local.mean + (1.0 - alpha) * global_value
            target_uncertainty = alpha * local.target_uncertainty_mean + (1.0 - alpha) * global_target
            local_weight = local.weight
        epistemic = 1.0 / sqrt(1.0 + local_weight)
        return GeneralizedValuePrediction(
            expected_value=float(expected),
            epistemic_uncertainty=float(epistemic),
            target_uncertainty=min(max(float(target_uncertainty), 0.0), 1.0),
            combined_uncertainty=self._combined(epistemic, target_uncertainty),
            evidence_weight=float(local_weight),
        )

    def to_dict(self) -> dict[str, Any]:
        actions: dict[str, Any] = {}
        for operation in sorted(set(self._global) | {op for op, _ in self._buckets}):
            actions[operation] = {
                "global": self._global.get(operation, _Stats()).to_dict(),
                "buckets": {
                    bucket: stats.to_dict()
                    for (op, bucket), stats in sorted(self._buckets.items())
                    if op == operation
                },
            }
        return {
            "model_type": self.MODEL_TYPE,
            "backoff_strength": self.backoff_strength,
            "min_target_weight": self.min_target_weight,
            "actions": actions,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "CrossWorldMetaValueModel":
        if payload.get("model_type") != cls.MODEL_TYPE:
            raise ValueError("unsupported cross-world meta value model type")
        model = cls(
            backoff_strength=float(payload["backoff_strength"]),
            min_target_weight=float(payload["min_target_weight"]),
        )
        for operation, row in dict(payload.get("actions", {})).items():
            if operation not in _OPERATION_SET:
                raise ValueError(f"unsupported generalized operation {operation!r}")
            global_row = dict(row.get("global", {}))
            if global_row:
                model._global[operation] = _Stats.from_dict(global_row)
            for bucket, stats_payload in dict(row.get("buckets", {})).items():
                model._buckets[(operation, str(bucket))] = _Stats.from_dict(dict(stats_payload))
        return model

    def model_hash(self) -> str:
        encoded = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return sha256(encoded).hexdigest()

    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "CrossWorldMetaValueModel":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
