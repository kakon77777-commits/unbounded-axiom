from __future__ import annotations

import math
from typing import Any


class LatentContextBeliefTracker:
    """Deterministic two-state belief tracker for latent opponent context."""

    CONTEXTS = ("ALIGNED", "COMPETITIVE")
    _TRUTHFULNESS = {"ALIGNED": 0.85, "COMPETITIVE": 0.35}

    def __init__(self, *, prior_aligned: float = 0.5, transition_persistence: float = 0.75) -> None:
        if not 0.0 < float(prior_aligned) < 1.0:
            raise ValueError("prior_aligned must be between 0 and 1")
        if not 0.5 <= float(transition_persistence) <= 1.0:
            raise ValueError("transition_persistence must be between 0.5 and 1")
        self.transition_persistence = float(transition_persistence)
        self._belief = {
            "ALIGNED": float(prior_aligned),
            "COMPETITIVE": 1.0 - float(prior_aligned),
        }
        self.feedback_updates = 0
        self.signal_checks = 0

    def belief(self) -> dict[str, float]:
        return dict(self._belief)

    def entropy(self) -> float:
        entropy = 0.0
        for probability in self._belief.values():
            if probability > 0.0:
                entropy -= probability * math.log2(probability)
        return entropy

    def _bayes(self, likelihoods: dict[str, float]) -> dict[str, float]:
        numerators = {
            context: self._belief[context] * max(float(likelihoods[context]), 1e-12)
            for context in self.CONTEXTS
        }
        total = sum(numerators.values())
        self._belief = {context: numerators[context] / total for context in self.CONTEXTS}
        return self.belief()

    def predict_next(self) -> dict[str, float]:
        aligned = self._belief["ALIGNED"]
        competitive = self._belief["COMPETITIVE"]
        persistence = self.transition_persistence
        self._belief = {
            "ALIGNED": persistence * aligned + (1.0 - persistence) * competitive,
            "COMPETITIVE": persistence * competitive + (1.0 - persistence) * aligned,
        }
        return self.belief()

    def update_from_feedback(
        self,
        *,
        signal_correct: bool | None,
        receiver_utility: float,
        signaler_utility: float,
        avoidable_loss: float,
    ) -> dict[str, float]:
        likelihoods = {context: 1.0 for context in self.CONTEXTS}
        if signal_correct is not None:
            for context in self.CONTEXTS:
                truthful = self._TRUTHFULNESS[context]
                likelihoods[context] *= truthful if signal_correct else (1.0 - truthful)

        aligned_gap = abs(float(signaler_utility) - float(receiver_utility))
        competitive_gap = abs(float(signaler_utility) - float(avoidable_loss))
        if aligned_gap + 1e-9 < competitive_gap:
            likelihoods["ALIGNED"] *= 0.9
            likelihoods["COMPETITIVE"] *= 0.1
        elif competitive_gap + 1e-9 < aligned_gap:
            likelihoods["ALIGNED"] *= 0.1
            likelihoods["COMPETITIVE"] *= 0.9
        else:
            likelihoods["ALIGNED"] *= 0.5
            likelihoods["COMPETITIVE"] *= 0.5

        self.feedback_updates += 1
        return self._bayes(likelihoods)

    def update_from_signal_check(self, *, signal_matches: bool, observer_reliability: float) -> dict[str, float]:
        reliability = min(max(float(observer_reliability), 0.0), 1.0)
        likelihoods: dict[str, float] = {}
        for context in self.CONTEXTS:
            truthful = self._TRUTHFULNESS[context]
            match_probability = truthful * reliability + (1.0 - truthful) * (1.0 - reliability)
            likelihoods[context] = match_probability if signal_matches else (1.0 - match_probability)
        self.signal_checks += 1
        return self._bayes(likelihoods)

    def snapshot(self) -> dict[str, Any]:
        return {
            "belief": self.belief(),
            "entropy": self.entropy(),
            "transition_persistence": self.transition_persistence,
            "feedback_updates": self.feedback_updates,
            "signal_checks": self.signal_checks,
        }
