from __future__ import annotations


class OnlineMVCValueEstimator:
    """Incremental weighted-mean estimator for realized cognitive gain by key."""

    def __init__(self) -> None:
        self._counts: dict[str, int] = {}
        self._weights: dict[str, float] = {}
        self._means: dict[str, float] = {}

    def estimate(self, key: str, fallback: float = 0.0) -> float:
        return self._means.get(key, float(fallback))

    def update_weighted(self, key: str, realized_gain: float, *, weight: float) -> float:
        weight = float(weight)
        if weight < 0.0:
            raise ValueError("weight must be non-negative")
        if weight == 0.0:
            return self.estimate(key)
        old_weight = self._weights.get(key, 0.0)
        new_weight = old_weight + weight
        old_mean = self._means.get(key, 0.0)
        new_mean = old_mean + weight * (float(realized_gain) - old_mean) / new_weight
        self._counts[key] = self._counts.get(key, 0) + 1
        self._weights[key] = new_weight
        self._means[key] = new_mean
        return new_mean

    def update(self, key: str, realized_gain: float) -> float:
        return self.update_weighted(key, realized_gain, weight=1.0)

    def count(self, key: str) -> int:
        return self._counts.get(key, 0)

    def evidence_weight(self, key: str) -> float:
        return self._weights.get(key, 0.0)

    def snapshot(self) -> dict[str, dict[str, float | int]]:
        return {
            key: {
                "count": self._counts[key],
                "weight": self._weights[key],
                "estimated_gain": self._means[key],
            }
            for key in sorted(self._means)
        }


class ContextualMVCValueEstimator:
    """Hierarchical online MVC estimate: context -> source -> global -> fallback."""

    def __init__(self, *, backoff_strength: float = 1.0) -> None:
        if backoff_strength <= 0:
            raise ValueError("backoff_strength must be positive")
        self.backoff_strength = float(backoff_strength)
        self._global = OnlineMVCValueEstimator()
        self._source: dict[tuple[str, str], OnlineMVCValueEstimator] = {}
        self._context: dict[tuple[str, str, str], OnlineMVCValueEstimator] = {}

    @staticmethod
    def _normalize_weights(context_weights: dict[str, float]) -> dict[str, float]:
        cleaned = {str(context): float(weight) for context, weight in context_weights.items() if float(weight) > 0.0}
        if any(float(weight) < 0.0 for weight in context_weights.values()):
            raise ValueError("context weights must be non-negative")
        total = sum(cleaned.values())
        if total <= 0.0:
            raise ValueError("context weights must contain positive mass")
        return {context: weight / total for context, weight in cleaned.items()}

    @staticmethod
    def _blend(parent: float, child: float, weight: float, strength: float) -> float:
        if weight <= 0:
            return parent
        blend_weight = weight / (weight + strength)
        return blend_weight * child + (1.0 - blend_weight) * parent

    def update(self, key: str, source_id: str, context: str, realized_gain: float) -> float:
        return self.update_belief(key, source_id, {str(context): 1.0}, realized_gain)

    def update_belief(
        self,
        key: str,
        source_id: str,
        context_weights: dict[str, float],
        realized_gain: float,
    ) -> float:
        weights = self._normalize_weights(context_weights)
        self._global.update(key, realized_gain)
        skey = (key, source_id)
        source_est = self._source.setdefault(skey, OnlineMVCValueEstimator())
        source_est.update(key, realized_gain)
        for context, weight in weights.items():
            ckey = (key, source_id, context)
            context_est = self._context.setdefault(ckey, OnlineMVCValueEstimator())
            context_est.update_weighted(key, realized_gain, weight=weight)
        return self.estimate_belief(key, source_id, weights)

    def estimate(
        self,
        key: str,
        source_id: str,
        context: str,
        *,
        fallback: float = 0.0,
        exploration_weight: float = 0.0,
    ) -> float:
        value = self._global.estimate(key, fallback=fallback)
        global_weight = self._global.evidence_weight(key)
        value = self._blend(float(fallback), value, global_weight, self.backoff_strength)

        source_est = self._source.get((key, source_id))
        if source_est is not None:
            value = self._blend(
                value,
                source_est.estimate(key, fallback=value),
                source_est.evidence_weight(key),
                self.backoff_strength,
            )

        context_est = self._context.get((key, source_id, str(context)))
        context_weight = 0.0
        if context_est is not None:
            context_weight = context_est.evidence_weight(key)
            value = self._blend(
                value,
                context_est.estimate(key, fallback=value),
                context_weight,
                self.backoff_strength,
            )

        if exploration_weight > 0.0:
            value += float(exploration_weight) / ((context_weight + 1.0) ** 0.5)
        return value

    def estimate_belief(
        self,
        key: str,
        source_id: str,
        context_weights: dict[str, float],
        *,
        fallback: float = 0.0,
        exploration_weight: float = 0.0,
    ) -> float:
        weights = self._normalize_weights(context_weights)
        return sum(
            probability
            * self.estimate(
                key,
                source_id,
                context,
                fallback=fallback,
                exploration_weight=exploration_weight,
            )
            for context, probability in weights.items()
        )

    def snapshot(self) -> dict[str, object]:
        global_snap = self._global.snapshot()
        source: dict[str, dict[str, dict[str, float | int]]] = {}
        for (key, source_id), estimator in sorted(self._source.items()):
            source.setdefault(key, {})[source_id] = estimator.snapshot()[key]
        context: dict[str, dict[str, dict[str, dict[str, float | int]]]] = {}
        for (key, source_id, context_name), estimator in sorted(self._context.items()):
            context.setdefault(key, {}).setdefault(source_id, {})[context_name] = estimator.snapshot()[key]
        return {"global": global_snap, "source": source, "context": context}
