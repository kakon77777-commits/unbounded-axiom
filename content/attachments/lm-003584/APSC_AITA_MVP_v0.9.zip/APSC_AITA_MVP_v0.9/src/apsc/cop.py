from __future__ import annotations

from dataclasses import dataclass, fields, replace


@dataclass(frozen=True, slots=True)
class AdaptiveRegion:
    minimum: dict[str, float]
    maximum: dict[str, float]


@dataclass(frozen=True, slots=True)
class CognitiveOperatingProfile:
    depth: float = 0.5
    breadth: float = 0.5
    verification: float = 0.5
    counterfactual: float = 0.5
    observation: float = 0.5
    risk: float = 0.5
    latency: float = 0.5
    abstraction: float = 0.5
    commitment: float = 0.5
    novelty: float = 0.5

    def project(self, region: AdaptiveRegion) -> "CognitiveOperatingProfile":
        updates: dict[str, float] = {}
        valid = {f.name for f in fields(self)}
        for name in valid:
            value = getattr(self, name)
            lower = region.minimum.get(name, 0.0)
            upper = region.maximum.get(name, 1.0)
            if lower > upper:
                raise ValueError(f"invalid adaptive region for {name}")
            updates[name] = min(max(value, lower), upper)
        return replace(self, **updates)

    def to_dict(self) -> dict[str, float]:
        return {f.name: getattr(self, f.name) for f in fields(self)}
