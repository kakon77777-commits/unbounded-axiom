from __future__ import annotations

from dataclasses import dataclass, fields
from hashlib import sha256
from math import sqrt
import json
from pathlib import Path
from typing import Any


_ALLOWED_OPERATIONS = {"trust_signal", "observe_field"}
_FORBIDDEN_FEATURE_KEYS = {
    "true_context",
    "hidden_context",
    "context",
    "current_truth",
    "future_truth",
    "oracle_action",
}


def _bucket_probability(value: float) -> str:
    value = float(value)
    if value < 0.34:
        return "LOW"
    if value < 0.67:
        return "MID"
    return "HIGH"


def _bucket_mvc(value: float) -> str:
    value = float(value)
    if value < -0.25:
        return "NEG"
    if value > 0.25:
        return "POS"
    return "NEUTRAL"


def _bucket_round(value: float) -> str:
    value = float(value)
    if value < 0.34:
        return "EARLY"
    if value < 0.67:
        return "MID"
    return "LATE"


@dataclass(frozen=True, slots=True)
class MetaStateFeatures:
    belief_aligned: float
    belief_competitive: float
    belief_entropy: float
    effective_signal_trust: float
    effective_field_trust: float
    handcrafted_trust_mvc: float
    handcrafted_field_mvc: float
    round_fraction: float
    observation_available: bool
    signal_is_catastrophic: bool

    @classmethod
    def from_mapping(cls, payload: dict[str, Any]) -> "MetaStateFeatures":
        keys = set(payload)
        forbidden = keys & _FORBIDDEN_FEATURE_KEYS
        if forbidden:
            raise ValueError(f"forbidden meta feature keys: {sorted(forbidden)}")
        expected = {field.name for field in fields(cls)}
        unknown = keys - expected
        missing = expected - keys
        if unknown:
            raise ValueError(f"unknown meta feature keys: {sorted(unknown)}")
        if missing:
            raise ValueError(f"missing meta feature keys: {sorted(missing)}")
        obj = cls(
            belief_aligned=float(payload["belief_aligned"]),
            belief_competitive=float(payload["belief_competitive"]),
            belief_entropy=float(payload["belief_entropy"]),
            effective_signal_trust=float(payload["effective_signal_trust"]),
            effective_field_trust=float(payload["effective_field_trust"]),
            handcrafted_trust_mvc=float(payload["handcrafted_trust_mvc"]),
            handcrafted_field_mvc=float(payload["handcrafted_field_mvc"]),
            round_fraction=float(payload["round_fraction"]),
            observation_available=bool(payload["observation_available"]),
            signal_is_catastrophic=bool(payload["signal_is_catastrophic"]),
        )
        obj._validate()
        return obj

    def _validate(self) -> None:
        for name in (
            "belief_aligned",
            "belief_competitive",
            "belief_entropy",
            "effective_signal_trust",
            "effective_field_trust",
            "round_fraction",
        ):
            value = float(getattr(self, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
        if abs((self.belief_aligned + self.belief_competitive) - 1.0) > 1e-6:
            raise ValueError("belief probabilities must sum to 1")

    def to_dict(self) -> dict[str, Any]:
        return {
            "belief_aligned": float(self.belief_aligned),
            "belief_competitive": float(self.belief_competitive),
            "belief_entropy": float(self.belief_entropy),
            "effective_signal_trust": float(self.effective_signal_trust),
            "effective_field_trust": float(self.effective_field_trust),
            "handcrafted_trust_mvc": float(self.handcrafted_trust_mvc),
            "handcrafted_field_mvc": float(self.handcrafted_field_mvc),
            "round_fraction": float(self.round_fraction),
            "observation_available": bool(self.observation_available),
            "signal_is_catastrophic": bool(self.signal_is_catastrophic),
        }

    def bucket_key(self) -> str:
        parts = (
            f"ba={_bucket_probability(self.belief_aligned)}",
            f"bc={_bucket_probability(self.belief_competitive)}",
            f"ent={_bucket_probability(self.belief_entropy)}",
            f"st={_bucket_probability(self.effective_signal_trust)}",
            f"ft={_bucket_probability(self.effective_field_trust)}",
            f"tm={_bucket_mvc(self.handcrafted_trust_mvc)}",
            f"fm={_bucket_mvc(self.handcrafted_field_mvc)}",
            f"round={_bucket_round(self.round_fraction)}",
            f"obs={int(self.observation_available)}",
            f"cat={int(self.signal_is_catastrophic)}",
        )
        return "|".join(parts)


@dataclass(frozen=True, slots=True)
class CognitiveExperience:
    experience_id: str
    episode_id: str
    round_index: int
    operation: str
    features: MetaStateFeatures
    realized_value: float
    observation_cost: float

    def __post_init__(self) -> None:
        if self.operation not in _ALLOWED_OPERATIONS:
            raise ValueError(f"unsupported cognitive operation {self.operation!r}")
        if int(self.round_index) < 0:
            raise ValueError("round_index must be non-negative")
        if float(self.observation_cost) < 0.0:
            raise ValueError("observation_cost must be non-negative")

    def to_dict(self) -> dict[str, Any]:
        return {
            "experience_id": self.experience_id,
            "episode_id": self.episode_id,
            "round_index": int(self.round_index),
            "operation": self.operation,
            "features": self.features.to_dict(),
            "realized_value": float(self.realized_value),
            "observation_cost": float(self.observation_cost),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "CognitiveExperience":
        return cls(
            experience_id=str(payload["experience_id"]),
            episode_id=str(payload["episode_id"]),
            round_index=int(payload["round_index"]),
            operation=str(payload["operation"]),
            features=MetaStateFeatures.from_mapping(dict(payload["features"])),
            realized_value=float(payload["realized_value"]),
            observation_cost=float(payload["observation_cost"]),
        )


@dataclass(slots=True)
class _MeanStats:
    count: int = 0
    weight: float = 0.0
    mean: float = 0.0

    def update(self, value: float, weight: float = 1.0) -> None:
        weight = float(weight)
        if weight <= 0.0:
            return
        new_weight = self.weight + weight
        self.mean += weight * (float(value) - self.mean) / new_weight
        self.weight = new_weight
        self.count += 1

    def to_dict(self) -> dict[str, float | int]:
        return {"count": self.count, "weight": self.weight, "mean": self.mean}

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "_MeanStats":
        return cls(count=int(payload["count"]), weight=float(payload["weight"]), mean=float(payload["mean"]))


class ExperienceMetaValueModel:
    """Deterministic empirical cognition-value model with bucket-to-global backoff."""

    MODEL_TYPE = "experience-meta-value-v0.7"

    def __init__(self, *, backoff_strength: float = 1.0) -> None:
        if float(backoff_strength) <= 0.0:
            raise ValueError("backoff_strength must be positive")
        self.backoff_strength = float(backoff_strength)
        self._global: dict[str, _MeanStats] = {}
        self._buckets: dict[tuple[str, str], _MeanStats] = {}

    def update(self, experience: CognitiveExperience) -> float:
        return self.update_weighted(experience, weight=1.0)

    def update_weighted(self, experience: CognitiveExperience, *, weight: float = 1.0) -> float:
        weight = float(weight)
        if weight <= 0.0:
            raise ValueError("weight must be positive")
        operation = experience.operation
        self._global.setdefault(operation, _MeanStats()).update(experience.realized_value, weight)
        key = (operation, experience.features.bucket_key())
        self._buckets.setdefault(key, _MeanStats()).update(experience.realized_value, weight)
        return self.estimate(operation, experience.features, fallback=experience.realized_value)

    def estimate(self, operation: str, features: MetaStateFeatures, *, fallback: float = 0.0) -> float:
        if operation not in _ALLOWED_OPERATIONS:
            raise ValueError(f"unsupported cognitive operation {operation!r}")
        global_stats = self._global.get(operation)
        global_value = float(fallback) if global_stats is None or global_stats.weight <= 0 else global_stats.mean
        local = self._buckets.get((operation, features.bucket_key()))
        if local is None or local.weight <= 0:
            return global_value
        alpha = local.weight / (local.weight + self.backoff_strength)
        return alpha * local.mean + (1.0 - alpha) * global_value

    def evidence_count(self, operation: str) -> int:
        stats = self._global.get(operation)
        return 0 if stats is None else stats.count

    def evidence_weight(self, operation: str, features: MetaStateFeatures | None = None) -> float:
        if operation not in _ALLOWED_OPERATIONS:
            raise ValueError(f"unsupported cognitive operation {operation!r}")
        if features is None:
            stats = self._global.get(operation)
        else:
            stats = self._buckets.get((operation, features.bucket_key()))
        return 0.0 if stats is None else float(stats.weight)

    def uncertainty(self, operation: str, features: MetaStateFeatures) -> float:
        local_weight = self.evidence_weight(operation, features)
        return 1.0 / sqrt(1.0 + local_weight)

    def estimate_with_uncertainty(
        self,
        operation: str,
        features: MetaStateFeatures,
        *,
        fallback: float = 0.0,
    ) -> tuple[float, float]:
        return (
            self.estimate(operation, features, fallback=fallback),
            self.uncertainty(operation, features),
        )

    def total_experiences(self) -> int:
        return sum(stats.count for stats in self._global.values())

    def to_dict(self) -> dict[str, Any]:
        actions: dict[str, Any] = {}
        for operation in sorted(set(self._global) | {op for op, _ in self._buckets}):
            bucket_rows = {
                bucket: stats.to_dict()
                for (op, bucket), stats in sorted(self._buckets.items())
                if op == operation
            }
            actions[operation] = {
                "global": self._global.get(operation, _MeanStats()).to_dict(),
                "buckets": bucket_rows,
            }
        return {
            "model_type": self.MODEL_TYPE,
            "backoff_strength": self.backoff_strength,
            "actions": actions,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ExperienceMetaValueModel":
        if payload.get("model_type") != cls.MODEL_TYPE:
            raise ValueError("unsupported meta value model type")
        model = cls(backoff_strength=float(payload["backoff_strength"]))
        for operation, row in dict(payload.get("actions", {})).items():
            if operation not in _ALLOWED_OPERATIONS:
                raise ValueError(f"unsupported cognitive operation {operation!r}")
            global_row = dict(row.get("global", {}))
            if global_row:
                model._global[operation] = _MeanStats.from_dict(global_row)
            for bucket, stats_payload in dict(row.get("buckets", {})).items():
                model._buckets[(operation, str(bucket))] = _MeanStats.from_dict(dict(stats_payload))
        return model

    def model_hash(self) -> str:
        encoded = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return sha256(encoded).hexdigest()

    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "ExperienceMetaValueModel":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
