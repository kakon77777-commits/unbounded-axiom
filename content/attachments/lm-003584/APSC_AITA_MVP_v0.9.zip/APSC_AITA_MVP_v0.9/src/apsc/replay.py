from __future__ import annotations

from dataclasses import asdict, is_dataclass
from pathlib import Path
import hashlib
import json
from typing import Any


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, tuple):
        return [_jsonable(v) for v in value]
    if isinstance(value, list):
        return [_jsonable(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    return value


def write_json(path: Path, payload: Any) -> None:
    path.write_text(json.dumps(_jsonable(payload), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(_jsonable(row), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ReplayLedger:
    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def record_event(self, event_type: str, payload: dict[str, Any], causal_parent_ids: tuple[str, ...] = ()) -> dict[str, Any]:
        event = {
            "sequence": len(self.events),
            "event_id": f"event://{len(self.events):08d}",
            "event_type": event_type,
            "causal_parent_ids": list(causal_parent_ids),
            "payload": _jsonable(payload),
        }
        self.events.append(event)
        return event
