from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from apsc.meta_learning import CognitiveExperience


_OPERATIONS = ("trust_signal", "observe_field")
_OPERATION_SET = set(_OPERATIONS)
_SOURCE_KINDS = {
    "on_policy",
    "forced_exploration",
    "uncertainty_exploration",
    "counterfactual_off_policy",
}


@dataclass(frozen=True, slots=True)
class MetaTrainingExperience:
    experience: CognitiveExperience
    source_kind: str
    sample_weight: float
    behavior_operation: str
    selection_reason: str
    counterfactual_of: str | None = None

    def __post_init__(self) -> None:
        if self.source_kind not in _SOURCE_KINDS:
            raise ValueError(f"unsupported source_kind {self.source_kind!r}")
        if float(self.sample_weight) <= 0.0:
            raise ValueError("sample_weight must be positive")
        if self.behavior_operation not in _OPERATION_SET:
            raise ValueError("behavior_operation must be a supported cognition operation")
        if not str(self.selection_reason):
            raise ValueError("selection_reason must be non-empty")
        if self.experience.operation not in _OPERATION_SET:
            raise ValueError("experience operation must be supported")

    def to_dict(self) -> dict[str, Any]:
        payload = self.experience.to_dict()
        payload.update(
            {
                "source_kind": self.source_kind,
                "sample_weight": float(self.sample_weight),
                "behavior_operation": self.behavior_operation,
                "selection_reason": self.selection_reason,
                "counterfactual_of": self.counterfactual_of,
            }
        )
        return payload

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "MetaTrainingExperience":
        return cls(
            experience=CognitiveExperience.from_dict(payload),
            source_kind=str(payload["source_kind"]),
            sample_weight=float(payload["sample_weight"]),
            behavior_operation=str(payload["behavior_operation"]),
            selection_reason=str(payload["selection_reason"]),
            counterfactual_of=None if payload.get("counterfactual_of") is None else str(payload["counterfactual_of"]),
        )


@dataclass(frozen=True, slots=True)
class MetaSelection:
    selected_operation: str
    selection_reason: str
    greedy_operation: str
    learned_values: dict[str, float]
    uncertainties: dict[str, float]
    rank_scores: dict[str, float]


class UncertaintyAwareMetaSelector:
    """Deterministic coverage-floor + uncertainty-bonus selector."""

    def __init__(self, *, coverage_floor: int = 2, uncertainty_bonus: float = 0.35) -> None:
        if int(coverage_floor) < 0:
            raise ValueError("coverage_floor must be non-negative")
        if float(uncertainty_bonus) < 0.0:
            raise ValueError("uncertainty_bonus must be non-negative")
        self.coverage_floor = int(coverage_floor)
        self.uncertainty_bonus = float(uncertainty_bonus)

    @staticmethod
    def _ordered(feasible: set[str], round_index: int) -> list[str]:
        preferred = list(_OPERATIONS if int(round_index) % 2 == 0 else reversed(_OPERATIONS))
        return [op for op in preferred if op in feasible]

    @staticmethod
    def _argmax(values: dict[str, float], ordered: list[str]) -> str:
        if not ordered:
            raise ValueError("at least one feasible operation is required")
        best = ordered[0]
        best_value = float(values[best])
        for operation in ordered[1:]:
            value = float(values[operation])
            if value > best_value:
                best = operation
                best_value = value
        return best

    def select(
        self,
        *,
        learned_values: dict[str, float],
        uncertainties: dict[str, float],
        episode_counts: dict[str, int],
        feasible_operations: set[str],
        training: bool,
        round_index: int,
    ) -> MetaSelection:
        feasible = set(feasible_operations)
        if not feasible or not feasible <= _OPERATION_SET:
            raise ValueError("feasible_operations must be a non-empty subset of supported operations")
        ordered = self._ordered(feasible, round_index)
        learned = {op: float(learned_values[op]) for op in feasible}
        uncertainty = {op: float(uncertainties[op]) for op in feasible}
        greedy = self._argmax(learned, [op for op in _OPERATIONS if op in feasible])

        if training and self.coverage_floor > 0:
            under = [op for op in ordered if int(episode_counts.get(op, 0)) < self.coverage_floor]
            if under:
                minimum = min(int(episode_counts.get(op, 0)) for op in under)
                candidates = [op for op in under if int(episode_counts.get(op, 0)) == minimum]
                selected = candidates[0]
                rank_scores = {op: learned[op] for op in feasible}
                return MetaSelection(selected, "coverage_floor", greedy, learned, uncertainty, rank_scores)

        rank_scores = {
            op: learned[op] + self.uncertainty_bonus * uncertainty[op]
            for op in feasible
        }
        selected = self._argmax(rank_scores, [op for op in _OPERATIONS if op in feasible])
        reason = "greedy_value" if self.uncertainty_bonus == 0.0 else "uncertainty_ucb"
        return MetaSelection(selected, reason, greedy, learned, uncertainty, rank_scores)
