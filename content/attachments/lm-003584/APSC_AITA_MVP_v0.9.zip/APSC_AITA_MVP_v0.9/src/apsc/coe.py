from __future__ import annotations

from dataclasses import dataclass

from .budget import Budget
from .cop import CognitiveOperatingProfile


@dataclass(frozen=True, slots=True)
class ObservationCandidate:
    query_id: str
    information_gain: float
    decision_value: float
    risk_reduction: float
    compression: float
    cost: Budget
    reliability: float = 1.0
    source_id: str = "source://unknown"


@dataclass(frozen=True, slots=True)
class ObservationOutcome:
    label: str
    probability: float | None
    posterior_summary: dict[str, object]


def _budget_scalar(cost: Budget) -> float:
    return (
        cost.wall_ms / 1000.0
        + cost.compute_units
        + cost.memory_units * 0.25
        + cost.observation_units
        + cost.action_units
        + cost.external_units
    )


def value_observation(candidate: ObservationCandidate, cop: CognitiveOperatingProfile) -> float:
    reliability = min(max(float(candidate.reliability), 0.0), 1.0)
    epistemic = (
        0.15 * candidate.information_gain * max(cop.counterfactual, 0.1)
        + 0.10 * candidate.compression * max(cop.observation, 0.1)
    )
    decision_sensitive = reliability * (
        0.50 * candidate.decision_value
        + 0.25 * candidate.risk_reduction * max(cop.risk, 0.1)
    )
    benefit = epistemic + decision_sensitive
    return benefit - 0.05 * _budget_scalar(candidate.cost)
