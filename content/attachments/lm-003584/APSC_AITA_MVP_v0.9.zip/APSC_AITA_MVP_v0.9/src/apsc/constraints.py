from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Literal

from .models import PossibilityNode

ConstraintStatus = Literal["pass", "fail", "undetermined"]


@dataclass(frozen=True, slots=True)
class Constraint:
    constraint_id: str
    severity: Literal["hard", "soft"]
    predicate: Callable[[PossibilityNode], bool | None]

    def __post_init__(self) -> None:
        if not self.constraint_id.startswith("rule://"):
            raise ValueError("constraint_id must use rule:// namespace")


@dataclass(frozen=True, slots=True)
class ConstraintResult:
    constraint_id: str
    status: ConstraintStatus
    severity: Literal["hard", "soft"]


class ConstraintEngine:
    def __init__(self, constraints: list[Constraint] | tuple[Constraint, ...] = ()) -> None:
        self.constraints = tuple(constraints)

    def check(self, node: PossibilityNode) -> tuple[ConstraintResult, ...]:
        results: list[ConstraintResult] = []
        for constraint in self.constraints:
            value = constraint.predicate(node)
            status: ConstraintStatus = "undetermined" if value is None else ("pass" if value else "fail")
            results.append(ConstraintResult(constraint.constraint_id, status, constraint.severity))
        return tuple(results)
