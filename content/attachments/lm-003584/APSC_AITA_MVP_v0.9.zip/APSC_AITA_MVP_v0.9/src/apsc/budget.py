from __future__ import annotations

from dataclasses import dataclass, fields


class InsufficientBudget(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Budget:
    wall_ms: int = 0
    compute_units: int = 0
    memory_units: int = 0
    observation_units: int = 0
    action_units: int = 0
    external_units: int = 0

    def __post_init__(self) -> None:
        for field in fields(self):
            if getattr(self, field.name) < 0:
                raise ValueError(f"budget field {field.name} must be non-negative")

    def charge(self, cost: "Budget") -> "Budget":
        values: dict[str, int] = {}
        for field in fields(self):
            remaining = getattr(self, field.name) - getattr(cost, field.name)
            if remaining < 0:
                raise InsufficientBudget(f"insufficient {field.name}")
            values[field.name] = remaining
        return Budget(**values)

    def can_afford(self, cost: "Budget") -> bool:
        return all(getattr(self, f.name) >= getattr(cost, f.name) for f in fields(self))

    def to_dict(self) -> dict[str, int]:
        return {f.name: getattr(self, f.name) for f in fields(self)}
