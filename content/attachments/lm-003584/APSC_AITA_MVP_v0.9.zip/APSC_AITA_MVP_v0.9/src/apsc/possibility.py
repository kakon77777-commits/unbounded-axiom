from __future__ import annotations

from dataclasses import replace

from .constraints import ConstraintResult
from .models import PossibilityNode


class PossibilityGraph:
    def __init__(self) -> None:
        self._nodes: dict[str, PossibilityNode] = {}
        self._hard_failed: set[str] = set()

    def add_candidate(self, node: PossibilityNode) -> None:
        if node.node_id in self._nodes:
            raise ValueError("duplicate possibility node")
        self._nodes[node.node_id] = replace(node, status="candidate")

    def get(self, node_id: str) -> PossibilityNode:
        return self._nodes[node_id]

    def apply_constraints(self, node_id: str, results: tuple[ConstraintResult, ...]) -> None:
        hard_fail = any(r.severity == "hard" and r.status == "fail" for r in results)
        if hard_fail:
            self._hard_failed.add(node_id)
            self._nodes[node_id] = replace(self._nodes[node_id], status="pruned")

    def activate(self, node_id: str) -> None:
        if node_id in self._hard_failed or self._nodes[node_id].status == "pruned":
            raise ValueError("hard-failed possibility cannot become active")
        self._nodes[node_id] = replace(self._nodes[node_id], status="active")

    def prune(self, node_id: str) -> None:
        self._nodes[node_id] = replace(self._nodes[node_id], status="pruned")

    def mark_dormant(self, node_id: str) -> None:
        self._nodes[node_id] = replace(self._nodes[node_id], status="dormant")

    def merge(self, source_ids: tuple[str, ...], *, state_ref: str, horizon: int, resolution: str) -> PossibilityNode:
        if len(source_ids) < 2:
            raise ValueError("merge requires at least two source nodes")
        for source_id in source_ids:
            if source_id not in self._nodes:
                raise KeyError(source_id)
        merged = PossibilityNode.create(state_ref=state_ref, horizon=horizon, resolution=resolution, parent_ids=tuple(source_ids))
        self._nodes[merged.node_id] = merged
        for source_id in source_ids:
            self._nodes[source_id] = replace(self._nodes[source_id], status="merged")
        return merged

    @property
    def nodes(self) -> tuple[PossibilityNode, ...]:
        return tuple(self._nodes.values())
