from __future__ import annotations

from dataclasses import dataclass, fields
from hashlib import sha256
import json
from math import sqrt
from pathlib import Path
from typing import Any

from apsc.meta_generalization import OPERATIONS


def _bucket(value: float) -> str:
    value = float(value)
    if value < 0.34:
        return "LOW"
    if value < 0.67:
        return "MID"
    return "HIGH"


@dataclass(frozen=True, slots=True)
class ExplorationPolicyFeatures:
    state_uncertainty: float
    value_gap: float
    uncertainty_gap: float
    observation_cost_fraction: float

    @classmethod
    def from_mapping(cls, payload: dict[str, Any]) -> "ExplorationPolicyFeatures":
        expected = {field.name for field in fields(cls)}
        keys = set(payload)
        if keys != expected:
            missing = expected - keys
            unknown = keys - expected
            if missing:
                raise ValueError(f"missing exploration feature keys: {sorted(missing)}")
            raise ValueError(f"unknown exploration feature keys: {sorted(unknown)}")
        obj = cls(
            state_uncertainty=float(payload["state_uncertainty"]),
            value_gap=float(payload["value_gap"]),
            uncertainty_gap=float(payload["uncertainty_gap"]),
            observation_cost_fraction=float(payload["observation_cost_fraction"]),
        )
        for name in expected:
            value = float(getattr(obj, name))
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} must be between 0 and 1")
        return obj

    def to_dict(self) -> dict[str, float]:
        return {
            "state_uncertainty": float(self.state_uncertainty),
            "value_gap": float(self.value_gap),
            "uncertainty_gap": float(self.uncertainty_gap),
            "observation_cost_fraction": float(self.observation_cost_fraction),
        }

    def bucket_key(self) -> str:
        return "|".join(
            (
                f"state={_bucket(self.state_uncertainty)}",
                f"gap={_bucket(self.value_gap)}",
                f"ugap={_bucket(self.uncertainty_gap)}",
                f"cost={_bucket(self.observation_cost_fraction)}",
            )
        )


@dataclass(frozen=True, slots=True)
class ExplorationPolicyExperience:
    experience_id: str
    features: ExplorationPolicyFeatures
    greedy_operation: str
    alternate_operation: str
    exploration_advantage: float
    target_uncertainty: float

    def __post_init__(self) -> None:
        if self.greedy_operation not in set(OPERATIONS) or self.alternate_operation not in set(OPERATIONS):
            raise ValueError("unsupported exploration operation")
        if self.greedy_operation == self.alternate_operation:
            raise ValueError("greedy and alternate operations must differ")
        if not 0.0 <= float(self.target_uncertainty) <= 1.0:
            raise ValueError("target_uncertainty must be between 0 and 1")

    def to_dict(self) -> dict[str, Any]:
        return {
            "experience_id": self.experience_id,
            "features": self.features.to_dict(),
            "greedy_operation": self.greedy_operation,
            "alternate_operation": self.alternate_operation,
            "exploration_advantage": float(self.exploration_advantage),
            "target_uncertainty": float(self.target_uncertainty),
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ExplorationPolicyExperience":
        return cls(
            experience_id=str(payload["experience_id"]),
            features=ExplorationPolicyFeatures.from_mapping(dict(payload["features"])),
            greedy_operation=str(payload["greedy_operation"]),
            alternate_operation=str(payload["alternate_operation"]),
            exploration_advantage=float(payload["exploration_advantage"]),
            target_uncertainty=float(payload["target_uncertainty"]),
        )


@dataclass(slots=True)
class _Stats:
    count: int = 0
    weight: float = 0.0
    mean: float = 0.0

    def update(self, value: float, weight: float) -> None:
        if weight <= 0.0:
            return
        new_weight = self.weight + float(weight)
        self.mean += float(weight) * (float(value) - self.mean) / new_weight
        self.weight = new_weight
        self.count += 1

    def to_dict(self) -> dict[str, float | int]:
        return {"count": self.count, "weight": self.weight, "mean": self.mean}

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "_Stats":
        return cls(int(payload.get("count", 0)), float(payload.get("weight", 0.0)), float(payload.get("mean", 0.0)))


@dataclass(frozen=True, slots=True)
class ExplorationPolicyPrediction:
    expected_advantage: float
    epistemic_uncertainty: float
    evidence_weight: float


class LearnedExplorationPolicyModel:
    MODEL_TYPE = "learned-exploration-policy-v0.9"

    def __init__(self, *, backoff_strength: float = 1.0, min_target_weight: float = 0.05) -> None:
        if float(backoff_strength) <= 0.0:
            raise ValueError("backoff_strength must be positive")
        if not 0.0 < float(min_target_weight) <= 1.0:
            raise ValueError("min_target_weight must be in (0, 1]")
        self.backoff_strength = float(backoff_strength)
        self.min_target_weight = float(min_target_weight)
        self._global = _Stats()
        self._buckets: dict[str, _Stats] = {}

    def update(self, experience: ExplorationPolicyExperience, *, sample_weight: float = 1.0) -> ExplorationPolicyPrediction:
        if float(sample_weight) <= 0.0:
            raise ValueError("sample_weight must be positive")
        confidence = max(1.0 - float(experience.target_uncertainty), self.min_target_weight)
        weight = float(sample_weight) * confidence
        self._global.update(experience.exploration_advantage, weight)
        self._buckets.setdefault(experience.features.bucket_key(), _Stats()).update(experience.exploration_advantage, weight)
        return self.predict(experience.features)

    def evidence_weight(self, features: ExplorationPolicyFeatures | None = None) -> float:
        stats = self._global if features is None else self._buckets.get(features.bucket_key())
        return 0.0 if stats is None else float(stats.weight)

    def predict(self, features: ExplorationPolicyFeatures) -> ExplorationPolicyPrediction:
        local = self._buckets.get(features.bucket_key())
        if self._global.weight <= 0.0:
            expected = 0.0
        elif local is None or local.weight <= 0.0:
            expected = self._global.mean
        else:
            alpha = local.weight / (local.weight + self.backoff_strength)
            expected = alpha * local.mean + (1.0 - alpha) * self._global.mean
        local_weight = 0.0 if local is None else local.weight
        return ExplorationPolicyPrediction(
            expected_advantage=float(expected),
            epistemic_uncertainty=1.0 / sqrt(1.0 + local_weight),
            evidence_weight=float(local_weight),
        )

    def should_explore(self, features: ExplorationPolicyFeatures, *, threshold: float = 0.0) -> bool:
        prediction = self.predict(features)
        return prediction.evidence_weight > 0.0 and prediction.expected_advantage > float(threshold)

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_type": self.MODEL_TYPE,
            "backoff_strength": self.backoff_strength,
            "min_target_weight": self.min_target_weight,
            "global": self._global.to_dict(),
            "buckets": {key: stats.to_dict() for key, stats in sorted(self._buckets.items())},
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "LearnedExplorationPolicyModel":
        if payload.get("model_type") != cls.MODEL_TYPE:
            raise ValueError("unsupported exploration policy model type")
        model = cls(
            backoff_strength=float(payload["backoff_strength"]),
            min_target_weight=float(payload["min_target_weight"]),
        )
        model._global = _Stats.from_dict(dict(payload.get("global", {})))
        for key, row in dict(payload.get("buckets", {})).items():
            model._buckets[str(key)] = _Stats.from_dict(dict(row))
        return model

    def model_hash(self) -> str:
        encoded = json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        return sha256(encoded).hexdigest()

    def save(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    @classmethod
    def load(cls, path: Path) -> "LearnedExplorationPolicyModel":
        return cls.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
