from __future__ import annotations

from dataclasses import dataclass, field
import uuid

from .budget import Budget


@dataclass(frozen=True, slots=True)
class OperatorSpec:
    operator_id: str
    input_types: tuple[str, ...]
    output_types: tuple[str, ...]
    interruptible: bool = True
    checkpointable: bool = True

    def __post_init__(self) -> None:
        if not self.operator_id.startswith("cog://") or "@" not in self.operator_id:
            raise ValueError("operator_id must look like cog://name@version")


@dataclass(slots=True)
class CognitiveOperation:
    operator_id: str
    estimated_gain: float
    cost: Budget
    state_ref: str = ""
    operation_id: str = field(default_factory=lambda: f"cogop://{uuid.uuid4().hex}")
    status: str = "proposed"
    metadata: dict[str, object] = field(default_factory=dict)
