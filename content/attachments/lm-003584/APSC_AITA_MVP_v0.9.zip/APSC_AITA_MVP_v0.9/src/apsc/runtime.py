from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import uuid

from .budget import Budget
from .cop import CognitiveOperatingProfile
from .models import DecisionReceipt, StateSnapshot
from .operators import CognitiveOperation
from .replay import ReplayLedger, sha256_file, write_json, write_jsonl


@dataclass(frozen=True, slots=True)
class RunManifest:
    run_id: str
    goal: str
    runtime_version: str


class APSCRuntime:
    def __init__(self, *, goal: str, initial_state: StateSnapshot, budget: Budget, cop: CognitiveOperatingProfile) -> None:
        self.manifest = RunManifest(f"run://{uuid.uuid4().hex}", goal, "0.1.0")
        self.state = initial_state
        self.budget = budget
        self.cop = cop
        self.ledger = ReplayLedger()
        self.receipts: list[DecisionReceipt] = []
        self.budget_rows: list[dict[str, object]] = []
        self.final_commit: dict[str, object] | None = None
        self.ledger.record_event("run.initialized", {"run_id": self.manifest.run_id, "state_ref": self.state.state_id})

    def step(self, operation: CognitiveOperation, *, next_payload: dict[str, object] | None = None) -> DecisionReceipt:
        before = self.budget
        after = before.charge(operation.cost)
        parent_state = self.state
        self.state = StateSnapshot.create(
            payload=dict(parent_state.payload if next_payload is None else next_payload),
            observation_ids=parent_state.observation_ids,
            parent=parent_state,
        )
        self.budget = after
        receipt = DecisionReceipt.create(
            state_ref=self.state.state_id,
            selected_operation=operation.operator_id,
            alternatives=(),
            commit=False,
        )
        self.receipts.append(receipt)
        self.budget_rows.append(
            {
                "operation_id": operation.operation_id,
                "before": before.to_dict(),
                "charge": operation.cost.to_dict(),
                "after": after.to_dict(),
            }
        )
        self.ledger.record_event(
            "cognition.operation.completed",
            {
                "operation_id": operation.operation_id,
                "operator_id": operation.operator_id,
                "state_before": parent_state.state_id,
                "state_after": self.state.state_id,
                "receipt_id": receipt.receipt_id,
            },
        )
        return receipt

    def commit(self, result: object) -> DecisionReceipt:
        receipt = DecisionReceipt.create(self.state.state_id, "cog://commit@0.1", commit=True)
        self.receipts.append(receipt)
        self.final_commit = {"state_ref": self.state.state_id, "result": result, "receipt_id": receipt.receipt_id}
        self.ledger.record_event("run.committed", dict(self.final_commit))
        return receipt

    def export_run(self, directory: Path) -> Path:
        directory.mkdir(parents=True, exist_ok=True)
        write_json(directory / "run_manifest.json", asdict(self.manifest))
        write_jsonl(directory / "events.jsonl", self.ledger.events)
        write_jsonl(directory / "budgets.jsonl", self.budget_rows)
        write_jsonl(directory / "receipts.jsonl", [asdict(r) for r in self.receipts])
        write_json(directory / "final_state.json", asdict(self.state))
        if self.final_commit is not None:
            write_json(directory / "final_commit.json", self.final_commit)

        artifact_names = [
            "events.jsonl",
            "budgets.jsonl",
            "receipts.jsonl",
            "final_state.json",
            "run_manifest.json",
        ]
        if self.final_commit is not None:
            artifact_names.append("final_commit.json")
        replay_manifest = {
            "run_id": self.manifest.run_id,
            "runtime_version": self.manifest.runtime_version,
            "deterministic_core": True,
            "artifact_hashes": {name: sha256_file(directory / name) for name in artifact_names},
        }
        write_json(directory / "replay_manifest.json", replay_manifest)
        return directory
