from __future__ import annotations

from dataclasses import fields

from .budget import Budget
from .cop import CognitiveOperatingProfile
from .operators import CognitiveOperation


class AdaptiveController:
    def __init__(
        self,
        shadow_prices: dict[str, float] | None = None,
        *,
        epsilon: float = 0.0,
        preemption_threshold: float = 0.25,
    ) -> None:
        self.shadow_prices = dict(shadow_prices or {})
        self.epsilon = epsilon
        self.preemption_threshold = preemption_threshold

    def score(self, operation: CognitiveOperation, cop: CognitiveOperatingProfile) -> float:
        cost_penalty = 0.0
        for field in fields(Budget):
            cost_penalty += self.shadow_prices.get(field.name, 0.0) * getattr(operation.cost, field.name)
        gain = operation.estimated_gain
        kind = str(operation.metadata.get("kind", ""))
        if kind == "verify":
            gain *= 0.5 + cop.verification
        elif kind == "observe":
            gain *= 0.5 + cop.observation
        elif kind == "expand":
            gain *= 0.5 + (cop.depth + cop.breadth) / 2.0
        elif kind == "counterfactual":
            gain *= 0.5 + cop.counterfactual
        return gain - cost_penalty

    def choose(
        self,
        operations: list[CognitiveOperation] | tuple[CognitiveOperation, ...],
        budget: Budget,
        cop: CognitiveOperatingProfile,
    ) -> CognitiveOperation | None:
        feasible = [op for op in operations if budget.can_afford(op.cost)]
        if not feasible:
            return None
        chosen = max(feasible, key=lambda op: (self.score(op, cop), op.operation_id))
        return chosen if self.score(chosen, cop) > self.epsilon else None

    def should_preempt(
        self,
        current: CognitiveOperation,
        candidate: CognitiveOperation,
        budget: Budget,
        cop: CognitiveOperatingProfile,
    ) -> bool:
        if not budget.can_afford(candidate.cost):
            return False
        return self.score(candidate, cop) - self.score(current, cop) > self.preemption_threshold
