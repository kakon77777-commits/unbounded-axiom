from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class _SourceStats:
    declared_reliability: float
    successes: float = 0.0
    failures: float = 0.0
    squared_error_sum: float = 0.0


class SourceReliabilityTracker:
    """Online calibration for source correctness with a declared-reliability prior."""

    def __init__(self, *, prior_strength: float = 2.0) -> None:
        if prior_strength <= 0:
            raise ValueError("prior_strength must be positive")
        self.prior_strength = float(prior_strength)
        self._stats: dict[str, _SourceStats] = {}

    @staticmethod
    def _validate_reliability(value: float) -> float:
        value = float(value)
        if not 0.0 <= value <= 1.0:
            raise ValueError("reliability must be between 0 and 1")
        return value

    def _get(self, source_id: str, declared_reliability: float) -> _SourceStats:
        declared = self._validate_reliability(declared_reliability)
        stats = self._stats.get(source_id)
        if stats is None:
            stats = _SourceStats(declared)
            self._stats[source_id] = stats
        return stats

    def estimate(self, source_id: str, declared_reliability: float) -> float:
        stats = self._get(source_id, declared_reliability)
        total = stats.successes + stats.failures
        return (self.prior_strength * stats.declared_reliability + stats.successes) / (self.prior_strength + total)

    def record_weighted(
        self,
        source_id: str,
        declared_reliability: float,
        *,
        correct: bool,
        weight: float,
    ) -> float:
        weight = float(weight)
        if weight < 0.0:
            raise ValueError("weight must be non-negative")
        stats = self._get(source_id, declared_reliability)
        if weight == 0.0:
            return self.estimate(source_id, stats.declared_reliability)
        prediction = self.estimate(source_id, stats.declared_reliability)
        outcome = 1.0 if correct else 0.0
        stats.squared_error_sum += weight * (prediction - outcome) ** 2
        if correct:
            stats.successes += weight
        else:
            stats.failures += weight
        return self.estimate(source_id, stats.declared_reliability)

    def record(self, source_id: str, declared_reliability: float, *, correct: bool) -> float:
        return self.record_weighted(source_id, declared_reliability, correct=correct, weight=1.0)

    def calibration_error(self, source_id: str, declared_reliability: float) -> float:
        stats = self._get(source_id, declared_reliability)
        total = stats.successes + stats.failures
        return 0.0 if total == 0 else stats.squared_error_sum / total

    def evidence_weight(self, source_id: str, declared_reliability: float) -> float:
        stats = self._get(source_id, declared_reliability)
        return stats.successes + stats.failures

    def snapshot(self) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {}
        for source_id, stats in sorted(self._stats.items()):
            result[source_id] = {
                "declared_reliability": stats.declared_reliability,
                "estimated_reliability": self.estimate(source_id, stats.declared_reliability),
                "successes": stats.successes,
                "failures": stats.failures,
                "calibration_error": self.calibration_error(source_id, stats.declared_reliability),
            }
        return result


class ContextualSourceReliabilityTracker:
    """Source reliability with context-specific posteriors backed off to a global source estimate."""

    def __init__(self, *, prior_strength: float = 2.0, backoff_strength: float = 1.0) -> None:
        if backoff_strength <= 0:
            raise ValueError("backoff_strength must be positive")
        self.backoff_strength = float(backoff_strength)
        self._global = SourceReliabilityTracker(prior_strength=prior_strength)
        self._contexts: dict[str, SourceReliabilityTracker] = {}

    @staticmethod
    def _normalize_weights(context_weights: dict[str, float]) -> dict[str, float]:
        cleaned = {str(context): float(weight) for context, weight in context_weights.items() if float(weight) > 0.0}
        if any(float(weight) < 0.0 for weight in context_weights.values()):
            raise ValueError("context weights must be non-negative")
        total = sum(cleaned.values())
        if total <= 0.0:
            raise ValueError("context weights must contain positive mass")
        return {context: weight / total for context, weight in cleaned.items()}

    @staticmethod
    def _count_from_snapshot(snapshot: dict[str, dict[str, float]], source_id: str) -> float:
        row = snapshot.get(source_id)
        if row is None:
            return 0.0
        return float(row["successes"]) + float(row["failures"])

    def _context_tracker(self, context: str) -> SourceReliabilityTracker:
        tracker = self._contexts.get(context)
        if tracker is None:
            tracker = SourceReliabilityTracker(prior_strength=self._global.prior_strength)
            self._contexts[context] = tracker
        return tracker

    def record(self, source_id: str, context: str, declared_reliability: float, *, correct: bool) -> float:
        return self.record_belief(source_id, {str(context): 1.0}, declared_reliability, correct=correct)

    def record_belief(
        self,
        source_id: str,
        context_weights: dict[str, float],
        declared_reliability: float,
        *,
        correct: bool,
    ) -> float:
        weights = self._normalize_weights(context_weights)
        self._global.record(source_id, declared_reliability, correct=correct)
        for context, weight in weights.items():
            self._context_tracker(context).record_weighted(
                source_id,
                declared_reliability,
                correct=correct,
                weight=weight,
            )
        return self.estimate_belief(source_id, weights, declared_reliability)

    def global_estimate(self, source_id: str, declared_reliability: float) -> float:
        return self._global.estimate(source_id, declared_reliability)

    def estimate(self, source_id: str, context: str, declared_reliability: float) -> float:
        global_est = self._global.estimate(source_id, declared_reliability)
        tracker = self._contexts.get(str(context))
        if tracker is None:
            return global_est
        count = self._count_from_snapshot(tracker.snapshot(), source_id)
        if count == 0:
            return global_est
        context_est = tracker.estimate(source_id, declared_reliability)
        weight = count / (count + self.backoff_strength)
        return weight * context_est + (1.0 - weight) * global_est

    def estimate_belief(
        self,
        source_id: str,
        context_weights: dict[str, float],
        declared_reliability: float,
    ) -> float:
        weights = self._normalize_weights(context_weights)
        return sum(
            weight * self.estimate(source_id, context, declared_reliability)
            for context, weight in weights.items()
        )

    def snapshot(self) -> dict[str, object]:
        return {
            "global": self._global.snapshot(),
            "contexts": {name: tracker.snapshot() for name, tracker in sorted(self._contexts.items())},
        }
