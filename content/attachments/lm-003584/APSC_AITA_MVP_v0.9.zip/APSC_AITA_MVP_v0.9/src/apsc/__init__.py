"""Adaptive Possibility-Space Cognition runtime MVP."""

__version__ = "0.1.0"
