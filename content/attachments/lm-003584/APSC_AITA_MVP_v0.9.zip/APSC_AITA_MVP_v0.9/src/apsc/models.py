from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import uuid
from typing import Any


def _id(prefix: str) -> str:
    return f"{prefix}://{uuid.uuid4().hex}"


def stable_fingerprint(payload: Any) -> str:
    raw = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


@dataclass(frozen=True, slots=True)
class ObservationRecord:
    observation_id: str
    source: str
    payload: dict[str, Any]
    reliability: float
    provenance: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def create(cls, source: str, payload: dict[str, Any], reliability: float, provenance: dict[str, Any] | None = None) -> "ObservationRecord":
        if not 0.0 <= reliability <= 1.0:
            raise ValueError("reliability must be between 0 and 1")
        return cls(_id("obs"), source, dict(payload), reliability, dict(provenance or {}))


@dataclass(frozen=True, slots=True)
class StateSnapshot:
    state_id: str
    version: int
    parent_state_id: str | None
    payload: dict[str, Any]
    observation_ids: tuple[str, ...] = ()

    @classmethod
    def create(cls, payload: dict[str, Any], observation_ids: tuple[str, ...] = (), parent: "StateSnapshot | None" = None) -> "StateSnapshot":
        return cls(
            state_id=_id("state"),
            version=0 if parent is None else parent.version + 1,
            parent_state_id=None if parent is None else parent.state_id,
            payload=dict(payload),
            observation_ids=tuple(observation_ids),
        )


@dataclass(frozen=True, slots=True)
class PossibilityNode:
    node_id: str
    state_ref: str
    horizon: int
    resolution: str
    parent_ids: tuple[str, ...] = ()
    probability: float | None = None
    risk: float | None = None
    decision_value: float | None = None
    reachability: str = "undetermined"
    status: str = "candidate"

    @classmethod
    def create(cls, state_ref: str, horizon: int, resolution: str, parent_ids: tuple[str, ...] = ()) -> "PossibilityNode":
        return cls(_id("poss"), state_ref, horizon, resolution, tuple(parent_ids))


@dataclass(frozen=True, slots=True)
class DecisionReceipt:
    receipt_id: str
    state_ref: str
    selected_operation: str
    alternatives: tuple[str, ...]
    commit: bool

    @classmethod
    def create(cls, state_ref: str, selected_operation: str, alternatives: tuple[str, ...] = (), commit: bool = False) -> "DecisionReceipt":
        return cls(_id("receipt"), state_ref, selected_operation, tuple(alternatives), commit)

@dataclass(frozen=True, slots=True)
class ProfileReceipt:
    receipt_id: str
    old_profile: dict[str, float]
    new_profile: dict[str, float]
    reason_code: str

    @classmethod
    def create(cls, old_profile: dict[str, float], new_profile: dict[str, float], reason_code: str) -> "ProfileReceipt":
        return cls(_id("receipt"), dict(old_profile), dict(new_profile), reason_code)
