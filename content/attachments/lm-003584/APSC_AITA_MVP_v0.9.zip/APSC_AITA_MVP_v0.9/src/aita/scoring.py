from __future__ import annotations

from apsc.budget import Budget

CANONICAL_METRICS = (
    "task_utility",
    "decision_quality",
    "cognitive_efficiency",
    "observation_efficiency",
    "critical_branch_recall",
    "opponent_model_regret",
    "allocation_regret",
    "observation_regret",
    "commit_regret",
    "rule_compliance",
    "robustness",
)


def _used(initial: Budget, final: Budget, name: str) -> int:
    return getattr(initial, name) - getattr(final, name)


def score_episode(
    world_score: dict[str, object],
    *,
    initial_budget: Budget,
    final_budget: Budget,
    status: str,
) -> dict[str, float]:
    success = bool(world_score.get("reached_goal", world_score.get("correct", False)))
    quality = 1.0 if success else 0.0
    utility = float(world_score.get("utility", quality))
    compute_used = max(_used(initial_budget, final_budget, "compute_units"), 0)
    observation_used = max(_used(initial_budget, final_budget, "observation_units"), 0)
    action_used = max(_used(initial_budget, final_budget, "action_units"), 0)
    total_cost = max(compute_used + observation_used + action_used, 1)
    metrics = {
        "task_utility": utility,
        "decision_quality": quality,
        "cognitive_efficiency": quality / total_cost,
        "observation_efficiency": quality / max(observation_used, 1),
        "critical_branch_recall": quality,
        "opponent_model_regret": 0.0,
        "allocation_regret": (1.0 - quality) * 0.25,
        "observation_regret": (0.0 if success else observation_used * 0.05),
        "commit_regret": 0.0 if status == "completed" else 1.0,
        "rule_compliance": 0.0 if status == "illegal_action" else 1.0,
        "robustness": 1.0,
    }
    result = {name: round(float(metrics[name]), 8) for name in CANONICAL_METRICS}
    for name, value in world_score.items():
        if name in result or name in {"utility", "reached_goal", "correct", "ticks"}:
            continue
        if isinstance(value, bool):
            result[name] = 1.0 if value else 0.0
        elif isinstance(value, (int, float)):
            result[name] = round(float(value), 8)
    return result


def _budget_total(budget: Budget) -> int:
    return sum(budget.to_dict().values())


def score_duel_episode(
    world_scores: dict[str, dict[str, object]],
    *,
    initial_budgets: dict[str, Budget],
    final_budgets: dict[str, Budget],
    agent_status: dict[str, str],
) -> dict[str, dict[str, float]]:
    agent_ids = tuple(sorted(world_scores))
    any_winner = any(bool(world_scores[agent].get("winner", False)) for agent in agent_ids)
    scores: dict[str, dict[str, float]] = {}
    for agent_id in agent_ids:
        status = agent_status.get(agent_id, "completed")
        base = score_episode(
            world_scores[agent_id],
            initial_budget=initial_budgets[agent_id],
            final_budget=final_budgets[agent_id],
            status=status,
        )
        opponent_id = next(other for other in agent_ids if other != agent_id)
        own_remaining = _budget_total(final_budgets[agent_id])
        opponent_remaining = _budget_total(final_budgets[opponent_id])
        normalization = max(_budget_total(initial_budgets[agent_id]), _budget_total(initial_budgets[opponent_id]), 1)
        collision_blocks = int(world_scores[agent_id].get("collision_blocks", 0))
        winner = bool(world_scores[agent_id].get("winner", False))
        duel_outcome = 1.0 if winner else (-1.0 if any_winner else 0.0)
        base["opponent_model_regret"] = round(min(1.0, collision_blocks * 0.1), 8)
        base["duel_outcome"] = duel_outcome
        base["resource_advantage"] = round((own_remaining - opponent_remaining) / normalization, 8)
        base["tension_efficiency"] = round(base["cognitive_efficiency"] / (1.0 + collision_blocks), 8)
        scores[agent_id] = base
    return scores
