from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass
from pathlib import Path
import hashlib
import json
from typing import Any

from apsc.budget import Budget, InsufficientBudget
from apsc.cop import CognitiveOperatingProfile
from apsc.replay import sha256_file, write_json, write_jsonl
from aita.agents import AgentAdapter
from aita.protocol import EpisodeConfig, ObservationResult
from aita.scoring import score_duel_episode, score_episode


def _json_hash(payload: object) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _serial(value: Any) -> Any:
    if is_dataclass(value):
        return {k: _serial(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): _serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_serial(v) for v in value]
    return value


@dataclass(frozen=True, slots=True)
class EpisodeResult:
    episode_id: str
    status: str
    score: dict[str, float]
    output_dir: Path
    initial_world_hash: str
    final_budget: Budget


def run_episode(
    world: Any,
    agent: AgentAdapter,
    config: EpisodeConfig,
    output_dir: Path,
    cop: CognitiveOperatingProfile,
) -> EpisodeResult:
    output_dir.mkdir(parents=True, exist_ok=True)
    public_state = world.reset(config.seed)
    initial_replay_state = world.export_replay_state()
    initial_world_hash = _json_hash(initial_replay_state)
    agent.reset(cop)
    budget = config.budget
    initial_budget = budget

    events: list[dict[str, Any]] = []
    observations: list[dict[str, Any]] = []
    cognitive_ops: list[dict[str, Any]] = []
    actions: list[dict[str, Any]] = []
    budgets: list[dict[str, Any]] = []
    profiles: list[dict[str, Any]] = [{"sequence": 0, "profile": cop.to_dict(), "source": "initial"}]
    receipts: list[dict[str, Any]] = []
    calibrations: list[dict[str, Any]] = []
    meta_generalization_rows: list[dict[str, Any]] = []
    last_meta_generalization_snapshot: dict[str, Any] | None = None
    status = "running"
    sequence = 0
    max_cycles = 256

    def event(event_type: str, payload: dict[str, Any]) -> None:
        nonlocal sequence
        events.append({"sequence": sequence, "event_type": event_type, "payload": _serial(payload)})
        sequence += 1

    def charge(cost: Budget, category: str, ref: str) -> bool:
        nonlocal budget, status
        before = budget
        try:
            after = budget.charge(cost)
        except InsufficientBudget:
            status = "budget_exhausted"
            event("budget.exhausted", {"category": category, "ref": ref, "before": before.to_dict(), "charge": cost.to_dict()})
            return False
        budget = after
        budgets.append({"category": category, "ref": ref, "before": before.to_dict(), "charge": cost.to_dict(), "after": after.to_dict()})
        return True

    event("episode.reset", {"seed": config.seed, "public_state": public_state})

    for cycle in range(max_cycles):
        if world.is_terminal():
            status = "completed"
            break
        public_state = world.get_public_state()
        decision = agent.decide(public_state, budget)
        generalization_method = getattr(agent, "meta_generalization_snapshot", None)
        if callable(generalization_method):
            snapshot = _serial(generalization_method())
            meaningful = snapshot.get("selected_operation") is not None
            if meaningful and snapshot != last_meta_generalization_snapshot:
                meta_generalization_rows.append({"cycle": cycle, "snapshot": snapshot})
                last_meta_generalization_snapshot = snapshot
        calibration_method = getattr(agent, "calibration_snapshot", None)
        if callable(calibration_method):
            snapshot = calibration_method()
            meaningful = bool(snapshot.get("reliability")) or bool(snapshot.get("mvc")) or snapshot.get("last_selected_source") is not None
            if meaningful:
                row = {"cycle": cycle, "round_index": public_state.get("round_index"), **_serial(snapshot)}
                comparable = {k: v for k, v in row.items() if k != "cycle"}
                previous = ({k: v for k, v in calibrations[-1].items() if k != "cycle"} if calibrations else None)
                if comparable != previous:
                    calibrations.append(row)
        op_ref = f"cogstep://{cycle}"
        cognitive_ops.append(
            {
                "cycle": cycle,
                "operator": decision.cognition_operator,
                "compute_cost": decision.compute_cost.to_dict(),
                "has_query": decision.query is not None,
                "has_action": decision.action is not None,
            }
        )
        event("cognition.selected", {"cycle": cycle, "operator": decision.cognition_operator})
        if not charge(decision.compute_cost, "cognition", op_ref):
            break

        if decision.profile_receipt is not None:
            receipt_payload = _serial(decision.profile_receipt)
            receipts.append(receipt_payload)
            profiles.append({"sequence": len(profiles), "profile": decision.profile_receipt.new_profile, "source": "adaptive", "receipt_id": decision.profile_receipt.receipt_id})
            event("profile.shift", receipt_payload)

        if decision.query is not None:
            if budget.observation_units <= 0:
                status = "budget_exhausted"
                event("budget.exhausted", {"category": "observation", "ref": op_ref})
                break
            result: ObservationResult = world.observe(agent.agent_id, decision.query)
            if not charge(result.cost, "observation", result.observation_id):
                break
            agent.ingest_observation(result)
            observations.append(_serial(result))
            event("observation.received", _serial(result))
            continue

        if decision.action is not None:
            try:
                before_world = world.get_public_state()
                public_state = world.step({agent.agent_id: decision.action})
            except ValueError as exc:
                status = "illegal_action"
                event("action.illegal", {"action": decision.action, "error": str(exc)})
                break
            actions.append({"cycle": cycle, "agent_id": agent.agent_id, "action": decision.action, "before": before_world, "after": public_state})
            event("action.applied", {"action": decision.action, "public_state": public_state})
            continue

        status = "agent_error"
        event("agent.invalid_decision", {"cycle": cycle})
        break
    else:
        status = "cycle_limit"

    if status == "running" and world.is_terminal():
        status = "completed"
    world_score = world.score_state()
    metric_vector = score_episode(world_score, initial_budget=initial_budget, final_budget=budget, status=status)

    episode_payload = {
        "episode_id": config.episode_id,
        "world_id": getattr(world, "WORLD_ID", type(world).__name__),
        "seed": config.seed,
        "baseline": config.baseline,
        "budget": initial_budget.to_dict(),
        "profile_name": config.profile_name,
        "status": status,
    }
    world_manifest = {
        "world_id": episode_payload["world_id"],
        "seed": config.seed,
        "initial_world_hash": initial_world_hash,
        "initial_replay_state": initial_replay_state,
    }
    write_json(output_dir / "episode.json", episode_payload)
    write_json(output_dir / "world_manifest.json", world_manifest)
    write_jsonl(output_dir / "events.jsonl", events)
    write_jsonl(output_dir / "observations.jsonl", observations)
    write_jsonl(output_dir / "cognitive_ops.jsonl", cognitive_ops)
    write_jsonl(output_dir / "actions.jsonl", actions)
    write_jsonl(output_dir / "budgets.jsonl", budgets)
    write_jsonl(output_dir / "profiles.jsonl", profiles)
    write_jsonl(output_dir / "receipts.jsonl", receipts)
    if calibrations:
        write_jsonl(output_dir / "calibration.jsonl", calibrations)
    if meta_generalization_rows:
        write_jsonl(output_dir / "meta_generalization.jsonl", meta_generalization_rows)
    write_json(output_dir / "score.json", metric_vector)

    artifact_names = [
        "episode.json", "world_manifest.json", "events.jsonl", "observations.jsonl",
        "cognitive_ops.jsonl", "actions.jsonl", "budgets.jsonl", "profiles.jsonl",
        "receipts.jsonl", "score.json",
    ]
    if calibrations:
        artifact_names.append("calibration.jsonl")
    if meta_generalization_rows:
        artifact_names.append("meta_generalization.jsonl")
    replay_manifest = {
        "episode_id": config.episode_id,
        "world_id": episode_payload["world_id"],
        "seed": config.seed,
        "deterministic_core": True,
        "initial_world_hash": initial_world_hash,
        "artifact_hashes": {name: sha256_file(output_dir / name) for name in artifact_names},
    }
    write_json(output_dir / "replay_manifest.json", replay_manifest)
    return EpisodeResult(config.episode_id, status, metric_vector, output_dir, initial_world_hash, budget)


@dataclass(frozen=True, slots=True)
class DuelEpisodeResult:
    episode_id: str
    status: str
    scores: dict[str, dict[str, float]]
    output_dir: Path
    initial_world_hash: str
    final_budgets: dict[str, Budget]


def run_duel_episode(
    world: Any,
    agents: dict[str, AgentAdapter],
    config: "DuelEpisodeConfig",
    output_dir: Path,
    cops: dict[str, CognitiveOperatingProfile],
) -> DuelEpisodeResult:
    from aita.protocol import DuelEpisodeConfig

    if not isinstance(config, DuelEpisodeConfig):
        raise TypeError("config must be DuelEpisodeConfig")
    if set(agents) != set(config.agent_ids) or set(cops) != set(config.agent_ids):
        raise ValueError("agents/cops must match duel config agent ids")

    output_dir.mkdir(parents=True, exist_ok=True)
    world.reset(config.seed)
    initial_replay_state = world.export_replay_state()
    initial_world_hash = _json_hash(initial_replay_state)
    budgets = dict(config.budgets)
    initial_budgets = dict(config.budgets)
    agent_status = {agent_id: "running" for agent_id in config.agent_ids}
    for agent_id in config.agent_ids:
        episode_setter = getattr(agents[agent_id], "set_episode_id", None)
        if callable(episode_setter):
            episode_setter(config.episode_id)
        agents[agent_id].reset(cops[agent_id])

    events: list[dict[str, Any]] = []
    observations: list[dict[str, Any]] = []
    cognitive_ops: list[dict[str, Any]] = []
    actions: list[dict[str, Any]] = []
    budget_rows: list[dict[str, Any]] = []
    profiles: list[dict[str, Any]] = [
        {"sequence": idx, "agent_id": agent_id, "profile": cops[agent_id].to_dict(), "source": "initial"}
        for idx, agent_id in enumerate(config.agent_ids)
    ]
    receipts: list[dict[str, Any]] = []
    deceptions: list[dict[str, Any]] = []
    last_deception_snapshot: dict[str, dict[str, Any]] = {}
    latent_contexts: list[dict[str, Any]] = []
    last_latent_context_snapshot: dict[str, dict[str, Any]] = {}
    meta_learning_rows: list[dict[str, Any]] = []
    last_meta_learning_snapshot: dict[str, dict[str, Any]] = {}
    meta_generalization_rows: list[dict[str, Any]] = []
    last_meta_generalization_snapshot: dict[str, dict[str, Any]] = {}
    sequence = 0

    def event(event_type: str, payload: dict[str, Any]) -> None:
        nonlocal sequence
        events.append({"sequence": sequence, "event_type": event_type, "payload": _serial(payload)})
        sequence += 1

    def charge(agent_id: str, cost: Budget, category: str, ref: str) -> bool:
        before = budgets[agent_id]
        try:
            after = before.charge(cost)
        except InsufficientBudget:
            agent_status[agent_id] = "budget_exhausted"
            event("budget.exhausted", {"agent_id": agent_id, "category": category, "ref": ref, "before": before.to_dict(), "charge": cost.to_dict()})
            return False
        budgets[agent_id] = after
        budget_rows.append({"agent_id": agent_id, "category": category, "ref": ref, "before": before.to_dict(), "charge": cost.to_dict(), "after": after.to_dict()})
        return True

    event("episode.reset", {"seed": config.seed, "public_state": {agent_id: world.get_public_state(agent_id) for agent_id in config.agent_ids}})

    status = "running"
    for cycle in range(config.max_cycles):
        if world.is_terminal():
            status = "completed"
            break

        action_bundle: dict[str, dict[str, Any]] = {}
        before_world = {agent_id: world.get_public_state(agent_id) for agent_id in config.agent_ids}

        for agent_id in config.agent_ids:
            if agent_status[agent_id] != "running":
                action_bundle[agent_id] = {"type": "wait"}
                continue

            decision = agents[agent_id].decide(before_world[agent_id], budgets[agent_id])
            generalization_method = getattr(agents[agent_id], "meta_generalization_snapshot", None)
            if callable(generalization_method):
                generalization_snapshot = _serial(generalization_method())
                if (
                    generalization_snapshot.get("selected_operation") is not None
                    and generalization_snapshot != last_meta_generalization_snapshot.get(agent_id)
                ):
                    meta_generalization_rows.append({
                        "cycle": cycle,
                        "agent_id": agent_id,
                        "snapshot": generalization_snapshot,
                    })
                    last_meta_generalization_snapshot[agent_id] = generalization_snapshot
            deception_method = getattr(agents[agent_id], "deception_snapshot", None)
            if callable(deception_method):
                snapshot = _serial(deception_method())
                meaningful = (
                    int(snapshot.get("feedback_count", 0)) > 0
                    or snapshot.get("last_received_signal") is not None
                    or snapshot.get("last_selected_path") is not None
                )
                if meaningful and snapshot != last_deception_snapshot.get(agent_id):
                    deceptions.append({"cycle": cycle, "agent_id": agent_id, "snapshot": snapshot})
                    last_deception_snapshot[agent_id] = snapshot
            latent_method = getattr(agents[agent_id], "latent_context_snapshot", None)
            if callable(latent_method):
                latent_snapshot = _serial(latent_method())
                latent_meaningful = (
                    int(latent_snapshot.get("feedback_count", 0)) > 0
                    or latent_snapshot.get("last_received_signal") is not None
                    or latent_snapshot.get("last_selected_path") is not None
                )
                if latent_meaningful and latent_snapshot != last_latent_context_snapshot.get(agent_id):
                    latent_contexts.append({"cycle": cycle, "agent_id": agent_id, "snapshot": latent_snapshot})
                    last_latent_context_snapshot[agent_id] = latent_snapshot
            meta_method = getattr(agents[agent_id], "meta_learning_snapshot", None)
            if callable(meta_method):
                meta_snapshot = _serial(meta_method())
                meta_meaningful = (
                    int(meta_snapshot.get("experience_count", 0)) > 0
                    or meta_snapshot.get("last_selected_operation") is not None
                )
                if meta_meaningful and meta_snapshot != last_meta_learning_snapshot.get(agent_id):
                    meta_learning_rows.append({"cycle": cycle, "agent_id": agent_id, "snapshot": meta_snapshot})
                    last_meta_learning_snapshot[agent_id] = meta_snapshot
            op_ref = f"cogstep://{cycle}/{agent_id.rsplit('/', 1)[-1]}"
            cognitive_ops.append({
                "cycle": cycle,
                "agent_id": agent_id,
                "operator": decision.cognition_operator,
                "compute_cost": decision.compute_cost.to_dict(),
                "has_query": decision.query is not None,
                "has_action": decision.action is not None,
            })
            event("cognition.selected", {"cycle": cycle, "agent_id": agent_id, "operator": decision.cognition_operator})
            if not charge(agent_id, decision.compute_cost, "cognition", op_ref):
                action_bundle[agent_id] = {"type": "wait"}
                continue

            if decision.profile_receipt is not None:
                receipt_payload = {"agent_id": agent_id, **_serial(decision.profile_receipt)}
                receipts.append(receipt_payload)
                profiles.append({
                    "sequence": len(profiles),
                    "agent_id": agent_id,
                    "profile": decision.profile_receipt.new_profile,
                    "source": "adaptive",
                    "receipt_id": decision.profile_receipt.receipt_id,
                })
                event("profile.shift", receipt_payload)

            if decision.query is not None:
                try:
                    result: ObservationResult = world.observe(agent_id, decision.query)
                except ValueError as exc:
                    agent_status[agent_id] = "observation_error"
                    event("observation.illegal", {"agent_id": agent_id, "query": decision.query, "error": str(exc)})
                    action_bundle[agent_id] = {"type": "wait"}
                    continue
                if not charge(agent_id, result.cost, "observation", result.observation_id):
                    action_bundle[agent_id] = {"type": "wait"}
                    continue
                agents[agent_id].ingest_observation(result)
                observations.append(_serial(result))
                event("observation.received", _serial(result))
                action_bundle[agent_id] = {"type": "wait"}
                continue

            action = decision.action or {"type": "wait"}
            if action not in world.legal_actions(agent_id):
                agent_status[agent_id] = "illegal_action"
                event("action.illegal", {"agent_id": agent_id, "action": action})
                action_bundle[agent_id] = {"type": "wait"}
            else:
                action_bundle[agent_id] = action

        try:
            after_world = world.step(action_bundle)
        except ValueError as exc:
            status = "world_error"
            event("world.step_failed", {"cycle": cycle, "action_bundle": action_bundle, "error": str(exc)})
            break

        actions.append({"cycle": cycle, "action_bundle": action_bundle, "before": before_world, "after": after_world})
        event("actions.applied", {"cycle": cycle, "action_bundle": action_bundle, "public_state": after_world})
    else:
        status = "cycle_limit"

    if status == "running" and world.is_terminal():
        status = "completed"

    final_public_state = {agent_id: world.get_public_state(agent_id) for agent_id in config.agent_ids}
    for agent_id in config.agent_ids:
        finalize_method = getattr(agents[agent_id], "finalize_episode", None)
        if callable(finalize_method):
            finalize_method(final_public_state[agent_id])

    raw_scores = world.score_state()
    scoring_status = {
        agent_id: ("completed" if agent_status[agent_id] == "running" and status == "completed" else agent_status[agent_id])
        for agent_id in config.agent_ids
    }
    scores = score_duel_episode(
        raw_scores,
        initial_budgets=initial_budgets,
        final_budgets=budgets,
        agent_status=scoring_status,
    )

    episode_payload = {
        "episode_id": config.episode_id,
        "world_id": getattr(world, "WORLD_ID", type(world).__name__),
        "seed": config.seed,
        "baselines": dict(config.agent_baselines),
        "budgets": {agent_id: budget.to_dict() for agent_id, budget in initial_budgets.items()},
        "profile_names": dict(config.profile_names),
        "status": status,
        "agent_status": agent_status,
    }
    world_manifest = {
        "world_id": episode_payload["world_id"],
        "seed": config.seed,
        "initial_world_hash": initial_world_hash,
        "initial_replay_state": initial_replay_state,
    }
    write_json(output_dir / "episode.json", episode_payload)
    write_json(output_dir / "world_manifest.json", world_manifest)
    write_jsonl(output_dir / "events.jsonl", events)
    write_jsonl(output_dir / "observations.jsonl", observations)
    write_jsonl(output_dir / "cognitive_ops.jsonl", cognitive_ops)
    write_jsonl(output_dir / "actions.jsonl", actions)
    write_jsonl(output_dir / "budgets.jsonl", budget_rows)
    write_jsonl(output_dir / "profiles.jsonl", profiles)
    write_jsonl(output_dir / "receipts.jsonl", receipts)
    if deceptions:
        write_jsonl(output_dir / "deception.jsonl", deceptions)
    if latent_contexts:
        write_jsonl(output_dir / "latent_context.jsonl", latent_contexts)
    if meta_learning_rows:
        write_jsonl(output_dir / "meta_learning.jsonl", meta_learning_rows)
    if meta_generalization_rows:
        write_jsonl(output_dir / "meta_generalization.jsonl", meta_generalization_rows)
    meta_experience_rows: list[dict[str, Any]] = []
    for agent_id in config.agent_ids:
        experience_method = getattr(agents[agent_id], "meta_experience_log", None)
        if callable(experience_method):
            for row in experience_method():
                meta_experience_rows.append({"agent_id": agent_id, **_serial(row)})
    if meta_experience_rows:
        write_jsonl(output_dir / "meta_experiences.jsonl", meta_experience_rows)
    meta_exploration_rows: list[dict[str, Any]] = []
    for agent_id in config.agent_ids:
        exploration_method = getattr(agents[agent_id], "meta_exploration_log", None)
        if callable(exploration_method):
            for row in exploration_method():
                meta_exploration_rows.append({"agent_id": agent_id, **_serial(row)})
    if meta_exploration_rows:
        write_jsonl(output_dir / "meta_exploration.jsonl", meta_exploration_rows)
    write_json(output_dir / "score.json", scores)

    artifact_names = [
        "episode.json", "world_manifest.json", "events.jsonl", "observations.jsonl",
        "cognitive_ops.jsonl", "actions.jsonl", "budgets.jsonl", "profiles.jsonl",
        "receipts.jsonl", "score.json",
    ]
    if deceptions:
        artifact_names.append("deception.jsonl")
    if latent_contexts:
        artifact_names.append("latent_context.jsonl")
    if meta_learning_rows:
        artifact_names.append("meta_learning.jsonl")
    if meta_generalization_rows:
        artifact_names.append("meta_generalization.jsonl")
    if meta_experience_rows:
        artifact_names.append("meta_experiences.jsonl")
    if meta_exploration_rows:
        artifact_names.append("meta_exploration.jsonl")
    replay_manifest = {
        "episode_id": config.episode_id,
        "world_id": episode_payload["world_id"],
        "seed": config.seed,
        "deterministic_core": True,
        "initial_world_hash": initial_world_hash,
        "artifact_hashes": {name: sha256_file(output_dir / name) for name in artifact_names},
    }
    write_json(output_dir / "replay_manifest.json", replay_manifest)
    return DuelEpisodeResult(config.episode_id, status, scores, output_dir, initial_world_hash, budgets)
