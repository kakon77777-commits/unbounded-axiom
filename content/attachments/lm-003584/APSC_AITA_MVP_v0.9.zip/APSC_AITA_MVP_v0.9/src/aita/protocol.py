from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from apsc.budget import Budget


@dataclass(frozen=True, slots=True)
class ObservationResult:
    observation_id: str
    agent_id: str
    payload: dict[str, Any]
    reliability: float
    cost: Budget
    observer_effect: str = "none"
    source_id: str = "source://unknown"


@dataclass(frozen=True, slots=True)
class EpisodeConfig:
    episode_id: str
    seed: int
    baseline: str
    budget: Budget
    profile_name: str = "balanced"


@dataclass(frozen=True, slots=True)
class DuelEpisodeConfig:
    episode_id: str
    seed: int
    agent_baselines: dict[str, str]
    budgets: dict[str, Budget]
    profile_names: dict[str, str]
    max_cycles: int = 256

    def __post_init__(self) -> None:
        ids = tuple(sorted(self.agent_baselines))
        if len(ids) != 2 or set(ids) != set(self.budgets) or set(ids) != set(self.profile_names):
            raise ValueError("duel config requires exactly two aligned agent ids")

    @property
    def agent_ids(self) -> tuple[str, str]:
        return tuple(sorted(self.agent_baselines))  # type: ignore[return-value]
