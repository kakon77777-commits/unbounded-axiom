from __future__ import annotations

from typing import Any

from apsc.budget import Budget
from apsc.meta_generalization import GeneralizedCognitiveFeatures


def _clip01(value: float) -> float:
    return min(max(float(value), 0.0), 1.0)


def _clip_signed(value: float) -> float:
    return min(max(float(value), -1.0), 1.0)


def _progress(public_state: dict[str, Any]) -> float:
    rounds_total = max(int(public_state.get("rounds_total", 1)), 1)
    round_index = max(int(public_state.get("round_index", 0)), 0)
    if rounds_total <= 1:
        return 0.0
    return _clip01(round_index / float(rounds_total - 1))


def _observation_cost_fraction(budget: Budget, *, unit_cost: int = 1) -> float:
    remaining = max(int(budget.observation_units), 0)
    if remaining <= 0:
        return 1.0
    return _clip01(float(unit_cost) / float(remaining))


def _risk_from_primary_signal(primary_signal: str | None) -> float:
    # Acting on FAST_SAFE exposes the agent to the largest downside if the primary is wrong.
    if primary_signal is None:
        return 0.7
    return 1.0 if str(primary_signal) == "FAST_SAFE" else 0.45


def _conflict(primary_signal: str | None, verifier_signal: str | None) -> bool:
    return primary_signal is not None and verifier_signal is not None and str(primary_signal) != str(verifier_signal)


def project_signal_hazard_features(
    public_state: dict[str, Any],
    budget: Budget,
    *,
    primary_trust: float,
    verifier_trust: float,
    primary_value_prior: float,
    verify_value_prior: float,
    primary_signal: str | None,
    verifier_signal: str | None,
) -> GeneralizedCognitiveFeatures:
    primary_trust = _clip01(primary_trust)
    verifier_trust = _clip01(verifier_trust)
    conflict = _conflict(primary_signal, verifier_signal)
    base_uncertainty = 1.0 - primary_trust
    if conflict:
        base_uncertainty = max(base_uncertainty, 0.75)
    return GeneralizedCognitiveFeatures.from_mapping(
        {
            "uncertainty": _clip01(base_uncertainty),
            "primary_trust": primary_trust,
            "verifier_trust": verifier_trust,
            "primary_value_prior": _clip_signed(primary_value_prior),
            "verify_value_prior": _clip_signed(verify_value_prior),
            "progress_fraction": _progress(public_state),
            "observation_available": budget.observation_units > 0,
            "risk_if_wrong": _risk_from_primary_signal(primary_signal),
            "evidence_conflict": conflict,
            "observation_cost_fraction": _observation_cost_fraction(budget),
        }
    )


def project_latent_context_features(
    public_state: dict[str, Any],
    budget: Budget,
    *,
    belief_entropy: float,
    primary_trust: float,
    verifier_trust: float,
    primary_value_prior: float,
    verify_value_prior: float,
    primary_signal: str | None,
    verifier_signal: str | None,
) -> GeneralizedCognitiveFeatures:
    conflict = _conflict(primary_signal, verifier_signal)
    uncertainty = max(_clip01(belief_entropy), 0.75 if conflict else 0.0)
    return GeneralizedCognitiveFeatures.from_mapping(
        {
            "uncertainty": uncertainty,
            "primary_trust": _clip01(primary_trust),
            "verifier_trust": _clip01(verifier_trust),
            "primary_value_prior": _clip_signed(primary_value_prior),
            "verify_value_prior": _clip_signed(verify_value_prior),
            "progress_fraction": _progress(public_state),
            "observation_available": budget.observation_units > 0,
            "risk_if_wrong": _risk_from_primary_signal(primary_signal),
            "evidence_conflict": conflict,
            "observation_cost_fraction": _observation_cost_fraction(budget),
        }
    )
