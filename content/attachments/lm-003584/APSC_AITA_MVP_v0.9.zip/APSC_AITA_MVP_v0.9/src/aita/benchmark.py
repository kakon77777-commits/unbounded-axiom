from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
from statistics import mean
from typing import Any

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel
from apsc.meta_exploration import MetaTrainingExperience
from apsc.meta_generalization import CrossWorldMetaValueModel, GeneralizedCognitiveExperience
from apsc.meta_exploration_policy import ExplorationPolicyExperience, ExplorationPolicyFeatures, LearnedExplorationPolicyModel
from apsc.replay import write_json, write_jsonl
from aita.agents import B0NeuralDirectAgent, B1FixedDepthAgent, B2FixedSearchVerifyAgent, B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent, B4LMetaLearnedAgent, B4XExplorationMetaAgent, B4GGeneralizingMetaAgent
from aita.protocol import DuelEpisodeConfig, EpisodeConfig
from aita.runner import run_duel_episode, run_episode
from aita.meta_offpolicy import build_counterfactual_experiences
from aita.meta_generalized_offpolicy import (
    build_latent_context_generalized_experiences,
    build_signal_hazard_generalized_experiences,
)
from aita.worlds.hidden_route import HiddenRouteWorld
from aita.worlds.hazard_choice import HazardChoiceWorld
from aita.worlds.hidden_route_duel import HiddenRouteDuelWorld
from aita.worlds.limited_verifier import LimitedVerifierWorld
from aita.worlds.negotiation_split import NegotiationSplitWorld
from aita.worlds.signal_hazard import SignalHazardWorld
from aita.worlds.strategic_signal_duel import StrategicSignalDuelWorld
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


WORLD_FACTORIES = {
    "HiddenRoute-v0.1": HiddenRouteWorld,
    "LimitedVerifier-v0.1": LimitedVerifierWorld,
    "HazardChoice-v0.3": HazardChoiceWorld,
    "SignalHazard-v0.4": SignalHazardWorld,
}
AGENT_FACTORIES = {
    "B0": B0NeuralDirectAgent,
    "B1": B1FixedDepthAgent,
    "B2": B2FixedSearchVerifyAgent,
    "B3": B3APSCFixedCOPAgent,
    "B4": B4APSCAdaptiveCOPAgent,
    "B4L": B4LMetaLearnedAgent,
    "B4X": B4XExplorationMetaAgent,
    "B4G": B4GGeneralizingMetaAgent,
}
COP_PRESETS = {
    "balanced": CognitiveOperatingProfile(),
    "single_turn_accuracy": CognitiveOperatingProfile(depth=0.75, breadth=0.3, verification=0.9, counterfactual=0.25, observation=0.45, risk=0.7, latency=0.6, abstraction=0.45, commitment=0.8, novelty=0.2),
    "exploration": CognitiveOperatingProfile(depth=0.65, breadth=0.9, verification=0.55, counterfactual=0.9, observation=0.8, risk=0.5, latency=0.2, abstraction=0.7, commitment=0.3, novelty=0.9),
    "low_latency": CognitiveOperatingProfile(depth=0.25, breadth=0.2, verification=0.35, counterfactual=0.2, observation=0.2, risk=0.5, latency=0.95, abstraction=0.9, commitment=0.35, novelty=0.1),
    "high_risk_assurance": CognitiveOperatingProfile(depth=0.7, breadth=0.5, verification=0.95, counterfactual=0.7, observation=0.9, risk=0.95, latency=0.35, abstraction=0.5, commitment=0.95, novelty=0.25),
}


@dataclass(frozen=True, slots=True)
class BenchmarkReport:
    rows: list[dict[str, Any]]
    aggregates: dict[str, dict[str, float | int]]
    output_dir: Path


def _budget(payload: dict[str, Any]) -> Budget:
    allowed = {name: int(payload.get(name, 0)) for name in Budget.__dataclass_fields__}
    return Budget(**allowed)


def run_matrix(spec: dict[str, Any], output_dir: Path) -> BenchmarkReport:
    output_dir.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    profile_name = str(spec.get("profile", "balanced"))
    cop = COP_PRESETS.get(profile_name, COP_PRESETS["balanced"])
    for world_id in spec["worlds"]:
        if world_id not in WORLD_FACTORIES:
            raise ValueError(f"unknown world {world_id}")
        for budget_name, budget_payload in spec["budgets"].items():
            initial_budget = _budget(budget_payload)
            for seed in spec["seeds"]:
                for baseline in spec["baselines"]:
                    if baseline not in AGENT_FACTORIES:
                        raise ValueError(f"unknown baseline {baseline}")
                    world = WORLD_FACTORIES[world_id]()
                    agent = AGENT_FACTORIES[baseline]("agent://A")
                    episode_id = f"episode://{world_id}/{baseline}/{budget_name}/{seed}"
                    run_dir = output_dir / world_id / baseline / str(budget_name) / f"seed-{seed}"
                    config = EpisodeConfig(episode_id, int(seed), baseline, initial_budget, profile_name)
                    result = run_episode(world, agent, config, run_dir, cop)
                    row = {
                        "world": world_id,
                        "baseline": baseline,
                        "budget": budget_name,
                        "seed": int(seed),
                        "status": result.status,
                        "initial_world_hash": result.initial_world_hash,
                        "run_dir": str(run_dir.relative_to(output_dir)),
                        **result.score,
                    }
                    rows.append(row)

    aggregates: dict[str, dict[str, float | int]] = {}
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        key = f"{row['world']}|{row['baseline']}|{row['budget']}"
        groups.setdefault(key, []).append(row)
    for key, group in groups.items():
        aggregates[key] = {
            "count": len(group),
            "mean_task_utility": round(mean(float(r["task_utility"]) for r in group), 8),
            "mean_decision_quality": round(mean(float(r["decision_quality"]) for r in group), 8),
            "mean_cognitive_efficiency": round(mean(float(r["cognitive_efficiency"]) for r in group), 8),
        }

    write_jsonl(output_dir / "result_per_seed.jsonl", rows)
    write_json(output_dir / "benchmark_report.json", {"spec": spec, "aggregates": aggregates, "row_count": len(rows)})
    return BenchmarkReport(rows, aggregates, output_dir)


DUEL_WORLD_FACTORIES = {
    "HiddenRouteDuel-v0.2": HiddenRouteDuelWorld,
    "NegotiationSplit-v0.3": NegotiationSplitWorld,
}


@dataclass(frozen=True, slots=True)
class DuelBenchmarkReport:
    rows: list[dict[str, Any]]
    aggregates: dict[str, dict[str, float | int]]
    output_dir: Path


def run_duel_matrix(spec: dict[str, Any], output_dir: Path) -> DuelBenchmarkReport:
    output_dir.mkdir(parents=True, exist_ok=True)
    world_id = str(spec["world"])
    if world_id not in DUEL_WORLD_FACTORIES:
        raise ValueError(f"unknown duel world {world_id}")
    role_swap = bool(spec.get("role_swap", False))
    rows: list[dict[str, Any]] = []

    for matchup_index, matchup in enumerate(spec["matchups"]):
        base_a = str(matchup["a"])
        base_b = str(matchup["b"])
        profile_a = str(matchup.get("profile_a", "balanced"))
        profile_b = str(matchup.get("profile_b", "balanced"))
        if base_a not in AGENT_FACTORIES or base_b not in AGENT_FACTORIES:
            raise ValueError("unknown duel baseline")
        if profile_a not in COP_PRESETS or profile_b not in COP_PRESETS:
            raise ValueError("unknown COP preset")

        orientations = [("normal", base_a, base_b, profile_a, profile_b)]
        if role_swap:
            orientations.append(("swapped", base_b, base_a, profile_b, profile_a))

        for budget_name, budget_payload in spec["budgets"].items():
            budget = _budget(budget_payload)
            for seed in spec["seeds"]:
                for orientation, assigned_a, assigned_b, assigned_profile_a, assigned_profile_b in orientations:
                    world = DUEL_WORLD_FACTORIES[world_id]()
                    agents = {
                        "agent://A": AGENT_FACTORIES[assigned_a]("agent://A"),
                        "agent://B": AGENT_FACTORIES[assigned_b]("agent://B"),
                    }
                    cops = {
                        "agent://A": COP_PRESETS[assigned_profile_a],
                        "agent://B": COP_PRESETS[assigned_profile_b],
                    }
                    episode_id = (
                        f"episode://{world_id}/m{matchup_index}/{orientation}/"
                        f"{assigned_a}-{assigned_b}/{budget_name}/{seed}"
                    )
                    run_dir = (
                        output_dir / world_id / f"matchup-{matchup_index}" / orientation /
                        f"{assigned_a}-{assigned_b}" / str(budget_name) / f"seed-{seed}"
                    )
                    config = DuelEpisodeConfig(
                        episode_id=episode_id,
                        seed=int(seed),
                        agent_baselines={"agent://A": assigned_a, "agent://B": assigned_b},
                        budgets={"agent://A": budget, "agent://B": budget},
                        profile_names={"agent://A": assigned_profile_a, "agent://B": assigned_profile_b},
                    )
                    result = run_duel_episode(world, agents, config, run_dir, cops)
                    row = {
                        "world": world_id,
                        "matchup_index": matchup_index,
                        "role_orientation": orientation,
                        "agent_a_baseline": assigned_a,
                        "agent_b_baseline": assigned_b,
                        "agent_a_profile": assigned_profile_a,
                        "agent_b_profile": assigned_profile_b,
                        "budget": budget_name,
                        "seed": int(seed),
                        "status": result.status,
                        "initial_world_hash": result.initial_world_hash,
                        "run_dir": str(run_dir.relative_to(output_dir)),
                    }
                    row.update({f"a_{key}": value for key, value in result.scores["agent://A"].items()})
                    row.update({f"b_{key}": value for key, value in result.scores["agent://B"].items()})
                    rows.append(row)

    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        key = (
            f"{row['world']}|{row['agent_a_baseline']}:{row['agent_a_profile']}|"
            f"{row['agent_b_baseline']}:{row['agent_b_profile']}|{row['budget']}|{row['role_orientation']}"
        )
        groups.setdefault(key, []).append(row)
    aggregates: dict[str, dict[str, float | int]] = {}
    for key, group in groups.items():
        aggregates[key] = {
            "count": len(group),
            "mean_a_task_utility": round(mean(float(row["a_task_utility"]) for row in group), 8),
            "mean_b_task_utility": round(mean(float(row["b_task_utility"]) for row in group), 8),
            "mean_a_cognitive_efficiency": round(mean(float(row["a_cognitive_efficiency"]) for row in group), 8),
            "mean_b_cognitive_efficiency": round(mean(float(row["b_cognitive_efficiency"]) for row in group), 8),
            "mean_a_duel_outcome": round(mean(float(row["a_duel_outcome"]) for row in group), 8),
            "mean_b_duel_outcome": round(mean(float(row["b_duel_outcome"]) for row in group), 8),
        }

    write_jsonl(output_dir / "duel_result_per_seed.jsonl", rows)
    write_json(output_dir / "duel_benchmark_report.json", {"spec": spec, "aggregates": aggregates, "row_count": len(rows)})
    return DuelBenchmarkReport(rows, aggregates, output_dir)


def run_strategic_signal_matrix(spec: dict[str, Any], output_dir: Path) -> DuelBenchmarkReport:
    """Run role-asymmetric strategic signaler/receiver cross-play.

    Unlike the symmetric duel matrix, the two roles are semantically fixed:
    ``agent://signaler`` owns the signaling policy and ``agent://receiver``
    owns the response/calibration policy.  There is therefore no implicit
    role swap in this matrix.
    """

    output_dir.mkdir(parents=True, exist_ok=True)
    world_id = str(spec["world"])
    if world_id != StrategicSignalDuelWorld.WORLD_ID:
        raise ValueError(f"unknown strategic signal world {world_id}")

    signaler_profile = str(spec.get("signaler_profile", "balanced"))
    receiver_profile = str(spec.get("receiver_profile", "balanced"))
    if signaler_profile not in COP_PRESETS or receiver_profile not in COP_PRESETS:
        raise ValueError("unknown COP preset")

    rows: list[dict[str, Any]] = []
    for signaler_baseline in spec["signaler_baselines"]:
        if signaler_baseline not in AGENT_FACTORIES:
            raise ValueError(f"unknown signaler baseline {signaler_baseline}")
        for receiver_baseline in spec["receiver_baselines"]:
            if receiver_baseline not in AGENT_FACTORIES:
                raise ValueError(f"unknown receiver baseline {receiver_baseline}")
            for budget_name, budget_payload in spec["budgets"].items():
                budget = _budget(budget_payload)
                for seed in spec["seeds"]:
                    world = StrategicSignalDuelWorld()
                    agents = {
                        StrategicSignalDuelWorld.SIGNALER: AGENT_FACTORIES[signaler_baseline](
                            StrategicSignalDuelWorld.SIGNALER
                        ),
                        StrategicSignalDuelWorld.RECEIVER: AGENT_FACTORIES[receiver_baseline](
                            StrategicSignalDuelWorld.RECEIVER
                        ),
                    }
                    cops = {
                        StrategicSignalDuelWorld.SIGNALER: COP_PRESETS[signaler_profile],
                        StrategicSignalDuelWorld.RECEIVER: COP_PRESETS[receiver_profile],
                    }
                    episode_id = (
                        f"episode://{world_id}/"
                        f"{signaler_baseline}-{receiver_baseline}/{budget_name}/{seed}"
                    )
                    run_dir = (
                        output_dir
                        / world_id
                        / f"signaler-{signaler_baseline}"
                        / f"receiver-{receiver_baseline}"
                        / str(budget_name)
                        / f"seed-{seed}"
                    )
                    config = DuelEpisodeConfig(
                        episode_id=episode_id,
                        seed=int(seed),
                        agent_baselines={
                            StrategicSignalDuelWorld.SIGNALER: signaler_baseline,
                            StrategicSignalDuelWorld.RECEIVER: receiver_baseline,
                        },
                        budgets={
                            StrategicSignalDuelWorld.SIGNALER: budget,
                            StrategicSignalDuelWorld.RECEIVER: budget,
                        },
                        profile_names={
                            StrategicSignalDuelWorld.SIGNALER: signaler_profile,
                            StrategicSignalDuelWorld.RECEIVER: receiver_profile,
                        },
                    )
                    result = run_duel_episode(world, agents, config, run_dir, cops)
                    row: dict[str, Any] = {
                        "world": world_id,
                        "signaler_baseline": signaler_baseline,
                        "receiver_baseline": receiver_baseline,
                        "signaler_profile": signaler_profile,
                        "receiver_profile": receiver_profile,
                        "budget": budget_name,
                        "seed": int(seed),
                        "status": result.status,
                        "initial_world_hash": result.initial_world_hash,
                        "run_dir": str(run_dir.relative_to(output_dir)),
                    }
                    row.update(
                        {
                            f"signaler_{key}": value
                            for key, value in result.scores[StrategicSignalDuelWorld.SIGNALER].items()
                        }
                    )
                    row.update(
                        {
                            f"receiver_{key}": value
                            for key, value in result.scores[StrategicSignalDuelWorld.RECEIVER].items()
                        }
                    )
                    rows.append(row)

    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        key = (
            f"{row['world']}|"
            f"{row['signaler_baseline']}:{row['signaler_profile']}|"
            f"{row['receiver_baseline']}:{row['receiver_profile']}|"
            f"{row['budget']}"
        )
        groups.setdefault(key, []).append(row)

    aggregates: dict[str, dict[str, float | int]] = {}
    for key, group in groups.items():
        aggregates[key] = {
            "count": len(group),
            "mean_signaler_task_utility": round(
                mean(float(row["signaler_task_utility"]) for row in group), 8
            ),
            "mean_receiver_task_utility": round(
                mean(float(row["receiver_task_utility"]) for row in group), 8
            ),
            "mean_receiver_cognitive_efficiency": round(
                mean(float(row["receiver_cognitive_efficiency"]) for row in group), 8
            ),
        }

    write_jsonl(output_dir / "strategic_result_per_seed.jsonl", rows)
    write_json(
        output_dir / "strategic_benchmark_report.json",
        {"spec": spec, "aggregates": aggregates, "row_count": len(rows)},
    )
    return DuelBenchmarkReport(rows, aggregates, output_dir)


def run_latent_context_signal_matrix(spec: dict[str, Any], output_dir: Path) -> DuelBenchmarkReport:
    """Run role-asymmetric signaling with the receiver's context hidden."""
    output_dir.mkdir(parents=True, exist_ok=True)
    world_id = str(spec["world"])
    if world_id != LatentContextSignalDuelWorld.WORLD_ID:
        raise ValueError(f"unknown latent context signal world {world_id}")

    signaler_profile = str(spec.get("signaler_profile", "balanced"))
    receiver_profile = str(spec.get("receiver_profile", "balanced"))
    if signaler_profile not in COP_PRESETS or receiver_profile not in COP_PRESETS:
        raise ValueError("unknown COP preset")

    rows: list[dict[str, Any]] = []
    for signaler_baseline in spec["signaler_baselines"]:
        if signaler_baseline not in AGENT_FACTORIES:
            raise ValueError(f"unknown signaler baseline {signaler_baseline}")
        for receiver_baseline in spec["receiver_baselines"]:
            if receiver_baseline not in AGENT_FACTORIES:
                raise ValueError(f"unknown receiver baseline {receiver_baseline}")
            for budget_name, budget_payload in spec["budgets"].items():
                budget = _budget(budget_payload)
                for seed in spec["seeds"]:
                    world = LatentContextSignalDuelWorld()
                    agents = {
                        LatentContextSignalDuelWorld.SIGNALER: AGENT_FACTORIES[signaler_baseline](
                            LatentContextSignalDuelWorld.SIGNALER
                        ),
                        LatentContextSignalDuelWorld.RECEIVER: AGENT_FACTORIES[receiver_baseline](
                            LatentContextSignalDuelWorld.RECEIVER
                        ),
                    }
                    cops = {
                        LatentContextSignalDuelWorld.SIGNALER: COP_PRESETS[signaler_profile],
                        LatentContextSignalDuelWorld.RECEIVER: COP_PRESETS[receiver_profile],
                    }
                    episode_id = (
                        f"episode://{world_id}/"
                        f"{signaler_baseline}-{receiver_baseline}/{budget_name}/{seed}"
                    )
                    run_dir = (
                        output_dir
                        / world_id
                        / f"signaler-{signaler_baseline}"
                        / f"receiver-{receiver_baseline}"
                        / str(budget_name)
                        / f"seed-{seed}"
                    )
                    config = DuelEpisodeConfig(
                        episode_id=episode_id,
                        seed=int(seed),
                        agent_baselines={
                            LatentContextSignalDuelWorld.SIGNALER: signaler_baseline,
                            LatentContextSignalDuelWorld.RECEIVER: receiver_baseline,
                        },
                        budgets={
                            LatentContextSignalDuelWorld.SIGNALER: budget,
                            LatentContextSignalDuelWorld.RECEIVER: budget,
                        },
                        profile_names={
                            LatentContextSignalDuelWorld.SIGNALER: signaler_profile,
                            LatentContextSignalDuelWorld.RECEIVER: receiver_profile,
                        },
                    )
                    result = run_duel_episode(world, agents, config, run_dir, cops)
                    row: dict[str, Any] = {
                        "world": world_id,
                        "signaler_baseline": signaler_baseline,
                        "receiver_baseline": receiver_baseline,
                        "signaler_profile": signaler_profile,
                        "receiver_profile": receiver_profile,
                        "budget": budget_name,
                        "seed": int(seed),
                        "status": result.status,
                        "initial_world_hash": result.initial_world_hash,
                        "run_dir": str(run_dir.relative_to(output_dir)),
                    }
                    row.update({
                        f"signaler_{key}": value
                        for key, value in result.scores[LatentContextSignalDuelWorld.SIGNALER].items()
                    })
                    row.update({
                        f"receiver_{key}": value
                        for key, value in result.scores[LatentContextSignalDuelWorld.RECEIVER].items()
                    })
                    rows.append(row)

    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        key = (
            f"{row['world']}|"
            f"{row['signaler_baseline']}:{row['signaler_profile']}|"
            f"{row['receiver_baseline']}:{row['receiver_profile']}|"
            f"{row['budget']}"
        )
        groups.setdefault(key, []).append(row)

    aggregates: dict[str, dict[str, float | int]] = {}
    for key, group in groups.items():
        aggregates[key] = {
            "count": len(group),
            "mean_signaler_task_utility": round(mean(float(row["signaler_task_utility"]) for row in group), 8),
            "mean_receiver_task_utility": round(mean(float(row["receiver_task_utility"]) for row in group), 8),
            "mean_receiver_cognitive_efficiency": round(
                mean(float(row["receiver_cognitive_efficiency"]) for row in group), 8
            ),
        }

    write_jsonl(output_dir / "latent_result_per_seed.jsonl", rows)
    write_json(
        output_dir / "latent_benchmark_report.json",
        {"spec": spec, "aggregates": aggregates, "row_count": len(rows)},
    )
    return DuelBenchmarkReport(rows, aggregates, output_dir)


def _read_jsonl_rows(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _receiver_cognition_signature(run_dir: Path, receiver_id: str) -> list[tuple[str, bool, bool]]:
    rows = _read_jsonl_rows(run_dir / "cognitive_ops.jsonl")
    return [
        (str(row.get("operator")), bool(row.get("has_query")), bool(row.get("has_action")))
        for row in rows
        if row.get("agent_id") == receiver_id
    ]


def run_meta_learning_experiment(spec: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    """Train B4L on training seeds, freeze the model, then pair it with B4 on held-out seeds."""
    output_dir.mkdir(parents=True, exist_ok=True)
    world_id = str(spec["world"])
    if world_id != LatentContextSignalDuelWorld.WORLD_ID:
        raise ValueError(f"unknown meta-learning world {world_id}")

    train_seeds = [int(seed) for seed in spec["train_seeds"]]
    eval_seeds = [int(seed) for seed in spec["eval_seeds"]]
    if not train_seeds or not eval_seeds:
        raise ValueError("train/eval seeds must be non-empty")
    if set(train_seeds) & set(eval_seeds):
        raise ValueError("train and eval seeds must be disjoint")

    train_signalers = [str(name) for name in spec["train_signaler_baselines"]]
    eval_signalers = [str(name) for name in spec["eval_signaler_baselines"]]
    for baseline in train_signalers + eval_signalers:
        if baseline not in AGENT_FACTORIES or baseline == "B4L":
            raise ValueError(f"invalid signaler baseline {baseline}")

    profile_name = str(spec.get("profile", "balanced"))
    if profile_name not in COP_PRESETS:
        raise ValueError("unknown COP preset")
    cop = COP_PRESETS[profile_name]
    budget = _budget(dict(spec["budget"]))
    observation_penalty = float(spec.get("observation_penalty", 0.15))
    model = ExperienceMetaValueModel(backoff_strength=float(spec.get("backoff_strength", 1.0)))

    training_experiences: list[dict[str, Any]] = []
    training_episode_count = 0
    for signaler_baseline in train_signalers:
        for seed in train_seeds:
            world = LatentContextSignalDuelWorld()
            receiver = B4LMetaLearnedAgent(
                world.RECEIVER,
                model=model,
                training=True,
                observation_penalty=observation_penalty,
            )
            agents = {
                world.SIGNALER: AGENT_FACTORIES[signaler_baseline](world.SIGNALER),
                world.RECEIVER: receiver,
            }
            cops = {world.SIGNALER: cop, world.RECEIVER: cop}
            episode_id = f"episode://meta-train/{signaler_baseline}/{seed}"
            run_dir = output_dir / "train" / f"signaler-{signaler_baseline}" / f"seed-{seed}"
            config = DuelEpisodeConfig(
                episode_id=episode_id,
                seed=seed,
                agent_baselines={world.SIGNALER: signaler_baseline, world.RECEIVER: "B4L"},
                budgets={world.SIGNALER: budget, world.RECEIVER: budget},
                profile_names={world.SIGNALER: profile_name, world.RECEIVER: profile_name},
            )
            run_duel_episode(world, agents, config, run_dir, cops)
            training_episode_count += 1
            training_experiences.extend(_read_jsonl_rows(run_dir / "meta_experiences.jsonl"))

    write_jsonl(output_dir / "training_experiences.jsonl", training_experiences)
    model_path = output_dir / "meta_model.json"
    model.save(model_path)
    model_hash = model.model_hash()
    training_report = {
        "world": world_id,
        "training_episode_count": training_episode_count,
        "experience_count": len(training_experiences),
        "operation_counts": {
            "trust_signal": model.evidence_count("trust_signal"),
            "observe_field": model.evidence_count("observe_field"),
        },
        "train_signaler_baselines": train_signalers,
        "train_seeds": train_seeds,
        "model_hash": model_hash,
    }
    write_json(output_dir / "meta_training_report.json", training_report)

    frozen_model = ExperienceMetaValueModel.load(model_path)
    model_hash_before_eval = frozen_model.model_hash()
    eval_rows: list[dict[str, Any]] = []
    receiver_id = LatentContextSignalDuelWorld.RECEIVER
    signaler_id = LatentContextSignalDuelWorld.SIGNALER

    for signaler_baseline in eval_signalers:
        for seed in eval_seeds:
            pair: dict[str, Any] = {
                "world": world_id,
                "signaler_baseline": signaler_baseline,
                "seed": seed,
                "model_hash": model_hash_before_eval,
            }
            run_dirs: dict[str, Path] = {}
            results: dict[str, Any] = {}
            for receiver_baseline in ("B4", "B4L"):
                world = LatentContextSignalDuelWorld()
                receiver = (
                    B4APSCAdaptiveCOPAgent(receiver_id)
                    if receiver_baseline == "B4"
                    else B4LMetaLearnedAgent(
                        receiver_id,
                        model=frozen_model,
                        training=False,
                        observation_penalty=observation_penalty,
                    )
                )
                agents = {
                    signaler_id: AGENT_FACTORIES[signaler_baseline](signaler_id),
                    receiver_id: receiver,
                }
                cops = {signaler_id: cop, receiver_id: cop}
                episode_id = f"episode://meta-eval/{signaler_baseline}/{receiver_baseline}/{seed}"
                run_dir = output_dir / "eval" / f"signaler-{signaler_baseline}" / f"receiver-{receiver_baseline}" / f"seed-{seed}"
                config = DuelEpisodeConfig(
                    episode_id=episode_id,
                    seed=seed,
                    agent_baselines={signaler_id: signaler_baseline, receiver_id: receiver_baseline},
                    budgets={signaler_id: budget, receiver_id: budget},
                    profile_names={signaler_id: profile_name, receiver_id: profile_name},
                )
                result = run_duel_episode(world, agents, config, run_dir, cops)
                run_dirs[receiver_baseline] = run_dir
                results[receiver_baseline] = result
                score = result.scores[receiver_id]
                prefix = receiver_baseline.lower()
                pair[f"{prefix}_run_dir"] = str(run_dir.relative_to(output_dir))
                pair[f"{prefix}_initial_world_hash"] = result.initial_world_hash
                pair[f"{prefix}_task_utility"] = float(score["task_utility"])
                pair[f"{prefix}_cognitive_efficiency"] = float(score["cognitive_efficiency"])
                pair[f"{prefix}_field_checks"] = float(score.get("field_checks", 0.0))

            pair["trajectory_diverged"] = (
                _receiver_cognition_signature(run_dirs["B4"], receiver_id)
                != _receiver_cognition_signature(run_dirs["B4L"], receiver_id)
            )
            pair["utility_delta_b4l_minus_b4"] = round(pair["b4l_task_utility"] - pair["b4_task_utility"], 8)
            pair["cognitive_efficiency_delta_b4l_minus_b4"] = round(
                pair["b4l_cognitive_efficiency"] - pair["b4_cognitive_efficiency"], 8
            )
            pair["field_check_delta_b4l_minus_b4"] = round(pair["b4l_field_checks"] - pair["b4_field_checks"], 8)
            eval_rows.append(pair)

    model_hash_after_eval = frozen_model.model_hash()
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in eval_rows:
        groups.setdefault(str(row["signaler_baseline"]), []).append(row)
    aggregates: dict[str, dict[str, float | int]] = {}
    for key, group in sorted(groups.items()):
        aggregates[key] = {
            "count": len(group),
            "mean_b4_task_utility": round(mean(float(row["b4_task_utility"]) for row in group), 8),
            "mean_b4l_task_utility": round(mean(float(row["b4l_task_utility"]) for row in group), 8),
            "mean_utility_delta_b4l_minus_b4": round(mean(float(row["utility_delta_b4l_minus_b4"]) for row in group), 8),
            "mean_b4_cognitive_efficiency": round(mean(float(row["b4_cognitive_efficiency"]) for row in group), 8),
            "mean_b4l_cognitive_efficiency": round(mean(float(row["b4l_cognitive_efficiency"]) for row in group), 8),
            "mean_b4_field_checks": round(mean(float(row["b4_field_checks"]) for row in group), 8),
            "mean_b4l_field_checks": round(mean(float(row["b4l_field_checks"]) for row in group), 8),
            "trajectory_divergence_count": sum(1 for row in group if row["trajectory_diverged"]),
        }

    eval_report = {
        "world": world_id,
        "train_seeds": train_seeds,
        "eval_seeds": eval_seeds,
        "eval_signaler_baselines": eval_signalers,
        "row_count": len(eval_rows),
        "model_hash_before_eval": model_hash_before_eval,
        "model_hash_after_eval": model_hash_after_eval,
        "routing_divergence_count": sum(1 for row in eval_rows if row["trajectory_diverged"]),
        "aggregates": aggregates,
    }
    write_jsonl(output_dir / "meta_eval_result_per_seed.jsonl", eval_rows)
    write_json(output_dir / "meta_eval_report.json", eval_report)
    return {
        "training_report": training_report,
        "eval_rows": eval_rows,
        "eval_report": eval_report,
        "model_hash_before_eval": model_hash_before_eval,
        "model_hash_after_eval": model_hash_after_eval,
    }



def _annotate_actual_exploration_experiences(run_dir: Path) -> list[MetaTrainingExperience]:
    exploration_rows = [
        row for row in _read_jsonl_rows(Path(run_dir) / "meta_exploration.jsonl")
        if row.get("agent_id") == LatentContextSignalDuelWorld.RECEIVER
    ]
    by_round = {int(row["round_index"]): row for row in exploration_rows}
    actual_rows = [
        row for row in _read_jsonl_rows(Path(run_dir) / "meta_experiences.jsonl")
        if row.get("agent_id") == LatentContextSignalDuelWorld.RECEIVER
    ]
    result: list[MetaTrainingExperience] = []
    for payload in actual_rows:
        experience = CognitiveExperience.from_dict(payload)
        exploration = by_round.get(experience.round_index, {})
        reason = str(exploration.get("selection_reason", "on_policy"))
        selected = str(exploration.get("selected_operation", experience.operation))
        greedy = str(exploration.get("greedy_operation", selected))
        if reason == "coverage_floor":
            source_kind = "forced_exploration"
        elif reason == "uncertainty_ucb" and selected != greedy:
            source_kind = "uncertainty_exploration"
        else:
            source_kind = "on_policy"
        result.append(
            MetaTrainingExperience(
                experience=experience,
                source_kind=source_kind,
                sample_weight=1.0,
                behavior_operation=experience.operation,
                selection_reason=reason,
            )
        )
    return result


def _operation_counts(rows: list[MetaTrainingExperience]) -> dict[str, int]:
    return {
        operation: sum(1 for row in rows if row.experience.operation == operation)
        for operation in ("trust_signal", "observe_field")
    }


def run_exploration_meta_learning_experiment(spec: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    """Train coverage-aware B4X with counterfactual labels, freeze, and compare against B4."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    world_id = str(spec["world"])
    if world_id != LatentContextSignalDuelWorld.WORLD_ID:
        raise ValueError(f"unknown meta-exploration world {world_id}")

    train_seeds = [int(seed) for seed in spec["train_seeds"]]
    eval_seeds = [int(seed) for seed in spec["eval_seeds"]]
    if not train_seeds or not eval_seeds:
        raise ValueError("train/eval seeds must be non-empty")
    if set(train_seeds) & set(eval_seeds):
        raise ValueError("train and eval seeds must be disjoint")

    train_signalers = [str(name) for name in spec["train_signaler_baselines"]]
    eval_signalers = [str(name) for name in spec["eval_signaler_baselines"]]
    for baseline in train_signalers + eval_signalers:
        if baseline not in AGENT_FACTORIES or baseline in {"B4L", "B4X"}:
            raise ValueError(f"invalid signaler baseline {baseline}")

    profile_name = str(spec.get("profile", "balanced"))
    if profile_name not in COP_PRESETS:
        raise ValueError("unknown COP preset")
    cop = COP_PRESETS[profile_name]
    budget = _budget(dict(spec["budget"]))
    observation_penalty = float(spec.get("observation_penalty", 0.15))
    counterfactual_weight = float(spec.get("counterfactual_weight", 0.5))
    coverage_floor = int(spec.get("coverage_floor", 2))
    train_uncertainty_bonus = float(spec.get("train_uncertainty_bonus", 0.35))
    eval_uncertainty_bonus = float(spec.get("eval_uncertainty_bonus", 0.15))
    model = ExperienceMetaValueModel(backoff_strength=float(spec.get("backoff_strength", 1.0)))

    augmented_rows: list[MetaTrainingExperience] = []
    training_episode_count = 0
    for signaler_baseline in train_signalers:
        for seed in train_seeds:
            world = LatentContextSignalDuelWorld()
            receiver = B4XExplorationMetaAgent(
                world.RECEIVER,
                model=model,
                training=True,
                observation_penalty=observation_penalty,
                coverage_floor=coverage_floor,
                uncertainty_bonus=train_uncertainty_bonus,
            )
            agents = {
                world.SIGNALER: AGENT_FACTORIES[signaler_baseline](world.SIGNALER),
                world.RECEIVER: receiver,
            }
            cops = {world.SIGNALER: cop, world.RECEIVER: cop}
            episode_id = f"episode://meta-explore-train/{signaler_baseline}/{seed}"
            run_dir = output_dir / "train" / f"signaler-{signaler_baseline}" / f"seed-{seed}"
            config = DuelEpisodeConfig(
                episode_id=episode_id,
                seed=seed,
                agent_baselines={world.SIGNALER: signaler_baseline, world.RECEIVER: "B4X"},
                budgets={world.SIGNALER: budget, world.RECEIVER: budget},
                profile_names={world.SIGNALER: profile_name, world.RECEIVER: profile_name},
            )
            run_duel_episode(world, agents, config, run_dir, cops)
            training_episode_count += 1
            actual = _annotate_actual_exploration_experiences(run_dir)
            augmented_rows.extend(actual)
            counterfactual = build_counterfactual_experiences(
                run_dir,
                observation_penalty=observation_penalty,
                sample_weight=counterfactual_weight,
            )
            for row in counterfactual:
                model.update_weighted(row.experience, weight=row.sample_weight)
            augmented_rows.extend(counterfactual)

    write_jsonl(output_dir / "exploration_training_experiences.jsonl", [row.to_dict() for row in augmented_rows])
    actual_rows = [row for row in augmented_rows if row.source_kind != "counterfactual_off_policy"]
    counterfactual_rows = [row for row in augmented_rows if row.source_kind == "counterfactual_off_policy"]
    actual_counts = _operation_counts(actual_rows)
    counterfactual_counts = _operation_counts(counterfactual_rows)
    positive_actual = [count for count in actual_counts.values() if count > 0]
    coverage_ratio = float("inf") if len(positive_actual) != 2 else max(positive_actual) / min(positive_actual)
    source_kind_counts: dict[str, int] = {}
    for row in augmented_rows:
        source_kind_counts[row.source_kind] = source_kind_counts.get(row.source_kind, 0) + 1

    model_path = output_dir / "exploration_meta_model.json"
    model.save(model_path)
    model_hash = model.model_hash()
    training_report = {
        "world": world_id,
        "training_episode_count": training_episode_count,
        "actual_experience_count": len(actual_rows),
        "counterfactual_experience_count": len(counterfactual_rows),
        "actual_operation_counts": actual_counts,
        "counterfactual_operation_counts": counterfactual_counts,
        "source_kind_counts": source_kind_counts,
        "forced_exploration_count": int(source_kind_counts.get("forced_exploration", 0)),
        "actual_coverage_ratio": round(coverage_ratio, 8),
        "weighted_evidence": {
            operation: round(model.evidence_weight(operation), 8)
            for operation in ("trust_signal", "observe_field")
        },
        "train_signaler_baselines": train_signalers,
        "train_seeds": train_seeds,
        "coverage_floor": coverage_floor,
        "train_uncertainty_bonus": train_uncertainty_bonus,
        "counterfactual_weight": counterfactual_weight,
        "model_hash": model_hash,
    }
    write_json(output_dir / "exploration_training_report.json", training_report)

    frozen_model = ExperienceMetaValueModel.load(model_path)
    model_hash_before_eval = frozen_model.model_hash()
    eval_rows: list[dict[str, Any]] = []
    receiver_id = LatentContextSignalDuelWorld.RECEIVER
    signaler_id = LatentContextSignalDuelWorld.SIGNALER

    for signaler_baseline in eval_signalers:
        for seed in eval_seeds:
            pair: dict[str, Any] = {
                "world": world_id,
                "signaler_baseline": signaler_baseline,
                "seed": seed,
                "model_hash": model_hash_before_eval,
            }
            run_dirs: dict[str, Path] = {}
            for receiver_baseline in ("B4", "B4X"):
                world = LatentContextSignalDuelWorld()
                receiver = (
                    B4APSCAdaptiveCOPAgent(receiver_id)
                    if receiver_baseline == "B4"
                    else B4XExplorationMetaAgent(
                        receiver_id,
                        model=frozen_model,
                        training=False,
                        observation_penalty=observation_penalty,
                        coverage_floor=coverage_floor,
                        uncertainty_bonus=eval_uncertainty_bonus,
                    )
                )
                agents = {signaler_id: AGENT_FACTORIES[signaler_baseline](signaler_id), receiver_id: receiver}
                cops = {signaler_id: cop, receiver_id: cop}
                episode_id = f"episode://meta-explore-eval/{signaler_baseline}/{receiver_baseline}/{seed}"
                run_dir = output_dir / "eval" / f"signaler-{signaler_baseline}" / f"receiver-{receiver_baseline}" / f"seed-{seed}"
                config = DuelEpisodeConfig(
                    episode_id=episode_id,
                    seed=seed,
                    agent_baselines={signaler_id: signaler_baseline, receiver_id: receiver_baseline},
                    budgets={signaler_id: budget, receiver_id: budget},
                    profile_names={signaler_id: profile_name, receiver_id: profile_name},
                )
                result = run_duel_episode(world, agents, config, run_dir, cops)
                run_dirs[receiver_baseline] = run_dir
                score = result.scores[receiver_id]
                prefix = receiver_baseline.lower()
                pair[f"{prefix}_run_dir"] = str(run_dir.relative_to(output_dir))
                pair[f"{prefix}_initial_world_hash"] = result.initial_world_hash
                pair[f"{prefix}_task_utility"] = float(score["task_utility"])
                pair[f"{prefix}_cognitive_efficiency"] = float(score["cognitive_efficiency"])
                pair[f"{prefix}_field_checks"] = float(score.get("field_checks", 0.0))

            pair["trajectory_diverged"] = (
                _receiver_cognition_signature(run_dirs["B4"], receiver_id)
                != _receiver_cognition_signature(run_dirs["B4X"], receiver_id)
            )
            pair["utility_delta_b4x_minus_b4"] = round(pair["b4x_task_utility"] - pair["b4_task_utility"], 8)
            pair["cognitive_efficiency_delta_b4x_minus_b4"] = round(
                pair["b4x_cognitive_efficiency"] - pair["b4_cognitive_efficiency"], 8
            )
            pair["field_check_delta_b4x_minus_b4"] = round(pair["b4x_field_checks"] - pair["b4_field_checks"], 8)
            eval_rows.append(pair)

    model_hash_after_eval = frozen_model.model_hash()
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in eval_rows:
        groups.setdefault(str(row["signaler_baseline"]), []).append(row)
    aggregates: dict[str, dict[str, float | int]] = {}
    for key, group in sorted(groups.items()):
        aggregates[key] = {
            "count": len(group),
            "mean_b4_task_utility": round(mean(float(row["b4_task_utility"]) for row in group), 8),
            "mean_b4x_task_utility": round(mean(float(row["b4x_task_utility"]) for row in group), 8),
            "mean_utility_delta_b4x_minus_b4": round(mean(float(row["utility_delta_b4x_minus_b4"]) for row in group), 8),
            "mean_b4_cognitive_efficiency": round(mean(float(row["b4_cognitive_efficiency"]) for row in group), 8),
            "mean_b4x_cognitive_efficiency": round(mean(float(row["b4x_cognitive_efficiency"]) for row in group), 8),
            "mean_b4_field_checks": round(mean(float(row["b4_field_checks"]) for row in group), 8),
            "mean_b4x_field_checks": round(mean(float(row["b4x_field_checks"]) for row in group), 8),
            "trajectory_divergence_count": sum(1 for row in group if row["trajectory_diverged"]),
        }

    eval_report = {
        "world": world_id,
        "train_seeds": train_seeds,
        "eval_seeds": eval_seeds,
        "eval_signaler_baselines": eval_signalers,
        "row_count": len(eval_rows),
        "model_hash_before_eval": model_hash_before_eval,
        "model_hash_after_eval": model_hash_after_eval,
        "eval_uncertainty_bonus": eval_uncertainty_bonus,
        "routing_divergence_count": sum(1 for row in eval_rows if row["trajectory_diverged"]),
        "aggregates": aggregates,
    }
    write_jsonl(output_dir / "exploration_eval_result_per_seed.jsonl", eval_rows)
    write_json(output_dir / "exploration_eval_report.json", eval_report)
    return {
        "training_report": training_report,
        "eval_rows": eval_rows,
        "eval_report": eval_report,
        "model_hash_before_eval": model_hash_before_eval,
        "model_hash_after_eval": model_hash_after_eval,
    }



def _generalized_field_checks(run_dir: Path, agent_id: str | None = None) -> int:
    count = 0
    for row in _read_jsonl_rows(Path(run_dir) / "observations.jsonl"):
        if agent_id is not None and row.get("agent_id") != agent_id:
            continue
        if row.get("source_id") == "sensor://field":
            count += 1
    return count


def _generalized_cognition_signature(run_dir: Path, agent_id: str | None = None) -> list[tuple[str, bool, bool]]:
    rows = _read_jsonl_rows(Path(run_dir) / "cognitive_ops.jsonl")
    result: list[tuple[str, bool, bool]] = []
    for row in rows:
        if agent_id is not None and row.get("agent_id") != agent_id:
            continue
        result.append((str(row.get("operator")), bool(row.get("has_query")), bool(row.get("has_action"))))
    return result


def _train_exploration_policy_from_generalized_pairs(
    rows: list[GeneralizedCognitiveExperience],
    value_model: CrossWorldMetaValueModel,
    *,
    backoff_strength: float,
) -> LearnedExplorationPolicyModel:
    policy = LearnedExplorationPolicyModel(backoff_strength=backoff_strength)
    grouped: dict[tuple[str, int], dict[str, GeneralizedCognitiveExperience]] = {}
    for row in rows:
        grouped.setdefault((row.episode_id, row.round_index), {})[row.operation] = row
    for (episode_id, round_index), pair in sorted(grouped.items()):
        if set(pair) != {"trust_primary", "verify_independent"}:
            continue
        features = pair["trust_primary"].features
        trust_pred = value_model.predict("trust_primary", features, fallback=pair["trust_primary"].realized_value)
        verify_pred = value_model.predict("verify_independent", features, fallback=pair["verify_independent"].realized_value)
        greedy = "verify_independent" if verify_pred.expected_value > trust_pred.expected_value else "trust_primary"
        alternate = "trust_primary" if greedy == "verify_independent" else "verify_independent"
        realized_advantage = pair[alternate].realized_value - pair[greedy].realized_value
        policy_features = ExplorationPolicyFeatures.from_mapping({
            "state_uncertainty": features.uncertainty,
            "value_gap": min(abs(verify_pred.expected_value - trust_pred.expected_value), 1.0),
            "uncertainty_gap": min(abs(verify_pred.combined_uncertainty - trust_pred.combined_uncertainty), 1.0),
            "observation_cost_fraction": features.observation_cost_fraction,
        })
        policy.update(
            ExplorationPolicyExperience(
                experience_id=f"px://cross-world/{episode_id.rsplit('/', 1)[-1]}/{round_index}",
                features=policy_features,
                greedy_operation=greedy,
                alternate_operation=alternate,
                exploration_advantage=realized_advantage,
                target_uncertainty=max(pair["trust_primary"].target_uncertainty, pair["verify_independent"].target_uncertainty),
            )
        )
    return policy


def _fit_cross_world_models(
    *,
    source_world: str,
    target_world: str,
    train_seeds: list[int],
    latent_signalers: list[str],
    output_dir: Path,
    budget: Budget,
    cop: CognitiveOperatingProfile,
    profile_name: str,
    observation_penalty: float,
    counterfactual_weight: float,
    backoff_strength: float,
    latent_behavior_coverage_floor: int,
    latent_behavior_uncertainty_bonus: float,
) -> tuple[CrossWorldMetaValueModel, LearnedExplorationPolicyModel, dict[str, Any], list[GeneralizedCognitiveExperience]]:
    model = CrossWorldMetaValueModel(backoff_strength=backoff_strength)
    experiences: list[GeneralizedCognitiveExperience] = []
    episode_count = 0
    if source_world == SignalHazardWorld.WORLD_ID:
        for seed in train_seeds:
            world = SignalHazardWorld()
            agent = B4APSCAdaptiveCOPAgent(world.AGENT_ID)
            episode_id = f"episode://meta-transfer/train/signal/{seed}"
            run_dir = output_dir / "train" / f"seed-{seed}"
            cfg = EpisodeConfig(episode_id, seed, "B4", budget, profile_name)
            run_episode(world, agent, cfg, run_dir, cop)
            rows = build_signal_hazard_generalized_experiences(run_dir, observation_penalty=observation_penalty)
            experiences.extend(rows)
            episode_count += 1
    elif source_world == LatentContextSignalDuelWorld.WORLD_ID:
        behavior_model = ExperienceMetaValueModel(backoff_strength=backoff_strength)
        for signaler_baseline in latent_signalers:
            if signaler_baseline not in AGENT_FACTORIES or signaler_baseline in {"B4L", "B4X", "B4G"}:
                raise ValueError(f"invalid latent training signaler {signaler_baseline}")
            for seed in train_seeds:
                world = LatentContextSignalDuelWorld()
                receiver = B4XExplorationMetaAgent(
                    world.RECEIVER,
                    model=behavior_model,
                    training=True,
                    observation_penalty=observation_penalty,
                    coverage_floor=latent_behavior_coverage_floor,
                    uncertainty_bonus=latent_behavior_uncertainty_bonus,
                )
                agents = {
                    world.SIGNALER: AGENT_FACTORIES[signaler_baseline](world.SIGNALER),
                    world.RECEIVER: receiver,
                }
                episode_id = f"episode://meta-transfer/train/latent/{signaler_baseline}/{seed}"
                run_dir = output_dir / "train" / f"signaler-{signaler_baseline}" / f"seed-{seed}"
                cfg = DuelEpisodeConfig(
                    episode_id=episode_id,
                    seed=seed,
                    agent_baselines={world.SIGNALER: signaler_baseline, world.RECEIVER: "B4X"},
                    budgets={world.SIGNALER: budget, world.RECEIVER: budget},
                    profile_names={world.SIGNALER: profile_name, world.RECEIVER: profile_name},
                )
                run_duel_episode(world, agents, cfg, run_dir, {world.SIGNALER: cop, world.RECEIVER: cop})
                rows = build_latent_context_generalized_experiences(run_dir, observation_penalty=observation_penalty)
                experiences.extend(rows)
                episode_count += 1
    else:
        raise ValueError(f"unsupported generalized source world {source_world}")

    for row in experiences:
        weight = counterfactual_weight if row.evidence_kind == "counterfactual" else 1.0
        model.update(row, sample_weight=weight)
    policy = _train_exploration_policy_from_generalized_pairs(experiences, model, backoff_strength=backoff_strength)

    write_jsonl(output_dir / "cross_world_training_experiences.jsonl", [row.to_dict() for row in experiences])
    model.save(output_dir / "generalized_meta_model.json")
    policy.save(output_dir / "learned_exploration_policy.json")
    op_counts = {
        op: sum(1 for row in experiences if row.operation == op)
        for op in ("trust_primary", "verify_independent")
    }
    uncertainty_by_op: dict[str, float] = {}
    for op in ("trust_primary", "verify_independent"):
        values = [row.target_uncertainty for row in experiences if row.operation == op]
        uncertainty_by_op[op] = round(mean(values), 8) if values else 0.0
    training_report = {
        "source_world": source_world,
        "target_world": target_world,
        "train_seeds": train_seeds,
        "training_episode_count": episode_count,
        "experience_count": len(experiences),
        "operation_counts": op_counts,
        "mean_target_uncertainty": uncertainty_by_op,
        "weighted_evidence": {
            op: round(model.evidence_weight(op), 8)
            for op in ("trust_primary", "verify_independent")
        },
        "value_model_hash": model.model_hash(),
        "exploration_policy_hash": policy.model_hash(),
    }
    write_json(output_dir / "cross_world_training_report.json", training_report)
    return model, policy, training_report, experiences


def _run_cross_world_target_eval(
    *,
    target_world: str,
    eval_seeds: list[int],
    eval_signalers: list[str],
    output_dir: Path,
    budget: Budget,
    cop: CognitiveOperatingProfile,
    profile_name: str,
    value_model: CrossWorldMetaValueModel,
    exploration_policy: LearnedExplorationPolicyModel,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    model_hash_before = value_model.model_hash()
    policy_hash_before = exploration_policy.model_hash()
    rows: list[dict[str, Any]] = []

    eval_cases: list[tuple[str | None, int]] = []
    if target_world == SignalHazardWorld.WORLD_ID:
        eval_cases = [(None, seed) for seed in eval_seeds]
    elif target_world == LatentContextSignalDuelWorld.WORLD_ID:
        for baseline in eval_signalers:
            if baseline not in AGENT_FACTORIES or baseline in {"B4L", "B4X", "B4G"}:
                raise ValueError(f"invalid latent eval signaler {baseline}")
            eval_cases.extend((baseline, seed) for seed in eval_seeds)
    else:
        raise ValueError(f"unsupported generalized target world {target_world}")

    for signaler_baseline, seed in eval_cases:
        pair: dict[str, Any] = {
            "target_world": target_world,
            "seed": seed,
            "signaler_baseline": signaler_baseline,
            "value_model_hash": model_hash_before,
            "exploration_policy_hash": policy_hash_before,
        }
        signatures: dict[str, list[tuple[str, bool, bool]]] = {}
        for receiver_baseline in ("B4", "B4G0", "B4G"):
            if target_world == SignalHazardWorld.WORLD_ID:
                world = SignalHazardWorld()
                if receiver_baseline == "B4":
                    agent = B4APSCAdaptiveCOPAgent(world.AGENT_ID)
                elif receiver_baseline == "B4G0":
                    agent = B4GGeneralizingMetaAgent(world.AGENT_ID)
                else:
                    agent = B4GGeneralizingMetaAgent(
                        world.AGENT_ID,
                        value_model=value_model,
                        exploration_policy=exploration_policy,
                    )
                run_dir = output_dir / "eval" / f"receiver-{receiver_baseline}" / f"seed-{seed}"
                cfg = EpisodeConfig(
                    f"episode://meta-transfer/eval/signal/{receiver_baseline}/{seed}",
                    seed,
                    receiver_baseline,
                    budget,
                    profile_name,
                )
                result = run_episode(world, agent, cfg, run_dir, cop)
                score = result.score
                initial_hash = result.initial_world_hash
                agent_id = None
            else:
                assert signaler_baseline is not None
                world = LatentContextSignalDuelWorld()
                if receiver_baseline == "B4":
                    receiver = B4APSCAdaptiveCOPAgent(world.RECEIVER)
                elif receiver_baseline == "B4G0":
                    receiver = B4GGeneralizingMetaAgent(world.RECEIVER)
                else:
                    receiver = B4GGeneralizingMetaAgent(
                        world.RECEIVER,
                        value_model=value_model,
                        exploration_policy=exploration_policy,
                    )
                agents = {
                    world.SIGNALER: AGENT_FACTORIES[signaler_baseline](world.SIGNALER),
                    world.RECEIVER: receiver,
                }
                run_dir = output_dir / "eval" / f"signaler-{signaler_baseline}" / f"receiver-{receiver_baseline}" / f"seed-{seed}"
                cfg = DuelEpisodeConfig(
                    episode_id=f"episode://meta-transfer/eval/latent/{signaler_baseline}/{receiver_baseline}/{seed}",
                    seed=seed,
                    agent_baselines={world.SIGNALER: signaler_baseline, world.RECEIVER: receiver_baseline},
                    budgets={world.SIGNALER: budget, world.RECEIVER: budget},
                    profile_names={world.SIGNALER: profile_name, world.RECEIVER: profile_name},
                )
                result = run_duel_episode(world, agents, cfg, run_dir, {world.SIGNALER: cop, world.RECEIVER: cop})
                score = result.scores[world.RECEIVER]
                initial_hash = result.initial_world_hash
                agent_id = world.RECEIVER

            prefix = receiver_baseline.lower()
            pair[f"{prefix}_run_dir"] = str(run_dir.relative_to(output_dir))
            pair[f"{prefix}_initial_world_hash"] = initial_hash
            pair[f"{prefix}_task_utility"] = float(score["task_utility"])
            pair[f"{prefix}_cognitive_efficiency"] = float(score["cognitive_efficiency"])
            pair[f"{prefix}_field_checks"] = float(_generalized_field_checks(run_dir, agent_id))
            signatures[receiver_baseline] = _generalized_cognition_signature(run_dir, agent_id)

        pair["trajectory_diverged_b4g_vs_b4"] = signatures["B4G"] != signatures["B4"]
        pair["trajectory_diverged_b4g_vs_b4g0"] = signatures["B4G"] != signatures["B4G0"]
        pair["transfer_utility_delta_b4g_minus_b4g0"] = round(pair["b4g_task_utility"] - pair["b4g0_task_utility"], 8)
        pair["utility_delta_b4g_minus_b4"] = round(pair["b4g_task_utility"] - pair["b4_task_utility"], 8)
        pair["cognitive_efficiency_delta_b4g_minus_b4"] = round(
            pair["b4g_cognitive_efficiency"] - pair["b4_cognitive_efficiency"], 8
        )
        pair["field_check_delta_b4g_minus_b4"] = round(pair["b4g_field_checks"] - pair["b4_field_checks"], 8)
        rows.append(pair)

    model_hash_after = value_model.model_hash()
    policy_hash_after = exploration_policy.model_hash()
    eval_report = {
        "target_world": target_world,
        "eval_seeds": eval_seeds,
        "eval_signaler_baselines": eval_signalers if target_world == LatentContextSignalDuelWorld.WORLD_ID else [],
        "row_count": len(rows),
        "value_model_hash_before_eval": model_hash_before,
        "value_model_hash_after_eval": model_hash_after,
        "exploration_policy_hash_before_eval": policy_hash_before,
        "exploration_policy_hash_after_eval": policy_hash_after,
        "mean_b4_task_utility": round(mean(float(r["b4_task_utility"]) for r in rows), 8),
        "mean_b4g0_task_utility": round(mean(float(r["b4g0_task_utility"]) for r in rows), 8),
        "mean_b4g_task_utility": round(mean(float(r["b4g_task_utility"]) for r in rows), 8),
        "mean_transfer_utility_delta_b4g_minus_b4g0": round(mean(float(r["transfer_utility_delta_b4g_minus_b4g0"]) for r in rows), 8),
        "negative_transfer_count": sum(1 for r in rows if float(r["transfer_utility_delta_b4g_minus_b4g0"]) < 0.0),
        "trajectory_divergence_count_b4g_vs_b4": sum(1 for r in rows if r["trajectory_diverged_b4g_vs_b4"]),
        "mean_b4_field_checks": round(mean(float(r["b4_field_checks"]) for r in rows), 8),
        "mean_b4g_field_checks": round(mean(float(r["b4g_field_checks"]) for r in rows), 8),
    }
    write_jsonl(output_dir / "cross_world_eval_result_per_seed.jsonl", rows)
    write_json(output_dir / "cross_world_eval_report.json", eval_report)
    return rows, eval_report


def run_cross_world_meta_generalization_experiment(spec: dict[str, Any], output_dir: Path) -> dict[str, Any]:
    """Train generalized cognition models in one world and evaluate frozen transfer in another."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    signal_train_seeds = [int(x) for x in spec["signal_train_seeds"]]
    signal_eval_seeds = [int(x) for x in spec["signal_eval_seeds"]]
    latent_train_seeds = [int(x) for x in spec["latent_train_seeds"]]
    latent_eval_seeds = [int(x) for x in spec["latent_eval_seeds"]]
    if not signal_train_seeds or not signal_eval_seeds or not latent_train_seeds or not latent_eval_seeds:
        raise ValueError("all train/eval seed sets must be non-empty")
    if set(signal_train_seeds) & set(signal_eval_seeds):
        raise ValueError("signal train/eval seeds must be disjoint")
    if set(latent_train_seeds) & set(latent_eval_seeds):
        raise ValueError("latent train/eval seeds must be disjoint")

    profile_name = str(spec.get("profile", "balanced"))
    if profile_name not in COP_PRESETS:
        raise ValueError("unknown COP preset")
    cop = COP_PRESETS[profile_name]
    budget = _budget(dict(spec["budget"]))
    observation_penalty = float(spec.get("observation_penalty", 0.15))
    counterfactual_weight = float(spec.get("counterfactual_weight", 0.5))
    backoff_strength = float(spec.get("backoff_strength", 1.0))
    latent_train_signalers = [str(x) for x in spec.get("latent_train_signaler_baselines", ["B2"])]
    latent_eval_signalers = [str(x) for x in spec.get("latent_eval_signaler_baselines", ["B2"])]
    coverage_floor = int(spec.get("latent_behavior_coverage_floor", 2))
    uncertainty_bonus = float(spec.get("latent_behavior_uncertainty_bonus", 0.35))

    directions_spec = [
        (
            "signal_to_latent",
            SignalHazardWorld.WORLD_ID,
            LatentContextSignalDuelWorld.WORLD_ID,
            signal_train_seeds,
            latent_eval_seeds,
            [],
            latent_eval_signalers,
        ),
        (
            "latent_to_signal",
            LatentContextSignalDuelWorld.WORLD_ID,
            SignalHazardWorld.WORLD_ID,
            latent_train_seeds,
            signal_eval_seeds,
            latent_train_signalers,
            [],
        ),
    ]
    direction_results: dict[str, Any] = {}
    root_summary: dict[str, Any] = {
        "spec": spec,
        "directions": {},
    }
    for name, source_world, target_world, train_seeds, eval_seeds, train_signalers, eval_signalers in directions_spec:
        direction_dir = output_dir / name
        model, policy, training_report, _ = _fit_cross_world_models(
            source_world=source_world,
            target_world=target_world,
            train_seeds=train_seeds,
            latent_signalers=train_signalers,
            output_dir=direction_dir,
            budget=budget,
            cop=cop,
            profile_name=profile_name,
            observation_penalty=observation_penalty,
            counterfactual_weight=counterfactual_weight,
            backoff_strength=backoff_strength,
            latent_behavior_coverage_floor=coverage_floor,
            latent_behavior_uncertainty_bonus=uncertainty_bonus,
        )
        frozen_model = CrossWorldMetaValueModel.load(direction_dir / "generalized_meta_model.json")
        frozen_policy = LearnedExplorationPolicyModel.load(direction_dir / "learned_exploration_policy.json")
        eval_rows, eval_report = _run_cross_world_target_eval(
            target_world=target_world,
            eval_seeds=eval_seeds,
            eval_signalers=eval_signalers,
            output_dir=direction_dir,
            budget=budget,
            cop=cop,
            profile_name=profile_name,
            value_model=frozen_model,
            exploration_policy=frozen_policy,
        )
        direction_results[name] = {
            "training_report": training_report,
            "eval_rows": eval_rows,
            "eval_report": eval_report,
        }
        root_summary["directions"][name] = {
            "source_world": source_world,
            "target_world": target_world,
            "training_episode_count": training_report["training_episode_count"],
            "eval_row_count": len(eval_rows),
            "value_model_hash": eval_report["value_model_hash_before_eval"],
            "exploration_policy_hash": eval_report["exploration_policy_hash_before_eval"],
            "mean_transfer_utility_delta_b4g_minus_b4g0": eval_report["mean_transfer_utility_delta_b4g_minus_b4g0"],
            "negative_transfer_count": eval_report["negative_transfer_count"],
        }
    write_json(output_dir / "cross_world_report.json", root_summary)
    return {"directions": direction_results, "summary": root_summary}
