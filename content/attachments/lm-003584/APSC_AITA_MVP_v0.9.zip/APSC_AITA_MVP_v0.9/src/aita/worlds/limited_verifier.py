from __future__ import annotations

import random
from typing import Any

from apsc.budget import Budget
from aita.protocol import ObservationResult


class LimitedVerifierWorld:
    WORLD_ID = "LimitedVerifier-v0.1"
    def __init__(self, *, verifier_limit: int = 2, candidate_count: int = 4) -> None:
        if verifier_limit < 0 or candidate_count < 2:
            raise ValueError("invalid verifier world parameters")
        self.verifier_limit = verifier_limit
        self.candidate_count = candidate_count
        self.seed = 0
        self.candidates: list[str] = []
        self.correct_candidate = ""
        self.verifier_remaining = verifier_limit
        self.verifications_used = 0
        self.committed_candidate: str | None = None
        self.tick = 0
        self._observation_counter = 0

    def reset(self, seed: int) -> dict[str, Any]:
        self.seed = seed
        rng = random.Random(seed)
        base = list(range(100, 100 + self.candidate_count * 7, 7))[: self.candidate_count]
        rng.shuffle(base)
        self.candidates = [f"candidate-{value}" for value in base]
        self.correct_candidate = rng.choice(self.candidates)
        self.verifier_remaining = self.verifier_limit
        self.verifications_used = 0
        self.committed_candidate = None
        self.tick = 0
        self._observation_counter = 0
        return self.get_public_state()

    def get_public_state(self) -> dict[str, Any]:
        return {
            "candidates": list(self.candidates),
            "verifier_remaining": self.verifier_remaining,
            "verifications_used": self.verifications_used,
            "committed": self.committed_candidate is not None,
            "tick": self.tick,
        }

    def observe(self, agent_id: str, query: dict[str, Any]) -> ObservationResult:
        if query.get("type") != "verify":
            raise ValueError("LimitedVerifier-v0.1 only supports verify observations")
        if self.verifier_remaining <= 0:
            raise ValueError("verifier quota exhausted")
        candidate = str(query.get("candidate", ""))
        if candidate not in self.candidates:
            raise ValueError("unknown candidate")
        self.verifier_remaining -= 1
        self.verifications_used += 1
        self._observation_counter += 1
        return ObservationResult(
            observation_id=f"obs://limited-verifier/{self.seed}/{self._observation_counter}",
            agent_id=agent_id,
            payload={"candidate": candidate, "verified": candidate == self.correct_candidate},
            reliability=1.0,
            cost=Budget(observation_units=1),
        )

    def legal_actions(self, agent_id: str) -> list[dict[str, Any]]:
        del agent_id
        return [{"type": "commit", "candidate": candidate} for candidate in self.candidates]

    def step(self, action_bundle: dict[str, dict[str, Any]]) -> dict[str, Any]:
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if len(action_bundle) != 1:
            raise ValueError("LimitedVerifier-v0.1 is single-agent")
        action = next(iter(action_bundle.values()))
        if action.get("type") != "commit":
            raise ValueError("illegal action type")
        candidate = str(action.get("candidate", ""))
        if candidate not in self.candidates:
            raise ValueError("unknown candidate")
        self.committed_candidate = candidate
        self.tick += 1
        return self.get_public_state()

    def is_terminal(self) -> bool:
        return self.committed_candidate is not None

    def score_state(self) -> dict[str, Any]:
        correct = self.committed_candidate == self.correct_candidate if self.committed_candidate is not None else False
        utility = (1.0 if correct else 0.0) - 0.03 * self.verifications_used
        return {
            "correct": correct,
            "utility": round(max(utility, 0.0), 6),
            "verifications_used": self.verifications_used,
            "committed_candidate": self.committed_candidate,
        }

    def export_replay_state(self) -> dict[str, Any]:
        return {
            **self.get_public_state(),
            "seed": self.seed,
            "correct_candidate": self.correct_candidate,
        }
