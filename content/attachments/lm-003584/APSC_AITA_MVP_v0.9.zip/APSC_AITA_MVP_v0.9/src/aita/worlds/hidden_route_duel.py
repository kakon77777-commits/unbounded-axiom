from __future__ import annotations

import random
from typing import Any

from apsc.budget import Budget
from aita.protocol import ObservationResult


class HiddenRouteDuelWorld:
    WORLD_ID = "HiddenRouteDuel-v0.2"
    AGENTS = ("agent://A", "agent://B")
    BASE_GRAPH: dict[str, tuple[str, ...]] = {
        "S": ("A", "B"),
        "A": ("C",),
        "B": ("C", "G"),
        "C": ("G",),
        "G": (),
    }

    def __init__(self, *, deadline: int = 7, shift_tick: int = 2) -> None:
        self.deadline = deadline
        self.shift_tick = shift_tick
        self.seed = 0
        self.tick = 0
        self.rule_version = 1
        self.shifted = False
        self.positions = {agent: "S" for agent in self.AGENTS}
        self.hazards: set[str] = set()
        self.hazard_hits = {agent: 0 for agent in self.AGENTS}
        self.travel_cost = {agent: 0 for agent in self.AGENTS}
        self.collision_blocks = {agent: 0 for agent in self.AGENTS}
        self.claims: dict[str, str] = {}
        self._observation_counter = 0

    def _graph(self) -> dict[str, tuple[str, ...]]:
        if not self.shifted:
            return self.BASE_GRAPH
        return {
            "S": ("A", "B"),
            "A": ("C", "G"),
            "B": ("C",),
            "C": ("G",),
            "G": (),
        }

    def reset(self, seed: int) -> dict[str, dict[str, Any]]:
        self.seed = seed
        rng = random.Random(seed)
        candidates = ["A", "B", "C"]
        self.hazards = {rng.choice(candidates)}
        if rng.random() < 0.35:
            extra = rng.choice([node for node in candidates if node not in self.hazards])
            self.hazards.add(extra)
        self.tick = 0
        self.rule_version = 1
        self.shifted = False
        self.positions = {agent: "S" for agent in self.AGENTS}
        self.hazard_hits = {agent: 0 for agent in self.AGENTS}
        self.travel_cost = {agent: 0 for agent in self.AGENTS}
        self.collision_blocks = {agent: 0 for agent in self.AGENTS}
        self.claims = {}
        self._observation_counter = 0
        return {agent: self.get_public_state(agent) for agent in self.AGENTS}

    def get_public_state(self, agent_id: str) -> dict[str, Any]:
        if agent_id not in self.AGENTS:
            raise ValueError("unknown agent")
        opponent = self.AGENTS[1] if agent_id == self.AGENTS[0] else self.AGENTS[0]
        graph = self._graph()
        location = self.positions[agent_id]
        return {
            "location": location,
            "opponent_location": self.positions[opponent],
            "tick": self.tick,
            "deadline": self.deadline,
            "goal": "G",
            "neighbors": list(graph[location]),
            "topology": {node: list(neighbors) for node, neighbors in graph.items()},
            "known_safe": ["S", "G"],
            "hazard_hits": self.hazard_hits[agent_id],
            "travel_cost": self.travel_cost[agent_id],
            "collision_blocks": self.collision_blocks[agent_id],
            "claims": sorted(node for node, owner in self.claims.items() if owner == agent_id),
            "opponent_claims": sorted(node for node, owner in self.claims.items() if owner == opponent),
            "rule_version": self.rule_version,
            "shifted": self.shifted,
            "shift_tick": self.shift_tick,
        }

    def observe(self, agent_id: str, query: dict[str, Any]) -> ObservationResult:
        if agent_id not in self.AGENTS:
            raise ValueError("unknown agent")
        if query.get("type") != "probe":
            raise ValueError("HiddenRouteDuel-v0.2 only supports probe observations")
        target = str(query.get("target", ""))
        if target not in self._graph():
            raise ValueError("unknown probe target")
        self._observation_counter += 1
        return ObservationResult(
            observation_id=f"obs://hidden-route-duel/{self.seed}/{agent_id.rsplit('/', 1)[-1]}/{self._observation_counter}",
            agent_id=agent_id,
            payload={"target": target, "hazard": target in self.hazards},
            reliability=1.0,
            cost=Budget(observation_units=1),
        )

    def legal_actions(self, agent_id: str) -> list[dict[str, Any]]:
        graph = self._graph()
        location = self.positions[agent_id]
        actions = [{"type": "move", "target": target} for target in graph[location]]
        actions.append({"type": "wait"})
        return actions

    def _validate_action(self, agent_id: str, action: dict[str, Any]) -> None:
        action_type = action.get("type")
        if action_type == "wait":
            return
        if action_type != "move":
            raise ValueError("illegal action type")
        target = str(action.get("target", ""))
        if target not in self._graph()[self.positions[agent_id]]:
            raise ValueError("illegal move")

    def _apply_move(self, agent_id: str, target: str) -> None:
        self.positions[agent_id] = target
        self.travel_cost[agent_id] += 1
        if target in self.hazards:
            self.hazard_hits[agent_id] += 1
        if target in {"A", "B", "C"} and target not in self.claims:
            self.claims[target] = agent_id

    def _maybe_shift_rules(self) -> None:
        if not self.shifted and self.tick >= self.shift_tick:
            self.shifted = True
            self.rule_version = 2

    def step(self, action_bundle: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if set(action_bundle) != set(self.AGENTS):
            raise ValueError("duel step requires exactly both agents")
        for agent_id, action in action_bundle.items():
            self._validate_action(agent_id, action)

        move_targets = {
            agent_id: str(action["target"])
            for agent_id, action in action_bundle.items()
            if action.get("type") == "move"
        }
        blocked: set[str] = set()
        if len(move_targets) == 2 and len(set(move_targets.values())) == 1:
            winner = self.AGENTS[(self.seed + self.tick) % len(self.AGENTS)]
            loser = self.AGENTS[1] if winner == self.AGENTS[0] else self.AGENTS[0]
            blocked.add(loser)
            self.collision_blocks[loser] += 1

        for agent_id in self.AGENTS:
            action = action_bundle[agent_id]
            if action.get("type") == "move" and agent_id not in blocked:
                self._apply_move(agent_id, str(action["target"]))

        self.tick += 1
        self._maybe_shift_rules()
        return {agent: self.get_public_state(agent) for agent in self.AGENTS}

    def is_terminal(self) -> bool:
        return any(location == "G" for location in self.positions.values()) or self.tick >= self.deadline

    def score_state(self) -> dict[str, dict[str, Any]]:
        winner = next((agent for agent in self.AGENTS if self.positions[agent] == "G"), None)
        scores: dict[str, dict[str, Any]] = {}
        for agent in self.AGENTS:
            reached_goal = self.positions[agent] == "G"
            claim_count = sum(1 for owner in self.claims.values() if owner == agent)
            utility = (
                (1.0 if reached_goal else 0.0)
                + 0.1 * claim_count
                - 0.2 * self.hazard_hits[agent]
                - 0.02 * self.travel_cost[agent]
                - 0.03 * self.collision_blocks[agent]
            )
            scores[agent] = {
                "reached_goal": reached_goal,
                "winner": winner == agent,
                "utility": round(utility, 6),
                "hazard_hits": self.hazard_hits[agent],
                "travel_cost": self.travel_cost[agent],
                "collision_blocks": self.collision_blocks[agent],
                "claim_count": claim_count,
                "ticks": self.tick,
            }
        return scores

    def export_replay_state(self) -> dict[str, Any]:
        return {
            "world_id": self.WORLD_ID,
            "seed": self.seed,
            "tick": self.tick,
            "deadline": self.deadline,
            "positions": dict(self.positions),
            "hazards": sorted(self.hazards),
            "hazard_hits": dict(self.hazard_hits),
            "travel_cost": dict(self.travel_cost),
            "collision_blocks": dict(self.collision_blocks),
            "claims": dict(sorted(self.claims.items())),
            "rule_version": self.rule_version,
            "shifted": self.shifted,
            "shift_tick": self.shift_tick,
            "topology": {node: list(neighbors) for node, neighbors in self._graph().items()},
        }
