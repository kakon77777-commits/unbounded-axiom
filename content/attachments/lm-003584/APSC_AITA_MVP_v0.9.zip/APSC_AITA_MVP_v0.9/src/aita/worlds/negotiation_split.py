from __future__ import annotations

import random
from typing import Any


class NegotiationSplitWorld:
    WORLD_ID = "NegotiationSplit-v0.3"
    AGENTS = ("agent://A", "agent://B")
    SURPLUS = 10

    def __init__(self, *, deadline: int = 5, shift_tick: int = 2) -> None:
        self.deadline = deadline
        self.shift_tick = shift_tick
        self.seed = 0
        self.tick = 0
        self.rule_version = 1
        self.shifted = False
        self.preferences: dict[str, dict[str, float | int]] = {}
        self.disagreement_payoffs = {agent: 1.0 for agent in self.AGENTS}
        self.outstanding_offer: dict[str, Any] | None = None
        self.agreement: dict[str, int] | None = None
        self.rejected_offers = 0

    def _opponent(self, agent_id: str) -> str:
        if agent_id not in self.AGENTS:
            raise ValueError("unknown agent")
        return self.AGENTS[1] if agent_id == self.AGENTS[0] else self.AGENTS[0]

    def reset(self, seed: int) -> dict[str, dict[str, Any]]:
        self.seed = seed
        rng = random.Random(seed)
        self.tick = 0
        self.rule_version = 1
        self.shifted = False
        self.outstanding_offer = None
        self.agreement = None
        self.rejected_offers = 0
        self.preferences = {}
        for agent in self.AGENTS:
            minimum = rng.randint(3, 6)
            concession_cost = round(rng.uniform(0.1, 0.4), 3)
            ideal_share = min(self.SURPLUS, minimum + 2)
            self.preferences[agent] = {
                "minimum": minimum,
                "concession_cost": concession_cost,
                "ideal_share": ideal_share,
            }
        self.disagreement_payoffs = {agent: 1.0 for agent in self.AGENTS}
        return {agent: self.get_public_state(agent) for agent in self.AGENTS}

    def get_public_state(self, agent_id: str) -> dict[str, Any]:
        self._opponent(agent_id)
        pref = self.preferences[agent_id]
        return {
            "world_kind": "negotiation_split",
            "tick": self.tick,
            "deadline": self.deadline,
            "surplus": self.SURPLUS,
            "own_minimum": int(pref["minimum"]),
            "own_concession_cost": float(pref["concession_cost"]),
            "own_ideal_share": int(pref["ideal_share"]),
            "outstanding_offer": None if self.outstanding_offer is None else dict(self.outstanding_offer),
            "agreement": None if self.agreement is None else dict(self.agreement),
            "rule_version": self.rule_version,
            "shifted": self.shifted,
            "shift_tick": self.shift_tick,
            "disagreement_payoff": self.disagreement_payoffs[agent_id],
        }

    def observe(self, agent_id: str, query: dict[str, Any]):
        del agent_id, query
        raise ValueError("NegotiationSplit-v0.3 has no explicit observation query in v0.3")

    def legal_actions(self, agent_id: str) -> list[dict[str, Any]]:
        self._opponent(agent_id)
        if self.is_terminal():
            return []
        actions: list[dict[str, Any]] = [{"type": "wait"}]
        actions.extend({"type": "offer", "self_share": share} for share in range(self.SURPLUS + 1))
        if self.outstanding_offer is not None and self.outstanding_offer["receiver"] == agent_id:
            actions.extend(({"type": "accept"}, {"type": "reject"}))
        return actions

    def _validate_action(self, agent_id: str, action: dict[str, Any]) -> None:
        if action not in self.legal_actions(agent_id):
            raise ValueError("illegal negotiation action")

    def _resolve_existing_offer(self, action_bundle: dict[str, dict[str, Any]]) -> bool:
        if self.outstanding_offer is None:
            return False
        receiver = str(self.outstanding_offer["receiver"])
        action = action_bundle[receiver]
        if action.get("type") == "accept":
            proposer = str(self.outstanding_offer["proposer"])
            self.agreement = {
                proposer: int(self.outstanding_offer["proposer_share"]),
                receiver: int(self.outstanding_offer["receiver_share"]),
            }
            self.outstanding_offer = None
            return True
        if action.get("type") == "reject":
            self.rejected_offers += 1
            self.outstanding_offer = None
        return False

    def _select_new_offer(self, action_bundle: dict[str, dict[str, Any]]) -> None:
        offers = [agent for agent in self.AGENTS if action_bundle[agent].get("type") == "offer"]
        if not offers:
            return
        proposer = offers[0] if len(offers) == 1 else self.AGENTS[(self.seed + self.tick) % 2]
        if proposer not in offers:
            proposer = offers[0]
        receiver = self._opponent(proposer)
        proposer_share = int(action_bundle[proposer]["self_share"])
        self.outstanding_offer = {
            "proposer": proposer,
            "receiver": receiver,
            "proposer_share": proposer_share,
            "receiver_share": self.SURPLUS - proposer_share,
            "tick": self.tick,
        }

    def _maybe_shift_rules(self) -> None:
        if not self.shifted and self.tick >= self.shift_tick:
            self.shifted = True
            self.rule_version = 2
            self.disagreement_payoffs = {agent: 2.0 for agent in self.AGENTS}

    def step(self, action_bundle: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if set(action_bundle) != set(self.AGENTS):
            raise ValueError("negotiation step requires exactly both agents")
        for agent_id, action in action_bundle.items():
            self._validate_action(agent_id, action)

        accepted = self._resolve_existing_offer(action_bundle)
        if not accepted:
            self._select_new_offer(action_bundle)
        self.tick += 1
        self._maybe_shift_rules()
        return {agent: self.get_public_state(agent) for agent in self.AGENTS}

    def is_terminal(self) -> bool:
        return self.agreement is not None or self.tick >= self.deadline

    def _concession_cost(self, agent_id: str, share: int) -> float:
        pref = self.preferences[agent_id]
        concession = max(0, int(pref["ideal_share"]) - share)
        return round(float(pref["concession_cost"]) * concession, 6)

    def _agreement_utility(self, agent_id: str, share: int) -> float:
        return round(share - self._concession_cost(agent_id, share), 6)

    def _split_utilities(self, a_share: int) -> dict[str, float]:
        shares = {self.AGENTS[0]: a_share, self.AGENTS[1]: self.SURPLUS - a_share}
        return {agent: self._agreement_utility(agent, shares[agent]) for agent in self.AGENTS}

    def _split_is_stable(self, a_share: int) -> bool:
        shares = {self.AGENTS[0]: a_share, self.AGENTS[1]: self.SURPLUS - a_share}
        return all(shares[agent] >= int(self.preferences[agent]["minimum"]) for agent in self.AGENTS)

    def _best_joint_utility(self) -> float:
        candidates = [
            sum(self._split_utilities(a_share).values())
            for a_share in range(self.SURPLUS + 1)
            if self._split_is_stable(a_share)
        ]
        if not candidates:
            return sum(self.disagreement_payoffs.values())
        return round(max(candidates), 6)

    def _pareto_efficiency(self, agreement: dict[str, int] | None) -> bool:
        if agreement is None:
            return False
        current = {agent: self._agreement_utility(agent, agreement[agent]) for agent in self.AGENTS}
        for a_share in range(self.SURPLUS + 1):
            if not self._split_is_stable(a_share):
                continue
            candidate = self._split_utilities(a_share)
            weakly_better = all(candidate[agent] >= current[agent] for agent in self.AGENTS)
            strictly_better = any(candidate[agent] > current[agent] for agent in self.AGENTS)
            if weakly_better and strictly_better:
                return False
        return True

    def score_state(self) -> dict[str, dict[str, Any]]:
        agreement_reached = self.agreement is not None
        if agreement_reached:
            realized = {agent: self._agreement_utility(agent, int(self.agreement[agent])) for agent in self.AGENTS}
            stability = all(int(self.agreement[agent]) >= int(self.preferences[agent]["minimum"]) for agent in self.AGENTS)
            pareto = self._pareto_efficiency(self.agreement)
        else:
            realized = {agent: (self.disagreement_payoffs[agent] if self.is_terminal() else 0.0) for agent in self.AGENTS}
            stability = False
            pareto = False
        joint_utility = round(sum(realized.values()), 6)
        best_joint = self._best_joint_utility()
        negotiation_regret = round(max(0.0, best_joint - joint_utility), 6)

        scores: dict[str, dict[str, Any]] = {}
        for agent in self.AGENTS:
            share = int(self.agreement[agent]) if agreement_reached else 0
            scores[agent] = {
                "reached_goal": agreement_reached,
                "winner": False,
                "utility": round(float(realized[agent]), 6),
                "agreement_reached": agreement_reached,
                "share": share,
                "disagreement_payoff": self.disagreement_payoffs[agent],
                "rejected_offers": self.rejected_offers,
                "ticks": self.tick,
                "joint_utility": joint_utility,
                "pareto_efficiency": pareto,
                "agreement_stability": stability,
                "concession_cost": self._concession_cost(agent, share) if agreement_reached else 0.0,
                "negotiation_regret": negotiation_regret,
            }
        return scores

    def export_replay_state(self) -> dict[str, Any]:
        return {
            "world_id": self.WORLD_ID,
            "seed": self.seed,
            "tick": self.tick,
            "deadline": self.deadline,
            "surplus": self.SURPLUS,
            "preferences": {agent: dict(values) for agent, values in self.preferences.items()},
            "disagreement_payoffs": dict(self.disagreement_payoffs),
            "outstanding_offer": None if self.outstanding_offer is None else dict(self.outstanding_offer),
            "agreement": None if self.agreement is None else dict(self.agreement),
            "rejected_offers": self.rejected_offers,
            "rule_version": self.rule_version,
            "shifted": self.shifted,
            "shift_tick": self.shift_tick,
        }
