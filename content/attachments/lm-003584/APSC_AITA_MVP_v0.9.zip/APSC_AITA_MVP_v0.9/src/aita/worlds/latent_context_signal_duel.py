from __future__ import annotations

from typing import Any

from aita.protocol import ObservationResult
from aita.worlds.strategic_signal_duel import StrategicSignalDuelWorld


class LatentContextSignalDuelWorld(StrategicSignalDuelWorld):
    """Strategic signaling where the receiver must infer the current incentive context."""

    WORLD_ID = "LatentContextSignalDuel-v0.6"

    @classmethod
    def _contexts_for_seed(cls, seed: int, rounds: int) -> list[str]:
        current = "COMPETITIVE" if int(seed) % 2 else "ALIGNED"
        contexts: list[str] = []
        for round_index in range(int(rounds)):
            contexts.append(current)
            if (int(seed) * 13 + (round_index + 1) * 7) % 5 == 0:
                current = "ALIGNED" if current == "COMPETITIVE" else "COMPETITIVE"
        return contexts

    def reset(self, seed: int) -> dict[str, dict[str, Any]]:
        super().reset(seed)
        self.contexts = self._contexts_for_seed(self.seed, self.rounds)
        return {agent: self.get_public_state(agent) for agent in self.AGENTS}

    @staticmethod
    def _sanitize_feedback(feedback: dict[str, Any] | None) -> dict[str, Any] | None:
        if feedback is None:
            return None
        sanitized = dict(feedback)
        sanitized.pop("context", None)
        return sanitized

    def get_public_state(self, agent_id: str) -> dict[str, Any]:
        state = super().get_public_state(agent_id)
        state["world_kind"] = "latent_context_signal_duel"
        state.pop("context", None)
        state["feedback"] = self._sanitize_feedback(state.get("feedback"))
        return state

    def observe(self, agent_id: str, query: dict[str, Any]) -> ObservationResult:
        result = super().observe(agent_id, query)
        payload = dict(result.payload)
        payload.pop("context", None)
        return ObservationResult(
            observation_id=result.observation_id,
            agent_id=result.agent_id,
            payload=payload,
            reliability=result.reliability,
            cost=result.cost,
            observer_effect=result.observer_effect,
            source_id=result.source_id,
        )

    def export_replay_state(self) -> dict[str, Any]:
        state = super().export_replay_state()
        state["world_id"] = self.WORLD_ID
        return state
