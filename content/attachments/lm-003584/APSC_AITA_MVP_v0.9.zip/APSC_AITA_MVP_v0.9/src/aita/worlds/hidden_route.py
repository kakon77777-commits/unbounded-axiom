from __future__ import annotations

import random
from typing import Any

from apsc.budget import Budget
from aita.protocol import ObservationResult


class HiddenRouteWorld:
    WORLD_ID = "HiddenRoute-v0.1"
    GRAPH: dict[str, tuple[str, ...]] = {
        "S": ("A", "B"),
        "A": ("C",),
        "B": ("C", "G"),
        "C": ("G",),
        "G": (),
    }

    def __init__(self, *, deadline: int = 6) -> None:
        self.deadline = deadline
        self.seed = 0
        self.location = "S"
        self.tick = 0
        self.hazards: set[str] = set()
        self.hazard_hits = 0
        self.travel_cost = 0
        self._observation_counter = 0

    def reset(self, seed: int) -> dict[str, Any]:
        self.seed = seed
        rng = random.Random(seed)
        candidates = ["A", "B", "C"]
        self.hazards = {rng.choice(candidates)}
        if rng.random() < 0.35:
            extra = rng.choice([n for n in candidates if n not in self.hazards])
            self.hazards.add(extra)
        self.location = "S"
        self.tick = 0
        self.hazard_hits = 0
        self.travel_cost = 0
        self._observation_counter = 0
        return self.get_public_state()

    def get_public_state(self) -> dict[str, Any]:
        return {
            "location": self.location,
            "tick": self.tick,
            "deadline": self.deadline,
            "goal": "G",
            "neighbors": list(self.GRAPH[self.location]),
            "topology": {node: list(neighbors) for node, neighbors in self.GRAPH.items()},
            "known_safe": ["S", "G"],
            "hazard_hits": self.hazard_hits,
            "travel_cost": self.travel_cost,
        }

    def observe(self, agent_id: str, query: dict[str, Any]) -> ObservationResult:
        if query.get("type") != "probe":
            raise ValueError("HiddenRoute-v0.1 only supports probe observations")
        target = str(query.get("target", ""))
        if target not in self.GRAPH:
            raise ValueError("unknown probe target")
        self._observation_counter += 1
        return ObservationResult(
            observation_id=f"obs://hidden-route/{self.seed}/{self._observation_counter}",
            agent_id=agent_id,
            payload={"target": target, "hazard": target in self.hazards},
            reliability=1.0,
            cost=Budget(observation_units=1),
        )

    def legal_actions(self, agent_id: str) -> list[dict[str, Any]]:
        del agent_id
        actions = [{"type": "move", "target": target} for target in self.GRAPH[self.location]]
        actions.append({"type": "wait"})
        return actions

    def step(self, action_bundle: dict[str, dict[str, Any]]) -> dict[str, Any]:
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if len(action_bundle) != 1:
            raise ValueError("HiddenRoute-v0.1 is single-agent")
        action = next(iter(action_bundle.values()))
        action_type = action.get("type")
        if action_type == "wait":
            pass
        elif action_type == "move":
            target = str(action.get("target", ""))
            if target not in self.GRAPH[self.location]:
                raise ValueError("illegal move")
            self.location = target
            self.travel_cost += 1
            if target in self.hazards:
                self.hazard_hits += 1
        else:
            raise ValueError("illegal action type")
        self.tick += 1
        return self.get_public_state()

    def is_terminal(self) -> bool:
        return self.location == "G" or self.tick >= self.deadline

    def score_state(self) -> dict[str, Any]:
        reached_goal = self.location == "G"
        utility = (1.0 if reached_goal else 0.0) - 0.2 * self.hazard_hits - 0.02 * self.travel_cost
        return {
            "reached_goal": reached_goal,
            "utility": round(utility, 6),
            "hazard_hits": self.hazard_hits,
            "travel_cost": self.travel_cost,
            "ticks": self.tick,
        }

    def export_replay_state(self) -> dict[str, Any]:
        return {
            **self.get_public_state(),
            "seed": self.seed,
            "hazards": sorted(self.hazards),
        }
