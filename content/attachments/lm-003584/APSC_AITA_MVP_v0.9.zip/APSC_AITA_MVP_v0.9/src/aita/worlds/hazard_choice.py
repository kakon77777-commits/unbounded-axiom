from __future__ import annotations

import random
from typing import Any

from apsc.budget import Budget
from aita.protocol import ObservationResult


class HazardChoiceWorld:
    WORLD_ID = "HazardChoice-v0.3"
    AGENT_ID = "agent://A"
    ROUTES = ("FAST", "SAFE")

    def __init__(self) -> None:
        self.seed = 0
        self.tick = 0
        self.regime = "FAST_SAFE"
        self.chosen_route: str | None = None
        self._observation_counter = 0
        self.probe_count = 0

    def reset(self, seed: int) -> dict[str, Any]:
        self.seed = seed
        rng = random.Random(seed)
        self.regime = "FAST_CATASTROPHIC" if rng.random() < 0.5 else "FAST_SAFE"
        self.tick = 0
        self.chosen_route = None
        self._observation_counter = 0
        self.probe_count = 0
        return self.get_public_state()

    def get_public_state(self) -> dict[str, Any]:
        return {
            "world_kind": "hazard_choice",
            "tick": self.tick,
            "routes": list(self.ROUTES),
            "probe_available": not self.is_terminal(),
            "chosen_route": self.chosen_route,
        }

    def observe(self, agent_id: str, query: dict[str, Any]) -> ObservationResult:
        if agent_id != self.AGENT_ID:
            raise ValueError("unknown agent")
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if query != {"type": "probe", "target": "route-regime"}:
            raise ValueError("HazardChoice-v0.3 only supports route-regime probe")
        self._observation_counter += 1
        self.probe_count += 1
        return ObservationResult(
            observation_id=f"obs://hazard-choice/{self.seed}/{self._observation_counter}",
            agent_id=agent_id,
            payload={"regime": self.regime},
            reliability=1.0,
            cost=Budget(observation_units=1),
        )

    def legal_actions(self, agent_id: str) -> list[dict[str, Any]]:
        if agent_id != self.AGENT_ID:
            raise ValueError("unknown agent")
        if self.is_terminal():
            return []
        return [{"type": "choose", "route": route} for route in self.ROUTES]

    def step(self, action_bundle: dict[str, dict[str, Any]]) -> dict[str, Any]:
        if self.is_terminal():
            raise ValueError("episode already terminal")
        if set(action_bundle) != {self.AGENT_ID}:
            raise ValueError("HazardChoice-v0.3 is single-agent")
        action = action_bundle[self.AGENT_ID]
        if action.get("type") != "choose" or action.get("route") not in self.ROUTES:
            raise ValueError("illegal action")
        self.chosen_route = str(action["route"])
        self.tick += 1
        return self.get_public_state()

    def is_terminal(self) -> bool:
        return self.chosen_route is not None

    def _utility(self) -> float:
        if self.chosen_route is None:
            return 0.0
        if self.chosen_route == "SAFE":
            return 0.65
        return 1.0 if self.regime == "FAST_SAFE" else -2.5

    def score_state(self) -> dict[str, Any]:
        catastrophic = int(self.chosen_route == "FAST" and self.regime == "FAST_CATASTROPHIC")
        utility = self._utility()
        oracle_utility = 1.0 if self.regime == "FAST_SAFE" else 0.65
        avoidable_loss = max(0.0, oracle_utility - utility) if self.is_terminal() else 0.0
        prevented_loss = 0.0
        if self.regime == "FAST_CATASTROPHIC" and self.probe_count > 0 and self.chosen_route == "SAFE":
            prevented_loss = 0.65 - (-2.5)
        return {
            "reached_goal": self.is_terminal() and not catastrophic,
            "utility": utility,
            "catastrophic_loss": catastrophic,
            "avoidable_loss": round(avoidable_loss, 6),
            "observation_prevented_loss": round(prevented_loss, 6),
            "chosen_route": self.chosen_route,
            "ticks": self.tick,
        }

    def export_replay_state(self) -> dict[str, Any]:
        return {
            **self.get_public_state(),
            "seed": self.seed,
            "regime": self.regime,
            "probe_count": self.probe_count,
        }
