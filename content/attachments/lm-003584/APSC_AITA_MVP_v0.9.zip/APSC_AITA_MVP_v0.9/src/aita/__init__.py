"""AI Tension Arena MVP."""

__version__ = "0.1.0"
