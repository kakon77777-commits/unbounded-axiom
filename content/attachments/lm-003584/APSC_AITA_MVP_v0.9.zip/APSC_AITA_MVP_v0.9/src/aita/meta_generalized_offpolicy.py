from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from apsc.budget import Budget
from apsc.meta_generalization import GeneralizedCognitiveExperience, GeneralizedCognitiveFeatures
from apsc.meta_learning import CognitiveExperience, MetaStateFeatures
from aita.meta_generalization import project_latent_context_features, project_signal_hazard_features
from aita.meta_offpolicy import build_counterfactual_experiences


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    path = Path(path)
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _route_from_signal(signal: str) -> str:
    return "SAFE" if str(signal) == "FAST_CATASTROPHIC" else "FAST"


def _utility(truth: str, route: str) -> float:
    if route == "SAFE":
        return 0.65
    return 1.0 if str(truth) == "FAST_SAFE" else -2.5


def _clip_signed(value: float) -> float:
    return min(max(float(value), -1.0), 1.0)


def _latent_features(meta: MetaStateFeatures, *, observation_cost_fraction: float = 0.1) -> GeneralizedCognitiveFeatures:
    # This conversion uses only v0.8 action-time features. No hidden context/truth exists here.
    return GeneralizedCognitiveFeatures.from_mapping(
        {
            "uncertainty": float(meta.belief_entropy),
            "primary_trust": float(meta.effective_signal_trust),
            "verifier_trust": float(meta.effective_field_trust),
            "primary_value_prior": _clip_signed(meta.handcrafted_trust_mvc),
            "verify_value_prior": _clip_signed(meta.handcrafted_field_mvc),
            "progress_fraction": float(meta.round_fraction),
            "observation_available": bool(meta.observation_available),
            "risk_if_wrong": 0.45 if meta.signal_is_catastrophic else 1.0,
            "evidence_conflict": False,
            "observation_cost_fraction": min(max(float(observation_cost_fraction), 0.0), 1.0),
        }
    )


def build_latent_context_generalized_experiences(
    run_dir: Path,
    *,
    observation_penalty: float,
    verify_counterfactual_uncertainty: float = 0.25,
    trust_counterfactual_uncertainty: float = 0.10,
) -> list[GeneralizedCognitiveExperience]:
    run_dir = Path(run_dir)
    actual_payloads = [
        row for row in _read_jsonl(run_dir / "meta_experiences.jsonl")
        if row.get("agent_id") == "agent://receiver"
    ]
    actual_by_round = {int(row["round_index"]): CognitiveExperience.from_dict(row) for row in actual_payloads}
    cf_rows = build_counterfactual_experiences(
        run_dir,
        observation_penalty=float(observation_penalty),
        sample_weight=1.0,
    )
    cf_by_round = {row.experience.round_index: row.experience for row in cf_rows}
    result: list[GeneralizedCognitiveExperience] = []
    world_id = str(_read_json(run_dir / "world_manifest.json").get("world_id", "LatentContextSignalDuel-v0.6"))
    observation_cost_fraction = min(max(float(observation_penalty), 0.0), 1.0)
    for round_index in sorted(actual_by_round):
        actual = actual_by_round[round_index]
        features = _latent_features(actual.features, observation_cost_fraction=observation_cost_fraction)
        operation = "trust_primary" if actual.operation == "trust_signal" else "verify_independent"
        result.append(
            GeneralizedCognitiveExperience(
                experience_id=f"gx://latent/actual/{actual.experience_id}",
                episode_id=actual.episode_id,
                round_index=round_index,
                source_world=world_id,
                operation=operation,
                features=features,
                realized_value=actual.realized_value,
                observation_cost=actual.observation_cost,
                target_uncertainty=0.0,
                evidence_kind="on_policy",
            )
        )
        cf = cf_by_round.get(round_index)
        if cf is None:
            continue
        cf_operation = "trust_primary" if cf.operation == "trust_signal" else "verify_independent"
        cf_uncertainty = (
            float(verify_counterfactual_uncertainty)
            if cf_operation == "verify_independent"
            else float(trust_counterfactual_uncertainty)
        )
        result.append(
            GeneralizedCognitiveExperience(
                experience_id=f"gx://latent/cf/{cf.experience_id}",
                episode_id=cf.episode_id,
                round_index=round_index,
                source_world=world_id,
                operation=cf_operation,
                features=features,
                realized_value=cf.realized_value,
                observation_cost=cf.observation_cost,
                target_uncertainty=cf_uncertainty,
                evidence_kind="counterfactual",
            )
        )
    return result


def _signal_observations_by_round(run_dir: Path) -> dict[int, dict[str, Any]]:
    result: dict[int, dict[str, Any]] = {}
    for row in _read_jsonl(run_dir / "observations.jsonl"):
        if row.get("agent_id") != "agent://A":
            continue
        idx = int(dict(row.get("payload", {})).get("round_index", -1))
        if idx >= 0:
            result[idx] = row
    return result


def _signal_calibration_by_round(run_dir: Path) -> dict[int, dict[str, Any]]:
    return {int(row["round_index"]): row for row in _read_jsonl(run_dir / "calibration.jsonl") if "round_index" in row}


def _signal_actions_by_round(run_dir: Path) -> dict[int, dict[str, Any]]:
    rows: dict[int, dict[str, Any]] = {}
    for row in _read_jsonl(run_dir / "actions.jsonl"):
        after = dict(row.get("after", {}))
        feedback = after.get("feedback")
        if isinstance(feedback, dict):
            idx = int(feedback.get("round_index", -1))
            if idx >= 0:
                rows[idx] = row
    return rows


def build_signal_hazard_generalized_experiences(
    run_dir: Path,
    *,
    observation_penalty: float,
    verify_counterfactual_uncertainty: float = 0.30,
    trust_counterfactual_uncertainty: float = 0.10,
) -> list[GeneralizedCognitiveExperience]:
    run_dir = Path(run_dir)
    world_manifest = _read_json(run_dir / "world_manifest.json")
    initial = dict(world_manifest.get("initial_replay_state", {}))
    truths = list(initial.get("regimes", []))
    source_signals = dict(initial.get("source_signals", {}))
    advisor_signals = list(source_signals.get("advisor://deceptive", []))
    field_signals = list(source_signals.get("sensor://field", []))
    observations = _signal_observations_by_round(run_dir)
    calibrations = _signal_calibration_by_round(run_dir)
    actions = _signal_actions_by_round(run_dir)
    episode = _read_json(run_dir / "episode.json")
    episode_id = str(episode.get("episode_id", "episode://signal-hazard/replay"))
    world_id = str(world_manifest.get("world_id", "SignalHazard-v0.4"))
    result: list[GeneralizedCognitiveExperience] = []

    for round_index in sorted(actions):
        if round_index >= len(truths) or round_index >= len(advisor_signals) or round_index >= len(field_signals):
            continue
        action_row = actions[round_index]
        before = dict(action_row.get("before", {}))
        feedback = dict(dict(action_row.get("after", {})).get("feedback", {}))
        observation = observations.get(round_index)
        calibration = calibrations.get(round_index, {})
        reliability = dict(calibration.get("reliability", {}))
        mvc = dict(calibration.get("mvc", {}))
        primary_trust = float(dict(reliability.get("advisor://deceptive", {})).get("estimated_reliability", 0.9))
        verifier_trust = float(dict(reliability.get("sensor://field", {})).get("estimated_reliability", 0.7))
        primary_prior = float(dict(mvc.get("observe:advisor://deceptive", {})).get("estimated_gain", 0.0))
        verify_prior = float(dict(mvc.get("observe:sensor://field", {})).get("estimated_gain", 0.0))
        selected_source = None if observation is None else observation.get("source_id")
        selected_signal = None if observation is None else dict(observation.get("payload", {})).get("signal")
        actual_operation = "trust_primary" if selected_source == "advisor://deceptive" else "verify_independent"
        primary_signal = str(selected_signal) if actual_operation == "trust_primary" and selected_signal is not None else None
        verifier_signal = str(selected_signal) if actual_operation == "verify_independent" and selected_signal is not None else None
        feature_budget = Budget(observation_units=max(1, 8 - round_index))
        features = project_signal_hazard_features(
            before,
            feature_budget,
            primary_trust=primary_trust,
            verifier_trust=verifier_trust,
            primary_value_prior=primary_prior,
            verify_value_prior=verify_prior,
            primary_signal=primary_signal,
            verifier_signal=verifier_signal,
        )
        actual_utility = float(feedback.get("utility", 0.0)) - float(observation_penalty)
        result.append(
            GeneralizedCognitiveExperience(
                experience_id=f"gx://signal/actual/{episode_id.rsplit('/', 1)[-1]}/{round_index}/{actual_operation}",
                episode_id=episode_id,
                round_index=round_index,
                source_world=world_id,
                operation=actual_operation,
                features=features,
                realized_value=actual_utility,
                observation_cost=float(observation_penalty),
                target_uncertainty=0.0,
                evidence_kind="on_policy",
            )
        )

        alternate = "verify_independent" if actual_operation == "trust_primary" else "trust_primary"
        alt_signal = field_signals[round_index] if alternate == "verify_independent" else advisor_signals[round_index]
        alt_route = _route_from_signal(str(alt_signal))
        alt_value = _utility(str(truths[round_index]), alt_route) - float(observation_penalty)
        alt_uncertainty = (
            float(verify_counterfactual_uncertainty)
            if alternate == "verify_independent"
            else float(trust_counterfactual_uncertainty)
        )
        result.append(
            GeneralizedCognitiveExperience(
                experience_id=f"gx://signal/cf/{episode_id.rsplit('/', 1)[-1]}/{round_index}/{alternate}",
                episode_id=episode_id,
                round_index=round_index,
                source_world=world_id,
                operation=alternate,
                features=features,
                realized_value=alt_value,
                observation_cost=float(observation_penalty),
                target_uncertainty=alt_uncertainty,
                evidence_kind="counterfactual",
            )
        )
    return result
