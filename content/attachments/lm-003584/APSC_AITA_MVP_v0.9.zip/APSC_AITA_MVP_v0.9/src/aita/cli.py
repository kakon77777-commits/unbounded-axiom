from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

from apsc.budget import Budget
from aita.acceptance import validate_run
from aita.benchmark import (
    AGENT_FACTORIES,
    COP_PRESETS,
    DUEL_WORLD_FACTORIES,
    WORLD_FACTORIES,
    run_duel_matrix,
    run_matrix,
    run_strategic_signal_matrix,
    run_latent_context_signal_matrix,
    run_meta_learning_experiment,
    run_exploration_meta_learning_experiment,
    run_cross_world_meta_generalization_experiment,
)
from aita.protocol import DuelEpisodeConfig, EpisodeConfig
from aita.runner import run_duel_episode, run_episode

BUDGET_PRESETS = {
    "small": Budget(compute_units=20, memory_units=20, observation_units=5, action_units=10),
    "medium": Budget(compute_units=50, memory_units=50, observation_units=12, action_units=20),
    "large": Budget(compute_units=100, memory_units=100, observation_units=25, action_units=40),
}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aita")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run")
    run.add_argument("--world", required=True, choices=sorted(WORLD_FACTORIES))
    run.add_argument("--baseline", required=True, choices=sorted(AGENT_FACTORIES))
    run.add_argument("--seed", type=int, required=True)
    run.add_argument("--budget", default="medium", choices=sorted(BUDGET_PRESETS))
    run.add_argument("--profile", default="balanced", choices=sorted(COP_PRESETS))
    run.add_argument("--output", required=True)


    duel = sub.add_parser("duel")
    duel.add_argument("--world", required=True, choices=sorted(DUEL_WORLD_FACTORIES))
    duel.add_argument("--baseline-a", required=True, choices=sorted(AGENT_FACTORIES))
    duel.add_argument("--baseline-b", required=True, choices=sorted(AGENT_FACTORIES))
    duel.add_argument("--profile-a", default="balanced", choices=sorted(COP_PRESETS))
    duel.add_argument("--profile-b", default="balanced", choices=sorted(COP_PRESETS))
    duel.add_argument("--seed", type=int, required=True)
    duel.add_argument("--budget", default="medium", choices=sorted(BUDGET_PRESETS))
    duel.add_argument("--output", required=True)

    duel_matrix = sub.add_parser("duel-matrix")
    duel_matrix.add_argument("spec")
    duel_matrix.add_argument("--output", required=True)

    strategic_matrix = sub.add_parser("strategic-matrix")
    strategic_matrix.add_argument("spec")
    strategic_matrix.add_argument("--output", required=True)

    latent_matrix = sub.add_parser("latent-signal-matrix")
    latent_matrix.add_argument("spec")
    latent_matrix.add_argument("--output", required=True)

    meta_learn = sub.add_parser("meta-learn")
    meta_learn.add_argument("spec")
    meta_learn.add_argument("--output", required=True)

    meta_explore = sub.add_parser("meta-explore")
    meta_explore.add_argument("spec")
    meta_explore.add_argument("--output", required=True)

    meta_transfer = sub.add_parser("meta-transfer")
    meta_transfer.add_argument("spec")
    meta_transfer.add_argument("--output", required=True)

    replay = sub.add_parser("replay")
    replay.add_argument("run_dir")

    compare = sub.add_parser("compare")
    compare.add_argument("run_a")
    compare.add_argument("run_b")

    matrix = sub.add_parser("matrix")
    matrix.add_argument("spec")
    matrix.add_argument("--output", required=True)

    report = sub.add_parser("report")
    report.add_argument("benchmark_dir")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(list(argv) if argv is not None else None)
    if args.command == "run":
        world = WORLD_FACTORIES[args.world]()
        agent = AGENT_FACTORIES[args.baseline]("agent://A")
        cop = COP_PRESETS[args.profile]
        config = EpisodeConfig(
            episode_id=f"episode://cli/{args.world}/{args.baseline}/{args.seed}",
            seed=args.seed,
            baseline=args.baseline,
            budget=BUDGET_PRESETS[args.budget],
            profile_name=args.profile,
        )
        result = run_episode(world, agent, config, Path(args.output), cop)
        print(json.dumps({"episode_id": result.episode_id, "status": result.status, "score": result.score}, ensure_ascii=False, sort_keys=True))
        return 0 if result.status in {"completed", "budget_exhausted"} else 2

    if args.command == "duel":
        world = DUEL_WORLD_FACTORIES[args.world]()
        agents = {
            "agent://A": AGENT_FACTORIES[args.baseline_a]("agent://A"),
            "agent://B": AGENT_FACTORIES[args.baseline_b]("agent://B"),
        }
        budget = BUDGET_PRESETS[args.budget]
        cops = {"agent://A": COP_PRESETS[args.profile_a], "agent://B": COP_PRESETS[args.profile_b]}
        config = DuelEpisodeConfig(
            episode_id=f"episode://cli/{args.world}/{args.baseline_a}-{args.baseline_b}/{args.seed}",
            seed=args.seed,
            agent_baselines={"agent://A": args.baseline_a, "agent://B": args.baseline_b},
            budgets={"agent://A": budget, "agent://B": budget},
            profile_names={"agent://A": args.profile_a, "agent://B": args.profile_b},
        )
        result = run_duel_episode(world, agents, config, Path(args.output), cops)
        print(json.dumps({"episode_id": result.episode_id, "status": result.status, "scores": result.scores}, ensure_ascii=False, sort_keys=True))
        return 0 if result.status in {"completed", "cycle_limit"} else 2

    if args.command == "duel-matrix":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_duel_matrix(spec, Path(args.output))
        print(json.dumps({"row_count": len(report.rows), "aggregates": report.aggregates}, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "strategic-matrix":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_strategic_signal_matrix(spec, Path(args.output))
        print(json.dumps({"row_count": len(report.rows), "aggregates": report.aggregates}, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "latent-signal-matrix":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_latent_context_signal_matrix(spec, Path(args.output))
        print(json.dumps({"row_count": len(report.rows), "aggregates": report.aggregates}, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "meta-learn":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_meta_learning_experiment(spec, Path(args.output))
        print(json.dumps({
            "row_count": len(report["eval_rows"]),
            "model_hash": report["model_hash_after_eval"],
            "aggregates": report["eval_report"]["aggregates"],
        }, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "meta-explore":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_exploration_meta_learning_experiment(spec, Path(args.output))
        print(json.dumps({
            "row_count": len(report["eval_rows"]),
            "model_hash": report["model_hash_after_eval"],
            "aggregates": report["eval_report"]["aggregates"],
        }, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "meta-transfer":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_cross_world_meta_generalization_experiment(spec, Path(args.output))
        print(json.dumps(report["summary"], ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "replay":
        path = Path(args.run_dir)
        gates = validate_run(path)
        print(json.dumps({"replay": str(path), "gates": gates}, ensure_ascii=False, sort_keys=True))
        return 0 if all(v["status"] != "FAIL" for v in gates.values()) else 2

    if args.command == "compare":
        a = json.loads((Path(args.run_a) / "score.json").read_text(encoding="utf-8"))
        b = json.loads((Path(args.run_b) / "score.json").read_text(encoding="utf-8"))
        keys = sorted(set(a) & set(b))
        delta = {key: round(float(a[key]) - float(b[key]), 8) for key in keys}
        print(json.dumps({"a_minus_b": delta}, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "matrix":
        spec = json.loads(Path(args.spec).read_text(encoding="utf-8"))
        report = run_matrix(spec, Path(args.output))
        print(json.dumps({"row_count": len(report.rows), "aggregates": report.aggregates}, ensure_ascii=False, sort_keys=True))
        return 0

    if args.command == "report":
        report_path = Path(args.benchmark_dir) / "benchmark_report.json"
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 0

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
