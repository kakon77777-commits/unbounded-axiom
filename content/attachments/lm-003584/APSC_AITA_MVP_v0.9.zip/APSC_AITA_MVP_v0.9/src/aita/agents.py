from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Any

from apsc.budget import Budget
from apsc.controller import AdaptiveController
from apsc.context_belief import LatentContextBeliefTracker
from apsc.coe import ObservationCandidate, value_observation
from apsc.cop import CognitiveOperatingProfile
from apsc.models import ProfileReceipt
from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel, MetaStateFeatures
from apsc.meta_exploration import UncertaintyAwareMetaSelector
from apsc.meta_generalization import CrossWorldMetaValueModel
from apsc.meta_exploration_policy import ExplorationPolicyFeatures, LearnedExplorationPolicyModel
from aita.meta_generalization import project_latent_context_features, project_signal_hazard_features
from apsc.reliability import SourceReliabilityTracker, ContextualSourceReliabilityTracker
from apsc.value_estimator import OnlineMVCValueEstimator, ContextualMVCValueEstimator
from apsc.operators import CognitiveOperation
from aita.protocol import ObservationResult


@dataclass(frozen=True, slots=True)
class AgentDecision:
    cognition_operator: str
    compute_cost: Budget
    query: dict[str, Any] | None = None
    action: dict[str, Any] | None = None
    profile_receipt: ProfileReceipt | None = None


class AgentAdapter:
    def __init__(self, agent_id: str) -> None:
        self.agent_id = agent_id
        self.current_cop = CognitiveOperatingProfile()
        self.observations: list[ObservationResult] = []

    def reset(self, cop: CognitiveOperatingProfile) -> None:
        self.current_cop = cop
        self.observations = []

    def ingest_observation(self, observation: ObservationResult) -> None:
        self.observations.append(observation)

    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        raise NotImplementedError

    def _hidden_route_known_hazards(self) -> dict[str, bool]:
        result: dict[str, bool] = {}
        for observation in self.observations:
            payload = observation.payload
            if "target" in payload and "hazard" in payload:
                result[str(payload["target"])] = bool(payload["hazard"])
        return result

    def _verifier_results(self) -> dict[str, bool]:
        result: dict[str, bool] = {}
        for observation in self.observations:
            payload = observation.payload
            if "candidate" in payload and "verified" in payload:
                result[str(payload["candidate"])] = bool(payload["verified"])
        return result

    def _hazard_choice_regime(self) -> str | None:
        for observation in reversed(self.observations):
            regime = observation.payload.get("regime")
            if regime in {"FAST_SAFE", "FAST_CATASTROPHIC"}:
                return str(regime)
        return None

    def _signal_hazard_observations(self, round_index: int) -> list[ObservationResult]:
        return [
            observation
            for observation in self.observations
            if observation.payload.get("round_index") == round_index
            and observation.source_id in {"sensor://field", "advisor://deceptive"}
        ]

    @staticmethod
    def _signal_route(signal: str, *, conservative: bool = False) -> str:
        if conservative:
            return "SAFE"
        return "SAFE" if signal == "FAST_CATASTROPHIC" else "FAST"

    @staticmethod
    def _flip_signal(signal: str) -> str:
        return "FAST_CATASTROPHIC" if signal == "FAST_SAFE" else "FAST_SAFE"

    def _strategic_field_observations(self, round_index: int) -> list[ObservationResult]:
        return [
            observation
            for observation in self.observations
            if observation.payload.get("round_index") == round_index
            and observation.source_id == "sensor://field"
        ]

    @staticmethod
    def _is_strategic_world(public_state: dict[str, Any]) -> bool:
        return public_state.get("world_kind") in {"strategic_signal_duel", "latent_context_signal_duel"}

    def _fixed_strategic_signal(self, public_state: dict[str, Any]) -> str:
        truth = str(public_state["current_truth"])
        incentive = public_state.get("own_incentive", public_state.get("context", "ALIGNED"))
        return truth if incentive == "ALIGNED" else self._flip_signal(truth)


class B0NeuralDirectAgent(AgentAdapter):
    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        del budget
        if self._is_strategic_world(public_state):
            if public_state.get("role") == "signaler":
                action = {"type": "send_signal", "claim": "FAST_SAFE"} if public_state.get("phase") == "SIGNAL" else {"type": "wait"}
            elif public_state.get("phase") == "SIGNAL":
                action = {"type": "wait"}
            else:
                signal = public_state.get("opponent_signal")
                route = self._signal_route(str(signal)) if signal is not None else "FAST"
                action = {"type": "choose", "route": route}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if public_state.get("world_kind") == "hazard_choice":
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": "FAST"})
        if public_state.get("world_kind") == "signal_hazard":
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": "FAST"})
        if public_state.get("world_kind") == "negotiation_split":
            offer = public_state.get("outstanding_offer")
            if offer is not None and offer.get("receiver") == self.agent_id:
                action = {"type": "accept"} if int(offer["receiver_share"]) >= int(public_state["own_ideal_share"]) else {"type": "reject"}
            elif offer is not None and offer.get("proposer") == self.agent_id:
                action = {"type": "wait"}
            else:
                action = {"type": "offer", "self_share": 7}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if "candidates" in public_state:
            action = {"type": "commit", "candidate": public_state["candidates"][0]}
        else:
            neighbors = list(public_state.get("neighbors", []))
            action = {"type": "wait"} if not neighbors else {"type": "move", "target": neighbors[-1]}
        return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)


class B1FixedDepthAgent(AgentAdapter):
    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        if self._is_strategic_world(public_state):
            if public_state.get("role") == "signaler":
                action = (
                    {"type": "send_signal", "claim": str(public_state["current_truth"])}
                    if public_state.get("phase") == "SIGNAL"
                    else {"type": "wait"}
                )
            elif public_state.get("phase") == "SIGNAL":
                action = {"type": "wait"}
            else:
                signal = public_state.get("opponent_signal")
                route = self._signal_route(str(signal)) if signal is not None else "SAFE"
                action = {"type": "choose", "route": route}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if public_state.get("world_kind") == "hazard_choice":
            regime = self._hazard_choice_regime()
            if regime is None and budget.observation_units > 0:
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "probe", "target": "route-regime"})
            route = "SAFE" if regime == "FAST_CATASTROPHIC" else "FAST"
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": route})
        if public_state.get("world_kind") == "signal_hazard":
            round_index = int(public_state["round_index"])
            current = [o for o in self._signal_hazard_observations(round_index) if o.source_id == "sensor://field"]
            if not current and budget.observation_units > 0:
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})
            signal = current[-1].payload["signal"] if current else "FAST_SAFE"
            route = self._signal_route(str(signal))
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": route})
        if public_state.get("world_kind") == "negotiation_split":
            offer = public_state.get("outstanding_offer")
            minimum = int(public_state["own_minimum"])
            if offer is not None and offer.get("receiver") == self.agent_id:
                action = {"type": "accept"} if int(offer["receiver_share"]) >= minimum else {"type": "reject"}
            elif offer is not None and offer.get("proposer") == self.agent_id:
                action = {"type": "wait"}
            else:
                ask = max(minimum, 6 - int(public_state.get("tick", 0)) // 2)
                action = {"type": "offer", "self_share": ask}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if "candidates" in public_state:
            results = self._verifier_results()
            for candidate, verified in results.items():
                if verified:
                    return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "commit", "candidate": candidate})
            if public_state.get("verifier_remaining", 0) > 0 and budget.observation_units > 0:
                for candidate in public_state["candidates"]:
                    if candidate not in results:
                        return AgentDecision("cog://verify@0.1", Budget(compute_units=1), query={"type": "verify", "candidate": candidate})
            candidate = next((c for c in public_state["candidates"] if results.get(c) is not False), public_state["candidates"][0])
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "commit", "candidate": candidate})

        hazards = self._hidden_route_known_hazards()
        neighbors = list(public_state.get("neighbors", []))
        if hazards:
            safe = [target for target in neighbors if hazards.get(target) is False]
            non_hazard = [target for target in neighbors if hazards.get(target) is not True]
            target = safe[0] if safe else (non_hazard[0] if non_hazard else None)
            action = {"type": "wait"} if target is None else {"type": "move", "target": target}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if budget.observation_units > 0 and neighbors:
            return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "probe", "target": neighbors[0]})
        target = neighbors[-1] if neighbors else None
        action = {"type": "wait"} if target is None else {"type": "move", "target": target}
        return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)


class B3APSCFixedCOPAgent(AgentAdapter):
    @staticmethod
    def _distance(topology: dict[str, list[str]], start: str, goal: str) -> int:
        if start == goal:
            return 0
        frontier = [(start, 0)]
        seen = {start}
        while frontier:
            node, depth = frontier.pop(0)
            for nxt in topology.get(node, []):
                if nxt == goal:
                    return depth + 1
                if nxt not in seen:
                    seen.add(nxt)
                    frontier.append((nxt, depth + 1))
        return 10**6

    def _route_target(self, public_state: dict[str, Any], hazards: dict[str, bool]) -> str | None:
        neighbors = list(public_state.get("neighbors", []))
        topology = dict(public_state.get("topology", {}))
        goal = str(public_state.get("goal", ""))
        feasible = [target for target in neighbors if hazards.get(target) is not True]
        if not feasible:
            return None
        opponent_location = public_state.get("opponent_location")
        collision_avoiding = [target for target in feasible if target != opponent_location]
        if collision_avoiding:
            feasible = collision_avoiding
        return min(feasible, key=lambda target: (self._distance(topology, target, goal), target))

    def _negotiation_threshold(self, public_state: dict[str, Any]) -> int:
        minimum = int(public_state["own_minimum"])
        delta = int(round(self.current_cop.commitment + self.current_cop.risk - 1.5 * self.current_cop.latency))
        return max(0, min(int(public_state["surplus"]), minimum + delta))

    def _negotiation_action(self, public_state: dict[str, Any]) -> dict[str, Any]:
        offer = public_state.get("outstanding_offer")
        if offer is not None and offer.get("receiver") == self.agent_id:
            threshold = self._negotiation_threshold(public_state)
            return {"type": "accept"} if int(offer["receiver_share"]) >= threshold else {"type": "reject"}
        if offer is not None and offer.get("proposer") == self.agent_id:
            return {"type": "wait"}
        minimum = int(public_state["own_minimum"])
        ideal = int(public_state["own_ideal_share"])
        extra = int(round(2.0 * self.current_cop.commitment + self.current_cop.risk - self.current_cop.latency))
        ask = max(minimum, min(ideal, minimum + extra))
        return {"type": "offer", "self_share": ask}

    def __init__(self, agent_id: str) -> None:
        super().__init__(agent_id)
        self.controller = AdaptiveController(
            shadow_prices={"compute_units": 0.05, "observation_units": 0.08, "action_units": 0.05},
            epsilon=0.0,
        )

    def _options(self, public_state: dict[str, Any]) -> tuple[list[CognitiveOperation], dict[str, AgentDecision]]:
        ops: list[CognitiveOperation] = []
        decisions: dict[str, AgentDecision] = {}
        if self._is_strategic_world(public_state):
            if public_state.get("role") == "signaler":
                action = (
                    {"type": "send_signal", "claim": self._fixed_strategic_signal(public_state)}
                    if public_state.get("phase") == "SIGNAL"
                    else {"type": "wait"}
                )
                op = CognitiveOperation("cog://commit@0.1", 1.0, Budget(compute_units=1, action_units=1), metadata={"kind": "strategic_signal"})
                return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action=action)}
            if public_state.get("phase") == "SIGNAL":
                op = CognitiveOperation("cog://commit@0.1", 1.0, Budget(compute_units=1, action_units=1), metadata={"kind": "wait"})
                return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action={"type": "wait"})}

            round_index = int(public_state["round_index"])
            field = self._strategic_field_observations(round_index)
            if field:
                route = self._signal_route(str(field[-1].payload["signal"]))
                op = CognitiveOperation("cog://commit@0.1", 1.3, Budget(compute_units=1, action_units=1), metadata={"kind": "field_action"})
                return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action={"type": "choose", "route": route})}

            signal = public_state.get("opponent_signal")
            claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
            signaler_claim = claims.get("agent://signaler", 0.5)
            field_claim = claims.get("sensor://field", 0.5)
            if signal is not None:
                trust = CognitiveOperation(
                    "cog://commit@0.1",
                    signaler_claim + 0.1 * self.current_cop.latency,
                    Budget(compute_units=1, action_units=1),
                    metadata={"kind": "trust_signal"},
                )
                ops.append(trust)
                decisions[trust.operation_id] = AgentDecision(
                    trust.operator_id,
                    trust.cost,
                    action={"type": "choose", "route": self._signal_route(str(signal))},
                )
            observe = CognitiveOperation(
                "cog://observe@0.1",
                field_claim + 0.1 * self.current_cop.observation - 0.05,
                Budget(compute_units=1, observation_units=1),
                metadata={"kind": "observe_field"},
            )
            ops.append(observe)
            decisions[observe.operation_id] = AgentDecision(
                observe.operator_id,
                Budget(compute_units=1),
                query={"type": "signal", "source": "sensor://field"},
            )
            return ops, decisions
        if public_state.get("world_kind") == "hazard_choice":
            regime = self._hazard_choice_regime()
            if regime is not None:
                route = "SAFE" if regime == "FAST_CATASTROPHIC" else "FAST"
                op = CognitiveOperation("cog://commit@0.1", 1.5, Budget(compute_units=1, action_units=1), metadata={"kind": "commit", "route": route})
                return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action={"type": "choose", "route": route})}
            observe_gain = 0.65 + 0.35 * self.current_cop.risk
            observe = CognitiveOperation("cog://observe@0.1", observe_gain, Budget(compute_units=1, observation_units=1), metadata={"kind": "observe", "target": "route-regime"})
            commit_gain = 0.75 + 0.25 * self.current_cop.latency
            commit = CognitiveOperation("cog://commit@0.1", commit_gain, Budget(compute_units=1, action_units=1), metadata={"kind": "commit", "route": "FAST"})
            return [observe, commit], {
                observe.operation_id: AgentDecision(observe.operator_id, Budget(compute_units=1), query={"type": "probe", "target": "route-regime"}),
                commit.operation_id: AgentDecision(commit.operator_id, commit.cost, action={"type": "choose", "route": "FAST"}),
            }
        if public_state.get("world_kind") == "signal_hazard":
            round_index = int(public_state["round_index"])
            current = self._signal_hazard_observations(round_index)
            if current:
                observation = current[-1]
                route = self._signal_route(str(observation.payload["signal"]))
                op = CognitiveOperation("cog://commit@0.1", 1.4, Budget(compute_units=1, action_units=1), metadata={"kind": "commit", "route": route})
                return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action={"type": "choose", "route": route})}
            claims = dict(public_state.get("source_claims", {}))
            source = max(claims, key=lambda key: (float(claims[key]), key))
            observe = CognitiveOperation(
                "cog://observe@0.1",
                0.6 + float(claims[source]),
                Budget(compute_units=1, observation_units=1),
                metadata={"kind": "observe", "source": source},
            )
            commit = CognitiveOperation(
                "cog://commit@0.1",
                0.55 + 0.4 * self.current_cop.latency,
                Budget(compute_units=1, action_units=1),
                metadata={"kind": "commit", "route": "FAST"},
            )
            return [observe, commit], {
                observe.operation_id: AgentDecision(observe.operator_id, Budget(compute_units=1), query={"type": "signal", "source": source}),
                commit.operation_id: AgentDecision(commit.operator_id, commit.cost, action={"type": "choose", "route": "FAST"}),
            }
        if public_state.get("world_kind") == "negotiation_split":
            action = self._negotiation_action(public_state)
            op = CognitiveOperation("cog://commit@0.1", 1.0, Budget(compute_units=1, action_units=1), metadata={"kind": "commit", "negotiation": True})
            return [op], {op.operation_id: AgentDecision(op.operator_id, op.cost, action=action)}
        if "candidates" in public_state:
            results = self._verifier_results()
            verified_true = next((c for c, v in results.items() if v), None)
            if verified_true is not None:
                op = CognitiveOperation("cog://commit@0.1", 1.5, Budget(compute_units=1, action_units=1), metadata={"kind": "commit"})
                ops.append(op)
                decisions[op.operation_id] = AgentDecision(op.operator_id, op.cost, action={"type": "commit", "candidate": verified_true})
            else:
                if public_state.get("verifier_remaining", 0) > 0:
                    candidate = next((c for c in public_state["candidates"] if c not in results), None)
                    if candidate is not None:
                        op = CognitiveOperation("cog://observe@0.1", 1.0, Budget(compute_units=1, observation_units=1), metadata={"kind": "observe"})
                        ops.append(op)
                        decisions[op.operation_id] = AgentDecision(op.operator_id, Budget(compute_units=1), query={"type": "verify", "candidate": candidate})
                candidate = next((c for c in public_state["candidates"] if results.get(c) is not False), public_state["candidates"][0])
                op = CognitiveOperation("cog://commit@0.1", 0.45, Budget(compute_units=1, action_units=1), metadata={"kind": "commit"})
                ops.append(op)
                decisions[op.operation_id] = AgentDecision(op.operator_id, op.cost, action={"type": "commit", "candidate": candidate})
            return ops, decisions

        hazards = self._hidden_route_known_hazards()
        target = self._route_target(public_state, hazards)
        known_safe = set(public_state.get("known_safe", []))
        needs_observation = target is not None and target not in known_safe and target not in hazards
        if needs_observation:
            op = CognitiveOperation("cog://observe@0.1", 0.5, Budget(compute_units=1, observation_units=1), metadata={"kind": "observe", "target": target})
            ops.append(op)
            decisions[op.operation_id] = AgentDecision(op.operator_id, Budget(compute_units=1), query={"type": "probe", "target": target})
        action = {"type": "wait"} if target is None else {"type": "move", "target": target}
        action_gain = 1.35 if target in known_safe or hazards.get(target) is False else 0.35
        op = CognitiveOperation("cog://commit@0.1", action_gain, Budget(compute_units=1, action_units=1), metadata={"kind": "commit", "target": target})
        ops.append(op)
        decisions[op.operation_id] = AgentDecision(op.operator_id, op.cost, action=action)
        return ops, decisions

    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        ops, decisions = self._options(public_state)
        chosen = self.controller.choose(ops, budget, self.current_cop)
        if chosen is None:
            return AgentDecision("cog://commit@0.1", Budget(), action={"type": "wait"})
        return decisions[chosen.operation_id]


class B4APSCAdaptiveCOPAgent(B3APSCFixedCOPAgent):
    def __init__(self, agent_id: str) -> None:
        super().__init__(agent_id)
        self._risk_shifted = False
        self._last_rule_version: int | None = None
        self._source_reliability = SourceReliabilityTracker(prior_strength=2.0)
        self._mvc_estimator = OnlineMVCValueEstimator()
        self._processed_signal_feedback: set[int] = set()
        self._last_selected_source: str | None = None
        self._context_reliability = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
        self._context_mvc = ContextualMVCValueEstimator(backoff_strength=1.0)
        self._processed_strategic_feedback: set[int] = set()
        self._last_received_strategic_signal: str | None = None
        self._last_strategic_path: str | None = None
        self._strategic_feedback_count = 0
        self._latent_belief = LatentContextBeliefTracker()
        self._processed_latent_feedback: set[int] = set()
        self._latent_field_evidence_rounds: set[int] = set()
        self._latent_feedback_count = 0
        self._last_latent_signal: str | None = None
        self._last_latent_path: str | None = None
        self._effective_signal_trust = 0.8
        self._effective_field_trust = 0.7
        self._latent_trust_mvc = 0.0
        self._latent_field_mvc = 0.0

    def reset(self, cop: CognitiveOperatingProfile) -> None:
        super().reset(cop)
        self._risk_shifted = False
        self._last_rule_version = None
        self._source_reliability = SourceReliabilityTracker(prior_strength=2.0)
        self._mvc_estimator = OnlineMVCValueEstimator()
        self._processed_signal_feedback = set()
        self._last_selected_source = None
        self._context_reliability = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
        self._context_mvc = ContextualMVCValueEstimator(backoff_strength=1.0)
        self._processed_strategic_feedback = set()
        self._last_received_strategic_signal = None
        self._last_strategic_path = None
        self._strategic_feedback_count = 0
        self._latent_belief = LatentContextBeliefTracker()
        self._processed_latent_feedback = set()
        self._latent_field_evidence_rounds = set()
        self._latent_feedback_count = 0
        self._last_latent_signal = None
        self._last_latent_path = None
        self._effective_signal_trust = 0.8
        self._effective_field_trust = 0.7
        self._latent_trust_mvc = 0.0
        self._latent_field_mvc = 0.0

    def _process_signal_feedback(self, public_state: dict[str, Any]) -> None:
        feedback = public_state.get("feedback")
        if not isinstance(feedback, dict):
            return
        round_index = int(feedback.get("round_index", -1))
        if round_index < 0 or round_index in self._processed_signal_feedback:
            return
        claims = dict(public_state.get("source_claims", {}))
        correctness = dict(feedback.get("correctness", {}))
        for source_id, correct in correctness.items():
            declared = float(claims.get(source_id, 0.5))
            self._source_reliability.record(source_id, declared, correct=bool(correct))
            self._mvc_estimator.update(f"observe:{source_id}", 1.0 if bool(correct) else -1.0)
        self._processed_signal_feedback.add(round_index)

    def _signal_hazard_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_signal_feedback(public_state)
        round_index = int(public_state["round_index"])
        current = self._signal_hazard_observations(round_index)
        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
        if current:
            observation = current[-1]
            trust = self._source_reliability.estimate(observation.source_id, observation.reliability)
            conservative = trust < 0.5 and self.current_cop.risk >= 0.7
            route = self._signal_route(str(observation.payload["signal"]), conservative=conservative)
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": route},
            )

        if budget.observation_units > 0 and not (self.current_cop.latency >= 0.9 and self.current_cop.observation <= 0.3):
            ranked: list[tuple[float, str]] = []
            for source_id, declared in claims.items():
                reliability = self._source_reliability.estimate(source_id, declared)
                candidate = ObservationCandidate(
                    f"query://signal/{source_id}",
                    information_gain=0.5,
                    decision_value=0.9,
                    risk_reduction=0.9,
                    compression=0.4,
                    cost=Budget(observation_units=1),
                    reliability=reliability,
                    source_id=source_id,
                )
                coe_value = value_observation(candidate, self.current_cop)
                learned = self._mvc_estimator.estimate(f"observe:{source_id}", fallback=coe_value)
                score = 0.75 * coe_value + 0.25 * learned
                ranked.append((score, source_id))
            source = max(ranked, key=lambda item: (item[0], item[1]))[1]
            self._last_selected_source = source
            return AgentDecision(
                "cog://observe@0.1",
                Budget(compute_units=1),
                query={"type": "signal", "source": source},
            )

        route = "FAST" if self.current_cop.latency >= self.current_cop.risk else "SAFE"
        return AgentDecision(
            "cog://commit@0.1",
            Budget(compute_units=1, action_units=1),
            action={"type": "choose", "route": route},
        )

    def _process_strategic_feedback(self, public_state: dict[str, Any]) -> None:
        feedback = public_state.get("feedback")
        if not isinstance(feedback, dict):
            return
        round_index = int(feedback.get("round_index", -1))
        if round_index < 0 or round_index in self._processed_strategic_feedback:
            return
        context = str(feedback.get("context", "UNKNOWN"))
        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}

        signal_correct = feedback.get("signal_correct")
        if signal_correct is not None and feedback.get("signal_claim") is not None:
            declared = claims.get("agent://signaler", 0.8)
            correct = bool(signal_correct)
            self._context_reliability.record("agent://signaler", context, declared, correct=correct)
            loss = float(feedback.get("avoidable_receiver_loss", 0.0))
            gain = 1.0 if correct else -(1.0 + loss)
            self._context_mvc.update("trust_signal", "agent://signaler", context, gain)

        field_correct = feedback.get("field_correct")
        if field_correct is not None and feedback.get("field_signal") is not None:
            declared = claims.get("sensor://field", 0.7)
            correct = bool(field_correct)
            self._context_reliability.record("sensor://field", context, declared, correct=correct)
            self._context_mvc.update("observe_field", "sensor://field", context, 1.0 if correct else -1.0)

        self._processed_strategic_feedback.add(round_index)
        self._strategic_feedback_count += 1

    def _strategic_signal_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_strategic_feedback(public_state)
        role = public_state.get("role")
        phase = public_state.get("phase")

        if role == "signaler":
            if phase != "SIGNAL":
                return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "wait"})
            truth = str(public_state["current_truth"])
            context = str(public_state.get("own_incentive", public_state.get("context", "ALIGNED")))
            claim = truth if context == "ALIGNED" else self._flip_signal(truth)
            self._last_strategic_path = "truthful_signal" if claim == truth else "deceptive_signal"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "send_signal", "claim": claim},
            )

        if phase == "SIGNAL":
            self._last_strategic_path = "wait_for_signal"
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "wait"})

        round_index = int(public_state["round_index"])
        context = str(public_state.get("context", "UNKNOWN"))
        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
        field_obs = self._strategic_field_observations(round_index)
        if field_obs:
            signal = str(field_obs[-1].payload["signal"])
            self._last_strategic_path = "act_from_field"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": self._signal_route(signal)},
            )

        signal = public_state.get("opponent_signal")
        self._last_received_strategic_signal = None if signal is None else str(signal)
        if signal is None:
            if budget.observation_units > 0:
                self._last_strategic_path = "observe_field"
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})
            route = "SAFE" if self.current_cop.risk >= self.current_cop.latency else "FAST"
            self._last_strategic_path = "conservative_no_signal"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": route},
            )

        signaler_declared = claims.get("agent://signaler", 0.8)
        field_declared = claims.get("sensor://field", 0.7)
        signaler_trust = self._context_reliability.estimate("agent://signaler", context, signaler_declared)
        field_trust = self._context_reliability.estimate("sensor://field", context, field_declared)
        trust_mvc = self._context_mvc.estimate("trust_signal", "agent://signaler", context, fallback=0.0)
        field_mvc = self._context_mvc.estimate(
            "observe_field", "sensor://field", context, fallback=0.0, exploration_weight=0.03
        )
        trust_score = signaler_trust + 0.20 * trust_mvc + 0.05 * self.current_cop.latency
        field_score = (
            field_trust
            + 0.20 * field_mvc
            + 0.08 * self.current_cop.observation
            + 0.05 * self.current_cop.risk
            - 0.08
        )
        if budget.observation_units > 0 and field_score > trust_score:
            self._last_strategic_path = "observe_field"
            return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})

        self._last_strategic_path = "trust_signal"
        return AgentDecision(
            "cog://commit@0.1",
            Budget(compute_units=1, action_units=1),
            action={"type": "choose", "route": self._signal_route(str(signal))},
        )

    def _refresh_latent_effective_values(self, public_state: dict[str, Any]) -> None:
        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
        belief = self._latent_belief.belief()
        signaler_declared = claims.get("agent://signaler", 0.8)
        field_declared = claims.get("sensor://field", 0.7)
        self._effective_signal_trust = self._context_reliability.estimate_belief(
            "agent://signaler", belief, signaler_declared
        )
        self._effective_field_trust = self._context_reliability.estimate_belief(
            "sensor://field", belief, field_declared
        )
        self._latent_trust_mvc = self._context_mvc.estimate_belief(
            "trust_signal", "agent://signaler", belief, fallback=0.0
        )
        self._latent_field_mvc = self._context_mvc.estimate_belief(
            "observe_field", "sensor://field", belief, fallback=0.0, exploration_weight=0.03
        )

    def _process_latent_feedback(self, public_state: dict[str, Any]) -> None:
        feedback = public_state.get("feedback")
        if not isinstance(feedback, dict):
            return
        round_index = int(feedback.get("round_index", -1))
        if round_index < 0 or round_index in self._processed_latent_feedback:
            return
        posterior = self._latent_belief.update_from_feedback(
            signal_correct=feedback.get("signal_correct"),
            receiver_utility=float(feedback.get("receiver_utility", 0.0)),
            signaler_utility=float(feedback.get("signaler_utility", 0.0)),
            avoidable_loss=float(feedback.get("avoidable_receiver_loss", 0.0)),
        )
        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
        signal_correct = feedback.get("signal_correct")
        if signal_correct is not None and feedback.get("signal_claim") is not None:
            correct = bool(signal_correct)
            self._context_reliability.record_belief(
                "agent://signaler", posterior, claims.get("agent://signaler", 0.8), correct=correct
            )
            loss = float(feedback.get("avoidable_receiver_loss", 0.0))
            gain = 1.0 if correct else -(1.0 + loss)
            self._context_mvc.update_belief(
                "trust_signal", "agent://signaler", posterior, gain
            )
        field_correct = feedback.get("field_correct")
        if field_correct is not None and feedback.get("field_signal") is not None:
            correct = bool(field_correct)
            self._context_reliability.record_belief(
                "sensor://field", posterior, claims.get("sensor://field", 0.7), correct=correct
            )
            self._context_mvc.update_belief(
                "observe_field", "sensor://field", posterior, 1.0 if correct else -1.0
            )
        self._processed_latent_feedback.add(round_index)
        self._latent_feedback_count += 1
        self._latent_belief.predict_next()

    def _apply_latent_field_evidence(
        self, public_state: dict[str, Any], observation: ObservationResult
    ) -> None:
        round_index = int(public_state.get("round_index", -1))
        if round_index < 0 or round_index in self._latent_field_evidence_rounds:
            return
        opponent_signal = public_state.get("opponent_signal")
        field_signal = observation.payload.get("signal")
        if opponent_signal is None or field_signal is None:
            return
        self._refresh_latent_effective_values(public_state)
        self._latent_belief.update_from_signal_check(
            signal_matches=str(opponent_signal) == str(field_signal),
            observer_reliability=max(float(observation.reliability), self._effective_field_trust),
        )
        self._latent_field_evidence_rounds.add(round_index)

    def _latent_context_signal_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_latent_feedback(public_state)
        role = public_state.get("role")
        phase = public_state.get("phase")
        if role == "signaler":
            if phase != "SIGNAL":
                return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "wait"})
            truth = str(public_state["current_truth"])
            incentive = str(public_state.get("own_incentive", "ALIGNED"))
            claim = truth if incentive == "ALIGNED" else self._flip_signal(truth)
            self._last_latent_path = "truthful_signal" if claim == truth else "deceptive_signal"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "send_signal", "claim": claim},
            )
        if phase == "SIGNAL":
            self._last_latent_path = "wait_for_signal"
            self._refresh_latent_effective_values(public_state)
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "wait"})

        round_index = int(public_state["round_index"])
        field_obs = self._strategic_field_observations(round_index)
        if field_obs:
            observation = field_obs[-1]
            self._apply_latent_field_evidence(public_state, observation)
            self._refresh_latent_effective_values(public_state)
            self._last_latent_path = "act_from_field"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": self._signal_route(str(observation.payload["signal"]))},
            )

        signal = public_state.get("opponent_signal")
        self._last_latent_signal = None if signal is None else str(signal)
        self._refresh_latent_effective_values(public_state)
        if signal is None:
            if budget.observation_units > 0:
                self._last_latent_path = "observe_field"
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})
            route = "SAFE" if self.current_cop.risk >= self.current_cop.latency else "FAST"
            self._last_latent_path = "conservative_no_signal"
            return AgentDecision(
                "cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": route}
            )

        entropy = self._latent_belief.entropy()
        trust_score = self._effective_signal_trust + 0.20 * self._latent_trust_mvc + 0.05 * self.current_cop.latency
        field_score = (
            self._effective_field_trust
            + 0.20 * self._latent_field_mvc
            + 0.08 * self.current_cop.observation
            + 0.05 * self.current_cop.risk
            + 0.08 * entropy
            - 0.08
        )
        if budget.observation_units > 0 and field_score > trust_score:
            self._last_latent_path = "observe_field"
            return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})
        self._last_latent_path = "trust_signal"
        return AgentDecision(
            "cog://commit@0.1",
            Budget(compute_units=1, action_units=1),
            action={"type": "choose", "route": self._signal_route(str(signal))},
        )

    def latent_context_snapshot(self) -> dict[str, Any]:
        return {
            "belief": self._latent_belief.snapshot(),
            "reliability": self._context_reliability.snapshot(),
            "mvc": self._context_mvc.snapshot(),
            "effective_signal_trust": float(self._effective_signal_trust),
            "effective_field_trust": float(self._effective_field_trust),
            "trust_signal_mvc": float(self._latent_trust_mvc),
            "observe_field_mvc": float(self._latent_field_mvc),
            "last_received_signal": self._last_latent_signal,
            "last_selected_path": self._last_latent_path,
            "feedback_count": self._latent_feedback_count,
        }

    def deception_snapshot(self) -> dict[str, Any]:
        return {
            "reliability": self._context_reliability.snapshot(),
            "mvc": self._context_mvc.snapshot(),
            "last_received_signal": self._last_received_strategic_signal,
            "last_selected_path": self._last_strategic_path,
            "field_check_selected": self._last_strategic_path == "observe_field",
            "feedback_count": self._strategic_feedback_count,
        }

    def calibration_snapshot(self) -> dict[str, Any]:
        return {
            "reliability": self._source_reliability.snapshot(),
            "mvc": self._mvc_estimator.snapshot(),
            "last_selected_source": self._last_selected_source,
        }

    def _maybe_shift(self, public_state: dict[str, Any]) -> ProfileReceipt | None:
        current_rule_version = int(public_state.get("rule_version", 1))
        rule_changed = self._last_rule_version is not None and current_rule_version > self._last_rule_version
        self._last_rule_version = current_rule_version
        if rule_changed:
            old = self.current_cop
            new = replace(
                old,
                verification=max(old.verification, 0.9),
                observation=max(old.observation, 0.8),
                abstraction=max(old.abstraction, 0.7),
                commitment=max(old.commitment, 0.8),
            )
            self.current_cop = new
            return ProfileReceipt.create(old.to_dict(), new.to_dict(), "rule_shift_trigger")

        hazard_observed = any(bool(o.payload.get("hazard")) for o in self.observations if "hazard" in o.payload)
        catastrophic_regime = any(o.payload.get("regime") == "FAST_CATASTROPHIC" for o in self.observations)
        risk_trigger = hazard_observed or catastrophic_regime or int(public_state.get("hazard_hits", 0)) > 0
        if not risk_trigger or self._risk_shifted:
            return None
        old = self.current_cop
        new = replace(
            old,
            risk=max(old.risk, 0.9),
            verification=max(old.verification, 0.9),
            observation=max(old.observation, 0.8),
            commitment=max(old.commitment, 0.8),
        )
        self.current_cop = new
        self._risk_shifted = True
        return ProfileReceipt.create(old.to_dict(), new.to_dict(), "risk_trigger")

    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        receipt = self._maybe_shift(public_state)
        if public_state.get("world_kind") == "latent_context_signal_duel":
            decision = self._latent_context_signal_decide(public_state, budget)
        elif public_state.get("world_kind") == "strategic_signal_duel":
            decision = self._strategic_signal_decide(public_state, budget)
        elif public_state.get("world_kind") == "signal_hazard":
            decision = self._signal_hazard_decide(public_state, budget)
        else:
            decision = super().decide(public_state, budget)
        if receipt is None:
            return decision
        return AgentDecision(
            cognition_operator=decision.cognition_operator,
            compute_cost=decision.compute_cost,
            query=decision.query,
            action=decision.action,
            profile_receipt=receipt,
        )


class B4LMetaLearnedAgent(B4APSCAdaptiveCOPAgent):
    """B4 latent-context agent whose trust/observe ranking is learned from experience."""

    def __init__(
        self,
        agent_id: str,
        *,
        model: ExperienceMetaValueModel | None = None,
        training: bool = False,
        observation_penalty: float = 0.15,
    ) -> None:
        super().__init__(agent_id)
        if float(observation_penalty) < 0.0:
            raise ValueError("observation_penalty must be non-negative")
        self.meta_model = model if model is not None else ExperienceMetaValueModel()
        self.training = bool(training)
        self.observation_penalty = float(observation_penalty)
        self._episode_id = "episode://unassigned"
        self._pending_meta: dict[str, Any] | None = None
        self._processed_meta_feedback: set[int] = set()
        self._meta_experiences: list[CognitiveExperience] = []
        self._last_meta_features: MetaStateFeatures | None = None
        self._last_meta_predictions: dict[str, float] = {}
        self._last_meta_operation: str | None = None

    def set_episode_id(self, episode_id: str) -> None:
        self._episode_id = str(episode_id)

    def reset(self, cop: CognitiveOperatingProfile) -> None:
        super().reset(cop)
        self._pending_meta = None
        self._processed_meta_feedback = set()
        self._meta_experiences = []
        self._last_meta_features = None
        self._last_meta_predictions = {}
        self._last_meta_operation = None

    def _meta_features(
        self,
        public_state: dict[str, Any],
        budget: Budget,
        signal: str | None,
    ) -> MetaStateFeatures:
        belief = self._latent_belief.belief()
        rounds_total = max(int(public_state.get("rounds_total", 1)), 1)
        round_index = max(int(public_state.get("round_index", 0)), 0)
        round_fraction = 0.0 if rounds_total <= 1 else min(round_index / float(rounds_total - 1), 1.0)
        return MetaStateFeatures.from_mapping(
            {
                "belief_aligned": belief["ALIGNED"],
                "belief_competitive": belief["COMPETITIVE"],
                "belief_entropy": min(max(self._latent_belief.entropy(), 0.0), 1.0),
                "effective_signal_trust": self._effective_signal_trust,
                "effective_field_trust": self._effective_field_trust,
                "handcrafted_trust_mvc": self._latent_trust_mvc,
                "handcrafted_field_mvc": self._latent_field_mvc,
                "round_fraction": round_fraction,
                "observation_available": budget.observation_units > 0,
                "signal_is_catastrophic": str(signal) == "FAST_CATASTROPHIC",
            }
        )

    def _remember_meta_choice(
        self,
        public_state: dict[str, Any],
        operation: str,
        features: MetaStateFeatures,
    ) -> None:
        self._pending_meta = {
            "round_index": int(public_state.get("round_index", 0)),
            "operation": operation,
            "features": features,
            "observation_cost": self.observation_penalty if operation == "observe_field" else 0.0,
        }
        self._last_meta_features = features
        self._last_meta_operation = operation

    def _process_meta_feedback(self, public_state: dict[str, Any]) -> None:
        feedback = public_state.get("feedback")
        if not isinstance(feedback, dict):
            return
        round_index = int(feedback.get("round_index", -1))
        if round_index < 0 or round_index in self._processed_meta_feedback:
            return
        pending = self._pending_meta
        if pending is not None and int(pending["round_index"]) == round_index:
            operation = str(pending["operation"])
            observation_cost = float(pending["observation_cost"])
            realized_value = float(feedback.get("receiver_utility", 0.0)) - observation_cost
            experience = CognitiveExperience(
                experience_id=f"exp://{self.agent_id}/{self._episode_id.rsplit('/', 1)[-1]}/{round_index}/{operation}",
                episode_id=self._episode_id,
                round_index=round_index,
                operation=operation,
                features=pending["features"],
                realized_value=realized_value,
                observation_cost=observation_cost,
            )
            self._meta_experiences.append(experience)
            if self.training:
                self.meta_model.update(experience)
            self._pending_meta = None
        self._processed_meta_feedback.add(round_index)

    @staticmethod
    def _handcrafted_latent_scores(
        *,
        effective_signal_trust: float,
        effective_field_trust: float,
        trust_mvc: float,
        field_mvc: float,
        entropy: float,
        cop: CognitiveOperatingProfile,
    ) -> tuple[float, float]:
        trust_score = effective_signal_trust + 0.20 * trust_mvc + 0.05 * cop.latency
        field_score = (
            effective_field_trust
            + 0.20 * field_mvc
            + 0.08 * cop.observation
            + 0.05 * cop.risk
            + 0.08 * entropy
            - 0.08
        )
        return trust_score, field_score

    def _choose_meta_operation(
        self,
        *,
        public_state: dict[str, Any],
        budget: Budget,
        features: MetaStateFeatures,
        trust_value: float,
        field_value: float,
    ) -> str:
        if budget.observation_units > 0 and field_value > trust_value:
            return "observe_field"
        return "trust_signal"

    def _latent_context_signal_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_meta_feedback(public_state)
        self._process_latent_feedback(public_state)
        role = public_state.get("role")
        phase = public_state.get("phase")

        # Signaler behavior and SIGNAL-phase waiting remain the B4 reference behavior.
        if role == "signaler" or phase == "SIGNAL":
            return super()._latent_context_signal_decide(public_state, budget)

        round_index = int(public_state["round_index"])
        field_obs = self._strategic_field_observations(round_index)
        if field_obs:
            observation = field_obs[-1]
            self._apply_latent_field_evidence(public_state, observation)
            self._refresh_latent_effective_values(public_state)
            self._last_latent_path = "act_from_field"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": self._signal_route(str(observation.payload["signal"]))},
            )

        signal = public_state.get("opponent_signal")
        self._last_latent_signal = None if signal is None else str(signal)
        self._refresh_latent_effective_values(public_state)
        features = self._meta_features(public_state, budget, None if signal is None else str(signal))

        if signal is None:
            if budget.observation_units > 0:
                self._last_meta_predictions = {"observe_field": self._effective_field_trust}
                self._remember_meta_choice(public_state, "observe_field", features)
                self._last_latent_path = "observe_field"
                return AgentDecision(
                    "cog://observe@0.1",
                    Budget(compute_units=1),
                    query={"type": "signal", "source": "sensor://field"},
                )
            route = "SAFE" if self.current_cop.risk >= self.current_cop.latency else "FAST"
            self._last_latent_path = "conservative_no_signal"
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": route},
            )

        trust_fallback, field_fallback = self._handcrafted_latent_scores(
            effective_signal_trust=self._effective_signal_trust,
            effective_field_trust=self._effective_field_trust,
            trust_mvc=self._latent_trust_mvc,
            field_mvc=self._latent_field_mvc,
            entropy=self._latent_belief.entropy(),
            cop=self.current_cop,
        )
        trust_value = self.meta_model.estimate("trust_signal", features, fallback=trust_fallback)
        field_value = self.meta_model.estimate("observe_field", features, fallback=field_fallback)
        self._last_meta_predictions = {
            "trust_signal": float(trust_value),
            "observe_field": float(field_value),
            "handcrafted_trust": float(trust_fallback),
            "handcrafted_observe": float(field_fallback),
        }

        selected_operation = self._choose_meta_operation(
            public_state=public_state,
            budget=budget,
            features=features,
            trust_value=trust_value,
            field_value=field_value,
        )
        if selected_operation == "observe_field":
            self._remember_meta_choice(public_state, "observe_field", features)
            self._last_latent_path = "observe_field"
            return AgentDecision(
                "cog://observe@0.1",
                Budget(compute_units=1),
                query={"type": "signal", "source": "sensor://field"},
            )

        self._remember_meta_choice(public_state, "trust_signal", features)
        self._last_latent_path = "trust_signal"
        return AgentDecision(
            "cog://commit@0.1",
            Budget(compute_units=1, action_units=1),
            action={"type": "choose", "route": self._signal_route(str(signal))},
        )

    def meta_learning_snapshot(self) -> dict[str, Any]:
        return {
            "training_mode": self.training,
            "model_hash": self.meta_model.model_hash(),
            "experience_count": self.meta_model.total_experiences(),
            "episode_experience_count": len(self._meta_experiences),
            "last_features": None if self._last_meta_features is None else self._last_meta_features.to_dict(),
            "predicted_values": dict(self._last_meta_predictions),
            "last_selected_operation": self._last_meta_operation,
        }

    def meta_experience_log(self) -> list[dict[str, Any]]:
        return [experience.to_dict() for experience in self._meta_experiences]

class B4XExplorationMetaAgent(B4LMetaLearnedAgent):
    """B4L with deterministic coverage exploration and uncertainty-aware ranking."""

    def __init__(
        self,
        agent_id: str,
        *,
        model: ExperienceMetaValueModel | None = None,
        training: bool = False,
        observation_penalty: float = 0.15,
        coverage_floor: int = 2,
        uncertainty_bonus: float = 0.35,
    ) -> None:
        super().__init__(
            agent_id,
            model=model,
            training=training,
            observation_penalty=observation_penalty,
        )
        self.meta_selector = UncertaintyAwareMetaSelector(
            coverage_floor=coverage_floor,
            uncertainty_bonus=uncertainty_bonus,
        )
        self._episode_operation_counts = {"trust_signal": 0, "observe_field": 0}
        self._meta_exploration_rows: list[dict[str, Any]] = []
        self._last_exploration: dict[str, Any] | None = None

    def reset(self, cop: CognitiveOperatingProfile) -> None:
        super().reset(cop)
        self._episode_operation_counts = {"trust_signal": 0, "observe_field": 0}
        self._meta_exploration_rows = []
        self._last_exploration = None

    def _choose_meta_operation(
        self,
        *,
        public_state: dict[str, Any],
        budget: Budget,
        features: MetaStateFeatures,
        trust_value: float,
        field_value: float,
    ) -> str:
        feasible = {"trust_signal"}
        if budget.observation_units > 0:
            feasible.add("observe_field")
        learned = {"trust_signal": float(trust_value), "observe_field": float(field_value)}
        uncertainties = {
            operation: self.meta_model.uncertainty(operation, features)
            for operation in ("trust_signal", "observe_field")
        }
        selection = self.meta_selector.select(
            learned_values=learned,
            uncertainties=uncertainties,
            episode_counts=self._episode_operation_counts,
            feasible_operations=feasible,
            training=self.training,
            round_index=int(public_state.get("round_index", 0)),
        )
        operation = selection.selected_operation
        self._episode_operation_counts[operation] += 1
        row = {
            "round_index": int(public_state.get("round_index", 0)),
            "selected_operation": operation,
            "selection_reason": selection.selection_reason,
            "greedy_operation": selection.greedy_operation,
            "learned_values": dict(selection.learned_values),
            "uncertainties": dict(selection.uncertainties),
            "rank_scores": dict(selection.rank_scores),
            "episode_operation_counts": dict(self._episode_operation_counts),
        }
        self._meta_exploration_rows.append(row)
        self._last_exploration = row
        return operation

    def finalize_episode(self, public_state: dict[str, Any]) -> None:
        self._process_meta_feedback(public_state)
        self._process_latent_feedback(public_state)

    def meta_exploration_log(self) -> list[dict[str, Any]]:
        return [dict(row) for row in self._meta_exploration_rows]

    def meta_learning_snapshot(self) -> dict[str, Any]:
        payload = super().meta_learning_snapshot()
        payload["exploration"] = None if self._last_exploration is None else dict(self._last_exploration)
        payload["episode_operation_counts"] = dict(self._episode_operation_counts)
        return payload


class B4GGeneralizingMetaAgent(B4APSCAdaptiveCOPAgent):
    """World-neutral learned cognition ranking over B4 world-local calibration."""

    def __init__(
        self,
        agent_id: str,
        *,
        value_model: CrossWorldMetaValueModel | None = None,
        exploration_policy: LearnedExplorationPolicyModel | None = None,
        exploration_threshold: float = 0.0,
    ) -> None:
        super().__init__(agent_id)
        self.generalized_value_model = value_model if value_model is not None else CrossWorldMetaValueModel()
        self.generalized_exploration_policy = (
            exploration_policy if exploration_policy is not None else LearnedExplorationPolicyModel()
        )
        self.exploration_threshold = float(exploration_threshold)
        self._last_generalization: dict[str, Any] | None = None

    def reset(self, cop: CognitiveOperatingProfile) -> None:
        super().reset(cop)
        self._last_generalization = None

    @staticmethod
    def _clip_gap(value: float) -> float:
        return min(max(abs(float(value)), 0.0), 1.0)

    def _select_generalized_operation(
        self,
        *,
        features: Any,
        trust_fallback: float,
        verify_fallback: float,
        verify_feasible: bool,
        source_world: str,
    ) -> str:
        trust_prediction = self.generalized_value_model.predict(
            "trust_primary", features, fallback=float(trust_fallback)
        )
        verify_prediction = self.generalized_value_model.predict(
            "verify_independent", features, fallback=float(verify_fallback)
        )
        greedy = (
            "verify_independent"
            if verify_feasible and verify_prediction.expected_value > trust_prediction.expected_value
            else "trust_primary"
        )
        selected = greedy
        reason = "generalized_greedy"
        policy_features = ExplorationPolicyFeatures.from_mapping(
            {
                "state_uncertainty": float(features.uncertainty),
                "value_gap": self._clip_gap(verify_prediction.expected_value - trust_prediction.expected_value),
                "uncertainty_gap": self._clip_gap(
                    verify_prediction.combined_uncertainty - trust_prediction.combined_uncertainty
                ),
                "observation_cost_fraction": float(features.observation_cost_fraction),
            }
        )
        policy_prediction = self.generalized_exploration_policy.predict(policy_features)
        if (
            greedy == "trust_primary"
            and verify_feasible
            and policy_prediction.evidence_weight > 0.0
            and policy_prediction.expected_advantage > self.exploration_threshold
        ):
            selected = "verify_independent"
            reason = "learned_exploration"
        self._last_generalization = {
            "source_world": source_world,
            "features": features.to_dict(),
            "predictions": {
                "trust_primary": {
                    "expected_value": trust_prediction.expected_value,
                    "epistemic_uncertainty": trust_prediction.epistemic_uncertainty,
                    "target_uncertainty": trust_prediction.target_uncertainty,
                    "combined_uncertainty": trust_prediction.combined_uncertainty,
                    "evidence_weight": trust_prediction.evidence_weight,
                },
                "verify_independent": {
                    "expected_value": verify_prediction.expected_value,
                    "epistemic_uncertainty": verify_prediction.epistemic_uncertainty,
                    "target_uncertainty": verify_prediction.target_uncertainty,
                    "combined_uncertainty": verify_prediction.combined_uncertainty,
                    "evidence_weight": verify_prediction.evidence_weight,
                },
            },
            "greedy_operation": greedy,
            "selected_operation": selected,
            "selection_reason": reason,
            "exploration_policy": {
                "features": policy_features.to_dict(),
                "expected_advantage": policy_prediction.expected_advantage,
                "epistemic_uncertainty": policy_prediction.epistemic_uncertainty,
                "evidence_weight": policy_prediction.evidence_weight,
            },
            "value_model_hash": self.generalized_value_model.model_hash(),
            "exploration_policy_hash": self.generalized_exploration_policy.model_hash(),
        }
        return selected

    def _generalized_signal_hazard_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_signal_feedback(public_state)
        round_index = int(public_state["round_index"])
        current = self._signal_hazard_observations(round_index)
        if current:
            return super()._signal_hazard_decide(public_state, budget)
        if budget.observation_units <= 0:
            return super()._signal_hazard_decide(public_state, budget)

        claims = {str(k): float(v) for k, v in dict(public_state.get("source_claims", {})).items()}
        primary_trust = self._source_reliability.estimate("advisor://deceptive", claims.get("advisor://deceptive", 0.9))
        verifier_trust = self._source_reliability.estimate("sensor://field", claims.get("sensor://field", 0.7))
        primary_mvc = self._mvc_estimator.estimate("observe:advisor://deceptive", fallback=0.0)
        verify_mvc = self._mvc_estimator.estimate("observe:sensor://field", fallback=0.0)
        trust_fallback = primary_trust + 0.20 * primary_mvc + 0.05 * self.current_cop.latency
        verify_fallback = (
            verifier_trust
            + 0.20 * verify_mvc
            + 0.08 * self.current_cop.observation
            + 0.05 * self.current_cop.risk
            - 0.08
        )
        features = project_signal_hazard_features(
            public_state,
            budget,
            primary_trust=primary_trust,
            verifier_trust=verifier_trust,
            primary_value_prior=primary_mvc,
            verify_value_prior=verify_mvc,
            primary_signal=None,
            verifier_signal=None,
        )
        selected = self._select_generalized_operation(
            features=features,
            trust_fallback=trust_fallback,
            verify_fallback=verify_fallback,
            verify_feasible=True,
            source_world="SignalHazard-v0.4",
        )
        source = "sensor://field" if selected == "verify_independent" else "advisor://deceptive"
        self._last_selected_source = source
        return AgentDecision(
            "cog://observe@0.1",
            Budget(compute_units=1),
            query={"type": "signal", "source": source},
        )

    def _generalized_latent_context_decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        self._process_latent_feedback(public_state)
        role = public_state.get("role")
        phase = public_state.get("phase")
        if role == "signaler" or phase == "SIGNAL":
            return super()._latent_context_signal_decide(public_state, budget)

        round_index = int(public_state["round_index"])
        field_obs = self._strategic_field_observations(round_index)
        if field_obs:
            return super()._latent_context_signal_decide(public_state, budget)
        signal = public_state.get("opponent_signal")
        if signal is None:
            return super()._latent_context_signal_decide(public_state, budget)

        self._last_latent_signal = str(signal)
        self._refresh_latent_effective_values(public_state)
        trust_fallback, verify_fallback = B4LMetaLearnedAgent._handcrafted_latent_scores(
            effective_signal_trust=self._effective_signal_trust,
            effective_field_trust=self._effective_field_trust,
            trust_mvc=self._latent_trust_mvc,
            field_mvc=self._latent_field_mvc,
            entropy=self._latent_belief.entropy(),
            cop=self.current_cop,
        )
        features = project_latent_context_features(
            public_state,
            budget,
            belief_entropy=self._latent_belief.entropy(),
            primary_trust=self._effective_signal_trust,
            verifier_trust=self._effective_field_trust,
            primary_value_prior=self._latent_trust_mvc,
            verify_value_prior=self._latent_field_mvc,
            primary_signal=str(signal),
            verifier_signal=None,
        )
        selected = self._select_generalized_operation(
            features=features,
            trust_fallback=trust_fallback,
            verify_fallback=verify_fallback,
            verify_feasible=budget.observation_units > 0,
            source_world="LatentContextSignalDuel-v0.6",
        )
        if selected == "verify_independent" and budget.observation_units > 0:
            self._last_latent_path = "observe_field"
            return AgentDecision(
                "cog://observe@0.1",
                Budget(compute_units=1),
                query={"type": "signal", "source": "sensor://field"},
            )
        self._last_latent_path = "trust_signal"
        return AgentDecision(
            "cog://commit@0.1",
            Budget(compute_units=1, action_units=1),
            action={"type": "choose", "route": self._signal_route(str(signal))},
        )

    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        receipt = self._maybe_shift(public_state)
        if public_state.get("world_kind") == "signal_hazard":
            decision = self._generalized_signal_hazard_decide(public_state, budget)
        elif public_state.get("world_kind") == "latent_context_signal_duel":
            decision = self._generalized_latent_context_decide(public_state, budget)
        else:
            decision = super().decide(public_state, budget)
        if receipt is None or decision.profile_receipt is not None:
            return decision
        return AgentDecision(
            cognition_operator=decision.cognition_operator,
            compute_cost=decision.compute_cost,
            query=decision.query,
            action=decision.action,
            profile_receipt=receipt,
        )

    def meta_generalization_snapshot(self) -> dict[str, Any]:
        payload = {
            "value_model_hash": self.generalized_value_model.model_hash(),
            "exploration_policy_hash": self.generalized_exploration_policy.model_hash(),
        }
        if self._last_generalization is not None:
            payload.update(self._last_generalization)
        return payload


class B2FixedSearchVerifyAgent(B1FixedDepthAgent):
    """Fixed search/verify baseline: exhaust local observations before acting."""

    def decide(self, public_state: dict[str, Any], budget: Budget) -> AgentDecision:
        if self._is_strategic_world(public_state):
            if public_state.get("role") == "signaler":
                action = (
                    {"type": "send_signal", "claim": self._fixed_strategic_signal(public_state)}
                    if public_state.get("phase") == "SIGNAL"
                    else {"type": "wait"}
                )
                return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
            if public_state.get("phase") == "SIGNAL":
                return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "wait"})
            round_index = int(public_state["round_index"])
            field = self._strategic_field_observations(round_index)
            if not field and budget.observation_units > 0:
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "sensor://field"})
            signal = str(field[-1].payload["signal"]) if field else str(public_state.get("opponent_signal") or "FAST_CATASTROPHIC")
            return AgentDecision(
                "cog://commit@0.1",
                Budget(compute_units=1, action_units=1),
                action={"type": "choose", "route": self._signal_route(signal)},
            )
        if public_state.get("world_kind") == "hazard_choice":
            regime = self._hazard_choice_regime()
            if regime is None and budget.observation_units > 0:
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "probe", "target": "route-regime"})
            route = "SAFE" if regime == "FAST_CATASTROPHIC" else "FAST"
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": route})
        if public_state.get("world_kind") == "signal_hazard":
            round_index = int(public_state["round_index"])
            current = [o for o in self._signal_hazard_observations(round_index) if o.source_id == "advisor://deceptive"]
            if not current and budget.observation_units > 0:
                return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "signal", "source": "advisor://deceptive"})
            signal = current[-1].payload["signal"] if current else "FAST_SAFE"
            route = self._signal_route(str(signal))
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "choose", "route": route})
        if public_state.get("world_kind") == "negotiation_split":
            offer = public_state.get("outstanding_offer")
            minimum = int(public_state["own_minimum"])
            if offer is not None and offer.get("receiver") == self.agent_id:
                action = {"type": "accept"} if int(offer["receiver_share"]) >= minimum else {"type": "reject"}
            elif offer is not None and offer.get("proposer") == self.agent_id:
                action = {"type": "wait"}
            else:
                ask = max(minimum, 5 - int(public_state.get("tick", 0)) // 2)
                action = {"type": "offer", "self_share": ask}
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
        if "candidates" in public_state:
            return super().decide(public_state, budget)
        hazards = self._hidden_route_known_hazards()
        neighbors = list(public_state.get("neighbors", []))
        known_safe = set(public_state.get("known_safe", []))
        safe_goal = next((target for target in neighbors if target in known_safe and target == public_state.get("goal")), None)
        if safe_goal is not None:
            return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action={"type": "move", "target": safe_goal})
        if budget.observation_units > 0:
            for target in neighbors:
                if target not in hazards and target not in known_safe:
                    return AgentDecision("cog://observe@0.1", Budget(compute_units=1), query={"type": "probe", "target": target})
        safe = [target for target in neighbors if hazards.get(target) is False or target in known_safe]
        non_hazard = [target for target in neighbors if hazards.get(target) is not True]
        target = safe[0] if safe else (non_hazard[0] if non_hazard else None)
        action = {"type": "wait"} if target is None else {"type": "move", "target": target}
        return AgentDecision("cog://commit@0.1", Budget(compute_units=1, action_units=1), action=action)
