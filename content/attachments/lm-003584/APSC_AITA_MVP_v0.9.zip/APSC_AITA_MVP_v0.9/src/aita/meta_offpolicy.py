from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from apsc.meta_exploration import MetaTrainingExperience
from apsc.meta_learning import CognitiveExperience


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not Path(path).exists():
        return []
    return [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def _route_from_signal(signal: str) -> str:
    return "SAFE" if str(signal) == "FAST_CATASTROPHIC" else "FAST"


def _receiver_utility(truth: str, route: str) -> float:
    if route == "SAFE":
        return 0.65
    return 1.0 if str(truth) == "FAST_SAFE" else -2.5


def _signal_claims_by_round(actions: list[dict[str, Any]]) -> dict[int, str | None]:
    result: dict[int, str | None] = {}
    for row in actions:
        before = dict(row.get("before", {})).get("agent://receiver", {})
        if before.get("phase") != "SIGNAL":
            continue
        round_index = int(before.get("round_index", -1))
        action = dict(row.get("action_bundle", {})).get("agent://signaler", {})
        if round_index < 0:
            continue
        if action.get("type") == "send_signal":
            result[round_index] = str(action.get("claim"))
        elif action.get("type") == "silence":
            result[round_index] = None
    return result


def build_counterfactual_experiences(
    run_dir: Path,
    *,
    observation_penalty: float,
    sample_weight: float = 0.5,
) -> list[MetaTrainingExperience]:
    """Create one alternate cognition target per actual receiver experience.

    Truth and deterministic field signals are post-outcome target labels only.
    The alternate row reuses the original action-time feature mapping exactly.
    """
    run_dir = Path(run_dir)
    if float(observation_penalty) < 0.0:
        raise ValueError("observation_penalty must be non-negative")
    if float(sample_weight) <= 0.0:
        raise ValueError("sample_weight must be positive")

    manifest = _read_json(run_dir / "world_manifest.json")
    initial = dict(manifest.get("initial_replay_state", {}))
    truths = list(initial.get("truths", []))
    field_signals = list(initial.get("field_signals", []))
    claims = _signal_claims_by_round(_read_jsonl(run_dir / "actions.jsonl"))
    actual_rows = [
        row for row in _read_jsonl(run_dir / "meta_experiences.jsonl")
        if row.get("agent_id") == "agent://receiver"
    ]

    counterfactuals: list[MetaTrainingExperience] = []
    for payload in actual_rows:
        actual = CognitiveExperience.from_dict(payload)
        idx = int(actual.round_index)
        if idx < 0 or idx >= len(truths) or idx >= len(field_signals):
            continue
        truth = str(truths[idx])
        alternate = "observe_field" if actual.operation == "trust_signal" else "trust_signal"
        if alternate == "observe_field":
            signal = str(field_signals[idx])
            observation_cost = float(observation_penalty)
        else:
            claim = claims.get(idx)
            if claim is None:
                continue
            signal = str(claim)
            observation_cost = 0.0
        route = _route_from_signal(signal)
        realized_value = _receiver_utility(truth, route) - observation_cost
        experience = CognitiveExperience(
            experience_id=f"cf://{actual.experience_id}",
            episode_id=actual.episode_id,
            round_index=idx,
            operation=alternate,
            features=actual.features,
            realized_value=realized_value,
            observation_cost=observation_cost,
        )
        counterfactuals.append(
            MetaTrainingExperience(
                experience=experience,
                source_kind="counterfactual_off_policy",
                sample_weight=float(sample_weight),
                behavior_operation=actual.operation,
                selection_reason="post_outcome_counterfactual",
                counterfactual_of=actual.experience_id,
            )
        )
    return counterfactuals
