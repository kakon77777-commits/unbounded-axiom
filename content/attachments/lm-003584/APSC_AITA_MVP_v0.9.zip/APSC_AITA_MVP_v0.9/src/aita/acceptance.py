from __future__ import annotations

from pathlib import Path
import hashlib
import json
import math

from aita.scoring import CANONICAL_METRICS


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _read_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def _gate(ok: bool, detail: str) -> dict[str, str]:
    return {"status": "PASS" if ok else "FAIL", "detail": detail}


def validate_run(run_dir: Path) -> dict[str, dict[str, str]]:
    episode_path = run_dir / "episode.json"
    episode = _read_json(episode_path) if episode_path.exists() else {}
    gates: dict[str, dict[str, str]] = {}

    is_duel = "baselines" in episode
    required_episode = (
        {"episode_id", "world_id", "seed", "baselines", "budgets", "profile_names", "status"}
        if is_duel
        else {"episode_id", "world_id", "seed", "baseline", "budget", "status"}
    )
    gates["A"] = _gate(required_episode <= set(episode), "episode schema fields present")
    gates["B"] = {"status": "SKIP", "detail": "world reset determinism is validated by world-level tests"}

    budget_rows = _read_jsonl(run_dir / "budgets.jsonl")
    budget_ok = True
    for row in budget_rows:
        for name, before in row["before"].items():
            charge = row["charge"][name]
            after = row["after"][name]
            if before - charge != after or after < 0:
                budget_ok = False
    gates["C"] = _gate(budget_ok, "budget transitions are monotone and exact")
    gates["D"] = {"status": "SKIP", "detail": "hidden-state isolation is validated by world-level tests"}
    gates["E"] = {"status": "SKIP", "detail": "illegal action fail-closed is validated by world-level tests"}

    replay_path = run_dir / "replay_manifest.json"
    replay_ok = replay_path.exists()
    if replay_ok:
        replay = _read_json(replay_path)
        for name, expected in replay.get("artifact_hashes", {}).items():
            path = run_dir / name
            actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else ""
            if actual != expected:
                replay_ok = False
                break
    gates["F"] = _gate(replay_ok, "replay manifest hashes validate")

    profiles = _read_jsonl(run_dir / "profiles.jsonl")
    receipts = _read_jsonl(run_dir / "receipts.jsonl")
    adaptive = [p for p in profiles if p.get("source") == "adaptive"]
    receipt_ids = {r.get("receipt_id") for r in receipts}
    profile_ok = all(p.get("receipt_id") in receipt_ids for p in adaptive)
    gates["G"] = _gate(profile_ok, "every adaptive profile shift has a receipt")
    gates["H"] = {"status": "SKIP", "detail": "MVP has no external AI judge"}
    gates["I"] = {"status": "SKIP", "detail": "paired fairness is validated by matrix tests"}
    gates["J"] = {"status": "SKIP", "detail": "held-out integrity is a benchmark-suite gate, not single-run gate"}

    score_path = run_dir / "score.json"
    score = _read_json(score_path) if score_path.exists() else {}
    if is_duel:
        score_ok = bool(score) and all(set(CANONICAL_METRICS) <= set(agent_score) for agent_score in score.values())
    else:
        score_ok = set(CANONICAL_METRICS) <= set(score)
    gates["K"] = _gate(score_ok, "canonical metric vector present")
    gates["L"] = {"status": "SKIP", "detail": "baseline comparability is validated by matrix/acceptance suite"}
    return gates


def validate_v03_evidence(
    *,
    hazard_matrix_dir: Path,
    hazard_low_latency_run: Path,
    hazard_high_risk_run: Path,
    negotiation_matrix_dir: Path,
) -> dict[str, dict[str, str]]:
    """Validate release-level v0.3 evidence across benchmark artifacts."""
    gates: dict[str, dict[str, str]] = {}

    hazard_rows = _read_jsonl(hazard_matrix_dir / "result_per_seed.jsonl")
    has_safe_fast = any(
        row.get("baseline") == "B0" and float(row.get("task_utility", 0.0)) >= 1.0
        for row in hazard_rows
    )
    has_catastrophic = any(float(row.get("catastrophic_loss", 0.0)) > 0.0 for row in hazard_rows)
    has_prevented = any(float(row.get("observation_prevented_loss", 0.0)) > 0.0 for row in hazard_rows)
    gates["V3-A"] = _gate(
        bool(hazard_rows) and has_safe_fast and has_catastrophic and has_prevented,
        "hazard seeds cover safe/catastrophic regimes and observation-prevented loss",
    )

    low_ops = _read_jsonl(hazard_low_latency_run / "cognitive_ops.jsonl")
    high_ops = _read_jsonl(hazard_high_risk_run / "cognitive_ops.jsonl")
    low_first = low_ops[0].get("operator") if low_ops else None
    high_first = high_ops[0].get("operator") if high_ops else None
    gates["V3-B"] = _gate(
        low_first is not None and high_first is not None and low_first != high_first,
        f"same B4 task diverges by COP: {low_first!r} vs {high_first!r}",
    )

    negotiation_rows = _read_jsonl(negotiation_matrix_dir / "duel_result_per_seed.jsonl")
    has_agreement = any(
        bool(row.get("a_agreement_reached", 0.0)) or bool(row.get("b_agreement_reached", 0.0))
        for row in negotiation_rows
    )
    has_timeout = any(
        not bool(row.get("a_agreement_reached", 0.0)) and not bool(row.get("b_agreement_reached", 0.0))
        for row in negotiation_rows
    )
    gates["V3-C"] = _gate(
        bool(negotiation_rows) and has_agreement and has_timeout,
        "negotiation seeds cover both agreement and timeout outcomes",
    )

    has_rule_shift_receipt = False
    for row in negotiation_rows:
        run_dir = negotiation_matrix_dir / str(row.get("run_dir", ""))
        receipts = _read_jsonl(run_dir / "receipts.jsonl")
        if any(receipt.get("reason_code") == "rule_shift_trigger" for receipt in receipts):
            has_rule_shift_receipt = True
            break
    gates["V3-D"] = _gate(has_rule_shift_receipt, "at least one B4 negotiation run records a rule-shift ProfileReceipt")

    grouped: dict[tuple[int, str, int], list[dict]] = {}
    for row in negotiation_rows:
        key = (int(row.get("matchup_index", -1)), str(row.get("budget", "")), int(row.get("seed", -1)))
        grouped.setdefault(key, []).append(row)
    role_swap_ok = bool(grouped)
    for rows in grouped.values():
        orientations = {row.get("role_orientation") for row in rows}
        hashes = {row.get("initial_world_hash") for row in rows}
        if orientations != {"normal", "swapped"} or len(hashes) != 1:
            role_swap_ok = False
            break
    gates["V3-E"] = _gate(role_swap_ok, "normal/swapped paired runs share the same initial-world hash")

    metric_keys = {"joint_utility", "pareto_efficiency", "agreement_stability", "negotiation_regret"}
    metrics_ok = bool(negotiation_rows) and all(
        all(f"a_{key}" in row and f"b_{key}" in row for key in metric_keys)
        for row in negotiation_rows
    )
    gates["V3-F"] = _gate(metrics_ok, "mixed-motive negotiation metrics are present for both agents")
    return gates


def _replay_hashes_valid(run_dir: Path) -> bool:
    replay_path = run_dir / "replay_manifest.json"
    if not replay_path.exists():
        return False
    replay = _read_json(replay_path)
    for name, expected in replay.get("artifact_hashes", {}).items():
        path = run_dir / name
        if not path.exists() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            return False
    return True


def validate_v04_evidence(*, signal_matrix_dir: Path, calibration_run_dir: Path) -> dict[str, dict[str, str]]:
    """Validate release-level v0.4 noisy-observation and calibration evidence."""
    gates: dict[str, dict[str, str]] = {}
    rows = _read_jsonl(signal_matrix_dir / "result_per_seed.jsonl")

    world_ok = bool(rows) and all(row.get("world") == "SignalHazard-v0.4" for row in rows)
    baselines = {row.get("baseline") for row in rows}
    gates["V4-A"] = _gate(world_ok and {"B0", "B1", "B2", "B3", "B4"} <= baselines, "signal-hazard matrix covers B0-B4")

    hidden_ok = bool(rows)
    for row in rows:
        run_dir = signal_matrix_dir / str(row.get("run_dir", ""))
        events = _read_jsonl(run_dir / "events.jsonl")
        reset = events[0].get("payload", {}).get("public_state", {}) if events else {}
        if "current_regime" in reset or "source_actual_accuracy" in reset or "regimes" in reset:
            hidden_ok = False
            break
    gates["V4-B"] = _gate(hidden_ok, "current truth and actual source accuracy stay out of public reset state")

    accuracy_ok = bool(rows) and all(
        float(row.get("field_sensor_accuracy", 0.0)) > float(row.get("deceptive_advisor_accuracy", 1.0))
        for row in rows
    )
    gates["V4-C"] = _gate(accuracy_ok, "reference seeds show field sensor more accurate than deceptive advisor despite lower declaration")

    calibration_rows = _read_jsonl(calibration_run_dir / "calibration.jsonl")
    selected = [row.get("last_selected_source") for row in calibration_rows if row.get("last_selected_source")]
    final = calibration_rows[-1] if calibration_rows else {}
    reliability = final.get("reliability", {}) if isinstance(final, dict) else {}
    advisor = reliability.get("advisor://deceptive", {}) if isinstance(reliability, dict) else {}
    shift_ok = (
        len(selected) >= 2
        and selected[0] == "advisor://deceptive"
        and "sensor://field" in selected[1:]
        and float(advisor.get("estimated_reliability", 1.0)) < float(advisor.get("declared_reliability", 0.0))
    )
    gates["V4-D"] = _gate(shift_ok, "B4 lowers deceptive-advisor trust and changes source selection")

    calibration_ok = bool(advisor) and float(advisor.get("calibration_error", 0.0)) > 0.0
    gates["V4-E"] = _gate(calibration_ok, "calibration artifact records non-zero prediction error for deceptive source")

    mvc = final.get("mvc", {}) if isinstance(final, dict) else {}
    advisor_mvc = mvc.get("observe:advisor://deceptive", {}) if isinstance(mvc, dict) else {}
    field_mvc = mvc.get("observe:sensor://field", {}) if isinstance(mvc, dict) else {}
    mvc_ok = (
        int(advisor_mvc.get("count", 0)) >= 1
        and int(field_mvc.get("count", 0)) >= 1
        and float(field_mvc.get("estimated_gain", -999.0)) > float(advisor_mvc.get("estimated_gain", 999.0))
    )
    gates["V4-F"] = _gate(mvc_ok, "online MVC proxy updates from realized source correctness and favors field evidence in reference run")

    replay_ok = _replay_hashes_valid(calibration_run_dir)
    for row in rows:
        run_dir = signal_matrix_dir / str(row.get("run_dir", ""))
        if not _replay_hashes_valid(run_dir):
            replay_ok = False
            break
    gates["V4-G"] = _gate(replay_ok, "matrix and calibration replay artifact hashes validate")
    return gates


def validate_v05_evidence(
    *,
    strategic_matrix_dir: Path,
    detailed_receiver_run_dir: Path,
    backward_compatibility_passed: bool,
) -> dict[str, dict[str, str]]:
    """Validate release-level v0.5 strategic-deception evidence."""
    gates: dict[str, dict[str, str]] = {}
    rows = _read_jsonl(strategic_matrix_dir / "strategic_result_per_seed.jsonl")

    strategic_rows = [row for row in rows if row.get("signaler_baseline") in {"B2", "B4"}]
    mixed_signals = any(
        float(row.get("signaler_truthful_signal_count", 0.0)) > 0.0
        and float(row.get("signaler_strategic_deception_count", 0.0)) > 0.0
        for row in strategic_rows
    )
    gates["V5-A"] = _gate(mixed_signals, "strategic signaler produces both truthful and deceptive signals")

    no_leak = bool(rows)
    for row in rows:
        run_dir = strategic_matrix_dir / str(row.get("run_dir", ""))
        events = _read_jsonl(run_dir / "events.jsonl")
        reset = events[0].get("payload", {}).get("public_state", {}) if events else {}
        receiver = reset.get("agent://receiver", {}) if isinstance(reset, dict) else {}
        if "current_truth" in receiver or "current_signal_correct" in receiver:
            no_leak = False
            break
    gates["V5-B"] = _gate(no_leak, "receiver public state does not expose current truth/correctness")

    deception_rows = _read_jsonl(detailed_receiver_run_dir / "deception.jsonl")
    receiver_rows = [row for row in deception_rows if row.get("agent_id") == "agent://receiver"]
    final = receiver_rows[-1].get("snapshot", {}) if receiver_rows else {}
    reliability = final.get("reliability", {}) if isinstance(final, dict) else {}
    contexts = reliability.get("contexts", {}) if isinstance(reliability, dict) else {}
    aligned = contexts.get("ALIGNED", {}).get("agent://signaler", {}) if isinstance(contexts, dict) else {}
    competitive = contexts.get("COMPETITIVE", {}).get("agent://signaler", {}) if isinstance(contexts, dict) else {}
    trust_diverged = (
        int(aligned.get("successes", 0)) + int(aligned.get("failures", 0)) > 0
        and int(competitive.get("successes", 0)) + int(competitive.get("failures", 0)) > 0
        and float(aligned.get("estimated_reliability", 0.0)) != float(competitive.get("estimated_reliability", 0.0))
    )
    gates["V5-C"] = _gate(trust_diverged, "B4 learns different signaler reliability by context")

    paths = [row.get("snapshot", {}).get("last_selected_path") for row in receiver_rows]
    behavior_shift = "trust_signal" in paths and "observe_field" in paths
    gates["V5-D"] = _gate(behavior_shift, "B4 trajectory contains direct trust and later independent field checking")

    mvc = final.get("mvc", {}) if isinstance(final, dict) else {}
    mvc_context = mvc.get("context", {}) if isinstance(mvc, dict) else {}
    contextual_mvc = (
        "trust_signal" in mvc_context
        and "agent://signaler" in mvc_context.get("trust_signal", {})
        and bool(mvc_context.get("trust_signal", {}).get("agent://signaler", {}))
    )
    gates["V5-E"] = _gate(contextual_mvc, "replay contains source-by-context realized MVC evidence")

    deception_attempts = sum(float(row.get("signaler_strategic_deception_count", 0.0)) for row in strategic_rows)
    deception_successes = sum(float(row.get("signaler_deception_success_count", 0.0)) for row in strategic_rows)
    deception_varied = deception_successes > 0.0 and deception_attempts > deception_successes
    gates["V5-F"] = _gate(deception_varied, "reference evidence contains successful and failed deception attempts")

    replay_ok = _replay_hashes_valid(detailed_receiver_run_dir)
    for row in rows:
        if not _replay_hashes_valid(strategic_matrix_dir / str(row.get("run_dir", ""))):
            replay_ok = False
            break
    gates["V5-G"] = _gate(replay_ok, "strategic matrix and detailed replay artifact hashes validate")
    gates["V5-H"] = _gate(bool(backward_compatibility_passed), "v0.1-v0.4 compatibility suite passed")
    return gates



def _contains_mapping_key(value: object, key: str) -> bool:
    if isinstance(value, dict):
        if key in value:
            return True
        return any(_contains_mapping_key(item, key) for item in value.values())
    if isinstance(value, list):
        return any(_contains_mapping_key(item, key) for item in value)
    return False


def _contextual_reliability_from_snapshot(snapshot: dict, source_id: str, context: str, declared: float) -> float:
    reliability = snapshot.get("reliability", {})
    global_row = reliability.get("global", {}).get(source_id, {}) if isinstance(reliability, dict) else {}
    global_est = float(global_row.get("estimated_reliability", declared))
    context_row = (
        reliability.get("contexts", {}).get(context, {}).get(source_id, {})
        if isinstance(reliability, dict)
        else {}
    )
    if not context_row:
        return global_est
    count = float(context_row.get("successes", 0.0)) + float(context_row.get("failures", 0.0))
    if count <= 0.0:
        return global_est
    raw = float(context_row.get("estimated_reliability", global_est))
    weight = count / (count + 1.0)
    return weight * raw + (1.0 - weight) * global_est


def _mvc_context_value(snapshot: dict, key: str, source_id: str, context: str, *, exploration: float = 0.0) -> float:
    mvc = snapshot.get("mvc", {})
    global_row = mvc.get("global", {}).get(key, {}) if isinstance(mvc, dict) else {}
    source_row = mvc.get("source", {}).get(key, {}).get(source_id, {}) if isinstance(mvc, dict) else {}
    context_row = (
        mvc.get("context", {}).get(key, {}).get(source_id, {}).get(context, {})
        if isinstance(mvc, dict)
        else {}
    )

    def blend(parent: float, row: dict) -> tuple[float, float]:
        if not row:
            return parent, 0.0
        evidence = float(row.get("weight", row.get("count", 0.0)))
        if evidence <= 0.0:
            return parent, 0.0
        child = float(row.get("estimated_gain", parent))
        w = evidence / (evidence + 1.0)
        return w * child + (1.0 - w) * parent, evidence

    value, _ = blend(0.0, global_row)
    value, _ = blend(value, source_row)
    value, context_weight = blend(value, context_row)
    if exploration > 0.0:
        value += float(exploration) / math.sqrt(context_weight + 1.0)
    return value


def validate_v06_evidence(
    *,
    latent_matrix_dir: Path,
    detailed_receiver_run_dir: Path,
    backward_compatibility_passed: bool,
) -> dict[str, dict[str, str]]:
    """Validate release-level v0.6 hidden-context inference evidence."""
    gates: dict[str, dict[str, str]] = {}
    rows = _read_jsonl(latent_matrix_dir / "latent_result_per_seed.jsonl")

    isolation_ok = bool(rows)
    for row in rows:
        run_dir = latent_matrix_dir / str(row.get("run_dir", ""))
        events = _read_jsonl(run_dir / "events.jsonl")
        actions = _read_jsonl(run_dir / "actions.jsonl")
        observations = _read_jsonl(run_dir / "observations.jsonl")
        reset = events[0].get("payload", {}).get("public_state", {}) if events else {}
        receiver_reset = reset.get("agent://receiver", {}) if isinstance(reset, dict) else {}
        if _contains_mapping_key(receiver_reset, "context"):
            isolation_ok = False
            break
        for action in actions:
            for phase in ("before", "after"):
                state = action.get(phase, {}).get("agent://receiver", {})
                if _contains_mapping_key(state, "context"):
                    isolation_ok = False
                    break
            if not isolation_ok:
                break
        if not isolation_ok:
            break
        for observation in observations:
            if observation.get("agent_id") == "agent://receiver" and _contains_mapping_key(observation.get("payload", {}), "context"):
                isolation_ok = False
                break
        if not isolation_ok:
            break
    gates["V6-A"] = _gate(isolation_ok, "receiver state, observations, and feedback contain no context label")

    latent_rows = _read_jsonl(detailed_receiver_run_dir / "latent_context.jsonl")
    receiver_rows = [row for row in latent_rows if row.get("agent_id") == "agent://receiver"]
    beliefs = [row.get("snapshot", {}).get("belief", {}).get("belief", {}) for row in receiver_rows]
    normalized = bool(beliefs) and all(
        set(belief) == {"ALIGNED", "COMPETITIVE"}
        and all(0.0 <= float(p) <= 1.0 for p in belief.values())
        and math.isclose(sum(float(p) for p in belief.values()), 1.0, abs_tol=1e-9)
        for belief in beliefs
    )
    gates["V6-B"] = _gate(normalized, "B4 latent context beliefs are normalized and bounded")

    responsive = bool(beliefs) and max(float(b["COMPETITIVE"]) for b in beliefs) > 0.65 and max(float(b["ALIGNED"]) for b in beliefs) > 0.65
    gates["V6-C"] = _gate(responsive, "latent posterior moves toward competitive and aligned hypotheses under different evidence")

    uncertainty_ok = bool(receiver_rows) and any(
        0.5 < max(float(p) for p in belief.values()) < 0.99
        for belief in beliefs
    ) and all(
        0.0 < float(row.get("snapshot", {}).get("belief", {}).get("transition_persistence", 1.0)) < 1.0
        for row in receiver_rows
    )
    gates["V6-D"] = _gate(uncertainty_ok, "prediction preserves uncertainty under sub-unit transition persistence")

    mixture_trust_ok = False
    mixture_mvc_ok = False
    for row in reversed(receiver_rows):
        snapshot = row.get("snapshot", {})
        belief = snapshot.get("belief", {}).get("belief", {})
        if set(belief) != {"ALIGNED", "COMPETITIVE"}:
            continue
        expected_signal = sum(
            float(probability) * _contextual_reliability_from_snapshot(snapshot, "agent://signaler", context, 0.8)
            for context, probability in belief.items()
        )
        expected_field = sum(
            float(probability) * _contextual_reliability_from_snapshot(snapshot, "sensor://field", context, 0.7)
            for context, probability in belief.items()
        )
        mixture_trust_ok = math.isclose(float(snapshot.get("effective_signal_trust", -1.0)), expected_signal, abs_tol=1e-8) and math.isclose(
            float(snapshot.get("effective_field_trust", -1.0)), expected_field, abs_tol=1e-8
        )

        expected_trust_mvc = sum(
            float(probability) * _mvc_context_value(snapshot, "trust_signal", "agent://signaler", context)
            for context, probability in belief.items()
        )
        expected_field_mvc = sum(
            float(probability) * _mvc_context_value(snapshot, "observe_field", "sensor://field", context, exploration=0.03)
            for context, probability in belief.items()
        )
        mixture_mvc_ok = math.isclose(float(snapshot.get("trust_signal_mvc", 999.0)), expected_trust_mvc, abs_tol=1e-8) and math.isclose(
            float(snapshot.get("observe_field_mvc", 999.0)), expected_field_mvc, abs_tol=1e-8
        )
        if mixture_trust_ok and mixture_mvc_ok:
            break
    gates["V6-E"] = _gate(mixture_trust_ok, "effective source trust matches the belief-weighted contextual mixture")
    gates["V6-F"] = _gate(mixture_mvc_ok, "effective trust/verify MVC matches the belief-weighted contextual mixture")

    paths = [row.get("snapshot", {}).get("last_selected_path") for row in receiver_rows]
    behavior_ok = "trust_signal" in paths and "observe_field" in paths
    gates["V6-G"] = _gate(behavior_ok, "detailed B4 trajectory contains both direct trust and field verification")

    replay_ok = _replay_hashes_valid(detailed_receiver_run_dir)
    for row in rows:
        if not _replay_hashes_valid(latent_matrix_dir / str(row.get("run_dir", ""))):
            replay_ok = False
            break
    gates["V6-H"] = _gate(replay_ok, "latent matrix and detailed replay artifact hashes validate")
    gates["V6-I"] = _gate(bool(backward_compatibility_passed), "v0.1-v0.5 compatibility suite passed")
    return gates


def validate_v07_evidence(
    *,
    experiment_dir: Path,
    repeat_experiment_dir: Path | None = None,
    backward_compatibility_passed: bool,
) -> dict[str, dict[str, str]]:
    """Validate v0.7 learned meta-controller training/evaluation evidence."""
    experiment_dir = Path(experiment_dir)
    gates: dict[str, dict[str, str]] = {}

    training_report = _read_json(experiment_dir / "meta_training_report.json")
    eval_report = _read_json(experiment_dir / "meta_eval_report.json")
    experiences = _read_jsonl(experiment_dir / "training_experiences.jsonl")
    eval_rows = _read_jsonl(experiment_dir / "meta_eval_result_per_seed.jsonl")
    model_payload = _read_json(experiment_dir / "meta_model.json")

    train_seeds = {int(seed) for seed in training_report.get("train_seeds", [])}
    eval_seeds = {int(seed) for seed in eval_report.get("eval_seeds", [])}
    isolation_ok = bool(train_seeds) and bool(eval_seeds) and train_seeds.isdisjoint(eval_seeds)
    gates["V7-A"] = _gate(isolation_ok, "training and held-out evaluation seeds are non-empty and disjoint")

    forbidden = {"true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"}
    feature_isolation_ok = bool(experiences)
    for row in experiences:
        features = row.get("features", {})
        if not isinstance(features, dict) or forbidden & set(features):
            feature_isolation_ok = False
            break
    gates["V7-B"] = _gate(feature_isolation_ok, "training experience features contain no hidden context/truth/oracle labels")

    counts = dict(training_report.get("operation_counts", {}))
    actions = dict(model_payload.get("actions", {}))
    learning_ok = (
        int(training_report.get("experience_count", 0)) > 0
        and int(counts.get("trust_signal", 0)) > 0
        and int(counts.get("observe_field", 0)) > 0
        and "trust_signal" in actions
        and "observe_field" in actions
    )
    gates["V7-C"] = _gate(learning_ok, "trained model contains positive evidence for both trust and observe cognition")

    training_hash = str(training_report.get("model_hash", ""))
    before_hash = str(eval_report.get("model_hash_before_eval", ""))
    after_hash = str(eval_report.get("model_hash_after_eval", ""))
    frozen_ok = bool(training_hash) and training_hash == before_hash == after_hash
    gates["V7-D"] = _gate(frozen_ok, "held-out evaluation uses a frozen model with unchanged SHA-256")

    routing_ok = bool(eval_rows) and any(bool(row.get("trajectory_diverged")) for row in eval_rows)
    gates["V7-E"] = _gate(routing_ok, "at least one held-out B4/B4L pair has a different cognition trajectory")

    required_eval = {
        "b4_task_utility",
        "b4l_task_utility",
        "b4_cognitive_efficiency",
        "b4l_cognitive_efficiency",
        "b4_field_checks",
        "b4l_field_checks",
        "utility_delta_b4l_minus_b4",
        "trajectory_diverged",
    }
    reporting_ok = bool(eval_rows) and all(required_eval <= set(row) for row in eval_rows)
    gates["V7-F"] = _gate(reporting_ok, "held-out paired utility, efficiency, observation use, and divergence metrics are reported")

    manifests = sorted((experiment_dir / "train").rglob("replay_manifest.json")) + sorted((experiment_dir / "eval").rglob("replay_manifest.json"))
    replay_ok = bool(manifests)
    meta_artifact_seen = False
    for manifest_path in manifests:
        run_dir = manifest_path.parent
        manifest = _read_json(manifest_path)
        names = set(manifest.get("artifact_hashes", {}))
        if "meta_learning.jsonl" in names or "meta_experiences.jsonl" in names:
            meta_artifact_seen = True
        if not _replay_hashes_valid(run_dir):
            replay_ok = False
            break
    gates["V7-G"] = _gate(replay_ok and meta_artifact_seen, "training/eval replay hashes validate and meta-learning artifacts are hashed")

    gates["V7-H"] = _gate(bool(backward_compatibility_passed), "v0.1-v0.6 compatibility suite passed")

    deterministic_ok = False
    if repeat_experiment_dir is not None:
        repeat_experiment_dir = Path(repeat_experiment_dir)
        required_files = ("meta_model.json", "meta_training_report.json", "meta_eval_report.json", "meta_eval_result_per_seed.jsonl")
        deterministic_ok = all(
            (experiment_dir / name).exists()
            and (repeat_experiment_dir / name).exists()
            and (experiment_dir / name).read_bytes() == (repeat_experiment_dir / name).read_bytes()
            for name in required_files
        )
    gates["V7-I"] = _gate(deterministic_ok, "repeated training spec yields byte-identical model and held-out reports")
    return gates


def validate_v08_evidence(
    *,
    experiment_dir: Path,
    repeat_experiment_dir: Path | None = None,
    backward_compatibility_passed: bool,
) -> dict[str, dict[str, str]]:
    """Validate v0.8 exploration/off-policy meta-control evidence."""
    from apsc.meta_learning import ExperienceMetaValueModel, MetaStateFeatures

    experiment_dir = Path(experiment_dir)
    gates: dict[str, dict[str, str]] = {}

    training_report = _read_json(experiment_dir / "exploration_training_report.json")
    eval_report = _read_json(experiment_dir / "exploration_eval_report.json")
    training_rows = _read_jsonl(experiment_dir / "exploration_training_experiences.jsonl")
    eval_rows = _read_jsonl(experiment_dir / "exploration_eval_result_per_seed.jsonl")
    model_path = experiment_dir / "exploration_meta_model.json"

    train_seeds = {int(seed) for seed in training_report.get("train_seeds", [])}
    eval_seeds = {int(seed) for seed in eval_report.get("eval_seeds", [])}
    isolation_ok = bool(train_seeds) and bool(eval_seeds) and train_seeds.isdisjoint(eval_seeds)
    gates["V8-A"] = _gate(isolation_ok, "training and held-out evaluation seeds are non-empty and disjoint")

    forbidden = {"true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"}
    feature_isolation_ok = bool(training_rows)
    for row in training_rows:
        features = row.get("features", {})
        if not isinstance(features, dict) or forbidden & set(features):
            feature_isolation_ok = False
            break
    gates["V8-B"] = _gate(feature_isolation_ok, "actual/counterfactual decision features contain no hidden context/truth/oracle labels")

    actual_counts = dict(training_report.get("actual_operation_counts", {}))
    coverage_ratio = float(training_report.get("actual_coverage_ratio", math.inf))
    coverage_ok = (
        int(actual_counts.get("trust_signal", 0)) > 0
        and int(actual_counts.get("observe_field", 0)) > 0
        and math.isfinite(coverage_ratio)
        and coverage_ratio <= 4.0
        and int(training_report.get("forced_exploration_count", 0)) > 0
    )
    gates["V8-C"] = _gate(coverage_ok, "actual training has bounded two-operation cognition coverage with forced exploration")

    cf_rows = [row for row in training_rows if row.get("source_kind") == "counterfactual_off_policy"]
    cf_ops = {str(row.get("operation")) for row in cf_rows}
    cf_ok = (
        bool(cf_rows)
        and {"trust_signal", "observe_field"} <= cf_ops
        and int(training_report.get("counterfactual_experience_count", 0)) == len(cf_rows)
        and int(training_report.get("counterfactual_experience_count", 0)) >= int(training_report.get("actual_experience_count", 0))
    )
    gates["V8-D"] = _gate(cf_ok, "counterfactual/off-policy training supplies alternate cognition targets for both operations")

    evidence = dict(training_report.get("weighted_evidence", {}))
    uncertainty_ok = False
    if training_rows and model_path.exists():
        try:
            model = ExperienceMetaValueModel.load(model_path)
            features = MetaStateFeatures.from_mapping(dict(training_rows[0]["features"]))
            uncertainty_ok = all(
                float(evidence.get(op, 0.0)) > 0.0
                and math.isfinite(model.uncertainty(op, features))
                and 0.0 < model.uncertainty(op, features) <= 1.0
                for op in ("trust_signal", "observe_field")
            )
        except (KeyError, TypeError, ValueError, OSError, json.JSONDecodeError):
            uncertainty_ok = False
    gates["V8-E"] = _gate(uncertainty_ok, "both cognition operations have positive weighted evidence and finite uncertainty estimates")

    training_hash = str(training_report.get("model_hash", ""))
    before_hash = str(eval_report.get("model_hash_before_eval", ""))
    after_hash = str(eval_report.get("model_hash_after_eval", ""))
    frozen_ok = bool(training_hash) and training_hash == before_hash == after_hash
    gates["V8-F"] = _gate(frozen_ok, "held-out evaluation uses the persisted frozen model with unchanged SHA-256")

    required_eval = {
        "b4_task_utility",
        "b4x_task_utility",
        "b4_cognitive_efficiency",
        "b4x_cognitive_efficiency",
        "b4_field_checks",
        "b4x_field_checks",
        "utility_delta_b4x_minus_b4",
        "trajectory_diverged",
    }
    paired_ok = bool(eval_rows) and all(
        required_eval <= set(row)
        and row.get("b4_initial_world_hash") == row.get("b4x_initial_world_hash")
        for row in eval_rows
    )
    routing_observed = any(bool(row.get("trajectory_diverged")) for row in eval_rows)
    gates["V8-G"] = _gate(paired_ok and routing_observed, "held-out B4/B4X rows are same-seed paired with measurable metrics and routing divergence")

    manifests = sorted((experiment_dir / "train").rglob("replay_manifest.json")) + sorted((experiment_dir / "eval").rglob("replay_manifest.json"))
    replay_ok = bool(manifests)
    exploration_artifact_seen = False
    for manifest_path in manifests:
        manifest = _read_json(manifest_path)
        names = set(manifest.get("artifact_hashes", {}))
        if "meta_exploration.jsonl" in names:
            exploration_artifact_seen = True
        if not _replay_hashes_valid(manifest_path.parent):
            replay_ok = False
            break
    gates["V8-H"] = _gate(replay_ok and exploration_artifact_seen, "all train/eval replay hashes validate and exploration evidence is hashed")

    deterministic_ok = False
    if repeat_experiment_dir is not None:
        repeat_experiment_dir = Path(repeat_experiment_dir)
        required_files = (
            "exploration_meta_model.json",
            "exploration_training_report.json",
            "exploration_eval_report.json",
            "exploration_eval_result_per_seed.jsonl",
            "exploration_training_experiences.jsonl",
        )
        deterministic_ok = all(
            (experiment_dir / name).exists()
            and (repeat_experiment_dir / name).exists()
            and (experiment_dir / name).read_bytes() == (repeat_experiment_dir / name).read_bytes()
            for name in required_files
        )
    gates["V8-I"] = _gate(deterministic_ok, "repeated full experiment yields byte-identical model, training ledger, and held-out reports")

    gates["V8-J"] = _gate(bool(backward_compatibility_passed), "v0.1-v0.7 compatibility suite passed")
    return gates


def validate_v09_evidence(
    *,
    experiment_dir: Path,
    repeat_experiment_dir: Path | None = None,
    backward_compatibility_passed: bool,
) -> dict[str, dict[str, str]]:
    """Validate v0.9 world-neutral transfer and frozen held-out evidence."""
    from apsc.meta_generalization import CrossWorldMetaValueModel, GeneralizedCognitiveFeatures
    from apsc.meta_exploration_policy import LearnedExplorationPolicyModel

    experiment_dir = Path(experiment_dir)
    gates: dict[str, dict[str, str]] = {}
    root = _read_json(experiment_dir / "cross_world_report.json")
    directions = dict(root.get("directions", {}))
    direction_names = {"signal_to_latent", "latent_to_signal"}

    # A/B/C/D inspect canonical training ledgers and persisted models.
    training_feature_sets: list[set[str]] = []
    schema_rejects_world_identity = False
    target_weight_ok = True
    exploration_ok = True
    world_neutral_bucket_ok = True
    for name in sorted(direction_names):
        d = experiment_dir / name
        rows = _read_jsonl(d / "cross_world_training_experiences.jsonl")
        if not rows:
            target_weight_ok = False
            exploration_ok = False
            world_neutral_bucket_ok = False
            continue
        for row in rows:
            features = dict(row.get("features", {}))
            training_feature_sets.append(set(features))
            if {"world_id", "world_kind", "source_world", "true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"} & set(features):
                world_neutral_bucket_ok = False
            try:
                obj = GeneralizedCognitiveFeatures.from_mapping(features)
                bucket = obj.bucket_key()
                if "SignalHazard" in bucket or "LatentContext" in bucket or "world" in bucket.lower():
                    world_neutral_bucket_ok = False
            except (TypeError, ValueError):
                world_neutral_bucket_ok = False
        if not schema_rejects_world_identity:
            bad = dict(rows[0]["features"])
            bad["world_id"] = "forbidden"
            try:
                GeneralizedCognitiveFeatures.from_mapping(bad)
            except ValueError:
                schema_rejects_world_identity = True

        model = CrossWorldMetaValueModel.load(d / "generalized_meta_model.json")
        policy = LearnedExplorationPolicyModel.load(d / "learned_exploration_policy.json")
        spec = dict(root.get("spec", {}))
        cf_weight = float(spec.get("counterfactual_weight", 0.5))
        for operation in ("trust_primary", "verify_independent"):
            expected = 0.0
            for row in rows:
                if row.get("operation") != operation:
                    continue
                base = cf_weight if row.get("evidence_kind") == "counterfactual" else 1.0
                expected += base * max(1.0 - float(row.get("target_uncertainty", 0.0)), model.min_target_weight)
            if not math.isclose(model.evidence_weight(operation), expected, abs_tol=1e-8):
                target_weight_ok = False
        if policy.evidence_weight() <= 0.0:
            exploration_ok = False
        reloaded_policy = LearnedExplorationPolicyModel.from_dict(policy.to_dict())
        if reloaded_policy.model_hash() != policy.model_hash():
            exploration_ok = False

    common_schema_ok = bool(training_feature_sets) and all(keys == training_feature_sets[0] for keys in training_feature_sets)
    gates["V9-A"] = _gate(schema_rejects_world_identity, "generalized schema rejects world identity and hidden/oracle feature injection")
    gates["V9-B"] = _gate(common_schema_ok and world_neutral_bucket_ok, "both source worlds use the same world-neutral generalized feature schema/buckets")
    gates["V9-C"] = _gate(target_weight_ok, "persisted value-model evidence equals uncertainty-discounted training weight")
    gates["V9-D"] = _gate(exploration_ok, "learned exploration policy has evidence and stable deterministic serialization/hash")

    both_directions_ok = set(directions) == direction_names
    frozen_ok = both_directions_ok
    paired_ok = both_directions_ok
    routing_ok = False
    replay_ok = True
    generalized_artifact_seen = False
    for name in sorted(direction_names):
        d = experiment_dir / name
        training = _read_json(d / "cross_world_training_report.json")
        evaluation = _read_json(d / "cross_world_eval_report.json")
        eval_rows = _read_jsonl(d / "cross_world_eval_result_per_seed.jsonl")
        train_seeds = {int(x) for x in training.get("train_seeds", [])}
        eval_seeds = {int(x) for x in evaluation.get("eval_seeds", [])}
        if not train_seeds or not eval_seeds or not train_seeds.isdisjoint(eval_seeds):
            frozen_ok = False
        if not (
            evaluation.get("value_model_hash_before_eval") == evaluation.get("value_model_hash_after_eval") == training.get("value_model_hash")
            and evaluation.get("exploration_policy_hash_before_eval") == evaluation.get("exploration_policy_hash_after_eval") == training.get("exploration_policy_hash")
        ):
            frozen_ok = False
        if not eval_rows:
            paired_ok = False
        for row in eval_rows:
            if not (
                row.get("b4_initial_world_hash")
                == row.get("b4g0_initial_world_hash")
                == row.get("b4g_initial_world_hash")
            ):
                paired_ok = False
            if bool(row.get("trajectory_diverged_b4g_vs_b4")):
                routing_ok = True
        for manifest_path in sorted(d.rglob("replay_manifest.json")):
            manifest = _read_json(manifest_path)
            if "meta_generalization.jsonl" in set(manifest.get("artifact_hashes", {})):
                generalized_artifact_seen = True
            if not _replay_hashes_valid(manifest_path.parent):
                replay_ok = False
                break

    gates["V9-E"] = _gate(frozen_ok, "train/eval seeds are disjoint and value/exploration model hashes stay frozen during held-out evaluation")
    gates["V9-F"] = _gate(both_directions_ok, "both SignalHazard→LatentContext and LatentContext→SignalHazard directions completed")
    gates["V9-G"] = _gate(paired_ok, "same-seed B4/B4G0/B4G evaluation rows share identical initial-world hashes")
    gates["V9-H"] = _gate(routing_ok, "B4G creates measurable held-out cognition-routing divergence without requiring positive transfer")
    gates["V9-I"] = _gate(replay_ok and generalized_artifact_seen, "all replay hashes validate and generalized-meta selection evidence is included in replay manifests")

    deterministic_ok = False
    if repeat_experiment_dir is not None:
        repeat_experiment_dir = Path(repeat_experiment_dir)
        canonical = ["cross_world_report.json"]
        for name in sorted(direction_names):
            canonical.extend([
                f"{name}/generalized_meta_model.json",
                f"{name}/learned_exploration_policy.json",
                f"{name}/cross_world_training_experiences.jsonl",
                f"{name}/cross_world_training_report.json",
                f"{name}/cross_world_eval_result_per_seed.jsonl",
                f"{name}/cross_world_eval_report.json",
            ])
        deterministic_ok = all(
            (experiment_dir / rel).exists()
            and (repeat_experiment_dir / rel).exists()
            and (experiment_dir / rel).read_bytes() == (repeat_experiment_dir / rel).read_bytes()
            for rel in canonical
        )
    gates["V9-J"] = _gate(deterministic_ok, "repeated cross-world experiment yields byte-identical canonical model, ledger, and report files")
    gates["V9-K"] = _gate(bool(backward_compatibility_passed), "v0.1-v0.8 compatibility suite passed")
    return gates
