# MVP Acceptance Gates

The v0.3 MVP implements single-agent and **dual-agent** run validation. Gates A, C, F, G, and K are validated directly from artifacts. Gates B, D, E, I, and L are enforced by automated world/matrix tests. Gate H is skipped because the MVP has no external AI judge. Gate J remains suite-level held-out integrity.

- A: episode schema, including duel `baselines` / `budgets` / `profile_names`
- B: deterministic world reset
- C: per-agent budget enforcement
- D: hidden-state isolation and private observation separation
- E: illegal action fail-closed
- F: replay completeness/hash integrity
- G: adaptive profile trace receipts, including `rule_shift_trigger`
- H: judge separation (SKIP in MVP)
- I: paired fairness, same seed, plus role swap for asymmetric comparisons
- J: held-out integrity (suite-level)
- K: canonical metric vector for each agent
- L: baseline comparability B0-B4 and COP cross-play


## v0.3 evidence gates

The v0.3 release adds artifact-level evidence checks on top of A–L:

- V3-A: HazardChoice covers safe/catastrophic regimes and non-zero observation-prevented loss.
- V3-B: the same B4 agent starts with different cognition operators under low-latency vs high-risk COP.
- V3-C: NegotiationSplit covers both agreement and timeout outcomes.
- V3-D: at least one B4 negotiation run records a `rule_shift_trigger` ProfileReceipt.
- V3-E: every normal/swapped pair has an identical initial-world hash.
- V3-F: mixed-motive metrics are present for both agents.
