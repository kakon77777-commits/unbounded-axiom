# 受約束可能空間與多尺度未來展開：從狀態、規則、因果到可達性、剪枝與抽象

**Constrained Possibility Spaces and Multi-Scale Future Expansion: From State, Rules, and Causality to Reachability, Pruning, and Abstraction**

**系列：Adaptive Possibility-Space Cognition（APSC）／Paper 02 of 06**  
**版本：v0.1**  
**日期：2026-08-24**  
**作者：Neo.K**  
**機構：EveMissLab / EVEMISS Technology**

---

## 摘要

自適應可能空間認知（Adaptive Possibility-Space Cognition, APSC）要求智能系統不只生成下一步答案，而是能在有限資源下建立、限制、展開、壓縮與更新未來可能空間。此目標首先面臨一個基礎問題：若沒有對「狀態是什麼、規則是什麼、哪些轉移合法、哪些分支可達、哪些路徑應保留」做形式區分，所謂未來展開只會退化成大量語義上看似合理但結構上不可驗證的生成。

本文提出 APSC 的第二層理論：**受約束可能空間與多尺度未來展開**。本文將任務相關世界表示為狀態系統，並將未來可能空間定義為在規則、因果、資源、觀察與可達性約束下形成的有限工作子空間。本文區分硬規則、軟規則、統計規則與未知規則；區分結構合法性、因果可行性與實際可達性；並提出候選生成、約束投影、可達性過濾、風險保留、狀態合併與抽象化等步驟。

為處理組合爆炸，本文進一步提出多尺度未來表示：近程未來保留高解析狀態轉移，中程未來使用情境族與結構化分支，遠程未來則使用吸引子、可行域、制度狀態或宏觀邊界，而非假裝維持逐事件精確預測。本文同時提出分支價值函數、剪枝保留原則、低機率高風險例外、等價狀態合併與展開停止條件，使未來推演從「越多越好」轉向「在有限認知時空中保留最有決策價值的結構」。

本文主張：高階 AI 的未來推演能力不應以單純步數衡量，而應以**可能空間品質、約束一致性、關鍵分支保留率、抽象尺度適切性與資源效率**共同評估。

**關鍵詞：** 自適應可能空間認知、狀態空間、受約束展開、因果約束、可達性、分支生成、剪枝、狀態合併、多尺度未來、抽象、組合爆炸、決策相關性

---

# 1. 問題定位

## 1.1 「之後」不是單一預測

任何需要推演未來的智能系統，都會面對：

$$
S_t
\rightarrow
S_{t+1}
\rightarrow
S_{t+2}
\rightarrow
\cdots.
$$

但在真實任務中，下一個狀態通常不是唯一值，而是候選集合：

$$
S_t
\rightarrow
\Omega_{t+1}.
$$

再往下一層：

$$
\Omega_{t+1}
\rightarrow
\Omega_{t+2}.
$$

因此真正的未來結構不是線，而是：

$$
\mathcal G_t
=
(V_t,E_t),
$$

其中節點 $V_t$ 表示候選狀態，邊 $E_t$ 表示合法或假設性的轉移關係。

---

## 1.2 組合爆炸不是例外

若每個狀態平均產生 $b$ 個後繼，深度 $h$ 的樹形展開為：

$$
N(h)
=
1+b+b^2+\cdots+b^h.
$$

當 $b>1$ 時：

$$
N(h)
=
O(b^h).
$$

因此 APSC 不以「完整枚舉所有未來」為目標。

本文採用的核心原則是：

$$
\boxed{
\text{Future cognition is constrained selective expansion.}
}
$$

未來推演的本質不是無限展開，而是選擇性建立**工作可能空間**。

---

# 2. 世界狀態的最小表示

## 2.1 狀態不是文本摘要

令某一時刻的任務相關狀態為：

$$
S_t.
$$

本文將其表示為：

$$
S_t
=
(
X_t,
R_t,
C_t,
O_t,
B_t
).
$$

其中：

- $X_t$：可觀察或推定的實體與變量狀態；
- $R_t$：目前適用規則；
- $C_t$：因果與依賴關係；
- $O_t$：觀察狀態與資訊可得性；
- $B_t$：資源、權限、時間或其他邊界條件。

因此狀態不是一段自然語言描述，而是：

$$
\boxed{
\text{state-bearing structure}
}
$$

即能支撐後續轉移、約束與驗證的結構。

---

## 2.2 狀態表示允許不完整

真實系統通常無法取得完整世界狀態。

因此：

$$
S_t
=
S_t^{known}
\cup
S_t^{unknown}
\cup
S_t^{uncertain}.
$$

其中：

- $S_t^{known}$：已知狀態；
- $S_t^{unknown}$：尚無觀察；
- $S_t^{uncertain}$：具有候選值或機率分佈。

這一區分非常重要，因為：

$$
Unknown
\neq
False.
$$

以及：

$$
Uncertain
\neq
Contradictory.
$$

若 AI 把未知值直接補成單一值，後續所有展開都可能建立在偽狀態上。

---

# 3. 規則的分層

## 3.1 規則不是同一強度

本文將規則初步分成四類：

$$
\mathcal R
=
\mathcal R_H
\cup
\mathcal R_S
\cup
\mathcal R_P
\cup
\mathcal R_U.
$$

其中：

- $\mathcal R_H$：Hard Rules，硬規則；
- $\mathcal R_S$：Soft Rules，軟規則；
- $\mathcal R_P$：Probabilistic Rules，統計或機率規則；
- $\mathcal R_U$：Unknown / Hypothesized Rules，未知或假設規則。

---

## 3.2 硬規則

硬規則定義不可違反的合法性邊界：

$$
r_H(S_t,a,S_{t+1})
\in
\{0,1\}.
$$

若：

$$
r_H=0,
$$

則該轉移直接被拒絕。

例如：

- 遊戲中的非法棋步；
- 程式狀態機中的禁止轉移；
- 物理模擬中的不可成立幾何條件；
- 已驗證 API 中不存在的狀態轉換。

---

## 3.3 軟規則

軟規則表示常態、偏好、制度慣例或高機率模式：

$$
r_S
:
(S_t,a,S_{t+1})
\mapsto
w
$$

其中：

$$
0\leq w\leq1.
$$

違反軟規則不代表不可能，而代表：

$$
Cost
\uparrow
$$

或：

$$
Likelihood
\downarrow.
$$

---

## 3.4 機率規則

統計規則給出：

$$
P(S_{t+1}\mid S_t,a).
$$

但 APSC 不將機率本身視為合法性。

因此：

$$
P(\omega)\approx0
$$

不代表：

$$
Impossible(\omega).
$$

尤其在高風險環境中，低機率分支仍可能需要保留。

---

## 3.5 未知規則

若系統對某個轉移機制沒有可靠模型：

$$
r_U
=
Unknown.
$$

則不得偷偷轉成：

$$
r_U=0
$$

或：

$$
r_U=1.
$$

應保留為：

$$
\boxed{
\text{explicit epistemic uncertainty}
}
$$

並交由後續觀察、實驗、搜尋或反事實觀察算子處理。

---

# 4. 轉移與候選生成

## 4.1 候選轉移函數

令行動或事件為 $a_t$，則候選轉移可寫為：

$$
\widetilde T
:
(S_t,a_t)
\mapsto
\widetilde{\Omega}_{t+1}.
$$

其中：

$$
\widetilde{\Omega}_{t+1}
$$

是尚未完全約束的候選空間。

神經模型非常適合生成：

$$
\widetilde{\Omega}_{t+1}.
$$

但它不是最終空間。

---

## 4.2 約束投影

正式工作空間為：

$$
\widehat{\Omega}_{t+1}
=
\Pi_{\mathcal K}
(
\widetilde{\Omega}_{t+1}
).
$$

其中：

$$
\Pi_{\mathcal K}
$$

表示將候選空間投影到符合目前約束核心 $\mathcal K$ 的子空間。

因此：

$$
\widetilde{\Omega}
\supseteq
\widehat{\Omega}.
$$

這正是「神經生成 + 約束」的核心架構。

---

# 5. 因果約束

## 5.1 狀態先後不等於因果

若：

$$
X_t
\prec
Y_{t+1},
$$

只能說時間上先發生，不能直接推出：

$$
X\rightarrow Y.
$$

APSC 因此區分：

- temporal predecessor；
- structural dependency；
- causal influence；
- observed correlation。

---

## 5.2 因果轉移

若存在因果結構：

$$
\mathcal C_t
=
(V_C,E_C),
$$

則對候選轉移 $\omega$ 可檢查：

$$
CausalCompatible(\omega,\mathcal C_t).
$$

若某分支要求：

$$
Y
$$

在沒有任何允許機制的情況下改變，則該分支應被降權或拒絕。

---

## 5.3 因果不完備

現實中：

$$
\mathcal C_t
$$

通常不完整。

因此 APSC 不要求：

$$
CausalCompatible=1
$$

才保留。

可以使用三值：

$$
CausalStatus(\omega)
\in
\{
Supported,
Contradicted,
Undetermined
\}.
$$

這避免因果模型不完整時過度剪枝。

---

# 6. 可達性

## 6.1 合法不等於可達

某個狀態可能符合所有硬規則，但仍無法從目前狀態在給定時間與資源下到達。

因此定義：

$$
Reachable
(
S_t,
\omega,
B,
h
)
\in
\{0,1,?\}.
$$

其中：

- $B$：資源與邊界；
- $h$：時間或步數地平線。

---

## 6.2 有界可達性

本文特別關注：

$$
Reachable_{\leq h}.
$$

即：

> 在不超過 $h$ 個步驟或指定資源下，該狀態是否可達？

這比純理論上的最終可達更接近實際決策。

---

## 6.3 可達圖

可定義：

$$
\mathcal G_R
=
(V_R,E_R),
$$

其中只保留目前被認為可達或尚未證偽的節點。

因此未來空間不是自由生成樹，而是：

$$
\boxed{
\text{constrained reachability graph}
}
$$

---

# 7. 分支價值

## 7.1 並非所有分支都值得同等資源

對每個候選分支 $\omega_i$，定義優先度：

$$
Priority(\omega_i)
=
F
(
P_i,
V_i,
Risk_i,
Info_i,
Novelty_i,
Cost_i,
Reach_i
).
$$

其中：

- $P_i$：概率或可信度；
- $V_i$：決策價值；
- $Risk_i$：風險；
- $Info_i$：資訊價值；
- $Novelty_i$：新穎或結構差異；
- $Cost_i$：繼續展開成本；
- $Reach_i$：可達程度。

---

## 7.2 機率不是唯一排序標準

若僅使用：

$$
Priority=P,
$$

會忽略低機率高損失事件。

因此可加入風險敏感項：

$$
Priority(\omega)
=
\alpha P(\omega)
+
\beta V(\omega)
+
\gamma Risk(\omega)
-
\delta Cost(\omega).
$$

當：

$$
Risk(\omega)\gg1,
$$

即使：

$$
P(\omega)\ll1,
$$

也可能仍需保留。

---

# 8. 剪枝

## 8.1 剪枝不是刪除「不喜歡的答案」

剪枝 $\mathfrak P$ 的目的，是在有限資源下移除低價值、重複、非法或明顯不可達的分支。

形式上：

$$
\mathfrak P
:
\widehat{\Omega}
\rightarrow
\widehat{\Omega}'.
$$

其中：

$$
|\widehat{\Omega}'|
\leq
|\widehat{\Omega}|.
$$

---

## 8.2 四種基本剪枝

本文提出四類：

### A. Constraint Pruning

$$
K(\omega)=0
\Rightarrow
Remove(\omega).
$$

### B. Reachability Pruning

$$
Reachable_{\leq h}(\omega)=0
\Rightarrow
Remove(\omega).
$$

### C. Dominance Pruning

若：

$$
\omega_i
$$

在所有相關決策維度上都被：

$$
\omega_j
$$

支配，則可降低優先度或移除。

### D. Budget Pruning

當剩餘資源不足時，只保留最高優先度分支。

---

# 9. 剪枝後悔與關鍵分支保留

## 9.1 過早剪枝

錯誤剪枝可能導致：

$$
\omega^\ast
\notin
\widehat{\Omega}'.
$$

其中：

$$
\omega^\ast
$$

是最終關鍵或真實分支。

---

## 9.2 關鍵分支保留率

可定義：

$$
Recall_{\mathrm{critical}}
=
\frac{
|\Omega_{\mathrm{critical}}
\cap
\widehat{\Omega}'|
}{
|\Omega_{\mathrm{critical}}|
}.
$$

因此剪枝評估不能只看壓縮率。

---

## 9.3 剪枝後悔

定義：

$$
R_{\mathrm{prune}}
=
Q_{\mathrm{with\ oracle}}
-
Q_{\mathrm{after\ prune}}.
$$

若壓縮空間很多但：

$$
R_{\mathrm{prune}}\gg0,
$$

則剪枝策略失敗。

---

# 10. 狀態合併

## 10.1 不同路徑可能到達同一有效狀態

若：

$$
\tau_1
:
S_t
\rightarrow
S_a
$$

以及：

$$
\tau_2
:
S_t
\rightarrow
S_b
$$

而對後續任務而言：

$$
S_a
\sim_G
S_b,
$$

則可以合併。

---

## 10.2 任務相對等價

本文不要求：

$$
S_a=S_b.
$$

而只要求：

$$
S_a
\sim_G
S_b,
$$

表示對目前目標 $G$ 而言，兩者在後續可行行動與價值上近似等價。

---

## 10.3 合併算子

$$
\mathfrak M
:
\{S_a,S_b,\ldots\}
\rightarrow
[S]_{\sim_G}.
$$

這能把樹轉為圖，降低重複計算。

---

# 11. 抽象

## 11.1 抽象不是丟資料

抽象化 $\mathfrak A$ 將高解析狀態轉換為對目前地平線更有效的表示：

$$
\mathfrak A
:
S^{high}
\rightarrow
S^{abstract}.
$$

要求：

$$
RelevantStructure(S^{high},G)
\subseteq
RecoverableStructure(S^{abstract},G).
$$

也就是至少保留對目標真正重要的結構。

---

## 11.2 抽象粒度

可定義抽象層：

$$
L_0,L_1,\ldots,L_k.
$$

其中：

$$
Detail(L_0)
>
Detail(L_1)
>
\cdots
>
Detail(L_k).
$$

遠期分支逐步提升抽象層級。

---

# 12. 多尺度未來

## 12.1 近程未來

近程未來：

$$
h\in[1,h_1].
$$

使用高解析狀態：

$$
S_{t+1},
S_{t+2},
\ldots.
$$

可保留：

- 具體行動；
- 具體事件；
- 明確資源；
- 局部因果；
- 可驗證狀態機轉移。

---

## 12.2 中程未來

中程：

$$
h\in(h_1,h_2].
$$

不再展開所有事件，而使用：

$$
ScenarioFamily_j.
$$

例如：

- 快速擴張；
- 穩定防守；
- 資源耗盡；
- 對手結盟；
- 制度失效。

其目的是保留結構差異，而不是逐秒模擬。

---

## 12.3 遠程未來

遠程：

$$
h>h_2.
$$

可使用：

$$
Attractor_k,
$$

或：

$$
Region_k
\subset
\Omega.
$$

例如：

- 穩定均衡域；
- 高風險崩潰域；
- 技術主導域；
- 多方合作域；
- 不可逆鎖定域。

因此：

$$
\boxed{
\text{far future}
\neq
\text{low-confidence detailed story}.
}
$$

---

# 13. 解析度自適應

## 13.1 解析度函數

令：

$$
r(h)
$$

表示地平線 $h$ 的解析度。

本文要求：

$$
\frac{dr}{dh}
\leq
0
$$

作為一般傾向，但允許例外。

---

## 13.2 重要遠期事件可以重新放大

若某遠期吸引子對目前決策極重要，則可以局部重新細化：

$$
\mathfrak Z
:
Region_k
\rightarrow
Subspace_k.
$$

因此抽象不是單向不可逆丟失，而是：

$$
Abstract
\leftrightarrow
Refine.
$$

---

# 14. 展開政策

## 14.1 Breadth-first 與 Depth-first 都不是普遍最優

寬度優先：

$$
BFS
$$

較適合尋找多個早期分支。

深度優先：

$$
DFS
$$

較適合快速測試一條長路徑。

APSC 使用自適應政策：

$$
\pi_{expand}
:
(S_t,G,B,\Theta)
\mapsto
Strategy.
$$

---

## 14.2 Hybrid Expansion

可使用：

$$
\text{breadth near uncertainty}
+
\text{depth near commitment}.
$$

即：

- 分歧大時先廣；
- 某分支價值提高後再深；
- 發現規則衝突時回溯；
- 發現關鍵未知時切換觀察。

---

# 15. 展開停止條件

## 15.1 局部分支停止

某分支 $\omega_i$ 若：

$$
EV_{\mathrm{expand}}(\omega_i)
\leq
C_{\mathrm{expand}}(\omega_i),
$$

則停止該分支。

---

## 15.2 全局停止

若所有活躍分支皆滿足：

$$
EV_{\mathrm{expand}}(\omega_i)
\leq
C_{\mathrm{expand}}(\omega_i)
+
\epsilon,
$$

則：

$$
StopExpansion=1.
$$

---

# 16. 狀態空間中的觀察位置

## 16.1 觀察改變的是可知空間

即使世界狀態不變，新的觀察也會改變：

$$
\widehat{\Omega}_t.
$$

因此：

$$
WorldState_t
=
constant
$$

仍可能有：

$$
BeliefSpace_t
\rightarrow
BeliefSpace_{t+1}.
$$

---

## 16.2 部分觀察

若觀察函數為：

$$
O_t
=
g(S_t),
$$

且 $g$ 非單射，則多個世界狀態可能對應同一觀察。

因此：

$$
O_t
\Rightarrow
\{S_t^{(1)},S_t^{(2)},\ldots\}.
$$

這也是 Paper 03 反事實觀察展開算子存在的基礎。

---

# 17. 對手與環境反作用

## 17.1 未來分支不是被動存在

在互動環境中，行動會改變分支結構：

$$
a_t
:
\Omega_t
\rightarrow
\Omega_{t+1}.
$$

對手也可以主動：

- 隱藏資訊；
- 製造假象；
- 改變規則；
- 消耗資源；
- 阻斷路徑；
- 創造新分支。

---

## 17.2 對抗式可達性

對手存在時：

$$
Reachable
$$

不再只取決於自己。

可以寫為：

$$
Reachable_A
(
S_t,
\omega
\mid
\pi_B
).
$$

其中：

$$
\pi_B
$$

是對手策略。

因此對抗環境中的可達性本身是條件性的。

---

# 18. 受約束可能空間的正式模型

本文提出最小形式：

$$
\mathcal P_t
=
\left\langle
S_t,
\widetilde{\Omega}_t,
\mathcal R_t,
\mathcal C_t,
\mathcal B_t,
\mathcal G_t,
\Pi_{\mathcal K},
\pi_{expand}
\right\rangle.
$$

其中：

- $S_t$：當前狀態；
- $\widetilde{\Omega}_t$：候選空間；
- $\mathcal R_t$：規則集合；
- $\mathcal C_t$：因果結構；
- $\mathcal B_t$：資源與邊界；
- $\mathcal G_t$：可達圖；
- $\Pi_{\mathcal K}$：約束投影；
- $\pi_{expand}$：展開政策。

工作可能空間則為：

$$
\widehat{\Omega}_t
=
\Pi_{\mathcal K}
(
\widetilde{\Omega}_t
).
$$

---

# 19. 評估方法

## 19.1 狀態一致性率

$$
ConsistencyRate
=
\frac{
N_{\mathrm{valid}}
}{
N_{\mathrm{generated}}
}.
$$

---

## 19.2 不可達分支比例

$$
UnreachableRatio
=
\frac{
N_{\mathrm{unreachable}}
}{
N_{\mathrm{generated}}
}.
$$

越低代表候選生成越貼近實際可行域。

---

## 19.3 關鍵分支保留率

$$
Recall_{\mathrm{critical}}.
$$

---

## 19.4 空間壓縮率

$$
Compression
=
1-
\frac{
|\widehat{\Omega}_{after}|
}{
|\widehat{\Omega}_{before}|
}.
$$

---

## 19.5 每單位資源有效分支數

$$
Efficiency_{\Omega}
=
\frac{
N_{\mathrm{decision\ relevant}}
}{
C_{\mathrm{compute}}
}.
$$

---

## 19.6 抽象失真

令：

$$
D_{\mathrm{abstract}}
=
d
(
Decision(S^{high}),
Decision(S^{abstract})
).
$$

若抽象後導致完全不同決策，表示抽象粒度可能過粗。

---

# 20. 失敗模式

主要失敗包括：

1. **State Hallucination**：狀態本身被模型補錯；
2. **Rule Rigidity**：把軟規則誤當硬規則；
3. **Rule Leakage**：用未授權或未知規則推演；
4. **Causal Overclaim**：把相關當因果；
5. **Reachability Blindness**：只看合法，不看能否抵達；
6. **Branch Explosion**：分支數失控；
7. **Risk Blind Pruning**：剪掉低機率高風險分支；
8. **Merge Error**：錯誤合併不同狀態；
9. **Abstraction Collapse**：抽象時丟失決策關鍵變量；
10. **Far-Future False Precision**：遠期過度細節化；
11. **Opponent Stationarity Error**：錯把對手當不會反應；
12. **Budget Misallocation**：資源花在低價值分支。

---

# 21. 可否證命題

## 命題一：受約束生成優勢

若：

$$
ConstrainedGeneration
$$

不能比單純生成降低非法或不可達分支比例，則約束層沒有工程增益。

---

## 命題二：多尺度展開優勢

若多尺度方法在固定預算下不能比統一高解析展開取得更佳：

$$
Q_{\mathrm{decision}}
$$

或更低成本，則其必要性受到挑戰。

---

## 命題三：合併有效性

若狀態合併持續造成高：

$$
R_{\mathrm{merge}},
$$

則任務相對等價關係定義需要修正。

---

## 命題四：剪枝必須保留關鍵分支

若壓縮率提高卻使：

$$
Recall_{\mathrm{critical}}
$$

顯著下降，則該剪枝策略不可接受。

---

# 22. 與 Paper 01 的關係

Paper 01 定義：

$$
APSC
=
Neural
+
State
+
Constraint
+
PossibilityOperators
+
AdaptiveControl
+
CognitiveProfile.
$$

本文正式展開其中：

$$
State
+
Constraint
+
PossibilitySpace.
$$

即：

$$
\boxed{
\text{What can be represented, what can happen, and what is worth expanding?}
}
$$

Paper 03 則將在此基礎上回答：

$$
\boxed{
\text{What should be observed before more expansion?}
}
$$

---

# 23. 核心命題總結

### 命題一：工作空間命題

$$
\boxed{
\widehat{\Omega}
\subset
\Omega_{\mathrm{possible}}
}
$$

智能只維護任務相關的有限工作可能空間。

### 命題二：合法性不等於可達性

$$
\boxed{
Legal(\omega)
\not\Rightarrow
Reachable(\omega).
}
$$

### 命題三：低機率不等於可剪枝

$$
\boxed{
P(\omega)\ll1
\not\Rightarrow
Remove(\omega).
}
$$

### 命題四：遠期應降低解析度

$$
\boxed{
h\uparrow
\Rightarrow
Resolution(h)\downarrow
}
$$

作為一般原則。

### 命題五：樹應逐步轉成圖

$$
\boxed{
\text{Equivalent future states should be merged when task-relevant structure is preserved.}
}
$$

### 命題六：未來推演品質不是步數

$$
\boxed{
\text{Future cognition quality}
\neq
\text{rollout depth alone}.
}
$$

真正需要同時衡量：

$$
ConstraintConsistency,
Reachability,
CriticalRecall,
AbstractionQuality,
ResourceEfficiency.
$$

---

# 24. 結論

本文建立 APSC 的受約束可能空間核心。

未來推演不應被理解為：

$$
\text{generate more futures}.
$$

而應理解為：

$$
\boxed{
\text{generate}
\rightarrow
\text{constrain}
\rightarrow
\text{filter}
\rightarrow
\text{rank}
\rightarrow
\text{merge}
\rightarrow
\text{abstract}
\rightarrow
\text{refine when needed}.
}
$$

神經模型負責提出候選，約束核心負責限制可能空間，可達性負責排除無法抵達的狀態，剪枝負責控制資源，合併負責去除重複，抽象負責將遠期未來轉為適當尺度。

因此真正的未來智能不是把「之後、之之後、之之之後」無限算下去，而是：

> 在每個尺度上，只保留對當前目標、風險與決策真正有價值的結構。

這使 APSC 從一般「長思考」概念，進一步成為一套可以被工程化、測量與否證的可能空間控制框架。

下一篇將處理本文刻意留下的核心問題：

> 當工作可能空間仍然過大或關鍵狀態未知時，AI 應該繼續內部推演，還是先取得新的觀察？

這將導向 APSC Paper 03 的核心：**反事實觀察展開空間算子族**。

---

## 版本記錄

### v0.1 — 2026-08-24

本版首次固定：

1. APSC 受約束可能空間的 canonical 定義；
2. 狀態五元表示；
3. known / unknown / uncertain 狀態分離；
4. Hard / Soft / Probabilistic / Unknown Rule 分層；
5. Candidate Transition 與 Constraint Projection；
6. 因果相容性與三值因果狀態；
7. 有界可達性；
8. 分支優先度函數；
9. 四類基本剪枝；
10. Critical Branch Recall；
11. Pruning Regret；
12. 任務相對狀態等價與 Merge；
13. 多層抽象與 refine；
14. Near / Mid / Far Horizon；
15. 自適應展開政策；
16. 局部與全局停止條件；
17. 部分觀察下的 belief-space 更新；
18. 對抗式可達性；
19. 受約束可能空間正式模型；
20. 評估指標與可否證命題。
