# 反事實觀察展開空間算子族：從介入、觀察價值到決策相關的可能空間收縮

**Counterfactual Observation Expansion Operators: From Intervention and Observation Value to Decision-Relevant Possibility-Space Contraction**

**系列：Adaptive Possibility-Space Cognition（APSC）／Paper 03 of 06**  
**版本：v0.1**  
**日期：2026-08-24**  
**作者：Neo.K**  
**機構：EveMissLab / EVEMISS Technology**

---

## 摘要

在多步推演、部分觀察、因果不完備與有限計算資源的環境中，智能系統面臨一個經常被忽略的問題：當目前可能空間仍然過大時，是否應繼續內部推演，還是先取得新的觀察？傳統反事實推理主要處理「若世界中的某變量被改變，結果會如何」，而主動觀察方法則通常直接評估「查詢某資訊是否有價值」。本文提出更一般化的 **反事實觀察展開**（Counterfactual Observation Expansion, COE）概念：在真正執行觀察之前，先展開該觀察可能返回的結果，以及每個結果將如何重構、壓縮、分裂、合併或重新排序當前工作可能空間。

本文將觀察視為一種改變認知狀態而不必直接改變世界狀態的操作，並正式區分 intervention、observation、counterfactual intervention 與 counterfactual observation expansion。本文提出觀察結果分支、後驗工作空間、資訊增益、決策價值、風險分辨力、成本與延遲等評估量，並建立一組觀察相關算子族，包括：候選觀察生成、觀察結果展開、空間更新、資訊價值評估、決策相關性評估、觀察選擇、觀察執行與觀察後重規劃。

本文進一步指出：高資訊量觀察不一定是高決策價值觀察；低熵結果不一定改善決策；而某些低機率觀察雖然不大幅降低不確定性，卻可能在高風險情境中具有極高價值。故本文提出 Decision-Relevant Observation Value、Risk-Sensitive Observation Value 與 Observation Regret 等概念，並將「觀察前模擬觀察」視為 APSC 中降低組合爆炸的重要機制。

本文主張，成熟智能系統不應只在內部一直「想」，而應能在適當時機選擇：

$$
\boxed{
\text{Think}
\rightarrow
\text{Counterfactually evaluate observation}
\rightarrow
\text{Observe}
\rightarrow
\text{Collapse or reshape possibility space}
\rightarrow
\text{Think again}.
}
$$

這種能力使觀察成為認知計算的一部分，而不是推理流程之外的附屬輸入。

**關鍵詞：** 反事實觀察、主動觀察、可能空間、資訊增益、決策價值、部分觀察、因果推演、認知算子、觀察成本、觀察後驗、風險敏感觀察、APSC

---

# 1. 問題的提出

## 1.1 一直內部推演不是普遍最優

在 APSC Paper 02 中，工作可能空間記為：

$$
\widehat{\Omega}_t.
$$

若：

$$
|\widehat{\Omega}_t|
$$

很大，最直接的做法是繼續展開：

$$
\widehat{\Omega}_t
\xrightarrow{\mathfrak E}
\widehat{\Omega}_{t+1}.
$$

但這可能產生：

$$
|\widehat{\Omega}_{t+1}|
>
|\widehat{\Omega}_t|.
$$

也就是越想越多。

因此，智能系統需要另一種能力：

> 在繼續展開之前，先判斷是否存在某個觀察，可以以較低成本直接縮小或重新組織可能空間。

---

## 1.2 「觀察」不是單純讀入更多資料

令世界真實狀態為：

$$
S_t^W.
$$

智能體目前的工作認知狀態為：

$$
B_t.
$$

觀察：

$$
q
$$

產生結果：

$$
o.
$$

世界本身可能完全不變：

$$
S_{t+1}^W
=
S_t^W,
$$

但認知狀態會改變：

$$
B_t
\xrightarrow{q,o}
B_{t+1}.
$$

因此，觀察是一種：

$$
\boxed{
\text{epistemic state transition}
}
$$

而不是必然的世界狀態轉移。

---

# 2. 四種不同操作

## 2.1 Intervention

介入直接改變世界：

$$
do(X=x').
$$

其核心問題是：

> 如果我讓某變量改變，後果是什麼？

---

## 2.2 Observation

觀察不直接設定世界變量，而取得：

$$
o
\sim
P(O\mid S).
$$

其核心問題是：

> 世界現在呈現什麼資訊？

---

## 2.3 Counterfactual Intervention

反事實介入在不真正執行介入時，先模擬：

$$
do(X=x')
\Rightarrow
\widehat Y.
$$

這是一種假設性世界改變。

---

## 2.4 Counterfactual Observation Expansion

本文提出：

$$
\boxed{
\mathfrak O_q^{CF}
}
$$

其目的不是改變世界，也不是立刻去看，而是：

> 在觀察 $q$ 真正發生以前，先展開它可能得到的觀察結果，以及每個結果對工作可能空間、決策與風險的影響。

因此：

$$
\mathfrak O_q^{CF}
:
\widehat{\Omega}_t
\rightarrow
\left\{
(o_i,
\widehat{\Omega}_{t\mid o_i})
\right\}_{i=1}^{n}.
$$

---

# 3. 觀察候選空間

## 3.1 不是所有東西都值得觀察

令候選觀察集合為：

$$
\mathcal Q_t
=
\{
q_1,q_2,\ldots,q_m
\}.
$$

例如：

- 搜尋某份文件；
- 詢問某個感測器；
- 查看遊戲畫面；
- 檢查某程序狀態；
- 讀取對手最近行動；
- 執行一次測試；
- 查詢外部 API；
- 重新觀察同一對象；
- 對某未知變量進行量測。

---

## 3.2 觀察可供性

候選觀察不是任意產生。

可以定義：

$$
Afford(q\mid B_t,G_t)
$$

表示觀察 $q$ 對當前認知狀態與目標是否具有可供性。

只有：

$$
Afford(q)\geq\tau_q
$$

的觀察，才進入候選集合。

---

# 4. 觀察結果展開

## 4.1 結果空間

對某候選觀察 $q$：

$$
\mathcal O(q)
=
\{
o_1,o_2,\ldots,o_n
\}.
$$

每一結果可有權重：

$$
p_i
=
P(o_i\mid B_t,q).
$$

---

## 4.2 後驗工作可能空間

若觀察到 $o_i$，則工作空間更新為：

$$
\widehat{\Omega}_{t\mid o_i}
=
Update
(
\widehat{\Omega}_t,
q,
o_i
).
$$

因此反事實觀察展開可寫為：

$$
\mathfrak O_q^{CF}
(
\widehat{\Omega}_t
)
=
\left\{
(
o_i,
p_i,
\widehat{\Omega}_{t\mid o_i}
)
\right\}_{i=1}^{n}.
$$

---

# 5. 觀察造成的空間變化

## 5.1 空間收縮

最典型情況：

$$
|\widehat{\Omega}_{t\mid o_i}|
<
|\widehat{\Omega}_t|.
$$

這代表觀察排除了部分候選世界。

---

## 5.2 空間分裂

有時觀察會揭露以前未區分的結構：

$$
\widehat{\Omega}_t
\rightarrow
\widehat{\Omega}_t^{(A)}
\cup
\widehat{\Omega}_t^{(B)}.
$$

這不一定降低總節點數，但提高結構辨識。

---

## 5.3 空間擴張

新觀察也可能揭露之前未考慮的可能：

$$
|\widehat{\Omega}_{t+1}|
>
|\widehat{\Omega}_t|.
$$

因此：

$$
Observation
\not\Rightarrow
Compression.
$$

有價值的觀察可能先擴張空間，再讓後續決策更正確。

---

## 5.4 空間重排序

即使候選集合不變，也可能有：

$$
Priority_t(\omega_i)
\neq
Priority_{t+1}(\omega_i).
$$

因此觀察價值不能只看：

$$
|\Omega|.
$$

---

# 6. 資訊增益

## 6.1 熵式資訊價值

若使用機率分佈，可以定義：

$$
IG(q)
=
H(\widehat{\Omega}_t)
-
\mathbb E_{o}
[
H(\widehat{\Omega}_{t\mid o})
].
$$

其中：

$$
H(\widehat{\Omega})
=
-\sum_i
p_i\log p_i.
$$

---

## 6.2 資訊增益的限制

高資訊增益不一定改善決策。

假設：

$$
q_A
$$

能讓系統知道 100 個與任務無關的變量，而：

$$
q_B
$$

只確認一個關鍵變量。

可能有：

$$
IG(q_A)
>
IG(q_B),
$$

但：

$$
DecisionValue(q_A)
<
DecisionValue(q_B).
$$

因此 APSC 需要決策相關的觀察價值。

---

# 7. 決策相關觀察價值

## 7.1 決策價值

令目前最佳決策品質為：

$$
Q^\ast(B_t).
$$

取得觀察 $q$ 後：

$$
Q^\ast(B_{t\mid o}).
$$

則定義：

$$
DROV(q)
=
\mathbb E_o
[
Q^\ast(B_{t\mid o})
]
-
Q^\ast(B_t).
$$

其中 DROV 表示：

**Decision-Relevant Observation Value**。

---

## 7.2 淨觀察價值

考慮成本：

$$
NOV(q)
=
DROV(q)
-
C_{obs}(q).
$$

其中：

$$
C_{obs}
=
C_{time}
+
C_{compute}
+
C_{money}
+
C_{latency}
+
C_{risk}.
$$

若：

$$
NOV(q)>0,
$$

則觀察在期望上值得執行。

---

# 8. 風險敏感觀察

## 8.1 低機率結果也可能重要

假設某觀察主要結果機率為：

$$
0.99,
$$

但另有：

$$
0.01
$$

機率揭露災難性狀態。

若只用平均資訊增益，可能低估該觀察。

---

## 8.2 風險敏感價值

本文定義：

$$
RSOV(q)
=
DROV(q)
+
\lambda_r
\mathbb E_o
[
RiskReduction(o)
]
-
C_{obs}(q).
$$

其中：

$$
\lambda_r
$$

依任務風險敏感度調整。

因此：

$$
\boxed{
\text{low probability}
\not\Rightarrow
\text{low observation value}.
}
$$

---

# 9. 反事實觀察算子族

本文提出第一版算子族：

$$
\mathfrak F_{obs}
=
\{
\mathfrak Q,
\mathfrak O^{CF},
\mathfrak U,
\mathfrak I_G,
\mathfrak D_V,
\mathfrak R_V,
\mathfrak S_O,
\mathfrak O,
\mathfrak R_P
\}.
$$

其中：

- $\mathfrak Q$：Candidate Observation Generation；
- $\mathfrak O^{CF}$：Counterfactual Observation Expansion；
- $\mathfrak U$：Belief / Possibility Update；
- $\mathfrak I_G$：Information Gain Evaluation；
- $\mathfrak D_V$：Decision Value Evaluation；
- $\mathfrak R_V$：Risk-Sensitive Value Evaluation；
- $\mathfrak S_O$：Observation Selection；
- $\mathfrak O$：Observation Execution；
- $\mathfrak R_P$：Post-Observation Replanning。

---

# 10. 候選觀察生成算子

## 10.1 定義

$$
\mathfrak Q
:
(B_t,G_t,\widehat{\Omega}_t)
\rightarrow
\mathcal Q_t.
$$

---

## 10.2 生成原則

候選觀察應優先來自：

1. 高不確定變量；
2. 高決策敏感變量；
3. 高風險分支；
4. 互斥世界的關鍵分辨點；
5. 因果模型中的未知邊；
6. 對手策略中的不確定節點；
7. 驗證成本低但能排除大量分支的檢查。

---

# 11. 觀察分辨力

## 11.1 Pairwise Discrimination

對兩個候選世界：

$$
\omega_a,\omega_b,
$$

若觀察 $q$ 對兩者產生不同結果：

$$
P(o\mid\omega_a,q)
\neq
P(o\mid\omega_b,q),
$$

則 $q$ 具有分辨力。

---

## 11.2 Discrimination Score

可定義：

$$
Disc(q)
=
\sum_{a<b}
w_{ab}
D
\left(
P(O\mid\omega_a,q),
P(O\mid\omega_b,q)
\right).
$$

其中 $D$ 可為某種分佈距離。

---

# 12. 觀察與因果

## 12.1 看見不等於干預

若觀察：

$$
X=x
$$

不能直接推出：

$$
do(X=x).
$$

因此：

$$
P(Y\mid X=x)
$$

與：

$$
P(Y\mid do(X=x))
$$

必須區分。

---

## 12.2 觀察選擇也可能有偏差

某些觀察只在特定條件下可得：

$$
P(q\text{ available}\mid S)
\neq
constant.
$$

因此「能觀察到」本身也可能包含資訊。

這表示 observation policy 可能產生 selection bias。

---

# 13. 觀察成本模型

## 13.1 成本不是只有時間

令：

$$
C_{obs}(q)
=
\alpha_t C_t
+
\alpha_c C_c
+
\alpha_m C_m
+
\alpha_e C_e
+
\alpha_r C_r.
$$

其中：

- $C_t$：時間成本；
- $C_c$：計算成本；
- $C_m$：金錢或資源成本；
- $C_e$：執行／操作成本；
- $C_r$：觀察本身帶來的風險。

---

## 13.2 某些觀察會改變世界

例如：

- 主動掃描可能暴露自身；
- 詢問對手可能改變對手策略；
- 執行測試可能消耗樣本；
- 檢查系統可能造成延遲；
- 進入某畫面可能觸發事件。

因此觀察不一定是：

$$
WorldNeutral.
$$

可以定義：

$$
ObserverEffect(q).
$$

---

# 14. 觀察前展開深度

## 14.1 觀察本身也不能無限模擬

如果每個候選觀察有 $n$ 個可能結果，而每個結果後又展開 $k$ 步：

$$
m\times n\times b^k
$$

同樣可能爆炸。

---

## 14.2 有界觀察展開

因此定義：

$$
Depth_{COE}
\leq
d_{obs}.
$$

通常只需要估計：

1. 可能結果；
2. 結果後的空間收縮；
3. 是否改變首選決策；
4. 是否排除高風險分支。

不必把每個觀察結果後的全部未來算到底。

---

# 15. 觀察選擇

## 15.1 單一觀察

最簡單情況：

$$
q^\ast
=
\arg\max_{q\in\mathcal Q_t}
NOV(q).
$$

---

## 15.2 風險敏感觀察

$$
q^\ast
=
\arg\max_{q\in\mathcal Q_t}
RSOV(q).
$$

---

## 15.3 多觀察序列

若觀察可以串接：

$$
q_1
\rightarrow
o_1
\rightarrow
q_2
\rightarrow
o_2.
$$

則觀察策略本身形成政策：

$$
\pi_O
:
B_t
\rightarrow
q_t.
$$

這會在未來工程中形成 Active Observation Runtime。

---

# 16. 觀察停止條件

## 16.1 不需要把所有未知都查清楚

若：

$$
\max_{q\in\mathcal Q_t}
NOV(q)
\leq
0,
$$

則：

$$
StopObserve=1.
$$

---

## 16.2 決策穩定停止

若對所有主要候選觀察：

$$
Decision^\ast(B_t)
=
Decision^\ast(B_{t\mid o}),
$$

則即使仍有資訊未知，也可能不值得觀察。

因此：

$$
\boxed{
\text{epistemic completeness is not required for decision sufficiency}.
}
$$

---

# 17. 觀察後重規劃

## 17.1 觀察不是終點

取得：

$$
o_t
$$

後：

$$
B_{t+1}
=
Update(B_t,q_t,o_t).
$$

接著重新計算：

$$
\widehat{\Omega}_{t+1},
$$

並再次選擇：

$$
u_{t+1}^\ast
\in
\mathfrak F.
$$

---

## 17.2 閉環

因此形成：

$$
Think
\rightarrow
COE
\rightarrow
Observe
\rightarrow
Update
\rightarrow
Replan
\rightarrow
Think.
$$

正式寫為：

$$
B_t
\xrightarrow{\mathfrak O^{CF}}
\mathcal Q_t
\xrightarrow{\mathfrak S_O}
q_t
\xrightarrow{\mathfrak O}
o_t
\xrightarrow{\mathfrak U}
B_{t+1}.
$$

---

# 18. 觀察與剪枝耦合

## 18.1 觀察可以替代大量剪枝計算

假設原空間：

$$
|\widehat{\Omega}_t|
=
10^5.
$$

一個觀察可能將其壓至：

$$
10^2.
$$

此時：

$$
Cost_{observe}
<
Cost_{deep\ prune}
$$

則觀察優先。

---

## 18.2 觀察也可能救回被錯剪的分支

若某分支原本因低機率被降權，但新觀察支持它：

$$
P_{t+1}(\omega)
\gg
P_t(\omega),
$$

則系統必須允許：

$$
Resurrect(\omega).
$$

因此剪枝最好區分：

$$
Discard
$$

與：

$$
Dormant.
$$

---

# 19. 反事實觀察與對手建模

## 19.1 對手也可能被觀察

例如：

$$
q
=
\text{observe opponent action}.
$$

可能結果：

$$
\{
rush,
defend,
expand,
feint
\}.
$$

每一結果改變：

$$
\Omega_A.
$$

---

## 19.2 觀察可能暴露意圖

若對手知道自己被觀察，則：

$$
q
\rightarrow
Reaction_B.
$$

因此：

$$
Outcome(q)
$$

不只是資訊返回，也可能包含反作用。

這可寫為：

$$
\mathfrak O_q^{interactive}.
$$

---

# 20. 觀察可信度

## 20.1 觀察不一定正確

令：

$$
Rel(o)
\in
[0,1].
$$

低可信觀察不應直接覆蓋原空間。

---

## 20.2 誤觀察模型

若感測器錯誤率為：

$$
\epsilon_q,
$$

則：

$$
P(o\mid S,q)
$$

應包含噪聲模型。

因此：

$$
Observation
\neq
Truth.
$$

---

# 21. 觀察後驗更新

## 21.1 機率式更新

如果可用 Bayes：

$$
P(\omega\mid o,q)
\propto
P(o\mid\omega,q)
P(\omega).
$$

---

## 21.2 非機率式更新

若沒有可靠機率，也可以使用：

- supported；
- contradicted；
- compatible；
- unresolved；
- newly-generated；

等狀態更新。

APSC 不要求所有可能空間都必須概率化。

---

# 22. 觀察價值的多目標形式

觀察選擇可寫為：

$$
V_{obs}(q)
=
w_I IG(q)
+
w_D DROV(q)
+
w_R RiskReduction(q)
+
w_C Compression(q)
-
w_K Cost(q).
$$

權重依 Cognitive Operating Profile 調整。

---

# 23. 與 Cognitive Operating Profile 的接口

若使用者偏好快速回答：

$$
\theta_o\downarrow.
$$

若高風險任務：

$$
\theta_o\uparrow,
\qquad
\theta_r\uparrow.
$$

若研究探索：

$$
\theta_o\uparrow,
\qquad
\theta_{cf}\uparrow.
$$

因此觀察政策不是固定常數，而受：

$$
\Theta
$$

控制。

---

# 24. 觀察後悔

## 24.1 錯過觀察

若本來有高價值觀察 $q^\ast$，系統沒有執行，造成決策損失：

$$
R_{\mathrm{miss}}
=
Q^\ast_{\mathrm{with}\ q^\ast}
-
Q_{\mathrm{actual}}.
$$

---

## 24.2 浪費觀察

若執行了低價值觀察：

$$
R_{\mathrm{waste}}
=
C_{obs}(q)
-
DROV(q).
$$

---

## 24.3 總觀察後悔

$$
R_{obs}
=
R_{\mathrm{miss}}
+
R_{\mathrm{waste}}.
$$

---

# 25. 觀察選擇的失敗模式

主要包括：

1. **High-Entropy Distraction**：選擇資訊很多但與決策無關的觀察；
2. **Decision Blindness**：忽略真正會改變決策的變量；
3. **Risk Blindness**：忽略低機率高風險結果；
4. **Observer Effect Neglect**：忽略觀察會改變世界；
5. **Noisy Observation Overtrust**：過度相信不可靠觀察；
6. **Infinite Checking**：陷入無限查證；
7. **Redundant Observation**：重複取得高度相關資訊；
8. **Premature Observation**：在內部已有足夠資訊時仍去查；
9. **Late Observation**：已花大量推演成本後才查一個本可早期排除大量分支的資訊；
10. **Reactive Opponent Error**：忽略對手會因被觀察而改變行為。

---

# 26. 實驗設計

## 26.1 Baseline A：Pure Rollout

只允許：

$$
Expand
+
Prune.
$$

---

## 26.2 Baseline B：Reactive Observation

只有在不確定性超過閾值時直接觀察，不做反事實觀察展開。

---

## 26.3 APSC-COE

先：

$$
\mathfrak O_q^{CF}
$$

估計觀察價值，再決定是否觀察。

---

## 26.4 評估

比較：

$$
Q_{\mathrm{decision}},
$$

$$
C_{\mathrm{compute}},
$$

$$
C_{\mathrm{observation}},
$$

$$
Latency,
$$

$$
R_{obs},
$$

$$
Recall_{\mathrm{critical}}.
$$

---

# 27. 可否證命題

## 命題一：COE 應改善觀察選擇

若：

$$
APSC\text{-}COE
$$

長期不能比簡單 heuristic 更有效選擇觀察，則 COE 的工程價值受到否證。

---

## 命題二：高資訊不等於高決策價值

應能構造任務使：

$$
IG(q_A)
>
IG(q_B)
$$

但：

$$
DROV(q_A)
<
DROV(q_B).
$$

若所有任務都無法區分兩者，則引入 DROV 的必要性需要重新評估。

---

## 命題三：觀察應降低部分深度推演需求

若在適當任務中：

$$
COE+Observe
$$

不能比：

$$
DeepRollout
$$

以更低成本達到相近或更高決策品質，則其核心效率主張受到挑戰。

---

# 28. 正式 COE 模型

本文提出：

$$
\mathcal{COE}_t
=
\left\langle
B_t,
\widehat{\Omega}_t,
\mathcal Q_t,
\mathcal O,
P_O,
\mathfrak O^{CF},
V_{obs},
C_{obs},
\pi_O
\right\rangle.
$$

其中：

- $B_t$：認知／信念狀態；
- $\widehat{\Omega}_t$：工作可能空間；
- $\mathcal Q_t$：候選觀察；
- $\mathcal O$：觀察結果空間；
- $P_O$：結果權重模型；
- $\mathfrak O^{CF}$：反事實觀察展開；
- $V_{obs}$：觀察價值；
- $C_{obs}$：觀察成本；
- $\pi_O$：觀察政策。

---

# 29. 核心命題總結

### 命題一：觀察是認知狀態轉移

$$
\boxed{
Observation
:
B_t
\rightarrow
B_{t+1}.
}
$$

### 命題二：觀察可以先被反事實展開

$$
\boxed{
\mathfrak O_q^{CF}
\text{ occurs before }
\mathfrak O_q.
}
$$

### 命題三：資訊增益不等於決策價值

$$
\boxed{
IG(q)
\not\equiv
DROV(q).
}
$$

### 命題四：低機率觀察結果可能具高價值

$$
\boxed{
P(o)\ll1
\not\Rightarrow
Value(o)\ll1.
}
$$

### 命題五：觀察不必使空間縮小才有價值

$$
\boxed{
|\Omega_{t+1}|>|\Omega_t|
\not\Rightarrow
ObservationFailure.
}
$$

### 命題六：觀察本身也需要停止規則

$$
\boxed{
\max_q NOV(q)\leq0
\Rightarrow
StopObserve.
}
$$

---

# 30. 與前兩篇的關係

Paper 01 建立：

$$
APSC.
$$

Paper 02 回答：

$$
\text{哪些未來值得展開？}
$$

本文回答：

$$
\boxed{
\text{在繼續展開以前，有沒有更值得先取得的觀察？}
}
$$

因此三篇形成：

$$
State
\rightarrow
PossibilitySpace
\rightarrow
CounterfactualObservation
\rightarrow
UpdatedPossibilitySpace.
$$

---

# 31. 結論

本文提出反事實觀察展開空間算子族，將「觀察」從外部輸入行為提升為 APSC 內部的正式認知操作。

其核心循環為：

$$
\boxed{
\text{Think}
\rightarrow
\text{simulate possible observations}
\rightarrow
\text{estimate their value}
\rightarrow
\text{observe selectively}
\rightarrow
\text{update possibility space}
\rightarrow
\text{replan}.
}
$$

這一架構的重要性在於：當未來空間快速爆炸時，智能系統不必只靠更深 rollout 解決不確定性。

它可以先問：

> 哪一個觀察最值得做？

再問：

> 如果我看到 A，我會怎麼改變判斷？  
> 如果看到 B，我會怎麼改變判斷？  
> 哪一個觀察會真正改變我的決策？  
> 哪一個觀察只是資訊很多，卻沒有決策價值？  
> 哪一個低機率結果雖少見，卻能避免重大風險？

因此，APSC 的智能不再只存在於模型內部的推演長度，而存在於：

$$
\boxed{
\text{thinking}
+
\text{knowing what to observe}
+
\text{knowing when observation is worth more than further thought}.
}
$$

下一篇將接續處理：即使系統已能選擇展開與觀察，它仍然需要在時間、算力、記憶與觀察預算之間做統一調度。這將導向 APSC Paper 04：**有限認知時空與自適應計算控制**。

---

## 版本記錄

### v0.1 — 2026-08-24

本版首次固定：

1. Counterfactual Observation Expansion（COE）canonical 定義；
2. intervention / observation / counterfactual intervention / COE 四分；
3. Candidate Observation Space；
4. Observation Affordance；
5. Observation Outcome Expansion；
6. Posterior Working Possibility Space；
7. 空間收縮、分裂、擴張與重排序；
8. Information Gain；
9. Decision-Relevant Observation Value（DROV）；
10. Net Observation Value（NOV）；
11. Risk-Sensitive Observation Value（RSOV）；
12. Observation Operator Family；
13. Observation Discrimination；
14. Observation Cost Model；
15. Observer Effect；
16. Bounded COE Depth；
17. Observation Policy；
18. StopObserve；
19. Post-Observation Replanning；
20. Observation-Pruning Coupling；
21. Interactive Observation；
22. Observation Reliability；
23. Probabilistic / Non-Probabilistic Update；
24. Multi-Objective Observation Value；
25. Cognitive Operating Profile interface；
26. Observation Regret；
27. Baseline / COE experiment design；
28. Formal COE model；
29. 可否證命題。
