# 有限認知時空與自適應計算控制：從資源預算、邊際認知價值到停止、搶佔與提交

**Finite Cognitive Spacetime and Adaptive Computation Control: From Resource Budgets and Marginal Cognitive Value to Stopping, Preemption, and Commitment**

**系列：Adaptive Possibility-Space Cognition（APSC）／Paper 04 of 06**  
**版本：v0.1**  
**日期：2026-08-24**  
**作者：Neo.K**  
**機構：EveMissLab / EVEMISS Technology**

---

## 摘要

自適應可能空間認知（Adaptive Possibility-Space Cognition, APSC）已在前兩篇中建立受約束可能空間與反事實觀察展開算子，但只要智能系統仍擁有有限時間、算力、記憶、觀察能力與外部工具額度，它就不可能無限制地展開、驗證、觀察與回溯。因而真正的核心問題不是「能否繼續思考」，而是「是否值得繼續思考，以及下一單位認知資源應該花在哪裡」。

本文提出 **有限認知時空**（Finite Cognitive Spacetime）與 **自適應計算控制**（Adaptive Computation Control）作為 APSC 的第四層理論。本文將認知預算表示為時間、計算、記憶、觀察、延遲與外部資源的多維向量，並將展開、驗證、觀察、剪枝、抽象、回溯、重構與提交視為具有不同成本與預期增益的候選認知操作。智能控制器的任務不再只是選答案，而是選擇下一個認知操作、分配資源、設定優先度、必要時中止低價值操作、保留可恢復檢查點，並在邊際認知價值低於邊際成本時主動停止。

本文提出 Marginal Value of Cognition、Cognitive Shadow Price、Budget Feasibility、Cognitive Scheduling、Preemption、Commitment Threshold、Decision Stability 與 Regret under Budget 等概念，並進一步區分 wall-clock time、logical cognitive depth 與 compute service，避免將「想得久」「算得多」「推得深」混為同一資源。本文亦提出即時任務、批次任務、高風險任務與研究任務下不同的控制政策，並說明為何單純增加推理 token、固定 thinking depth 或固定 verifier 次數，無法普遍得到最優結果。

本文主張：高階智能的一部分，是在有限認知時空中動態分配自身認知資源，並知道何時不再值得進一步計算。換言之：

$$
\boxed{
\text{Intelligence}
\supset
\text{allocation of cognition under finite resources}.
}
$$

**關鍵詞：** 認知時空、認知預算、自適應計算控制、邊際認知價值、停止策略、認知排程、搶佔、提交、延遲、資源分配、APSC

---

# 1. 問題的提出

## 1.1 「更多思考」不是免費資源

若智能系統擁有可用認知操作集合：

$$
\mathcal U_t
=
\{
Expand,
Observe,
Verify,
Prune,
Merge,
Abstract,
Backtrack,
Reframe,
Commit
\},
$$

每個操作都需要資源。

因此：

$$
C(u)>0.
$$

即使某操作可能提高答案品質，也必須問：

$$
\Delta Q(u)
>
C(u)
?
$$

## 1.2 從推理能力轉向認知配置能力

一個系統可能具有很強的局部推理能力，卻把大量計算花在：

- 已穩定的分支；
- 與決策無關的未知；
- 重複驗證；
- 過深遠期推演；
- 已被其他觀察否定的假設；
- 低價值候選；
- 不會改變決策的細節。

因此：

$$
ReasoningPower
\neq
ReasoningEfficiency.
$$

APSC Paper 04 的核心問題是：

$$
\boxed{
\text{Given finite resources, where should cognition be spent next?}
}
$$

---

# 2. 有限認知時空

## 2.1 認知時空的定義

本文將認知時空定義為：

> 智能系統在某一任務或持續目標下，可以用於內部計算、外部觀察、記憶維持、驗證、重規劃與決策的有限資源—時間聯合域。

表示為：

$$
\mathcal{CS}_t
=
\left\langle
B_t,
\Delta t_t,
\mathcal U_t,
\Theta_t
\right\rangle.
$$

其中：

- $B_t$：當前可用資源預算；
- $\Delta t_t$：可用 wall-clock 時間窗；
- $\mathcal U_t$：候選認知操作；
- $\Theta_t$：當前 Cognitive Operating Profile。

## 2.2 認知預算向量

定義：

$$
B_t
=
(
B_{\mathrm{wall}},
B_{\mathrm{compute}},
B_{\mathrm{memory}},
B_{\mathrm{observation}},
B_{\mathrm{external}},
B_{\mathrm{risk}}
).
$$

其中：

- $B_{\mathrm{wall}}$：實際可等待時間；
- $B_{\mathrm{compute}}$：可用計算資源；
- $B_{\mathrm{memory}}$：可用工作記憶；
- $B_{\mathrm{observation}}$：觀察／量測額度；
- $B_{\mathrm{external}}$：外部工具、API、金錢或權限額度；
- $B_{\mathrm{risk}}$：允許承擔的操作風險。

---

# 3. 時間不是單一量

## 3.1 Wall-Clock Time

實際經過時間記為：

$$
T_{\mathrm{wall}}.
$$

這是使用者真正感受到的延遲。

## 3.2 Logical Cognitive Depth

認知操作深度記為：

$$
D_{\mathrm{cog}}.
$$

例如：

$$
Expand
\rightarrow
Verify
\rightarrow
Backtrack
\rightarrow
Expand
$$

可能具有較高的邏輯深度，但未必需要很長 wall-clock time。

## 3.3 Compute Service

實際消耗的模型推理、CPU、GPU 或其他計算服務記為：

$$
C_{\mathrm{svc}}.
$$

因此：

$$
T_{\mathrm{wall}}
\neq
D_{\mathrm{cog}}
\neq
C_{\mathrm{svc}}.
$$

這三者不能混為「thinking time」。

---

# 4. 認知操作成本

對任一操作 $u$，定義成本向量：

$$
C(u)
=
(
c_w,
c_c,
c_m,
c_o,
c_e,
c_r
).
$$

分別對應：

- wall-clock；
- compute；
- memory；
- observation；
- external；
- risk。

## 4.1 成本依狀態而變

同一個操作在不同狀態下成本不同：

$$
C(u\mid S_t,B_t).
$$

例如，同樣一次 verifier：

- 對 10 行證明很便宜；
- 對 10 萬行狀態圖很昂貴。

因此成本不是固定常數。

---

# 5. 認知收益

## 5.1 預期品質提升

定義：

$$
\Delta Q(u)
=
\mathbb E
[
Q_{t+1}-Q_t
\mid
u
].
$$

其中 $Q$ 可以表示：

- 決策品質；
- 預測準確；
- 關鍵分支保留；
- 錯誤降低；
- 風險降低；
- 使用者效用。

## 5.2 邊際認知價值

本文定義：

$$
MVC(u)
=
\frac{
\mathbb E[\Delta Q(u)]
}{
\operatorname{ScalarCost}(u)
}.
$$

MVC 即：

**Marginal Value of Cognition**。

## 5.3 多維成本下的價值

如果成本不能自然壓成單一尺度，可使用：

$$
Score(u)
=
\mathbb E[\Delta Q(u)]
-
\lambda^\top C(u).
$$

其中：

$$
\lambda
=
(
\lambda_w,
\lambda_c,
\lambda_m,
\lambda_o,
\lambda_e,
\lambda_r
).
$$

---

# 6. Cognitive Shadow Price

## 6.1 資源的影子價格

當某種資源即將耗盡時，它的邊際成本應提高。

例如：

$$
B_{\mathrm{wall}}\downarrow
\Rightarrow
\lambda_w\uparrow.
$$

因此本文提出：

$$
\lambda_i
=
\lambda_i(B_t,\Theta_t,G_t).
$$

## 6.2 同一操作在不同情境下價值不同

研究任務：

$$
\lambda_w
\downarrow.
$$

即時控制任務：

$$
\lambda_w
\uparrow.
$$

高風險任務：

$$
\lambda_r
\uparrow.
$$

因此不存在普遍固定的認知成本函數。

---

# 7. 可行認知操作集合

## 7.1 Budget Feasibility

候選操作 $u$ 可執行，必須滿足：

$$
C(u)
\preceq
B_t.
$$

定義：

$$
\mathcal U_t^{feasible}
=
\{
u\in\mathcal U_t
\mid
C(u)\preceq B_t
\}.
$$

## 7.2 不可行不代表低價值

某操作可能很有價值，但超出預算：

$$
Value(u)\gg0
$$

且：

$$
u\notin
\mathcal U_t^{feasible}.
$$

此時控制器應考慮：

- 降低解析度；
- 縮短深度；
- 先抽象；
- 分階段執行；
- 延後；
- 改用替代觀察；
- 請求更多資源。

---

# 8. 自適應計算控制器

## 8.1 基本控制問題

定義控制器：

$$
\mathcal C
:
(S_t,B_t,\widehat{\Omega}_t,\Theta_t)
\rightarrow
u_t^\ast.
$$

其中：

$$
u_t^\ast
=
\arg\max_{u\in\mathcal U_t^{feasible}}
\left[
\mathbb E[\Delta Q(u)]
-
\lambda^\top C(u)
\right].
$$

## 8.2 控制器選的是認知操作，不是答案

這裡：

$$
u_t^\ast
$$

可以是：

$$
Verify
$$

而不是：

$$
Answer_A.
$$

因此控制層作用於：

$$
\boxed{
\text{cognition selection}.
}
$$

---

# 9. 認知排程

## 9.1 多操作同時存在

可能同時有：

- 分支 A 等待驗證；
- 分支 B 等待觀察；
- 分支 C 可繼續 rollout；
- 分支 D 應抽象；
- 最終答案已接近穩定。

因此需要：

$$
Schedule_t
=
\pi_{\mathrm{sched}}
(
Queue_t,
B_t,
\Theta_t
).
$$

## 9.2 Priority Queue

對認知工作項目 $j$：

$$
Priority_j
=
f(
MVC_j,
Deadline_j,
Risk_j,
Dependency_j,
Stability_j
).
$$

---

# 10. 認知搶佔

## 10.1 執行中的操作也可能失去價值

若某操作 $u_a$ 已開始，但新觀察使其價值下降：

$$
MVC_{t+1}(u_a)
\ll
MVC_t(u_a),
$$

則不應因「已經開始」而強迫完成。

## 10.2 Preemption

定義：

$$
Preempt(u_a)
$$

當：

$$
Score(u_b)
-
Score(u_a)
>
\tau_p.
$$

其中 $u_b$ 是新出現的高優先操作。

## 10.3 認知沉沒成本錯誤

如果：

$$
Cost_{\mathrm{spent}}
$$

已不可回收，則它不應單獨成為繼續執行的理由。

因此：

$$
\boxed{
\text{Spent cognitive cost is not future cognitive value.}
}
$$

---

# 11. 檢查點與可恢復認知

## 11.1 搶佔需要 checkpoint

若所有中止都使前面計算丟失，搶佔會非常昂貴。

因此可維護：

$$
Checkpoint_k
=
(
State_k,
Hypotheses_k,
Evidence_k,
OpenBranches_k
).
$$

## 11.2 Resume

重新進入時：

$$
Resume
(
Checkpoint_k
)
\rightarrow
Cognition_{k+1}.
$$

這使「停止」可以是暫停，而不必等同丟棄。

---

# 12. 即時與非即時控制

## 12.1 Real-Time Mode

若存在 deadline：

$$
T_{\mathrm{wall}}
\leq
T_{\max},
$$

控制器必須優先保證：

$$
CommitBeforeDeadline.
$$

## 12.2 Best-Effort Mode

沒有硬 deadline 時：

$$
T_{\mathrm{wall}}
$$

可以被決策品質交換。

## 12.3 Batch Mode

多任務可共同分配：

$$
B^{global}
$$

形成：

$$
\sum_i
C(u_i)
\preceq
B^{global}.
$$

因此需要跨任務資源調度。

---

# 13. 驗證資源配置

## 13.1 驗證不是越多越好

若 verifier 次數為：

$$
n_v,
$$

通常存在遞減報酬：

$$
\frac{
\partial Q
}{
\partial n_v
}
\downarrow.
$$

## 13.2 驗證停止

若下一次驗證的預期錯誤降低：

$$
\Delta E_v
$$

小於成本：

$$
C_v,
$$

則：

$$
StopVerify=1.
$$

---

# 14. 觀察與計算的競爭

## 14.1 下一單位資源要拿去想還是看？

比較：

$$
MVC_{\mathrm{expand}}
$$

與：

$$
MVC_{\mathrm{observe}}.
$$

若：

$$
MVC_{\mathrm{observe}}
>
MVC_{\mathrm{expand}},
$$

則優先觀察。

## 14.2 觀察與 verifier 的競爭

同理：

$$
MVC_{\mathrm{verify}}
$$

與：

$$
MVC_{\mathrm{observe}}
$$

也可直接比較。

---

# 15. 抽象化作為節能操作

若高解析展開成本過高：

$$
C_{\mathrm{high-res}}
\gg
B_t,
$$

可以選擇：

$$
Abstract.
$$

因此抽象本身是一種 resource-saving cognition。

---

# 16. 動態深度控制

固定：

$$
D=D_0
$$

會忽略任務差異。

本文使用：

$$
D_t^\ast
=
f(
Uncertainty_t,
Risk_t,
Budget_t,
Stability_t,
\Theta_t
).
$$

---

# 17. 動態廣度控制

$$
B_t^\ast
=
f(
BranchDiversity_t,
CriticalRisk_t,
Budget_t,
\Theta_t
).
$$

不確定性高時可提高 breadth；接近提交時則可降低 breadth 並加深局部驗證。

---

# 18. 停止是一種主動控制

傳統被動停止：

$$
Budget=0.
$$

APSC 定義主動停止：

$$
Stop
=
1
$$

當：

$$
\max_{u\in\mathcal U_t^{feasible}}
\left[
\mathbb E[\Delta Q(u)]
-
\lambda^\top C(u)
\right]
\leq
\epsilon.
$$

---

# 19. 決策穩定性

如果多個額外認知操作都不改變首選決策：

$$
Decision^\ast(B_t)
=
Decision^\ast(B_{t+1}^{(u)}),
$$

則：

$$
Stability_t\uparrow.
$$

但：

$$
DecisionStability
\not\Rightarrow
Truth.
$$

高風險任務仍可能要求額外外部驗證。

---

# 20. Commitment Threshold

定義：

$$
Commit
=
1
$$

當同時滿足：

$$
Stability_t
\geq
\tau_s,
$$

$$
Risk_t
\leq
\tau_r,
$$

$$
ExpectedGain_{\mathrm{further}}
\leq
\tau_g.
$$

快速聊天可降低穩定門檻；高風險工程則提高穩定門檻並降低允許風險。

---

# 21. 延遲—品質前沿

對某任務可形成：

$$
\mathcal F_{QL}
=
\{
(T,Q)
\}.
$$

理想控制器應接近 Pareto frontier。

因此即使：

$$
Q_A>Q_B,
$$

若：

$$
T_A\gg T_B,
$$

A 也不一定在所有使用情境中更好。

---

# 22. 資源耗盡順序

不同資源可能先耗盡。

例如：

$$
B_{\mathrm{wall}}=0
$$

但：

$$
B_{\mathrm{compute}}>0.
$$

此時仍必須提交。

反之：

$$
B_{\mathrm{compute}}=0
$$

但仍有時間，可能轉向低成本觀察或既有記憶。

---

# 23. 認知退化策略

資源下降時，可以依序：

1. 降低 breadth；
2. 降低 far-horizon resolution；
3. 延後低價值 verifier；
4. 合併相似分支；
5. 切換廉價觀察；
6. 使用摘要狀態；
7. 進入最小可行決策模式。

形成：

$$
GracefulCognitiveDegradation.
$$

---

# 24. 多代理資源共享

若存在：

$$
A_1,\ldots,A_n
$$

共享：

$$
B^{global},
$$

則：

$$
Allocation
:
B^{global}
\rightarrow
(B_1,\ldots,B_n).
$$

若：

$$
V_i\neq V_j,
$$

則平均分配未必最優。

候選方法之一，是由每個 Agent 回報：

$$
Bid_i
=
\widehat{MVC}_i.
$$

再由控制器分配。

---

# 25. 認知資源與風險

高風險任務不能只追求效率。

可定義：

$$
Score(u)
=
\mathbb E[\Delta Q(u)]
+
\lambda_r
RiskReduction(u)
-
\lambda^\top C(u).
$$

---

# 26. 不確定性與資源配置

全局不確定性高，不代表所有地方都需要更多計算。

應優先尋找：

$$
\frac{
\partial Q
}{
\partial C_i
}
$$

較高的區域。

定義：

$$
Hotspot_j
=
Uncertainty_j
\times
DecisionSensitivity_j
\times
Risk_j.
$$

資源優先分配到高 Hotspot。

---

# 27. 控制器自身的不確定性

控制器不知道真正的：

$$
\Delta Q(u).
$$

只能估計：

$$
\widehat{\Delta Q}(u).
$$

因此還有：

$$
Uncertainty
(
\widehat{MVC}(u)
).
$$

這意味著控制器自身也需要管理 meta-uncertainty。

---

# 28. 控制器的探索—利用問題

Exploit：

> 選擇目前估計 MVC 最高的操作。

Explore：

> 測試較少使用的操作，以改善未來成本與收益估計。

因此控制層也存在：

$$
Explore
\leftrightarrow
Exploit.
$$

---

# 29. 時間一致性

隨新觀察與剩餘資源變化：

$$
\pi_t
\neq
\pi_{t+1}.
$$

這是正常的。

原本計畫深入 10 層：

$$
D=10
$$

不代表新資訊出現後仍必須完成。

因此：

$$
Plan
\neq
Commitment.
$$

---

# 30. 認知 Regret

## 30.1 Allocation Regret

若 oracle 得到：

$$
Q_{\mathrm{oracle}},
$$

而實際控制器得到：

$$
Q_{\mathrm{actual}},
$$

則：

$$
R_{\mathrm{alloc}}
=
Q_{\mathrm{oracle}}
-
Q_{\mathrm{actual}}.
$$

## 30.2 Compute Waste

$$
W_{\mathrm{compute}}
=
\sum_{u\in\mathcal U_{\mathrm{executed}}}
C(u)
\cdot
\mathbf 1
[
\Delta Q(u)\leq0
].
$$

---

# 31. 認知資源利用率

$$
\eta_{\mathrm{resource}}
=
\frac{
Q_{\mathrm{final}}-Q_{\mathrm{initial}}
}{
\lambda^\top C_{\mathrm{total}}
}.
$$

但此量不能單獨最佳化，仍需同時考慮安全、關鍵分支保留與最終正確性。

---

# 32. 形式化控制模型

本文提出：

$$
\mathcal{ACC}_t
=
\left\langle
S_t,
B_t,
\mathcal U_t,
C,
\widehat{\Delta Q},
\lambda_t,
\pi_{\mathrm{sched}},
\pi_{\mathrm{stop}},
\pi_{\mathrm{commit}}
\right\rangle.
$$

其中：

- $S_t$：當前認知／任務狀態；
- $B_t$：剩餘預算；
- $\mathcal U_t$：候選認知操作；
- $C$：成本模型；
- $\widehat{\Delta Q}$：預期認知收益模型；
- $\lambda_t$：動態影子價格；
- $\pi_{\mathrm{sched}}$：排程策略；
- $\pi_{\mathrm{stop}}$：停止策略；
- $\pi_{\mathrm{commit}}$：提交策略。

---

# 33. 控制循環

完整循環：

$$
S_t
\rightarrow
\mathcal U_t^{feasible}
\rightarrow
EstimateValue
\rightarrow
Schedule
\rightarrow
Execute
\rightarrow
ObserveOutcome
\rightarrow
UpdateBudget
\rightarrow
UpdateState
\rightarrow
Recompute.
$$

因此：

$$
\boxed{
\text{Cognition itself becomes a controlled dynamical process.}
}
$$

---

# 34. 實驗設計

### Baseline A：Fixed Depth

$$
D=D_0.
$$

### Baseline B：Fixed Budget Uniform Allocation

平均分配給展開、驗證與觀察。

### Baseline C：No Preemption

操作一旦開始就必須完成。

### APSC-ACC

使用：

- dynamic MVC；
- dynamic shadow price；
- preemption；
- checkpoint；
- adaptive stop；
- adaptive commit。

---

# 35. 評估指標

比較：

$$
Q_{\mathrm{decision}},
$$

$$
T_{\mathrm{wall}},
$$

$$
C_{\mathrm{svc}},
$$

$$
C_{\mathrm{obs}},
$$

$$
R_{\mathrm{alloc}},
$$

$$
W_{\mathrm{compute}},
$$

$$
DeadlineMissRate,
$$

以及：

$$
Recall_{\mathrm{critical}}.
$$

---

# 36. 主要失敗模式

1. Overthinking；
2. Underthinking；
3. Budget Blindness；
4. Deadline Blindness；
5. No-Preemption Lock-In；
6. Sunk-Cost Cognition；
7. Verifier Overuse；
8. Observation Overuse；
9. Abstraction Too Early；
10. Abstraction Too Late；
11. Shadow-Price Miscalibration；
12. Controller Myopia；
13. Unsafe Efficiency；
14. Commit Instability。

---

# 37. 可否證命題

若自適應控制在多種任務上：

$$
Q_{\mathrm{adaptive}}
\leq
Q_{\mathrm{fixed}}
$$

且成本又不低，則自適應控制的必要性受到挑戰。

若：

$$
Preemption
$$

無法在新資訊頻繁出現的任務降低資源浪費，其工程必要性需重新評估。

若使用 MVC stopping 後：

$$
W_{\mathrm{compute}}
$$

沒有下降，且品質沒有提升，則停止判準設計失敗。

---

# 38. 與前面三篇的關係

Paper 01 定義：

$$
APSC.
$$

Paper 02 定義：

$$
\widehat{\Omega}.
$$

Paper 03 定義：

$$
\mathfrak O^{CF}.
$$

本文回答：

$$
\boxed{
\text{在有限時間與資源下，下一個 cognition 到底應該選哪一個？}
}
$$

因此形成：

$$
PossibilitySpace
+
ObservationSpace
+
ResourceBudget
\rightarrow
AdaptiveCognitiveControl.
$$

---

# 39. 與 Paper 05 的接口

本文已假定：

$$
\Theta_t
$$

會影響：

$$
\lambda_t,
$$

$$
\pi_{\mathrm{sched}},
$$

$$
\pi_{\mathrm{stop}},
$$

與：

$$
\pi_{\mathrm{commit}}.
$$

但本文不詳細定義 $\Theta$ 的政策語義。

下一篇 Paper 05 將正式處理：

$$
\boxed{
\text{Cognitive Operating Profile}.
}
$$

---

# 40. 核心命題總結

### 認知資源有限

$$
\boxed{
B_t<\infty.
}
$$

### 時間、深度與計算服務不同

$$
\boxed{
T_{\mathrm{wall}}
\neq
D_{\mathrm{cog}}
\neq
C_{\mathrm{svc}}.
}
$$

### 下一單位認知資源需要被分配

$$
\boxed{
u_t^\ast
=
\arg\max
\left(
\Delta Q
-
\lambda^\top C
\right).
}
$$

### 停止是智能操作

$$
\boxed{
EV_{\mathrm{further}}
\leq
Cost_{\mathrm{further}}
\Rightarrow
Stop.
}
$$

### 執行中的 cognition 可以被搶佔

$$
\boxed{
Started(u)
\not\Rightarrow
MustFinish(u).
}
$$

### 提交不是預算耗盡的同義詞

$$
\boxed{
Commit
\neq
BudgetExhaustion.
}
$$

### 認知最佳化是多目標約束問題

$$
\boxed{
\text{Cognitive control is multi-objective under constraints.}
}
$$

---

# 41. 結論

本文將 APSC 的可能空間與觀察算子推進到資源控制層。

高階智能不只是：

$$
\text{能不能想得更深？}
$$

而是：

$$
\boxed{
\text{現在應不應該繼續想？}
}
$$

以及：

> 下一單位資源應花在展開、觀察、驗證、剪枝、抽象還是回溯？  
> 哪個分支值得繼續？  
> 哪個 verifier 已經沒有邊際價值？  
> 哪個觀察比更多 rollout 更有效？  
> 哪個正在執行的認知工作應被打斷？  
> 何時應降解析度？  
> 何時應直接提交？

因此 APSC 的核心控制循環可收斂為：

$$
\boxed{
\text{Estimate cognitive value}
\rightarrow
\text{allocate finite resources}
\rightarrow
\text{execute}
\rightarrow
\text{measure gain}
\rightarrow
\text{reprice resources}
\rightarrow
\text{stop or continue}.
}
$$

這種架構把「thinking budget」從單純的 token 或秒數限制，提升為真正的**認知時空資源調度問題**。

下一篇將進一步固定：不同使用者、任務與 AI 本身可以如何設定與自適應修改這些控制權重。這將導向 APSC Paper 05：**Cognitive Operating Profile：可調與自適應認知政策**。

---

## 版本記錄

### v0.1 — 2026-08-24

本版首次固定：

1. Finite Cognitive Spacetime canonical 定義；
2. 多維 Cognitive Budget；
3. Wall-Clock / Cognitive Depth / Compute Service 分離；
4. Cognitive Operation Cost Vector；
5. Marginal Value of Cognition（MVC）；
6. Dynamic Cognitive Shadow Price；
7. Budget Feasible Operation Set；
8. Adaptive Computation Controller；
9. Cognitive Scheduling；
10. Priority Queue；
11. Cognitive Preemption；
12. Sunk-Cost Cognition 原則；
13. Checkpoint / Resume；
14. Real-Time / Best-Effort / Batch Mode；
15. Verification Budgeting；
16. Observation vs Compute resource competition；
17. Abstraction as resource-saving cognition；
18. Adaptive Depth；
19. Adaptive Breadth；
20. Active Stop；
21. Decision Stability；
22. Commitment Threshold；
23. Quality-Latency Frontier；
24. Resource Exhaustion Ordering；
25. Graceful Cognitive Degradation；
26. Multi-Agent Resource Allocation；
27. Risk-Adjusted Cognitive Control；
28. Cognitive Hotspot；
29. Controller Meta-Uncertainty；
30. Explore / Exploit of cognition control；
31. Time Consistency；
32. Allocation Regret；
33. Compute Waste；
34. Formal ACC model；
35. Experiment baselines；
36. 可否證命題。
