# AI Tension Arena Protocol & Benchmark Specification v0.1

**A Replayable Multi-Agent Benchmark Protocol for Adaptive Possibility-Space Cognition under Finite Cognitive Budgets**

**文件類型：技術白皮書 02 / 02**  
**系列：Adaptive Possibility-Space Cognition（APSC）**  
**版本：v0.1**  
**日期：2026-08-25**  
**作者：Neo.K**  
**機構：EveMissLab / EVEMISS Technology**

---

## 0. 文件定位

本文件是 APSC 系列的第二份技術白皮書，也是理論論文與 MVP 之間的最後一份 benchmark / protocol 母文件。

第一份白皮書《APSC Runtime Technical Architecture v0.1》固定：

- canonical cognitive runtime；
- possibility graph；
- constraint engine；
- COE；
- finite cognitive budget；
- adaptive controller；
- COP；
- receipts；
- replay。

本文件則固定：

$$
\boxed{
\text{如何讓兩個或多個 AI 在同一個受控動態世界中，被公平、可重播、可否證地比較。}
}
$$

其目標不是建立遊戲內容本身，而是建立一套：

$$
\boxed{
\text{Arena Protocol}
+
\text{Benchmark Contract}
+
\text{Scoring Contract}
+
\text{Replay Contract}.
}
$$

---

# 1. 一句話規格

AI Tension Arena（AITA）第一版工程定義：

$$
\boxed{
\text{Finite-Budget Multi-Agent World}
+
\text{Partial Observation}
+
\text{Dynamic Reaction}
+
\text{Replayable Evidence}
+
\text{Multi-Metric Evaluation}.
}
$$

核心 benchmark loop：

$$
Reset
\rightarrow
Observe
\rightarrow
Cognition
\rightarrow
Action
\rightarrow
Reaction
\rightarrow
Update
\rightarrow
Score
\rightarrow
Replay.
$$

---

# 2. Benchmark 核心不變量

## 2.1 對手不是靜態測資

$$
Opponent
\subset
TaskDynamics.
$$

Agent 的行動會改變另一方後續任務。

## 2.2 Win Rate 不是唯一分數

$$
WinRate
\not\equiv
CognitiveQuality.
$$

Benchmark 必須分開衡量：

- task utility；
- decision quality；
- cognitive efficiency；
- observation efficiency；
- critical branch recall；
- regret；
- rule compliance；
- robustness。

## 2.3 Model Strength 與 Budget 分離

$$
ModelStrength
\neq
CognitiveBudget.
$$

因此 benchmark 必須記錄並可固定：

$$
B_i.
$$

## 2.4 Replay 不依賴私有 Chain-of-Thought

$$
Replayability
\not\Rightarrow
PrivateReasoningDisclosure.
$$

AITA 只要求可重播：

- world state；
- observation；
- action；
- selected cognition operator；
- budget；
- profile；
- receipt；
- score。

## 2.5 Arena 必須允許 APSC 失敗

$$
AITA
\neq
Proof(APSC).
$$

若 baseline 更好，benchmark 必須如實顯示。

---

# 3. Arena Episode Contract

每一場 episode：

$$
\mathcal E
=
\left\langle
EID,
W_0,
Seed,
Agents,
Rules,
Budgets,
Profiles,
Horizon,
Scoring
\right\rangle.
$$

最小 JSON：

```json
{
  "episode_id": "episode://...",
  "world_id": "world://hidden-route-v01",
  "seed": 42,
  "agents": [],
  "ruleset": "rules://...",
  "budgets": {},
  "profiles": {},
  "horizon": {},
  "scoring_profile": "score://default-v01"
}
```

---

# 4. World Contract

每個 arena world 必須實作：

```text
reset(seed)
get_public_state()
observe(agent_id, query)
legal_actions(agent_id)
step(action_bundle)
is_terminal()
score_state()
export_replay_state()
```

世界狀態：

$$
W_t
=
(
E_t,
R_t,
Q_t,
H_t,
Z_t
).
$$

其中：

- $E_t$：entities / environment；
- $R_t$：rules；
- $Q_t$：resources / objectives；
- $H_t$：history；
- $Z_t$：hidden state。

每個 state field 必須標記：

```text
PUBLIC
AGENT_PRIVATE
HIDDEN
DERIVED
```

---

# 5. Observation Contract

Observation Query：

```json
{
  "query_id": "query://...",
  "agent_id": "agent://A",
  "type": "inspect|scan|ask|probe|verify",
  "target": "...",
  "cost_class": "low|medium|high"
}
```

Observation Result：

```json
{
  "observation_id": "obs://...",
  "query_id": "...",
  "payload": {},
  "reliability": 1.0,
  "cost": {},
  "observer_effect": "none|possible|confirmed"
}
```

Arena 可以包含 noisy sensor、deceptive opponent、stale information 與 partial visibility，因此：

$$
Observation
\neq
Truth.
$$

---

# 6. Agent Contract

每個 Agent Adapter 最少實作：

```text
reset(config)
ingest_observation(observation)
propose_cognition()
commit_world_action()
export_public_receipt()
```

APSC Agent 可支援：

```text
expand
observe
verify
prune
abstract
counterfactual_observe
profile_shift
commit
```

Baseline Agent 不要求支援 APSC，只要能：

```text
observe
act
```

即可，這樣 benchmark 才能比較：

$$
APSC
\text{ vs }
NonAPSC.
$$

---

# 7. Action Contract

```json
{
  "action_id": "action://...",
  "agent_id": "...",
  "type": "...",
  "arguments": {},
  "expected_cost": {},
  "expected_effect": null
}
```

所有 action 都先經：

```text
schema
→ legality
→ budget
→ world gate
→ apply
```

---

# 8. Cognitive Budget Contract

每個 Agent：

$$
B_i
=
(
B_i^{wall},
B_i^{compute},
B_i^{memory},
B_i^{obs},
B_i^{action},
B_i^{external}
).
$$

工程表示：

```json
{
  "wall_ms": 30000,
  "compute_units": 100,
  "memory_units": 100,
  "observation_units": 10,
  "action_units": 20,
  "external_units": 0
}
```

每個 cognition / observation / action 都必須產生 BudgetCharge。

除非 ruleset 明確補充：

$$
B_{t+1}
\preceq
B_t.
$$

---

# 9. Budget Parity Modes

Strict Parity：

$$
B_i=B_j.
$$

Normalized Cost Parity：不同模型單次推理成本可換算為 NormalizedComputeUnit。

Open Budget：允許：

$$
B_i\neq B_j
$$

研究資源優勢與策略效率。

---

# 10. Cognitive Operating Profile Contract

每個 Agent 的 COP：

$$
\Theta_i
=
(
\theta_d,
\theta_b,
\theta_v,
\theta_{cf},
\theta_o,
\theta_r,
\theta_l,
\theta_a,
\theta_c,
\theta_n
).
$$

Fixed COP：整場不變。

Adaptive COP：

$$
\Theta_t
\rightarrow
\Theta_{t+1}.
$$

每次重要 shift 必須有 ProfileReceipt。

---

# 11. Seed Contract

每一 episode 必須有：

$$
Seed_{world}.
$$

另外可選：

```text
seed_agent
seed_noise
seed_judge
```

若 provider 不提供 deterministic generation，仍至少固定：

- world；
- hidden state；
- observation noise；
- rule transition；
- scoring。

---

# 12. Replay Contract

每一場輸出：

```text
episode.json
world_manifest.json
events.jsonl
observations.jsonl
cognitive_ops.jsonl
actions.jsonl
budgets.jsonl
profiles.jsonl
receipts.jsonl
score.json
replay_manifest.json
```

Replay Manifest：

```json
{
  "episode_id": "...",
  "world_version": "...",
  "ruleset_version": "...",
  "agent_versions": {},
  "seeds": {},
  "artifact_hashes": {},
  "deterministic_core": true
}
```

每個 event 具有：

```text
tick
subtick
event_id
causal_parent_ids
```

因此 EventOrder 不可只依檔案行號推測。

---

# 13. Tick Model

第一版可採同步回合：

$$
t=0,1,\ldots,T.
$$

流程：

```text
emit observations
→ collect cognition / actions
→ validate
→ apply simultaneous or ordered transition
→ resolve effects
→ charge budgets
→ score intermediate state
→ next tick
```

ruleset 必須聲明：

```text
SIMULTANEOUS
SEQUENTIAL_FIXED
SEQUENTIAL_PRIORITY
```

避免 turn-order ambiguity。

---

# 14. Difficulty Regimes

Hidden-State Regime：

$$
H_{hidden}
\in
[0,1].
$$

Observation Noise：

$$
N_{obs}
\in
[0,1].
$$

Rule Stability：

```text
STATIC
SCHEDULED_SHIFT
CONDITIONAL_SHIFT
NEGOTIABLE
```

Opponent Reactivity 記為：

$$
R_{opp}.
$$

Difficulty Vector：

$$
D
=
(
d_h,
d_b,
d_o,
d_r,
d_n,
d_c
).
$$

分別表示：

- hidden-state；
- branching；
- opponent strength；
- rule volatility；
- observation noise；
- budget tightness。

---

# 15. Benchmark Families

## 15.1 Hidden Resource Duel

測：

- opponent model；
- COE；
- observation value；
- resource inference。

## 15.2 Trap-and-Route

測：

- reachability；
- hidden hazard；
- risk；
- observe-vs-act。

## 15.3 Negotiation Split

測：

- mixed motive；
- cooperation；
- deception；
- agreement stability。

## 15.4 Adaptive Rule Shift

測：

- rule change detection；
- replan；
- COP shift；
- stale model failure。

## 15.5 Limited Verifier Game

測：

- MVC；
- verifier allocation；
- stopping；
- commit timing。

---

# 16. Benchmark Task Contract

每個 task 必須提供：

```text
task_id
world_version
ruleset
hidden-state generator
difficulty vector
budget profiles
allowed observations
allowed actions
terminal conditions
scoring profile
held-out policy
```

Benchmark split：

```text
TRAIN
DEV
TEST
HELD_OUT_VARIANT
```

同一底層規則可生成不同表面變體：

$$
R_1,R_2,\ldots,R_n.
$$

測量：

$$
GeneralizationAcrossVariants.
$$

---

# 17. Procedural Generation 與 Leakage Control

世界至少可依 seed 生成：

```text
map topology
resource placement
hazard placement
goal position
opponent initial state
surface labels
```

測試使用：

- held-out seeds；
- hidden procedural parameters；
- surface renaming；
- rule-preserving transformations。

避免固定題庫被記憶。

---

# 18. Baseline Matrix

最少五個 baseline：

```text
B0 Neural Direct
B1 Fixed Depth
B2 Fixed Search + Verify
B3 APSC Fixed COP
B4 Full APSC Adaptive COP
```

B0：

```text
observe
→ model
→ action
```

B1：

$$
D=D_0.
$$

B2 固定 breadth / depth / verifier 次數。

B3 使用 possibility graph、COE、adaptive controller，但：

$$
\Theta_t=\Theta_0.
$$

B4 加入 Adaptive COP。

---

# 19. Experimental Matrix

推薦：

$$
Model
\times
Baseline
\times
Budget
\times
Difficulty
\times
Seed.
$$

同一 seed 上所有 baseline 遇到相同：

$$
W_0.
$$

形成 paired comparison。

---

# 20. Score Layer

AITA canonical result 不使用單一總分。

最少輸出：

```text
task_utility
decision_quality
cognitive_efficiency
observation_efficiency
critical_branch_recall
opponent_model_regret
allocation_regret
observation_regret
commit_regret
rule_compliance
robustness
```

---

# 21. Task Utility

$$
U_i.
$$

由 world 定義。

---

# 22. Decision Quality

若有 oracle：

$$
Q_i
=
1
-
\frac{
Loss_i
}{
Loss_{\max}
}.
$$

無 oracle 時可使用 task reward / completion。

---

# 23. Cognitive Efficiency

$$
\eta_{cog}
=
\frac{
Q_i
}{
\alpha C_{compute}
+
\beta C_{wall}
+
\gamma C_{obs}
+
\delta C_{action}
}.
$$

---

# 24. Observation Efficiency

$$
\eta_{obs}
=
\frac{
\Delta Q_{obs}
}{
C_{obs}
}.
$$

---

# 25. Critical Branch Recall

若 world 能事後標記：

$$
\Omega_{critical},
$$

則：

$$
Recall_{critical}
=
\frac{
|\Omega_{critical}\cap\widehat{\Omega}_{agent}|
}{
|\Omega_{critical}|
}.
$$

---

# 26. Regret Metrics

Opponent-Model Regret：

$$
R_{opp}
=
Q_{oracle\ opponent}
-
Q_{actual}.
$$

Allocation Regret：

$$
R_{alloc}
=
Q_{oracle\ allocation}
-
Q_{actual}.
$$

Observation Regret：

$$
R_{obs}
=
R_{miss}
+
R_{waste}.
$$

Commit Regret：

$$
R_{commit}
=
R_{early}
+
R_{late}.
$$

Arena Regret：

$$
R_{arena}
=
R_{state}
+
R_{poss}
+
R_{obs}
+
R_{opp}
+
R_{alloc}
+
R_{profile}
+
R_{commit}.
$$

---

# 27. Rule Compliance

$$
RC
=
1-
\frac{
N_{illegal}
}{
N_{actions}
}.
$$

---

# 28. Robustness

跨 seed：

$$
Robustness
=
1-
NormalizedVariance(Q).
$$

---

# 29. Pareto Evaluation

排行榜支援：

$$
Quality
-
Cost
-
Latency
-
Risk
$$

Pareto frontier。

若產品層需要 AggregateScore，可以另外建立 preset，但：

$$
AggregateScore
\neq
CanonicalResult.
$$

---

# 30. Statistical Reporting

至少報：

- mean；
- median；
- standard deviation；
- confidence interval；
- paired difference；
- failure count。

並保留：

```text
result_per_seed.jsonl
```

不可只存 aggregate。

---

# 31. Failure Taxonomy

State Failure：

```text
STATE_MISREAD
STATE_STALE
STATE_HALLUCINATION
```

Possibility Failure：

```text
BRANCH_EXPLOSION
CRITICAL_BRANCH_PRUNED
BAD_MERGE
BAD_ABSTRACTION
```

Observation Failure：

```text
LOW_VALUE_OBSERVATION
MISSED_OBSERVATION
NOISY_OBSERVATION_OVERTRUST
DECEPTION_FAILURE
```

Control Failure：

```text
OVERTHINK
UNDERTHINK
BAD_ALLOCATION
BAD_PREEMPTION
```

Profile Failure：

```text
BAD_PROFILE_ROUTE
PROFILE_OSCILLATION
PROFILE_UNDER_ADAPT
```

Commit Failure：

```text
EARLY_COMMIT
LATE_COMMIT
UNSTABLE_COMMIT
```

---

# 32. Replay Analysis

Replay 工具至少支援：

```text
play
pause
step
jump-to-tick
show-budget
show-profile
show-observation
show-action
show-public-possibility-summary
```

---

# 33. Counterfactual Replay

可替換某一：

$$
a_t
$$

或：

$$
q_t
$$

重跑：

$$
Replay^{CF}.
$$

Profile Replay：固定其他條件，只改：

$$
\Theta.
$$

Model Swap Replay：固定 world、seed、budget、COP，只換模型。

Budget Swap Replay：固定模型與世界，只改：

$$
B.
$$

---

# 34. Judge Architecture

能 deterministic scoring 的部分全部由 World Kernel 判。

只有語義難以形式化的項目才交給 external judge。

必要時：

$$
Judge_1,\ldots,Judge_n.
$$

必須固定：

$$
Player
\neq
Judge
$$

以及：

$$
Judge
\neq
WorldKernel.
$$

AI Judge 每次評分保存：

```text
judge_model
judge_version
rubric
input_refs
score
confidence
```

---

# 35. Fairness Rules

Parity 模式至少要求：

1. Same Observation Access；
2. Same Action Space；
3. Same Budget Semantics；
4. Same World Seed。

若研究非對稱角色，必須交換角色重新測試。

---

# 36. Cross-Play

模型族：

$$
M_1,\ldots,M_n
$$

可做 round-robin：

$$
M_i
\leftrightarrow
M_j.
$$

允許 Self-Play：

$$
M_i
\leftrightarrow
M_i.
$$

也允許 COP Cross-Play：

$$
\Theta_a
\leftrightarrow
\Theta_b.
$$

---

# 37. Population Arena

當：

$$
n>2,
$$

可以研究：

- coalition；
- public goods；
- voting；
- institutional dynamics。

若允許規則變更，RuleProposal 必須有：

```text
rule_proposal_id
proposer
diff
scope
vote / acceptance mechanism
effective_tick
rollback_rule
```

且：

$$
RuleProposal
\neq
RuleMutation.
$$

---

# 38. Safety Boundary

MVP 所有 world action 限制於：

$$
BoundedSimulation.
$$

不接現實高風險 actuator。

每 tick 設：

```text
max cognitive ops
max observations
max world actions
max external tool calls
```

每個 Agent step 具有：

$$
T_{step}
\leq
T_{\max}.
$$

逾時策略由 ruleset 固定。

---

# 39. Arena Acceptance Gates

### Gate A — Episode Schema

Episode contract 完整。

### Gate B — Deterministic World Reset

同 seed 可重建相同 $W_0$。

### Gate C — Budget Enforcement

任何 Agent 不可繞過 budget。

### Gate D — Observation Isolation

不可直接讀取未授權 hidden state。

### Gate E — Action Legality

非法 action fail closed。

### Gate F — Replay Completeness

Public transition 可由 ledger 重建。

### Gate G — Profile Trace

Adaptive COP shift 必有 receipt。

### Gate H — Judge Separation

Judge 不參與 world transition。

### Gate I — Paired Fairness

paired run 使用同 seed、ruleset、budget semantics。

### Gate J — Held-Out Integrity

test / held-out 參數不能由 agent adapter直接讀取。

### Gate K — Metric Vector

所有 canonical metric 個別輸出。

### Gate L — Baseline Comparability

至少 B0–B4 可在同 world contract 執行。

---

# 40. MVP Benchmark Scope

第一版只實作兩個 world：

```text
HiddenRoute-v0.1
LimitedVerifier-v0.1
```

即可。

---

# 41. HiddenRoute-v0.1

圖世界包含：

```text
start
goal
hidden hazards
optional probes
multiple routes
deadline
```

核心變量：

```text
node
edge
hazard
travel_cost
probe_cost
goal
deadline
```

測：

- observe vs act；
- reachability；
- risk；
- prune；
- abstraction；
- commit timing。

---

# 42. LimitedVerifier-v0.1

Agent 面對多個候選解，但只有：

$$
V_{\max}
$$

次 verifier。

測：

- verifier allocation；
- MVC；
- stopping；
- branch priority；
- commit。

---

# 43. Minimal Multi-Agent Extension

HiddenRoute 第二階段加入：

```text
shared map
exclusive resources
private hazards
opponent blocking
```

形成：

```text
HiddenRouteDuel-v0.2
```

---

# 44. MVP Leaderboard

先分：

```text
Utility
Quality
Efficiency
Observation
Regret
Robustness
```

六頁，不做唯一總榜。

---

# 45. Benchmark CLI

建議：

```bash
aita run --world HiddenRoute-v0.1 --agent A --baseline B4 --seed 42
aita replay runs/<id>
aita compare runs/<a> runs/<b>
aita matrix benchmark.yaml
aita report benchmark-results/
```

---

# 46. Benchmark YAML

```yaml
worlds:
  - HiddenRoute-v0.1
baselines:
  - B0
  - B1
  - B3
  - B4
budgets:
  - small
  - medium
seeds:
  - 1
  - 2
  - 3
```

---

# 47. Repository Layout

```text
ai-tension-arena/
├── README.md
├── pyproject.toml
├── schemas/
├── src/aita/
│   ├── protocol/
│   ├── worlds/
│   ├── agents/
│   ├── budgets/
│   ├── scoring/
│   ├── replay/
│   ├── judges/
│   ├── benchmarks/
│   └── cli/
├── benchmark_specs/
├── examples/
├── tests/
└── docs/
```

---

# 48. Test Strategy

至少包含：

```text
schema tests
world reset tests
budget bypass tests
hidden-state isolation tests
action legality tests
replay tests
paired fairness tests
role-swap tests
judge separation tests
held-out integrity tests
```

Golden Episode：

```text
HiddenRoute-v0.1
seed=42
baseline=B1
budget=small
```

---

# 49. Property Tests

重要 property：

$$
Reset(seed)=Reset(seed).
$$

以及：

$$
Budget_{t+1}
\preceq
Budget_t.
$$

以及：

$$
HiddenState_i
\notin
Observation_j
$$

除非 ruleset 明確允許。

---

# 50. Performance 優先序

MVP 優先：

```text
correctness
fairness
replayability
boundedness
auditability
then throughput
```

---

# 51. 非目標

v0.1 不做：

- 真實軍事模擬；
- 現實武器控制；
- 大型 MMO；
- 高保真 3D；
- 任意網路自治攻防；
- 現實金融執行；
- 無限制 Agent internet access；
- 唯一全球排行榜。

---

# 52. Benchmark 成功定義

最小成功條件：

$$
\boxed{
\text{同一模型、同一 seed、同一 budget，
不同 cognition policy 產生可測且可重播的 trajectory 差異。}
}
$$

第二條：

$$
\boxed{
B4
\text{ 在至少一類部分觀察或資源受限任務中}
>
B1/B2.
}
$$

如果沒有，APSC 不應宣稱工程優勢。

---

# 53. Full APSC × AITA Integration

APSC Runtime 提供：

```text
state
possibility
COE
controller
COP
receipt
```

AITA 提供：

```text
world
opponent
partial observation
budget parity
scoring
replay comparison
```

整合後：

$$
\boxed{
APSC
+
AITA
=
\text{runtime cognition under falsifiable dynamic evaluation}.
}
$$

---

# 54. MVP 前最後接口

工程可採兩 repo：

```text
apsc-runtime
ai-tension-arena
```

或 monorepo：

```text
apsc/
├── runtime/
└── arena/
```

透過：

```text
AgentAdapter
ObservationContract
BudgetContract
ReceiptContract
```

耦合。

---

# 55. 最終 Protocol 總結

AITA protocol 收斂為：

$$
\boxed{
Episode
\rightarrow
SeededWorld
\rightarrow
PartialObservation
\rightarrow
FiniteBudgetAgent
\rightarrow
DynamicInteraction
\rightarrow
MetricVector
\rightarrow
ReplayableEvidence.
}
$$

---

# 56. 結論

AI 張力競技場的工程目的，不是把兩個模型放進聊天室互相辯論。

真正的 benchmark 必須讓它們面對：

> 有限觀察。  
> 有限算力。  
> 有限時間。  
> 會反應的對手。  
> 會改變的狀態。  
> 可能不可靠的資訊。  
> 需要取捨的驗證。  
> 需要適時停止的 cognition。  
> 需要可重播的結果。

因此最終評估問題不是：

$$
\boxed{
\text{誰講得比較像贏家？}
}
$$

而是：

$$
\boxed{
\text{誰能在相同或明確記錄的有限認知預算下，
更穩定、更有效率地管理一個會反作用的可能空間？}
}
$$

本文件完成 APSC 系列的第二份技術白皮書。

至此：

$$
\boxed{
6\text{ 篇正式論文}
+
2\text{ 份技術白皮書}
}
$$

已全部完成第一版 canonical source。

下一步正式進入：

$$
\boxed{
APSC\ Runtime\ Lite
+
AI\ Tension\ Arena\ MVP.
}
$$

---

## 版本記錄

### v0.1 — 2026-08-25

本版首次固定：

1. AITA Episode Contract；
2. World Adapter；
3. Observation Contract；
4. Agent Contract；
5. Action Contract；
6. Cognitive Budget Contract；
7. Budget Accounting；
8. Strict / Normalized / Open Budget Parity；
9. COP Contract；
10. Seed Contract；
11. Replay Contract；
12. Event Ordering；
13. Tick Model；
14. Simultaneous / Sequential Semantics；
15. Hidden-State Regime；
16. Observation Noise Regime；
17. Rule Stability Regime；
18. Difficulty Vector；
19. 五類初始 Benchmark Families；
20. Task Contract；
21. Train / Dev / Test / Held-Out Variant；
22. Procedural Generation；
23. Benchmark Leakage Control；
24. B0–B4 Baseline Matrix；
25. Experimental Matrix；
26. Pairing Strategy；
27. Multi-Seed Reporting；
28. Canonical Metric Vector；
29. Pareto Evaluation；
30. Statistical Reporting；
31. Failure Taxonomy；
32. Arena Regret Decomposition；
33. Replay Analysis；
34. Counterfactual / Profile / Model / Budget Replay；
35. Judge Architecture；
36. Judge Separation；
37. Fairness Rules；
38. Asymmetric Role Swap；
39. Cross-Play / Self-Play / COP Cross-Play；
40. Population Arena；
41. Institution Protocol；
42. Safety Boundary；
43. Rate Limits；
44. Timeout / Error Policy；
45. Acceptance Gate A–L；
46. HiddenRoute-v0.1；
47. LimitedVerifier-v0.1；
48. HiddenRouteDuel-v0.2 路線；
49. Leaderboard Dimensions；
50. CLI；
51. Benchmark YAML；
52. Repository Layout；
53. Test Strategy；
54. Golden Episode；
55. Property Tests；
56. Non-goals；
57. Benchmark Success Criteria；
58. Full APSC × AITA Integration Contract。
