# APSC Runtime Lite + AI Tension Arena MVP Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a deterministic, replayable Python MVP implementing the APSC runtime core plus two benchmark worlds and B0/B1/B3/B4 comparison baselines.

**Architecture:** One Python monorepo contains `apsc` runtime modules and `aita` arena modules. The runtime owns canonical state, possibility nodes, budgets, COP, cognitive operations, receipts, and adaptive scheduling; the arena owns seeded worlds, observations, actions, scoring, replay, and benchmark matrices. Neural integrations are adapter interfaces only; the MVP uses deterministic baseline agents so all acceptance behavior can be tested offline.

**Tech Stack:** Python 3.12+, standard library first, `pytest` for tests, JSON/JSONL artifacts, `argparse` CLI, no network/API dependency.

**Spec:** `docs/specs/APSC_Runtime_Technical_Architecture_v0.1.md` and `docs/specs/AI_Tension_Arena_Protocol_and_Benchmark_Specification_v0.1.md`

## Global Constraints

- Canonical mathematical source uses `$...$` and `$$...$$` only in documentation.
- Neural proposals never directly mutate canonical state.
- Observations are evidence records, not truth.
- Decisions are distinct from final commits.
- Budgets are monotone decreasing unless a world explicitly grants a top-up.
- Hidden world state is never exposed through an unauthorized observation.
- Adaptive COP shifts remain within an explicit adaptive region and create receipts.
- Deterministic world/core behavior must replay from seed + public artifacts.
- No private chain-of-thought persistence.
- MVP is bounded simulation only; no real-world high-risk actuator.

---

### Task 1: Repository, canonical data model, and budget/COP primitives

**Files:**
- Create: `pyproject.toml`
- Create: `src/apsc/__init__.py`
- Create: `src/apsc/models.py`
- Create: `src/apsc/budget.py`
- Create: `src/apsc/cop.py`
- Test: `tests/test_models_budget_cop.py`

**Interfaces:**
- Produces: `Budget`, `CognitiveOperatingProfile`, `AdaptiveRegion`, `ObservationRecord`, `StateSnapshot`, `PossibilityNode`, `DecisionReceipt`
- Budget method: `charge(cost: Budget) -> Budget`
- COP method: `project(region: AdaptiveRegion) -> CognitiveOperatingProfile`

- [ ] Write failing tests for monotone budget charging, insufficient budget rejection, COP projection, and immutable state/version identifiers.
- [ ] Run `pytest tests/test_models_budget_cop.py -q` and confirm expected failures.
- [ ] Implement minimal dataclasses and validation.
- [ ] Run the test file and full suite.
- [ ] Commit `feat: add canonical models budget and cop`.

### Task 2: Possibility graph, constraints, and cognitive operators

**Files:**
- Create: `src/apsc/possibility.py`
- Create: `src/apsc/constraints.py`
- Create: `src/apsc/operators.py`
- Test: `tests/test_possibility_constraints_operators.py`

**Interfaces:**
- Produces: `PossibilityGraph`, `ConstraintEngine`, `OperatorSpec`, `CognitiveOperation`
- Methods: `add_candidate`, `activate`, `prune`, `mark_dormant`, `merge`, `check_constraints`

- [ ] Write failing tests showing hard-failed nodes never become active, merged nodes retain lineage, and operator specs enforce interruptible/checkpointable flags.
- [ ] Verify RED.
- [ ] Implement minimal graph/constraint/operator behavior.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add possibility graph constraints and operators`.

### Task 3: COE and adaptive controller

**Files:**
- Create: `src/apsc/coe.py`
- Create: `src/apsc/controller.py`
- Test: `tests/test_coe_controller.py`

**Interfaces:**
- Produces: `ObservationCandidate`, `ObservationOutcome`, `value_observation`, `AdaptiveController`
- Controller method: `choose(operations, budget, cop) -> CognitiveOperation | None`
- Stop rule returns `None` when no feasible operation has positive score.

- [ ] Write failing tests for observation-value ranking, budget-feasibility filtering, fixed shadow-price scoring, stop behavior, and preemption threshold.
- [ ] Verify RED.
- [ ] Implement minimal deterministic heuristics.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add coe and adaptive controller`.

### Task 4: Receipts, run state, replay ledger, and deterministic hashing

**Files:**
- Create: `src/apsc/runtime.py`
- Create: `src/apsc/replay.py`
- Test: `tests/test_runtime_replay.py`

**Interfaces:**
- Produces: `APSCRuntime`, `ReplayLedger`, `RunManifest`
- Methods: `record_event`, `step`, `commit`, `export_run(directory)`

- [ ] Write failing tests for state version increments, receipt creation, budget trajectory persistence, deterministic artifact hashes, and replay manifest completeness.
- [ ] Verify RED.
- [ ] Implement minimal runtime and JSON/JSONL export.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add runtime receipts and replay`.

### Task 5: AITA protocol and HiddenRoute-v0.1

**Files:**
- Create: `src/aita/__init__.py`
- Create: `src/aita/protocol.py`
- Create: `src/aita/worlds/hidden_route.py`
- Test: `tests/test_hidden_route.py`

**Interfaces:**
- World methods: `reset(seed)`, `observe(agent_id, query)`, `legal_actions(agent_id)`, `step(action_bundle)`, `is_terminal()`, `score_state()`, `export_replay_state()`

- [ ] Write failing tests for deterministic reset, hidden hazard isolation, probe costs, legal movement, deadline handling, and score determinism.
- [ ] Verify RED.
- [ ] Implement deterministic graph world.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add hidden route benchmark world`.

### Task 6: LimitedVerifier-v0.1

**Files:**
- Create: `src/aita/worlds/limited_verifier.py`
- Test: `tests/test_limited_verifier.py`

**Interfaces:**
- World exposes candidate answers, bounded verifier queries, commit action, and oracle score after terminal state.

- [ ] Write failing tests for verifier quota, verifier evidence, illegal over-quota verification, commit timing, and deterministic scoring.
- [ ] Verify RED.
- [ ] Implement world.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add limited verifier benchmark world`.

### Task 7: Baseline agents B0/B1/B3/B4

**Files:**
- Create: `src/aita/agents.py`
- Test: `tests/test_agents.py`

**Interfaces:**
- `AgentAdapter.reset`, `decide`
- `B0NeuralDirectAgent`, `B1FixedDepthAgent`, `B3APSCFixedCOPAgent`, `B4APSCAdaptiveCOPAgent`

- [ ] Write failing behavioral tests proving B0 acts directly, B1 uses fixed-depth heuristic, B3 uses APSC controller with fixed COP, and B4 creates a profile receipt when risk triggers an adaptive shift.
- [ ] Verify RED.
- [ ] Implement deterministic reference agents.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add benchmark baseline agents`.

### Task 8: Arena runner, scoring vector, paired benchmark matrix

**Files:**
- Create: `src/aita/runner.py`
- Create: `src/aita/scoring.py`
- Create: `src/aita/benchmark.py`
- Test: `tests/test_runner_benchmark.py`

**Interfaces:**
- `run_episode(world, agent, config, output_dir) -> EpisodeResult`
- `run_matrix(spec, output_dir) -> BenchmarkReport`

- [ ] Write failing tests for budget enforcement, per-seed artifacts, canonical metric-vector fields, paired same-seed runs, and multi-seed aggregation.
- [ ] Verify RED.
- [ ] Implement runner/scoring/matrix.
- [ ] Verify GREEN and full suite.
- [ ] Commit `feat: add arena runner scoring and benchmark matrix`.

### Task 9: CLI, golden episodes, and acceptance gates

**Files:**
- Create: `src/aita/cli.py`
- Create: `tests/test_acceptance.py`
- Create: `examples/benchmark.json`
- Create: `docs/ACCEPTANCE.md`

**Interfaces:**
- CLI commands: `run`, `replay`, `compare`, `matrix`, `report`

- [ ] Write failing acceptance tests for Gates A–L that are applicable to MVP scope.
- [ ] Verify RED.
- [ ] Implement CLI and gate checks.
- [ ] Generate golden HiddenRoute seed 42 and LimitedVerifier seed 42 runs.
- [ ] Run `pytest -q` and CLI smoke tests.
- [ ] Commit `feat: complete MVP acceptance gates and cli`.

### Task 10: Documentation, validation, and release package

**Files:**
- Create: `README.md`
- Create: `CHANGELOG.md`
- Create: `VALIDATION.json`

**Interfaces:**
- README contains install/run/test commands and exact MVP/non-goal boundaries.

- [ ] Write documentation checks for required commands and stated boundaries.
- [ ] Verify RED.
- [ ] Write README/CHANGELOG.
- [ ] Run `python -m compileall -q src`.
- [ ] Run `pytest -q`.
- [ ] Run both golden episodes and benchmark matrix.
- [ ] Validate UTF-8 source and documentation delimiters.
- [ ] Create release ZIP containing source, tests, docs, specs, example outputs, and validation report.
- [ ] Commit `chore: prepare apsc aita mvp v0.1 release`.
