# Changelog

## 0.9.0 — 2026-08-26

Added cross-world cognition-value meta-generalization while preserving v0.1–v0.8 baselines. Added world-neutral generalized features, uncertainty-discounted counterfactual targets, learned exploration, B4G, hashed generalized replay evidence, bidirectional SignalHazard ↔ LatentContext transfer experiments, `aita meta-transfer`, and V9-A–V9-K gates. The reference has positive mean transfer versus an empty generalized wrapper in both directions but also per-seed negative transfer; LatentContext → SignalHazard remains worse than handcrafted B4. This is not a universal ranking.

## 0.8.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with exploration-aware meta-control, counterfactual/off-policy cognition experience, and uncertainty-aware learned routing.

Added:

- weighted evidence and deterministic local-bucket uncertainty queries to `ExperienceMetaValueModel` without changing the v0.7 serialization/model-type contract;
- `MetaTrainingExperience` provenance for on-policy, forced-exploration, uncertainty-exploration, and counterfactual/off-policy experience;
- `UncertaintyAwareMetaSelector` with a per-episode cognition coverage floor and learned-value-plus-uncertainty ranking;
- **B4X**, preserving B4/B4L hard budget/COP gates while adding exploration-aware learned cognition selection;
- terminal feedback finalization and hashed `meta_exploration.jsonl` replay evidence;
- replay-derived alternate-cognition targets that reuse action-time-visible features and use revealed world truth only after the outcome to construct labels;
- a deterministic B4-versus-B4X train/freeze/held-out pipeline and `aita meta-explore` CLI;
- V8-A–V8-J release gates covering train/eval isolation, feature isolation, cognition coverage, counterfactual coverage, uncertainty evidence, frozen model identity, paired held-out metrics, replay integrity, repeat determinism, and backward compatibility.

Reference result: v0.7's 335:1 cognition coverage collapse is repaired to 221 `trust_signal` versus 163 `observe_field` actual experiences, plus 384 counterfactual/off-policy rows. Weighted evidence is 302.5 versus 273.5. On 16 held-out B4/B4X pairs, routing diverges on all 16; B4X mean task utility is 2.09375 versus -0.26875 for B4, field checks are 2.625 versus 4.5, and the cognitive-efficiency proxy is 0.02713733 versus 0.0246323. This is a bounded reference result, **not a universal ranking**.

## 0.7.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with a deterministic experience-learned meta-controller reference baseline.

Added:

- `CognitiveExperience`, whose action-time feature schema excludes hidden context, hidden/current/future truth, and oracle action labels;
- `ExperienceMetaValueModel`, a deterministic global-to-feature-bucket empirical cognition-value model with stable JSON serialization and SHA-256 identity;
- `B4L`, which preserves B4 latent-context inference and hard budget/COP gates while allowing learned values to rank `trust_signal` and `observe_field`;
- hashed `meta_learning.jsonl` and `meta_experiences.jsonl` public replay evidence;
- a train/freeze/held-out pipeline with disjoint training/evaluation seeds and frozen-model hash enforcement;
- paired same-seed B4 versus B4L held-out evaluation;
- repeat-experiment byte determinism and V7-A–V7-I release gates.

Reference result: 48 training episodes produced 336 experiences, but the on-policy data were severely imbalanced: 335 `trust_signal` rows and only 1 `observe_field` row. The frozen B4L model changed cognition routing on all 16 held-out paired rows, reduced mean field checks from 4.5 to 0, and increased the cognitive-efficiency proxy from 0.0246323 to 0.03125, but mean task utility degraded from -0.26875 for handcrafted B4 to -0.79375 for B4L. This is a replayable **cognitive policy collapse under imbalanced on-policy experience**, not a universal ranking and not evidence that learned control is superior.

## 0.6.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with latent opponent-context inference and belief-weighted cognition.

Added:

- `LatentContextBeliefTracker`, a deterministic two-state posterior over hidden `ALIGNED` / `COMPETITIVE` incentive context;
- weighted evidence in contextual reliability and MVC estimators while preserving v0.5 one-hot behavior;
- `LatentContextSignalDuel-v0.6`, which removes the context label from receiver state, observation, and feedback while retaining it in replay kernel state;
- B4 latent-context routing using posterior-weighted signal trust, field trust, trust-signal MVC, and observe-field MVC;
- `latent_context.jsonl` replay evidence and manifest hashing;
- `run_latent_context_signal_matrix()` and `aita latent-signal-matrix`;
- V6-A–V6-I release gates and a 96-episode reference matrix.

Reference result: against strategic B2/B4 signalers, B4 latent-context receiver mean utility is -0.26875 with 4.5 field checks per eight-round episode, compared with -0.79375 for fixed trust and 0.3 for always verifying. In the detailed seed-1 run, posterior belief moves from 0.5/0.5 toward approximately 0.814 competitive after adverse deception/field evidence and later back toward approximately 0.742 aligned. This demonstrates replayable hidden-context inference and a trust/verification trade-off; it is not a universal ranking and B4 does not yet beat always-verify on mean utility.

## 0.5.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with strategic deceptive signaling and contextual online calibration.

Added:

- `StrategicSignalDuel-v0.5`, where a signaler Agent sees hidden truth and strategically chooses honest or misleading public signals;
- fixed signaler / receiver role contracts without abusing symmetric duel role-swap semantics;
- `ContextualSourceReliabilityTracker`, separating global source trust from source×context trust with hierarchical backoff;
- `ContextualMVCValueEstimator`, tracking realized cognition value at global, source, and source×context levels;
- B0–B4 strategic signaler/receiver reference policies without introducing a benchmark-specific B5;
- B4 contextual trust calibration and trust-versus-field-verification routing;
- `deception.jsonl` replay evidence with replay-manifest hashing;
- `run_strategic_signal_matrix()` and `aita strategic-matrix`;
- V5-A–V5-H release gates and a 96-episode reference cross-play matrix.

Reference result: a B2/B4 strategic signaler produces both honest aligned-context signals and deceptive competitive-context signals. In the detailed B2 → B4 seed-1 run, B4 calibrates the same signaler to about 0.92 reliability in `ALIGNED` context and 0.267 in `COMPETITIVE` context, while contextual trust-signal MVC separates to +1.0 versus -1.7875. Across strategic-sender rows, B4 receiver mean utility is 2.4875 with 4.5 field checks per eight-round episode, compared with -0.4 for fixed trust and 0.3 for always verifying. This is task-specific strategic-calibration evidence, not a universal ranking.

## 0.4.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with noisy/deceptive observation and online calibration.

Added:

- `SignalHazard-v0.4`, an eight-round sequential hazard benchmark with hidden current truth;
- `source_id` on `ObservationResult` with backward-compatible default;
- `SourceReliabilityTracker`, separating declared reliability from calibrated reliability;
- Brier-style public calibration error evidence;
- `OnlineMVCValueEstimator`, an incremental realized-gain estimated MVC proxy;
- reliability-aware COE observation value;
- B4 online calibration and source-selection shift;
- `calibration.jsonl` replay evidence and replay-manifest hashing;
- V4-A–V4-G release-evidence gates and a 40-episode B0–B4 reference matrix.

Reference result: the field sensor declares 0.70 reliability but is empirically correct 0.75; the deceptive advisor declares 0.90 but is empirically correct 0.25. In the seed-1 B4 reference episode, the first advisor error lowers its calibrated estimate from 0.90 to 0.60 and B4 switches to the field sensor. B4 improves over fixed advisor-trusting B2/B3 on mean task utility, but fixed-field B1 remains better. This is task-specific calibration evidence, not a universal ranking.

## 0.3.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with explicit observation-loss and mixed-motive benchmark regimes.

Added:

- `HazardChoice-v0.3`, where probing can avoid an irreversible catastrophic FAST outcome and produces measurable `observation_prevented_loss`;
- COP-dependent HazardChoice behavior: low-latency can act immediately while high-risk assurance probes first;
- `NegotiationSplit-v0.3` with private preferences, offer/accept/reject/wait state transitions, deadline disagreement payoffs, and public rule shift;
- mixed-motive metrics: joint utility, Pareto efficiency, agreement stability, concession cost, and negotiation regret;
- B0–B4 negotiation policies and B4 `rule_shift_trigger` adaptation;
- v0.3 benchmark specs and release-level evidence gates for hazard coverage, COP trajectory divergence, agreement/timeout coverage, rule-shift receipts, and role-swap hash parity.

## 0.2.0 — 2026-08-25

Extended **APSC Runtime Lite + AI Tension Arena** with true dual-agent evaluation.

Added:

- `HiddenRouteDuel-v0.2` shared-world duel with private probes, exclusive claims, deterministic collision resolution, and public rule shift;
- duel-aware B3/B4 behavior and B4 `rule_shift_trigger` ProfileReceipt;
- independent per-agent budgets, COP traces, observations, actions, and replay artifacts;
- duel scoring with outcome, resource advantage, tension efficiency, and collision-derived opponent-model regret;
- role-swap and COP cross-play benchmark matrices;
- `aita duel` and `aita duel-matrix` CLI commands;
- dual-agent acceptance validation.

## 0.1.0 — 2026-08-25

Initial reference release of **APSC Runtime Lite + AI Tension Arena**.

Added:

- canonical state, budget, COP and receipt objects;
- possibility graph, constraints and cognitive operators;
- COE value primitives and adaptive computation controller;
- replay ledger and hashed public artifacts;
- `HiddenRoute-v0.1` and `LimitedVerifier-v0.1`;
- B0, B1, B2, B3 and B4 deterministic baselines;
- multi-metric scoring and paired benchmark matrix;
- CLI and MVP acceptance gates;
- approved APSC Runtime and AITA protocol specifications.
