from pathlib import Path


def test_v030_docs_declare_hazard_negotiation_and_nonuniversality():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.3",
        "HazardChoice-v0.3",
        "NegotiationSplit-v0.3",
        "observation-prevented loss",
        "mixed-motive",
        "Pareto efficiency",
        "task-specific trade-off",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.3.0" in changelog
    assert "0.3.0" in changelog


def test_v030_results_document_has_required_evidence_sections():
    text = Path("docs/V0.3_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "HazardChoice-v0.3",
        "NegotiationSplit-v0.3",
        "Observation prevented loss",
        "Rule-shift ProfileReceipt",
        "Role-swap pairing",
        "Limitations",
    ):
        assert required in text


def test_v030_validation_metadata_declares_artifact_evidence():
    import json

    payload = json.loads(Path("docs/validation/VALIDATION_v0.3.json").read_text(encoding="utf-8"))
    assert payload["version"] == "0.3.0"
    assert payload["status"] == "PASS"
    assert payload["checks"]["v03_evidence"]["status"] == "PASS"
    assert payload["checks"]["v03_evidence"]["hazard_tradeoff"] == "PASS"
    assert payload["checks"]["v03_evidence"]["negotiation_rule_shift"] == "PASS"
    assert payload["checks"]["v03_evidence"]["role_swap_pairing"] == "PASS"
