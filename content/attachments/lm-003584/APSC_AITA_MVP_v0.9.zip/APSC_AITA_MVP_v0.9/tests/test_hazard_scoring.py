from apsc.budget import Budget
from aita.scoring import score_episode
from aita.worlds.hazard_choice import HazardChoiceWorld


def _seed_for(regime: str) -> int:
    world = HazardChoiceWorld()
    for seed in range(100):
        world.reset(seed)
        if world.export_replay_state()["regime"] == regime:
            return seed
    raise AssertionError(regime)


def test_hazard_score_reports_avoidable_loss_for_catastrophic_fast_choice():
    world = HazardChoiceWorld()
    world.reset(_seed_for("FAST_CATASTROPHIC"))
    world.step({"agent://A": {"type": "choose", "route": "FAST"}})
    raw = world.score_state()
    assert raw["avoidable_loss"] > 3.0
    metrics = score_episode(raw, initial_budget=Budget(compute_units=3, action_units=1), final_budget=Budget(compute_units=2), status="completed")
    assert metrics["catastrophic_loss"] == 1.0
    assert metrics["avoidable_loss"] == raw["avoidable_loss"]


def test_probe_then_safe_records_observation_prevented_loss():
    world = HazardChoiceWorld()
    world.reset(_seed_for("FAST_CATASTROPHIC"))
    world.observe("agent://A", {"type": "probe", "target": "route-regime"})
    world.step({"agent://A": {"type": "choose", "route": "SAFE"}})
    raw = world.score_state()
    assert raw["catastrophic_loss"] == 0
    assert raw["observation_prevented_loss"] > 3.0
