import json

from aita.benchmark import run_duel_matrix


def test_duel_matrix_supports_role_swap_and_cop_cross_play(tmp_path):
    spec = {
        "world": "HiddenRouteDuel-v0.2",
        "matchups": [
            {"a": "B3", "b": "B4", "profile_a": "balanced", "profile_b": "balanced"},
            {"a": "B4", "b": "B4", "profile_a": "exploration", "profile_b": "high_risk_assurance"},
        ],
        "budgets": {
            "small": {"compute_units": 20, "observation_units": 6, "action_units": 10},
        },
        "seeds": [1, 2],
        "role_swap": True,
    }
    report = run_duel_matrix(spec, tmp_path)
    assert len(report.rows) == 8
    assert any(row["agent_a_baseline"] == "B3" and row["agent_b_baseline"] == "B4" for row in report.rows)
    assert any(row["agent_a_baseline"] == "B4" and row["agent_b_baseline"] == "B4" and row["agent_a_profile"] != row["agent_b_profile"] for row in report.rows)
    assert {row["role_orientation"] for row in report.rows} == {"normal", "swapped"}

    for seed in spec["seeds"]:
        pair = [row for row in report.rows if row["seed"] == seed and {row["agent_a_baseline"], row["agent_b_baseline"]} == {"B3", "B4"}]
        assert len(pair) == 2
        assert pair[0]["initial_world_hash"] == pair[1]["initial_world_hash"]

    payload = json.loads((tmp_path / "duel_benchmark_report.json").read_text(encoding="utf-8"))
    assert payload["row_count"] == 8
    assert payload["aggregates"]
