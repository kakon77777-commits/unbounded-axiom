from aita.benchmark import run_strategic_signal_matrix


def test_strategic_signal_matrix_runs_role_asymmetric_crossplay(tmp_path):
    spec = {
        "world": "StrategicSignalDuel-v0.5",
        "signaler_baselines": ["B1", "B2"],
        "receiver_baselines": ["B1", "B4"],
        "budgets": {
            "medium": {
                "compute_units": 100,
                "memory_units": 100,
                "observation_units": 30,
                "action_units": 100,
            }
        },
        "seeds": [1, 2],
        "signaler_profile": "balanced",
        "receiver_profile": "balanced",
    }
    report = run_strategic_signal_matrix(spec, tmp_path)

    assert len(report.rows) == 8
    assert {row["signaler_baseline"] for row in report.rows} == {"B1", "B2"}
    assert {row["receiver_baseline"] for row in report.rows} == {"B1", "B4"}
    assert all(row["world"] == "StrategicSignalDuel-v0.5" for row in report.rows)
    assert all("signaler_task_utility" in row and "receiver_task_utility" in row for row in report.rows)
    assert (tmp_path / "strategic_result_per_seed.jsonl").exists()
    assert (tmp_path / "strategic_benchmark_report.json").exists()


def test_cli_strategic_matrix_command(tmp_path):
    import json
    from aita.cli import main

    spec = {
        "world": "StrategicSignalDuel-v0.5",
        "signaler_baselines": ["B2"],
        "receiver_baselines": ["B4"],
        "budgets": {
            "medium": {
                "compute_units": 100,
                "memory_units": 100,
                "observation_units": 30,
                "action_units": 100,
            }
        },
        "seeds": [1],
        "signaler_profile": "balanced",
        "receiver_profile": "balanced",
    }
    spec_path = tmp_path / "spec.json"
    spec_path.write_text(json.dumps(spec), encoding="utf-8")
    out = tmp_path / "out"

    assert main(["strategic-matrix", str(spec_path), "--output", str(out)]) == 0
    assert (out / "strategic_benchmark_report.json").exists()
