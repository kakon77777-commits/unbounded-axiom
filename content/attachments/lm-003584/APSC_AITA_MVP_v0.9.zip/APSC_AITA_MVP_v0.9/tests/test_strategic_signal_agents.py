from apsc.budget import Budget
from aita.benchmark import COP_PRESETS
from aita.agents import (
    B0NeuralDirectAgent,
    B1FixedDepthAgent,
    B2FixedSearchVerifyAgent,
    B3APSCFixedCOPAgent,
    B4APSCAdaptiveCOPAgent,
)
from aita.protocol import ObservationResult


def signaler_state(*, context="ALIGNED", truth="FAST_SAFE"):
    return {
        "world_kind": "strategic_signal_duel",
        "role": "signaler",
        "phase": "SIGNAL",
        "round_index": 0,
        "context": context,
        "current_truth": truth,
        "own_incentive": context,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": None,
    }


def receiver_state(*, context="COMPETITIVE", signal="FAST_SAFE", round_index=0, feedback=None):
    return {
        "world_kind": "strategic_signal_duel",
        "role": "receiver",
        "phase": "RESPONSE",
        "round_index": round_index,
        "context": context,
        "opponent_signal": signal,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
    }


def test_signaler_baselines_have_distinct_truthfulness_policies():
    budget = Budget(compute_units=20, observation_units=10, action_units=20)
    b0 = B0NeuralDirectAgent("agent://signaler")
    b1 = B1FixedDepthAgent("agent://signaler")
    b2 = B2FixedSearchVerifyAgent("agent://signaler")
    b3 = B3APSCFixedCOPAgent("agent://signaler")
    b4 = B4APSCAdaptiveCOPAgent("agent://signaler")
    for agent in (b0, b1, b2, b3, b4):
        agent.reset(COP_PRESETS["balanced"])

    aligned_truth = signaler_state(context="ALIGNED", truth="FAST_CATASTROPHIC")
    competitive_truth = signaler_state(context="COMPETITIVE", truth="FAST_CATASTROPHIC")

    assert b0.decide(aligned_truth, budget).action == {"type": "send_signal", "claim": "FAST_SAFE"}
    assert b1.decide(aligned_truth, budget).action == {"type": "send_signal", "claim": "FAST_CATASTROPHIC"}
    for agent in (b2, b3, b4):
        assert agent.decide(aligned_truth, budget).action == {"type": "send_signal", "claim": "FAST_CATASTROPHIC"}
        assert agent.decide(competitive_truth, budget).action == {"type": "send_signal", "claim": "FAST_SAFE"}


def test_receiver_b1_trusts_signal_and_b2_fixed_verifies_field():
    budget = Budget(compute_units=20, observation_units=10, action_units=20)
    state = receiver_state(signal="FAST_CATASTROPHIC")
    b1 = B1FixedDepthAgent("agent://receiver")
    b2 = B2FixedSearchVerifyAgent("agent://receiver")
    b1.reset(COP_PRESETS["balanced"])
    b2.reset(COP_PRESETS["balanced"])

    assert b1.decide(state, budget).action == {"type": "choose", "route": "SAFE"}
    assert b2.decide(state, budget).query == {"type": "signal", "source": "sensor://field"}


def test_b4_receiver_shifts_from_signal_trust_to_field_after_competitive_lie_feedback():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)

    initial = receiver_state(context="COMPETITIVE", signal="FAST_SAFE", round_index=0)
    first = agent.decide(initial, budget)
    assert first.action == {"type": "choose", "route": "FAST"}

    feedback = {
        "round_index": 0,
        "context": "COMPETITIVE",
        "truth": "FAST_CATASTROPHIC",
        "signal_claim": "FAST_SAFE",
        "signal_correct": False,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": -2.5,
        "avoidable_receiver_loss": 3.15,
    }
    # The next SIGNAL-phase decision processes feedback but cannot inspect the next truth.
    agent.decide({
        "world_kind": "strategic_signal_duel",
        "role": "receiver",
        "phase": "SIGNAL",
        "round_index": 1,
        "context": "ALIGNED",
        "opponent_signal": None,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
    }, budget)

    second = agent.decide(receiver_state(context="COMPETITIVE", signal="FAST_SAFE", round_index=1, feedback=feedback), budget)
    assert second.query == {"type": "signal", "source": "sensor://field"}


def test_b4_receiver_uses_field_observation_then_routes_from_field_signal():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["high_risk_assurance"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    state = receiver_state(context="COMPETITIVE", signal="FAST_SAFE", round_index=2)
    agent.ingest_observation(ObservationResult(
        observation_id="obs://field/2",
        agent_id="agent://receiver",
        payload={"round_index": 2, "context": "COMPETITIVE", "signal": "FAST_CATASTROPHIC"},
        reliability=0.7,
        cost=Budget(observation_units=1),
        source_id="sensor://field",
    ))

    decision = agent.decide(state, budget)
    assert decision.action == {"type": "choose", "route": "SAFE"}


def test_b4_deception_snapshot_exposes_contextual_trust_and_mvc():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    feedback = {
        "round_index": 0,
        "context": "ALIGNED",
        "truth": "FAST_SAFE",
        "signal_claim": "FAST_SAFE",
        "signal_correct": True,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": 1.0,
        "avoidable_receiver_loss": 0.0,
    }
    agent.decide({
        "world_kind": "strategic_signal_duel",
        "role": "receiver",
        "phase": "SIGNAL",
        "round_index": 1,
        "context": "COMPETITIVE",
        "opponent_signal": None,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
    }, budget)
    snap = agent.deception_snapshot()

    assert "ALIGNED" in snap["reliability"]["contexts"]
    assert "trust_signal" in snap["mvc"]["global"]
    assert snap["feedback_count"] == 1
