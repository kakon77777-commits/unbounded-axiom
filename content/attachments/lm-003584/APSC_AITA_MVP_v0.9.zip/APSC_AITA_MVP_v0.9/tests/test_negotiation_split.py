from aita.worlds.negotiation_split import NegotiationSplitWorld


def test_negotiation_reset_is_deterministic_and_preferences_are_private():
    a = NegotiationSplitWorld()
    b = NegotiationSplitWorld()
    states_a = a.reset(12)
    states_b = b.reset(12)
    assert states_a == states_b
    assert a.export_replay_state()["preferences"] == b.export_replay_state()["preferences"]
    assert "opponent_minimum" not in states_a["agent://A"]
    assert "opponent_concession_cost" not in states_a["agent://A"]
    assert states_a["agent://A"]["own_minimum"] == a.export_replay_state()["preferences"]["agent://A"]["minimum"]
    assert states_a["agent://B"]["own_minimum"] == a.export_replay_state()["preferences"]["agent://B"]["minimum"]


def test_offer_then_accept_creates_terminal_agreement():
    world = NegotiationSplitWorld(deadline=4, shift_tick=99)
    world.reset(2)
    world.step({"agent://A": {"type": "offer", "self_share": 6}, "agent://B": {"type": "wait"}})
    state_b = world.get_public_state("agent://B")
    assert state_b["outstanding_offer"]["proposer"] == "agent://A"
    assert state_b["outstanding_offer"]["receiver_share"] == 4
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "accept"}})
    assert world.is_terminal()
    scores = world.score_state()
    assert scores["agent://A"]["agreement_reached"] is True
    assert scores["agent://B"]["agreement_reached"] is True


def test_deadline_without_agreement_uses_disagreement_payoff():
    world = NegotiationSplitWorld(deadline=1, shift_tick=99)
    world.reset(5)
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "wait"}})
    scores = world.score_state()
    assert world.is_terminal()
    assert scores["agent://A"]["agreement_reached"] is False
    assert scores["agent://A"]["utility"] == scores["agent://A"]["disagreement_payoff"]
    assert scores["agent://B"]["utility"] == scores["agent://B"]["disagreement_payoff"]


def test_only_receiver_can_accept_outstanding_offer():
    world = NegotiationSplitWorld(deadline=4, shift_tick=99)
    world.reset(2)
    world.step({"agent://A": {"type": "offer", "self_share": 6}, "agent://B": {"type": "wait"}})
    assert {"type": "accept"} not in world.legal_actions("agent://A")
    assert {"type": "accept"} in world.legal_actions("agent://B")
