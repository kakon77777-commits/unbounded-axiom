import pytest

from apsc.budget import Budget
from aita.protocol import DuelEpisodeConfig


def test_duel_episode_config_requires_two_distinct_agents():
    config = DuelEpisodeConfig(
        episode_id='episode://duel/1',
        seed=7,
        agent_baselines={'agent://A': 'B3', 'agent://B': 'B4'},
        budgets={'agent://A': Budget(compute_units=5), 'agent://B': Budget(compute_units=5)},
        profile_names={'agent://A': 'balanced', 'agent://B': 'high_risk_assurance'},
    )
    assert config.agent_ids == ('agent://A', 'agent://B')


def test_duel_episode_config_rejects_missing_or_duplicate_agent_shape():
    with pytest.raises(ValueError):
        DuelEpisodeConfig(
            episode_id='episode://duel/bad',
            seed=1,
            agent_baselines={'agent://A': 'B3'},
            budgets={'agent://A': Budget(compute_units=5)},
            profile_names={'agent://A': 'balanced'},
        )
