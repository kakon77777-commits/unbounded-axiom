from __future__ import annotations

from pathlib import Path

import pytest


def f(**overrides):
    payload = {
        "state_uncertainty": 0.7,
        "value_gap": 0.2,
        "uncertainty_gap": 0.6,
        "observation_cost_fraction": 0.1,
    }
    payload.update(overrides)
    return payload


def test_exploration_policy_learns_positive_and_negative_advantage():
    from apsc.meta_exploration_policy import (
        ExplorationPolicyExperience,
        ExplorationPolicyFeatures,
        LearnedExplorationPolicyModel,
    )

    features = ExplorationPolicyFeatures.from_mapping(f())
    model = LearnedExplorationPolicyModel()
    positive = ExplorationPolicyExperience(
        "x://1", features, "trust_primary", "verify_independent", 1.5, 0.1
    )
    model.update(positive)
    assert model.predict(features).expected_advantage > 1.0
    negative = ExplorationPolicyExperience(
        "x://2", features, "trust_primary", "verify_independent", -2.0, 0.1
    )
    model.update(negative)
    assert model.predict(features).expected_advantage < 0.0


def test_exploration_policy_empty_model_falls_back_to_zero():
    from apsc.meta_exploration_policy import ExplorationPolicyFeatures, LearnedExplorationPolicyModel

    model = LearnedExplorationPolicyModel()
    prediction = model.predict(ExplorationPolicyFeatures.from_mapping(f()))
    assert prediction.expected_advantage == 0.0
    assert prediction.evidence_weight == 0.0
    assert prediction.epistemic_uncertainty == 1.0
    assert model.should_explore(ExplorationPolicyFeatures.from_mapping(f()), threshold=0.0) is False


def test_exploration_policy_bucket_backoff_and_target_uncertainty_weighting():
    from apsc.meta_exploration_policy import (
        ExplorationPolicyExperience,
        ExplorationPolicyFeatures,
        LearnedExplorationPolicyModel,
    )

    train = ExplorationPolicyFeatures.from_mapping(f(state_uncertainty=0.9))
    other = ExplorationPolicyFeatures.from_mapping(f(state_uncertainty=0.1))
    model = LearnedExplorationPolicyModel(min_target_weight=0.1)
    model.update(ExplorationPolicyExperience("x://1", train, "trust_primary", "verify_independent", 1.0, 0.0))
    model.update(ExplorationPolicyExperience("x://2", train, "trust_primary", "verify_independent", -1.0, 0.8))
    assert model.evidence_weight() == pytest.approx(1.2)
    assert model.predict(other).expected_advantage > 0.5


def test_exploration_policy_serialization_is_deterministic(tmp_path: Path):
    from apsc.meta_exploration_policy import (
        ExplorationPolicyExperience,
        ExplorationPolicyFeatures,
        LearnedExplorationPolicyModel,
    )

    model = LearnedExplorationPolicyModel()
    features = ExplorationPolicyFeatures.from_mapping(f())
    model.update(ExplorationPolicyExperience("x://1", features, "trust_primary", "verify_independent", 0.75, 0.2))
    path = tmp_path / "policy.json"
    model.save(path)
    loaded = LearnedExplorationPolicyModel.load(path)
    assert loaded.to_dict() == model.to_dict()
    assert loaded.model_hash() == model.model_hash()
