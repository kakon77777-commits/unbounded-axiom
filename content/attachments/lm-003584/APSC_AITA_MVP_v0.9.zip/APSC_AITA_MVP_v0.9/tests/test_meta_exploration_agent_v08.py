from __future__ import annotations

from apsc.budget import Budget
from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel, MetaStateFeatures
from aita.agents import B4LMetaLearnedAgent
from aita.benchmark import AGENT_FACTORIES, COP_PRESETS


def receiver_state(*, phase="RESPONSE", signal="FAST_SAFE", round_index=0, feedback=None, terminal=False):
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "receiver",
        "phase": phase,
        "round_index": round_index,
        "rounds_total": 8,
        "opponent_signal": signal if phase == "RESPONSE" else None,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
        "terminal": terminal,
    }


def feedback(round_index=0, *, utility=1.0):
    return {
        "round_index": round_index,
        "truth": "FAST_SAFE",
        "signal_claim": "FAST_SAFE",
        "signal_correct": True,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": utility,
        "signaler_utility": utility,
        "avoidable_receiver_loss": 0.0,
    }


def dummy_features():
    return MetaStateFeatures.from_mapping({
        "belief_aligned": 0.5,
        "belief_competitive": 0.5,
        "belief_entropy": 1.0,
        "effective_signal_trust": 0.8,
        "effective_field_trust": 0.7,
        "handcrafted_trust_mvc": 0.0,
        "handcrafted_field_mvc": 0.0,
        "round_fraction": 0.0,
        "observation_available": True,
        "signal_is_catastrophic": False,
    })


def operation(decision):
    return "observe_field" if decision.query is not None else "trust_signal"


def test_b4x_is_registered_and_frozen_empty_model_matches_b4l():
    from aita.agents import B4XExplorationMetaAgent

    assert AGENT_FACTORIES["B4X"] is B4XExplorationMetaAgent
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    b4l = B4LMetaLearnedAgent("agent://receiver", model=ExperienceMetaValueModel(), training=False)
    b4x = B4XExplorationMetaAgent(
        "agent://receiver",
        model=ExperienceMetaValueModel(),
        training=False,
        uncertainty_bonus=0.0,
    )
    for agent in (b4l, b4x):
        agent.reset(COP_PRESETS["balanced"])
    assert operation(b4l.decide(receiver_state(), budget)) == operation(b4x.decide(receiver_state(), budget))


def test_b4x_training_coverage_floor_selects_both_operations_early():
    from aita.agents import B4XExplorationMetaAgent

    agent = B4XExplorationMetaAgent(
        "agent://receiver",
        model=ExperienceMetaValueModel(),
        training=True,
        coverage_floor=1,
        uncertainty_bonus=0.0,
    )
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)

    first = agent.decide(receiver_state(round_index=0), budget)
    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback(0)), budget)
    second = agent.decide(receiver_state(round_index=1, signal="FAST_CATASTROPHIC", feedback=feedback(0)), budget)

    assert {operation(first), operation(second)} == {"trust_signal", "observe_field"}
    reasons = [row["selection_reason"] for row in agent.meta_exploration_log()]
    assert reasons[:2] == ["coverage_floor", "coverage_floor"]


def test_b4x_uncertainty_bonus_can_flip_greedy_value_choice():
    from aita.agents import B4XExplorationMetaAgent

    model = ExperienceMetaValueModel()
    f = dummy_features()
    for idx in range(8):
        model.update(CognitiveExperience(f"exp://t/{idx}", "ep://x", idx, "trust_signal", f, 0.6, 0.0))
    model.update(CognitiveExperience("exp://o/0", "ep://x", 0, "observe_field", f, 0.4, 0.15))

    agent = B4XExplorationMetaAgent(
        "agent://receiver",
        model=model,
        training=False,
        coverage_floor=0,
        uncertainty_bonus=0.6,
    )
    agent.reset(COP_PRESETS["balanced"])
    decision = agent.decide(receiver_state(), Budget(compute_units=30, observation_units=10, action_units=20))
    assert operation(decision) == "observe_field"
    snapshot = agent.meta_learning_snapshot()
    assert snapshot["exploration"]["greedy_operation"] == "trust_signal"
    assert snapshot["exploration"]["selected_operation"] == "observe_field"


def test_b4x_frozen_does_not_update_model_and_budget_still_blocks_observe():
    from aita.agents import B4XExplorationMetaAgent

    model = ExperienceMetaValueModel()
    agent = B4XExplorationMetaAgent(
        "agent://receiver",
        model=model,
        training=False,
        coverage_floor=5,
        uncertainty_bonus=10.0,
    )
    agent.reset(COP_PRESETS["balanced"])
    before = model.model_hash()
    decision = agent.decide(receiver_state(), Budget(compute_units=30, observation_units=0, action_units=20))
    agent.finalize_episode(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback(0), terminal=True))
    assert operation(decision) == "trust_signal"
    assert model.model_hash() == before


def test_b4x_finalize_episode_processes_terminal_feedback_and_logs_selection_reason():
    from aita.agents import B4XExplorationMetaAgent

    model = ExperienceMetaValueModel()
    agent = B4XExplorationMetaAgent(
        "agent://receiver",
        model=model,
        training=True,
        coverage_floor=1,
        uncertainty_bonus=0.0,
    )
    agent.set_episode_id("episode://v08/final")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    decision = agent.decide(receiver_state(round_index=0), budget)
    agent.finalize_episode(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback(0), terminal=True))

    chosen = operation(decision)
    assert model.evidence_count(chosen) == 1
    assert len(agent.meta_experience_log()) == 1
    exploration = agent.meta_exploration_log()
    assert exploration[0]["round_index"] == 0
    assert exploration[0]["selected_operation"] == chosen
    assert exploration[0]["selection_reason"] == "coverage_floor"
