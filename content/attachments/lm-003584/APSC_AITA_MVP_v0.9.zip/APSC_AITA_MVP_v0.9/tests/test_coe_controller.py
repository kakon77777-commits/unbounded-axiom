from apsc.budget import Budget
from apsc.coe import ObservationCandidate, value_observation
from apsc.controller import AdaptiveController
from apsc.cop import CognitiveOperatingProfile
from apsc.operators import CognitiveOperation


def test_observation_value_prefers_decision_relevant_probe():
    cop = CognitiveOperatingProfile(observation=0.8, counterfactual=0.5, risk=0.7)
    noisy = ObservationCandidate("query://noisy", information_gain=0.9, decision_value=0.1, risk_reduction=0.0, compression=0.1, cost=Budget(observation_units=1))
    decisive = ObservationCandidate("query://decisive", information_gain=0.3, decision_value=0.9, risk_reduction=0.2, compression=0.5, cost=Budget(observation_units=1))
    assert value_observation(decisive, cop) > value_observation(noisy, cop)


def test_controller_filters_unaffordable_operation():
    controller = AdaptiveController(shadow_prices={"compute_units": 0.1})
    budget = Budget(compute_units=2)
    expensive = CognitiveOperation("cog://expand@0.1", estimated_gain=10.0, cost=Budget(compute_units=3))
    cheap = CognitiveOperation("cog://verify@0.1", estimated_gain=1.0, cost=Budget(compute_units=1))
    chosen = controller.choose([expensive, cheap], budget, CognitiveOperatingProfile())
    assert chosen is cheap


def test_controller_stops_when_no_positive_value_operation_exists():
    controller = AdaptiveController(shadow_prices={"compute_units": 2.0}, epsilon=0.0)
    op = CognitiveOperation("cog://expand@0.1", estimated_gain=1.0, cost=Budget(compute_units=1))
    assert controller.choose([op], Budget(compute_units=5), CognitiveOperatingProfile()) is None


def test_controller_preempts_only_above_threshold():
    controller = AdaptiveController(shadow_prices={"compute_units": 0.0}, preemption_threshold=0.5)
    current = CognitiveOperation("cog://expand@0.1", estimated_gain=1.0, cost=Budget())
    better = CognitiveOperation("cog://observe@0.1", estimated_gain=1.7, cost=Budget())
    barely = CognitiveOperation("cog://verify@0.1", estimated_gain=1.4, cost=Budget())
    budget = Budget()
    cop = CognitiveOperatingProfile()
    assert controller.should_preempt(current, better, budget, cop) is True
    assert controller.should_preempt(current, barely, budget, cop) is False
