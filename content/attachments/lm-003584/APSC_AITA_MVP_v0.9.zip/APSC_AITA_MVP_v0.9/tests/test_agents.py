from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.agents import B0NeuralDirectAgent, B1FixedDepthAgent, B2FixedSearchVerifyAgent, B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.protocol import ObservationResult


def hidden_state(**overrides):
    state = {"location": "S", "neighbors": ["A", "B"], "goal": "G", "tick": 0, "deadline": 5, "hazard_hits": 0, "travel_cost": 0, "topology": {"S": ["A", "B"], "A": ["C"], "B": ["C", "G"], "C": ["G"], "G": []}, "known_safe": ["S", "G"]}
    state.update(overrides)
    return state


def test_b0_acts_directly_without_requesting_observation():
    agent = B0NeuralDirectAgent("agent://A")
    agent.reset(CognitiveOperatingProfile())
    decision = agent.decide(hidden_state(), Budget(compute_units=5, action_units=5, observation_units=5))
    assert decision.query is None
    assert decision.action is not None
    assert decision.cognition_operator == "cog://commit@0.1"


def test_b1_uses_fixed_probe_then_acts_from_evidence():
    agent = B1FixedDepthAgent("agent://A")
    agent.reset(CognitiveOperatingProfile())
    first = agent.decide(hidden_state(), Budget(compute_units=5, action_units=5, observation_units=5))
    assert first.query == {"type": "probe", "target": "A"}
    agent.ingest_observation(ObservationResult("obs://1", "agent://A", {"target": "A", "hazard": True}, 1.0, Budget(observation_units=1)))
    second = agent.decide(hidden_state(), Budget(compute_units=4, action_units=5, observation_units=4))
    assert second.action == {"type": "move", "target": "B"}


def test_b3_routes_through_apsc_controller_but_keeps_fixed_cop():
    cop = CognitiveOperatingProfile(observation=0.9, verification=0.8)
    agent = B3APSCFixedCOPAgent("agent://A")
    agent.reset(cop)
    decision = agent.decide(hidden_state(), Budget(compute_units=5, action_units=5, observation_units=5))
    assert decision.cognition_operator.startswith("cog://")
    assert decision.query == {"type": "probe", "target": "B"}
    assert agent.current_cop == cop
    assert decision.profile_receipt is None


def test_b4_risk_trigger_creates_profile_receipt_and_increases_assurance():
    cop = CognitiveOperatingProfile(risk=0.3, verification=0.4, observation=0.4)
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    agent.reset(cop)
    agent.ingest_observation(ObservationResult("obs://hazard", "agent://A", {"target": "A", "hazard": True}, 1.0, Budget(observation_units=1)))
    decision = agent.decide(hidden_state(), Budget(compute_units=5, action_units=5, observation_units=5))
    assert decision.profile_receipt is not None
    assert decision.profile_receipt.reason_code == "risk_trigger"
    assert agent.current_cop.risk >= 0.9
    assert agent.current_cop.verification >= 0.9


def test_b2_does_not_probe_known_safe_goal():
    agent = B2FixedSearchVerifyAgent("agent://A")
    agent.reset(CognitiveOperatingProfile())
    state = {"location": "B", "neighbors": ["C", "G"], "goal": "G", "tick": 1, "deadline": 5, "hazard_hits": 0, "travel_cost": 1, "topology": {"S": ["A", "B"], "A": ["C"], "B": ["C", "G"], "C": ["G"], "G": []}, "known_safe": ["S", "G"]}
    decision = agent.decide(state, Budget(compute_units=10, action_units=5, observation_units=5))
    assert decision.action == {"type": "move", "target": "G"}
