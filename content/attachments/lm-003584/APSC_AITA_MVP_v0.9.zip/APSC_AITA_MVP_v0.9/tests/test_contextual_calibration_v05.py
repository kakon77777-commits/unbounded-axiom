from apsc.reliability import ContextualSourceReliabilityTracker
from apsc.value_estimator import ContextualMVCValueEstimator


def test_contextual_reliability_diverges_for_same_source():
    tracker = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
    for _ in range(3):
        tracker.record("agent://signaler", "ALIGNED", 0.8, correct=True)
        tracker.record("agent://signaler", "COMPETITIVE", 0.8, correct=False)

    aligned = tracker.estimate("agent://signaler", "ALIGNED", 0.8)
    competitive = tracker.estimate("agent://signaler", "COMPETITIVE", 0.8)

    assert aligned > competitive
    assert aligned > 0.6
    assert competitive < 0.6


def test_contextual_reliability_unseen_context_backs_off_to_global():
    tracker = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
    tracker.record("agent://signaler", "ALIGNED", 0.8, correct=True)
    tracker.record("agent://signaler", "COMPETITIVE", 0.8, correct=False)

    unseen = tracker.estimate("agent://signaler", "UNSEEN", 0.8)
    global_est = tracker.global_estimate("agent://signaler", 0.8)
    assert unseen == global_est


def test_contextual_reliability_snapshot_exposes_global_and_context_counts():
    tracker = ContextualSourceReliabilityTracker()
    tracker.record("agent://signaler", "ALIGNED", 0.8, correct=True)
    snap = tracker.snapshot()

    assert snap["global"]["agent://signaler"]["successes"] == 1
    assert snap["contexts"]["ALIGNED"]["agent://signaler"]["successes"] == 1


def test_contextual_mvc_diverges_by_context_and_backs_off():
    estimator = ContextualMVCValueEstimator(backoff_strength=1.0)
    for _ in range(3):
        estimator.update("trust_signal", "agent://signaler", "ALIGNED", 1.0)
        estimator.update("trust_signal", "agent://signaler", "COMPETITIVE", -1.0)

    aligned = estimator.estimate("trust_signal", "agent://signaler", "ALIGNED", fallback=0.0)
    competitive = estimator.estimate("trust_signal", "agent://signaler", "COMPETITIVE", fallback=0.0)
    unseen = estimator.estimate("trust_signal", "agent://signaler", "UNSEEN", fallback=0.0)

    assert aligned > 0.0
    assert competitive < 0.0
    assert competitive < unseen < aligned


def test_contextual_mvc_snapshot_contains_source_context_evidence():
    estimator = ContextualMVCValueEstimator()
    estimator.update("observe", "sensor://field", "COMPETITIVE", 0.5)
    snap = estimator.snapshot()

    assert snap["global"]["observe"]["count"] == 1
    assert snap["source"]["observe"]["sensor://field"]["count"] == 1
    assert snap["context"]["observe"]["sensor://field"]["COMPETITIVE"]["count"] == 1
