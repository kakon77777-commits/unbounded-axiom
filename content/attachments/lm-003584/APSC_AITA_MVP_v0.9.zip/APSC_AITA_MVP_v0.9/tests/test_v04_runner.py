import json

from apsc.budget import Budget
from aita.agents import B0NeuralDirectAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS, WORLD_FACTORIES
from aita.protocol import EpisodeConfig
from aita.runner import run_episode
from aita.worlds.signal_hazard import SignalHazardWorld


def _budget() -> Budget:
    return Budget(compute_units=60, observation_units=20, action_units=20)


def test_signal_hazard_is_registered_in_existing_single_agent_factory():
    assert WORLD_FACTORIES["SignalHazard-v0.4"] is SignalHazardWorld


def test_b4_signal_hazard_run_emits_calibration_artifact_and_hash(tmp_path):
    run_episode(
        SignalHazardWorld(rounds=8),
        B4APSCAdaptiveCOPAgent("agent://A"),
        EpisodeConfig("episode://v04/calibration", 1, "B4", _budget(), "high_risk_assurance"),
        tmp_path,
        COP_PRESETS["high_risk_assurance"],
    )
    calibration = tmp_path / "calibration.jsonl"
    assert calibration.exists()
    rows = [json.loads(line) for line in calibration.read_text(encoding="utf-8").splitlines() if line]
    assert rows
    assert any(row["reliability"] for row in rows)
    assert any(row["mvc"] for row in rows)
    replay = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "calibration.jsonl" in replay["artifact_hashes"]


def test_non_calibrating_agent_does_not_emit_calibration_artifact(tmp_path):
    run_episode(
        SignalHazardWorld(rounds=2),
        B0NeuralDirectAgent("agent://A"),
        EpisodeConfig("episode://v04/direct", 1, "B0", _budget(), "balanced"),
        tmp_path,
        COP_PRESETS["balanced"],
    )
    assert not (tmp_path / "calibration.jsonl").exists()
