from __future__ import annotations

import json

import pytest

from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel, MetaStateFeatures


def features(**overrides):
    base = {
        "belief_aligned": 0.5,
        "belief_competitive": 0.5,
        "belief_entropy": 1.0,
        "effective_signal_trust": 0.8,
        "effective_field_trust": 0.7,
        "handcrafted_trust_mvc": 0.1,
        "handcrafted_field_mvc": 0.2,
        "round_fraction": 0.25,
        "observation_available": True,
        "signal_is_catastrophic": False,
    }
    base.update(overrides)
    return MetaStateFeatures.from_mapping(base)


def test_meta_features_reject_hidden_or_truth_fields():
    payload = features().to_dict()
    payload["true_context"] = "COMPETITIVE"
    with pytest.raises(ValueError, match="forbidden|unknown"):
        MetaStateFeatures.from_mapping(payload)

    payload = features().to_dict()
    payload["current_truth"] = "FAST_CATASTROPHIC"
    with pytest.raises(ValueError, match="forbidden|unknown"):
        MetaStateFeatures.from_mapping(payload)


def test_feature_bucket_is_stable_and_changes_on_material_state_change():
    a = features()
    b = MetaStateFeatures.from_mapping(a.to_dict())
    c = features(belief_competitive=0.85, belief_aligned=0.15)
    assert a.bucket_key() == b.bucket_key()
    assert a.bucket_key() != c.bucket_key()


def test_meta_value_model_uses_global_then_bucket_backoff():
    model = ExperienceMetaValueModel(backoff_strength=1.0)
    low_risk = features(belief_competitive=0.2, belief_aligned=0.8)
    high_risk = features(belief_competitive=0.9, belief_aligned=0.1)

    model.update(CognitiveExperience("exp://1", "ep://1", 0, "trust_signal", low_risk, 1.0, 0.0))
    model.update(CognitiveExperience("exp://2", "ep://2", 0, "trust_signal", high_risk, -2.0, 0.0))

    # Unseen bucket backs off to global action mean.
    unseen = features(belief_competitive=0.5, belief_aligned=0.5, round_fraction=0.8)
    assert model.estimate("trust_signal", unseen, fallback=9.0) == pytest.approx(-0.5)

    # Seen bucket blends its local mean with global mean.
    assert model.estimate("trust_signal", low_risk, fallback=9.0) == pytest.approx(0.25)


def test_model_tracks_evidence_for_both_operations():
    model = ExperienceMetaValueModel()
    f = features()
    model.update(CognitiveExperience("exp://t", "ep://1", 0, "trust_signal", f, 0.5, 0.0))
    model.update(CognitiveExperience("exp://o", "ep://1", 1, "observe_field", f, 0.2, 0.15))
    snap = model.to_dict()
    assert snap["actions"]["trust_signal"]["global"]["count"] == 1
    assert snap["actions"]["observe_field"]["global"]["count"] == 1


def test_json_roundtrip_preserves_model_and_hash(tmp_path):
    model = ExperienceMetaValueModel(backoff_strength=2.0)
    f = features(belief_competitive=0.8, belief_aligned=0.2)
    model.update(CognitiveExperience("exp://1", "ep://1", 0, "observe_field", f, 0.65, 0.15))
    before_hash = model.model_hash()

    path = tmp_path / "model.json"
    model.save(path)
    loaded = ExperienceMetaValueModel.load(path)

    assert loaded.to_dict() == model.to_dict()
    assert loaded.model_hash() == before_hash
    assert json.loads(path.read_text(encoding="utf-8")) == model.to_dict()
