from pathlib import Path


def test_readme_documents_install_test_run_and_mvp_boundaries():
    text = Path("README.md").read_text(encoding="utf-8")
    for required in (
        "pip install -e '.[dev]'",
        "pytest -q",
        "aita run",
        "aita matrix",
        "HiddenRoute-v0.1",
        "LimitedVerifier-v0.1",
        "B0",
        "B4",
        "No private chain-of-thought persistence",
        "bounded simulation",
    ):
        assert required in text


def test_changelog_declares_v010():
    text = Path("CHANGELOG.md").read_text(encoding="utf-8")
    assert "0.1.0" in text
    assert "APSC Runtime Lite" in text
    assert "AI Tension Arena" in text


def test_v020_docs_declare_duel_rule_shift_and_cross_play():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    acceptance = Path("docs/ACCEPTANCE.md").read_text(encoding="utf-8")
    pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
    for required in (
        "MVP v0.2",
        "HiddenRouteDuel-v0.2",
        "aita duel",
        "aita duel-matrix",
        "rule shift",
        "COP cross-play",
        "role swap",
    ):
        assert required in readme
    assert "0.2.0" in changelog
    assert 'version = "' in pyproject
    assert "dual-agent" in acceptance
