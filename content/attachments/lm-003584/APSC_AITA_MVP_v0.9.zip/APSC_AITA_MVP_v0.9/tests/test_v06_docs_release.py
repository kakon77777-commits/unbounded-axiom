from pathlib import Path
import json


def test_v060_docs_declare_latent_context_inference_and_nonuniversality():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.6",
        "LatentContextSignalDuel-v0.6",
        "LatentContextBeliefTracker",
        "belief-weighted",
        "latent_context.jsonl",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.6.0" in changelog


def test_v060_results_document_has_required_evidence_sections():
    text = Path("docs/V0.6_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "Hidden context isolation",
        "Latent belief responsiveness",
        "Belief-weighted trust",
        "Belief-weighted MVC",
        "Receiver trade-off",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v060_validation_metadata_and_v05_archive_exist():
    v06_archive = json.loads(Path("docs/validation/VALIDATION_v0.6.json").read_text(encoding="utf-8"))
    assert v06_archive["version"] == "0.6.0"
    assert v06_archive["status"] == "PASS"
    v06 = v06_archive["checks"]["v06_evidence"]
    assert v06["status"] == "PASS"
    for gate in ("V6-A", "V6-B", "V6-C", "V6-D", "V6-E", "V6-F", "V6-G", "V6-H", "V6-I"):
        assert v06["gates"][gate]["status"] == "PASS"

    archived = json.loads(Path("docs/validation/VALIDATION_v0.5.json").read_text(encoding="utf-8"))
    assert archived["version"] == "0.5.0"
    assert archived["status"] == "PASS"
