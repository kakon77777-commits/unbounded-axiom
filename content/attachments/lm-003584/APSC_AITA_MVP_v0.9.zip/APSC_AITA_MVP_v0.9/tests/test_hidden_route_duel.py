import pytest

from aita.worlds.hidden_route_duel import HiddenRouteDuelWorld


def test_duel_reset_is_deterministic_and_hazards_are_hidden():
    a = HiddenRouteDuelWorld(shift_tick=2)
    b = HiddenRouteDuelWorld(shift_tick=2)
    state_a = a.reset(11)
    state_b = b.reset(11)
    assert a.export_replay_state()["hazards"] == b.export_replay_state()["hazards"]
    assert state_a == state_b
    assert "hazards" not in state_a["agent://A"]
    assert "hazards" not in state_a["agent://B"]


def test_probe_is_private_and_charged():
    world = HiddenRouteDuelWorld()
    world.reset(3)
    result = world.observe("agent://A", {"type": "probe", "target": "A"})
    assert result.agent_id == "agent://A"
    assert result.cost.observation_units == 1
    assert result.payload == {"target": "A", "hazard": "A" in world.export_replay_state()["hazards"]}
    assert "hazards" not in world.get_public_state("agent://B")


def test_simultaneous_different_moves_both_apply_and_claim_nodes():
    world = HiddenRouteDuelWorld(shift_tick=9)
    world.reset(5)
    states = world.step({
        "agent://A": {"type": "move", "target": "A"},
        "agent://B": {"type": "move", "target": "B"},
    })
    assert states["agent://A"]["location"] == "A"
    assert states["agent://B"]["location"] == "B"
    replay = world.export_replay_state()
    assert replay["claims"]["A"] == "agent://A"
    assert replay["claims"]["B"] == "agent://B"


def test_collision_resolution_is_deterministic_and_loser_stays():
    world = HiddenRouteDuelWorld(shift_tick=9)
    world.reset(8)
    states = world.step({
        "agent://A": {"type": "move", "target": "A"},
        "agent://B": {"type": "move", "target": "A"},
    })
    assert states["agent://A"]["location"] == "A"
    assert states["agent://B"]["location"] == "S"
    assert states["agent://B"]["collision_blocks"] == 1


def test_rule_shift_is_public_and_changes_shortcut_after_shift_tick():
    world = HiddenRouteDuelWorld(shift_tick=2)
    world.reset(2)
    assert world.get_public_state("agent://A")["rule_version"] == 1
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "wait"}})
    assert world.get_public_state("agent://A")["rule_version"] == 1
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "wait"}})
    state = world.get_public_state("agent://A")
    assert state["rule_version"] == 2
    assert state["shifted"] is True
    assert "G" in state["topology"]["A"]
    assert "G" not in state["topology"]["B"]


def test_duel_rejects_missing_agent_action_and_exports_complete_replay():
    world = HiddenRouteDuelWorld()
    world.reset(7)
    with pytest.raises(ValueError):
        world.step({"agent://A": {"type": "wait"}})
    replay = world.export_replay_state()
    assert set(replay["positions"]) == {"agent://A", "agent://B"}
    assert "hazards" in replay
    assert "rule_version" in replay


def test_collision_tie_break_alternates_deterministically_across_seeds():
    world = HiddenRouteDuelWorld(shift_tick=9)
    world.reset(9)
    states = world.step({
        "agent://A": {"type": "move", "target": "A"},
        "agent://B": {"type": "move", "target": "A"},
    })
    assert states["agent://B"]["location"] == "A"
    assert states["agent://A"]["location"] == "S"
