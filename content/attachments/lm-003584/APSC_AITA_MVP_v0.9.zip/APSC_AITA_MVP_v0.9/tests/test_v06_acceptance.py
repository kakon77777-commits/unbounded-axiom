from pathlib import Path

from apsc.budget import Budget
from aita.acceptance import validate_v06_evidence
from aita.agents import B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS, run_latent_context_signal_matrix
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


def budget():
    return Budget(compute_units=120, memory_units=100, observation_units=30, action_units=120)


def test_v06_acceptance_passes_on_reference_like_latent_evidence(tmp_path: Path):
    matrix_dir = tmp_path / "matrix"
    spec = {
        "world": "LatentContextSignalDuel-v0.6",
        "signaler_baselines": ["B2"],
        "receiver_baselines": ["B4"],
        "signaler_profile": "balanced",
        "receiver_profile": "balanced",
        "budgets": {"medium": budget().to_dict()},
        "seeds": [1],
    }
    run_latent_context_signal_matrix(spec, matrix_dir)

    detailed = tmp_path / "detailed"
    world = LatentContextSignalDuelWorld(rounds=8)
    agents = {
        world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER),
        world.RECEIVER: B4APSCAdaptiveCOPAgent(world.RECEIVER),
    }
    cops = {world.SIGNALER: COP_PRESETS["balanced"], world.RECEIVER: COP_PRESETS["balanced"]}
    config = DuelEpisodeConfig(
        episode_id="episode://v06/detailed",
        seed=1,
        agent_baselines={world.SIGNALER: "B2", world.RECEIVER: "B4"},
        budgets={world.SIGNALER: budget(), world.RECEIVER: budget()},
        profile_names={world.SIGNALER: "balanced", world.RECEIVER: "balanced"},
        max_cycles=128,
    )
    run_duel_episode(world, agents, config, detailed, cops)

    gates = validate_v06_evidence(
        latent_matrix_dir=matrix_dir,
        detailed_receiver_run_dir=detailed,
        backward_compatibility_passed=True,
    )
    assert set(gates) == {f"V6-{letter}" for letter in "ABCDEFGHI"}
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates
