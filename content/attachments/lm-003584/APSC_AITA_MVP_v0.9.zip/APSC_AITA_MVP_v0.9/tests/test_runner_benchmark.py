import json
from pathlib import Path

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.agents import B0NeuralDirectAgent
from aita.benchmark import run_matrix
from aita.protocol import EpisodeConfig
from aita.runner import run_episode
from aita.worlds.hidden_route import HiddenRouteWorld


CANONICAL_METRICS = {
    "task_utility",
    "decision_quality",
    "cognitive_efficiency",
    "observation_efficiency",
    "critical_branch_recall",
    "opponent_model_regret",
    "allocation_regret",
    "observation_regret",
    "commit_regret",
    "rule_compliance",
    "robustness",
}


def test_runner_enforces_budget_before_agent_action(tmp_path: Path):
    world = HiddenRouteWorld(deadline=5)
    agent = B0NeuralDirectAgent("agent://A")
    config = EpisodeConfig("episode://budget", 42, "B0", Budget(), "balanced")
    result = run_episode(world, agent, config, tmp_path / "budget", CognitiveOperatingProfile())
    assert result.status == "budget_exhausted"
    assert world.get_public_state()["location"] == "S"


def test_runner_writes_canonical_episode_artifacts_and_metric_vector(tmp_path: Path):
    world = HiddenRouteWorld(deadline=5)
    agent = B0NeuralDirectAgent("agent://A")
    config = EpisodeConfig("episode://artifacts", 42, "B0", Budget(compute_units=10, action_units=10, observation_units=5), "balanced")
    result = run_episode(world, agent, config, tmp_path / "episode", CognitiveOperatingProfile())
    expected = {
        "episode.json", "world_manifest.json", "events.jsonl", "observations.jsonl",
        "cognitive_ops.jsonl", "actions.jsonl", "budgets.jsonl", "profiles.jsonl",
        "receipts.jsonl", "score.json", "replay_manifest.json",
    }
    assert expected <= {p.name for p in result.output_dir.iterdir()}
    score = json.loads((result.output_dir / "score.json").read_text(encoding="utf-8"))
    assert CANONICAL_METRICS <= set(score)
    assert result.status == "completed"


def test_matrix_pairs_same_seed_across_baselines_and_aggregates(tmp_path: Path):
    spec = {
        "worlds": ["HiddenRoute-v0.1"],
        "baselines": ["B0", "B1"],
        "budgets": {
            "small": {"compute_units": 20, "action_units": 10, "observation_units": 5}
        },
        "seeds": [1, 2],
    }
    report = run_matrix(spec, tmp_path / "matrix")
    assert len(report.rows) == 4
    for seed in (1, 2):
        rows = [r for r in report.rows if r["seed"] == seed]
        assert len(rows) == 2
        assert len({r["initial_world_hash"] for r in rows}) == 1
    assert report.aggregates["HiddenRoute-v0.1|B0|small"]["count"] == 2
    assert report.aggregates["HiddenRoute-v0.1|B1|small"]["count"] == 2
    assert (tmp_path / "matrix" / "result_per_seed.jsonl").exists()
    assert (tmp_path / "matrix" / "benchmark_report.json").exists()
