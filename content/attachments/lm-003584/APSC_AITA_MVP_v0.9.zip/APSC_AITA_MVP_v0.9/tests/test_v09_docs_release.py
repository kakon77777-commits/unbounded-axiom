from pathlib import Path
import json


def test_v090_docs_declare_cross_world_generalization_and_negative_transfer():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    pyproject = Path("pyproject.toml").read_text(encoding="utf-8")
    for required in (
        "MVP v0.9",
        "B4G",
        "world-neutral",
        "SignalHazard → LatentContext",
        "LatentContext → SignalHazard",
        "target uncertainty",
        "learned exploration",
        "negative transfer",
        "frozen",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.9.0" in changelog
    assert 'version = "0.9.0"' in pyproject


def test_v090_results_document_has_required_evidence_sections():
    text = Path("docs/V0.9_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "World-neutral representation",
        "SignalHazard → LatentContext",
        "LatentContext → SignalHazard",
        "Target uncertainty",
        "Learned exploration policy",
        "Frozen held-out transfer",
        "Negative transfer",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v090_validation_metadata_and_v08_archive_exist():
    current = json.loads(Path("VALIDATION.json").read_text(encoding="utf-8"))
    assert current["version"] == "0.9.0"
    assert current["status"] == "PASS"
    v09 = current["checks"]["v09_evidence"]
    assert v09["status"] == "PASS"
    for gate in tuple(f"V9-{letter}" for letter in "ABCDEFGHIJK"):
        assert v09["gates"][gate]["status"] == "PASS"

    archived = json.loads(Path("docs/validation/VALIDATION_v0.8.json").read_text(encoding="utf-8"))
    assert archived["version"] == "0.8.0"
    assert archived["status"] == "PASS"
