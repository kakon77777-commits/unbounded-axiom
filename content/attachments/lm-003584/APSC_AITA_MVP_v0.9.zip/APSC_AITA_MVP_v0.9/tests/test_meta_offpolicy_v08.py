from __future__ import annotations

from pathlib import Path

import pytest

from apsc.budget import Budget
from apsc.meta_learning import ExperienceMetaValueModel
from aita.agents import B2FixedSearchVerifyAgent, B4XExplorationMetaAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


def build_run(output: Path):
    world = LatentContextSignalDuelWorld()
    budget = Budget(compute_units=120, memory_units=100, observation_units=30, action_units=120)
    receiver = B4XExplorationMetaAgent(
        world.RECEIVER,
        model=ExperienceMetaValueModel(),
        training=True,
        coverage_floor=1,
        uncertainty_bonus=0.0,
    )
    agents = {world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER), world.RECEIVER: receiver}
    cops = {agent_id: COP_PRESETS["balanced"] for agent_id in agents}
    config = DuelEpisodeConfig(
        episode_id="episode://v08/offpolicy/seed-1",
        seed=1,
        agent_baselines={world.SIGNALER: "B2", world.RECEIVER: "B4X"},
        budgets={world.SIGNALER: budget, world.RECEIVER: budget},
        profile_names={world.SIGNALER: "balanced", world.RECEIVER: "balanced"},
    )
    run_duel_episode(world, agents, config, output, cops)


def test_counterfactual_builder_generates_alternate_operation_with_same_features(tmp_path: Path):
    from aita.meta_offpolicy import build_counterfactual_experiences

    build_run(tmp_path)
    rows = build_counterfactual_experiences(tmp_path, observation_penalty=0.15, sample_weight=0.5)
    assert len(rows) == 8
    first = rows[0]
    assert first.source_kind == "counterfactual_off_policy"
    assert first.behavior_operation == "trust_signal"
    assert first.experience.operation == "observe_field"
    assert first.sample_weight == pytest.approx(0.5)
    assert first.counterfactual_of is not None

    # Seed 1 round 0: truth is catastrophic and the field signal is correct, so
    # the alternate field-check route is SAFE: 0.65 utility - 0.15 observation cost.
    assert first.experience.realized_value == pytest.approx(0.50)
    assert first.experience.observation_cost == pytest.approx(0.15)

    forbidden = {"true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"}
    assert forbidden.isdisjoint(first.experience.features.to_dict())


def test_counterfactual_builder_inverts_observe_behavior_to_trust_target(tmp_path: Path):
    from aita.meta_offpolicy import build_counterfactual_experiences

    build_run(tmp_path)
    rows = build_counterfactual_experiences(tmp_path, observation_penalty=0.15)
    by_round = {row.experience.round_index: row for row in rows}
    round_one = by_round[1]
    assert round_one.behavior_operation == "observe_field"
    assert round_one.experience.operation == "trust_signal"
    # B2 sends FAST_CATASTROPHIC at seed-1 round 1, so trust chooses SAFE.
    assert round_one.experience.realized_value == pytest.approx(0.65)
    assert round_one.experience.observation_cost == pytest.approx(0.0)


def test_counterfactual_rows_roundtrip_without_hidden_labels(tmp_path: Path):
    from apsc.meta_exploration import MetaTrainingExperience
    from aita.meta_offpolicy import build_counterfactual_experiences

    build_run(tmp_path)
    row = build_counterfactual_experiences(tmp_path, observation_penalty=0.15)[0]
    payload = row.to_dict()
    restored = MetaTrainingExperience.from_dict(payload)
    assert restored == row
    assert payload["selection_reason"] == "post_outcome_counterfactual"
