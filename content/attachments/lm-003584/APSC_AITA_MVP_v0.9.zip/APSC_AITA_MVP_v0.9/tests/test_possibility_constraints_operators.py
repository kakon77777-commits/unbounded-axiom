import pytest

from apsc.constraints import Constraint, ConstraintEngine
from apsc.models import PossibilityNode
from apsc.operators import OperatorSpec
from apsc.possibility import PossibilityGraph


def test_hard_failed_candidate_never_becomes_active():
    graph = PossibilityGraph()
    node = PossibilityNode.create("state://bad", 1, "near")
    graph.add_candidate(node)
    engine = ConstraintEngine([Constraint("rule://legal", "hard", lambda n: False)])
    results = engine.check(node)
    graph.apply_constraints(node.node_id, results)
    assert graph.get(node.node_id).status == "pruned"
    with pytest.raises(ValueError):
        graph.activate(node.node_id)


def test_soft_failed_candidate_can_remain_active():
    graph = PossibilityGraph()
    node = PossibilityNode.create("state://soft", 1, "near")
    graph.add_candidate(node)
    engine = ConstraintEngine([Constraint("rule://preference", "soft", lambda n: False)])
    graph.apply_constraints(node.node_id, engine.check(node))
    graph.activate(node.node_id)
    assert graph.get(node.node_id).status == "active"


def test_merge_retains_lineage_and_marks_sources_merged():
    graph = PossibilityGraph()
    a = PossibilityNode.create("state://a", 2, "mid", ("poss://root",))
    b = PossibilityNode.create("state://b", 2, "mid", ("poss://root2",))
    graph.add_candidate(a)
    graph.add_candidate(b)
    merged = graph.merge((a.node_id, b.node_id), state_ref="state://merged", horizon=2, resolution="mid")
    assert set(merged.parent_ids) == {a.node_id, b.node_id}
    assert graph.get(a.node_id).status == "merged"
    assert graph.get(b.node_id).status == "merged"


def test_operator_spec_preserves_interrupt_and_checkpoint_contract():
    spec = OperatorSpec(
        operator_id="cog://expand@0.1",
        input_types=("StateSnapshot",),
        output_types=("PossibilityNode",),
        interruptible=True,
        checkpointable=True,
    )
    assert spec.interruptible is True
    assert spec.checkpointable is True
    with pytest.raises(ValueError):
        OperatorSpec(operator_id="expand", input_types=(), output_types=())
