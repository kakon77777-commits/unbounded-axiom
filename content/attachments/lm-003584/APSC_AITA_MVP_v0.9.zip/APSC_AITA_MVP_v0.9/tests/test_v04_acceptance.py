import json
from pathlib import Path

from apsc.budget import Budget
from aita.acceptance import validate_v04_evidence
from aita.agents import B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS, run_matrix
from aita.protocol import EpisodeConfig
from aita.runner import run_episode
from aita.worlds.signal_hazard import SignalHazardWorld

ROOT = Path(__file__).resolve().parents[1]


def test_v04_example_spec_names_signal_hazard_and_calibration_baselines():
    spec = json.loads((ROOT / "examples" / "benchmark_v0.4_signal_hazard.json").read_text(encoding="utf-8"))
    assert spec["worlds"] == ["SignalHazard-v0.4"]
    assert {"B0", "B1", "B2", "B3", "B4"} <= set(spec["baselines"])
    assert spec["profile"] == "high_risk_assurance"
    assert spec["seeds"] == list(range(1, 9))


def test_validate_v04_evidence_requires_accuracy_divergence_calibration_shift_mvc_and_replay(tmp_path):
    matrix_dir = tmp_path / "signal-matrix"
    spec = {
        "worlds": ["SignalHazard-v0.4"],
        "baselines": ["B0", "B1", "B2", "B3", "B4"],
        "budgets": {"medium": {"compute_units": 60, "observation_units": 20, "action_units": 20}},
        "seeds": list(range(1, 9)),
        "profile": "high_risk_assurance",
    }
    run_matrix(spec, matrix_dir)

    calibration_dir = tmp_path / "calibration-run"
    budget = Budget(compute_units=60, observation_units=20, action_units=20)
    run_episode(
        SignalHazardWorld(rounds=8),
        B4APSCAdaptiveCOPAgent("agent://A"),
        EpisodeConfig("episode://v04/calibration", 1, "B4", budget, "high_risk_assurance"),
        calibration_dir,
        COP_PRESETS["high_risk_assurance"],
    )

    gates = validate_v04_evidence(signal_matrix_dir=matrix_dir, calibration_run_dir=calibration_dir)
    assert set(gates) == {"V4-A", "V4-B", "V4-C", "V4-D", "V4-E", "V4-F", "V4-G"}
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates
