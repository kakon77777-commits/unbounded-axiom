import json

from apsc.budget import Budget
from aita.agents import B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS, DUEL_WORLD_FACTORIES, WORLD_FACTORIES
from aita.protocol import DuelEpisodeConfig, EpisodeConfig
from aita.runner import run_duel_episode, run_episode
from aita.worlds.hazard_choice import HazardChoiceWorld
from aita.worlds.negotiation_split import NegotiationSplitWorld


def test_v03_worlds_are_registered_in_existing_factories():
    assert WORLD_FACTORIES["HazardChoice-v0.3"] is HazardChoiceWorld
    assert DUEL_WORLD_FACTORIES["NegotiationSplit-v0.3"] is NegotiationSplitWorld


def test_hazard_choice_runs_through_existing_single_agent_runner(tmp_path):
    world = HazardChoiceWorld()
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    config = EpisodeConfig(
        episode_id="episode://hazard/v03",
        seed=3,
        baseline="B4",
        budget=Budget(compute_units=10, observation_units=3, action_units=3),
        profile_name="high_risk_assurance",
    )
    result = run_episode(world, agent, config, tmp_path, COP_PRESETS["high_risk_assurance"])
    assert result.status == "completed"
    score = json.loads((tmp_path / "score.json").read_text(encoding="utf-8"))
    assert "catastrophic_loss" in score
    assert "avoidable_loss" in score


def test_negotiation_runs_through_existing_duel_runner_and_preserves_metrics(tmp_path):
    world = NegotiationSplitWorld(deadline=5, shift_tick=1)
    agents = {
        "agent://A": B3APSCFixedCOPAgent("agent://A"),
        "agent://B": B4APSCAdaptiveCOPAgent("agent://B"),
    }
    budget = Budget(compute_units=30, observation_units=4, action_units=20)
    config = DuelEpisodeConfig(
        episode_id="episode://negotiation/v03",
        seed=2,
        agent_baselines={"agent://A": "B3", "agent://B": "B4"},
        budgets={"agent://A": budget, "agent://B": budget},
        profile_names={"agent://A": "balanced", "agent://B": "balanced"},
        max_cycles=8,
    )
    result = run_duel_episode(
        world,
        agents,
        config,
        tmp_path,
        {"agent://A": COP_PRESETS["balanced"], "agent://B": COP_PRESETS["balanced"]},
    )
    assert result.status in {"completed", "cycle_limit"}
    score = json.loads((tmp_path / "score.json").read_text(encoding="utf-8"))
    for agent_id in ("agent://A", "agent://B"):
        assert "joint_utility" in score[agent_id]
        assert "pareto_efficiency" in score[agent_id]
        assert "agreement_stability" in score[agent_id]
        assert "negotiation_regret" in score[agent_id]
