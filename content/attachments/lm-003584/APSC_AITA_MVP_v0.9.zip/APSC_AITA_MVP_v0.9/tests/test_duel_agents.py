from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.agents import B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent


def duel_state(**overrides):
    state = {
        "location": "S",
        "opponent_location": "B",
        "neighbors": ["A", "B"],
        "goal": "G",
        "tick": 0,
        "deadline": 7,
        "hazard_hits": 0,
        "travel_cost": 0,
        "collision_blocks": 0,
        "topology": {"S": ["A", "B"], "A": ["C"], "B": ["C", "G"], "C": ["G"], "G": []},
        "known_safe": ["S", "G"],
        "claims": [],
        "opponent_claims": [],
        "rule_version": 1,
        "shifted": False,
        "shift_tick": 2,
    }
    state.update(overrides)
    return state


def test_b3_avoids_immediate_opponent_collision_when_alternative_exists():
    agent = B3APSCFixedCOPAgent("agent://A")
    agent.reset(CognitiveOperatingProfile(observation=0.9))
    decision = agent.decide(duel_state(), Budget(compute_units=10, observation_units=5, action_units=5))
    assert decision.query == {"type": "probe", "target": "A"}


def test_b3_keeps_fixed_cop_across_public_rule_shift():
    cop = CognitiveOperatingProfile(verification=0.4, observation=0.4)
    agent = B3APSCFixedCOPAgent("agent://A")
    agent.reset(cop)
    agent.decide(duel_state(rule_version=2, shifted=True), Budget(compute_units=10, observation_units=5, action_units=5))
    assert agent.current_cop == cop


def test_b4_rule_shift_creates_profile_receipt_and_increases_assurance():
    cop = CognitiveOperatingProfile(verification=0.3, observation=0.3, risk=0.4, abstraction=0.3)
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    agent.reset(cop)
    first = agent.decide(duel_state(rule_version=1), Budget(compute_units=10, observation_units=5, action_units=5))
    assert first.profile_receipt is None
    second = agent.decide(duel_state(rule_version=2, shifted=True, topology={"S": ["A", "B"], "A": ["C", "G"], "B": ["C"], "C": ["G"], "G": []}), Budget(compute_units=9, observation_units=5, action_units=5))
    assert second.profile_receipt is not None
    assert second.profile_receipt.reason_code == "rule_shift_trigger"
    assert agent.current_cop.verification >= 0.9
    assert agent.current_cop.observation >= 0.8
    assert agent.current_cop.abstraction >= 0.7


def test_b4_cop_cross_play_changes_first_cognitive_choice():
    low_latency = B4APSCAdaptiveCOPAgent("agent://A")
    high_risk = B4APSCAdaptiveCOPAgent("agent://B")
    low_latency.reset(CognitiveOperatingProfile(depth=0.25, breadth=0.2, verification=0.35, counterfactual=0.2, observation=0.2, risk=0.5, latency=0.95, abstraction=0.9, commitment=0.35, novelty=0.1))
    high_risk.reset(CognitiveOperatingProfile(depth=0.7, breadth=0.5, verification=0.95, counterfactual=0.7, observation=0.9, risk=0.95, latency=0.35, abstraction=0.5, commitment=0.95, novelty=0.25))
    state = duel_state(opponent_location="S")
    budget = Budget(compute_units=10, observation_units=5, action_units=5)
    fast_decision = low_latency.decide(state, budget)
    safe_decision = high_risk.decide(state, budget)
    assert fast_decision.action is not None
    assert fast_decision.query is None
    assert safe_decision.query is not None
