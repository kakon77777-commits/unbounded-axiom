from __future__ import annotations

import hashlib
import json
from pathlib import Path

from apsc.budget import Budget
from apsc.meta_exploration_policy import LearnedExplorationPolicyModel
from apsc.meta_generalization import CrossWorldMetaValueModel
from aita.agents import B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent, B4GGeneralizingMetaAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig, EpisodeConfig
from aita.runner import run_duel_episode, run_episode
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld
from aita.worlds.signal_hazard import SignalHazardWorld


def budget() -> Budget:
    return Budget(compute_units=160, memory_units=100, observation_units=40, action_units=160)


def test_single_runner_writes_generalization_artifact_and_hashes_it(tmp_path: Path):
    world = SignalHazardWorld()
    agent = B4GGeneralizingMetaAgent(
        world.AGENT_ID,
        value_model=CrossWorldMetaValueModel(),
        exploration_policy=LearnedExplorationPolicyModel(),
    )
    cfg = EpisodeConfig("episode://v09/replay/single", 1, "B4G", budget(), "balanced")
    run_episode(world, agent, cfg, tmp_path, COP_PRESETS["balanced"])

    path = tmp_path / "meta_generalization.jsonl"
    assert path.exists()
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert rows
    assert all(row["snapshot"]["selected_operation"] in {"trust_primary", "verify_independent"} for row in rows)
    assert all("world_id" not in row["snapshot"].get("features", {}) for row in rows)

    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "meta_generalization.jsonl" in manifest["artifact_hashes"]
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["artifact_hashes"]["meta_generalization.jsonl"]


def test_duel_runner_writes_receiver_generalization_artifact_and_hashes_it(tmp_path: Path):
    world = LatentContextSignalDuelWorld()
    agents = {
        world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER),
        world.RECEIVER: B4GGeneralizingMetaAgent(
            world.RECEIVER,
            value_model=CrossWorldMetaValueModel(),
            exploration_policy=LearnedExplorationPolicyModel(),
        ),
    }
    cfg = DuelEpisodeConfig(
        episode_id="episode://v09/replay/duel",
        seed=1,
        agent_baselines={world.SIGNALER: "B2", world.RECEIVER: "B4G"},
        budgets={world.SIGNALER: budget(), world.RECEIVER: budget()},
        profile_names={world.SIGNALER: "balanced", world.RECEIVER: "balanced"},
    )
    run_duel_episode(world, agents, cfg, tmp_path, {aid: COP_PRESETS["balanced"] for aid in agents})

    path = tmp_path / "meta_generalization.jsonl"
    assert path.exists()
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert rows
    assert {row["agent_id"] for row in rows} == {world.RECEIVER}
    assert any(row["snapshot"]["source_world"] == "LatentContextSignalDuel-v0.6" for row in rows)

    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(path.read_bytes()).hexdigest() == manifest["artifact_hashes"]["meta_generalization.jsonl"]


def test_ordinary_b4_does_not_emit_empty_generalization_artifact(tmp_path: Path):
    world = SignalHazardWorld()
    agent = B4APSCAdaptiveCOPAgent(world.AGENT_ID)
    cfg = EpisodeConfig("episode://v09/replay/b4", 1, "B4", budget(), "balanced")
    run_episode(world, agent, cfg, tmp_path, COP_PRESETS["balanced"])

    assert not (tmp_path / "meta_generalization.jsonl").exists()
    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "meta_generalization.jsonl" not in manifest["artifact_hashes"]
