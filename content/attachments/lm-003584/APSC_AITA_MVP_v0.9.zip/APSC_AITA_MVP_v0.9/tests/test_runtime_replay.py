import hashlib
import json
from pathlib import Path

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from apsc.models import StateSnapshot
from apsc.operators import CognitiveOperation
from apsc.runtime import APSCRuntime


def test_runtime_step_versions_state_charges_budget_and_creates_receipt():
    initial = StateSnapshot.create({"value": 1})
    runtime = APSCRuntime(goal="test", initial_state=initial, budget=Budget(compute_units=5), cop=CognitiveOperatingProfile())
    op = CognitiveOperation("cog://verify@0.1", estimated_gain=1.0, cost=Budget(compute_units=2), metadata={"kind": "verify"})
    receipt = runtime.step(op, next_payload={"value": 2})
    assert runtime.state.version == 1
    assert runtime.state.parent_state_id == initial.state_id
    assert runtime.budget.compute_units == 3
    assert receipt.receipt_id.startswith("receipt://")
    assert receipt.state_ref == runtime.state.state_id


def test_export_run_persists_budget_trajectory_and_manifest_hashes(tmp_path: Path):
    runtime = APSCRuntime(goal="export", initial_state=StateSnapshot.create({"x": 0}), budget=Budget(compute_units=4), cop=CognitiveOperatingProfile())
    runtime.step(CognitiveOperation("cog://expand@0.1", 1.0, Budget(compute_units=1), metadata={"kind": "expand"}), next_payload={"x": 1})
    runtime.commit("done")
    out = runtime.export_run(tmp_path / "run")

    budgets = [json.loads(line) for line in (out / "budgets.jsonl").read_text(encoding="utf-8").splitlines()]
    assert budgets[0]["before"]["compute_units"] == 4
    assert budgets[0]["after"]["compute_units"] == 3

    manifest = json.loads((out / "replay_manifest.json").read_text(encoding="utf-8"))
    required = {"events.jsonl", "budgets.jsonl", "receipts.jsonl", "final_state.json", "run_manifest.json"}
    assert required <= set(manifest["artifact_hashes"])
    for name, digest in manifest["artifact_hashes"].items():
        actual = hashlib.sha256((out / name).read_bytes()).hexdigest()
        assert digest == actual


def test_exported_event_sequence_is_monotone(tmp_path: Path):
    runtime = APSCRuntime(goal="sequence", initial_state=StateSnapshot.create({}), budget=Budget(compute_units=3), cop=CognitiveOperatingProfile())
    for i in range(2):
        runtime.step(CognitiveOperation("cog://expand@0.1", 1.0, Budget(compute_units=1), metadata={"kind": "expand"}), next_payload={"i": i})
    out = runtime.export_run(tmp_path / "run")
    events = [json.loads(line) for line in (out / "events.jsonl").read_text(encoding="utf-8").splitlines()]
    sequences = [e["sequence"] for e in events]
    assert sequences == sorted(sequences)
    assert sequences == list(range(len(sequences)))
