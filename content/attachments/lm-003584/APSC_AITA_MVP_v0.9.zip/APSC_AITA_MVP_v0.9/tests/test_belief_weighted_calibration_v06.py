import math

from apsc.reliability import ContextualSourceReliabilityTracker
from apsc.value_estimator import ContextualMVCValueEstimator, OnlineMVCValueEstimator


def test_contextual_reliability_soft_update_weights_context_evidence():
    tracker = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
    tracker.record_belief(
        "agent://signaler",
        {"ALIGNED": 0.75, "COMPETITIVE": 0.25},
        0.8,
        correct=True,
    )
    snap = tracker.snapshot()
    aligned = snap["contexts"]["ALIGNED"]["agent://signaler"]
    competitive = snap["contexts"]["COMPETITIVE"]["agent://signaler"]
    assert math.isclose(float(aligned["successes"]), 0.75)
    assert math.isclose(float(competitive["successes"]), 0.25)
    assert math.isclose(float(snap["global"]["agent://signaler"]["successes"]), 1.0)


def test_contextual_reliability_belief_estimate_is_probability_weighted_mixture():
    tracker = ContextualSourceReliabilityTracker(prior_strength=2.0, backoff_strength=1.0)
    for _ in range(3):
        tracker.record("agent://signaler", "ALIGNED", 0.8, correct=True)
        tracker.record("agent://signaler", "COMPETITIVE", 0.8, correct=False)
    weights = {"ALIGNED": 0.8, "COMPETITIVE": 0.2}
    expected = sum(weights[c] * tracker.estimate("agent://signaler", c, 0.8) for c in weights)
    assert math.isclose(tracker.estimate_belief("agent://signaler", weights, 0.8), expected)


def test_existing_contextual_reliability_unit_updates_remain_identical():
    old = ContextualSourceReliabilityTracker()
    new = ContextualSourceReliabilityTracker()
    old.record("agent://signaler", "ALIGNED", 0.8, correct=True)
    new.record_belief("agent://signaler", {"ALIGNED": 1.0}, 0.8, correct=True)
    assert old.snapshot() == new.snapshot()


def test_online_mvc_weighted_update_tracks_evidence_weight_without_breaking_count():
    estimator = OnlineMVCValueEstimator()
    estimator.update_weighted("trust", 1.0, weight=0.75)
    estimator.update_weighted("trust", -1.0, weight=0.25)
    assert estimator.count("trust") == 2
    assert math.isclose(estimator.evidence_weight("trust"), 1.0)
    assert math.isclose(estimator.estimate("trust"), 0.5)


def test_contextual_mvc_soft_update_and_belief_estimate():
    estimator = ContextualMVCValueEstimator(backoff_strength=1.0)
    estimator.update_belief(
        "trust_signal",
        "agent://signaler",
        {"ALIGNED": 0.75, "COMPETITIVE": 0.25},
        1.0,
    )
    snap = estimator.snapshot()
    assert math.isclose(float(snap["context"]["trust_signal"]["agent://signaler"]["ALIGNED"]["weight"]), 0.75)
    assert math.isclose(float(snap["context"]["trust_signal"]["agent://signaler"]["COMPETITIVE"]["weight"]), 0.25)
    value = estimator.estimate_belief(
        "trust_signal",
        "agent://signaler",
        {"ALIGNED": 0.8, "COMPETITIVE": 0.2},
        fallback=0.0,
    )
    expected = sum(
        p * estimator.estimate("trust_signal", "agent://signaler", c, fallback=0.0)
        for c, p in {"ALIGNED": 0.8, "COMPETITIVE": 0.2}.items()
    )
    assert math.isclose(value, expected)


def test_existing_contextual_mvc_unit_update_remains_identical():
    old = ContextualMVCValueEstimator()
    new = ContextualMVCValueEstimator()
    old.update("trust_signal", "agent://signaler", "ALIGNED", 1.0)
    new.update_belief("trust_signal", "agent://signaler", {"ALIGNED": 1.0}, 1.0)
    assert old.snapshot() == new.snapshot()
