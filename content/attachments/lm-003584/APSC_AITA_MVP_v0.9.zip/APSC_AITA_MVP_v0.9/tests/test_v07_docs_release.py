from pathlib import Path
import json


def test_v070_docs_declare_learned_meta_controller_and_nonuniversality():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.7",
        "B4L",
        "CognitiveExperience",
        "ExperienceMetaValueModel",
        "meta_learning.jsonl",
        "held-out",
        "frozen",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.7.0" in changelog


def test_v070_results_document_has_required_evidence_sections():
    text = Path("docs/V0.7_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "Train / eval isolation",
        "Learning evidence",
        "Frozen held-out evaluation",
        "B4 vs B4L",
        "Routing divergence",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v070_validation_metadata_and_v06_archive_exist():
    current = json.loads(Path("docs/validation/VALIDATION_v0.7.json").read_text(encoding="utf-8"))
    assert current["version"] == "0.7.0"
    assert current["status"] == "PASS"
    v07 = current["checks"]["v07_evidence"]
    assert v07["status"] == "PASS"
    for gate in ("V7-A", "V7-B", "V7-C", "V7-D", "V7-E", "V7-F", "V7-G", "V7-H", "V7-I"):
        assert v07["gates"][gate]["status"] == "PASS"

    archived = json.loads(Path("docs/validation/VALIDATION_v0.6.json").read_text(encoding="utf-8"))
    assert archived["version"] == "0.6.0"
    assert archived["status"] == "PASS"
