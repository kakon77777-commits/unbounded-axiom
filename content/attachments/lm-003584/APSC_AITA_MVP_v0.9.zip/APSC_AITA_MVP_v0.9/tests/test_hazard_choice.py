from aita.worlds.hazard_choice import HazardChoiceWorld


def _seed_for(regime: str) -> int:
    probe = HazardChoiceWorld()
    for seed in range(100):
        probe.reset(seed)
        if probe.export_replay_state()["regime"] == regime:
            return seed
    raise AssertionError(f"no seed found for {regime}")


def test_hazard_choice_reset_is_deterministic_and_regime_is_hidden():
    a = HazardChoiceWorld()
    b = HazardChoiceWorld()
    assert a.reset(4) == b.reset(4)
    assert a.export_replay_state()["regime"] == b.export_replay_state()["regime"]
    assert "regime" not in a.get_public_state()


def test_probe_reveals_regime_at_observation_cost():
    world = HazardChoiceWorld()
    world.reset(3)
    obs = world.observe("agent://A", {"type": "probe", "target": "route-regime"})
    assert obs.payload["regime"] in {"FAST_SAFE", "FAST_CATASTROPHIC"}
    assert obs.cost.observation_units == 1
    assert obs.reliability == 1.0


def test_fast_catastrophic_is_irreversible_large_loss():
    world = HazardChoiceWorld()
    seed = _seed_for("FAST_CATASTROPHIC")
    world.reset(seed)
    world.step({"agent://A": {"type": "choose", "route": "FAST"}})
    score = world.score_state()
    assert world.is_terminal()
    assert score["catastrophic_loss"] == 1
    assert score["utility"] < -1.0


def test_safe_route_is_positive_but_slower_than_safe_fast_route():
    safe_fast_seed = _seed_for("FAST_SAFE")
    fast = HazardChoiceWorld()
    slow = HazardChoiceWorld()
    fast.reset(safe_fast_seed)
    slow.reset(safe_fast_seed)
    fast.step({"agent://A": {"type": "choose", "route": "FAST"}})
    slow.step({"agent://A": {"type": "choose", "route": "SAFE"}})
    assert 0.0 < slow.score_state()["utility"] < fast.score_state()["utility"]
