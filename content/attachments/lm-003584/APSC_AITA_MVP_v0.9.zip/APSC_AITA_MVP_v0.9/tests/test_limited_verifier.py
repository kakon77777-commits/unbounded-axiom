import pytest

from aita.worlds.limited_verifier import LimitedVerifierWorld


def test_limited_verifier_reset_is_deterministic_and_hides_oracle():
    a = LimitedVerifierWorld(verifier_limit=2)
    b = LimitedVerifierWorld(verifier_limit=2)
    public_a = a.reset(42)
    public_b = b.reset(42)
    assert public_a == public_b
    assert "correct_candidate" not in public_a
    assert a.export_replay_state()["correct_candidate"] == b.export_replay_state()["correct_candidate"]


def test_verifier_returns_evidence_and_consumes_quota():
    world = LimitedVerifierWorld(verifier_limit=2)
    state = world.reset(42)
    candidate = state["candidates"][0]
    result = world.observe("agent://A", {"type": "verify", "candidate": candidate})
    assert result.payload == {"candidate": candidate, "verified": result.payload["verified"]}
    assert world.get_public_state()["verifier_remaining"] == 1
    assert result.cost.observation_units == 1


def test_verifier_fails_closed_over_quota():
    world = LimitedVerifierWorld(verifier_limit=1)
    state = world.reset(2)
    world.observe("agent://A", {"type": "verify", "candidate": state["candidates"][0]})
    with pytest.raises(ValueError):
        world.observe("agent://A", {"type": "verify", "candidate": state["candidates"][1]})


def test_commit_terminates_and_scores_correctness_with_verifier_cost():
    world = LimitedVerifierWorld(verifier_limit=3)
    state = world.reset(9)
    oracle = world.export_replay_state()["correct_candidate"]
    world.observe("agent://A", {"type": "verify", "candidate": oracle})
    world.step({"agent://A": {"type": "commit", "candidate": oracle}})
    assert world.is_terminal() is True
    score = world.score_state()
    assert score["correct"] is True
    assert score["verifications_used"] == 1
    assert 0.0 < score["utility"] <= 1.0
