from pathlib import Path
import json


def test_v050_docs_declare_strategic_signaling_contextual_calibration_and_nonuniversality():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.5",
        "StrategicSignalDuel-v0.5",
        "strategic deceptive signaling",
        "ContextualSourceReliabilityTracker",
        "ContextualMVCValueEstimator",
        "deception.jsonl",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.5.0" in changelog


def test_v050_results_document_has_required_evidence_sections():
    text = Path("docs/V0.5_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "Strategic signaler policy",
        "Contextual trust divergence",
        "Receiver behavior shift",
        "Contextual MVC",
        "Deception success/failure",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v050_validation_metadata_and_v04_archive_exist():
    v05_archive = json.loads(Path("docs/validation/VALIDATION_v0.5.json").read_text(encoding="utf-8"))
    assert v05_archive["version"] == "0.5.0"
    assert v05_archive["status"] == "PASS"
    v05 = v05_archive["checks"]["v05_evidence"]
    assert v05["status"] == "PASS"
    for gate in ("V5-A", "V5-B", "V5-C", "V5-D", "V5-E", "V5-F", "V5-G", "V5-H"):
        assert v05["gates"][gate]["status"] == "PASS"

    archived = json.loads(Path("docs/validation/VALIDATION_v0.4.json").read_text(encoding="utf-8"))
    assert archived["version"] == "0.4.0"
    assert archived["status"] == "PASS"
