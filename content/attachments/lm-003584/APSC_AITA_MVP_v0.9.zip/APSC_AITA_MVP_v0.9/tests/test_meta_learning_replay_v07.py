from __future__ import annotations

import hashlib
import json
from pathlib import Path

from apsc.budget import Budget
from apsc.meta_learning import ExperienceMetaValueModel
from aita.agents import B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent, B4LMetaLearnedAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


def config(episode_id: str) -> DuelEpisodeConfig:
    budget = Budget(compute_units=120, memory_units=100, observation_units=30, action_units=120)
    return DuelEpisodeConfig(
        episode_id=episode_id,
        seed=1,
        agent_baselines={"agent://signaler": "B2", "agent://receiver": "B4L"},
        budgets={"agent://signaler": budget, "agent://receiver": budget},
        profile_names={"agent://signaler": "balanced", "agent://receiver": "balanced"},
    )


def test_duel_runner_writes_meta_learning_and_experience_artifacts_and_hashes_them(tmp_path: Path):
    world = LatentContextSignalDuelWorld()
    model = ExperienceMetaValueModel()
    agents = {
        world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER),
        world.RECEIVER: B4LMetaLearnedAgent(world.RECEIVER, model=model, training=True),
    }
    cops = {agent_id: COP_PRESETS["balanced"] for agent_id in agents}
    episode_id = "episode://v07/replay/1"
    run_duel_episode(world, agents, config(episode_id), tmp_path, cops)

    meta_path = tmp_path / "meta_learning.jsonl"
    exp_path = tmp_path / "meta_experiences.jsonl"
    assert meta_path.exists()
    assert exp_path.exists()

    experiences = [json.loads(line) for line in exp_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert experiences
    assert all(row["episode_id"] == episode_id for row in experiences)
    forbidden = {"true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"}
    assert all(forbidden.isdisjoint(row["features"]) for row in experiences)

    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    for name in ("meta_learning.jsonl", "meta_experiences.jsonl"):
        assert name in manifest["artifact_hashes"]
        actual = hashlib.sha256((tmp_path / name).read_bytes()).hexdigest()
        assert actual == manifest["artifact_hashes"][name]


def test_ordinary_b4_does_not_emit_empty_meta_learning_artifacts(tmp_path: Path):
    world = LatentContextSignalDuelWorld()
    agents = {
        world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER),
        world.RECEIVER: B4APSCAdaptiveCOPAgent(world.RECEIVER),
    }
    cops = {agent_id: COP_PRESETS["balanced"] for agent_id in agents}
    cfg = config("episode://v07/replay/b4")
    cfg = DuelEpisodeConfig(
        episode_id=cfg.episode_id,
        seed=cfg.seed,
        agent_baselines={"agent://signaler": "B2", "agent://receiver": "B4"},
        budgets=cfg.budgets,
        profile_names=cfg.profile_names,
    )
    run_duel_episode(world, agents, cfg, tmp_path, cops)

    assert not (tmp_path / "meta_learning.jsonl").exists()
    assert not (tmp_path / "meta_experiences.jsonl").exists()
    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "meta_learning.jsonl" not in manifest["artifact_hashes"]
    assert "meta_experiences.jsonl" not in manifest["artifact_hashes"]
