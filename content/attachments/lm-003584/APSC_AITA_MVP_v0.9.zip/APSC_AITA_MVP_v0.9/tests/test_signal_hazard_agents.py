from apsc.budget import Budget
from aita.agents import (
    B0NeuralDirectAgent,
    B1FixedDepthAgent,
    B2FixedSearchVerifyAgent,
    B3APSCFixedCOPAgent,
    B4APSCAdaptiveCOPAgent,
)
from aita.benchmark import COP_PRESETS
from aita.protocol import ObservationResult
from aita.worlds.signal_hazard import SignalHazardWorld


def _budget() -> Budget:
    return Budget(compute_units=30, observation_units=12, action_units=12)


def _state(round_index: int = 0, feedback=None):
    return {
        "world_kind": "signal_hazard",
        "round_index": round_index,
        "rounds_total": 8,
        "routes": ["FAST", "SAFE"],
        "source_claims": {"sensor://field": 0.70, "advisor://deceptive": 0.90},
        "feedback": feedback,
        "terminal": False,
    }


def test_b0_signal_hazard_commits_fast_without_observing():
    agent = B0NeuralDirectAgent("agent://A")
    agent.reset(COP_PRESETS["balanced"])
    decision = agent.decide(_state(), _budget())
    assert decision.query is None
    assert decision.action == {"type": "choose", "route": "FAST"}


def test_b1_uses_field_sensor_and_b2_uses_declared_high_advisor():
    b1 = B1FixedDepthAgent("agent://A")
    b2 = B2FixedSearchVerifyAgent("agent://A")
    b1.reset(COP_PRESETS["balanced"])
    b2.reset(COP_PRESETS["balanced"])
    assert b1.decide(_state(), _budget()).query == {"type": "signal", "source": "sensor://field"}
    assert b2.decide(_state(), _budget()).query == {"type": "signal", "source": "advisor://deceptive"}


def test_b3_uses_declared_reliability_and_initially_selects_advisor():
    agent = B3APSCFixedCOPAgent("agent://A")
    agent.reset(COP_PRESETS["high_risk_assurance"])
    decision = agent.decide(_state(), _budget())
    assert decision.query == {"type": "signal", "source": "advisor://deceptive"}


def test_b4_calibration_lowers_deceptive_trust_updates_mvc_and_changes_source():
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    agent.reset(COP_PRESETS["high_risk_assurance"])
    first = agent.decide(_state(), _budget())
    assert first.query == {"type": "signal", "source": "advisor://deceptive"}

    agent.ingest_observation(
        ObservationResult(
            "obs://advisor/0",
            "agent://A",
            {"round_index": 0, "signal": "FAST_CATASTROPHIC"},
            0.90,
            Budget(observation_units=1),
            source_id="advisor://deceptive",
        )
    )
    feedback = {
        "round_index": 0,
        "truth": "FAST_SAFE",
        "signals": {"advisor://deceptive": "FAST_CATASTROPHIC"},
        "correctness": {"advisor://deceptive": False},
        "chosen_route": "SAFE",
        "utility": 0.65,
    }
    second = agent.decide(_state(round_index=1, feedback=feedback), _budget())
    assert second.query == {"type": "signal", "source": "sensor://field"}
    snapshot = agent.calibration_snapshot()
    advisor = snapshot["reliability"]["advisor://deceptive"]
    assert advisor["estimated_reliability"] < advisor["declared_reliability"]
    assert snapshot["mvc"]["observe:advisor://deceptive"]["count"] == 1
    assert snapshot["last_selected_source"] == "sensor://field"


def test_b4_uses_current_signal_to_choose_route_after_observation():
    world = SignalHazardWorld(rounds=2)
    state = world.reset(2)
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    agent.reset(COP_PRESETS["high_risk_assurance"])
    query = agent.decide(state, _budget()).query
    assert query is not None
    obs = world.observe("agent://A", query)
    agent.ingest_observation(obs)
    decision = agent.decide(state, _budget())
    assert decision.action is not None
    assert decision.action["route"] in {"FAST", "SAFE"}
