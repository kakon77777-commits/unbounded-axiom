from __future__ import annotations

from pathlib import Path

from aita.acceptance import validate_v09_evidence
from aita.benchmark import run_cross_world_meta_generalization_experiment


def tiny_spec() -> dict:
    return {
        "profile": "balanced",
        "budget": {"compute_units": 120, "memory_units": 100, "observation_units": 30, "action_units": 120},
        "observation_penalty": 0.15,
        "counterfactual_weight": 0.5,
        "backoff_strength": 1.0,
        "signal_train_seeds": [1, 2],
        "signal_eval_seeds": [101],
        "latent_train_seeds": [1, 2],
        "latent_eval_seeds": [101],
        "latent_train_signaler_baselines": ["B2"],
        "latent_eval_signaler_baselines": ["B2"],
        "latent_behavior_coverage_floor": 1,
        "latent_behavior_uncertainty_bonus": 0.35,
    }


def test_v09_acceptance_gates_all_pass_on_tiny_cross_world_experiment(tmp_path: Path):
    one = tmp_path / "one"
    two = tmp_path / "two"
    run_cross_world_meta_generalization_experiment(tiny_spec(), one)
    run_cross_world_meta_generalization_experiment(tiny_spec(), two)
    gates = validate_v09_evidence(
        experiment_dir=one,
        repeat_experiment_dir=two,
        backward_compatibility_passed=True,
    )
    assert set(gates) == {f"V9-{letter}" for letter in "ABCDEFGHIJK"}
    assert all(row["status"] == "PASS" for row in gates.values()), gates
