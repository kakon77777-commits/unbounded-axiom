from __future__ import annotations

from pathlib import Path

from aita.acceptance import validate_v07_evidence
from aita.benchmark import run_meta_learning_experiment


def spec():
    return {
        "world": "LatentContextSignalDuel-v0.6",
        "train_signaler_baselines": ["B2"],
        "train_seeds": [1, 2, 3, 4],
        "eval_signaler_baselines": ["B2"],
        "eval_seeds": [101, 102],
        "profile": "balanced",
        "budget": {
            "compute_units": 120,
            "memory_units": 100,
            "observation_units": 30,
            "action_units": 120,
            "external_units": 0,
            "wall_ms": 0,
            "risk_ceiling": 0,
        },
    }


def test_v07_acceptance_passes_on_rebuilt_deterministic_experiment(tmp_path: Path):
    first = tmp_path / "first"
    repeat = tmp_path / "repeat"
    run_meta_learning_experiment(spec(), first)
    run_meta_learning_experiment(spec(), repeat)

    gates = validate_v07_evidence(
        experiment_dir=first,
        repeat_experiment_dir=repeat,
        backward_compatibility_passed=True,
    )
    assert set(gates) == {f"V7-{letter}" for letter in "ABCDEFGHI"}
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates
