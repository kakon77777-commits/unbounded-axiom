from __future__ import annotations

import json
from pathlib import Path

import pytest

from aita.benchmark import run_meta_learning_experiment
from aita.cli import main


def tiny_spec():
    return {
        "world": "LatentContextSignalDuel-v0.6",
        "train_signaler_baselines": ["B2"],
        "train_seeds": [1, 2, 3, 4],
        "eval_signaler_baselines": ["B2"],
        "eval_seeds": [101, 102],
        "profile": "balanced",
        "budget": {
            "compute_units": 120,
            "memory_units": 100,
            "observation_units": 30,
            "action_units": 120,
            "external_units": 0,
            "wall_ms": 0,
            "risk_ceiling": 0,
        },
    }


def test_meta_learning_experiment_rejects_overlapping_train_eval_seeds(tmp_path: Path):
    spec = tiny_spec()
    spec["eval_seeds"] = [4, 101]
    with pytest.raises(ValueError, match="disjoint"):
        run_meta_learning_experiment(spec, tmp_path)


def test_meta_learning_experiment_trains_persists_and_freezes_model(tmp_path: Path):
    report = run_meta_learning_experiment(tiny_spec(), tmp_path)

    assert (tmp_path / "meta_model.json").exists()
    assert (tmp_path / "training_experiences.jsonl").exists()
    training = json.loads((tmp_path / "meta_training_report.json").read_text(encoding="utf-8"))
    evaluation = json.loads((tmp_path / "meta_eval_report.json").read_text(encoding="utf-8"))
    model = json.loads((tmp_path / "meta_model.json").read_text(encoding="utf-8"))

    assert training["training_episode_count"] == 4
    assert training["experience_count"] > 0
    assert model["actions"]
    assert evaluation["model_hash_before_eval"] == training["model_hash"]
    assert evaluation["model_hash_after_eval"] == training["model_hash"]
    assert report["model_hash_before_eval"] == report["model_hash_after_eval"]


def test_meta_learning_eval_pairs_b4_and_b4l_on_same_world_seed(tmp_path: Path):
    report = run_meta_learning_experiment(tiny_spec(), tmp_path)
    rows = report["eval_rows"]
    assert len(rows) == 2
    for row in rows:
        assert row["b4_initial_world_hash"] == row["b4l_initial_world_hash"]
        assert "b4_task_utility" in row
        assert "b4l_task_utility" in row
        assert "b4_cognitive_efficiency" in row
        assert "b4l_cognitive_efficiency" in row
        assert "b4_field_checks" in row
        assert "b4l_field_checks" in row
        assert isinstance(row["trajectory_diverged"], bool)
    assert (tmp_path / "meta_eval_result_per_seed.jsonl").exists()


def test_cli_meta_learn_runs_spec(tmp_path: Path):
    spec_path = tmp_path / "spec.json"
    spec_path.write_text(json.dumps(tiny_spec()), encoding="utf-8")
    output = tmp_path / "out"
    assert main(["meta-learn", str(spec_path), "--output", str(output)]) == 0
    payload = json.loads((output / "meta_eval_report.json").read_text(encoding="utf-8"))
    assert payload["row_count"] == 2


def test_reference_v07_spec_uses_disjoint_48_train_and_16_eval_pairs():
    spec = json.loads(Path("examples/benchmark_v0.7_meta_learning.json").read_text(encoding="utf-8"))
    assert set(spec["train_seeds"]).isdisjoint(spec["eval_seeds"])
    assert len(spec["train_signaler_baselines"]) * len(spec["train_seeds"]) == 48
    assert len(spec["eval_signaler_baselines"]) * len(spec["eval_seeds"]) == 16
