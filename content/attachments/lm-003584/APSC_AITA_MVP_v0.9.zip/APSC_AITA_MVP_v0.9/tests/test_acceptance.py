import json
from pathlib import Path

import pytest

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.acceptance import validate_run
from aita.agents import B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent
from aita.cli import main
from aita.protocol import EpisodeConfig
from aita.runner import run_episode
from aita.scoring import CANONICAL_METRICS
from aita.worlds.hidden_route import HiddenRouteWorld


def test_b2_fixed_search_probes_all_local_options_before_acting():
    agent = B2FixedSearchVerifyAgent("agent://A")
    agent.reset(CognitiveOperatingProfile())
    state = {"location": "S", "neighbors": ["A", "B"], "goal": "G", "tick": 0, "deadline": 5, "hazard_hits": 0, "travel_cost": 0}
    first = agent.decide(state, Budget(compute_units=10, action_units=5, observation_units=5))
    assert first.query == {"type": "probe", "target": "A"}


def test_golden_b4_run_passes_applicable_acceptance_gates(tmp_path: Path):
    world = HiddenRouteWorld(deadline=6)
    agent = B4APSCAdaptiveCOPAgent("agent://A")
    config = EpisodeConfig("episode://golden-b4", 0, "B4", Budget(compute_units=30, action_units=10, observation_units=10), "balanced")
    result = run_episode(world, agent, config, tmp_path / "run", CognitiveOperatingProfile())
    gates = validate_run(result.output_dir)
    for gate in ("A", "C", "F", "G", "K"):
        assert gates[gate]["status"] == "PASS", (gate, gates[gate])
    profiles = [json.loads(line) for line in (result.output_dir / "profiles.jsonl").read_text(encoding="utf-8").splitlines()]
    assert any(row.get("source") == "adaptive" for row in profiles)


def test_hidden_state_and_illegal_action_fail_closed():
    world = HiddenRouteWorld()
    public = world.reset(1)
    assert "hazards" not in public
    with pytest.raises(ValueError):
        world.step({"agent://A": {"type": "move", "target": "G"}})


def test_cli_run_and_replay_smoke(tmp_path: Path, capsys):
    out = tmp_path / "cli-run"
    assert main(["run", "--world", "HiddenRoute-v0.1", "--baseline", "B0", "--seed", "42", "--output", str(out)]) == 0
    assert (out / "replay_manifest.json").exists()
    assert main(["replay", str(out)]) == 0
    printed = capsys.readouterr().out
    assert "replay" in printed.lower()


def test_score_file_has_all_canonical_metrics(tmp_path: Path):
    out = tmp_path / "run"
    main(["run", "--world", "LimitedVerifier-v0.1", "--baseline", "B1", "--seed", "42", "--output", str(out)])
    score = json.loads((out / "score.json").read_text(encoding="utf-8"))
    assert set(CANONICAL_METRICS) <= set(score)
