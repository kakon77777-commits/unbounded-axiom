from __future__ import annotations

from apsc.budget import Budget
from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel, MetaStateFeatures
from aita.agents import B4APSCAdaptiveCOPAgent, B4LMetaLearnedAgent
from aita.benchmark import COP_PRESETS, AGENT_FACTORIES


def receiver_state(*, phase="RESPONSE", signal="FAST_SAFE", round_index=0, feedback=None):
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "receiver",
        "phase": phase,
        "round_index": round_index,
        "rounds_total": 8,
        "opponent_signal": signal if phase == "RESPONSE" else None,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
        "terminal": False,
    }


def dummy_features():
    return MetaStateFeatures.from_mapping({
        "belief_aligned": 0.5,
        "belief_competitive": 0.5,
        "belief_entropy": 1.0,
        "effective_signal_trust": 0.8,
        "effective_field_trust": 0.7,
        "handcrafted_trust_mvc": 0.0,
        "handcrafted_field_mvc": 0.0,
        "round_fraction": 0.0,
        "observation_available": True,
        "signal_is_catastrophic": False,
    })


def feedback(round_index=0, *, utility=1.0):
    return {
        "round_index": round_index,
        "truth": "FAST_SAFE",
        "signal_claim": "FAST_SAFE",
        "signal_correct": True,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": utility,
        "signaler_utility": utility,
        "avoidable_receiver_loss": 0.0,
    }


def test_b4l_is_registered_and_empty_model_matches_handcrafted_b4():
    assert AGENT_FACTORIES["B4L"] is B4LMetaLearnedAgent
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    b4 = B4APSCAdaptiveCOPAgent("agent://receiver")
    b4l = B4LMetaLearnedAgent("agent://receiver", model=ExperienceMetaValueModel(), training=False)
    for agent in (b4, b4l):
        agent.reset(COP_PRESETS["balanced"])
    expected = b4.decide(receiver_state(), budget)
    actual = b4l.decide(receiver_state(), budget)
    assert (actual.cognition_operator, actual.query, actual.action) == (
        expected.cognition_operator,
        expected.query,
        expected.action,
    )


def test_b4l_training_updates_pending_experience_on_next_feedback():
    model = ExperienceMetaValueModel()
    agent = B4LMetaLearnedAgent("agent://receiver", model=model, training=True)
    agent.set_episode_id("episode://train/1")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)

    first = agent.decide(receiver_state(), budget)
    chosen = "observe_field" if first.query is not None else "trust_signal"
    assert model.total_experiences() == 0

    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback()), budget)
    assert model.evidence_count(chosen) == 1
    log = agent.meta_experience_log()
    assert len(log) == 1
    assert log[0]["episode_id"] == "episode://train/1"
    assert log[0]["operation"] == chosen


def test_b4l_frozen_evaluation_logs_but_does_not_update_model():
    model = ExperienceMetaValueModel()
    agent = B4LMetaLearnedAgent("agent://receiver", model=model, training=False)
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    agent.decide(receiver_state(), budget)
    before = model.model_hash()
    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback()), budget)
    assert model.model_hash() == before
    assert len(agent.meta_experience_log()) == 1


def test_b4l_reset_preserves_injected_model_but_clears_episode_pending_state():
    model = ExperienceMetaValueModel()
    model.update(CognitiveExperience("exp://1", "ep://1", 0, "trust_signal", dummy_features(), 0.4, 0.0))
    agent = B4LMetaLearnedAgent("agent://receiver", model=model, training=True)
    before = model.model_hash()
    agent.reset(COP_PRESETS["balanced"])
    agent.decide(receiver_state(), Budget(compute_units=30, observation_units=10, action_units=20))
    agent.reset(COP_PRESETS["balanced"])
    assert agent.meta_model is model
    assert agent.meta_model.model_hash() == before
    assert agent.meta_experience_log() == []


def test_b4l_cannot_observe_when_observation_budget_is_zero_even_if_model_prefers_it():
    model = ExperienceMetaValueModel()
    f = dummy_features()
    for i in range(3):
        model.update(CognitiveExperience(f"exp://o/{i}", "ep://x", i, "observe_field", f, 10.0, 0.15))
        model.update(CognitiveExperience(f"exp://t/{i}", "ep://x", i, "trust_signal", f, -10.0, 0.0))
    agent = B4LMetaLearnedAgent("agent://receiver", model=model, training=False)
    agent.reset(COP_PRESETS["balanced"])
    decision = agent.decide(receiver_state(), Budget(compute_units=30, observation_units=0, action_units=20))
    assert decision.query is None
    assert decision.action is not None
    assert agent.meta_learning_snapshot()["last_selected_operation"] == "trust_signal"


def test_learned_global_values_can_flip_handcrafted_routing():
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    handcrafted = B4APSCAdaptiveCOPAgent("agent://receiver")
    handcrafted.reset(COP_PRESETS["balanced"])
    hand = handcrafted.decide(receiver_state(), budget)
    hand_op = "observe_field" if hand.query is not None else "trust_signal"
    opposite = "trust_signal" if hand_op == "observe_field" else "observe_field"

    model = ExperienceMetaValueModel()
    f = dummy_features()
    for i in range(4):
        model.update(CognitiveExperience(f"exp://hi/{i}", "ep://x", i, opposite, f, 5.0, 0.15 if opposite == "observe_field" else 0.0))
        model.update(CognitiveExperience(f"exp://lo/{i}", "ep://x", i, hand_op, f, -5.0, 0.15 if hand_op == "observe_field" else 0.0))

    learned = B4LMetaLearnedAgent("agent://receiver", model=model, training=False)
    learned.reset(COP_PRESETS["balanced"])
    decision = learned.decide(receiver_state(), budget)
    learned_op = "observe_field" if decision.query is not None else "trust_signal"
    assert learned_op == opposite
