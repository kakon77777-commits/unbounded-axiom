from apsc.budget import Budget
from aita.agents import (
    B0NeuralDirectAgent,
    B1FixedDepthAgent,
    B2FixedSearchVerifyAgent,
    B3APSCFixedCOPAgent,
    B4APSCAdaptiveCOPAgent,
)
from aita.benchmark import COP_PRESETS
from aita.protocol import ObservationResult


def receiver_state(*, phase="RESPONSE", signal="FAST_SAFE", round_index=0, feedback=None):
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "receiver",
        "phase": phase,
        "round_index": round_index,
        "rounds_total": 8,
        "opponent_signal": signal if phase == "RESPONSE" else None,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": feedback,
        "terminal": False,
    }


def signaler_state(*, incentive="COMPETITIVE", truth="FAST_CATASTROPHIC"):
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "signaler",
        "phase": "SIGNAL",
        "round_index": 0,
        "rounds_total": 8,
        "current_truth": truth,
        "own_incentive": incentive,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": None,
        "terminal": False,
    }


def test_b0_through_b3_are_protocol_compatible_without_context_key():
    budget = Budget(compute_units=20, observation_units=10, action_units=20)
    for cls in (B0NeuralDirectAgent, B1FixedDepthAgent, B2FixedSearchVerifyAgent, B3APSCFixedCOPAgent):
        agent = cls("agent://receiver")
        agent.reset(COP_PRESETS["balanced"])
        decision = agent.decide(receiver_state(), budget)
        assert decision.action is not None or decision.query is not None


def test_b2_and_b4_signaler_use_private_own_incentive_not_public_context():
    budget = Budget(compute_units=20, observation_units=10, action_units=20)
    for cls in (B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent):
        agent = cls("agent://signaler")
        agent.reset(COP_PRESETS["balanced"])
        aligned = agent.decide(signaler_state(incentive="ALIGNED"), budget)
        competitive = agent.decide(signaler_state(incentive="COMPETITIVE"), budget)
        assert aligned.action == {"type": "send_signal", "claim": "FAST_CATASTROPHIC"}
        assert competitive.action == {"type": "send_signal", "claim": "FAST_SAFE"}


def test_b4_starts_with_uncertain_latent_context_belief():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    snap = agent.latent_context_snapshot()
    assert snap["belief"]["belief"] == {"ALIGNED": 0.5, "COMPETITIVE": 0.5}
    assert "true_context" not in snap


def test_b4_competitive_feedback_shifts_belief_without_context_label():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    feedback = {
        "round_index": 0,
        "truth": "FAST_CATASTROPHIC",
        "signal_claim": "FAST_SAFE",
        "signal_correct": False,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": -2.5,
        "signaler_utility": 3.15,
        "avoidable_receiver_loss": 3.15,
    }
    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=feedback), budget)
    belief = agent.latent_context_snapshot()["belief"]["belief"]
    assert belief["COMPETITIVE"] > belief["ALIGNED"]


def test_b4_aligned_feedback_can_shift_belief_back_toward_aligned():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    competitive = {
        "round_index": 0,
        "truth": "FAST_CATASTROPHIC",
        "signal_claim": "FAST_SAFE",
        "signal_correct": False,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": -2.5,
        "signaler_utility": 3.15,
        "avoidable_receiver_loss": 3.15,
    }
    aligned = {
        "round_index": 1,
        "truth": "FAST_SAFE",
        "signal_claim": "FAST_SAFE",
        "signal_correct": True,
        "field_signal": None,
        "field_correct": None,
        "receiver_route": "FAST",
        "receiver_utility": 1.0,
        "signaler_utility": 1.0,
        "avoidable_receiver_loss": 0.0,
    }
    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=1, feedback=competitive), budget)
    before = agent.latent_context_snapshot()["belief"]["belief"]["ALIGNED"]
    agent.decide(receiver_state(phase="SIGNAL", signal=None, round_index=2, feedback=aligned), budget)
    after = agent.latent_context_snapshot()["belief"]["belief"]["ALIGNED"]
    assert after > before


def test_b4_field_signal_mismatch_updates_current_context_belief():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    state = receiver_state(signal="FAST_SAFE", round_index=0)
    agent.ingest_observation(ObservationResult(
        observation_id="obs://field/current",
        agent_id="agent://receiver",
        payload={"round_index": 0, "signal": "FAST_CATASTROPHIC"},
        reliability=0.95,
        cost=Budget(observation_units=1),
        source_id="sensor://field",
    ))
    agent.decide(state, budget)
    belief = agent.latent_context_snapshot()["belief"]["belief"]
    assert belief["COMPETITIVE"] > 0.5


def test_b4_latent_snapshot_exposes_belief_weighted_trust_and_mvc():
    agent = B4APSCAdaptiveCOPAgent("agent://receiver")
    agent.reset(COP_PRESETS["balanced"])
    budget = Budget(compute_units=30, observation_units=10, action_units=20)
    agent.decide(receiver_state(signal="FAST_SAFE"), budget)
    snap = agent.latent_context_snapshot()
    assert 0.0 <= snap["effective_signal_trust"] <= 1.0
    assert 0.0 <= snap["effective_field_trust"] <= 1.0
    assert isinstance(snap["trust_signal_mvc"], float)
    assert isinstance(snap["observe_field_mvc"], float)
    assert snap["last_selected_path"] in {"trust_signal", "observe_field"}
