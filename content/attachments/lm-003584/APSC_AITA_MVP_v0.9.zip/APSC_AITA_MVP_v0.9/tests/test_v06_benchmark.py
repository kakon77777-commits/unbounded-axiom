import json
from pathlib import Path

from aita.benchmark import run_latent_context_signal_matrix
from aita.cli import main


def tiny_spec():
    return {
        "world": "LatentContextSignalDuel-v0.6",
        "signaler_baselines": ["B2"],
        "receiver_baselines": ["B4"],
        "signaler_profile": "balanced",
        "receiver_profile": "balanced",
        "budgets": {
            "medium": {
                "compute_units": 120,
                "memory_units": 100,
                "observation_units": 30,
                "action_units": 120,
                "external_units": 0,
                "wall_ms": 0,
                "risk_ceiling": 0,
            }
        },
        "seeds": [1, 2],
    }


def test_latent_context_matrix_keeps_fixed_asymmetric_roles_and_metric_prefixes(tmp_path: Path):
    report = run_latent_context_signal_matrix(tiny_spec(), tmp_path)
    assert len(report.rows) == 2
    for row in report.rows:
        assert row["world"] == "LatentContextSignalDuel-v0.6"
        assert row["signaler_baseline"] == "B2"
        assert row["receiver_baseline"] == "B4"
        assert "role_orientation" not in row
        assert "signaler_task_utility" in row
        assert "receiver_task_utility" in row
        episode = json.loads((tmp_path / row["run_dir"] / "episode.json").read_text())
        assert set(episode["baselines"]) == {"agent://signaler", "agent://receiver"}
    assert (tmp_path / "latent_result_per_seed.jsonl").exists()
    assert (tmp_path / "latent_benchmark_report.json").exists()


def test_reference_spec_declares_96_episode_matrix():
    spec = json.loads(Path("examples/benchmark_v0.6_latent_context.json").read_text())
    expected = len(spec["signaler_baselines"]) * len(spec["receiver_baselines"]) * len(spec["seeds"]) * len(spec["budgets"])
    assert expected == 96


def test_cli_latent_signal_matrix_runs_spec(tmp_path: Path):
    spec_path = tmp_path / "spec.json"
    spec_path.write_text(json.dumps(tiny_spec()), encoding="utf-8")
    output = tmp_path / "out"
    assert main(["latent-signal-matrix", str(spec_path), "--output", str(output)]) == 0
    payload = json.loads((output / "latent_benchmark_report.json").read_text())
    assert payload["row_count"] == 2
