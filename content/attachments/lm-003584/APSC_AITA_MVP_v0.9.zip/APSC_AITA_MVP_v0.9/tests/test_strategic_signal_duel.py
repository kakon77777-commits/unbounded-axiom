import pytest

from aita.worlds.strategic_signal_duel import StrategicSignalDuelWorld


def test_reset_is_deterministic_and_roles_see_different_truth_access():
    first = StrategicSignalDuelWorld(rounds=4)
    second = StrategicSignalDuelWorld(rounds=4)
    first.reset(7)
    second.reset(7)

    assert first.export_replay_state() == second.export_replay_state()
    signaler = first.get_public_state(first.SIGNALER)
    receiver = first.get_public_state(first.RECEIVER)
    assert signaler["current_truth"] in {"FAST_SAFE", "FAST_CATASTROPHIC"}
    assert "current_truth" not in receiver
    assert "current_signal_correct" not in receiver


def test_signal_phase_publishes_claim_then_response_phase():
    world = StrategicSignalDuelWorld(rounds=2)
    world.reset(1)
    truth = world.get_public_state(world.SIGNALER)["current_truth"]

    state = world.step({
        world.SIGNALER: {"type": "send_signal", "claim": truth},
        world.RECEIVER: {"type": "wait"},
    })

    assert state[world.RECEIVER]["phase"] == "RESPONSE"
    assert state[world.RECEIVER]["opponent_signal"] == truth


def test_receiver_field_observation_is_noisy_bounded_and_does_not_advance_round():
    world = StrategicSignalDuelWorld(rounds=2)
    world.reset(1)
    truth = world.get_public_state(world.SIGNALER)["current_truth"]
    world.step({world.SIGNALER: {"type": "send_signal", "claim": truth}, world.RECEIVER: {"type": "wait"}})

    observation = world.observe(world.RECEIVER, {"type": "signal", "source": world.FIELD})
    assert observation.source_id == world.FIELD
    assert observation.reliability == world.FIELD_DECLARED_RELIABILITY
    assert observation.payload["round_index"] == 0
    assert observation.payload["context"] in {"ALIGNED", "COMPETITIVE"}
    assert world.get_public_state(world.RECEIVER)["round_index"] == 0

    with pytest.raises(ValueError):
        world.observe(world.RECEIVER, {"type": "signal", "source": world.FIELD})


def test_receiver_action_reveals_feedback_only_after_resolution():
    world = StrategicSignalDuelWorld(rounds=2)
    world.reset(2)
    truth = world.get_public_state(world.SIGNALER)["current_truth"]
    false_claim = "FAST_SAFE" if truth == "FAST_CATASTROPHIC" else "FAST_CATASTROPHIC"
    world.step({world.SIGNALER: {"type": "send_signal", "claim": false_claim}, world.RECEIVER: {"type": "wait"}})

    state = world.step({world.SIGNALER: {"type": "wait"}, world.RECEIVER: {"type": "choose", "route": "SAFE"}})
    feedback = state[world.RECEIVER]["feedback"]
    assert feedback["truth"] == truth
    assert feedback["signal_claim"] == false_claim
    assert feedback["signal_correct"] is False
    assert state[world.RECEIVER]["round_index"] == 1
    assert state[world.RECEIVER]["phase"] == "SIGNAL"


def test_competitive_deception_can_create_signaler_utility_and_deception_metric():
    world = StrategicSignalDuelWorld(rounds=1)
    # Find deterministic seed whose first round is competitive + catastrophic.
    seed = next(
        seed for seed in range(1, 20)
        if (lambda w: (w.reset(seed), w.get_public_state(w.SIGNALER))[1])(StrategicSignalDuelWorld(rounds=1))["context"] == "COMPETITIVE"
        and StrategicSignalDuelWorld(rounds=1)._truth_for_seed(seed, 0) == "FAST_CATASTROPHIC"
    )
    world.reset(seed)
    world.step({world.SIGNALER: {"type": "send_signal", "claim": "FAST_SAFE"}, world.RECEIVER: {"type": "wait"}})
    world.step({world.SIGNALER: {"type": "wait"}, world.RECEIVER: {"type": "choose", "route": "FAST"}})
    scores = world.score_state()

    assert scores[world.SIGNALER]["strategic_deception_count"] == 1
    assert scores[world.SIGNALER]["deception_success_count"] == 1
    assert scores[world.SIGNALER]["utility"] > 0
    assert scores[world.RECEIVER]["avoidable_receiver_loss"] > 0
