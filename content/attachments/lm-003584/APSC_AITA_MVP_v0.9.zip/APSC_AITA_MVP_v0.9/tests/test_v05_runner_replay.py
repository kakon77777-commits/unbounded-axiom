import json
from pathlib import Path

from apsc.budget import Budget
from aita.agents import B1FixedDepthAgent, B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.strategic_signal_duel import StrategicSignalDuelWorld


def budget():
    return Budget(compute_units=100, observation_units=30, action_units=100, memory_units=100)


def config(signaler="B2", receiver="B4"):
    return DuelEpisodeConfig(
        episode_id="episode://v05/replay",
        seed=1,
        agent_baselines={"agent://signaler": signaler, "agent://receiver": receiver},
        budgets={"agent://signaler": budget(), "agent://receiver": budget()},
        profile_names={"agent://signaler": "balanced", "agent://receiver": "balanced"},
        max_cycles=128,
    )


def test_duel_runner_writes_deception_evidence_and_hashes_it(tmp_path: Path):
    agents = {
        "agent://signaler": B2FixedSearchVerifyAgent("agent://signaler"),
        "agent://receiver": B4APSCAdaptiveCOPAgent("agent://receiver"),
    }
    run_duel_episode(
        StrategicSignalDuelWorld(rounds=4),
        agents,
        config(),
        tmp_path,
        {"agent://signaler": COP_PRESETS["balanced"], "agent://receiver": COP_PRESETS["balanced"]},
    )

    evidence = tmp_path / "deception.jsonl"
    assert evidence.exists()
    rows = [json.loads(line) for line in evidence.read_text().splitlines() if line.strip()]
    assert rows
    assert any(row["agent_id"] == "agent://receiver" for row in rows)
    receiver_rows = [row for row in rows if row["agent_id"] == "agent://receiver"]
    assert any(row["snapshot"]["feedback_count"] > 0 for row in receiver_rows)
    assert any(row["snapshot"]["reliability"]["contexts"] for row in receiver_rows)

    manifest = json.loads((tmp_path / "replay_manifest.json").read_text())
    assert "deception.jsonl" in manifest["artifact_hashes"]


def test_duel_runner_does_not_emit_empty_deception_artifact_for_noncapable_agents(tmp_path: Path):
    agents = {
        "agent://signaler": B1FixedDepthAgent("agent://signaler"),
        "agent://receiver": B1FixedDepthAgent("agent://receiver"),
    }
    run_duel_episode(
        StrategicSignalDuelWorld(rounds=2),
        agents,
        config("B1", "B1"),
        tmp_path,
        {"agent://signaler": COP_PRESETS["balanced"], "agent://receiver": COP_PRESETS["balanced"]},
    )

    assert not (tmp_path / "deception.jsonl").exists()
    manifest = json.loads((tmp_path / "replay_manifest.json").read_text())
    assert "deception.jsonl" not in manifest["artifact_hashes"]
