import json
from pathlib import Path

from apsc.budget import Budget
from aita.acceptance import validate_v05_evidence
from aita.agents import B2FixedSearchVerifyAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.strategic_signal_duel import StrategicSignalDuelWorld


def budget():
    return Budget(compute_units=200, observation_units=40, action_units=200, memory_units=100)


def test_v05_release_gates_pass_on_real_strategic_signaling_evidence(tmp_path: Path):
    matrix = tmp_path / "matrix"
    run_dir = matrix / "StrategicSignalDuel-v0.5" / "B2-B4" / "seed-1"
    b = budget()
    config = DuelEpisodeConfig(
        episode_id="episode://v05/acceptance/1",
        seed=1,
        agent_baselines={"agent://signaler": "B2", "agent://receiver": "B4"},
        budgets={"agent://signaler": b, "agent://receiver": b},
        profile_names={"agent://signaler": "balanced", "agent://receiver": "balanced"},
        max_cycles=128,
    )
    result = run_duel_episode(
        StrategicSignalDuelWorld(rounds=8),
        {
            "agent://signaler": B2FixedSearchVerifyAgent("agent://signaler"),
            "agent://receiver": B4APSCAdaptiveCOPAgent("agent://receiver"),
        },
        config,
        run_dir,
        {"agent://signaler": COP_PRESETS["balanced"], "agent://receiver": COP_PRESETS["balanced"]},
    )

    row = {
        "world": "StrategicSignalDuel-v0.5",
        "signaler_baseline": "B2",
        "receiver_baseline": "B4",
        "seed": 1,
        "run_dir": str(run_dir.relative_to(matrix)),
        **{f"signaler_{k}": v for k, v in result.scores["agent://signaler"].items()},
        **{f"receiver_{k}": v for k, v in result.scores["agent://receiver"].items()},
    }
    matrix.mkdir(parents=True, exist_ok=True)
    (matrix / "strategic_result_per_seed.jsonl").write_text(json.dumps(row) + "\n")

    gates = validate_v05_evidence(
        strategic_matrix_dir=matrix,
        detailed_receiver_run_dir=run_dir,
        backward_compatibility_passed=True,
    )

    assert set(gates) == {f"V5-{letter}" for letter in "ABCDEFGH"}
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates


def test_v05_truth_does_not_leak_to_receiver_reset_or_pre_action_state(tmp_path: Path):
    run_dir = tmp_path / "run"
    b = budget()
    run_duel_episode(
        StrategicSignalDuelWorld(rounds=2),
        {
            "agent://signaler": B2FixedSearchVerifyAgent("agent://signaler"),
            "agent://receiver": B4APSCAdaptiveCOPAgent("agent://receiver"),
        },
        DuelEpisodeConfig(
            episode_id="episode://v05/no-leak",
            seed=2,
            agent_baselines={"agent://signaler": "B2", "agent://receiver": "B4"},
            budgets={"agent://signaler": b, "agent://receiver": b},
            profile_names={"agent://signaler": "balanced", "agent://receiver": "balanced"},
            max_cycles=64,
        ),
        run_dir,
        {"agent://signaler": COP_PRESETS["balanced"], "agent://receiver": COP_PRESETS["balanced"]},
    )
    events = [json.loads(line) for line in (run_dir / "events.jsonl").read_text().splitlines()]
    reset = events[0]["payload"]["public_state"]["agent://receiver"]
    assert "current_truth" not in reset
    assert "current_signal_correct" not in reset
