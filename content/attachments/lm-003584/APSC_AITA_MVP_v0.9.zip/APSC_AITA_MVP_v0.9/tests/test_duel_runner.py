import json
from pathlib import Path

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.agents import B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.hidden_route_duel import HiddenRouteDuelWorld


def read_jsonl(path: Path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def test_duel_runner_tracks_separate_budgets_private_observations_and_replay(tmp_path):
    world = HiddenRouteDuelWorld(shift_tick=2)
    agents = {
        "agent://A": B3APSCFixedCOPAgent("agent://A"),
        "agent://B": B4APSCAdaptiveCOPAgent("agent://B"),
    }
    budget = Budget(compute_units=20, observation_units=6, action_units=10)
    config = DuelEpisodeConfig(
        episode_id="episode://duel/test",
        seed=5,
        agent_baselines={"agent://A": "B3", "agent://B": "B4"},
        budgets={"agent://A": budget, "agent://B": budget},
        profile_names={"agent://A": "balanced", "agent://B": "balanced"},
        max_cycles=16,
    )
    cops = {"agent://A": CognitiveOperatingProfile(), "agent://B": CognitiveOperatingProfile()}
    result = run_duel_episode(world, agents, config, tmp_path, cops)
    assert result.status == "completed"
    assert set(result.final_budgets) == {"agent://A", "agent://B"}
    assert result.final_budgets["agent://A"].compute_units < budget.compute_units
    assert result.final_budgets["agent://B"].compute_units < budget.compute_units

    observations = read_jsonl(tmp_path / "observations.jsonl")
    assert observations
    assert all(row["agent_id"] in agents for row in observations)
    assert all("hazards" not in row["payload"] for row in observations)

    actions = read_jsonl(tmp_path / "actions.jsonl")
    assert any(set(row["action_bundle"]) == set(agents) for row in actions)

    profiles = read_jsonl(tmp_path / "profiles.jsonl")
    receipts = read_jsonl(tmp_path / "receipts.jsonl")
    assert any(row.get("agent_id") == "agent://B" and row.get("source") == "adaptive" for row in profiles)
    assert any(row.get("reason_code") == "rule_shift_trigger" for row in receipts)

    replay = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert replay["deterministic_core"] is True
    assert "actions.jsonl" in replay["artifact_hashes"]
    assert set(json.loads((tmp_path / "score.json").read_text(encoding="utf-8"))) == set(agents)
