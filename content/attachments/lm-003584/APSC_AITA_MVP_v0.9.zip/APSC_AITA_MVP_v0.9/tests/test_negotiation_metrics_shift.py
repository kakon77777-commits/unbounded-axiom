from aita.worlds.negotiation_split import NegotiationSplitWorld


def test_accepted_split_reports_joint_and_pareto_metrics():
    world = NegotiationSplitWorld(deadline=4, shift_tick=99)
    world.reset(2)
    world.step({"agent://A": {"type": "offer", "self_share": 5}, "agent://B": {"type": "wait"}})
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "accept"}})
    scores = world.score_state()
    for agent in world.AGENTS:
        assert "joint_utility" in scores[agent]
        assert "pareto_efficiency" in scores[agent]
        assert "agreement_stability" in scores[agent]
        assert "concession_cost" in scores[agent]
        assert "negotiation_regret" in scores[agent]
    assert scores["agent://A"]["joint_utility"] == scores["agent://B"]["joint_utility"]


def test_rule_shift_is_public_and_changes_disagreement_payoff():
    world = NegotiationSplitWorld(deadline=5, shift_tick=1)
    before = world.reset(7)["agent://A"]
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "wait"}})
    after = world.get_public_state("agent://A")
    assert before["rule_version"] == 1
    assert after["rule_version"] == 2
    assert after["shifted"] is True
    assert after["disagreement_payoff"] != before["disagreement_payoff"]


def test_unstable_agreement_is_marked_not_stable():
    world = NegotiationSplitWorld(deadline=4, shift_tick=99)
    states = world.reset(12)
    minimum_b = states["agent://B"]["own_minimum"]
    receiver_share = max(0, minimum_b - 1)
    world.step({
        "agent://A": {"type": "offer", "self_share": world.SURPLUS - receiver_share},
        "agent://B": {"type": "wait"},
    })
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "accept"}})
    assert world.score_state()["agent://B"]["agreement_stability"] is False


def test_timeout_reports_joint_disagreement_utility_and_regret():
    world = NegotiationSplitWorld(deadline=1, shift_tick=99)
    world.reset(4)
    world.step({"agent://A": {"type": "wait"}, "agent://B": {"type": "wait"}})
    scores = world.score_state()
    expected_joint = scores["agent://A"]["disagreement_payoff"] + scores["agent://B"]["disagreement_payoff"]
    assert scores["agent://A"]["joint_utility"] == expected_joint
    assert scores["agent://A"]["negotiation_regret"] >= 0.0
