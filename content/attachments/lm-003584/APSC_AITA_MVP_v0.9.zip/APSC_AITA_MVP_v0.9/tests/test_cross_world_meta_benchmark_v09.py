from __future__ import annotations

import json
from pathlib import Path

import pytest

from aita.benchmark import run_cross_world_meta_generalization_experiment
from aita.cli import main


def tiny_spec() -> dict:
    return {
        "profile": "balanced",
        "budget": {"compute_units": 120, "memory_units": 100, "observation_units": 30, "action_units": 120},
        "observation_penalty": 0.15,
        "counterfactual_weight": 0.5,
        "backoff_strength": 1.0,
        "signal_train_seeds": [1, 2],
        "signal_eval_seeds": [101],
        "latent_train_seeds": [1, 2],
        "latent_eval_seeds": [101],
        "latent_train_signaler_baselines": ["B2"],
        "latent_eval_signaler_baselines": ["B2"],
        "latent_behavior_coverage_floor": 1,
        "latent_behavior_uncertainty_bonus": 0.35,
    }


def test_cross_world_experiment_runs_both_directions_freezes_and_pairs(tmp_path: Path):
    report = run_cross_world_meta_generalization_experiment(tiny_spec(), tmp_path)
    assert set(report["directions"]) == {"signal_to_latent", "latent_to_signal"}

    for name, payload in report["directions"].items():
        training = payload["training_report"]
        evaluation = payload["eval_report"]
        assert set(training["train_seeds"]).isdisjoint(evaluation["eval_seeds"])
        assert evaluation["value_model_hash_before_eval"] == evaluation["value_model_hash_after_eval"]
        assert evaluation["exploration_policy_hash_before_eval"] == evaluation["exploration_policy_hash_after_eval"]
        assert payload["eval_rows"]
        for row in payload["eval_rows"]:
            assert row["b4_initial_world_hash"] == row["b4g0_initial_world_hash"] == row["b4g_initial_world_hash"]
            assert "transfer_utility_delta_b4g_minus_b4g0" in row
            assert "trajectory_diverged_b4g_vs_b4" in row

    assert (tmp_path / "cross_world_report.json").exists()
    assert (tmp_path / "signal_to_latent" / "generalized_meta_model.json").exists()
    assert (tmp_path / "latent_to_signal" / "learned_exploration_policy.json").exists()


def test_cross_world_experiment_is_byte_deterministic(tmp_path: Path):
    one = tmp_path / "one"
    two = tmp_path / "two"
    run_cross_world_meta_generalization_experiment(tiny_spec(), one)
    run_cross_world_meta_generalization_experiment(tiny_spec(), two)
    canonical = [
        "cross_world_report.json",
        "signal_to_latent/generalized_meta_model.json",
        "signal_to_latent/learned_exploration_policy.json",
        "signal_to_latent/cross_world_training_report.json",
        "signal_to_latent/cross_world_eval_report.json",
        "signal_to_latent/cross_world_eval_result_per_seed.jsonl",
        "latent_to_signal/generalized_meta_model.json",
        "latent_to_signal/learned_exploration_policy.json",
        "latent_to_signal/cross_world_training_report.json",
        "latent_to_signal/cross_world_eval_report.json",
        "latent_to_signal/cross_world_eval_result_per_seed.jsonl",
    ]
    for rel in canonical:
        assert (one / rel).read_bytes() == (two / rel).read_bytes(), rel


def test_cross_world_experiment_rejects_overlapping_train_eval_seeds(tmp_path: Path):
    spec = tiny_spec()
    spec["signal_eval_seeds"] = [2]
    with pytest.raises(ValueError, match="signal train/eval seeds"):
        run_cross_world_meta_generalization_experiment(spec, tmp_path)


def test_meta_transfer_cli_and_reference_spec(tmp_path: Path):
    spec_path = tmp_path / "spec.json"
    spec_path.write_text(json.dumps(tiny_spec()), encoding="utf-8")
    assert main(["meta-transfer", str(spec_path), "--output", str(tmp_path / "out")]) == 0
    reference = Path("examples/benchmark_v0.9_cross_world.json")
    assert reference.exists()
    payload = json.loads(reference.read_text(encoding="utf-8"))
    assert set(payload["signal_train_seeds"]).isdisjoint(payload["signal_eval_seeds"])
    assert set(payload["latent_train_seeds"]).isdisjoint(payload["latent_eval_seeds"])
