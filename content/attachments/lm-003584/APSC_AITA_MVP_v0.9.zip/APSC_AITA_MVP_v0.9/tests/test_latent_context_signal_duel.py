from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


def test_latent_context_reset_is_deterministic_and_persistent():
    first = LatentContextSignalDuelWorld(rounds=8)
    second = LatentContextSignalDuelWorld(rounds=8)
    first.reset(3)
    second.reset(3)
    assert first.export_replay_state() == second.export_replay_state()
    contexts = first.export_replay_state()["contexts"]
    assert len(contexts) == 8
    assert any(contexts[idx] == contexts[idx - 1] for idx in range(1, len(contexts)))
    assert len(set(contexts)) == 2


def test_receiver_public_state_hides_current_context_but_signaler_sees_own_incentive():
    world = LatentContextSignalDuelWorld(rounds=4)
    world.reset(1)
    receiver = world.get_public_state(world.RECEIVER)
    signaler = world.get_public_state(world.SIGNALER)
    assert receiver["world_kind"] == "latent_context_signal_duel"
    assert "context" not in receiver
    assert "own_incentive" not in receiver
    assert signaler["own_incentive"] in {"ALIGNED", "COMPETITIVE"}
    assert "context" not in signaler


def test_receiver_field_observation_hides_context_label():
    world = LatentContextSignalDuelWorld(rounds=2)
    world.reset(1)
    truth = world.get_public_state(world.SIGNALER)["current_truth"]
    world.step({world.SIGNALER: {"type": "send_signal", "claim": truth}, world.RECEIVER: {"type": "wait"}})
    observation = world.observe(world.RECEIVER, {"type": "signal", "source": world.FIELD})
    assert "context" not in observation.payload
    assert observation.payload["round_index"] == 0


def test_receiver_feedback_hides_context_but_keeps_inference_evidence():
    world = LatentContextSignalDuelWorld(rounds=2)
    world.reset(2)
    truth = world.get_public_state(world.SIGNALER)["current_truth"]
    world.step({world.SIGNALER: {"type": "send_signal", "claim": truth}, world.RECEIVER: {"type": "wait"}})
    state = world.step({world.SIGNALER: {"type": "wait"}, world.RECEIVER: {"type": "choose", "route": "FAST"}})
    feedback = state[world.RECEIVER]["feedback"]
    assert "context" not in feedback
    for key in ("truth", "signal_correct", "receiver_utility", "signaler_utility", "avoidable_receiver_loss"):
        assert key in feedback


def test_hidden_contexts_exist_only_in_replay_evidence():
    world = LatentContextSignalDuelWorld(rounds=4)
    world.reset(5)
    replay = world.export_replay_state()
    assert replay["world_id"] == "LatentContextSignalDuel-v0.6"
    assert len(replay["contexts"]) == 4
    assert "context" not in world.get_public_state(world.RECEIVER)
