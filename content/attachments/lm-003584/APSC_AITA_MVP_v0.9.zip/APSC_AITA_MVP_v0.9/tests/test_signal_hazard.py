from aita.worlds.signal_hazard import SignalHazardWorld


def test_signal_hazard_reset_is_deterministic_and_hides_current_truth_and_actual_accuracy():
    a = SignalHazardWorld(rounds=8)
    b = SignalHazardWorld(rounds=8)
    assert a.reset(3) == b.reset(3)
    assert a.export_replay_state()["regimes"] == b.export_replay_state()["regimes"]
    public = a.get_public_state()
    assert "current_regime" not in public
    assert "actual_accuracy" not in public
    assert public["source_claims"]["sensor://field"] == 0.70
    assert public["source_claims"]["advisor://deceptive"] == 0.90


def test_signal_query_returns_source_identity_and_declared_reliability():
    world = SignalHazardWorld(rounds=2)
    world.reset(2)
    field = world.observe("agent://A", {"type": "signal", "source": "sensor://field"})
    advisor = world.observe("agent://A", {"type": "signal", "source": "advisor://deceptive"})
    assert field.source_id == "sensor://field"
    assert field.reliability == 0.70
    assert advisor.source_id == "advisor://deceptive"
    assert advisor.reliability == 0.90
    assert field.payload["signal"] in {"FAST_SAFE", "FAST_CATASTROPHIC"}
    assert advisor.payload["signal"] in {"FAST_SAFE", "FAST_CATASTROPHIC"}


def test_feedback_reveals_previous_round_truth_but_not_next_round_truth():
    world = SignalHazardWorld(rounds=2)
    initial = world.reset(1)
    assert initial["feedback"] is None
    obs = world.observe("agent://A", {"type": "signal", "source": "sensor://field"})
    world.step({"agent://A": {"type": "choose", "route": "SAFE"}})
    public = world.get_public_state()
    assert public["round_index"] == 1
    assert public["feedback"]["truth"] in {"FAST_SAFE", "FAST_CATASTROPHIC"}
    assert public["feedback"]["signals"]["sensor://field"] == obs.payload["signal"]
    assert "current_regime" not in public


def test_world_runs_multiple_rounds_and_reports_source_empirical_accuracy():
    world = SignalHazardWorld(rounds=8)
    world.reset(4)
    for _ in range(8):
        world.observe("agent://A", {"type": "signal", "source": "sensor://field"})
        world.observe("agent://A", {"type": "signal", "source": "advisor://deceptive"})
        world.step({"agent://A": {"type": "choose", "route": "SAFE"}})
    assert world.is_terminal()
    score = world.score_state()
    assert score["field_sensor_accuracy"] == 0.75
    assert score["deceptive_advisor_accuracy"] == 0.25
    assert score["catastrophic_count"] == 0
    assert score["utility"] == 8 * 0.65
