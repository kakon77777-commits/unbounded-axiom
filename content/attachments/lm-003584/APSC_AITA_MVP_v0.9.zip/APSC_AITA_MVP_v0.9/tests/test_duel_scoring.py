from apsc.budget import Budget
from aita.scoring import CANONICAL_METRICS, score_duel_episode


def test_duel_scoring_marks_winner_loser_and_resource_advantage():
    raw = {
        "agent://A": {"reached_goal": True, "winner": True, "utility": 1.1, "collision_blocks": 0},
        "agent://B": {"reached_goal": False, "winner": False, "utility": 0.2, "collision_blocks": 1},
    }
    initial = {
        "agent://A": Budget(compute_units=10, observation_units=5, action_units=5),
        "agent://B": Budget(compute_units=10, observation_units=5, action_units=5),
    }
    final = {
        "agent://A": Budget(compute_units=6, observation_units=3, action_units=3),
        "agent://B": Budget(compute_units=4, observation_units=2, action_units=2),
    }
    scores = score_duel_episode(raw, initial_budgets=initial, final_budgets=final, agent_status={"agent://A": "completed", "agent://B": "completed"})
    assert scores["agent://A"]["duel_outcome"] == 1.0
    assert scores["agent://B"]["duel_outcome"] == -1.0
    assert scores["agent://A"]["resource_advantage"] > 0
    assert scores["agent://B"]["opponent_model_regret"] > scores["agent://A"]["opponent_model_regret"]
    assert scores["agent://A"]["tension_efficiency"] >= scores["agent://B"]["tension_efficiency"]
    assert set(CANONICAL_METRICS) <= set(scores["agent://A"])


def test_duel_scoring_preserves_illegal_action_compliance_penalty_and_tie():
    raw = {
        "agent://A": {"reached_goal": False, "winner": False, "utility": 0.0, "collision_blocks": 0},
        "agent://B": {"reached_goal": False, "winner": False, "utility": 0.0, "collision_blocks": 0},
    }
    initial = {agent: Budget(compute_units=5, action_units=5) for agent in raw}
    final = {agent: Budget(compute_units=4, action_units=4) for agent in raw}
    scores = score_duel_episode(raw, initial_budgets=initial, final_budgets=final, agent_status={"agent://A": "illegal_action", "agent://B": "completed"})
    assert scores["agent://A"]["duel_outcome"] == 0.0
    assert scores["agent://B"]["duel_outcome"] == 0.0
    assert scores["agent://A"]["rule_compliance"] == 0.0
    assert scores["agent://B"]["rule_compliance"] == 1.0
