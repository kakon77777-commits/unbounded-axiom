from apsc.budget import Budget
from aita.agents import B0NeuralDirectAgent, B1FixedDepthAgent, B2FixedSearchVerifyAgent, B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS
from aita.worlds.hazard_choice import HazardChoiceWorld


def _budget() -> Budget:
    return Budget(compute_units=10, observation_units=2, action_units=4)


def test_b0_hazard_choice_commits_fast_without_observing():
    world = HazardChoiceWorld()
    state = world.reset(8)
    agent = B0NeuralDirectAgent("agent://A")
    agent.reset(COP_PRESETS["balanced"])
    decision = agent.decide(state, _budget())
    assert decision.query is None
    assert decision.action == {"type": "choose", "route": "FAST"}


def test_b1_and_b2_probe_before_hazard_choice_when_budget_allows():
    world = HazardChoiceWorld()
    state = world.reset(8)
    for cls in (B1FixedDepthAgent, B2FixedSearchVerifyAgent):
        agent = cls("agent://A")
        agent.reset(COP_PRESETS["balanced"])
        decision = agent.decide(state, _budget())
        assert decision.query == {"type": "probe", "target": "route-regime"}


def test_b4_low_latency_commits_while_high_risk_probes():
    world = HazardChoiceWorld()
    state = world.reset(8)
    fast = B4APSCAdaptiveCOPAgent("agent://A")
    safe = B4APSCAdaptiveCOPAgent("agent://A")
    fast.reset(COP_PRESETS["low_latency"])
    safe.reset(COP_PRESETS["high_risk_assurance"])
    assert fast.decide(state, _budget()).action == {"type": "choose", "route": "FAST"}
    assert safe.decide(state, _budget()).query == {"type": "probe", "target": "route-regime"}


def test_b3_uses_observed_regime_to_choose_safe_route():
    world = HazardChoiceWorld()
    for seed in range(100):
        state = world.reset(seed)
        if world.export_replay_state()["regime"] == "FAST_CATASTROPHIC":
            break
    agent = B3APSCFixedCOPAgent("agent://A")
    agent.reset(COP_PRESETS["high_risk_assurance"])
    obs = world.observe("agent://A", {"type": "probe", "target": "route-regime"})
    agent.ingest_observation(obs)
    decision = agent.decide(state, _budget())
    assert decision.action == {"type": "choose", "route": "SAFE"}
