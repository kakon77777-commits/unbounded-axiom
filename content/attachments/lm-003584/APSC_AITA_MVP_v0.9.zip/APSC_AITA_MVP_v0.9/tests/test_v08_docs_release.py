from pathlib import Path
import json


def test_v080_docs_declare_exploration_offpolicy_and_uncertainty_meta_control():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.8",
        "B4X",
        "forced exploration",
        "counterfactual",
        "off-policy",
        "uncertainty",
        "coverage",
        "held-out",
        "frozen",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.8.0" in changelog


def test_v080_results_document_has_required_evidence_sections():
    text = Path("docs/V0.8_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "v0.7 collapse baseline",
        "Coverage repair",
        "Counterfactual / off-policy experience",
        "Uncertainty-aware meta-control",
        "Frozen held-out evaluation",
        "B4 vs B4X",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v080_validation_metadata_and_v07_archive_exist():
    current = json.loads(Path("docs/validation/VALIDATION_v0.8.json").read_text(encoding="utf-8"))
    assert current["version"] == "0.8.0"
    assert current["status"] == "PASS"
    v08 = current["checks"]["v08_evidence"]
    assert v08["status"] == "PASS"
    for gate in tuple(f"V8-{letter}" for letter in "ABCDEFGHIJ"):
        assert v08["gates"][gate]["status"] == "PASS"

    archived = json.loads(Path("docs/validation/VALIDATION_v0.7.json").read_text(encoding="utf-8"))
    assert archived["version"] == "0.7.0"
    assert archived["status"] == "PASS"
