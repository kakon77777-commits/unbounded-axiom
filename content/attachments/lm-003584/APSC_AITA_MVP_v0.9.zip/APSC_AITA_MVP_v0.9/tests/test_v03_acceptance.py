import json
from pathlib import Path

from apsc.budget import Budget
from aita.acceptance import validate_v03_evidence
from aita.agents import B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS, run_duel_matrix, run_matrix
from aita.cli import main
from aita.protocol import EpisodeConfig
from aita.runner import run_episode
from aita.worlds.hazard_choice import HazardChoiceWorld


ROOT = Path(__file__).resolve().parents[1]


def test_v03_example_specs_exist_and_name_new_worlds():
    hazard = json.loads((ROOT / "examples" / "benchmark_v0.3_hazard.json").read_text(encoding="utf-8"))
    negotiation = json.loads((ROOT / "examples" / "benchmark_v0.3_negotiation.json").read_text(encoding="utf-8"))
    assert hazard["worlds"] == ["HazardChoice-v0.3"]
    assert {"B0", "B4"} <= set(hazard["baselines"])
    assert hazard["profile"] == "high_risk_assurance"
    assert negotiation["world"] == "NegotiationSplit-v0.3"
    assert negotiation["role_swap"] is True
    assert any(
        row["a"] == "B4"
        and row["b"] == "B4"
        and row["profile_a"] == "low_latency"
        and row["profile_b"] == "high_risk_assurance"
        for row in negotiation["matchups"]
    )


def test_cli_accepts_v03_world_ids(tmp_path):
    hazard_dir = tmp_path / "hazard"
    assert main([
        "run", "--world", "HazardChoice-v0.3", "--baseline", "B4",
        "--profile", "high_risk_assurance", "--seed", "1", "--budget", "small",
        "--output", str(hazard_dir),
    ]) == 0

    negotiation_dir = tmp_path / "negotiation"
    assert main([
        "duel", "--world", "NegotiationSplit-v0.3",
        "--baseline-a", "B3", "--baseline-b", "B4",
        "--profile-a", "balanced", "--profile-b", "balanced",
        "--seed", "4", "--budget", "small", "--output", str(negotiation_dir),
    ]) == 0


def test_validate_v03_evidence_requires_tradeoff_shift_and_role_swap(tmp_path):
    hazard_matrix_dir = tmp_path / "hazard-matrix"
    run_matrix(
        {
            "worlds": ["HazardChoice-v0.3"],
            "baselines": ["B0", "B4"],
            "budgets": {"small": {"compute_units": 20, "observation_units": 5, "action_units": 10}},
            "seeds": list(range(1, 9)),
            "profile": "high_risk_assurance",
        },
        hazard_matrix_dir,
    )

    catastrophic_seed = None
    probe = HazardChoiceWorld()
    for seed in range(1, 100):
        probe.reset(seed)
        if probe.export_replay_state()["regime"] == "FAST_CATASTROPHIC":
            catastrophic_seed = seed
            break
    assert catastrophic_seed is not None

    low_dir = tmp_path / "hazard-low"
    high_dir = tmp_path / "hazard-high"
    budget = Budget(compute_units=20, observation_units=5, action_units=10)
    run_episode(
        HazardChoiceWorld(),
        B4APSCAdaptiveCOPAgent("agent://A"),
        EpisodeConfig("episode://v03/low", catastrophic_seed, "B4", budget, "low_latency"),
        low_dir,
        COP_PRESETS["low_latency"],
    )
    run_episode(
        HazardChoiceWorld(),
        B4APSCAdaptiveCOPAgent("agent://A"),
        EpisodeConfig("episode://v03/high", catastrophic_seed, "B4", budget, "high_risk_assurance"),
        high_dir,
        COP_PRESETS["high_risk_assurance"],
    )

    negotiation_matrix_dir = tmp_path / "negotiation-matrix"
    run_duel_matrix(
        {
            "world": "NegotiationSplit-v0.3",
            "matchups": [{"a": "B3", "b": "B4", "profile_a": "balanced", "profile_b": "balanced"}],
            "budgets": {"small": {"compute_units": 30, "observation_units": 4, "action_units": 20}},
            "seeds": list(range(1, 9)),
            "role_swap": True,
        },
        negotiation_matrix_dir,
    )

    gates = validate_v03_evidence(
        hazard_matrix_dir=hazard_matrix_dir,
        hazard_low_latency_run=low_dir,
        hazard_high_risk_run=high_dir,
        negotiation_matrix_dir=negotiation_matrix_dir,
    )
    assert gates
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates
