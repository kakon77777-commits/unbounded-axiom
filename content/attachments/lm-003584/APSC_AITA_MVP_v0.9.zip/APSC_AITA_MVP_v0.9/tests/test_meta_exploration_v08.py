from __future__ import annotations

import math

import pytest

from apsc.meta_learning import CognitiveExperience, ExperienceMetaValueModel, MetaStateFeatures


def features(**overrides):
    payload = {
        "belief_aligned": 0.5,
        "belief_competitive": 0.5,
        "belief_entropy": 1.0,
        "effective_signal_trust": 0.8,
        "effective_field_trust": 0.7,
        "handcrafted_trust_mvc": 0.1,
        "handcrafted_field_mvc": 0.2,
        "round_fraction": 0.25,
        "observation_available": True,
        "signal_is_catastrophic": False,
    }
    payload.update(overrides)
    return MetaStateFeatures.from_mapping(payload)


def exp(exp_id: str, operation: str, value: float, f: MetaStateFeatures | None = None):
    return CognitiveExperience(exp_id, "episode://v08", 0, operation, f or features(), value, 0.15 if operation == "observe_field" else 0.0)


def test_weighted_update_changes_evidence_weight_and_weighted_mean():
    model = ExperienceMetaValueModel()
    f = features()
    model.update_weighted(exp("exp://a", "trust_signal", 1.0, f), weight=1.0)
    model.update_weighted(exp("exp://b", "trust_signal", -1.0, f), weight=3.0)

    assert model.evidence_count("trust_signal") == 2
    assert model.evidence_weight("trust_signal") == pytest.approx(4.0)
    assert model.estimate("trust_signal", f) == pytest.approx(-0.5)


def test_uncertainty_is_high_for_unseen_bucket_and_falls_with_local_evidence():
    model = ExperienceMetaValueModel()
    seen = features(belief_aligned=0.8, belief_competitive=0.2)
    unseen = features(belief_aligned=0.2, belief_competitive=0.8)

    before = model.uncertainty("observe_field", unseen)
    model.update_weighted(exp("exp://o", "observe_field", 0.5, seen), weight=4.0)
    seen_u = model.uncertainty("observe_field", seen)
    unseen_u = model.uncertainty("observe_field", unseen)

    assert before == pytest.approx(1.0)
    assert seen_u < unseen_u
    assert seen_u == pytest.approx(1.0 / math.sqrt(5.0))
    assert unseen_u == pytest.approx(1.0)


def test_estimate_with_uncertainty_returns_existing_estimate_and_uncertainty():
    model = ExperienceMetaValueModel()
    f = features()
    model.update(exp("exp://t", "trust_signal", 0.75, f))
    value, uncertainty = model.estimate_with_uncertainty("trust_signal", f, fallback=-9.0)
    assert value == pytest.approx(model.estimate("trust_signal", f, fallback=-9.0))
    assert uncertainty == pytest.approx(model.uncertainty("trust_signal", f))


def test_ordinary_v07_update_serialization_remains_unchanged():
    model = ExperienceMetaValueModel(backoff_strength=2.0)
    model.update(exp("exp://compat", "trust_signal", 0.25))
    payload = model.to_dict()
    assert set(payload) == {"model_type", "backoff_strength", "actions"}
    assert payload["model_type"] == "experience-meta-value-v0.7"
    assert set(payload["actions"]["trust_signal"]["global"]) == {"count", "weight", "mean"}


def test_meta_training_experience_validates_source_kind_and_serializes_public_features():
    from apsc.meta_exploration import MetaTrainingExperience

    base = exp("exp://env", "trust_signal", 0.5)
    row = MetaTrainingExperience(
        experience=base,
        source_kind="forced_exploration",
        sample_weight=1.0,
        behavior_operation="trust_signal",
        selection_reason="coverage_floor",
    )
    payload = row.to_dict()
    assert payload["source_kind"] == "forced_exploration"
    assert payload["features"] == base.features.to_dict()
    assert "true_context" not in payload["features"]

    with pytest.raises(ValueError, match="source_kind"):
        MetaTrainingExperience(base, "invented", 1.0, "trust_signal", "bad")


def test_selector_enforces_per_episode_coverage_floor_deterministically():
    from apsc.meta_exploration import UncertaintyAwareMetaSelector

    selector = UncertaintyAwareMetaSelector(coverage_floor=2, uncertainty_bonus=0.5)
    values = {"trust_signal": 10.0, "observe_field": -10.0}
    uncertainties = {"trust_signal": 0.1, "observe_field": 1.0}

    first = selector.select(
        learned_values=values,
        uncertainties=uncertainties,
        episode_counts={"trust_signal": 0, "observe_field": 0},
        feasible_operations={"trust_signal", "observe_field"},
        training=True,
        round_index=0,
    )
    second = selector.select(
        learned_values=values,
        uncertainties=uncertainties,
        episode_counts={"trust_signal": 1, "observe_field": 0},
        feasible_operations={"trust_signal", "observe_field"},
        training=True,
        round_index=1,
    )
    assert first.selected_operation == "trust_signal"
    assert second.selected_operation == "observe_field"
    assert first.selection_reason == second.selection_reason == "coverage_floor"


def test_selector_uses_uncertainty_bonus_after_coverage_floor():
    from apsc.meta_exploration import UncertaintyAwareMetaSelector

    selector = UncertaintyAwareMetaSelector(coverage_floor=1, uncertainty_bonus=0.6)
    selection = selector.select(
        learned_values={"trust_signal": 0.6, "observe_field": 0.4},
        uncertainties={"trust_signal": 0.1, "observe_field": 0.8},
        episode_counts={"trust_signal": 2, "observe_field": 2},
        feasible_operations={"trust_signal", "observe_field"},
        training=True,
        round_index=4,
    )
    assert selection.greedy_operation == "trust_signal"
    assert selection.selected_operation == "observe_field"
    assert selection.selection_reason == "uncertainty_ucb"
    assert selection.rank_scores["observe_field"] > selection.rank_scores["trust_signal"]


def test_selector_never_selects_infeasible_observation():
    from apsc.meta_exploration import UncertaintyAwareMetaSelector

    selector = UncertaintyAwareMetaSelector(coverage_floor=5, uncertainty_bonus=9.0)
    selection = selector.select(
        learned_values={"trust_signal": -100.0, "observe_field": 100.0},
        uncertainties={"trust_signal": 0.0, "observe_field": 1.0},
        episode_counts={"trust_signal": 0, "observe_field": 0},
        feasible_operations={"trust_signal"},
        training=True,
        round_index=0,
    )
    assert selection.selected_operation == "trust_signal"
    assert set(selection.rank_scores) == {"trust_signal"}


def test_selector_is_deterministic_on_equal_frozen_scores():
    from apsc.meta_exploration import UncertaintyAwareMetaSelector

    selector = UncertaintyAwareMetaSelector(coverage_floor=0, uncertainty_bonus=0.0)
    kwargs = dict(
        learned_values={"trust_signal": 0.5, "observe_field": 0.5},
        uncertainties={"trust_signal": 1.0, "observe_field": 1.0},
        episode_counts={"trust_signal": 0, "observe_field": 0},
        feasible_operations={"trust_signal", "observe_field"},
        training=False,
        round_index=3,
    )
    assert selector.select(**kwargs) == selector.select(**kwargs)
    assert selector.select(**kwargs).selected_operation == "trust_signal"
