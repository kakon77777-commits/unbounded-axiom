from pathlib import Path
import json


def test_v040_docs_declare_noisy_deceptive_calibration_and_nonuniversality():
    readme = Path("README.md").read_text(encoding="utf-8")
    changelog = Path("CHANGELOG.md").read_text(encoding="utf-8")
    for required in (
        "MVP v0.4",
        "SignalHazard-v0.4",
        "noisy observation",
        "deceptive advisor",
        "declared reliability",
        "calibrated reliability",
        "estimated MVC",
        "task-specific calibration",
        "not a universal ranking",
    ):
        assert required in readme
    assert "0.4.0" in changelog


def test_v040_results_document_has_required_evidence_sections():
    text = Path("docs/V0.4_RESULTS.md").read_text(encoding="utf-8")
    for required in (
        "SignalHazard-v0.4",
        "Source accuracy",
        "Reliability calibration",
        "Source-selection shift",
        "Estimated MVC",
        "Replay integrity",
        "Limitations",
    ):
        assert required in text


def test_v040_validation_metadata_declares_calibration_evidence():
    payload = json.loads(Path("docs/validation/VALIDATION_v0.4.json").read_text(encoding="utf-8"))
    assert payload["version"] == "0.4.0"
    assert payload["status"] == "PASS"
    v04 = payload["checks"]["v04_evidence"]
    assert v04["status"] == "PASS"
    assert v04["source_accuracy_divergence"] == "PASS"
    assert v04["reliability_calibration"] == "PASS"
    assert v04["source_selection_shift"] == "PASS"
    assert v04["estimated_mvc"] == "PASS"
    assert v04["replay_integrity"] == "PASS"
