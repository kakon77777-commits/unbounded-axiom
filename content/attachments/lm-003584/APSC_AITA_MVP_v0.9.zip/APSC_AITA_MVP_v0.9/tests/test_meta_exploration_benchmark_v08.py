from __future__ import annotations

import json
from pathlib import Path

import pytest

from aita.cli import main


def tiny_spec():
    return {
        "world": "LatentContextSignalDuel-v0.6",
        "train_signaler_baselines": ["B2"],
        "train_seeds": [1, 2, 3, 4],
        "eval_signaler_baselines": ["B2"],
        "eval_seeds": [101, 102],
        "profile": "balanced",
        "observation_penalty": 0.15,
        "counterfactual_weight": 0.5,
        "coverage_floor": 1,
        "train_uncertainty_bonus": 0.35,
        "eval_uncertainty_bonus": 0.15,
        "budget": {
            "compute_units": 120,
            "memory_units": 100,
            "observation_units": 30,
            "action_units": 120,
            "external_units": 0,
            "wall_ms": 0,
            "risk_ceiling": 0,
        },
    }


def test_exploration_experiment_rejects_overlapping_train_eval_seeds(tmp_path: Path):
    from aita.benchmark import run_exploration_meta_learning_experiment

    spec = tiny_spec()
    spec["eval_seeds"] = [4, 101]
    with pytest.raises(ValueError, match="disjoint"):
        run_exploration_meta_learning_experiment(spec, tmp_path)


def test_exploration_experiment_builds_actual_and_counterfactual_training_coverage(tmp_path: Path):
    from aita.benchmark import run_exploration_meta_learning_experiment

    report = run_exploration_meta_learning_experiment(tiny_spec(), tmp_path)
    training = json.loads((tmp_path / "exploration_training_report.json").read_text(encoding="utf-8"))
    rows = [json.loads(line) for line in (tmp_path / "exploration_training_experiences.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]

    assert training["training_episode_count"] == 4
    assert training["actual_experience_count"] == 32
    assert training["counterfactual_experience_count"] == 32
    assert training["forced_exploration_count"] > 0
    assert training["actual_operation_counts"]["trust_signal"] > 0
    assert training["actual_operation_counts"]["observe_field"] > 0
    assert training["counterfactual_operation_counts"]["trust_signal"] > 0
    assert training["counterfactual_operation_counts"]["observe_field"] > 0
    assert training["actual_coverage_ratio"] <= 4.0
    assert training["weighted_evidence"]["trust_signal"] > 0
    assert training["weighted_evidence"]["observe_field"] > 0
    assert len(rows) == 64
    assert {row["source_kind"] for row in rows} >= {"forced_exploration", "counterfactual_off_policy"}
    assert report["model_hash_before_eval"] == report["model_hash_after_eval"]


def test_exploration_eval_pairs_b4_and_b4x_on_same_world_seed(tmp_path: Path):
    from aita.benchmark import run_exploration_meta_learning_experiment

    report = run_exploration_meta_learning_experiment(tiny_spec(), tmp_path)
    rows = report["eval_rows"]
    assert len(rows) == 2
    for row in rows:
        assert row["b4_initial_world_hash"] == row["b4x_initial_world_hash"]
        assert "b4_task_utility" in row
        assert "b4x_task_utility" in row
        assert "b4_cognitive_efficiency" in row
        assert "b4x_cognitive_efficiency" in row
        assert "b4_field_checks" in row
        assert "b4x_field_checks" in row
        assert isinstance(row["trajectory_diverged"], bool)
    assert (tmp_path / "exploration_eval_result_per_seed.jsonl").exists()


def test_exploration_experiment_is_byte_deterministic(tmp_path: Path):
    from aita.benchmark import run_exploration_meta_learning_experiment

    first = tmp_path / "first"
    repeat = tmp_path / "repeat"
    run_exploration_meta_learning_experiment(tiny_spec(), first)
    run_exploration_meta_learning_experiment(tiny_spec(), repeat)
    for name in (
        "exploration_meta_model.json",
        "exploration_training_report.json",
        "exploration_eval_report.json",
        "exploration_eval_result_per_seed.jsonl",
        "exploration_training_experiences.jsonl",
    ):
        assert (first / name).read_bytes() == (repeat / name).read_bytes()


def test_cli_meta_explore_runs_spec(tmp_path: Path):
    spec_path = tmp_path / "spec.json"
    spec_path.write_text(json.dumps(tiny_spec()), encoding="utf-8")
    output = tmp_path / "out"
    assert main(["meta-explore", str(spec_path), "--output", str(output)]) == 0
    payload = json.loads((output / "exploration_eval_report.json").read_text(encoding="utf-8"))
    assert payload["row_count"] == 2


def test_reference_v08_spec_uses_disjoint_48_train_and_16_eval_pairs():
    spec = json.loads(Path("examples/benchmark_v0.8_meta_exploration.json").read_text(encoding="utf-8"))
    assert set(spec["train_seeds"]).isdisjoint(spec["eval_seeds"])
    assert len(spec["train_signaler_baselines"]) * len(spec["train_seeds"]) == 48
    assert len(spec["eval_signaler_baselines"]) * len(spec["eval_seeds"]) == 16
