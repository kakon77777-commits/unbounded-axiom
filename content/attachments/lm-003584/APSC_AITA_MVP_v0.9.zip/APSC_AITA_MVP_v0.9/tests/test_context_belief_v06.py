import math

from apsc.context_belief import LatentContextBeliefTracker


def test_context_belief_starts_normalized_and_balanced():
    tracker = LatentContextBeliefTracker()
    belief = tracker.belief()
    assert belief == {"ALIGNED": 0.5, "COMPETITIVE": 0.5}
    assert math.isclose(sum(belief.values()), 1.0)
    assert math.isclose(tracker.entropy(), 1.0)


def test_competitive_feedback_increases_competitive_posterior():
    tracker = LatentContextBeliefTracker()
    posterior = tracker.update_from_feedback(
        signal_correct=False,
        receiver_utility=-2.5,
        signaler_utility=3.15,
        avoidable_loss=3.15,
    )
    assert posterior["COMPETITIVE"] > 0.8
    assert posterior["COMPETITIVE"] > posterior["ALIGNED"]


def test_aligned_feedback_increases_aligned_posterior():
    tracker = LatentContextBeliefTracker()
    posterior = tracker.update_from_feedback(
        signal_correct=True,
        receiver_utility=1.0,
        signaler_utility=1.0,
        avoidable_loss=0.0,
    )
    assert posterior["ALIGNED"] > 0.8
    assert posterior["ALIGNED"] > posterior["COMPETITIVE"]


def test_predict_next_softens_but_preserves_direction_under_persistence():
    tracker = LatentContextBeliefTracker(transition_persistence=0.75)
    tracker.update_from_feedback(
        signal_correct=False,
        receiver_utility=-2.5,
        signaler_utility=3.15,
        avoidable_loss=3.15,
    )
    before = tracker.belief()["COMPETITIVE"]
    predicted = tracker.predict_next()["COMPETITIVE"]
    assert 0.5 < predicted < before < 1.0


def test_signal_check_strength_scales_with_observer_reliability():
    weak = LatentContextBeliefTracker()
    strong = LatentContextBeliefTracker()
    weak_posterior = weak.update_from_signal_check(signal_matches=False, observer_reliability=0.55)
    strong_posterior = strong.update_from_signal_check(signal_matches=False, observer_reliability=0.95)
    assert strong_posterior["COMPETITIVE"] > weak_posterior["COMPETITIVE"] > 0.5


def test_snapshot_exposes_only_belief_state_not_hidden_label():
    tracker = LatentContextBeliefTracker()
    tracker.update_from_signal_check(signal_matches=True, observer_reliability=0.8)
    snap = tracker.snapshot()
    assert set(snap["belief"]) == {"ALIGNED", "COMPETITIVE"}
    assert "true_context" not in snap
    assert snap["signal_checks"] == 1
