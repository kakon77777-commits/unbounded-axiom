from apsc.budget import Budget
from apsc.reliability import SourceReliabilityTracker
from aita.protocol import ObservationResult


def test_reliability_prior_starts_at_declared_value():
    tracker = SourceReliabilityTracker(prior_strength=2.0)
    assert tracker.estimate("advisor://x", 0.9) == 0.9


def test_repeated_incorrect_feedback_lowers_reliability():
    tracker = SourceReliabilityTracker(prior_strength=2.0)
    for _ in range(4):
        tracker.record("advisor://x", 0.9, correct=False)
    assert tracker.estimate("advisor://x", 0.9) < 0.5
    assert tracker.snapshot()["advisor://x"]["failures"] == 4


def test_repeated_correct_feedback_raises_reliability():
    tracker = SourceReliabilityTracker(prior_strength=2.0)
    for _ in range(4):
        tracker.record("sensor://x", 0.6, correct=True)
    assert tracker.estimate("sensor://x", 0.6) > 0.8
    assert tracker.calibration_error("sensor://x", 0.6) >= 0.0


def test_observation_result_source_id_is_backward_compatible():
    old_style = ObservationResult("obs://1", "agent://A", {"x": 1}, 0.8, Budget())
    assert old_style.source_id == "source://unknown"
    named = ObservationResult("obs://2", "agent://A", {"x": 1}, 0.8, Budget(), source_id="sensor://field")
    assert named.source_id == "sensor://field"
