from __future__ import annotations

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from apsc.meta_exploration_policy import ExplorationPolicyExperience, ExplorationPolicyFeatures, LearnedExplorationPolicyModel
from apsc.meta_generalization import CrossWorldMetaValueModel, GeneralizedCognitiveExperience
from aita.agents import B4APSCAdaptiveCOPAgent
from aita.meta_generalization import project_signal_hazard_features


def signal_state():
    return {
        "world_kind": "signal_hazard",
        "round_index": 0,
        "rounds_total": 8,
        "source_claims": {"advisor://deceptive": 0.9, "sensor://field": 0.7},
        "feedback": None,
        "terminal": False,
    }


def latent_state(signal="FAST_SAFE"):
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "receiver",
        "phase": "RESPONSE",
        "round_index": 0,
        "rounds_total": 8,
        "opponent_signal": signal,
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": None,
        "terminal": False,
    }


def category(decision):
    if decision.query is not None:
        return "query"
    if decision.action is not None:
        return "action"
    return "none"


def test_b4g_is_registered():
    from aita.agents import B4GGeneralizingMetaAgent
    from aita.benchmark import AGENT_FACTORIES

    assert AGENT_FACTORIES["B4G"] is B4GGeneralizingMetaAgent


def test_b4g_empty_models_match_b4_signal_hazard_and_latent_context():
    from aita.agents import B4GGeneralizingMetaAgent

    cop = CognitiveOperatingProfile()
    budget = Budget(compute_units=30, observation_units=10, action_units=30)
    for state in (signal_state(), latent_state()):
        b4 = B4APSCAdaptiveCOPAgent("agent://A" if state["world_kind"] == "signal_hazard" else "agent://receiver")
        b4g = B4GGeneralizingMetaAgent(
            b4.agent_id,
            value_model=CrossWorldMetaValueModel(),
            exploration_policy=LearnedExplorationPolicyModel(),
        )
        b4.reset(cop)
        b4g.reset(cop)
        assert category(b4.decide(state, budget)) == category(b4g.decide(state, budget))


def test_b4g_learned_exploration_can_override_signal_hazard_greedy_choice():
    from aita.agents import B4GGeneralizingMetaAgent

    budget = Budget(compute_units=30, observation_units=10, action_units=30)
    features = project_signal_hazard_features(
        signal_state(), budget,
        primary_trust=0.9, verifier_trust=0.7,
        primary_value_prior=0.0, verify_value_prior=0.0,
        primary_signal=None, verifier_signal=None,
    )
    value_model = CrossWorldMetaValueModel()
    value_model.update(GeneralizedCognitiveExperience(
        "gx://trust", "ep://train", 0, "SignalHazard-v0.4", "trust_primary", features,
        0.8, 0.15, 0.0, "on_policy"
    ))
    value_model.update(GeneralizedCognitiveExperience(
        "gx://verify", "ep://train", 0, "SignalHazard-v0.4", "verify_independent", features,
        0.6, 0.15, 0.0, "on_policy"
    ))
    policy_features = ExplorationPolicyFeatures.from_mapping({
        "state_uncertainty": features.uncertainty,
        "value_gap": 0.2,
        "uncertainty_gap": 0.0,
        "observation_cost_fraction": features.observation_cost_fraction,
    })
    policy = LearnedExplorationPolicyModel()
    policy.update(ExplorationPolicyExperience(
        "px://1", policy_features, "trust_primary", "verify_independent", 1.0, 0.0
    ))

    agent = B4GGeneralizingMetaAgent("agent://A", value_model=value_model, exploration_policy=policy)
    agent.reset(CognitiveOperatingProfile())
    decision = agent.decide(signal_state(), budget)
    assert decision.query == {"type": "signal", "source": "sensor://field"}
    snapshot = agent.meta_generalization_snapshot()
    assert snapshot["greedy_operation"] == "trust_primary"
    assert snapshot["selected_operation"] == "verify_independent"
    assert snapshot["selection_reason"] == "learned_exploration"


def test_b4g_budget_zero_cannot_query_even_when_models_prefer_verify():
    from aita.agents import B4GGeneralizingMetaAgent

    model = CrossWorldMetaValueModel()
    policy = LearnedExplorationPolicyModel()
    agent = B4GGeneralizingMetaAgent("agent://A", value_model=model, exploration_policy=policy)
    agent.reset(CognitiveOperatingProfile())
    decision = agent.decide(signal_state(), Budget(compute_units=30, observation_units=0, action_units=30))
    assert decision.query is None
    assert decision.action is not None
