from __future__ import annotations

from pathlib import Path

import pytest


def feature_payload(**overrides):
    payload = {
        "uncertainty": 0.5,
        "primary_trust": 0.8,
        "verifier_trust": 0.7,
        "primary_value_prior": 0.2,
        "verify_value_prior": 0.1,
        "progress_fraction": 0.25,
        "observation_available": True,
        "risk_if_wrong": 0.9,
        "evidence_conflict": False,
        "observation_cost_fraction": 0.1,
    }
    payload.update(overrides)
    return payload


def test_generalized_features_reject_hidden_or_world_identity_keys():
    from apsc.meta_generalization import GeneralizedCognitiveFeatures

    for forbidden in ("world_id", "world_kind", "hidden_context", "current_truth", "oracle_action"):
        payload = feature_payload(**{forbidden: "forbidden"})
        with pytest.raises(ValueError):
            GeneralizedCognitiveFeatures.from_mapping(payload)


def test_generalized_bucket_is_world_neutral():
    from apsc.meta_generalization import GeneralizedCognitiveExperience, GeneralizedCognitiveFeatures

    features = GeneralizedCognitiveFeatures.from_mapping(feature_payload())
    a = GeneralizedCognitiveExperience(
        experience_id="gx://a",
        episode_id="episode://a",
        round_index=0,
        source_world="SignalHazard-v0.4",
        operation="trust_primary",
        features=features,
        realized_value=1.0,
        observation_cost=0.0,
        target_uncertainty=0.0,
        evidence_kind="on_policy",
    )
    b = GeneralizedCognitiveExperience(
        experience_id="gx://b",
        episode_id="episode://b",
        round_index=0,
        source_world="LatentContextSignalDuel-v0.6",
        operation="trust_primary",
        features=features,
        realized_value=1.0,
        observation_cost=0.0,
        target_uncertainty=0.0,
        evidence_kind="on_policy",
    )
    assert a.features.bucket_key() == b.features.bucket_key()
    assert "SignalHazard" not in a.features.bucket_key()
    assert "LatentContext" not in a.features.bucket_key()


def test_target_uncertainty_reduces_effective_evidence_weight():
    from apsc.meta_generalization import CrossWorldMetaValueModel, GeneralizedCognitiveExperience, GeneralizedCognitiveFeatures

    features = GeneralizedCognitiveFeatures.from_mapping(feature_payload())
    model = CrossWorldMetaValueModel(min_target_weight=0.1)
    certain = GeneralizedCognitiveExperience(
        "gx://certain", "episode://1", 0, "SignalHazard-v0.4", "trust_primary", features,
        1.0, 0.0, 0.0, "on_policy"
    )
    uncertain = GeneralizedCognitiveExperience(
        "gx://uncertain", "episode://2", 0, "SignalHazard-v0.4", "trust_primary", features,
        -1.0, 0.0, 0.8, "counterfactual"
    )
    model.update(certain, sample_weight=1.0)
    model.update(uncertain, sample_weight=1.0)
    assert model.evidence_weight("trust_primary") == pytest.approx(1.2)
    prediction = model.predict("trust_primary", features)
    assert prediction.expected_value > 0.5
    assert 0.0 <= prediction.target_uncertainty <= 1.0
    assert 0.0 <= prediction.combined_uncertainty <= 1.0


def test_generalized_model_backoff_and_roundtrip_hash(tmp_path: Path):
    from apsc.meta_generalization import CrossWorldMetaValueModel, GeneralizedCognitiveExperience, GeneralizedCognitiveFeatures

    f_train = GeneralizedCognitiveFeatures.from_mapping(feature_payload(primary_trust=0.9))
    f_other = GeneralizedCognitiveFeatures.from_mapping(feature_payload(primary_trust=0.1))
    model = CrossWorldMetaValueModel(backoff_strength=2.0)
    model.update(GeneralizedCognitiveExperience(
        "gx://1", "episode://1", 0, "SignalHazard-v0.4", "verify_independent", f_train,
        0.6, 0.15, 0.0, "on_policy"
    ))
    pred = model.predict("verify_independent", f_other, fallback=-0.2)
    assert pred.expected_value == pytest.approx(0.6)
    path = tmp_path / "generalized_model.json"
    model.save(path)
    loaded = CrossWorldMetaValueModel.load(path)
    assert loaded.to_dict() == model.to_dict()
    assert loaded.model_hash() == model.model_hash()
