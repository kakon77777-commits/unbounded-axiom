import pytest

from apsc.budget import Budget, InsufficientBudget
from apsc.cop import AdaptiveRegion, CognitiveOperatingProfile
from apsc.models import ObservationRecord, StateSnapshot, PossibilityNode


def test_budget_charge_is_monotone_and_returns_new_budget():
    before = Budget(wall_ms=100, compute_units=10, memory_units=8, observation_units=3, action_units=2, external_units=1)
    after = before.charge(Budget(wall_ms=10, compute_units=2, memory_units=1, observation_units=1, action_units=0, external_units=0))
    assert after.compute_units == 8
    assert after.wall_ms == 90
    assert before.compute_units == 10


def test_budget_rejects_overcharge():
    before = Budget(compute_units=1)
    with pytest.raises(InsufficientBudget):
        before.charge(Budget(compute_units=2))


def test_cop_projects_into_adaptive_region():
    cop = CognitiveOperatingProfile(depth=1.2, verification=-0.1, risk=0.9)
    region = AdaptiveRegion(minimum={"depth": 0.2, "verification": 0.4}, maximum={"depth": 0.8, "verification": 0.9})
    projected = cop.project(region)
    assert projected.depth == 0.8
    assert projected.verification == 0.4
    assert projected.risk == 0.9


def test_state_objects_have_stable_identifiers_and_parent_version():
    obs = ObservationRecord.create(source="world", payload={"x": 1}, reliability=1.0)
    state = StateSnapshot.create(payload={"x": 1}, observation_ids=(obs.observation_id,))
    node = PossibilityNode.create(state_ref=state.state_id, horizon=1, resolution="near")
    assert obs.observation_id.startswith("obs://")
    assert state.state_id.startswith("state://")
    assert state.version == 0
    assert state.parent_state_id is None
    assert node.node_id.startswith("poss://")
