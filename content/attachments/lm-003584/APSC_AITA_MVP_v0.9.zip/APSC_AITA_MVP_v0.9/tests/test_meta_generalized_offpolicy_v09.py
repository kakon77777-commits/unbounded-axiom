from __future__ import annotations

from pathlib import Path


def _by_round(rows):
    grouped = {}
    for row in rows:
        grouped.setdefault(row.round_index, []).append(row)
    return grouped


def test_signal_hazard_builder_creates_actual_and_counterfactual_rows():
    from aita.meta_generalized_offpolicy import build_signal_hazard_generalized_experiences

    run_dir = Path("examples/reference_v0.4_calibration_seed_1")
    rows = build_signal_hazard_generalized_experiences(run_dir, observation_penalty=0.15)
    assert len(rows) == 16
    assert {row.operation for row in rows} == {"trust_primary", "verify_independent"}
    assert {row.evidence_kind for row in rows} == {"on_policy", "counterfactual"}
    grouped = _by_round(rows)
    assert all(len(pair) == 2 for pair in grouped.values())
    for pair in grouped.values():
        actual = next(row for row in pair if row.evidence_kind == "on_policy")
        cf = next(row for row in pair if row.evidence_kind == "counterfactual")
        assert actual.features == cf.features
        assert actual.operation != cf.operation
        assert actual.target_uncertainty == 0.0
        assert cf.target_uncertainty > 0.0
        assert "truth" not in cf.features.to_dict()
        assert "world" not in cf.features.to_dict()


def test_latent_builder_reuses_action_time_features_and_marks_counterfactual_uncertainty():
    from aita.meta_generalized_offpolicy import build_latent_context_generalized_experiences

    run_dir = Path("reference_v0.8_meta_exploration/train/signaler-B2/seed-1")
    rows = build_latent_context_generalized_experiences(run_dir, observation_penalty=0.15)
    assert len(rows) == 16
    assert {row.operation for row in rows} == {"trust_primary", "verify_independent"}
    grouped = _by_round(rows)
    for pair in grouped.values():
        assert len(pair) == 2
        actual = next(row for row in pair if row.evidence_kind == "on_policy")
        cf = next(row for row in pair if row.evidence_kind == "counterfactual")
        assert actual.features == cf.features
        assert cf.target_uncertainty > actual.target_uncertainty
        assert 0.0 <= cf.target_uncertainty <= 1.0


def test_counterfactual_target_uncertainty_is_higher_for_noisy_verifier_alternate():
    from aita.meta_generalized_offpolicy import build_signal_hazard_generalized_experiences

    rows = build_signal_hazard_generalized_experiences(
        Path("examples/reference_v0.4_calibration_seed_1"), observation_penalty=0.15
    )
    cf_by_operation = {row.operation: row.target_uncertainty for row in rows if row.evidence_kind == "counterfactual"}
    assert cf_by_operation["verify_independent"] > cf_by_operation["trust_primary"]
