import pytest

from aita.worlds.hidden_route import HiddenRouteWorld


def test_hidden_route_reset_is_deterministic_and_public_state_hides_hazards():
    a = HiddenRouteWorld(deadline=5)
    b = HiddenRouteWorld(deadline=5)
    public_a = a.reset(42)
    public_b = b.reset(42)
    assert public_a == public_b
    assert a.export_replay_state()["hazards"] == b.export_replay_state()["hazards"]
    assert "hazards" not in public_a


def test_probe_reveals_only_requested_node_and_has_cost():
    world = HiddenRouteWorld(deadline=5)
    world.reset(42)
    result = world.observe("agent://A", {"type": "probe", "target": "A"})
    assert result.payload["target"] == "A"
    assert set(result.payload) == {"target", "hazard"}
    assert result.cost.observation_units == 1


def test_legal_move_updates_location_and_illegal_move_fails_closed():
    world = HiddenRouteWorld(deadline=5)
    state = world.reset(42)
    legal = world.legal_actions("agent://A")
    destinations = {a["target"] for a in legal if a["type"] == "move"}
    assert destinations == {"A", "B"}
    target = sorted(destinations)[0]
    world.step({"agent://A": {"type": "move", "target": target}})
    assert world.get_public_state()["location"] == target
    with pytest.raises(ValueError):
        world.step({"agent://A": {"type": "move", "target": "S"}})


def test_deadline_terminates_episode_and_score_is_deterministic():
    a = HiddenRouteWorld(deadline=2)
    b = HiddenRouteWorld(deadline=2)
    a.reset(7)
    b.reset(7)
    for world in (a, b):
        world.step({"agent://A": {"type": "wait"}})
        world.step({"agent://A": {"type": "wait"}})
        assert world.is_terminal() is True
    assert a.score_state() == b.score_state()
    assert a.score_state()["reached_goal"] is False


def test_public_state_exposes_topology_and_known_safe_rules_but_not_hazards():
    world = HiddenRouteWorld(deadline=5)
    public = world.reset(0)
    assert public["topology"]["B"] == ["C", "G"]
    assert "G" in public["known_safe"]
    assert "hazards" not in public
