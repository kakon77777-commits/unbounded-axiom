from apsc.budget import Budget
from aita.agents import B0NeuralDirectAgent, B1FixedDepthAgent, B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.benchmark import COP_PRESETS
from aita.worlds.negotiation_split import NegotiationSplitWorld


def _budget() -> Budget:
    return Budget(compute_units=20, observation_units=4, action_units=10)


def _state(seed: int = 11):
    world = NegotiationSplitWorld(deadline=5, shift_tick=99)
    return world.reset(seed)["agent://A"]


def test_b0_negotiation_starts_with_aggressive_offer():
    agent = B0NeuralDirectAgent("agent://A")
    agent.reset(COP_PRESETS["balanced"])
    decision = agent.decide(_state(), _budget())
    assert decision.action == {"type": "offer", "self_share": 7}


def test_b1_accepts_offer_at_or_above_own_minimum():
    state = _state()
    state["outstanding_offer"] = {
        "proposer": "agent://B",
        "receiver": "agent://A",
        "proposer_share": 10 - state["own_minimum"],
        "receiver_share": state["own_minimum"],
        "tick": 0,
    }
    agent = B1FixedDepthAgent("agent://A")
    agent.reset(COP_PRESETS["balanced"])
    assert agent.decide(state, _budget()).action == {"type": "accept"}


def test_b4_low_latency_and_high_risk_make_different_first_offers():
    state = _state()
    low = B4APSCAdaptiveCOPAgent("agent://A")
    high = B4APSCAdaptiveCOPAgent("agent://A")
    low.reset(COP_PRESETS["low_latency"])
    high.reset(COP_PRESETS["high_risk_assurance"])
    low_decision = low.decide(state, _budget())
    high_decision = high.decide(state, _budget())
    assert low_decision.action["type"] == "offer"
    assert high_decision.action["type"] == "offer"
    assert low_decision.action["self_share"] != high_decision.action["self_share"]


def test_b4_rule_shift_creates_receipt_and_changes_offer_while_b3_has_no_receipt():
    before = _state()
    shifted = dict(before)
    shifted.update({"rule_version": 2, "shifted": True, "disagreement_payoff": 2.0})

    b3 = B3APSCFixedCOPAgent("agent://A")
    b4 = B4APSCAdaptiveCOPAgent("agent://A")
    b3.reset(COP_PRESETS["balanced"])
    b4.reset(COP_PRESETS["balanced"])

    first_b4 = b4.decide(before, _budget())
    shifted_b3 = b3.decide(shifted, _budget())
    shifted_b4 = b4.decide(shifted, _budget())

    assert shifted_b3.profile_receipt is None
    assert shifted_b4.profile_receipt is not None
    assert shifted_b4.profile_receipt.reason_code == "rule_shift_trigger"
    assert shifted_b4.action["type"] == "offer"
    assert shifted_b4.action["self_share"] != first_b4.action["self_share"]
