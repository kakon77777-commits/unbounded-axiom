from __future__ import annotations

import hashlib
import json
from pathlib import Path

from apsc.budget import Budget
from apsc.meta_learning import ExperienceMetaValueModel
from aita.agents import B2FixedSearchVerifyAgent, B4LMetaLearnedAgent, B4XExplorationMetaAgent
from aita.benchmark import COP_PRESETS
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.latent_context_signal_duel import LatentContextSignalDuelWorld


def cfg(receiver: str) -> DuelEpisodeConfig:
    budget = Budget(compute_units=120, memory_units=100, observation_units=30, action_units=120)
    return DuelEpisodeConfig(
        episode_id=f"episode://v08/replay/{receiver}",
        seed=1,
        agent_baselines={"agent://signaler": "B2", "agent://receiver": receiver},
        budgets={"agent://signaler": budget, "agent://receiver": budget},
        profile_names={"agent://signaler": "balanced", "agent://receiver": "balanced"},
    )


def run(receiver_agent, receiver_name: str, output: Path):
    world = LatentContextSignalDuelWorld()
    agents = {
        world.SIGNALER: B2FixedSearchVerifyAgent(world.SIGNALER),
        world.RECEIVER: receiver_agent,
    }
    cops = {agent_id: COP_PRESETS["balanced"] for agent_id in agents}
    return run_duel_episode(world, agents, cfg(receiver_name), output, cops)


def test_b4x_runner_finalizes_last_round_and_hashes_exploration_artifact(tmp_path: Path):
    model = ExperienceMetaValueModel()
    receiver = B4XExplorationMetaAgent(
        "agent://receiver",
        model=model,
        training=True,
        coverage_floor=2,
        uncertainty_bonus=0.35,
    )
    run(receiver, "B4X", tmp_path)

    exp_rows = [json.loads(line) for line in (tmp_path / "meta_experiences.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
    receiver_rows = [row for row in exp_rows if row["agent_id"] == "agent://receiver"]
    assert len(receiver_rows) == 8

    exploration_path = tmp_path / "meta_exploration.jsonl"
    assert exploration_path.exists()
    exploration = [json.loads(line) for line in exploration_path.read_text(encoding="utf-8").splitlines() if line.strip()]
    assert exploration
    assert all(row["agent_id"] == "agent://receiver" for row in exploration)
    assert any(row["selection_reason"] == "coverage_floor" for row in exploration)
    forbidden = {"true_context", "hidden_context", "context", "current_truth", "future_truth", "oracle_action"}
    assert all(forbidden.isdisjoint(row) for row in exploration)

    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "meta_exploration.jsonl" in manifest["artifact_hashes"]
    actual = hashlib.sha256(exploration_path.read_bytes()).hexdigest()
    assert actual == manifest["artifact_hashes"]["meta_exploration.jsonl"]


def test_b4l_does_not_emit_empty_exploration_artifact(tmp_path: Path):
    receiver = B4LMetaLearnedAgent("agent://receiver", model=ExperienceMetaValueModel(), training=True)
    run(receiver, "B4L", tmp_path)
    assert not (tmp_path / "meta_exploration.jsonl").exists()
    manifest = json.loads((tmp_path / "replay_manifest.json").read_text(encoding="utf-8"))
    assert "meta_exploration.jsonl" not in manifest["artifact_hashes"]
