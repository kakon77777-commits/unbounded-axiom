from apsc.budget import Budget
from apsc.coe import ObservationCandidate, value_observation
from apsc.cop import CognitiveOperatingProfile
from apsc.value_estimator import OnlineMVCValueEstimator


def test_online_mvc_estimator_tracks_incremental_mean():
    estimator = OnlineMVCValueEstimator()
    assert estimator.estimate("observe:sensor", fallback=0.4) == 0.4
    estimator.update("observe:sensor", 1.0)
    estimator.update("observe:sensor", -0.5)
    assert estimator.count("observe:sensor") == 2
    assert estimator.estimate("observe:sensor", fallback=0.0) == 0.25
    assert estimator.snapshot()["observe:sensor"]["count"] == 2


def test_reliability_aware_coe_downranks_unreliable_observation():
    cop = CognitiveOperatingProfile(observation=0.9, counterfactual=0.8, risk=0.9)
    common = dict(
        information_gain=0.6,
        decision_value=0.9,
        risk_reduction=0.8,
        compression=0.5,
        cost=Budget(observation_units=1),
    )
    trusted = ObservationCandidate("q://trusted", **common, reliability=0.9, source_id="sensor://trusted")
    dubious = ObservationCandidate("q://dubious", **common, reliability=0.25, source_id="advisor://dubious")
    assert value_observation(trusted, cop) > value_observation(dubious, cop)


def test_old_observation_candidate_constructor_remains_valid():
    candidate = ObservationCandidate("q://old", 0.1, 0.2, 0.3, 0.4, Budget(observation_units=1))
    assert candidate.reliability == 1.0
    assert candidate.source_id == "source://unknown"
