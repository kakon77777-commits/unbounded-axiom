from __future__ import annotations

from pathlib import Path

from aita.acceptance import validate_v08_evidence
from aita.benchmark import run_exploration_meta_learning_experiment


def tiny_spec():
    return {
        "world": "LatentContextSignalDuel-v0.6",
        "train_signaler_baselines": ["B2"],
        "train_seeds": [1, 2, 3, 4],
        "eval_signaler_baselines": ["B2"],
        "eval_seeds": [101, 102],
        "profile": "balanced",
        "observation_penalty": 0.15,
        "counterfactual_weight": 0.5,
        "coverage_floor": 1,
        "train_uncertainty_bonus": 0.35,
        "eval_uncertainty_bonus": 0.15,
        "budget": {
            "compute_units": 120,
            "memory_units": 100,
            "observation_units": 30,
            "action_units": 120,
            "external_units": 0,
            "wall_ms": 0,
            "risk_ceiling": 0,
        },
    }


def test_v08_acceptance_gates_pass_for_deterministic_exploration_experiment(tmp_path: Path):
    first = tmp_path / "first"
    repeat = tmp_path / "repeat"
    run_exploration_meta_learning_experiment(tiny_spec(), first)
    run_exploration_meta_learning_experiment(tiny_spec(), repeat)

    gates = validate_v08_evidence(
        experiment_dir=first,
        repeat_experiment_dir=repeat,
        backward_compatibility_passed=True,
    )

    assert set(gates) == {f"V8-{letter}" for letter in "ABCDEFGHIJ"}
    assert all(gate["status"] == "PASS" for gate in gates.values()), gates
