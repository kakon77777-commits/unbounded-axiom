import json

from apsc.budget import Budget
from apsc.cop import CognitiveOperatingProfile
from aita.acceptance import validate_run
from aita.agents import B3APSCFixedCOPAgent, B4APSCAdaptiveCOPAgent
from aita.cli import main
from aita.protocol import DuelEpisodeConfig
from aita.runner import run_duel_episode
from aita.worlds.hidden_route_duel import HiddenRouteDuelWorld


def test_validate_run_accepts_duel_budget_profile_and_metric_traces(tmp_path):
    budget = Budget(compute_units=20, observation_units=6, action_units=10)
    config = DuelEpisodeConfig(
        episode_id="episode://acceptance/duel",
        seed=42,
        agent_baselines={"agent://A": "B3", "agent://B": "B4"},
        budgets={"agent://A": budget, "agent://B": budget},
        profile_names={"agent://A": "balanced", "agent://B": "balanced"},
    )
    run_duel_episode(
        HiddenRouteDuelWorld(shift_tick=2),
        {"agent://A": B3APSCFixedCOPAgent("agent://A"), "agent://B": B4APSCAdaptiveCOPAgent("agent://B")},
        config,
        tmp_path,
        {"agent://A": CognitiveOperatingProfile(), "agent://B": CognitiveOperatingProfile()},
    )
    gates = validate_run(tmp_path)
    for gate in ("A", "C", "F", "G", "K"):
        assert gates[gate]["status"] == "PASS", gates


def test_cli_duel_and_duel_matrix_commands(tmp_path):
    duel_dir = tmp_path / "duel"
    rc = main([
        "duel", "--world", "HiddenRouteDuel-v0.2",
        "--baseline-a", "B3", "--baseline-b", "B4",
        "--profile-a", "balanced", "--profile-b", "balanced",
        "--seed", "42", "--budget", "small", "--output", str(duel_dir),
    ])
    assert rc == 0
    score = json.loads((duel_dir / "score.json").read_text(encoding="utf-8"))
    assert set(score) == {"agent://A", "agent://B"}

    spec = {
        "world": "HiddenRouteDuel-v0.2",
        "matchups": [{"a": "B3", "b": "B4", "profile_a": "balanced", "profile_b": "balanced"}],
        "budgets": {"small": {"compute_units": 20, "observation_units": 6, "action_units": 10}},
        "seeds": [1, 2],
        "role_swap": True,
    }
    spec_path = tmp_path / "duel_spec.json"
    spec_path.write_text(json.dumps(spec), encoding="utf-8")
    matrix_dir = tmp_path / "matrix"
    rc = main(["duel-matrix", str(spec_path), "--output", str(matrix_dir)])
    assert rc == 0
    report = json.loads((matrix_dir / "duel_benchmark_report.json").read_text(encoding="utf-8"))
    assert report["row_count"] == 4
