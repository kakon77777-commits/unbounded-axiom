from __future__ import annotations

from apsc.budget import Budget


def signal_state():
    return {
        "world_kind": "signal_hazard",
        "round_index": 2,
        "rounds_total": 8,
        "source_claims": {"advisor://deceptive": 0.9, "sensor://field": 0.7},
        "feedback": None,
        "terminal": False,
    }


def latent_state():
    return {
        "world_kind": "latent_context_signal_duel",
        "role": "receiver",
        "phase": "RESPONSE",
        "round_index": 2,
        "rounds_total": 8,
        "opponent_signal": "FAST_SAFE",
        "source_claims": {"agent://signaler": 0.8, "sensor://field": 0.7},
        "feedback": None,
        "terminal": False,
    }


def test_signal_and_latent_adapters_emit_same_schema_and_no_world_identity():
    from aita.meta_generalization import project_latent_context_features, project_signal_hazard_features

    budget = Budget(observation_units=5, compute_units=20, action_units=20)
    signal = project_signal_hazard_features(
        signal_state(), budget,
        primary_trust=0.6, verifier_trust=0.8,
        primary_value_prior=-0.2, verify_value_prior=0.4,
        primary_signal="FAST_SAFE", verifier_signal=None,
    )
    latent = project_latent_context_features(
        latent_state(), budget,
        belief_entropy=0.7,
        primary_trust=0.6, verifier_trust=0.8,
        primary_value_prior=-0.2, verify_value_prior=0.4,
        primary_signal="FAST_SAFE", verifier_signal=None,
    )
    assert set(signal.to_dict()) == set(latent.to_dict())
    assert "world" not in signal.bucket_key().lower()
    assert "world" not in latent.bucket_key().lower()


def test_adapters_normalize_progress_cost_risk_and_conflict():
    from aita.meta_generalization import project_latent_context_features, project_signal_hazard_features

    budget = Budget(observation_units=4, compute_units=20, action_units=20)
    signal = project_signal_hazard_features(
        signal_state(), budget,
        primary_trust=0.5, verifier_trust=0.75,
        primary_value_prior=3.0, verify_value_prior=-4.0,
        primary_signal="FAST_SAFE", verifier_signal="FAST_CATASTROPHIC",
    )
    assert signal.progress_fraction == 2 / 7
    assert signal.observation_cost_fraction == 0.25
    assert signal.risk_if_wrong == 1.0
    assert signal.evidence_conflict is True
    assert signal.primary_value_prior == 1.0
    assert signal.verify_value_prior == -1.0

    latent = project_latent_context_features(
        latent_state(), Budget(observation_units=0),
        belief_entropy=1.2,
        primary_trust=0.4, verifier_trust=0.7,
        primary_value_prior=0.0, verify_value_prior=0.0,
        primary_signal="FAST_CATASTROPHIC", verifier_signal="FAST_CATASTROPHIC",
    )
    assert latent.uncertainty == 1.0
    assert latent.observation_available is False
    assert latent.observation_cost_fraction == 1.0
    assert latent.evidence_conflict is False


def test_signal_adapter_does_not_require_truth_or_actual_accuracy():
    from aita.meta_generalization import project_signal_hazard_features

    state = signal_state()
    state.pop("world_kind")
    features = project_signal_hazard_features(
        state,
        Budget(observation_units=2),
        primary_trust=0.55,
        verifier_trust=0.7,
        primary_value_prior=0.1,
        verify_value_prior=0.2,
        primary_signal=None,
        verifier_signal=None,
    )
    assert 0.0 <= features.uncertainty <= 1.0
    assert "regime" not in features.to_dict()
    assert "truth" not in features.to_dict()
