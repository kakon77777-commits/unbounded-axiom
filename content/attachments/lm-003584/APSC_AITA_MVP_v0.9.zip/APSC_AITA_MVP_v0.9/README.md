# APSC Runtime Lite + AI Tension Arena MVP v0.9

A deterministic, offline reference MVP for **Adaptive Possibility-Space Cognition (APSC)** and the **AI Tension Arena (AITA)** benchmark protocol.

This repository does **not** implement a new foundation model. It implements the control layer around a model or deterministic reference agent: canonical state, bounded possibility handling, observation/value decisions, finite cognitive budgets, Cognitive Operating Profiles (COP), receipts, replay, seeded benchmark worlds, and multi-metric evaluation.

## Current MVP

**MVP v0.9** preserves all v0.1–v0.8 contracts and adds **B4G**, a cross-world, **world-neutral** generalizing meta-controller. It aligns `SignalHazard-v0.4` and `LatentContextSignalDuel-v0.6` as `trust_primary` versus `verify_independent`, adds explicit **target uncertainty** and uncertainty-discounted counterfactual evidence, and adds a **learned exploration** policy.

The formal protocol evaluates both **SignalHazard → LatentContext** and **LatentContext → SignalHazard** with disjoint train/eval seeds and persisted models reloaded **frozen**. SignalHazard → LatentContext reaches 0.30 mean B4G utility versus -0.26875 for B4/B4G0, but includes 2 negative-transfer rows and increases field checks to 8.0. LatentContext → SignalHazard improves over empty B4G by +0.525 mean utility yet remains worse than handcrafted B4 (-1.10 versus -0.05) and has 4/8 **negative transfer** rows. This is measurable cross-world transfer, **not a universal ranking**.

Compatibility baseline: **MVP v0.8** remains the exploration-aware B4X control with **forced exploration**, counterfactual and **off-policy** cognition experience, **uncertainty**-aware selection, bounded cognition **coverage**, seed-disjoint **held-out** evaluation, persisted **frozen** models, and its explicit **not a universal ranking** limitation.  **MVP v0.7** remains the learned-meta-controller control and preserves its replayable negative result: naive on-policy learning produced 335 `trust_signal` versus 1 `observe_field` experience and degraded held-out utility. **MVP v0.6** remains the latent-context inference control (`LatentContextSignalDuel-v0.6`, `LatentContextBeliefTracker`, belief-weighted contextual trust/MVC, and `latent_context.jsonl`) and retains its explicit **not a universal ranking** limitation. **MVP v0.5** remains the observable-context **strategic deceptive signaling** control (`StrategicSignalDuel-v0.5`, `ContextualSourceReliabilityTracker`, `ContextualMVCValueEstimator`, and `deception.jsonl`). **MVP v0.4** remains the preserved noisy-observation/calibration baseline (`SignalHazard-v0.4`, declared vs calibrated reliability, estimated MVC, `calibration.jsonl`, and its **task-specific calibration** result). **MVP v0.3** remains the observation-loss/mixed-motive baseline, and **MVP v0.2** remains the dual-agent baseline.

Implemented:

- `GeneralizedCognitiveFeatures`, a world-neutral cognition representation with no world identity or hidden/oracle fields;
- `CrossWorldMetaValueModel` with target-uncertainty-discounted evidence and deterministic persistence;
- `LearnedExplorationPolicyModel` trained from paired actual/counterfactual generalized cognition outcomes;
- `B4G`, preserving B4 local calibration fallback and hard budget gates while applying transferred cognition value;
- replay-hashed `meta_generalization.jsonl`;
- bidirectional `aita meta-transfer` train/freeze/held-out experiments;
- canonical APSC state/budget/COP dataclasses;
- possibility graph with hard/soft constraint handling and merge lineage;
- cognitive operator specifications;
- Counterfactual Observation Expansion value primitives;
- adaptive controller with budget feasibility, shadow-price scoring, stop behavior, and preemption threshold;
- versioned runtime state, decision receipts, budget trajectories, JSON/JSONL replay artifacts and SHA-256 manifests;
- `HiddenRoute-v0.1` partial-observation route benchmark;
- `LimitedVerifier-v0.1` verifier-allocation benchmark;
- `HiddenRouteDuel-v0.2` dual-agent partial-observation benchmark with collision tension, exclusive node claims, and a public rule shift;
- `HazardChoice-v0.3` single-agent benchmark where a probe can create measurable **observation-prevented loss** by avoiding an irreversible catastrophic route;
- `NegotiationSplit-v0.3` mixed-motive duel with private preferences, offer/accept/reject/wait actions, joint utility, Pareto efficiency, agreement stability, negotiation regret, and a public disagreement-payoff rule shift;
- `SignalHazard-v0.4` multi-round benchmark with a 0.70-declared field sensor, a 0.90-declared deceptive advisor, deterministic 0.75/0.25 empirical correctness, truth feedback after each action, and replayable source calibration;
- `SourceReliabilityTracker` for online declared-vs-calibrated reliability updates and Brier-style calibration error;
- `OnlineMVCValueEstimator` for an incremental realized-gain estimate used as an estimated MVC proxy;
- `LatentContextBeliefTracker` for deterministic hidden incentive/context inference without receiver access to the context label;
- belief-weighted `ContextualSourceReliabilityTracker` and `ContextualMVCValueEstimator` updates with fractional evidence;
- `LatentContextSignalDuel-v0.6` with hidden persistent contexts, receiver-side intent inference, and hashed `latent_context.jsonl` replay evidence;
- `CognitiveExperience` with a closed action-time feature schema that excludes hidden context, current truth, future truth, and oracle actions;
- `ExperienceMetaValueModel`, a deterministic empirical meta-value model with global-to-feature-bucket backoff, stable JSON persistence, and SHA-256 identity;
- weighted meta-value evidence plus deterministic local-bucket uncertainty queries while preserving the v0.7 model serialization contract;
- `UncertaintyAwareMetaSelector`, combining a per-episode cognition coverage floor with learned value plus uncertainty bonus;
- `B4X`, an exploration-aware learned baseline with forced cognition coverage, uncertainty-aware routing, terminal experience finalization, and hard observation-budget gating;
- `MetaTrainingExperience`, separating on-policy, forced-exploration, uncertainty-exploration, and `counterfactual_off_policy` training provenance;
- replay-derived counterfactual/off-policy cognition experience that reuses action-time features and uses revealed truth only for post-outcome target construction;
- hashed `meta_exploration.jsonl` replay evidence and a deterministic B4/B4X train/freeze/held-out experiment pipeline;
- `B4L`, a learned-meta-controller baseline that preserves B4's hard budget/COP gates and uses learned values only to rank feasible cognition operations;
- train/freeze/held-out meta-learning experiments with disjoint seeds, frozen-model hash checks, paired B4/B4L evaluation, and repeat-run determinism;
- dual-agent runner with independent budgets, observations, COP traces, and simultaneous action bundles;
- COP cross-play and deterministic role swap benchmark matrices;
- B0–B4 reference baselines;
- canonical metric vector and paired multi-seed benchmark matrix;
- CLI for run/replay/compare/matrix/report;
- acceptance-gate validation.

## Install

Python 3.12+ is required.

```bash
python -m pip install -e '.[dev]'
```

In an offline environment that already has setuptools/pytest installed, disable build isolation:

```bash
python -m pip install -e . --no-build-isolation
```

The runtime itself has no third-party runtime dependency. `pytest` is used for development verification.

## Test

```bash
pytest -q
python -m compileall -q src
```

## Run one episode

```bash
aita run --world HiddenRoute-v0.1 --baseline B4 --seed 1 --budget medium --profile balanced --output runs/hidden-b4
```

Or without installing the console script:

```bash
PYTHONPATH=src python -m aita.cli run --world HiddenRoute-v0.1 --baseline B4 --seed 1 --output runs/hidden-b4
```


## Run one duel episode

```bash
aita duel --world HiddenRouteDuel-v0.2 --baseline-a B3 --baseline-b B4 --profile-a balanced --profile-b balanced --seed 42 --budget small --output runs/duel-b3-b4
```

The world applies a public **rule shift** during the episode. B4 may react with an adaptive COP shift and ProfileReceipt, while B3 keeps its fixed COP.

## Run a COP cross-play / role swap matrix

```bash
aita duel-matrix examples/benchmark_v0.2.json --output runs/duel-matrix
```

The v0.2 matrix supports **COP cross-play** and deterministic **role swap** so policy effects can be separated from role-position effects.


## Run the v0.3 observation-loss benchmark

```bash
aita matrix examples/benchmark_v0.3_hazard.json --output runs/v03-hazard-high-risk
aita matrix examples/benchmark_v0.3_hazard_low_latency.json --output runs/v03-hazard-low-latency
```

Across the fixed 1–8 reference seeds, the high-risk profile pays observation cost to avoid catastrophic FAST outcomes, while the low-latency profile is cheaper on safe seeds but accepts catastrophic exposure. This is a **task-specific trade-off** and **not a universal ranking** of the profiles.

## Run the v0.3 mixed-motive negotiation benchmark

```bash
aita duel-matrix examples/benchmark_v0.3_negotiation.json --output runs/v03-negotiation
```

`NegotiationSplit-v0.3` reports individual utility together with joint utility, Pareto efficiency, agreement stability, concession cost, and negotiation regret. Role swap remains enabled so private-role position is separated from policy effects.

## Run the v0.4 noisy/deceptive observation benchmark

```bash
aita matrix examples/benchmark_v0.4_signal_hazard.json --output runs/v04-signal-hazard
```

`SignalHazard-v0.4` runs eight hazard rounds per episode. `sensor://field` declares reliability 0.70 and is empirically correct 0.75 of the time; `advisor://deceptive` declares 0.90 but is empirically correct only 0.25 of the time. B4 starts from declared reliability, then updates calibrated reliability and estimated MVC from post-action truth feedback. In the seed-1 reference run it selects the advisor first, lowers its estimate from 0.90 to 0.60 after the first revealed error, and then switches to the field sensor.

This is evidence that calibration can change cognition routing in this bounded benchmark. It is **not a universal ranking** of B4 over fixed-source policies: B1, which is hard-coded to the better source, remains stronger on mean task utility in the reference set.

## Replay / validate a run

```bash
aita replay runs/hidden-b4
```

## Compare two runs

```bash
aita compare runs/a runs/b
```

## Run a benchmark matrix

The MVP uses JSON to remain stdlib-only.

```bash
aita matrix examples/benchmark.json --output runs/matrix
aita strategic-matrix examples/benchmark_v0.5_strategic_signal.json --output runs/strategic-v05
aita latent-signal-matrix examples/benchmark_v0.6_latent_context.json --output runs/latent-v06
aita meta-learn examples/benchmark_v0.7_meta_learning.json --output runs/meta-v07
aita meta-explore examples/benchmark_v0.8_meta_exploration.json --output runs/meta-v08
aita report runs/matrix
```

## Worlds

### HiddenRoute-v0.1

A seeded graph world with hidden hazards, optional probes, multiple routes, finite observation/action budgets and a deadline. It tests observe-vs-act decisions, reachability, risk handling and commit timing.


### HiddenRouteDuel-v0.2

A shared seeded graph world for two agents. Hazards are hidden and probes are private; both agents act on the same world tick, same-target movement produces deterministic collision tension, first arrival can claim exclusive nodes, and the topology performs a public rule shift at a configured tick. It tests opponent-aware routing, adaptive COP changes, budget competition, and replayable multi-agent trajectory divergence.


### HazardChoice-v0.3

A one-decision hidden-regime world with `FAST` and `SAFE` routes. A bounded probe reveals whether FAST is safe or catastrophic. Choosing FAST without probing is efficient when the hidden regime is safe, but produces an irreversible large loss when catastrophic. The benchmark emits `catastrophic_loss`, `avoidable_loss`, and `observation_prevented_loss`.

### NegotiationSplit-v0.3

A deterministic two-agent **mixed-motive** bargaining world with private minimum shares, concession costs, and ideal shares. Agents can offer, accept, reject, or wait. A scheduled public rule shift changes disagreement payoffs and increments `rule_version`; adaptive B4 can react with a `rule_shift_trigger` ProfileReceipt. The world reports joint utility, **Pareto efficiency**, agreement stability, concession cost, and negotiation regret.

### SignalHazard-v0.4

A sequential eight-round hazard world for reliability-aware observation. The current regime and each source's actual accuracy remain hidden from public state. The field sensor has lower declared reliability but higher empirical correctness; the deceptive advisor advertises higher reliability while being systematically misleading. After each route action, the previous round truth is revealed as feedback so source trust can be calibrated online without exposing the current round truth. B4 stores public `calibration.jsonl` evidence containing calibrated reliability, calibration error, source selection, and estimated MVC snapshots.

### StrategicSignalDuel-v0.5

A deterministic eight-round role-asymmetric signaling arena. `agent://signaler` sees the hidden current truth and may report it honestly, invert it, or remain silent; `agent://receiver` never receives current truth before acting and may spend observation budget on `sensor://field`. Public `ALIGNED` / `COMPETITIVE` context changes the signaler's incentive. B4 performs contextual source calibration and contextual MVC estimation, allowing the same signaler to be trusted differently across incentive contexts. Strategic evidence is stored in hashed `deception.jsonl` when supported by the Agent.

### LatentContextSignalDuel-v0.6

A role-asymmetric strategic signaling control in which the arena still has a seeded hidden `ALIGNED` / `COMPETITIVE` incentive context but the receiver never receives that label in public state, field observation, or feedback. B4 maintains a posterior with `LatentContextBeliefTracker`, applies belief-weighted contextual trust/MVC, and can switch between `trust_signal` and `observe_field`. Public inference evidence is stored in hashed `latent_context.jsonl`. The v0.6 result is **not a universal ranking**: latent inference improves on fixed trust in the reference strategic rows but does not yet outperform always verifying on mean utility.

### LimitedVerifier-v0.1

A seeded candidate-selection world with a hidden oracle and a hard verifier quota. It tests verifier allocation, stopping and commitment under limited evidence.

## Baselines

| Baseline | Behavior |
|---|---|
| B0 | Neural-direct analogue: observe public state, act directly |
| B1 | Fixed depth: one local probe/verification step, then act |
| B2 | Fixed search + verify: exhaust local fixed search before acting |
| B3 | APSC controller with fixed COP |
| B4 | APSC controller with adaptive COP and ProfileReceipt |
| B4L | B4 latent-context controller plus frozen/trainable ExperienceMetaValueModel cognition ranking |

## Canonical evaluation vector

Every episode emits separate values for:

- task utility;
- decision quality;
- cognitive efficiency;
- observation efficiency;
- critical branch recall;
- opponent-model regret;
- allocation regret;
- observation regret;
- commit regret;
- rule compliance;
- robustness.

The MVP intentionally does not make a single aggregate score canonical.

## Replay artifacts

A normal episode writes:

```text
episode.json
world_manifest.json
events.jsonl
observations.jsonl
cognitive_ops.jsonl
actions.jsonl
budgets.jsonl
profiles.jsonl
receipts.jsonl
score.json
replay_manifest.json
# calibration.jsonl is additionally emitted for runs with public calibration evidence
# deception.jsonl is emitted for strategic contextual-calibration evidence
# latent_context.jsonl is emitted for hidden-context inference evidence
# meta_learning.jsonl stores learned-controller model/routing snapshots when supported
# meta_experiences.jsonl stores public CognitiveExperience rows when supported
```

Replay hashes cover all public benchmark artifacts.

## Core boundaries

- Neural/model proposals never directly mutate canonical state.
- Observation does not equal truth; hidden/noisy observation remains an explicit protocol concept. **Declared reliability** is a source prior, not truth, and can diverge from **calibrated reliability** after feedback.
- Decision does not equal commit.
- Budgets fail closed when exhausted.
- Hidden state is not exposed through public state.
- Adaptive COP changes create receipts.
- **No private chain-of-thought persistence.** Replay stores public state transitions, selected cognitive operators, observations, actions, budgets, profiles and receipts only.
- All MVP worlds are **bounded simulation**. There is no real-world high-risk actuator.

## Architecture

```text
APSC Runtime
  state / budget / COP
  possibility / constraints / operators
  COE / adaptive controller
  receipts / replay
        |
        v
AITA Protocol
  world / observation / action
  budget parity / seeded episodes
  scoring / benchmark matrix / CLI
```

## Repository layout

```text
src/apsc/        APSC Runtime Lite
src/aita/        AI Tension Arena protocol and worlds
tests/           TDD + acceptance suite
examples/        benchmark spec and generated reference outputs
docs/specs/      approved v0.1 technical whitepapers
docs/superpowers/plans/ implementation plan
docs/ACCEPTANCE.md acceptance-gate mapping
```

## MVP non-goals

v0.7 intentionally does not implement a universal world model, general causal discovery, a full POMDP solver, private reasoning persistence, unrestricted long-running autonomy, real military/financial execution, arbitrary autonomous network attack tooling, or a high-fidelity 3D game.

The v0.7 learned meta-controller is a deterministic reference learner, not a neural meta-controller. The next engineering problem is to prevent cognitive policy collapse by improving exploration/action coverage, uncertainty awareness, and counterfactual or off-policy cognition experience while preserving deterministic benchmark kernels, budget, COP, receipt, and replay contracts.
